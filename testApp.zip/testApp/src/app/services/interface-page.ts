export interface Page {
    csuname: string;
    changed: boolean;
  };