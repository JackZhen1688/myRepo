import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { CurrencyPipe, DatePipe } from '@angular/common'
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { LocationStrategy, PathLocationStrategy } from '@angular/common';
import { HttpConfigInterceptor} from '../interceptors/httpconfig.interceptor';
//import { TokenInterceptorService} from '../interceptors/token.interceptor.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';   //FormsModule->[(ngModel)]  ReactiveFormsModule->[formGroup]
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';  
import { DragDropModule} from '@angular/cdk/drag-drop';
//Material Module
import { MdePopoverModule } from '@material-extended/mde';
import { AngularFontAwesomeModule } from 'angular-font-awesome';
import { MatBadgeModule } from '@angular/material/badge';
import { MatMenuModule, 
         MatPaginatorModule,
         MatProgressSpinnerModule, 
         MatSidenavModule,
         MatSortModule,
         MatListModule,
         MatTooltipModule,
         MatTabsModule,
         MatCardModule,
         MatDividerModule,
         MatTableModule,
         MatInputModule,
         MatButtonModule,
         MatDialogModule,
         MatSnackBarModule,
         MatCheckboxModule,
         MatRadioModule,
         MatSelectModule,
         MatDatepickerModule,
         MatNativeDateModule,
         MatAutocompleteModule,
         MatStepperModule,
         MatIconModule,
         MatTreeModule,
         MatGridListModule,
         MatExpansionModule,
         MatSlideToggleModule,
         MatToolbarModule } from '@angular/material';
//ngx-* Module         
import { NgxMaskModule } from 'ngx-mask'
import { TreeviewModule } from 'ngx-treeview';
import { ChartsModule, ThemeService } from 'ng2-charts';
//DSAMS Services
import { DsamsDeactivateService } from './dsams/services/dsams-deactivate.service';
import { DsamsMethodsService } from './dsams/services/dsams-methods.service'
import { DsamsUserMessageService } from './dsams/services/dsams-user-message.service'
import { BillingRestfulService } from './dsams/billing/services/billing-restful.service';
import { ReimbursementService } from './dsams/billing/services/manage-manual-reimbursement.service';
import { BillAmountsValidatorService } from './dsams/billing/services/bill-amounts-validator.service';
import { CaseRestfulService } from './dsams/case/services/case-restful.service';
import { CaseUIService } from './dsams/case/services/case-ui-service';
import { ObjectService } from './dsams/case/initialize/basic/case-objects/object-service';
import { FundingUIService } from './dsams/funding/services/funding-ui-service';
import { AuthenticationService } from '../interceptors/authentication.service';
import { ShareMethodsService } from './dsams/case/milestone-dashboard/services/share-methods.service'

//DSAMS Directives
import { NumbersOnlyDirective } from './dsams/directives/numbers-only.directive';
import { ToUpperCaseDirective } from './dsams/directives/toUpperCase.directive';
//DSAMS Test Components
import { TestComponent, DialogOverviewExampleDialog} from './dsams/test/test.component';
//DSAMS Components
import { AppComponent } from './app.component';
import { FooterComponent } from './footer/footer.component';
import { HeaderComponent } from './header/header.component';
import { NotFoundComponent } from './not-found/not-found.component';
import { NotAuthorizedComponent } from './not-authorized/not-authorized.component';
import { HomeComponent } from './home/home.component';
import { SignOutComponent } from './sign-out/sign-out.component';
import { MenubarComponent } from './dsams/billing/menubar/menubar.component';
import { BillingDashboardComponent } from './dsams/billing/billing-dashboard/billing-dashboard.component';
import { FinancialHistoryComponent } from './dsams/billing/financial-history/financial-history.component';
import { GfebsSuffixCycleComponent } from './dsams/billing/run-new-cycle/gfebs-suffix-cycle/gfebs-suffix-cycle.component';
import { GfebsTlaCycleComponent } from './dsams/billing/run-new-cycle/gfebs-tla-cycle/gfebs-tla-cycle.component';
import { ManualObligationDisbursementsComponent } from './dsams/billing/manual-obligation-disbursements/manual-obligation-disbursements.component';
import { MangeAutomaticReimbursementCycleComponent } from './dsams/billing/run-new-cycle/manage-automatic-reimbursement-cycle/manage-automatic-reimbursement-cycle.component';
import { MangeManualReimbursementCycleComponent } from './dsams/billing/run-new-cycle/manage-manual-reimbursement-cycle/manage-manual-reimbursement-cycle.component';
import { DovComponent } from './dsams/billing/run-new-cycle/manage-manual-reimbursement-cycle/dov.component';
import { MenubarCaseComponent } from './dsams/case/menubar-case/menubar-case.component';
import { UpdateComponent } from './dsams/case/update/update.component';
import { ViewComponent } from './dsams/case/view/view.component';
import { AmendmentComponent } from './dsams/case/initialize/amendment/amendment.component';
import { ModificationComponent } from './dsams/case/initialize/modification/modification.component';
import { RevisionComponent } from './dsams/case/initialize/revision/revision.component';
import { ProcessOneComponent } from './dsams/case/initialize/basic/process-one/process-one.component';
import { ProcessTwoComponent } from './dsams/case/initialize/basic/process-two/process-two.component';
import { ProcessThreeComponent } from './dsams/case/initialize/basic/process-three/process-three.component';
import { ProcessFourComponent } from './dsams/case/initialize/basic/process-four/process-four.component';
import { CustomerRequestComponent } from './dsams/case/dialogs/customer-request/customer-request.component';
import { AutonewReimbursementCycleComponent } from './dsams/billing/run-new-cycle/autonew-reimbursement-cycle/autonew-reimbursement-cycle.component';
import { AutonewReimburseCycleComponent } from './dsams/billing/run-new-cycle/autonew-reimburse-cycle/autonew-reimburse-cycle.component';
import { DialogMessageComponent } from './dsams/utilitis/dialogs/dialog-message/dialog-message.component';
import { DialogMegsListComponent } from './dsams/utilitis/dialogs/dialog-megs-list/dialog-megs-list.component';
import { DialogUserMessageComponent } from './dsams/utilitis/dialogs/dialog-user-message/dialog-user-message.component';
import { DiaModalCountryComponent } from './dsams/utilitis/dialogs/dia-modal-country/dia-modal-country.component';
import { DiaModalCaseComponent } from './dsams/utilitis/dialogs/dia-modal-case/dia-modal-case.component';
import { DiaModalLineComponent } from './dsams/utilitis/dialogs/dia-modal-line/dia-modal-line.component';
import { DiaModalFiscalYearComponent } from './dsams/utilitis/dialogs/dia-modal-fiscal-year/dia-modal-fiscal-year.component';
import { DiaModalWcnComponent } from './dsams/utilitis/dialogs/dia-modal-wcn/dia-modal-wcn.component';
import { DiaModalSuffixComponent } from './dsams/utilitis/dialogs/dia-modal-suffix/dia-modal-suffix.component';
import { DiaModalTlaSuffixComponent } from './dsams/utilitis/dialogs/dia-modal-tla-suffix/dia-modal-tla-suffix.component';
import { DiaModalExaComponent } from './dsams/utilitis/dialogs/dia-modal-exa/dia-modal-exa.component';
import { DialogDbsetsComponent } from './dsams/utilitis/dialogs/dialog-dbsets/dialog-dbsets.component';
import { CaseDashboardComponent } from './dsams/case/case-dashboard/case-dashboard.component';
import { DialogMessageYesnoComponent } from './dsams/utilitis/dialogs/dialog-message-yesno/dialog-message-yesno.component';
import { BreadcrumbComponent } from './breadcrumb/breadcrumb.component';
import { NotificationComponent } from './dsams/utilitis/notifications/notification/notification.component';
import { NotificationModalComponent } from './dsams/utilitis/notifications/notification-modal/notification-modal.component';
import { DiaModalFmsCaseComponent } from './dsams/utilitis/dialogs/dia-modal-fms-case/dia-modal-fms-case.component';
import { DiaModalGrantCaseComponent } from './dsams/utilitis/dialogs/dia-modal-grant-case/dia-modal-grant-case.component';
import { DescriptionsPanelComponent } from './dsams/case/case-dashboard/descriptions-panel/descriptions-panel.component';
import { CustomerRequestPanelComponent } from './dsams/case/case-dashboard/customer-request-panel/customer-request-panel.component';
import { DocumentPanelComponent } from './dsams/case/case-dashboard/document-panel/document-panel.component';
import { SignatoriesPanelComponent } from './dsams/case/case-dashboard/signatories-panel/signatories-panel.component';
import { WaiversPanelComponent } from './dsams/case/case-dashboard/waivers-panel/waivers-panel.component';
import { AssociationsPanelComponent } from './dsams/case/case-dashboard/associations-panel/associations-panel.component';
import { CaseInformationPanelComponent } from './dsams/case/case-dashboard/case-information-panel/case-information-panel.component';
import { CaseButtonsComponent } from './dsams/case/case-dashboard/case-buttons/case-buttons.component';
import { CaseSearchComponent } from './dsams/case/search/case-search.component';
import { RefAutoCompleteComponent } from './dsams/case/ref-auto-complete/ref-auto-complete.component';
import { LineDetailsComponent } from './dsams/case/line-dashboard/line/line-details.component';
import { LineSublineComponent } from './dsams/case/line-dashboard/line-list/line-subline.component';
import { LineDashboardComponent } from './dsams/case/line-dashboard/line-dashboard.component';
import { LineDeliveryComponent } from './dsams/case/line-dashboard/line-delivery/line-delivery.component';
import { LineSubdashboardComponent } from './dsams/case/line-dashboard/line-subdashboard/line-subdashboard.component';
import { FundingDashboardComponent } from './dsams/funding/funding-dashboard/funding-dashboard.component';
import { ManageOpenFundingCycleComponent } from './dsams/funding/manage-open-funding-cycle/manage-open-funding-cycle.component';
import { ConfirmDeleteComponent } from './dsams/funding/utils/confirm-delete/confirm-delete.component';
import { PopTemplateAllLevelsComponent } from './dsams/utilitis/popups/pop-template-all-levels/pop-template-all-levels.component';
import { PopCaseMasterLineComponent } from './dsams/utilitis/popups/pop-case-master-line/pop-case-master-line.component';
import { PopCaseAssociationComponent } from './dsams/utilitis/popups/pop-case-association/pop-case-association.component';
import { PopCaseActivityComponent } from './dsams/utilitis/popups/pop-case-activity/pop-case-activity.component';
import { FundingHomeComponent } from './dsams/funding/funding-home/funding-home.component';
import { PopWcnAllLevelsComponent } from './dsams/utilitis/popups/pop-wcn-all-levels/pop-wcn-all-levels.component';
import { DialogMessageListComponent } from './dsams/utilitis/dialogs/dialog-message-list/dialog-message-list.component';
import { DialogMessageListComponentTc } from './dsams/utilitis/dialogs/dialog-message-list-tc/dialog-message-list-tc.component';
import { DialogMessageListComponentPrint } from './dsams/utilitis/dialogs/dialog-message-list-print/dialog-message-list-print.component';
import { ReleaseTransactionsComponent } from './dsams/billing/release-transactions/release-transactions.component';
import { ReleaseDtimComponent } from './dsams/billing/release-dtim/release-dtim.component';
import { PopLineAllLevelsComponent } from './dsams/utilitis/popups/pop-line-all-levels/pop-line-all-levels.component';
import { PopPersonComponent } from './dsams/utilitis/popups/pop-person/pop-person.component';
import { PopCustomerRequestComponent } from './dsams/utilitis/popups/pop-customer-request/pop-customer-request.component';
import { RequiredIndComponent } from './dsams/utilitis/required-ind.component';
import { Sizometer } from './dsams/utilitis/sizometer.component';
import { ResTextComponent } from './dsams/utilitis/res-text.component';
import { EditSliderComponent } from './dsams/utilitis/edit-slider-component/edit-slider-component';
import { EditToggleComponent } from './dsams/utilitis/edit-toggle/edit-toggle.component';
import { SlideToggleComponent } from './dsams/utilitis/slide-toggle';
import { PopSelectAllLevelBaseComponent } from './dsams/utilitis/popups/pop-select-all-level-base/pop-select-all-level-base.component';
import { PopSuffixAllLevelsComponent } from './dsams/utilitis/popups/pop-suffix-all-levels/pop-suffix-all-levels.component';
import { PopCountryAllLevelComponent } from './dsams/utilitis/popups/pop-country-all-level/pop-country-all-level.component';
import { LinePricingComponent } from './dsams/case/line-dashboard/line-pricing/line-pricing.component';
import { ManageArmyBillingCycleBaseComponent } from './dsams/billing/run-new-cycle/manage-army-billing-cycle-base/manage-army-billing-cycle-base.component';
import { CaseShortcutsComponent } from './dsams/case/shortcuts/case-shortcuts/case-shortcuts.component';
import { PopTttsAllLevelsComponent } from './dsams/utilitis/popups/pop-ttts-all-levels/pop-ttts-all-levels.component';
import { PopCaseAllLevelsComponent } from './dsams/utilitis/popups/pop-case-all-levels/pop-case-all-levels.component';
import { UpdateFillnobillComponent } from './dsams/billing/update-fillnobill/update-fillnobill.component';
import { CaseAmendModNumberComponent } from './dsams/case/case-dashboard/case-amendmod-number/case-amendmod-number.component';
import { GenerateTrainingFundingCycleComponent } from './dsams/funding/generate-training-funding-cycle/generate-training-funding-cycle.component';
import { ManageOfflineItoAuthorizationsComponent } from './dsams/funding/manage-offline-ito-authorizations/manage-offline-ito-authorizations.component';
import { ApproveBidCTransactionsComponent } from './dsams/funding/approve-bid-c-transactions/approve-bid-c-transactions.component';
import { AirforceDocumentCertificationComponent } from './dsams/funding/airforce-document-certification/airforce-document-certification.component';
import { DocumentAcceptanceComponent } from './dsams/funding/document-acceptance/document-acceptance.component';
import { ArmyDocumentCertificationComponent } from './dsams/funding/army-document-certification/army-document-certification.component';
import { FinancialPipelineSuffixComponent } from './dsams/funding/financial-pipeline-suffix/financial-pipeline-suffix.component';
import { AirforceFinancialPipelineComponent } from './dsams/funding/airforce-financial-pipeline/airforce-financial-pipeline.component';
import { ArmyFinancialPipelineComponent } from './dsams/funding/army-financial-pipeline/army-financial-pipeline.component';
import { NavyFinancialPipelineComponent } from './dsams/funding/navy-financial-pipeline/navy-financial-pipeline.component';
import { CustomerNumberStartingRangesComponent } from './dsams/funding/customer-number-starting-ranges/customer-number-starting-ranges.component';
import { RouterOutletCanDeactivatePluginDirective } from './dsams/blockers/router-outlet-can-deactivate-plugin.directive';
import {CanDeactiveNotiticationService} from './dsams/blockers/can-deactive-notitication.service';
import { CaseCountryComponent } from './dsams/case/case-dashboard/case-country/case-country.component';
import { PopSuffixModdComponent } from './dsams/utilitis/popups/pop-suffix-modd/pop-suffix-modd.component';
import { PopupTestComponent } from './dsams/popup-test/popup-test.component';
import { CurrencyFormatterDirective } from './dsams/directives/currency-formatter.directive';
import { NotificationFundingComponent } from './dsams/utilitis/notifications/notification-funding/notification-funding.component';
import { ChartComponent } from './dsams/utilitis/charts/chart/chart.component';
import { PopTrainingActvityRoleComponent } from './dsams/utilitis/popups/pop-training-actvity-role/pop-training-actvity-role.component';
import { CaseReserveComponent } from './dsams/case/case-dashboard/case-reserve/case-reserve.component';
import { DeleteConfirmationComponent } from './dsams/case/dialogs/delete-confirmation/delete-confirmation.component';
import { PopMaslComponent } from './dsams/utilitis/popups/pop-masl/pop-masl.component';
import { MilestoneCommentComponent } from './dsams/case/dialogs/milestone-comment/milestone-comment.component';
import { RequestImmediateFundingComponent } from './dsams/funding/request-immediate-funding/request-immediate-funding.component';
import { RequestImmediateSuffixFundingComponent } from './dsams/funding/request-immediate-funding/request-immediate-suffix-funding/request-immediate-suffix-funding.component';
import { RequestImmediateTlaFundingComponent } from './dsams/funding/request-immediate-funding/request-immediate-tla-funding/request-immediate-tla-funding.component';
import { AnnouncementsComponent } from './dsams/utilitis/announcements/announcements.component';
import { PendingTasksComponent } from './dsams/utilitis/pending-tasks/pending-tasks.component';
import { RollupSublineComponent } from './dsams/case/dialogs/rollup-subline/rollup-subline.component';
import { HomeChartComponent } from './dsams/utilitis/charts/home-chart/home-chart.component';
import { AlertsComponent } from './dsams/utilitis/alerts/alerts.component';
import { CusRequestDashboardComponent } from './dsams/customer-request/cus-request-dashboard/cus-request-dashboard.component';
import { CongNotificationDashboardComponent } from './dsams/congressional-notification/cong-notification-dashboard/cong-notification-dashboard.component';
import { SummaryPanelComponent } from './dsams/customer-request/summary-panel/summary-panel.component';
import { SummaryNotifyPanelComponent } from './dsams/congressional-notification/summary-notify-panel/summary-notify-panel.component';
import { RequirementsPanelComponent } from './dsams/customer-request/requirements-panel/requirements-panel.component';
import { RemarksPanelComponent } from './dsams/customer-request/remarks-panel/remarks-panel.component';
import { ManageGafsPsrDetailsComponent } from './dsams/funding/manage-gafs-psr-details/manage-gafs-psr-details.component';
import { TextAreaComponent } from './dsams/case/dialogs/text-area/text-area.component';
import { PopNporComponent } from './dsams/utilitis/popups/pop-npor/pop-npor.component';
import { FundingDocumentContactsComponent } from './dsams/funding/funding-document-contacts/funding-document-contacts.component';
import { IpcDashboardComponent } from './dsams/case/line-dashboard/line-pricing/ipc-tab-dashboard/ipc-dashboard/ipc-dashboard.component';
import { IpcTabComponent } from './dsams/case/line-dashboard/line-pricing/ipc-tab-dashboard/ipc-tab/ipc-tab.component';
import { IpcCostTabComponent } from './dsams/case/line-dashboard/line-pricing/ipc-tab-dashboard/ipc-cost-tab/ipc-cost-tab.component';
import { AutocompleteDropdownComponent } from './dsams/case/line-dashboard/line-pricing/ipc-tab-dashboard/ipc-dashboard/autocomplete-dropdown/autocomplete-dropdown.component';
import { PopGafsAccountLineComponent } from './dsams/utilitis/popups/pop-gafs-account-line/pop-gafs-account-line.component';
import { CivilianPersonnelComponent } from './dsams/case/dialogs/civilian-personnel/civilian-personnel.component';
import { SupplementalNoteTabComponent } from './dsams/case/line-dashboard/line-pricing/ipc-tab-dashboard/supplemental-note-tab/supplemental-note-tab.component';
import { PublicationsComponent } from './dsams/case/dialogs/publications/publications.component';
import { DTCComponent } from './dsams/case/dialogs/dtc/dtc.component';
import { MtdsComponent } from './dsams/case/dialogs/mtds/mtds.component';
import { ManpowerComponent } from './dsams/case/dialogs/manpower/manpower.component';
import { NoteListComponent } from './dsams/case/note-dashboard/note-list/note-list.component';
import { NoteDashboardComponent } from './dsams/case/note-dashboard/note-dashboard.component';
import { NoteDetailsComponent } from './dsams/case/note-dashboard/note/note-details.component';
import { AssoLinesComponent } from './dsams/case/dialogs/asso-lines/asso-lines.component';
import { UnderConstructionComponent } from './dsams/utilitis/under-construction/under-construction.component';
import { PopCaseNoteComponent } from './dsams/utilitis/popups/pop-case-note/pop-case-note.component';
import { ArmyFinancialPipelineSuffixDetailsComponent } from './dsams/funding/army-financial-pipeline-suffix-details/army-financial-pipeline-suffix-details.component';
import { ReplaceExpiredVersionComponent } from './dsams/case/dialogs/replace-expired-version/replace-expired-version.component';
import { RemarksDashboardComponent } from './dsams/case/remarks-dashboard/remarks-dashboard.component';
import { MilestoneDashboardComponent } from './dsams/case/milestone-dashboard/milestone-dashboard.component';
import { CaseRemarksPanelComponent } from './dsams/case/remarks-dashboard/case-remarks-panel/case-remarks-panel.component';
import { AssignReferenceNotesComponent } from './dsams/case/dialogs/assign-reference-notes/assign-reference-notes.component';
import { AttachmentsDashboardComponent } from './dsams/case/attachments-dashboard/attachments-dashboard.component';
import { CaseAttachmentsPanelComponent } from './dsams/case/attachments-dashboard/case-attachments-panel/case-attachments-panel.component';
import { EditSliderChild } from './dsams/utilitis/edit-slider/edit-slider-child.component';
import { ITOAuthorizations } from './dsams/funding/ito-authorizations/ito-authorizations.component';
import { CaseAmountPanelComponent } from './dsams/congressional-notification/case-amount-panel/case-amount-panel.component';
import { CaseCommentsPanelComponent } from './dsams/congressional-notification/case-comments-panel/case-comments-panel.component';
import { FindReportComponent } from './dsams/reports/find-report/find-report.component';
import { PopCongNotificationComponent } from './dsams/utilitis/popups/pop-cong-notification/pop-cong-notification.component';
import { PopCongMaslComponent } from './dsams/utilitis/popups/pop-cong-masl/pop-cong-masl.component';
import { CaseQuantityPanelComponent } from './dsams/congressional-notification/case-quantity-panel/case-quantity-panel.component';
import { DeamsTransactionApprovalComponent } from './dsams/funding/deams-transaction-approval/deams-transaction-approval.component';
import { CaseOveragePanelComponent } from './dsams/congressional-notification/case-overage-panel/case-overage-panel.component';
import { CongAttachmentsPanelComponent } from './dsams/congressional-notification/cong-attachments-panel/cong-attachments-panel.component';
import { ReleaseBIDsToGAFSComponent } from './dsams/funding/release-bids-to-gafs/release-bids-to-gafs.component';
import { PersonComponent } from './dsams/reference/person/person.component';
import { CaseAmendModRefreshComponent } from './dsams/case/case-dashboard/case-amendmod-refresh/case-amendmod-refresh.component';
import { ModFundingPanelComponent } from './dsams/case/case-dashboard/mod-funding-panel/mod-funding-panel.component';
import { CaseMilestoneComponent } from './dsams/case/milestone-dashboard/case-milestone/case-milestone.component';
import { CaseMilestoneOptionsComponent } from './dsams/case/milestone-dashboard/case-milestone-options/case-milestone-options.component';
import { PopCaseMilestoneComponent } from './dsams/utilitis/popups/pop-case-milestone/pop-case-milestone.component';
import { ControlMilestoneComponent } from './dsams/case/milestone-dashboard/case-milestone-options/control-milestone/control-milestone.component';
import { PopCommonMilestoneComponent } from './dsams/utilitis/popups/pop-common-milestone/pop-common-milestone.component';

@NgModule({
  declarations: [
    AppComponent, 
    FooterComponent,
    HeaderComponent,
    NotFoundComponent,
    NotAuthorizedComponent,
    HomeComponent,
    SignOutComponent,
    MenubarComponent,
    BillingDashboardComponent,
    TestComponent,
    DialogOverviewExampleDialog,
    FinancialHistoryComponent,
    GfebsSuffixCycleComponent,
    GfebsTlaCycleComponent,
    ITOAuthorizations,
    ManualObligationDisbursementsComponent,
    MangeAutomaticReimbursementCycleComponent,
    MangeManualReimbursementCycleComponent,
    DovComponent,
    NumbersOnlyDirective,
    ToUpperCaseDirective,
    MenubarCaseComponent,
    UpdateComponent,
    ViewComponent,
    AmendmentComponent,
    ModificationComponent,
    RevisionComponent,
    ProcessOneComponent,
    ProcessTwoComponent,
    ProcessThreeComponent,
    ProcessFourComponent,
    CustomerRequestComponent,
    AutonewReimbursementCycleComponent,
    AutonewReimburseCycleComponent,
    DialogMessageComponent,
    DialogMegsListComponent,
    DiaModalCountryComponent,
    DiaModalCaseComponent,
    DiaModalLineComponent,
    DiaModalFiscalYearComponent,
    DiaModalWcnComponent,
    DiaModalSuffixComponent,
    DiaModalExaComponent,
    DialogDbsetsComponent,
    CaseDashboardComponent,
    DialogMessageYesnoComponent,
    DialogUserMessageComponent,
    BreadcrumbComponent,
    NotificationComponent,
    NotificationModalComponent,
    DiaModalFmsCaseComponent,
    DiaModalGrantCaseComponent,
    DiaModalTlaSuffixComponent,
    DescriptionsPanelComponent,
    CustomerRequestPanelComponent,
    DocumentPanelComponent,
    SignatoriesPanelComponent,
    WaiversPanelComponent,
    AssociationsPanelComponent,
    CaseInformationPanelComponent,
    CaseButtonsComponent,
    CaseSearchComponent,
    RefAutoCompleteComponent,
    LineDetailsComponent,
    LineSublineComponent,
    LineDashboardComponent,
    LineDeliveryComponent,
    LineSubdashboardComponent,   
    FundingDashboardComponent, 
    ManageOpenFundingCycleComponent,
    ConfirmDeleteComponent,
    PopTemplateAllLevelsComponent,
    PopCaseMasterLineComponent,
    PopCaseAssociationComponent,
    PopCaseActivityComponent,
    PopMaslComponent,
    PopPersonComponent,
    PopCustomerRequestComponent,
    RequiredIndComponent,
    Sizometer,
    ResTextComponent, 
    EditSliderComponent,
    EditSliderChild,
    EditToggleComponent,
    SlideToggleComponent,
    PopSuffixAllLevelsComponent,
    PopSelectAllLevelBaseComponent,
    FundingHomeComponent,
    PopWcnAllLevelsComponent,
    DialogMessageListComponent,
    DialogMessageListComponentTc,
    DialogMessageListComponentPrint,
    ReleaseTransactionsComponent,
    PopLineAllLevelsComponent,
    PopSelectAllLevelBaseComponent,
    PopNporComponent,
    ReleaseDtimComponent,    
    PopSuffixModdComponent,
    PopCountryAllLevelComponent,
    LinePricingComponent,
    ManageArmyBillingCycleBaseComponent,
    CaseShortcutsComponent,
    PopTttsAllLevelsComponent,
    PopCaseAllLevelsComponent,
    UpdateFillnobillComponent,
    CaseAmendModNumberComponent,
    // GenerateFundingCycleComponent,
    GenerateTrainingFundingCycleComponent,
    ManageOfflineItoAuthorizationsComponent,
    ApproveBidCTransactionsComponent,
    AirforceDocumentCertificationComponent,
    DocumentAcceptanceComponent,
    ArmyDocumentCertificationComponent,
    FinancialPipelineSuffixComponent,
    AirforceFinancialPipelineComponent,
    ArmyFinancialPipelineComponent,
    NavyFinancialPipelineComponent,
    CustomerNumberStartingRangesComponent,
    RouterOutletCanDeactivatePluginDirective,
    CaseCountryComponent,
    PopSuffixModdComponent,
    PopupTestComponent,
    CurrencyFormatterDirective,
    NotificationFundingComponent,
    ChartComponent,
    PopTrainingActvityRoleComponent,
    CaseReserveComponent,
    DeleteConfirmationComponent,
    MilestoneCommentComponent,
    RequestImmediateFundingComponent,
    RequestImmediateSuffixFundingComponent,
    RequestImmediateTlaFundingComponent,
    AnnouncementsComponent,
    PendingTasksComponent,
    RollupSublineComponent,
    HomeChartComponent,
    AlertsComponent,
    // Customer Request components
    CusRequestDashboardComponent,
    CongNotificationDashboardComponent,
    RequirementsPanelComponent,
    SummaryPanelComponent,
    SummaryNotifyPanelComponent,
    RemarksPanelComponent,
    ManageGafsPsrDetailsComponent,
    TextAreaComponent,
    FundingDocumentContactsComponent,
    IpcDashboardComponent,
    IpcTabComponent,
    IpcCostTabComponent,
    AutocompleteDropdownComponent,
    PopGafsAccountLineComponent,
    CivilianPersonnelComponent,
    SupplementalNoteTabComponent,
    PublicationsComponent,
    DTCComponent,
    MtdsComponent,
    ManpowerComponent,
    NoteListComponent,
    NoteDashboardComponent,
    NoteDetailsComponent,
    AssoLinesComponent,
    UnderConstructionComponent,
    PopCaseNoteComponent,
    ArmyDocumentCertificationComponent,
    ArmyFinancialPipelineSuffixDetailsComponent,
    ReplaceExpiredVersionComponent,
    RemarksDashboardComponent,
    CaseRemarksPanelComponent,
    AssignReferenceNotesComponent,
    AttachmentsDashboardComponent,
    CaseAttachmentsPanelComponent,
    CaseAmountPanelComponent,
    CaseCommentsPanelComponent,
    FindReportComponent,
    PopCongNotificationComponent,
    PopCongMaslComponent,
    CaseQuantityPanelComponent,
    DeamsTransactionApprovalComponent,
    CaseOveragePanelComponent,
    CongAttachmentsPanelComponent,
    ReleaseBIDsToGAFSComponent,
    PersonComponent,
    CaseAmendModRefreshComponent,
    ModFundingPanelComponent,
    MilestoneDashboardComponent,
    CaseMilestoneComponent,
    CaseMilestoneOptionsComponent,
    PopCaseMilestoneComponent,
    ControlMilestoneComponent,
    PopCommonMilestoneComponent,
  ],
  entryComponents:[
    DialogOverviewExampleDialog, // For testing
    CustomerRequestComponent,
    DialogMessageComponent,
    DialogMegsListComponent,
    DialogUserMessageComponent,
    DialogMessageYesnoComponent,
    DialogDbsetsComponent,
    DiaModalCountryComponent,
    DiaModalCaseComponent,
    DiaModalGrantCaseComponent,
    DiaModalFmsCaseComponent,
    DiaModalLineComponent,
    DiaModalFiscalYearComponent,
    DiaModalWcnComponent,
    DiaModalSuffixComponent,
    DiaModalTlaSuffixComponent,
    DiaModalExaComponent,
    EditSliderChild,
    PopTemplateAllLevelsComponent,
    PopCaseAssociationComponent,
    PopCaseActivityComponent,
    PopMaslComponent,
    PopPersonComponent,
    PopCustomerRequestComponent,
    PopSuffixAllLevelsComponent,
    PopSuffixModdComponent,
    PopTrainingActvityRoleComponent,
    DialogMessageListComponent,
    DialogMessageListComponentTc,
    DialogMessageListComponentPrint,
    PopWcnAllLevelsComponent,
    PopLineAllLevelsComponent,
    PopCountryAllLevelComponent,
    PopTttsAllLevelsComponent,
    PopCaseAllLevelsComponent,
    PopNporComponent,
    CaseAmendModNumberComponent,
    CaseCountryComponent,
    CaseReserveComponent,
    MilestoneCommentComponent,
    RollupSublineComponent,
    TextAreaComponent,
    CivilianPersonnelComponent,
    PopGafsAccountLineComponent,
    PublicationsComponent,
    DTCComponent,
    MtdsComponent,
    ManpowerComponent,
    NoteDetailsComponent,
    AssoLinesComponent,
    PopCaseNoteComponent,
    ReplaceExpiredVersionComponent,
    AssignReferenceNotesComponent,
    PopCongNotificationComponent,
    PopCongMaslComponent,
    CaseAmendModRefreshComponent,
    PopCaseMilestoneComponent,
    ControlMilestoneComponent,
    PopCommonMilestoneComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    MdePopoverModule,
    FormsModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,  //NoopAnimationsModule Disable
    NgxMaskModule.forRoot(),
    TreeviewModule.forRoot(),
    ChartsModule,
    DragDropModule,
    AngularFontAwesomeModule,
    MatPaginatorModule, //DH
    MatSidenavModule, //DH
    MatProgressSpinnerModule, //DH
    MatSortModule, //DH
    MatListModule, //DH
    MatTooltipModule, //DH
    MatBadgeModule,
    MatMenuModule, 
    MatTabsModule,
    MatCardModule,
    MatDividerModule,
    MatTableModule,
    MatInputModule,
    MatButtonModule,
    MatDialogModule,
    MatSnackBarModule,
    MatCheckboxModule,
    MatRadioModule,
    MatSelectModule,
    MatDatepickerModule,
    MatNativeDateModule, 
    MatAutocompleteModule,
    MatStepperModule,
    MatIconModule,
    MatTreeModule,
    MatGridListModule,
    MatExpansionModule,
    MatSlideToggleModule,
    MatToolbarModule,
  ],
  providers: [
    CurrencyPipe,
    DatePipe,
    DsamsDeactivateService,
    BillingRestfulService, 
    CaseUIService,
    FundingUIService, 
    ReimbursementService,
    BillAmountsValidatorService,
    CaseRestfulService, 
    DsamsMethodsService,
    DsamsUserMessageService,
    CanDeactiveNotiticationService,
    ObjectService,
    AuthenticationService,
    ShareMethodsService,
    ThemeService,
    { provide: HTTP_INTERCEPTORS, useClass: HttpConfigInterceptor, multi: true },
    { provide: LocationStrategy, useClass: PathLocationStrategy}
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
