import { Component, OnInit, ViewEncapsulation, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { map, take } from 'rxjs/operators';
import { IBreadCrumb } from './breadcrumb';
import { Subscription } from 'rxjs';
import { CaseUIService } from '../dsams/case/services/case-ui-service';
import { DsamsShareService } from '../dsams/services/dsams-share.service';
import { LinkCaseDataClass } from '../dsams/case/model/link-case-data';

@Component({
  selector: 'app-breadcrumb',
  templateUrl: './breadcrumb.component.html',
  styleUrls: ['./breadcrumb.component.css'],
  encapsulation: ViewEncapsulation.None
})

export class BreadcrumbComponent implements OnInit, OnDestroy {
  breadcrumbs$: IBreadCrumb[];
  private _caseUIServiceSubscription: Subscription
  private _tmUIServiceSubscription: Subscription;
  private _defaultBreadcrumbTitle: string = "Case";
  private _caseBreadcrumbTitle: string = this._defaultBreadcrumbTitle;
  private _caseDetailsBCSubscription: Subscription = null;
  private _homeBreadcrumbTitle: string = "Home";
 
  constructor(private activatedRoute: ActivatedRoute,
    private router: Router, private caseUIService: CaseUIService, private dataSharingService: DsamsShareService) {
  }

  ngOnInit() {
    this.breadcrumbs$ = this.buildBreadCrumb(this.activatedRoute.root);
    this.router.events.pipe(
      map(event => this.buildBreadCrumb(this.activatedRoute.root))
    ).subscribe(bcArray => {
      this.breadcrumbs$ = bcArray;
    });
  
    // Subscribe to case UI services (mostly for breadcrumb changes)
    // This is for non-router events, so needs a separate service.
    this._caseUIServiceSubscription = this.caseUIService.breadcrumbTitleChangeRequest.subscribe(
      {
        next: (pNewBreadcrumbName: string) => {
          this._caseBreadcrumbTitle = pNewBreadcrumbName;
       
          if (pNewBreadcrumbName === 'Case Search Summary' || pNewBreadcrumbName === 'Case Detail Search' ||
            pNewBreadcrumbName === 'ICase Search Summary') {
              setTimeout(() => {
            let length: number = 2;
            if (pNewBreadcrumbName === 'Case Search Summary') {
              length = 3;
            }
            if (pNewBreadcrumbName === 'ICase Search Summary') {
              pNewBreadcrumbName = 'Case Search Summary';
            }
            this.breadcrumbs$[1].label = pNewBreadcrumbName;
            if (this.breadcrumbs$.length > length) {
              this.breadcrumbs$.splice(2, this.breadcrumbs$.length - 2);
            }
          },500)
          }

                  
          switch (pNewBreadcrumbName) {
            case 'Case Detail' :{
              let newBC = { label: 'Case Detail', url: '/caseSearchSummary/caseDetail/' };
            setTimeout(() => {
              this.breadcrumbs$.push(newBC);
            },500) 
            break;
            }
            case 'Customer Request':
            case 'Congressional Notification' : {
              this.breadcrumbs$.splice(2, this.breadcrumbs$.length - 2);
              this.breadcrumbs$[1].label = pNewBreadcrumbName;
              break; 
            }  
            case 'Remarks':
            case 'Line List':
            case 'Milestone List':  
            case 'Attachment List':
            case 'Note List': {
              this.breadcrumbs$.splice(2, this.breadcrumbs$.length - 2);
              let newBC1 = { label: pNewBreadcrumbName, url: pNewBreadcrumbName };
              this.breadcrumbs$.push(newBC1);
              this.breadcrumbs$[1].label = this.getCaseBC();
              break;
            }

          }
        }
      });

      this._tmUIServiceSubscription = this.dataSharingService.breadcrumbForFundingHome.subscribe(value => {
        if (value === 'funding') {
            this.breadcrumbs$.splice(1, 0, { label: 'Funding Home', url: value });
        } 
        if (value === 'billing') {
            this.breadcrumbs$.splice(1, 0, { label: 'Billing Home', url: value });
        } 
      });
  }
  
  // Destroy - remove subscriptions.
  ngOnDestroy(): void {
    this._caseUIServiceSubscription.unsubscribe();
    this._tmUIServiceSubscription.unsubscribe();
  }

  // Determine if a breadcrumb is of a case type 
  private _isCaseBreadcrumb(pBC: string): boolean {
    if (pBC === "Case" ||
      pBC === "Case Search Summary" ||
      pBC === "Case Version Summary" ||
      pBC === "Enter New Case") {
      return true;
    }
    return false;
  }

  // Print breadcrumbs to console for debugging purposes.
  printbreadCrumbs(breadcrumbs: Array<IBreadCrumb>) {
    breadcrumbs.forEach((element: IBreadCrumb) => {
      console.log(element.label + ", ");
    });
  }


  buildBreadCrumb(route: ActivatedRoute,
    url: string = '',
    breadcrumbs: Array<IBreadCrumb> = []): Array<IBreadCrumb> {
    let label: string;
    let path: string = '';
    // If no routeConfig is avalailable we are on the root path
    try {
      label = route.routeConfig ? route.routeConfig.data['breadcrumb'] : 'Home';
      path = route.routeConfig ? route.routeConfig.path : '';
    }
    catch (Error) {
      label = '';
      // Error is always route.routeConfig undefined. 
      // The ternary expression above doesn't catch it.
    }
    // In the routeConfig the complete path is not available,
    // so we rebuild it each time
    const nextUrl = `${url}${path}/`;

    const breadcrumb = {
      label: label,
      url: nextUrl,
    };
    const newBreadcrumbs = (breadcrumb.label === '') ? [...breadcrumbs] : [...breadcrumbs, breadcrumb];

    if (route.firstChild) {
      // If we are not on our current path yet,
      // there will be more children to look after, to build our breadcumb
      return this.buildBreadCrumb(route.firstChild, nextUrl, newBreadcrumbs);
    }
    return newBreadcrumbs;
  }

  bcClick(pIndex: number) {
    if (pIndex === 1 && (this.breadcrumbs$[pIndex].label === 'Case' ||
      this.breadcrumbs$[pIndex].label === 'Case Search Summary')) {
      this.dataSharingService.backToCaseDetail.next(false);
      this.dataSharingService.backToSearchSummary.next(true);

    }
  }

  getCaseBC(): string {
    let caseBC: string = '';
    this._caseDetailsBCSubscription = this.dataSharingService
      .caseDetailsBC
      .subscribe(value => {
        if (value) {
          caseBC = 'Case Detail Search';
        } else {
          caseBC = 'Case Search Summary';
        }
      });
    return caseBC;
  }

  //Jira DSAMS 5346 DH 04/22
  subscribeToBreadcrumbForNewPage() {
    if (!!this.dataSharingService.breadcrumbForNewPage) {
      this.dataSharingService.breadcrumbForNewPage.pipe(take(1)).subscribe(value => {
        if (value == LinkCaseDataClass.theLinkCaseData) {
         this.breadcrumbs$ = [{ label: this._homeBreadcrumbTitle , url: '/' }];
          this.dataSharingService.breadcrumbForNewPage.next(null);
        }
      })
    }
  }
}