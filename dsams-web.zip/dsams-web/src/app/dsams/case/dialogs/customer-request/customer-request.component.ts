import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material';
import { FormBuilder, FormGroup } from '@angular/forms';
import { DsamsMethodsService } from './../../../services/dsams-methods.service';
import { DsamsConstants } from './../../../dsams.constants'
import { CaseRestfulService } from './../../services/case-restful.service';


@Component({
  selector: 'app-customer-request',
  templateUrl: './customer-request.component.html',
  styleUrls: ['./customer-request.component.css']
})
export class CustomerRequestComponent implements OnInit {

  custRequestForm: FormGroup;

  constructor(private caseRestService: CaseRestfulService, 
              public dsamsMethodsService: DsamsMethodsService,
              private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.constructCustRequestForm();
    //this.getCustRequest();
  }

  constructCustRequestForm() {
    this.custRequestForm = this.formBuilder.group({
      custRequestId: this.formBuilder.control(''),
      custOrganizationId: this.formBuilder.control(''),
      custReqReferenceTx: this.formBuilder.control(''),
      custRequestDate: this.formBuilder.control(''),
      custActivityId: this.formBuilder.control(''),
    });
  }

    //Table: Filter'
    displayedColumns: string[] = ['customer_request_id','customer_organization_id','customer_request_reference_tx','customer_request_date','customer_activity_id'];
    dataSource = new MatTableDataSource();
    recordCount: number=0;
  
    //Get data from RWS
    getCustRequest(queryString: string) {
      this.caseRestService.getCustRequestData(queryString)
      .subscribe(
        data => { 
          this.dataSource.data = data; 
          if (data == null) 
              this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, DsamsConstants.EW20269);
          else { 
              this.recordCount = this.dataSource.filteredData.length;
              console.log("count=="+this.recordCount)
              if (this.recordCount == 1000)
                  this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, DsamsConstants.WW20888);
              else {
                  this.selectedRowIndex = data[0].customer_request_id;
                  this.customerRequestId = data[0].customer_request_id;
              }
          }
        },
        err => {
          console.log("Error occured: getCustRequestData()")
        }
      );
    }    
  
    applyFilter(filterValue: string) {
      this.dataSource.filter = filterValue.trim().toLowerCase();
    }  
  
    //Table: highlighter
    selectedRowIndex: string; 
    customerRequestId: string;
    
    highlight(row: any){
      this.selectedRowIndex = row.customer_request_id;
      this.customerRequestId = row.customer_request_id;
    }
  
    //Action button
    onFilter() {
      var queryString = "";
      if (this.custRequestForm.get("custRequestId").value != '')
          queryString = "CUSTOMER_REQUEST_ID like '"+this.custRequestForm.get("custRequestId").value.toUpperCase()+"'";
      if (this.custRequestForm.get("custOrganizationId").value != '')
          queryString = queryString + " and CUSTOMER_ORGANIZATION_ID like '"+this.custRequestForm.get("custOrganizationId").value.toUpperCase()+"'";
      if (this.custRequestForm.get("custReqReferenceTx").value !='')
          queryString = queryString + " and CUSTOMER_REQUEST_REFERENCE_TX like '"+this.custRequestForm.get("custReqReferenceTx").value.toUpperCase()+"'";
      if (this.custRequestForm.get("custRequestDate").value != '')
          queryString = queryString + " and TO_CHAR(CUSTOMER_REQUEST_DT) like '"+this.custRequestForm.get("custRequestDate").value.toUpperCase()+"'";
      if (this.custRequestForm.get("custActivityId").value != '')
          queryString = queryString + " and ACTIVITY_ID like '"+this.custRequestForm.get("custActivityId").value.toUpperCase()+"'";

      //console.log("queryString==="+queryString+ "encoded=="+encodeURIComponent(queryString));

      if (queryString == "")
          this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, DsamsConstants.EW20266);
      else {    
          this.getCustRequest(encodeURIComponent(queryString));
      }

    }


}
