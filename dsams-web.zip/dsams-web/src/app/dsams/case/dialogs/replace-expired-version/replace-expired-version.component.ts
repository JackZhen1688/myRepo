import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { SelectionModel } from '@angular/cdk/collections';
import { MatTableDataSource } from '@angular/material';
import { CaseRestfulService } from '../../services/case-restful.service';
import { CaseUIService } from '../../services/case-ui-service';
import { CaseNoteDto } from '../../model/dto/case-note-dto';
import { MatCheckboxChange } from '@angular/material';
import { CaseCommonValidator } from '../../validation/case-common-validator';

@Component({
  selector: 'app-replace-expired-version',
  templateUrl: './replace-expired-version.component.html',
  styleUrls: ['./replace-expired-version.component.css']
})
export class ReplaceExpiredVersionComponent implements OnInit {

  headerColumns: string[] = ['parent', 'noteNumber', 'noteId', 'noteVersionNumber', 'noteStatus', 'noteOfficialTitle'];
  rowColumns: string[] = ['child', 'noteNumber', 'noteId', 'noteVersionNumber', 'noteStatus', 'noteOfficialTitle'];
  selectionReplaceExpiredVersion = new SelectionModel<CaseNoteDto>(true, []);
  checkedNoteDtoList: CaseNoteDto[] = [];
  dataSourceReplaceExpiredVersion = new MatTableDataSource(this.checkedNoteDtoList);

  //Select all checkbox
  isIndeterminate: boolean = false;
  isChecked: boolean[] = [];
  inChecked: boolean = false;

  constructor(private caseRestService: CaseRestfulService,
    public dialogRef: MatDialogRef<ReplaceExpiredVersionComponent>,
    private caseUIService: CaseUIService,
    @Inject(MAT_DIALOG_DATA) public data: { noteList: CaseNoteDto[] }) { }

  ngOnInit(): void {
    this.dataSourceReplaceExpiredVersion = new MatTableDataSource(this.getTheNoteListData());
    this.dataSourceReplaceExpiredVersion._updateChangeSubscription();
  }

  getCheckedValues() {
    console.log('getCheckedValues=', this.dataSourceReplaceExpiredVersion.data);
    this.dataSourceReplaceExpiredVersion.data.forEach((row, index) => {
      if (this.isChecked[index]) {
        this.checkedNoteDtoList.push(row);
      }
    });
  }

  onIndeterminateChange(event: MatCheckboxChange) {
    if (event.checked) {
      this.inChecked = true;
      for (let x = 0; x < this.dataSourceReplaceExpiredVersion.data.length; x++) {
        this.isChecked[x] = true;
      }
    } else {
      this.inChecked = false;
      for (let m = 0; m < this.dataSourceReplaceExpiredVersion.data.length; m++) {
        this.isChecked[m] = false;
      }
    }
  }

  onChkBoxChange(event: MatCheckboxChange, index: number) {
    if (event.checked) {
      this.isChecked[index] = true;
      if (this.inChecked) {
        this.isIndeterminate = true;
      } else {
        this.isIndeterminate = false;
      }
    } else {
      this.isChecked[index] = false;
      if (this.inChecked) {
        this.isIndeterminate = true;
      } else {
        this.isIndeterminate = false;
      }
    }
  }

  private getTheNoteListData(): CaseNoteDto[] {
    console.log('this.data.noteList=', this.data.noteList);
    var theNoteListData: CaseNoteDto[] = [];
    this.data.noteList.forEach((eachCaseNote) => {
      if (CaseCommonValidator.isEqual(eachCaseNote.theNoteId.note_TYPE_CD, 'ST') ||
        CaseCommonValidator.isEqual(eachCaseNote.theNoteId.note_TYPE_CD, 'CT')) {
        theNoteListData.push(eachCaseNote);
      }
    });
    return theNoteListData;
  }

  XcloseDialog(): void {
    this.dialogRef.close();
  }

  saveDialog(): void {
    this.getCheckedValues();
    this.dialogRef.close(this.checkedNoteDtoList);
  }

  cancelDialog(): void {
    this.dialogRef.close();
  }

}