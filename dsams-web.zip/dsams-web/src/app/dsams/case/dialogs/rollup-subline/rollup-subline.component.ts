import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { SelectionModel } from '@angular/cdk/collections';
import { MatTableDataSource } from '@angular/material';
import { CaseRestfulService } from '../../services/case-restful.service';
import { CaseUIService } from '../../services/case-ui-service';
import { BehaviorSubject } from 'rxjs';
import { ErrorParameter } from '../../../entities/specialEntities/error-parameter.model';
import { CaseUtils } from '../../../case/utils/case-utils';
import { Router } from '@angular/router';
import swal from 'sweetalert2';

export interface LineRollupSubline {
    line_NUM: string;
    line_QUANTITY: number;
    masl_NUM: string;
    lineQuantity: number;
    line_CASE_ID: string;
    line_CASE_MASTER_LINE_ID: string;
    line_WORKING_CASE_ID: string;
    line_WORKING_CASE_VERSION_ID: string;
    line_MDESME: boolean;
    line_tttMDESME: string;
}

@Component({
    selector: 'app-rollup-subline',
    templateUrl: './rollup-subline.component.html',
    styleUrls: ['./rollup-subline.component.css']
})
export class RollupSublineComponent implements OnInit {

    displayedColumns: string[] = ['select','lineNum','lineQuantity','maslNum']; 
    dataSourceRollupSubline = new MatTableDataSource<LineRollupSubline>();
    dataSourceRollupSublineArray = new Array <LineRollupSubline>();
    selectionLineRollupSubline = new SelectionModel<LineRollupSubline>(true, []);
    recordCount: number=0;
    noDataFoundInd: boolean = false;
    rollupSublinesSuccess: boolean = false;
    tttMDESME: string = '';

    showSpinner: BehaviorSubject<boolean> = new BehaviorSubject(false);

    // The selected line(s) to be rolled up
    selRowLineNums: string;

    constructor(private caseRestService: CaseRestfulService,
        public dialogRef: MatDialogRef<RollupSublineComponent>,
        private router: Router,
        @Inject(MAT_DIALOG_DATA) public data: {caseId: number, versionId: number },
        private caseUIService: CaseUIService) { }

    ngOnInit(): void { 
        // Build list
        //console.log("Case Id: " + this.data.caseId);
        //console.log("Case Version Id: " + this.data.versionId);
        // Do List
        this.dataSourceRollupSubline.data = [];
        this.getDataForRollupList();
    }

    /** Whether the number of selected elements matches the total number of rows. */
    isAllSelected() {
        const numSelected = this.selectionLineRollupSubline.selected.length;
        const numRows = this.dataSourceRollupSubline.filteredData.length;
        return numSelected === numRows;
    }

    /** Selects all rows if they are not all selected; otherwise clear selection. */
    masterToggle() {
        this.isAllSelected() ?
        this.selectionLineRollupSubline.clear() :
        this.dataSourceRollupSubline.data.forEach(row => this.selectionLineRollupSubline.select(row));   
    }

    /** The label for the checkbox on the passed row */
    checkboxLabel(row?: LineRollupSubline): string {
        if (!row) {
        return `${this.isAllSelected() ? 'select' : 'deselect'} all`;
        }
        return `${this.selectionLineRollupSubline.isSelected(row) ? 'deselect' : 'select'} row ${row.line_NUM + 1}`;
    }

    onCheckboxChange($event) {
        this.selRowLineNums = this.getCheckedValues();
        //console.log("Selected lines: " + this.selRowLineNums);
        //this.dsamsMethodsService.selectedValuesFromPopup.next(this.getCheckedValues());
        // Setting the lines that were selected for rollup.
        sessionStorage.setItem('lineRollupSublineValues', this.selRowLineNums);
    }

    getCheckedValues() {
        let values: string;
        this.dataSourceRollupSubline.data.forEach(row => { 
            if (this.selectionLineRollupSubline.isSelected(row)) {
                if (values == null) 
                    values = row.line_NUM+","
                else
                    values = values+row.line_NUM+","
            }
          }
        )
        return values.slice(0,-1);
    }  

    onNoclick(): void {
        this.dialogRef.close();
    }

    XcloseDialog(): void {
        this.dialogRef.close();
    }

    completeDialog(): void {
        this.dialogRef.close();
    }

    //Table: highlighter
    selectedRowIndex: string; 
    lineNumId: string;

    highlight(row: any){
        this.selectedRowIndex = row.lineNum;
        this.lineNumId = row.lineNum;
    }

    saveDialog(): void {
        // Make call to rollup sublines
        this.dataSourceRollupSubline.data.forEach(row => { 
            if (this.selectionLineRollupSubline.isSelected(row)) {
                //console.log("Ok Button clicked this line was selected: " + row.line_NUM + 
                //" with " + row.lineQuantity + " quantity.");
                // Do the legacy rollup call
                let pCaseId: string;
                let pCaseMasterLineId: string;
                let pWorkingCaseId: string;
                let pWorkingCaseVersionId: string;
                let pQuantity: number;

                pCaseId = row.line_CASE_ID;
                pCaseMasterLineId = row.line_CASE_MASTER_LINE_ID;
                pWorkingCaseId = row.line_WORKING_CASE_ID;
                pWorkingCaseVersionId = row.line_WORKING_CASE_VERSION_ID;
                if (row.line_MDESME) {
                    pQuantity = row.lineQuantity;
                }
                else {
                    pQuantity = 0;
                }

                if (row.line_MDESME && (pQuantity == null || pQuantity.toString().replace(/\s/g,'') == '')) {
                    swal.fire({
                        text: 'Quantity is required for MDE Line.',
                        icon: 'error',
                        showConfirmButton: true,
                        width: 400,
                        focusConfirm: true,
                        confirmButtonText: 'OK'
                    })
                }
                else if (row.line_MDESME && pQuantity == 0) {
                    swal.fire({
                        text: 'Quantity greater than 0 is required for MDE Line.',
                        icon: 'error',
                        showConfirmButton: true,
                        width: 400,
                        focusConfirm: true,
                        confirmButtonText: 'OK'
                    })
                }
                else {
                    this.rollupSublines(pCaseId, pCaseMasterLineId, pWorkingCaseId, pWorkingCaseVersionId, pQuantity)
                }
            }
        });
        // no rows selected
        if (this.selectionLineRollupSubline.isEmpty()) {
            swal.fire({
                text: 'Select a line to rollup.',
                icon: 'error',
                showConfirmButton: true,
                width: 400,
                focusConfirm: true,
                confirmButtonText: 'OK'
            })
        }
    }

    cancelDialog(): void {
        this.dialogRef.close();
    }

    getDataForRollupList() {
        this.caseRestService.getCaseLineListFromServer(this.data.caseId,
            this.data.versionId)
            .subscribe(
            data => {
                let lineItem: LineRollupSubline;
                for (var i = 0; i <= data.caseLineList.length - 1; i++) {
                    // Only get lines with 'A' status and exclude lines without sublines
                    if (data.caseLineList[i].virtualSublineList != null && data.caseLineList[i].change_ACTION_CD === 'A') {
                        //console.log("Status code A, Line Num: " + data.caseLineList[i].wm_USER_CASE_LINE_NUMBER_ID);
                        //console.log("major_DEFENSE_EQUIPMENT_CD: " + data.caseLineList[i].major_DEFENSE_EQUIPMENT_CD);
                        var line_MDE = false;
                        this.tttMDESME = "Quantity only for MDE Lines";
                        if (data.caseLineList[i].major_DEFENSE_EQUIPMENT_CD.toUpperCase() === 'Y') {
                            line_MDE = true;
                            this.tttMDESME = '';
                            //console.log("Inside the Y condition.");
                        }
                        if (data.caseLineList[i].military_ARTICLE_SERVICE_CD != "N/A") {
                            this.dataSourceRollupSublineArray.push
                            ({line_NUM: data.caseLineList[i].wm_USER_CASE_LINE_NUMBER_ID, 
                                line_QUANTITY: 0, 
                                lineQuantity: null, 
                                masl_NUM: data.caseLineList[i].military_ARTICLE_SERVICE_CD, 
                                line_CASE_ID: data.caseLineList[i].case_ID, 
                                line_CASE_MASTER_LINE_ID: data.caseLineList[i].case_MASTER_LINE_ID, 
                                line_WORKING_CASE_ID: data.caseLineList[i].working_CASE_ID, 
                                line_WORKING_CASE_VERSION_ID: data.caseLineList[i].working_CASE_VERSION_ID,
                                line_tttMDESME: this.tttMDESME,
                                line_MDESME: line_MDE});
                        }
                    }
                }
                this.recordCount = this.dataSourceRollupSublineArray.length;
                //console.log("data: " + JSON.stringify(data));
                this.dataSourceRollupSubline.data = this.dataSourceRollupSublineArray;
                this.noDataFoundInd = (this.recordCount == 0);
            })
    }

    /* Rollup Sublines */
    private rollupSublines(pCaseId: string, pCaseMasterLineId: string, pWorkingCaseId: string, pWorkingCaseVersionId: string, pQuantity: number) {
        // Show the spinner
        this.showSpinner.next(true);
        this.caseRestService
        .rollupSublines(pCaseId, pCaseMasterLineId, pWorkingCaseId, pWorkingCaseVersionId, pQuantity)
        .subscribe((pMessageList: Array<ErrorParameter>) => {
            // console.log("Message List:");
            // console.log(pMessageList);      
            // Legacy call was successful, remove the spinner        
            this.showSpinner.next(false);
            // Success message - Not being used
            //this.rollupSublinesSuccess = true;
            // Success message in popup
            this.successDialog();
            // Refresh the line list
            this.router.navigateByUrl('/case/line-dashboard/0/line');
            // Close the dialog box
            this.dialogRef.close();
            // This is to refresh the rollup list if the dialog box did not close.
            //this.dataSourceRollupSublineArray = [];
            //this.getDataForRollupList();
        },
            err => {
            CaseUtils.ReportHTTPError(err, "Error Rollup Sublines");
            this.showSpinner.next(false);
            }
        );
    }

    successDialog() {
        swal.fire({
            title: "Rollup was Successful",
            icon: 'success',
            showCancelButton: false,
            cancelButtonText: 'No',
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'OK'
        });
    }
}