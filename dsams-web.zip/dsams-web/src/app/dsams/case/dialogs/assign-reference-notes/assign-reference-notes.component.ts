import { Component, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

@Component({
  selector: 'app-assign-reference-notes',
  templateUrl: './assign-reference-notes.component.html',
  styleUrls: ['./assign-reference-notes.component.css']
})
export class AssignReferenceNotesComponent {

  constructor(public dialogRef: MatDialogRef<AssignReferenceNotesComponent>,
    @Inject(MAT_DIALOG_DATA) public data: { value: string }) { }
 
  saveDialog() {
    this.dialogRef.close(this.data.value);
  }

  cancelDialog() {
    this.dialogRef.close();
  }


}
