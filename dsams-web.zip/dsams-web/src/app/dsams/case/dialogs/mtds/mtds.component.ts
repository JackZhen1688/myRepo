import { Component, Inject, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { MatDialogRef, MatTableDataSource, MAT_DIALOG_DATA, MatSort } from '@angular/material';
import { CurrencyPipe, formatDate } from '@angular/common';
import { Subscription } from 'rxjs';
import { caseLineComponentDto, caseLineComponentForCivilianPopup } from '../../model/dto/case-line-component-dto';
import { mtdsPersonnelDto } from '../../model/dto/mtds-personnel-dto';
import { mtdsPersonnelSupportCostsDto } from '../../model/dto/mtds-personnel-support-costs-dto';
import { mtdsTravelDto } from '../../model/dto/mtds-travel-dto';
import { FieldDisabledMap } from '../../model/field-disabled-map';
import { CaseLineIPCDto } from "../../line-dashboard/line-pricing/ipc-tab-dashboard/model/dto/case-line-ipc-dto";
import { CaseUIService } from '../../services/case-ui-service';
import { ICaseLinePricing } from '../../model/dto/icase-line-pricing';
import { IEditResponseType } from 'src/app/dsams/case/model/edit-response-type';
import { DsamsConstants } from 'src/app/dsams/dsams.constants';
import { ReferenceDataType } from 'src/app/dsams/case/model/reference-data-type';
import { CaseRestfulService } from 'src/app/dsams/case/services/case-restful.service';
import { CaseUtils } from 'src/app/dsams/case/utils/case-utils';
import { ISelectOptions } from 'src/app/dsams/interfaces/i-select-options';
import { ManpowerComponent } from 'src/app/dsams/case/dialogs/manpower/manpower.component';
import { MatDialog } from '@angular/material/dialog';
import { LinePricingUtils } from '../../line-dashboard/line-pricing-utils';
import { DsamsUserMessageService } from 'src/app/dsams/services/dsams-user-message.service';


export interface dropdownArray {
  pCode: string,
  pDesc: string
}

@Component({
  selector: 'app-mtds',
  templateUrl: './mtds.component.html',
  styleUrls: ['./mtds.component.css'],
  providers: [CurrencyPipe]
})
export class MtdsComponent implements OnInit, OnDestroy {

  /* Personnel */
  personnelColumns = [
    'personnelPositionNm',
    'personnelGradeRankNm',
    'mtdsPersonOrganTx',
    'mtdsPersonWorkYearsQy',
    'mtdsPersonWorkYearsTx',
    'mtdsPersonBaseCostAm',
    'mtdsPersonTotalCostAm',
    'mtdsManpowerMatrixTx',
    'flyout1',
    'DeleteRow'
  ]
  personnelColumnsFooter = ['AddRow'];
  personnelDataList: mtdsPersonnelDto[] = [{
    personnel_POSITION_NM: null,
    personnel_GRADE_RANK_NM: null,
    mtds_PERSON_ORGAN_TX: null,
    mtds_PERSON_WORK_YEARS_QY: null,
    mtds_PERSON_WORK_YEARS_TX: null,
    mtds_PERSON_BASE_COST_AM: null,
    mtds_PERSON_TOTAL_COST_AM: null,
    mtds_MANPOWER_MATRIX_TX: null,
    mtds_MANPOWER_MATRIX_TX_USER_FORMAT: null
  }];
  
  personnelDataSource: MatTableDataSource<mtdsPersonnelDto>;

  /* Travel */
  travelColumns = [
    'mtdsTravelPurposeTx',
    'fiscalYearId',
    'mtdsTravelSiteTx',
    'mtdsTravelNumberQy',
    'mtdsTravelDurationQy',
    'mtdsTravelDurationUnitCd',
    'mtdsTravelNumberPersonQy',
    'mtdsTravelTotalCostAm',
    'mtdsManpowerMatrixCd',
    'flyout2',
    'DeleteRow'
  ];
  travelColumnsFooter = ['AddRow'];
  travelDataList: mtdsTravelDto[] = [{
    mtds_TRAVEL_PURPOSE_TX: null,
    fiscal_YEAR_ID: null,
    mtds_TRAVEL_SITE_TX: null,
    mtds_TRAVEL_NUMBER_QY: null,
    mtds_TRAVEL_DURATION_QY: null,
    mtds_TRAVEL_DURATION_UNIT_CD: null,
    mtds_TRAVEL_NUMBER_PERSON_QY: null,
    mtds_TRAVEL_TOTAL_COST_AM: null,
    mtds_MANPOWER_MATRIX_CD: null,
    mtds_MANPOWER_MATRIX_CD_USER_FORMAT: null
  }];

  travelDataSource: MatTableDataSource<mtdsTravelDto>

  travelSiteList: ISelectOptions[] = [
    { value: 'C', viewValue: 'CONUS' },
    { value: 'I', viewValue: 'In Country' }
  ];
  travelDurationUnitList: ISelectOptions[] = [
    { value: 'D', viewValue: 'Days' },
    { value: 'W', viewValue: 'Weeks' },
    { value: 'M', viewValue: 'Months' },
  ];

  /* Personnel Support Costs */
  personnelSupportCostsColumns = [
    'mtdsSupportTypeTx',
    'mtdsSupportTotalCostAm',
    'mtdsSupportMatrixCd',
    'flyout3',
    'DeleteRow'
  ];
  personnelSupportCostsColumnsFooter = ['AddRow'];
  personnelSupportCostsDataList: mtdsPersonnelSupportCostsDto[] = [{
    mtds_SUPPORT_TYPE_TX: null,
    mtds_SUPPORT_TOTAL_COST_AM: null,
    mtds_SUPPORT_MATRIX_CD: null,
    mtds_SUPPORT_MATRIX_CD_USER_FORMAT: null,
    mtds_SUPPRT_ORGAN_TX: null
  }];
  personnelSupportCostsDataSource: MatTableDataSource<mtdsPersonnelSupportCostsDto>;

  mtdsPersonTotalBaseSumString: string = 'N/A';
  mtdsPersonTotalCostSumString: string = 'N/A';
  sumPersonnelCostIPCs: number;

  mtdsTravelTotalCostSumString: string = 'N/A';

  mtdsSupportTotalCostSumString: string = 'N/A';

  isMTDSPanelEditable: boolean = false;
  private _fieldDisabledMap: FieldDisabledMap = {};

  // Storage for personnel total cost
  ipcDataList: CaseLineIPCDto [];

  // Line / Subline No.
  lineSublineNo: string = 'N/A';

  // Primary Category
  primaryCategory: string = 'N/A';

  // Duration From
  durationFrom: string = 'N/A';

  // Duration To
  durationTo: string = 'N/A';

  // Stores the case line details for the popup.
  caseLineComponentInfo: caseLineComponentDto;
  clcIndex: number;
  private editSubscription: Subscription = null;

  // Reference Lists
  refManpowerMatrixList: Array<ReferenceDataType> = [];
  refManpowerMatrixListNoInactive: Array<ReferenceDataType> = [];
  refPersonnelGradeRankList: Array<ReferenceDataType> = [];
  refPersonnelPositionList: Array<ReferenceDataType> = [];
  refTravelFiscalYearList: Array<ReferenceDataType> = [];

  // Using for Sonarqube
  newPersonnelDataList: mtdsPersonnelDto[];
  newCLCMtdsPersonList: mtdsPersonnelDto[];
  newPersonnelDataSource: MatTableDataSource<mtdsPersonnelSupportCostsDto>;
  newTravelDataList: mtdsTravelDto[];
  newCLCMtdsTravelList: mtdsTravelDto[];
  newTravelDataSource: MatTableDataSource<mtdsTravelDto>;
  newPersonnelSupportCostsDataList: mtdsPersonnelSupportCostsDto[];
  newCLCMtdsSupportList: mtdsPersonnelSupportCostsDto[];
  newPersonnelSupportCostsDataSource: MatTableDataSource<mtdsPersonnelSupportCostsDto>;

  @ViewChild(MatSort, {static: true}) sort: MatSort;
  
  constructor(
    public dialogRef: MatDialogRef<MtdsComponent>,
    @Inject(MAT_DIALOG_DATA) public data: { caseLineData: any,
                                            caseVersionData: any,
                                            caseLinePricingSummaryForPopup: ICaseLinePricing, 
                                            clcElementForCivilianPersonnelForPopup: caseLineComponentForCivilianPopup, 
                                            indexForElement: number, clcElementData: any },
    public dialog: MatDialog,
    private currencyPipe: CurrencyPipe,
    private caseUIService: CaseUIService,
    private caseRestService: CaseRestfulService,
    private messageService: DsamsUserMessageService
  ) { }

  ngOnInit() {
    this.caseLineComponentInfo = this.data.clcElementData;   
    // Reference lists
    this.getReferenceDataLists();
    // Get Data for MTDS Tables
    this.getDataForMTDS();
    this.subscribeToEditService();
    setTimeout(() => {
      this.formatManpowerMatrix();
    }, 1200);
  }

  ngOnDestroy() {
    if (!!this.editSubscription) {
      this.editSubscription.unsubscribe();
    }
  }

  // Determine if a field is disabled.
  isFieldDisabled(pElement: any, pFieldName: string): boolean {
    // Is whole panel disabled?
    // if (!this.isPanelEditable) {
    //   return true;
    // }
    if (!!pElement && pElement.isDisabled) {
      return true;
    }
    return this._fieldDisabledMap[pFieldName];
  }

  addNewPersonnelItem() {
    var mtdsPersonnelItemObject: mtdsPersonnelDto =
    {
      wm_status: '',
      isDisabled: false,   // Is row enabled?

      personnel_POSITION_NM: null,
      personnel_GRADE_RANK_NM: null,
      mtds_PERSON_ORGAN_TX: null,
      mtds_PERSON_WORK_YEARS_QY: null,
      mtds_PERSON_WORK_YEARS_TX: null,
      mtds_MANPOWER_MATRIX_TX: null,
      mtds_MANPOWER_MATRIX_TX_USER_FORMAT: null,
      mtds_PERSON_BASE_COST_AM: 0,
      mtds_PERSON_BASE_COST_AM_String: this.currencyPipe.transform(0, 'USD', 'symbol-narrow', '3.2-5', 'en-US'),
      mtds_PERSON_TOTAL_COST_AM: 0,
      mtds_PERSON_TOTAL_COST_AM_String: this.currencyPipe.transform(0, 'USD', 'symbol-narrow', '3.2-5', 'en-US'),
      wm_MTDS_PERSON_BASE_COST_AM_SUM: '',
      wm_TOTAL_COST: '',
      entityName: 'CASE_LINE_COMP_MTDS_PERSON',
      tempStatus: true
    }
    // for new entity
    /*
    if (this.caseLineInfoData.caseLineDeliveryItemList == null) {
      this.caseLineInfoData.caseLineDeliveryItemList = []
    }*/
    //this.caseLineInfoData.caseLineDeliveryItemList.push(mtdsPersonnelItemObject);
    this.personnelDataSource.data.push(mtdsPersonnelItemObject);
    this.personnelDataSource = new MatTableDataSource(this.personnelDataSource.data);
    this.personnelDataSource._updateChangeSubscription();
    //this.caseLineInfoData.isDataChanged = true;
  }

  addNewTravelItem() {
    var mtdsTravelItemObject: mtdsTravelDto =
    {
      wm_status: '',
      isDisabled: false,   // Is row enabled?

      mtds_TRAVEL_PURPOSE_TX: null,
      fiscal_YEAR_ID: null,
      mtds_TRAVEL_SITE_TX: null,
      mtds_TRAVEL_NUMBER_QY: null,
      mtds_TRAVEL_DURATION_QY: null,
      mtds_TRAVEL_DURATION_UNIT_CD: null,
      mtds_TRAVEL_NUMBER_PERSON_QY: null,
      mtds_TRAVEL_TOTAL_COST_AM: 0,
      mtds_TRAVEL_TOTAL_COST_AM_String: this.currencyPipe.transform(0, 'USD', 'symbol-narrow', '3.2-8', 'en-US'),
      mtds_MANPOWER_MATRIX_CD: null,      
      wm_MTDS_TRAVEL_TOTAL_COST_AM: '',
      entityName: 'CASE_LINE_COMP_MTDS_TRAVEL',
      tempStatus: true
    }
    // for new entity
    /*
    if (this.caseLineInfoData.caseLineDeliveryItemList == null) {
      this.caseLineInfoData.caseLineDeliveryItemList = []
    }*/
    //this.caseLineInfoData.caseLineDeliveryItemList.push(mtdsPersonnelItemObject);
    this.travelDataSource.data.push(mtdsTravelItemObject);
    this.travelDataSource = new MatTableDataSource(this.travelDataSource.data);
    this.travelDataSource._updateChangeSubscription();
    //this.caseLineInfoData.isDataChanged = true;
  }

  addNewPersonnelSupportItem() {
    var mtdsPersonnelSupportItemObject: mtdsPersonnelSupportCostsDto =
    {
      wm_status: '',
      isDisabled: false,   // Is row enabled?
      mtds_SUPPORT_TYPE_TX: null,
      mtds_SUPPORT_MATRIX_CD: null,
      mtds_SUPPRT_ORGAN_TX: null,
      mtds_SUPPORT_TOTAL_COST_AM: 0,
      mtds_SUPPORT_TOTAL_COST_AM_String:  this.currencyPipe.transform(0, 'USD', 'symbol-narrow', '3.2-8', 'en-US'),
      wm_MTDS_SUPPORT_TOTAL_COST_AM: '',
      entityName: 'CASE_LINE_COMP_MTDS_SUPPRT',
      tempStatus: true
    }
    // for new entity
    /*
    if (this.caseLineInfoData.caseLineDeliveryItemList == null) {
      this.caseLineInfoData.caseLineDeliveryItemList = []
    }*/
    //this.caseLineInfoData.caseLineDeliveryItemList.push(mtdsPersonnelItemObject);
    this.personnelSupportCostsDataSource.data.push(mtdsPersonnelSupportItemObject);
    this.personnelSupportCostsDataSource = new MatTableDataSource(this.personnelSupportCostsDataSource.data);
    this.personnelSupportCostsDataSource._updateChangeSubscription();
    //this.caseLineInfoData.isDataChanged = true;
  }

  delPersonnelRow(rowElement: any) {
    let rowIndex = this.personnelDataSource.data.indexOf(rowElement);
    if (!this.caseLineComponentInfo.deletedCaseLineCompMtdsPersonList) {
      this.caseLineComponentInfo.deletedCaseLineCompMtdsPersonList = [];
    }
    this.caseLineComponentInfo.deletedCaseLineCompMtdsPersonList.push(this.personnelDataSource.data[rowIndex]);     
    this.personnelDataSource.data.splice(rowIndex, 1);
    this.personnelDataSource = new MatTableDataSource(this.personnelDataSource.data);
    this.calcPersonMtdsTotal();
    this.setChangedClc();
  }

  /* This procedure checks the returned result value from the 
     popover Yes/No dialog window. */
    yesButtonPersonnelDeleteOnClick(isDeleteConfirmed: any, rowElement: any) {
      if (isDeleteConfirmed)
        this.delPersonnelRow(rowElement);
  }

  delTravelRow(rowElement: any) {
    let rowIndex = this.travelDataSource.data.indexOf(rowElement);
    if (!this.caseLineComponentInfo.deletedCaseLineCompMtdsTravelList) {
      this.caseLineComponentInfo.deletedCaseLineCompMtdsTravelList = [];
    }
    this.caseLineComponentInfo.deletedCaseLineCompMtdsTravelList.push(this.travelDataSource.data[rowIndex]);    
    this.travelDataSource.data.splice(rowIndex, 1);
    this.travelDataSource = new MatTableDataSource(this.travelDataSource.data);
        
    this.calcTravelMtdsTotal();
    this.setChangedClc();    
  }

  /* This procedure checks the returned result value from the 
     popover Yes/No dialog window. */
    yesButtonTravelDeleteOnClick(isDeleteConfirmed: any, rowElement: any) {
      if (isDeleteConfirmed)
        this.delTravelRow(rowElement);
  }

  delPersonnelSupportRow(rowElement: any) {
    let rowIndex = this.personnelSupportCostsDataSource.data.indexOf(rowElement);
    if (!this.caseLineComponentInfo.deletedCaseLineCompMtdsSupportList) {
      this.caseLineComponentInfo.deletedCaseLineCompMtdsSupportList = [];
    }
    this.caseLineComponentInfo.deletedCaseLineCompMtdsSupportList.push(this.personnelSupportCostsDataSource.data[rowIndex]);       
    this.personnelSupportCostsDataSource.data.splice(rowIndex, 1);
    this.personnelSupportCostsDataSource = new MatTableDataSource(this.personnelSupportCostsDataSource.data);
    
    this.calcSupportMtdsTotal();
    this.setChangedClc();   
  }

  /* This procedure checks the returned result value from the 
     popover Yes/No dialog window. */
    yesButtonPersonnelSupportDeleteOnClick(isDeleteConfirmed: any, rowElement: any) {
      if (isDeleteConfirmed)
        this.delPersonnelSupportRow(rowElement);
  }

  saveDialog(): void {
    if (LinePricingUtils.validateMtds(this.caseLineComponentInfo, this.messageService)) {
      this.caseUIService.mtdsInfoChosen.next(this.caseLineComponentInfo);
      if (this.personnelDataList != null) {
        for (let i = 0; i < this.personnelDataList.length; i++) {
          this.personnelDataList[i].tempStatus = false;
        }
      }
      if (this.travelDataList != null) {
        for (let i = 0; i < this.travelDataList.length; i++) {
          this.travelDataList[i].tempStatus = false;
        }
      }
      if (this.personnelSupportCostsDataList != null) {
        for (let i = 0; i < this.personnelSupportCostsDataList.length; i++) {
          this.personnelSupportCostsDataList[i].tempStatus = false;
        }
      }
      this.dialogRef.close();  
    }
  }

  cancelDialog(): void {
    // Resetting the three datastores.
    // For example if the user add/delete mtds personnel and clicks cancel.
    // It should revert to what is in the database.
    if (this.personnelDataList != null) {
      for (let i = 0; i < this.personnelDataList.length; i++) {
        if (this.personnelDataList[i].tempStatus === true) {
          this.newPersonnelDataList = this.personnelDataList.splice(i, 1);
          this.newCLCMtdsPersonList = this.caseLineComponentInfo.caseLineCompMtdsPersonList.splice(i, 1);
          if (this.personnelDataSource.data != null && this.personnelDataSource.data != undefined) {
            this.personnelDataSource.data = this.personnelDataSource.data.splice(i, 1);
            this.newPersonnelDataSource = this.personnelDataSource;
          }
          this.personnelDataSource = new MatTableDataSource(this.personnelDataSource.data);
        }
      }
    }
    if (this.travelDataList != null) {
      for (let i = 0; i < this.travelDataList.length; i++) {
        if (this.travelDataList[i].tempStatus === true) {
          this.newTravelDataList = this.travelDataList.splice(i, 1);
          this.newCLCMtdsTravelList = this.caseLineComponentInfo.caseLineCompMtdsTravelList.splice(i, 1);
          if (this.travelDataSource.data != null && this.travelDataSource.data != undefined) {
            this.travelDataSource.data = this.travelDataSource.data.splice(i, 1);
            this.newTravelDataSource = this.travelDataSource;
          }
          this.travelDataSource = new MatTableDataSource(this.travelDataSource.data);
        }
      }
    }
    if (this.personnelSupportCostsDataList != null) {
      for (let i = 0; i < this.personnelSupportCostsDataList.length; i++) {
        if (this.personnelSupportCostsDataList[i].tempStatus === true) {
          this.newPersonnelSupportCostsDataList = this.personnelSupportCostsDataList.splice(i, 1);
          this.newCLCMtdsSupportList = this.caseLineComponentInfo.caseLineCompMtdsSupprtList.splice(i, 1);
          if (this.personnelSupportCostsDataSource.data != null && this.personnelSupportCostsDataSource.data != undefined) {
            this.personnelSupportCostsDataSource.data = this.personnelSupportCostsDataSource.data.splice(i, 1);
            this.newPersonnelSupportCostsDataSource = this.personnelSupportCostsDataSource;
          }
          this.personnelSupportCostsDataSource = new MatTableDataSource(this.personnelSupportCostsDataSource.data);
        }
      }
    }
    
    this.dialogRef.close();
  }

  getDataForMTDS() {
    // this.personnelDataList = this.data.clcElementData.caseLineCompMtdsPersonList;
    // this.travelDataList = this.data.clcElementData.caseLineCompMtdsTravelList;
    // this.personnelSupportCostsDataList = this.data.clcElementData.caseLineCompMtdsSupprtList;
    // this.ipcDataList = this.data.clcElementData.caseLineIpcList;    
    if (!this.caseLineComponentInfo.caseLineCompMtdsPersonList) {
      this.caseLineComponentInfo.caseLineCompMtdsPersonList = [];
    }
    if (!this.caseLineComponentInfo.caseLineCompMtdsTravelList) {
      this.caseLineComponentInfo.caseLineCompMtdsTravelList = [];
    }
    if (!this.caseLineComponentInfo.caseLineCompMtdsSupprtList) {
      this.caseLineComponentInfo.caseLineCompMtdsSupprtList = [];
    }
    if (!this.caseLineComponentInfo.caseLineIpcList) {
       this.caseLineComponentInfo.caseLineIpcList = [];
    }    
    this.personnelDataList = this.caseLineComponentInfo.caseLineCompMtdsPersonList;
    this.travelDataList = this.caseLineComponentInfo.caseLineCompMtdsTravelList;
    this.personnelSupportCostsDataList = this.caseLineComponentInfo.caseLineCompMtdsSupprtList;
    this.ipcDataList = this.caseLineComponentInfo.caseLineIpcList;

    // Set the Line / Subline No.
    if (this.data.caseLinePricingSummaryForPopup.theCaseMasterLineId.user_CASE_SUBLINE_TX == null) {
      this.lineSublineNo = this.data.caseLinePricingSummaryForPopup.theCaseMasterLineId.user_CASE_LINE_NUMBER_ID;
    }
    else {
      this.lineSublineNo = this.data.caseLinePricingSummaryForPopup.theCaseMasterLineId.user_CASE_LINE_NUMBER_ID + 
        this.data.caseLinePricingSummaryForPopup.theCaseMasterLineId.user_CASE_SUBLINE_TX;
    }

    // Set the Primary Category
    if (this.data.clcElementData.primary_CATEGORY_CD != null) {
      this.primaryCategory = this.data.clcElementData.primary_CATEGORY_CD;
    }

    this.sumPersonnelCostIPCs = 0;

    // Loop through IPCS to get sumPersonnelCostIPCs
    if (this.ipcDataList != null) {
      for (let i = 0; i < this.ipcDataList.length; i++) {
        if ((this.ipcDataList[i].ipc_NUMBER_ID === 'A0400' && (this.ipcDataList[i].case_LINE_IPC_STATUS_CD != 'NA')) || 
        (this.ipcDataList[i].ipc_NUMBER_ID === 'A0420' && (this.ipcDataList[i].case_LINE_IPC_STATUS_CD != 'NA')) || 
        (this.ipcDataList[i].ipc_NUMBER_ID === 'A0430' && (this.ipcDataList[i].case_LINE_IPC_STATUS_CD != 'NA')) || 
        (this.ipcDataList[i].ipc_NUMBER_ID === 'A0460' && (this.ipcDataList[i].case_LINE_IPC_STATUS_CD != 'NA')) || 
        (this.ipcDataList[i].ipc_NUMBER_ID === 'A0470' && (this.ipcDataList[i].case_LINE_IPC_STATUS_CD != 'NA')) || 
        (this.ipcDataList[i].ipc_NUMBER_ID === 'A0480' && (this.ipcDataList[i].case_LINE_IPC_STATUS_CD != 'NA')) || 
        (this.ipcDataList[i].ipc_NUMBER_ID === 'A0490' && (this.ipcDataList[i].case_LINE_IPC_STATUS_CD != 'NA')))
          {
            if (this.ipcDataList[i].case_LINE_IPC_UNIT_COST_AM > 0) {
              this.sumPersonnelCostIPCs = this.sumPersonnelCostIPCs + this.ipcDataList[i].case_LINE_IPC_UNIT_COST_AM;
            }
          }
      }
    }

    this.calcPersonMtdsTotal();
    
    //Set the Duration From and To values
    let theDay: number = 0;
    
    if (this.data.caseLineData.estimated_DELIVERY_DT != null) {
      //this.durationFrom = this.data.caseLineData.estimated_DELIVERY_DT;
      this.durationFrom = formatDate(this.data.caseLineData.estimated_DELIVERY_DT, 'MM-dd-yyyy', 'en-US');
    }
    else if (this.data.caseVersionData.offer_EXPIRATION_DT != null && 
             this.data.caseLineData.case_LINE_PERIOD_START_QY != null && 
             this.data.caseLineData.case_LINE_PERIOD_START_QY > 0) {
      let workDate: Date = new Date(this.data.caseVersionData.offer_EXPIRATION_DT);
      theDay = this.data.caseLineData.case_LINE_PERIOD_START_QY;
      workDate.setDate( workDate.getDate() - theDay);
      this.durationFrom = formatDate(workDate, 'MM-dd-yyyy', 'en-US');
    }
    
    if (this.data.caseLineData.estimated_DELIVERY_END_DT != null) {
      //this.durationTo = this.data.caseLineData.estimated_DELIVERY_END_DT;
      this.durationTo = formatDate(this.data.caseLineData.estimated_DELIVERY_END_DT, 'MM-dd-yyyy', 'en-US');
    }
    else if (this.data.caseVersionData.offer_EXPIRATION_DT != null && 
             this.data.caseLineData.case_LINE_PERIOD_END_QY != null && 
             this.data.caseLineData.case_LINE_PERIOD_END_QY > 0) {
      let workDate: Date = new Date(this.data.caseVersionData.offer_EXPIRATION_DT);
      theDay = this.data.caseLineData.case_LINE_PERIOD_END_QY;
      workDate.setDate( workDate.getDate() + theDay);
      this.durationTo = formatDate(workDate, 'MM-dd-yyyy', 'en-US');
    }

    this.calcTravelMtdsTotal();

    this.calcSupportMtdsTotal();

    this.personnelDataSource = new MatTableDataSource<mtdsPersonnelDto>(this.personnelDataList);
    this.travelDataSource = new MatTableDataSource<mtdsTravelDto>(this.travelDataList);
    this.personnelSupportCostsDataSource = new MatTableDataSource<mtdsPersonnelSupportCostsDto>(this.personnelSupportCostsDataList);
    this.setPersonMtdsRankAndPosition();    
  }

  // Subscribe to edit service
  private subscribeToEditService() {
    this.editSubscription = this.caseUIService.caseEditService.subscribe((pEditResult: IEditResponseType) => {
    if (!!pEditResult && pEditResult.ID === DsamsConstants.CASE_LINE_EDITOR) {
        this.isMTDSPanelEditable = pEditResult.editToggle;
    }
    });
  }

  // Calculate MTDS Person Amounts
  private calcPersonMtdsTotal() {
    let mtdsPersonTotalBaseSum:number = 0;
    let mtdsPersonTotalCostSum:number = 0;
    // Get sum of personnel costs
    if (this.personnelDataList != null) {
      for (let i = 0; i < this.personnelDataList.length; i++) {
        mtdsPersonTotalBaseSum = mtdsPersonTotalBaseSum + this.personnelDataList[i].mtds_PERSON_BASE_COST_AM;
      }
    }
    //Set Total cost & the currency strings for MTDS Personnel
    if (this.personnelDataList != null) {
      for (let i = 0; i < this.personnelDataList.length; i++) {
        if (this.personnelDataList[i].mtds_PERSON_BASE_COST_AM != null && this.personnelDataList[i].mtds_PERSON_BASE_COST_AM != 0) {
          this.personnelDataList[i].mtds_PERSON_TOTAL_COST_AM = this.personnelDataList[i].mtds_PERSON_BASE_COST_AM + (this.personnelDataList[i].mtds_PERSON_BASE_COST_AM / mtdsPersonTotalBaseSum * this.sumPersonnelCostIPCs);
          this.personnelDataList[i].mtds_PERSON_TOTAL_COST_AM_String = this.currencyPipe.transform(this.personnelDataList[i].mtds_PERSON_TOTAL_COST_AM, 'USD', 'symbol-narrow', '3.2-5', 'en-US');
          this.personnelDataList[i].mtds_PERSON_BASE_COST_AM_String = this.currencyPipe.transform(this.personnelDataList[i].mtds_PERSON_BASE_COST_AM, 'USD', 'symbol-narrow', '3.2-2', 'en-US');
          mtdsPersonTotalCostSum = mtdsPersonTotalCostSum + this.personnelDataList[i].mtds_PERSON_TOTAL_COST_AM;
        }
      }
    }
    this.mtdsPersonTotalBaseSumString = this.currencyPipe.transform(mtdsPersonTotalBaseSum, 'USD', 'symbol-narrow', '3.2-2', 'en-US');
    this.mtdsPersonTotalCostSumString = this.currencyPipe.transform(mtdsPersonTotalCostSum, 'USD', 'symbol-narrow', '3.2-5', 'en-US');
    this.caseLineComponentInfo.caseLineCompMtdsPersonTotalAm = mtdsPersonTotalCostSum;
  }

  private calcTravelMtdsTotal() {
    let mtdsTravelTotalCostSum:number = 0;
    //Set Total cost & the currency strings for MTDS Travel
      if (this.travelDataList != null) {
        for (let i = 0; i < this.travelDataList.length; i++) {
          this.travelDataList[i].mtds_TRAVEL_TOTAL_COST_AM_String = 
            this.currencyPipe.transform(this.travelDataList[i].mtds_TRAVEL_TOTAL_COST_AM, 'USD', 'symbol-narrow', '3.2-8', 'en-US');
          
          mtdsTravelTotalCostSum = mtdsTravelTotalCostSum + this.travelDataList[i].mtds_TRAVEL_TOTAL_COST_AM;
        }
      }
      this.mtdsTravelTotalCostSumString = this.currencyPipe.transform(mtdsTravelTotalCostSum, 'USD', 'symbol-narrow', '3.2-8', 'en-US');
      this.caseLineComponentInfo.caseLineCompMtdsTravelTotalAm = mtdsTravelTotalCostSum;
  }


  private calcSupportMtdsTotal() {
    let mtdsSupportTotalCostSum:number = 0;
    //Set Total cost & the currency strings for MTDS Support
    if (this.personnelSupportCostsDataList != null) {
      for (let i = 0; i < this.personnelSupportCostsDataList.length; i++) {
        this.personnelSupportCostsDataList[i].mtds_SUPPORT_TOTAL_COST_AM_String = 
          this.currencyPipe.transform(this.personnelSupportCostsDataList[i].mtds_SUPPORT_TOTAL_COST_AM, 'USD', 'symbol-narrow', '3.2-8', 'en-US');
        
        mtdsSupportTotalCostSum = mtdsSupportTotalCostSum + this.personnelSupportCostsDataList[i].mtds_SUPPORT_TOTAL_COST_AM;
      }
    }
    this.mtdsSupportTotalCostSumString = this.currencyPipe.transform(mtdsSupportTotalCostSum, 'USD', 'symbol-narrow', '3.2-8', 'en-US');
    this.caseLineComponentInfo.caseLineCompMtdsSupprtTotalAm = mtdsSupportTotalCostSum;
  }


  // Set Changed for each of the arrays.
  private setChangedStatus(pStatus:string) {
    return (pStatus == DsamsConstants.ENT_UNCHANGED.toString()?DsamsConstants.ENT_CHANGED.toString():pStatus);
  }

  private setChangedClc() {
    this.caseLineComponentInfo.status = this.setChangedStatus(this.caseLineComponentInfo.status);
  }

  setChangedMtdsPersonnel(pIndex:number) {
    this.caseLineComponentInfo.caseLineCompMtdsPersonList[pIndex].status = this.setChangedStatus(this.caseLineComponentInfo.caseLineCompMtdsPersonList[pIndex].status);
    this.setChangedClc();
  }

  setChangedMtdsSupport(pIndex:number) {
    this.caseLineComponentInfo.caseLineCompMtdsSupprtList[pIndex].status = this.setChangedStatus(this.caseLineComponentInfo.caseLineCompMtdsSupprtList[pIndex].status);
    this.setChangedClc();
  }

  setChangedMtdsTravel(pIndex:number) {
    this.caseLineComponentInfo.caseLineCompMtdsTravelList[pIndex].status = this.setChangedStatus(this.caseLineComponentInfo.caseLineCompMtdsTravelList[pIndex].status);
    this.setChangedClc();    
  }  

  onChangePERSONNEL_POSITION_NM(pValue:string, pIndex:number) {
    // Set the value equal to what was selected in the dropdown.
    let posId:number = 0;
    for (let currPos of this.refPersonnelPositionList) {
      if (currPos.field_1 == pValue) {
        posId = +currPos.key_FIELD;
      }
    }
    this.caseLineComponentInfo.caseLineCompMtdsPersonList[pIndex].personnel_POSITION_ID = posId;
    this.setChangedMtdsPersonnel(pIndex);
  }

  onChangePERSONNEL_GRADE_RANK_NM(pValue:string, pIndex:number) {
    let rankId:string = "";
    for (let currRank of this.refPersonnelGradeRankList) {
      if (currRank.field_1 == pValue) {
        rankId = currRank.key_FIELD;
      }
    }
    this.caseLineComponentInfo.caseLineCompMtdsPersonList[pIndex].personnel_GRADE_RANK_ID = rankId;
    this.setChangedMtdsPersonnel(pIndex);
  }

  onChangeMTDS_PERSON_ORGAN_TX(pValue:string, pIndex:number) {
    this.caseLineComponentInfo.caseLineCompMtdsPersonList[pIndex].mtds_PERSON_ORGAN_TX = pValue;
    this.setChangedMtdsPersonnel(pIndex);
  }


  onChangeMTDS_PERSON_WORK_YEARS_QY(pValue:string, pIndex:number) {
    this.caseLineComponentInfo.caseLineCompMtdsPersonList[pIndex].mtds_PERSON_WORK_YEARS_QY = +CaseUtils.fixupNumber(pValue);
    this.setChangedMtdsPersonnel(pIndex);
  }

  onChangeMTDS_PERSON_WORK_YEARS_TX(pValue:string, pIndex:number) {
    this.caseLineComponentInfo.caseLineCompMtdsPersonList[pIndex].mtds_PERSON_WORK_YEARS_TX = pValue;
    this.setChangedMtdsPersonnel(pIndex);
  }

  onChangeMTDS_PERSON_BASE_COST_AM(pValue:string, pIndex:number) {
    this.caseLineComponentInfo.caseLineCompMtdsPersonList[pIndex].mtds_PERSON_BASE_COST_AM = CaseUtils.unformatCurrency(CaseUtils.fixupNumber(pValue));
    this.calcPersonMtdsTotal();
    this.setChangedMtdsPersonnel(pIndex);
  }


  onChangeMTDS_TRAVEL_TOTAL_COST_AM(pValue:string, pIndex:number) {
    this.caseLineComponentInfo.caseLineCompMtdsTravelList[pIndex].mtds_TRAVEL_TOTAL_COST_AM = CaseUtils.unformatCurrency(CaseUtils.fixupNumber(pValue));
    this.calcTravelMtdsTotal();
    this.setChangedMtdsTravel(pIndex);
  }

  onChangeMTDS_SUPPORT_TOTAL_COST_AM(pValue:string, pIndex:number) {
    this.caseLineComponentInfo.caseLineCompMtdsSupprtList[pIndex].mtds_SUPPORT_TOTAL_COST_AM = CaseUtils.unformatCurrency(CaseUtils.fixupNumber(pValue));
    this.calcSupportMtdsTotal();    
    this.setChangedMtdsSupport(pIndex);
  }

  // Getting reference data
  // ****************** Get reference fields ****************
  getReferenceDataLists() {
    // Manpower Matrix
    this.caseRestService
      .getReferenceData(DsamsConstants.REF_MANPOWER_MATRIX, "", 0, true)
      .subscribe(
        (data: Array<ReferenceDataType>) => {
          this.refManpowerMatrixList = data;
          // Create no inactive ref list
          this.refManpowerMatrixList.forEach(row => { 
            if (row.inactive_IN === false) {
              this.refManpowerMatrixListNoInactive.push(row);
            }
          });
        },
        err => {
          CaseUtils.ReportHTTPError(err, "Error fetching reference for " + DsamsConstants.REF_MANPOWER_MATRIX);
        }
      );
    
    // Personnel Grade Rank
    this.caseRestService
      .getReferenceData(DsamsConstants.REF_PERSONNEL_GRADE_RANK, "", 0, true)
      .subscribe(
        (data: Array<ReferenceDataType>) => {
          this.refPersonnelGradeRankList = data;
          this.setPersonMtdsRankAndPosition(); 
        },
        err => {
          CaseUtils.ReportHTTPError(err, "Error fetching reference for " + DsamsConstants.REF_PERSONNEL_GRADE_RANK);
        }
      );

    // Personnel Position
    this.caseRestService
      .getReferenceData(DsamsConstants.REF_PERSONNEL_POSITION, "", 0, true)
      .subscribe(
        (data: Array<ReferenceDataType>) => {
          this.refPersonnelPositionList = data;
          // Sort the position reference list
          this.refPersonnelPositionList.sort((obj1: ReferenceDataType, obj2: ReferenceDataType) => {
            if (obj1.field_1 > obj2.field_1) {
              return 1;
            }
            if (obj1.field_1 < obj2.field_1) {
              return -1;
            }
            return 0;
          });
          this.setPersonMtdsRankAndPosition();
        },
        err => {
          CaseUtils.ReportHTTPError(err, "Error fetching reference for " + DsamsConstants.REF_PERSONNEL_POSITION);
        }
      );

    // Travel Fiscal Year
    /* Fiscal Year from reference */
    this.caseRestService
      .getReferenceData(DsamsConstants.REF_FISCAL_YEAR, "", 0, true)
      .subscribe(
        (data: Array<ReferenceDataType>) => {
          this.refTravelFiscalYearList = data;
        },
        err => {
          CaseUtils.ReportHTTPError(err, "Error fetching reference for " + DsamsConstants.REF_FISCAL_YEAR);
        }
      );
  }

  // 
  /* Open the Manpower Dialog */
  openManpowerDialog(pManpowerElement: any, pIndex: number, pManpowerRefList: any, pManpowerRefListNoInactive: any): any {
    let manpowerDialog = this.dialog.open(ManpowerComponent, {
      width: '40em',
      height: '40em',
      data: {
        elementForManpowerForPopup: pManpowerElement,
        indexForElement: pIndex,
        manpowerRefList: pManpowerRefList,
        manpowerRefListNoInactive: pManpowerRefListNoInactive
      }
    });

    manpowerDialog.afterClosed().subscribe(resp => {
      // received data from dialog-component
      //console.log("resp.data.mtdsType is: " + resp.data.mtdsType);
      //console.log("resp.data.index is: " + resp.data.index);
      //console.log("resp.data.response is: " + resp.data.response);
      
      if (resp != null && resp.data != null && resp.data.response != '') {
        if (resp.data.mtdsType === 'CASE_LINE_COMP_MTDS_PERSON') {
          this.personnelDataList[resp.data.index].mtds_MANPOWER_MATRIX_TX = resp.data.response;
          this.personnelDataList[resp.data.index].mtds_MANPOWER_MATRIX_TX_USER_FORMAT = resp.data.userResponse;
          this.setChangedMtdsPersonnel(resp.data.index);
        }
        else if (resp.data.mtdsType === 'CASE_LINE_COMP_MTDS_TRAVEL') {
          this.travelDataList[resp.data.index].mtds_MANPOWER_MATRIX_CD = resp.data.response;
          this.travelDataList[resp.data.index].mtds_MANPOWER_MATRIX_CD_USER_FORMAT = resp.data.userResponse;
          this.setChangedMtdsTravel(resp.data.index);
        }
        else if (resp.data.mtdsType === 'CASE_LINE_COMP_MTDS_SUPPRT') {
          this.personnelSupportCostsDataList[resp.data.index].mtds_SUPPORT_MATRIX_CD = resp.data.response;
          this.personnelSupportCostsDataList[resp.data.index].mtds_SUPPORT_MATRIX_CD_USER_FORMAT = resp.data.userResponse;
          this.setChangedMtdsSupport(resp.data.index);
        }
      }
    });
  }

  // Set Personnel Rank and Position
  private setPersonMtdsRankAndPosition() {
    //this.personnelDataList.forEach(perRow => {
    if (!!this.personnelDataList) {
      for (let i = 0; i < this.personnelDataList.length; i++) {
        //
        for (let j = 0; j < this.refPersonnelGradeRankList.length; j++) {
          if(!!this.personnelDataList[i].personnel_GRADE_RANK_ID && this.refPersonnelGradeRankList[j].key_FIELD === this.personnelDataList[i].personnel_GRADE_RANK_ID.toString()) {
            this.personnelDataList[i].personnel_GRADE_RANK_NM = this.refPersonnelGradeRankList[j].field_1;
          }
        }
        for (let k = 0; k < this.refPersonnelPositionList.length; k++) {
          if(!!this.personnelDataList[i].personnel_POSITION_ID && this.refPersonnelPositionList[k].key_FIELD === this.personnelDataList[i].personnel_POSITION_ID.toString()) {
            this.personnelDataList[i].personnel_POSITION_NM = this.refPersonnelPositionList[k].field_1;
          }
        }
      }
    }
  }

  // Format the manpower matrix to present to user (use field_1 instead of key_field)
  formatManpowerMatrix() {
    //this.personnelDataList.forEach(perRow => {
    for (let i = 0; i < this.personnelDataList.length; i++) {
      let matrixStringParsed = [];
      let matrixStringParsedUserFormat = [];
      let matrixStringUserFormat = '';

      if (this.personnelDataList[i].mtds_MANPOWER_MATRIX_TX != null && this.personnelDataList[i].mtds_MANPOWER_MATRIX_TX != '') {
        matrixStringParsed = this.personnelDataList[i].mtds_MANPOWER_MATRIX_TX.split(",").map(function (value) {
          return value.trim();
        });
  
        for (let j = 0; j < matrixStringParsed.length; j++) {
          for (let k = 0; k < this.refManpowerMatrixList.length; k++) {
            if (matrixStringParsed[j] === this.refManpowerMatrixList[k].key_FIELD) {
              matrixStringParsedUserFormat.push(this.refManpowerMatrixList[k].field_1);
            }
          }
        }

        matrixStringUserFormat = this.getValuesFromArray(matrixStringParsedUserFormat);
      }

      this.personnelDataList[i].mtds_MANPOWER_MATRIX_TX_USER_FORMAT = matrixStringUserFormat;
    }

    for (let i = 0; i < this.travelDataList.length; i++) {
      let matrixStringParsed = [];
      let matrixStringParsedUserFormat = [];
      let matrixStringUserFormat = '';

      if (this.travelDataList[i].mtds_MANPOWER_MATRIX_CD != null && this.travelDataList[i].mtds_MANPOWER_MATRIX_CD != '') {
        matrixStringParsed = this.travelDataList[i].mtds_MANPOWER_MATRIX_CD.split(",").map(function (value) {
          return value.trim();
        });
  
        for (let j = 0; j < matrixStringParsed.length; j++) {
          for (let k = 0; k < this.refManpowerMatrixList.length; k++) {
            if (matrixStringParsed[j] === this.refManpowerMatrixList[k].key_FIELD) {
              matrixStringParsedUserFormat.push(this.refManpowerMatrixList[k].field_1);
            }
          }
        }

        matrixStringUserFormat = this.getValuesFromArray(matrixStringParsedUserFormat);
      }

      this.travelDataList[i].mtds_MANPOWER_MATRIX_CD_USER_FORMAT = matrixStringUserFormat;
    }

    for (let i = 0; i < this.personnelSupportCostsDataList.length; i++) {
      let matrixStringParsed = [];
      let matrixStringParsedUserFormat = [];
      let matrixStringUserFormat = '';

      if (this.personnelSupportCostsDataList[i].mtds_SUPPORT_MATRIX_CD != null && this.personnelSupportCostsDataList[i].mtds_SUPPORT_MATRIX_CD != '') {
        matrixStringParsed = this.personnelSupportCostsDataList[i].mtds_SUPPORT_MATRIX_CD.split(",").map(function (value) {
          return value.trim();
        });
  
        for (let j = 0; j < matrixStringParsed.length; j++) {
          for (let k = 0; k < this.refManpowerMatrixList.length; k++) {
            if (matrixStringParsed[j] === this.refManpowerMatrixList[k].key_FIELD) {
              matrixStringParsedUserFormat.push(this.refManpowerMatrixList[k].field_1);
            }
          }
        }

        matrixStringUserFormat = this.getValuesFromArray(matrixStringParsedUserFormat);
      }

      this.personnelSupportCostsDataList[i].mtds_SUPPORT_MATRIX_CD_USER_FORMAT = matrixStringUserFormat;
    }

  }

  getValuesFromArray(arrayToParse: string[]) {
    let values: string;
    arrayToParse.forEach(row => { 
        if (values == null) 
          values = row+","
        else
          values = values+row+","
    });
    return values.slice(0,-1);
  }
}
