import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MtdsComponent } from './mtds.component';

describe('MtdsComponent', () => {
  let component: MtdsComponent;
  let fixture: ComponentFixture<MtdsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MtdsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MtdsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
