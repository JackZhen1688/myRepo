import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { SelectionModel } from '@angular/cdk/collections';
import { MatTableDataSource } from '@angular/material';
import { CaseRestfulService } from '../../services/case-restful.service';
import { BehaviorSubject, Subscription } from 'rxjs';
import { CaseUIService } from '../../services/case-ui-service';
import { IEditResponseType } from 'src/app/dsams/case/model/edit-response-type';
import { DsamsConstants } from 'src/app/dsams/dsams.constants';

export interface ManpowerMatrix {
    field_1: string; //row #
    field_2: string; //title
    field_3: string; //row# - title
    inactive_IN: boolean; //inactive
    key_FIELD: string; //row id
}

export interface ReturnObject {
    mtdsType: string; // personnel, travel, support
    index: number; // array index
    userResponse: string; // selected manpower items in user format (field_1)
    response: string; // selected manpower items in db format (key_field)
}

@Component({
    selector: 'app-manpower',
    templateUrl: './manpower.component.html',
    styleUrls: ['./manpower.component.css']
})
export class ManpowerComponent implements OnInit {

    displayedColumns: string[] = ['select','field_1','field_2','inactive_IN']; 
    dataSourceManpowerMatrix = new MatTableDataSource<ManpowerMatrix>();
    dataSourceManpowerMatrixArray = new Array <ManpowerMatrix>();
    dataSourceManpowerMatrixArrayNoInactive = new Array <ManpowerMatrix>();
    selectionManpowerMatrix = new SelectionModel<ManpowerMatrix>(true, []);
    recordCount: number=0;

    showSpinner: BehaviorSubject<boolean> = new BehaviorSubject(false);

    // The selected item(s)
    selManpowerNums: string;
    selManpowerNumsUserFormat: string;


    // Return object info
    returnObject: ReturnObject = <ReturnObject>{};

    showFullManpowerList: boolean = false;

    private editSubscription: Subscription = null;
    isManpowerPanelEditable: boolean = false;

    constructor(private caseRestService: CaseRestfulService,
        public dialogRef: MatDialogRef<ManpowerComponent>,
        private caseUIService: CaseUIService,
        @Inject(MAT_DIALOG_DATA) public data: {elementForManpowerForPopup: any, indexForElement: number, manpowerRefList: any, manpowerRefListNoInactive: any}) { }

    ngOnInit(): void { 
        // Build list
        this.dataSourceManpowerMatrix.data = [];
        this.getDataForManpowerList();
        this.subscribeToEditService();
    }

    /** Whether the number of selected elements matches the total number of rows. */
    isAllSelected() {
        const numSelected = this.selectionManpowerMatrix.selected.length;
        const numRows = this.dataSourceManpowerMatrix.filteredData.length;
        return numSelected === numRows;
    }

    /** Selects all rows if they are not all selected; otherwise clear selection. */
    masterToggle() {
        this.isAllSelected() ?
        this.selectionManpowerMatrix.clear() :
        this.dataSourceManpowerMatrix.data.forEach(row => this.selectionManpowerMatrix.select(row));   
    }

    /** The label for the checkbox on the passed row */
    checkboxLabel(row?: ManpowerMatrix): string {
        if (!row) {
        return `${this.isAllSelected() ? 'select' : 'deselect'} all`;
        }
        return `${this.selectionManpowerMatrix.isSelected(row) ? 'deselect' : 'select'} row ${row.field_1 + 1}`; //??? Check
    }

    onCheckboxChange() {
        this.selManpowerNums = this.getCheckedValues();
        this.selManpowerNumsUserFormat = this.getCheckedUserFormatValues();
        //console.log("Selected lines: " + this.selManpowerNums);
    }

    getCheckedValues() {
        let values: string;
        this.dataSourceManpowerMatrix.data.forEach(row => { 
            if (this.selectionManpowerMatrix.isSelected(row)) {
                if (values == null) 
                    values = row.key_FIELD+","
                else
                    values = values+row.key_FIELD+","
            }
          }
        )
        return values.slice(0,-1);
    }

    getCheckedUserFormatValues() {
        let values: string;
        this.dataSourceManpowerMatrix.data.forEach(row => { 
            if (this.selectionManpowerMatrix.isSelected(row)) {
                if (values == null) 
                    values = row.field_1+","
                else
                    values = values+row.field_1+","
            }
          }
        )
        return values.slice(0,-1);
    }

    onNoclick(): void {
        this.dialogRef.close();
    }

    XcloseDialog(): void {
        this.dialogRef.close();
    }

    completeDialog(): void {
        this.dialogRef.close();
    }

    //Table: highlighter
    selectedRowIndex: string; 
    lineNumId: string;

    highlight(row: any){
        this.selectedRowIndex = row.lineNum;
        this.lineNumId = row.lineNum;
    }

    saveDialog(): void {
        // Return the selected manpower matrix along with origin data
        this.returnObject.mtdsType = this.data.elementForManpowerForPopup.entityName;
        this.returnObject.index = this.data.indexForElement;
        this.returnObject.response = this.selManpowerNums;
        this.returnObject.userResponse = this.selManpowerNumsUserFormat;
        this.dialogRef.close({ data: this.returnObject });
    }

    cancelDialog(): void {
        this.dialogRef.close();
    }

    getDataForManpowerList() {
        this.dataSourceManpowerMatrixArray = this.data.manpowerRefList;
        this.dataSourceManpowerMatrixArrayNoInactive = this.data.manpowerRefListNoInactive;

        let matrixString: string = '';
        let matrixUserString: string = '';
        let matrixStringParsed = [];
        
        if (this.data.elementForManpowerForPopup.entityName != null) {
            if (this.data.elementForManpowerForPopup.entityName === 'CASE_LINE_COMP_MTDS_PERSON') {
                matrixString = this.data.elementForManpowerForPopup.mtds_MANPOWER_MATRIX_TX;
            }
            else if (this.data.elementForManpowerForPopup.entityName === 'CASE_LINE_COMP_MTDS_TRAVEL') {
                matrixString = this.data.elementForManpowerForPopup.mtds_MANPOWER_MATRIX_CD;
            }
            else if (this.data.elementForManpowerForPopup.entityName === 'CASE_LINE_COMP_MTDS_SUPPRT') {
                matrixString = this.data.elementForManpowerForPopup.mtds_SUPPORT_MATRIX_CD;
            }
            if (matrixString != null && matrixString != '') {
                matrixStringParsed = matrixString.split(",").map(function (value) {
                    return value.trim();
                });
            }
        }

        // Record count
        if (this.dataSourceManpowerMatrixArray != null) {
            this.recordCount = this.dataSourceManpowerMatrixArray.length;
        }

        // Check to see if show only exist list or full list
        if (this.showFullManpowerList) {
            this.dataSourceManpowerMatrix.data = this.dataSourceManpowerMatrixArrayNoInactive;
            
            // Loop through each manpower item and check the it in the reference list
            this.dataSourceManpowerMatrixArrayNoInactive.forEach(row => { 
                matrixStringParsed.forEach((element: string) => {
                    if (element === row.key_FIELD) {
                        this.selectionManpowerMatrix.select(row);
                    }
                });
            }
            );
        }
        else {
            let tempManpowerMaxtrix = new Array <ManpowerMatrix>();
            // Loop through each existing matrix item
            for (let i = 0; i < matrixStringParsed.length; i++) {
                // Loop through each manpower item
                for (let j = 0; j < this.dataSourceManpowerMatrixArray.length; j++) {
                    // If match add to exist list
                    if (matrixStringParsed[i] === this.dataSourceManpowerMatrixArray[j].key_FIELD) {
                        tempManpowerMaxtrix.push(this.dataSourceManpowerMatrixArray[j]);
                    }
                }
            }
            this.dataSourceManpowerMatrix.data = tempManpowerMaxtrix;
        }
    }

    showManpowerFullList() {
        this.showFullManpowerList = true;
        this.getDataForManpowerList();
    }

    // Subscribe to edit service
    private subscribeToEditService() {
        this.editSubscription = this.caseUIService.caseEditService.subscribe((pEditResult: IEditResponseType) => {
        if (!!pEditResult && pEditResult.ID === DsamsConstants.CASE_LINE_EDITOR) {
            this.isManpowerPanelEditable = pEditResult.editToggle;
        }
        });
    }
}