import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

@Component({
    selector: 'app-text-area',
    templateUrl: './text-area.component.html',
    styleUrls: ['./text-area.component.css']
})
export class TextAreaComponent implements OnInit {

    txtText_Area_TX: string = '';
    pTitle: string = '';
    isReadOnly: boolean = false;

    constructor(public dialogRef: MatDialogRef<TextAreaComponent>,
        @Inject(MAT_DIALOG_DATA) public data: { passingData: string, pTitle: string, isReadOnly: boolean }) { }

    ngOnInit(): void { 
        // Init here        
        // Just wait for user input
        if (!!this.data) {
            this.isReadOnly = this.data.isReadOnly;
            this.txtText_Area_TX = this.data.passingData;
            this.pTitle = this.data.pTitle;
        }
    }

    XcloseDialog(): void {
        this.dialogRef.close(null);
    }

    saveDialog(textAreaValue: string): void {
        this.dialogRef.close(textAreaValue)
    }

    cancelDialog(): void {
        this.dialogRef.close(null);
    }
}