import { Component, Inject, OnInit } from '@angular/core';
import { Subscription, BehaviorSubject } from 'rxjs';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { CaseRestfulService } from '../../services/case-restful.service';
import { CaseUIService } from '../../services/case-ui-service';
import { Router } from '@angular/router';
import { FundDTO, FiscalYearDTO } from '../../line-dashboard/line-pricing/ipc-tab-dashboard/model/dto/case-line-ipc-dto';
import { ISelectOptions } from 'src/app/dsams/interfaces/i-select-options';
import { IEditResponseType } from 'src/app/dsams/case/model/edit-response-type';
import { DsamsConstants } from 'src/app/dsams/dsams.constants';
import { CurrencyPipe } from '@angular/common';
import { CaseLineRelatedInfoType } from 'src/app/dsams/case/model/case-line-related-info-type';
import { caseLineComponentDto, caseLineComponentForCivilianPopup } from '../../model/dto/case-line-component-dto';
import { CaseUtils } from '../../utils/case-utils';
import { MessageMgr } from '../../validation/message-mgr';
import { CivilianPersonnelResultsType } from '../../model/dto/civilian-personnel-results-type';

export interface dropdownArray {
    pCode: string,
    pDesc: string
}

@Component({
    selector: 'app-civilian-personnel',
    templateUrl: './civilian-personnel.component.html',
    styleUrls: ['./civilian-personnel.component.css'],
    providers: [CurrencyPipe]
})
export class CivilianPersonnelComponent implements OnInit {

    showSpinner: BehaviorSubject<boolean> = new BehaviorSubject(false);

    aCaseUserId: string = ''
    caseLineRelatedInfoData: CaseLineRelatedInfoType;

    naString: string = 'N/A';
    wm_PRICE_YEAR_NM: string = this.naString;
    theCLCData: caseLineComponentDto;

    //Static dropdown List
    theFundList: FundDTO[] = [];
    theFYList: FiscalYearDTO[] = [];
    theBaseUnitPriceYearList: ISelectOptions[] = [
        { value: '1', viewValue: 'Base Fiscal Year' },
        { value: '2', viewValue: 'Then Fiscal Year' }
    ];
    theCivilianPersPayCodeList: ISelectOptions[] = [
        { value: '1', viewValue: 'Fringe / Unfunded Retirement Included' },
        { value: '2', viewValue: 'Fringe Included / Retirement Not Included' },
        { value: '3', viewValue: 'Fringe / Unfunded Retirement Not Included' },
    ];

    isPricingEditable: boolean = false;

    private editSubscription: Subscription = null;

    fiscalYearArray: dropdownArray[] = [];
    fiscalYearData: FiscalYearDTO;
    civilianPersonnelPayCodeText: string;
    civilianPersoonelCostText: string;

    constructor(private caseRestService: CaseRestfulService,
        public dialogRef: MatDialogRef<CivilianPersonnelComponent>,
        @Inject(MAT_DIALOG_DATA) public data: {clcElementForCivilianPersonnelForPopup: caseLineComponentDto, indexForElement: number, fiscalYearArray: any },
        private currencyPipe: CurrencyPipe,
        private caseUIService: CaseUIService) { }

    ngOnInit(): void {
        this.getDataForCivilianPersonnelData();
        this.subscribeToEditService();
    }

    XcloseDialog(): void {
        this.dialogRef.close();
    }

    saveDialog(): void {
        const cpErrorTitle:string = 'Civilian Personnel Error';
        // Check mandatry fields.
        if (!this.theCLCData.civilian_FISCAL_YEAR_ID || this.theCLCData.civilian_FISCAL_YEAR_ID == "") {
            MessageMgr.swalFire({
                title: cpErrorTitle,
                text: 'Civilian Fiscal Year is required.',
                icon: 'error',
                showCancelButton: false,
                cancelButtonText: 'No',
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'OK'
          });
        }
        else if (!this.theCLCData.civilian_PAYROLL_CATEGORY_CD || this.theCLCData.civilian_PAYROLL_CATEGORY_CD == 0) {
            MessageMgr.swalFire({
                title: cpErrorTitle,
                text: 'Civilian Payroll Category is required.',
                icon: 'error',
                showCancelButton: false,
                cancelButtonText: 'No',
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'OK'
          });
        }
        else if (!this.civilianPersoonelCostText || this.civilianPersoonelCostText == "N/A") {
            MessageMgr.swalFire({
                title: cpErrorTitle,
                text: 'Civilian Payroll Cost is required.',
                icon: 'error',
                showCancelButton: false,
                cancelButtonText: 'No',
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'OK'
          });
        }

        //civilianPersoonelCostText
        else {   // Required fields are present.
            // Check if the rate is valid and update the component unit base price amt with this value if so.
            this.caseRestService.getPersonnelBaseRate(this.theCLCData).subscribe((pResult:CivilianPersonnelResultsType) => {
                if (!!pResult) {
                    if (pResult.errorMsg == "") {
                        this.theCLCData.component_UNIT_BASE_PRICE_AM = pResult.component_UNIT_BASE_PRICE_AM; 
                        this.caseUIService.civilianPersonnelChosen.next(this.theCLCData);
                        this.dialogRef.close();                                    
                    }
                    else {
                        MessageMgr.swalFire({
                            title: cpErrorTitle,
                            text: pResult.errorMsg,
                            icon: 'error',
                            showCancelButton: false,
                            cancelButtonText: 'No',
                            confirmButtonColor: '#3085d6',
                            cancelButtonColor: '#d33',
                            confirmButtonText: 'OK'
                    });
                    }
                }          
            },
            err => {
                CaseUtils.ReportHTTPError(err, "Error Fetching Personnel Base Rate.");
            }); 
        }
    }

    cancelDialog(): void {
        this.dialogRef.close();
    }

    getDataForCivilianPersonnelData() {
        this.theCLCData = this.data.clcElementForCivilianPersonnelForPopup;
        this.fiscalYearData = this.data.fiscalYearArray;
        // Set the text of Civilian Personnel Payment Code
        for (let i = 0; i < this.theCivilianPersPayCodeList.length; i++) {
            if (this.theCLCData.civilian_PAYROLL_CATEGORY_CD === parseInt(this.theCivilianPersPayCodeList[i].value )) {
                this.civilianPersonnelPayCodeText = this.theCivilianPersPayCodeList[i].viewValue;
            }
        }
        // Currency with 2 decimal places, legacy uses 4
        this.civilianPersoonelCostText = this.currencyPipe.transform(this.theCLCData.civilian_PAYROLL_COST_AM, 'USD', 'symbol-narrow', '3.4-4', 'en-US');

        // Set customer number
        this.getTheUserCaseInfo();
    }

    // Subscribe to edit service
    private subscribeToEditService() {
        this.editSubscription = this.caseUIService.caseEditService.subscribe((pEditResult: IEditResponseType) => {
        if (!!pEditResult && pEditResult.ID === DsamsConstants.CASE_LINE_EDITOR) {
            this.isPricingEditable = pEditResult.editToggle;
        }
        });
    }

    onChangeCivilianPersonnelCostText(pValue:string) {
        this.theCLCData.civilian_PAYROLL_COST_AM = CaseUtils.unformatCurrency(CaseUtils.fixupNumber(pValue));
        this.civilianPersoonelCostText = this.currencyPipe.transform(this.theCLCData.civilian_PAYROLL_COST_AM, 'USD', 'symbol-narrow', '3.4-4', 'en-US');        
    }

    onCivilianFYChange(pValue:any) {
        this.theCLCData.civilian_FISCAL_YEAR_ID = !pValue.key_FIELD?"":pValue.key_FIELD;
    }

    onCivilianPayChange(pValue:string) {     
        let theValue:number = 0;
        if (pValue === "Fringe / Unfunded Retirement Included") {
            theValue = 1;
        }
        else if (pValue === "Fringe Included / Retirement Not Included") {
            theValue = 2;
        }
        else if (pValue === "Fringe / Unfunded Retirement Not Included") {
            theValue = 3;
        }
        this.theCLCData.civilian_PAYROLL_CATEGORY_CD = theValue;
    }

    getTheUserCaseInfo() {
        this.caseUIService.getCaseLineRelatedInfoValues().subscribe((value) => {
          this.caseLineRelatedInfoData = value;
          // Concatenate the case user ID with case version type code         
          if (!!this.caseLineRelatedInfoData) {
            //exclude version for basic case
            //if (this.caseLineRelatedInfoData.case_VERSION_TYPE_CD == 'B')
            if (this.caseLineRelatedInfoData.case_VERSION_NUMBER_ID == 0) {
              setTimeout(() => {
                this.aCaseUserId = '(' + this.caseLineRelatedInfoData.user_CASE_ID
                  + ' ' + this.caseLineRelatedInfoData.case_VERSION_TYPE_CD + ')';
              }, 0);
            }
            else {
              setTimeout(() => {
                this.aCaseUserId = '(' + this.caseLineRelatedInfoData.user_CASE_ID
                  + ' ' + this.caseLineRelatedInfoData.case_VERSION_TYPE_CD
                  + ' ' + this.caseLineRelatedInfoData.case_VERSION_NUMBER_ID + ')';
              }, 0);
            }
          }
        });
      }
}