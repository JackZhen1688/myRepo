import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-process-four',
  templateUrl: './process-four.component.html',
  styleUrls: ['./process-four.component.css']
})
export class ProcessFourComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
