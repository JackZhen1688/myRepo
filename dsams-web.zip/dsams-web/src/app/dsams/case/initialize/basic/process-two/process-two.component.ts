import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, FormArray, Validators} from '@angular/forms';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import { CaseRestfulService } from './../../../services/case-restful.service';
import { ObjectService } from '../case-objects/object-service';

export interface Category {
  case_category_cd: string;
  case_category_title: string;
}

export interface PreActivity {
  activity_id: string;
  //activity_abbreviation_nm: string;
  activity_name: string;
  //agency_manager_id: string;
  //implementing_agency_id: string;
  //activity_manager_id: string;
}

export interface CustService {
  customer_service_type_id: string;
  service_type_title_nm: string;
}

export interface Manager {
  person_last_nm: string;
  person_first_nm: string;
  person_nickname_nm: string;
}

export interface Role {
  management_role_id: string;
  management_role_title_name: string;
}

@Component({
  selector: 'app-process-two',
  templateUrl: './process-two.component.html',
  styleUrls: ['./process-two.component.css']
})
export class ProcessTwoComponent implements OnInit {

  managerLoaded: boolean = false;
  roleLoaded: boolean = false;

  categories: Category[] = [{"case_category_cd": "Code","case_category_title": "Title"}];
  preActivities: PreActivity[] = [{"activity_id": "ID","activity_name": "Name"}];
  cusServices: CustService[]; 
  managers: Manager[] = [{"person_first_nm": "First Name","person_last_nm": "Last Name", "person_nickname_nm":"Nick Name"}];
  roles: Role[] = [{"management_role_id": "Code","management_role_title_name": "Title"}];

  countryCode: string;
  countryName: string;
  implAgencyCode: string;
  implAgencyTitle: string;

  categoryCtrl = new FormControl();
  preActivityCtrl = new FormControl();
  custServiceCtrl = new FormControl();

  filteredCategories: Observable<Category[]>;
  filteredPreActivities: Observable<PreActivity[]>;
  filteredCustServices: Observable<CustService[]>;
  filteredManagers: Observable<Manager[]>[] = [];
  filteredRoles: Observable<Role[]>[] = [];


  processTwoForm: FormGroup;

  constructor(private formBuilder: FormBuilder, private restService: CaseRestfulService, private objectService: ObjectService) { }

  ngOnInit() {
    this.constructProcessTwoForm();
    this.processTwoForm.get("categoryTitle").disable();
    this.processTwoForm.get("preActivityName").disable();
  }

  ngOnDestroy() {
     console.log("#########################")
  }
  //Construct and Initial Process Form
  constructProcessTwoForm() {
    this.processTwoForm = this.formBuilder.group({
      nickName: this.formBuilder.control(''),
      categoryCode: this.formBuilder.control(''),
      categoryTitle: this.formBuilder.control(''),
      preActivityId: this.formBuilder.control(''),
      preActivityName: this.formBuilder.control(''),

      customerServices: this.initCustomers(),
      managersAndRoles: this.initManagerRoles(),
    });

    this.manageManagerControl(0);
    this.manageRoleControl(0);
  }

  initManagerRoles() {
    var formArray = this.formBuilder.array([]);
    formArray.push(this.formBuilder.group({
      manager: ['', [Validators.required]],
      role: ['', [Validators.required]],
    }));

    return formArray;
  }

  initCustomers() {
    var formArray = this.formBuilder.array([]);
    formArray.push(this.formBuilder.group({
      custServiceCode: ['', [Validators.required]],
      proAgency: [],
    }));

    return formArray;
  }

  private _filterPreActivities(value: string): PreActivity[] {
    const filterValue = value.toLowerCase();
    return this.preActivities.filter(preActivity => (preActivity.activity_id.toLowerCase().indexOf(filterValue) === 0 || 
                                                     preActivity.activity_name.toLowerCase().indexOf(filterValue) === 0));
  }
  
  onSelectPreActivity(event: any, sourceCompt: any, targetCompt: any) {
    if (event.isUserInput) {
        if (event.source.value.indexOf(":") >= 0) {
            this.processTwoForm.get(sourceCompt).setValue(event.source.value.slice(0, event.source.value.indexOf(":")));
            this.processTwoForm.get(targetCompt).setValue(event.source.value.slice(event.source.value.indexOf(":")+1));
        }
    }
  }

  onBlurPreActivity(event: any, sourceCompt: any, targetCompt: any) {
    this.processTwoForm.get(sourceCompt).reset();
    for(let i=0; i<this.preActivities.length; i++) {
        if (event.target.value.toUpperCase() == this.preActivities[i].activity_id) {
            this.processTwoForm.get(sourceCompt).setValue(this.preActivities[i].activity_id.toUpperCase());
            this.processTwoForm.get(targetCompt).setValue(this.preActivities[i].activity_name.toUpperCase());
            break;
        } 
    }
  }


  private _filterCategories(value: string): Category[] {
    const filterValue = value.toLowerCase();
    return this.categories.filter(category => (category.case_category_cd.toLowerCase().indexOf(filterValue) === 0 || 
                                               category.case_category_title.toLowerCase().indexOf(filterValue) === 0));
  }
  
  onSelectCategory(event: any, sourceCompt: any, targetCompt: any) {
    if (event.isUserInput) {
        if (event.source.value.indexOf(":") >= 0) {
            this.processTwoForm.get(sourceCompt).setValue(event.source.value.slice(0, event.source.value.indexOf(":")));
            this.processTwoForm.get(targetCompt).setValue(event.source.value.slice(event.source.value.indexOf(":")+1));
        }
    } 
  }

  onBlurCategory(event: any, sourceCompt: any, targetCompt: any) {
    this.processTwoForm.get(sourceCompt).reset();
    for(let i=0; i<this.categories.length; i++) {
        if (event.target.value.toUpperCase() == this.categories[i].case_category_cd) {
            this.processTwoForm.get(sourceCompt).setValue(this.categories[i].case_category_cd.toUpperCase());
            this.processTwoForm.get(targetCompt).setValue(this.categories[i].case_category_title.toUpperCase());
            break;
        } 
    }
  }


  manageManagerControl(index: number){
    this.filteredManagers[index] = this.managersRoles.at(index).get('manager').valueChanges
    .pipe(
      startWith(''),
      map(manager => manager ? this._filterManagers(manager) : this.managers.slice())
    );
  }

  private _filterManagers(value: string): Manager[] {
    const filterValue = value.toLowerCase();
    return this.managers.filter(manager => (manager.person_first_nm.toLowerCase().indexOf(filterValue) === 0 || 
                                            manager.person_last_nm.toLowerCase().indexOf(filterValue) === 0 ||
                                            manager.person_nickname_nm.toLowerCase().indexOf(filterValue) === 0 ));
  }
  
  onSelectManager(event: any, index: number) {
    if (event.isUserInput) {
        this.managersRoles.controls[index].get("manager").setValue(event.source.value);
    } 
  }

  onBlurManager(event: any, index: number) {
    this.managersRoles.controls[index].get("manager").reset();
    for(let i=0; i<this.managers.length; i++) {
        if (event.target.value.toUpperCase() == this.managers[i].person_nickname_nm) {
            this.managersRoles.controls[index].get("manager").setValue(event.target.value.toUpperCase());
            break;
        } 
    }
  }

  manageRoleControl(index: number){
    this.filteredRoles[index] = this.managersRoles.at(index).get('role').valueChanges
    .pipe(
      startWith(''),
      map(role => role ? this._filterRoles(role) : this.roles.slice())
    );
  }

  private _filterRoles(value: string): Role[] {
    const filterValue = value.toLowerCase();
    return this.roles.filter(role => (role.management_role_id.toLowerCase().indexOf(filterValue) === 0 || 
                                      role.management_role_title_name.toLowerCase().indexOf(filterValue) === 0 ));
  }
  

  onSelectRole(event: any, index: number) {
    console.log("hello")
    //if (event.isUserInput) {
    //    this.managersRoles.controls[index].get("role").setValue(event.source.value);
    //} 
  }

  onBlurRole(event: any, index: number) {
    this.managersRoles.controls[index].get("role").reset();
    for(let i=0; i<this.roles.length; i++) {
        if (event.target.value.toUpperCase() == this.roles[i].management_role_id) {
            this.managersRoles.controls[index].get("role").setValue(event.target.value.toUpperCase());
            break;
        } 
    }
  }

  onSubmit() {
    console.log("Form Value: "+JSON.stringify(this.processTwoForm.value));
  }

  /*-------------------
    Customer Service
   --------------------*/
  get custServices() {
    return this.processTwoForm.get('customerServices') as FormArray
  }

  addCustServices() {
    const custService = this.formBuilder.group({ 
      custServiceCode: [],
      proAgency: [],
    })
    this.custServices.push(custService);
  }

  delCustServices(i) {
    this.custServices.removeAt(i);
  }


  onSelect (event: any, sourceCompt: any) {
    console.log("value=="+event.target.value);
  }
  
  /*-------------------
    Managers and Roles
   --------------------*/
  get managersRoles() {
    return this.processTwoForm.get('managersAndRoles') as FormArray
  }

  addManagersRoles() {
    const mangerRole = this.formBuilder.group({ 
      manager: [],
      role: [],
    })
    this.managersRoles.push(mangerRole);
    this.manageManagerControl(this.managersRoles.length-1);
    this.manageRoleControl(this.managersRoles.length-1);
  }

  delManagersRoles(i: any) {
    this.managersRoles.removeAt(i);
  }

}
