import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-amendment',
  templateUrl: './amendment.component.html',
  styleUrls: ['./amendment.component.css']
})
export class AmendmentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
