/* 
  Author: Francis Shu 
  Date:   04/06/2020 
*/

import { Component, OnInit, Input, ViewChild, Output, EventEmitter } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { CaseRestfulService } from '../services/case-restful.service';
import { CaseQueryParamsType } from '../model/search-params/case-query-params-type';
import { CaseUIService } from '../services/case-ui-service';
import { CaseUtils } from '../utils/case-utils';
import { CaseRequestParamsType } from '../model/search-params/case-request-params-type';
import { CaseRelatedInfoType } from '../model/case-related-info-type';
import { CaseLineRelatedInfoType } from '../model/case-line-related-info-type';
import { ActivatedRoute, Router } from '@angular/router';
import { ifaceCaseLineData, ifaceCaseLineListArray } from '../model/case-line-model';
import { FormControl, NumberValueAccessor } from '@angular/forms';
import { LineSublineRefComponent } from '../line-dashboard/line-reference.component';
import { DsamsConstants } from '../../dsams.constants';
import { MatPaginator, PageEvent } from '@angular/material';
import { Subscription } from 'rxjs';
import { LineUtils } from '../line-dashboard/line-utils';
import { MessageMgr } from '../validation/message-mgr';
import { ISearchPageEvent } from '../../utilitis/search-page-event';
import { DsamsShareService } from '../../services/dsams-share.service';
import { LinkCaseDataIface, LinkCaseDataClass } from '../model/link-case-data';

@Component({
  selector: 'app-case-search',
  templateUrl: './case-search.component.html',
  styleUrls: ['./case-search.component.css',
    '../case-dashboard/common-CSS.component.css'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0', minHeight: '0', display: 'none' })),
      state('expanded', style({ height: '*' })),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})

export class CaseSearchComponent implements OnInit {

  caseLineInfoData: ifaceCaseLineData;
  private caseSearchResultData: any = {};
  private _reloadData: boolean = true;
  noCasesFoundInd: boolean = false;
  selectedLine: any;
  private lastLineNumber: string;

  gobackTest: any = {};
  aCaseRelatedInfoType: CaseRelatedInfoType;
  aCaseLineRelatedInfoType: CaseLineRelatedInfoType;
  theCaseMasterLineListArray: ifaceCaseLineListArray[];
  theCaseMasterLineList: ifaceCaseLineListArray[];
  theCaseLineListArray: ifaceCaseLineListArray[];
  theCaseMasterSublineListArray: ifaceCaseLineListArray[];
  theLineSublineListArray: ifaceCaseLineListArray[];
  backToCaseSearchSummaryValue: boolean;
  lineFormCtl: FormControl = new FormControl();
  subLineFormCtl: FormControl = new FormControl();
  subLineSubFormCtl: FormControl = new FormControl();
  currentlySelectedRowNum: number = 0;
  showProgressSpinner: boolean = false;
  private _spinnerSubscription: Subscription = null;
  private _prevCaseIndex: number = -1;
  linkCaseDataObject: LinkCaseDataIface;
  linkCaseData: any;

  // Case Search fields
  caseSearchData: CaseQueryParamsType;

  //Input variables from case-dashboard.component.html (Parent)
  @Input() pageLength: number;
  @Input() recordLength: number;
  @Input() pageCount: number;
  @Input() pageOptions: number[];

  @Output() sendTabIndex = new EventEmitter<number>();
  @Output() sendTabLabel = new EventEmitter<string>();
  private tabId: number = 1; //indicate new Line/Subline tab

  //Subscriptions
  private _fetchSearchSubscription: Subscription = null;

  dataCaseSearchResults = new MatTableDataSource();
  dataCaseVersions = new MatTableDataSource();

  columnsToDisplayCaseSearchResults = ['ArrowInd', 'DocType', 'Case', 'CaseStatus', 'ProgramType', 'Category', 'PreparingActivity', 'Nickname', 'CaseManager'];
  expandedElement: null;
  displaySubcolumns = ['VersionType', 'VersionStatus', 'InitializationDate', 'ImplmentationDate', 'Detail',
    'LineList', 'Milestones', 'PaySchedule', 'NoteList', 'Remarks', 'Attachments'];
  aCaseVersionRowIndex: number = 0;
  serviceDbId: string;
  private static alphabeticalString: string = 'abcdefghijklmnopqrstuvwxyz';
  matches: string[] = [];
  sublinesCount: number = 0;

  _caseUIServiceSubscription: Subscription;
  caseRelatedInfoData: CaseRelatedInfoType;
  caseLineRelatedInfoData: CaseLineRelatedInfoType;
  sublineNumber: string = "";
  sublineIndexVal: number = 0;
  private _caseDetailsSubscription: Subscription = null;

  constructor(private caseRestService: CaseRestfulService, private route: ActivatedRoute, private router: Router,
    private getLineSublineRefData: LineSublineRefComponent, private caseUIService: CaseUIService,
    private dataSharingService: DsamsShareService) {
    //console.log("Inside CaseSearchComponent");
  }

  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;

  ngOnInit() {
    //console.log("Inside ngOnInit");
    this.showProgressSpinner = false;
    this.theCaseLineListArray = [{ virtualSublineList: [] }];
    this.theLineSublineListArray = [];
    this.theCaseMasterLineListArray = [];
    this.theCaseMasterLineList = [];
    this.serviceDbId = CaseUtils.getServiceDatabaseId();
    this.linkCaseDataObject = {
      case_ID: 0,
      case_VERSION_ID: 0,
      serviceDbId: this.serviceDbId,
    }
    this.caseUIService.getbackToCaseSearchSummaryValue().subscribe((value) => {
      this.backToCaseSearchSummaryValue = value;
    });
    //reset Line Edit mode
    this.caseUIService.setIsLineDataInEditMode(false);

    this.subscribeToSpinner();


    if (this.backToCaseSearchSummaryValue) {
      // console.log('***backfromCaseLineList')
      this.gobackTest = JSON.parse(sessionStorage.getItem('goback'))
      this.caseSearchResultData = this.gobackTest;
      // Retrieving case search results
      this.initializeCaseSearchResultsArray();
      this.caseUIService.setbackToCaseSearchSummaryValue(false);
      this.fetchCaseSearchResultsData();
    }
    else {
      this.fetchCaseSearchResultsData();
    }
    this._caseUIServiceSubscription = this.caseUIService.getCaseLineRelatedInfoValues().subscribe((value) => {
      this.caseLineRelatedInfoData = value;
    });
    this._caseUIServiceSubscription = this.caseUIService.getCaseRelatedInfoValues().subscribe((value) => {
      this.caseRelatedInfoData = value;
    });
  }


  ngOnDestroy() {
    if (this._caseUIServiceSubscription) this._caseUIServiceSubscription.unsubscribe();
    //Unsubscribe
    if (!!this._fetchSearchSubscription) {
      this._fetchSearchSubscription.unsubscribe();
      this._fetchSearchSubscription = null;
    }
    if (!!this._spinnerSubscription) {
      this._spinnerSubscription.unsubscribe();
      this._spinnerSubscription = null;
    }
  }

  /**
   * Function to denote that the row is expanded.
   */
  isExpanded(pRow) {
    return pRow == this.currentlySelectedRowNum;
  }

  /**
   * Reset the prev case search index.
   */
  private resetPrevCaseIndex() {
    this._prevCaseIndex = -1;
  }

  private resetDataCaseVersions() {
    this.dataCaseVersions = new MatTableDataSource([]);
  }

  /**
  * Subscribe to the spinner spinning.
  */
  subscribeToSpinner() {
    if (!this._spinnerSubscription) {
      this._spinnerSubscription = this.caseUIService.showSearchSpinner.subscribe((pShowSpinner: boolean) => {
        this.showProgressSpinner = pShowSpinner;
      });
    }
  }

  onLineForSublinemenuClick(pLineNum: any) {
    //clear out all previous values 
    this.theCaseMasterSublineListArray = [{}];
    this.populateSublineDropdownList(pLineNum.value);
  }

  //set up subline dropdown list
  populateSublineDropdownList(pLineNum: any) {
    //clean up the first empty row
    for (var parentI = 0; parentI <= this.theCaseLineListArray.length - 1; parentI++) {
      if (this.theCaseLineListArray[parentI].wm_USER_CASE_LINE_NUMBER_ID == null)
        this.theCaseLineListArray.splice(parentI, 1);
    }
    for (var i = 0; i <= this.theCaseLineListArray.length - 1; i++) {
      if (this.theCaseLineListArray[i].wm_USER_CASE_LINE_NUMBER_ID == pLineNum) {
        for (let index = 0; index <= this.theCaseLineListArray[i].virtualSublineList.length - 1; index++) {
          this.theCaseMasterSublineListArray[index] = {
            wm_USER_CASE_SUBLINE_TX: this.theCaseLineListArray[i].virtualSublineList[index],
            //store the parent case master line id
            case_MASTER_LINE_ID: this.theCaseLineListArray[i].case_MASTER_LINE_ID,
            //only for display purposes
            wm_USER_CASE_LINE_NUMBER_ID: this.theCaseLineListArray[i].wm_USER_CASE_LINE_NUMBER_ID,
          };
        }
      }
    }
    //set default display value for subline
    this.subLineSubFormCtl.setValue(this.theCaseMasterSublineListArray[0].wm_USER_CASE_SUBLINE_TX);
  }

  //populate the dropdown case line/subline fields
  getCasMasterLineListData(currRowCaseId: any, currRowCaseVersionID: any) {
    var lineNumber: string = '';
    var isNotFirstValue: boolean = true;
    //Instantiate or reset the array
    this.theCaseMasterLineListArray = [{}];
    this.theCaseMasterSublineListArray = [{}];
    this.theLineSublineListArray = [];
    this.theCaseLineListArray = [{ virtualSublineList: [] }];
    this.theCaseMasterLineList = [];

    this.caseRestService.getCaseLineListFromServer(currRowCaseId, currRowCaseVersionID)
      .subscribe(
        data => {
          if (data.caseLineList) {
            for (var i = 0; i <= data.caseLineList.length - 1; i++) {
              //set the default display value for line dropdown list 
              if (data.caseLineList[i].wm_USER_CASE_LINE_NUMBER_ID &&
                (data.caseLineList[i].wm_USER_CASE_SUBLINE_TX == null) &&
                isNotFirstValue) {
                this.lineFormCtl.setValue(data.caseLineList[i].wm_USER_CASE_LINE_NUMBER_ID);
                isNotFirstValue = false;
              }
              //set up the virtual line and subline dropdown list
              if (data.caseLineList[i].virtualSublineList) {
                this.theCaseLineListArray.push(data.caseLineList[i])
              }
              //set up line data for processing
              if (data.caseLineList[i].wm_USER_CASE_SUBLINE_TX == null) {
                data.caseLineList[i].LINESUBLINESEQVIR = data.caseLineList[i].wm_USER_CASE_LINE_NUMBER_ID;
                this.theCaseMasterLineListArray.push(data.caseLineList[i]);
              }
              //Stores all lines and sublines entity
              this.theLineSublineListArray.push(data.caseLineList[i])
            }

            //set the default display value for subline dropdown fields
            if (this.theCaseLineListArray && this.theCaseLineListArray.length > 1) {
              this.subLineFormCtl.setValue(this.theCaseLineListArray[1].wm_USER_CASE_LINE_NUMBER_ID);
              //set up the virtual line and subline list
              this.populateSublineDropdownList(this.theCaseLineListArray[1].wm_USER_CASE_LINE_NUMBER_ID);
            }

            //set up the line dropdown list for Line menu
            if (!!this.theLineSublineListArray) {
              for (let index = 0; index < this.theLineSublineListArray.length; index++) {
                if (this.theLineSublineListArray[index].wm_USER_CASE_LINE_NUMBER_ID !== null &&
                  this.theLineSublineListArray[index].wm_USER_CASE_SUBLINE_TX == null)
                  this.theCaseMasterLineList.push(this.theLineSublineListArray[index]);
              }
            }
            //set up the last line number for adding new line 
            if (!!this.theCaseMasterLineListArray) {
              //pick up the last line number
              if (this.theCaseMasterLineListArray[this.theCaseMasterLineListArray.length - 1].wm_USER_CASE_SUBLINE_TX !== null) {
                for (let index = 0; index <= this.theCaseMasterLineListArray.length - 1; index++) {
                  if (this.theCaseMasterLineListArray[index].wm_PARENT_CASE_MASTER_LINE_ID ==
                    this.theCaseMasterLineListArray[this.theCaseMasterLineListArray.length - 1].wm_PARENT_CASE_MASTER_LINE_ID) {
                    this.lastLineNumber = this.theCaseMasterLineListArray[index].wm_USER_CASE_LINE_NUMBER_ID;
                    this.theCaseMasterLineListArray[this.theCaseMasterLineListArray.length - 1].LINESUBLINESEQVIR =
                      this.lastLineNumber;
                  }
                }
              }
              else this.lastLineNumber =
                this.theCaseMasterLineListArray[this.theCaseMasterLineListArray.length - 1].LINESUBLINESEQVIR.substring(0, 3);
            }
          }
        });
  }

  getParentLineCMLId(pParentCaseId: any, pParentCaseMasterLineId: any): string {
    //set up parent line for subline
    for (let i = 0; i < this.theLineSublineListArray.length; i++) {
      if (this.theLineSublineListArray[i].case_ID == pParentCaseId &&
        this.theLineSublineListArray[i].case_MASTER_LINE_ID == pParentCaseMasterLineId) {
        return (CaseUtils.formatLineNumber(this.theLineSublineListArray[i].wm_USER_CASE_LINE_NUMBER_ID));
      }
    }
    return '';
  }

  //get a case line/subline entity data
  getCaseLineData(pNavigateToLine: boolean) {
    if (this.caseLineInfoData == null)
      this.caseLineInfoData = {};
    //get only 1 case line using legacy interface
    this.caseRestService.getCaseLineFromServer(
      this.aCaseRelatedInfoType.working_CASE_ID,
      this.aCaseRelatedInfoType.case_MASTER_LINE_ID,
      this.aCaseRelatedInfoType.working_CASE_VERSION_ID).subscribe((value) => {
        if (!!value.caseLineList && !!value.caseLineList[0]) {
          this.caseLineInfoData.offer_EXPIRATION_DT = this.aCaseRelatedInfoType.offer_EXPIRATION_DT;
          this.caseLineInfoData.implementing_AGENCY_ID = this.aCaseRelatedInfoType.implementing_AGENCY_ID;
          this.caseLineInfoData.case_USAGE_INDICATOR_CD = this.aCaseRelatedInfoType.case_USAGE_INDICATOR_CD;
          this.caseLineInfoData.case_CATEGORY_CD = this.aCaseRelatedInfoType.case_CATEGORY_CD;
          //set up virtual line number for line
          if (value.caseLineList[0].wm_USER_CASE_SUBLINE_TX == null)
            this.caseLineInfoData.LINESUBLINESEQVIR = CaseUtils.formatLineNumber(value.caseLineList[0].wm_USER_CASE_LINE_NUMBER_ID);
          else
            this.caseLineInfoData.LINESUBLINESEQVIR = this.getParentLineCMLId(value.caseLineList[0].wm_PARENT_CASE_ID,
              value.caseLineList[0].wm_PARENT_CASE_MASTER_LINE_ID);
          //Set up other info needed by sub classes JS
          this.caseLineInfoData.working_CASE_ID = value.caseLineList[0].working_CASE_ID;
          this.caseLineInfoData.working_CASE_VERSION_ID = value.caseLineList[0].working_CASE_VERSION_ID;
          this.caseLineInfoData.wm_USER_CASE_SUBLINE_TX = value.caseLineList[0].wm_USER_CASE_SUBLINE_TX;
          this.caseLineInfoData.change_ACTION_CD = value.caseLineList[0].change_ACTION_CD;
          this.caseLineInfoData.wm_CASE_LINE_LOI_IN = value.caseLineList[0].wm_CASE_LINE_LOI_IN;
          this.caseLineInfoData.wm_CASE_VERSION_STATUS_CD = this.aCaseLineRelatedInfoType.case_VERSION_STATUS_CD;
          this.caseLineInfoData.change_ACTION_TITLE_NM = value.caseLineList[0].change_ACTION_TITLE_NM;
          this.caseLineInfoData.wm_USER_CASE_LINE_NUMBER_ID = value.caseLineList[0].wm_USER_CASE_LINE_NUMBER_ID;
          //send up the selected case line entity to be used by the Line tab component.
          // this.setupCaseRelatedInfo(value.caseLineList[0]);
          // this.caseUIService.setCaseLineRelatedInfoValues(this.aCaseLineRelatedInfoType);
          LineUtils.getFormattedMDEValue(this.caseLineInfoData);
          LineUtils.resetReferenceTitleValues(this.caseLineInfoData);
          this.caseUIService.setCaseLineInfoValues(this.caseLineInfoData);
          //begin DSAMS-5269-03/22 DH
          this.getLineSublineRefData.populateReferenceDataForCaseLine();
          this.getLineSublineRefData.setResetDynamicRefList(true);
          //end DSAMS-5269-03/22 DH
          this.resetFormValues();
          //Jump to applicable line/subline tab
          this.caseUIService.setIsLineTabDisabled(false);
          if (pNavigateToLine) this.router.navigate(['/case/line-dashboard', '1', 'Line']);
          else this.router.navigate(['/case/line-dashboard', '1', 'Subline']);
        }
        else {
          MessageMgr.swalFire({
            text: 'Case Line is not found',
            icon: 'error',
            //showConfirmButton: false,
            width: 400,
            focusConfirm: true,
            confirmButtonText: 'OK'
          })
        }
      });
  }

  initializeCaseLineInfoData() {
    this.caseLineInfoData = {
      //this is for Header section
      wm_USER_CASE_LINE_NUMBER_ID: this.lastLineNumber,
      wm_USER_CASE_SUBLINE_TX: '',
      wm_CASE_LINE_LOI_IN: false,
      wm_EXCLUSION_IN: false,
      wm_CML_SERVICES_COMPLETE_IN: false,
      wm_CASE_VERSION_STATUS_CD: '',
      change_ACTION_TITLE_NM: '',
      offer_EXPIRATION_DT: '',
      implementing_AGENCY_ID: '',
      LINESUBLINESEQVIR: '',
      case_CUSTOMER_TYPE_CD: '',
      case_USAGE_INDICATOR_CD: '',
      case_CATEGORY_CD: '',
      //this is for Pricing tab
      recalculation_IN: false,
      isPricingDataChanged: false,
      //this is for Line Detail tab
      case_LINE_ITEM_QY: '', generic_CD: '', military_ARTICLE_SERVICE_CD: '',
      line_PURPOSE_CD: '', line_PURPOSE_TITLE_NM: '', issue_UNIT_CD: '',
      article_DESCRIPTION_TX: '', major_DEFENSE_EQUIPMENT_CD: '', equipment_TYPE_TITLE_NM: '',
      stock_ON_ORDER_COST_AM: '', stock_ON_HAND_COST_AM: '', total_ABOVE_LINE_COST_AM: '',
      unit_ABOVE_LINE_COST_AM: '', part_NUMBER_IN: false, other_PART_NUMBER_IN: false,
      acquisition_VALUE_AM: '', inventory_VALUE_AM: '', percent_STOCK_RT: '',
      missile_TECH_CNTRL_REGIME_ID: '', mtcr_TITLE_NM: '', mde_SME_CD: '',
      national_STOCK_NUMBER_ID: '', other_NATIONAL_STOCK_NUMBER_ID: '',
      caseLineAssistanceTypeList: [],
      //this is for delivery tab
      case_LINE_PERIOD_START_QY: '', case_LINE_PERIOD_END_QY: '',
      case_LINE_PAY_PERIOD_START_QY: '', case_LINE_PAY_PERIOD_END_QY: '',
      case_LINE_AVAILABILITY_LEAD_QY: '', case_LINE_SHIPMENT_TX: '',
      caseLineDeliveryItemList: [], caseLineOfferReleaseList: [], caseLineDeliveryTermList: [],
    }
  }

  //FR2 - search for an available line
  generateLineNumber(): number {
    let dataSourceLength = this.theCaseMasterLineListArray.length;
    var numLine: number = 1;
    for (var i = 1; i < dataSourceLength; i++) {
      if (numLine < parseInt(this.theCaseMasterLineListArray[i].wm_USER_CASE_LINE_NUMBER_ID))
        return numLine;
      else numLine++;
    }
    return numLine;
  }

  getNewSubline(currentSublineChar: string): string {
    let newSublineChar = this.getSublineChar(CaseSearchComponent.alphabeticalString.indexOf(currentSublineChar) + 1);
    return newSublineChar;
  }

  getSublineChar(posNum: number = 0): string {
    return CaseSearchComponent.alphabeticalString.charAt(posNum).toString();
  }

  sublineOkOnClick() {
    this.sublineNumber = this.subLineFormCtl.value;
    this.sublineIndexVal = this.convertlineNumToInt(parseInt(this.sublineNumber));
    this.createNewSubline();
  }

  createNewSubline() {
    // Call REST API to see if sub-line can be edited.
    // CML and Parent CML should be the same because we're already checking the parent to see if we can edit the sub-line.
    this.caseRestService
      .getCanSublineBeEdited(this.caseRelatedInfoData.case_ID,
        this.caseRelatedInfoData.working_CASE_VERSION_ID,
        this.sublineNumber)
      .subscribe((pResult: string) => {
        if (!pResult || pResult === DsamsConstants.NO_ERROR) {
          // Create the subline
          for (let i = 0; i < this.theLineSublineListArray.length; i++) {
            if (this.theLineSublineListArray[i].wm_USER_CASE_LINE_NUMBER_ID === this.sublineNumber &&
              this.theLineSublineListArray[i].wm_USER_CASE_SUBLINE_TX !== null) {
              this.sublinesCount = this.sublinesCount + 1;
              this.matches.push(this.theLineSublineListArray[i].wm_USER_CASE_SUBLINE_TX);
            }
          }
          if (this.sublinesCount == 0) {
            this.theLineSublineListArray[this.sublineIndexVal].wm_USER_CASE_SUBLINE_TX = this.getSublineChar(0);
          } else {
            this.theLineSublineListArray[this.sublineIndexVal].wm_USER_CASE_SUBLINE_TX =
              this.getNewSubline(this.matches[--this.sublinesCount]);
          }
          this.navigateToDetailSubline(this.theLineSublineListArray[this.sublineIndexVal].wm_USER_CASE_SUBLINE_TX,
            parseInt(this.sublineNumber));
        }
        else {
          MessageMgr.displaySinglePopupError("E" + pResult);
        }
      },
        err => {
          CaseUtils.ReportHTTPError(err, "Determining if subline can be created. Possible no lines in line list.");
        });
  }

  //Add a new subline when clicked on the menu in line list (Add) button. 
  navigateToDetailSubline(sublineNum: string, lineNum: number) {
    if (this.caseLineRelatedInfoData.case_VERSION_STATUS_CD.toUpperCase() == 'D') {
      var lineNumberIndex = this.convertlineNumToInt(lineNum);
      this.initializeCaseLineInfoData();
      // this.caseLineInfoData.status = DsamsConstants.ENT_CHANGED.toString();
      // this.caseLineInfoData.service_DB_ID = CaseUtils.getServiceDatabaseId();
      LineUtils.transferCMLDataToCL(this.caseLineInfoData, this.caseRelatedInfoData);

      this.caseLineInfoData.isEntityNew = true;
      this.caseLineInfoData.wm_PARENT_CASE_ID = this.theCaseMasterLineList[lineNumberIndex].case_ID;
      this.caseLineInfoData.wm_PARENT_CASE_MASTER_LINE_ID = this.theCaseMasterLineList[lineNumberIndex].case_MASTER_LINE_ID;
      this.caseLineInfoData.customer_ORGANIZATION_ID = this.theCaseMasterLineList[lineNumberIndex].customer_ORGANIZATION_ID;
      this.caseLineInfoData.wm_CM_CUSTOMER_ORGANIZATION_ID = this.theCaseMasterLineList[lineNumberIndex].wm_CM_CUSTOMER_ORGANIZATION_ID;
      this.caseLineInfoData.wm_PARENT_CHANGE_ACTION_CD = this.theCaseMasterLineList[lineNumberIndex].wm_PARENT_CHANGE_ACTION_CD;
      this.caseLineInfoData.wm_PARENT_IS_PRICED = this.theCaseMasterLineList[lineNumberIndex].wm_PARENT_IS_PRICED;
      this.caseLineInfoData.wm_LINE_IS_PRICED = this.theCaseMasterLineList[lineNumberIndex].wm_LINE_IS_PRICED;
      this.caseLineInfoData.wm_CML_IMPLEMENTED_CASE_ID = this.theCaseMasterLineList[lineNumberIndex].wm_CML_IMPLEMENTED_CASE_ID;
      this.caseLineInfoData.wm_CML_IMPLEMENTED_CASE_VRSN_ID = this.theCaseMasterLineList[lineNumberIndex].wm_CML_IMPLEMENTED_CASE_VRSN_ID;
      this.caseLineInfoData.wm_CM_IMPLEMENTED_CASE_ID = this.theCaseMasterLineList[lineNumberIndex].wm_CM_IMPLEMENTED_CASE_ID;
      this.caseLineInfoData.wm_CM_IMPLEMENTED_CASE_VERSION_ID = this.theCaseMasterLineList[lineNumberIndex].wm_CM_IMPLEMENTED_CASE_VERSION_ID;
      this.caseLineInfoData.program_OF_RECORD_ID = this.theCaseMasterLineList[lineNumberIndex].program_OF_RECORD_ID;
      this.caseLineInfoData.wm_CHECK_NPOR = this.theCaseMasterLineList[lineNumberIndex].wm_CHECK_NPOR;
      this.caseLineInfoData.LINESUBLINESEQVIR = CaseUtils.formatLineNumber(lineNum);
      this.caseLineInfoData.wm_USER_CASE_SUBLINE_TX = sublineNum;
      this.caseLineInfoData.change_ACTION_CD = 'A';
      this.caseLineInfoData.change_ACTION_TITLE_NM = 'Added';
      this.caseLineInfoData.wm_CASE_LINE_LOI_IN = this.theCaseMasterLineList[lineNumberIndex].wm_CASE_LINE_LOI_IN;
      this.caseLineInfoData.wm_CASE_VERSION_STATUS_CD = this.caseLineRelatedInfoData.case_VERSION_STATUS_CD;
      this.caseLineInfoData.case_USAGE_INDICATOR_CD = this.caseRelatedInfoData.case_USAGE_INDICATOR_CD;
      this.caseLineInfoData.entityStatus = DsamsConstants.ENT_NEW.toString();
      this.caseLineInfoData.status = DsamsConstants.ENT_NEW.toString();
      this.caseLineInfoData.isDataChanged = true;
      this.caseUIService.setCaseLineInfoValues(this.caseLineInfoData);
      //begin DSAMS-5269-03/22 DH
      this.getLineSublineRefData.populateReferenceDataForCaseLine();
      this.getLineSublineRefData.setResetDynamicRefList(true);
      //end DSAMS-5269-03/22 DH
      this.caseUIService.setIsLineTabDisabled(false);
      this.router.navigate(['/case/line-dashboard', '1', 'Subline']);
      // this.sendTabId();
      // this.sendTabLabelId("Subline");
      //this.caseLineInfoData.isEntityNew = false; //reset
    } else {
      MessageMgr.swalFire({
        text: 'The selected DSAMS function is only available for the document being in Development status.',
        icon: 'error',
        width: 400,
        focusConfirm: true,
        confirmButtonText: 'OK'
      })
    }
  }

  // convertSublineNumToInt(line: number): number {
  //   var index: number = 0;
  //   for (var x=0; x < this.theLineSublineListArray.length; x++){
  //     if (this.theLineSublineListArray[x].wm_USER_CASE_LINE_NUMBER_ID <= CaseUtils.formatLineNumber(line)){
  //           index = index + 1;
  //     }
  //   }
  //   return index;
  // }

  convertlineNumToInt(line: number): number {
    var index: number = 0;
    for (var x = 0; x < this.theCaseMasterLineList.length; x++) {
      if (this.theCaseMasterLineList[x].wm_USER_CASE_LINE_NUMBER_ID < CaseUtils.formatLineNumber(line)) {
        index = index + 1;
      }
    }
    return index;
  }

  //switch to the tab ID
  sendTabId() {
    //send new Line tab index as output
    this.sendTabIndex.emit(this.tabId);
  }

  sendTabLabelId(pLabel: string) {
    //send new Line tab label as output
    this.sendTabLabel.emit(pLabel);
  }

  //set up data for adding new line 
  menuNewLineButtonOnClick() {
    if (this.caseLineRelatedInfoData.case_VERSION_STATUS_CD.toUpperCase() == 'D') {
      this.initializeCaseLineInfoData();
      this.caseLineInfoData.LINESUBLINESEQVIR = CaseUtils.formatLineNumber(this.generateLineNumber());
      this.lastLineNumber = this.caseLineInfoData.LINESUBLINESEQVIR;
      if (parseInt(this.lastLineNumber) > 999) {
        MessageMgr.swalFire({
          text: 'Line Number cannot exceed 999',
          icon: 'error',
          width: 400,
          focusConfirm: true,
          confirmButtonText: 'OK'
        })
      } else {
        this.caseLineInfoData.case_ID = this.aCaseRelatedInfoType.case_ID;
        this.caseLineInfoData.change_ACTION_CD = 'A';
        this.caseLineInfoData.change_ACTION_TITLE_NM = 'Added';
        this.caseLineInfoData.wm_CASE_VERSION_STATUS_CD = this.caseLineRelatedInfoData.case_VERSION_STATUS_CD;
        LineUtils.transferCMLDataToCL(this.caseLineInfoData, this.caseRelatedInfoData);
        this.caseLineInfoData.entityStatus = DsamsConstants.ENT_NEW.toString();
        this.caseLineInfoData.status = DsamsConstants.ENT_NEW.toString();
        this.caseLineInfoData.isDataChanged = true;
        this.caseLineInfoData.isTemporarilySkipSavePrompt = true;
        this.caseLineInfoData.isDataChanged = true;
        this.caseUIService.setCaseLineInfoValues(this.caseLineInfoData);
        //begin DSAMS-5269-03/22 DH
        this.getLineSublineRefData.populateReferenceDataForCaseLine();
        this.getLineSublineRefData.setResetDynamicRefList(true);
        //end DSAMS-5269-03/22 DH
        this.caseUIService.setIsLineTabDisabled(false);
        this.router.navigate(['/case/line-dashboard', '1', 'Line']);
      }
    } else {
      MessageMgr.swalFire({
        text: 'The selected DSAMS function is only available for the document being in Development status.',
        icon: 'error',
        //showConfirmButton: true,
        width: 400,
        focusConfirm: true,
        confirmButtonText: 'OK'
      })
    }
  }

  resetFormValues() {
    this.lineFormCtl.reset();
    this.subLineFormCtl.reset();
    this.subLineSubFormCtl.reset();
  }

  // Open case line detail tab for line menu selection
  caseLineOkButtonOnClick(pVal: any) {
    var lineNumber: string;
    if (this.lineFormCtl)
      lineNumber = this.lineFormCtl.value
    else {
      if (pVal.value !== null && pVal.value !== undefined)
        lineNumber = pVal.value;
    }
    if (lineNumber !== null && lineNumber !== undefined) {
      for (let i = 0; i < this.theCaseMasterLineListArray.length; i++) {
        if (this.theCaseMasterLineListArray[i].wm_USER_CASE_LINE_NUMBER_ID == lineNumber) {
          this.aCaseRelatedInfoType.case_MASTER_LINE_ID =
            this.theCaseMasterLineListArray[i].case_MASTER_LINE_ID;
          i = this.theCaseMasterLineListArray.length++;
        }
      }
      this.getCaseLineData(true);
    }
  }

  // Open case line detail tab for subline menu selection
  caseSublineOkButtonOnClick(pLineVal: any, pSublineVal: any) {
    for (let i = 0; i < this.theCaseMasterSublineListArray.length; i++) {
      if (this.theCaseMasterSublineListArray[i].wm_USER_CASE_LINE_NUMBER_ID == this.subLineFormCtl.value &&
        this.theCaseMasterSublineListArray[i].wm_USER_CASE_SUBLINE_TX == this.subLineSubFormCtl.value) {
        for (let index = 0; index < this.theLineSublineListArray.length; index++) {
          if (this.theLineSublineListArray[index].wm_PARENT_CASE_MASTER_LINE_ID == this.theCaseMasterSublineListArray[i].case_MASTER_LINE_ID &&
            this.theLineSublineListArray[index].wm_USER_CASE_SUBLINE_TX == this.theCaseMasterSublineListArray[i].wm_USER_CASE_SUBLINE_TX) {
            this.aCaseRelatedInfoType.case_MASTER_LINE_ID =
              this.theLineSublineListArray[index].case_MASTER_LINE_ID;
            index = this.theLineSublineListArray.length + 99;
          }
        }
        this.aCaseRelatedInfoType.wm_USER_CASE_SUBLINE_TX = this.subLineSubFormCtl.value;
        i = this.theCaseMasterSublineListArray.length + 999;
      }
    }
    this.getCaseLineData(false);
  }

  cancelButtonOnClick() {
    this.resetFormValues();
  }

  /* Load the data source */
  initializeCaseSearchResultsArray() {
    let currSearchResultList: Array<any> = <Array<any>>(this.caseSearchResultData);
    if (!!currSearchResultList) {
      let currSearchResultItem: any;
      const aCaseResultsRowIndex: number = currSearchResultList.length;
      for (let i = 0; i < aCaseResultsRowIndex; i++) {
        currSearchResultItem = Object.assign({ rowNum: (i + 1), isExpanded: false }, currSearchResultList[i]);
        currSearchResultList[i] = currSearchResultItem;
      }
      this.dataCaseSearchResults = new MatTableDataSource(currSearchResultList);
    }
    /* 
      Set the page size to display while retaining the number of records
      retrieved from the submitSearch()
    */
    setTimeout(() => {
      this.paginator.pageSize = this.pageLength;
      this.paginator.length = this.recordLength;
      this.paginator.pageIndex = this.pageCount;
      this.paginator.pageSizeOptions = this.pageOptions;
      this.dataCaseSearchResults.paginator = this.paginator
    });

    /* 
       If no cases are found then set this so a
       message can be display to the user
    */
    this.noCasesFoundInd = (!currSearchResultList || currSearchResultList.length == 0);

  }

  // This method to get a list of cases, then select a case and then return all the versions for that case.
  initializeCaseVersionArrayIndex(index) {
    let currSearchResultListForVersions: Array<any> = <Array<any>>(this.caseSearchResultData);
    let currCaseVersionItem: any;
    const aCaseResultsRowIndex: number = currSearchResultListForVersions.length;

    // List of Cases    
    for (let i = 0; i < aCaseResultsRowIndex; i++) {
      currCaseVersionItem = Object.assign({ rowNum: (i + 1), isExpanded: false }, currSearchResultListForVersions[i]);
      currSearchResultListForVersions[i] = currCaseVersionItem;
    }

    // Select a particular case to get the versions
    //let currSearchResultListForVersions1: Array<any> = <Array<any>>(currSearchResultListForVersions[index]);
    let currCaseMaster: any = currSearchResultListForVersions[index];
    // Retreive the case versions
    let currSearchResultListForVersions2: Array<any> = <Array<any>>(currCaseMaster["caseVersionList"]);
    this.aCaseVersionRowIndex = currSearchResultListForVersions2.length;

    // Set the row number to what the user cliecked.
    this.currentlySelectedRowNum = index + 1;

    for (let i = 0; i < this.aCaseVersionRowIndex; i++) {
      currCaseVersionItem = Object.assign({ rowNum: (i + 1), isExpanded: false }, currSearchResultListForVersions2[i]);
      currCaseVersionItem["customer_ORGANIZATION_ID"] = this.aCaseLineRelatedInfoType.case_CUSTOMER_ORGANIZATION_ID;
      currCaseVersionItem.case_MASTER_STATUS_CD = currCaseMaster.case_MASTER_STATUS_CD;
      currSearchResultListForVersions2[i] = currCaseVersionItem;
    }
    this.dataCaseVersions = new MatTableDataSource(currSearchResultListForVersions2);
  }

  public fetchCaseSearchResultsData() {
    if (this._reloadData) {
      // Subscribe to the service.
      if (this._fetchSearchSubscription == null) {
        this._fetchSearchSubscription =
          this.caseRestService
            .caseSearchReplaySubject
            .subscribe((data: any) => {
              this.caseSearchResultData = data;
              //Retrieving case search results
              this.initializeCaseSearchResultsArray();
              //Clean up first 
              sessionStorage.removeItem('goback');
              sessionStorage.setItem('goback', JSON.stringify(this.caseSearchResultData));
              this.showProgressSpinner = false;
              this.resetPrevCaseIndex();
            },
              err => {
                this.showProgressSpinner = false;
                CaseUtils.ReportHTTPError(err, "Case Search");
              }
            );
      }
      this._reloadData = false;
    }
  }

  // Jump to Case Detail when the user clicks the Case Detail link.
  openCaseDetail(pCaseId: number,
    pCaseVersionId: number,
    pCustomerOrganizationId: string,
    pCaseVersionTypeCd: string,
    pSecurityAssistanceProgramCd: string,
    pImplemetingAgencyId: string,
    pCustomerRequestId: number,
    pIsEditable: boolean) {
    const caseRequestParamsType: CaseRequestParamsType = {
      caseId: pCaseId,
      caseVersionId: pCaseVersionId,
      customerOrganizationId: pCustomerOrganizationId,
      caseVersionTypeCd: pCaseVersionTypeCd,
      securityAssistanceProgramCd: pSecurityAssistanceProgramCd,
      implementingAgencyId: pImplemetingAgencyId,
      customerRequestId: pCustomerRequestId,
      isEditable: false
    }
    // Notify the subscribers of case detail selection.
    this.caseUIService.caseDetailSelected.next(caseRequestParamsType);
  }

  //DSAMS 5390 04/22 DH - use this object values as secondary data 
  setUpLinkCaseVersionInfoData(pCaseRelatedInfoType: any, pCaseLineRelatedInfoType: any) {
     let linkCaseDataObject: LinkCaseDataIface = {
      serviceDbId: CaseUtils.getServiceDatabaseId(),
      case_VERSION_ID: pCaseLineRelatedInfoType.case_VERSION_ID,
      case_VERSION_STATUS_CD: pCaseLineRelatedInfoType.case_VERSION_STATUS_CD,
      user_CASE_ID: pCaseLineRelatedInfoType.user_CASE_ID,
      case_ID: pCaseRelatedInfoType.case_ID,
      case_MASTER_STATUS_CD: pCaseRelatedInfoType.case_MASTER_STATUS_CD,
      case_USAGE_INDICATOR_CD: pCaseRelatedInfoType.case_USAGE_INDICATOR_CD,
    }
    localStorage.setItem(LinkCaseDataClass.linkCaseVersionInfoData, LinkCaseDataClass.setTheLinkCaseDataObject(linkCaseDataObject));
   }

  onLineListClick(){
    //DSAMS-5269 DH 03/2022 - preload reference data when line list button is clicked for less error exposure
    this.getLineSublineRefData.populateReferenceDataForCaseLine();
    this.getLineSublineRefData.setResetDynamicRefList(true);
  }

  // Method to handle click event on Search results table row
  getMainRow(expandedElement: any, row: any, index) {
    // Account for the page you're on and LPP for adjusting the index.
    const realIndex = index + (this.paginator.pageIndex * this.paginator.pageSize);
    // Flip the panel to expand/collapsed.
    row.isExpanded = (this._prevCaseIndex == realIndex) ? !(row.isExpanded) : true;
    //console.log('parent',row,realIndex)
    if (!!expandedElement) {
      //This aCaseRelatedInfoType object is being utilized by Case Line List tab window
      this.aCaseRelatedInfoType = {
        case_ID: row.case_ID,
        case_MASTER_LINE_ID: row.case_MASTER_LINE_ID,
        case_USAGE_INDICATOR_CD: row.case_USAGE_INDICATOR_CD,
        case_MASTER_STATUS_CD: row.case_MASTER_STATUS_CD,
        case_CATEGORY_CD: row.case_CATEGORY_CD,
        case_CUSTOMER_TYPE_CD: row.customer_TYPE_CD,
        wm_CASE_VERSION_TYPE_CD: row.case_VERSION_TYPE_CD
      }
      //This aCaseLineRelatedInfoType object is being utilized by Case Line Detail/Delivery tabs window
      this.aCaseLineRelatedInfoType = {
        user_CASE_ID: row.user_CASE_ID,
        case_VERSION_STATUS_CD: row.case_VERSION_STATUS_CD,
        case_CUSTOMER_ORGANIZATION_ID: row.customer_ORGANIZATION_ID,
        implementing_AGENCY_ID: row.implementing_AGENCY_ID,
        security_ASSISTANCE_PROGRAM_CD: row.security_ASSISTANCE_PROGRAM_CD,
        customer_REQUEST_ID: row.customer_REQUEST_ID,
      }
      this.initializeLinkCaseDataObject(expandedElement);
      if (row.isExpanded) {
        this.initializeCaseVersionArrayIndex(realIndex);
      }
      else {
        this.resetDataCaseVersions();
      }
      this.caseUIService.setCaseRelatedInfoValues(this.aCaseRelatedInfoType);
      this.caseUIService.setCaseLineRelatedInfoValues(this.aCaseLineRelatedInfoType);
      this.setUpLinkCaseVersionInfoData(this.aCaseRelatedInfoType, this.aCaseLineRelatedInfoType);
      this.onLineListClick();
      this._prevCaseIndex = realIndex;
      console.log(JSON.parse(JSON.stringify(this.aCaseRelatedInfoType)));
    }
  }


  // Notify the parent container of the page event.
  onCaseSearchPaginate(pPageEvent: PageEvent) {
    // Collapse all expanded case masters.
    this.resetPrevCaseIndex();
    this.resetDataCaseVersions();

    let searchPageEvent: ISearchPageEvent = {
      pageEvent: pPageEvent,
      pageSizeOptions: "[25,50,75,100]"
    };
    this.caseUIService.caseSearchPaginate.next(searchPageEvent);
  }


  setupCaseRelatedInfo(row: any) {
    //This aCaseRelatedInfoType object is being utilized by Case Line List tab window
    if (this.aCaseRelatedInfoType != null) {
      let tmpCaseRelatedInfoType = JSON.parse(JSON.stringify(this.aCaseRelatedInfoType));
      this.aCaseRelatedInfoType.working_CASE_VERSION_ID = row.case_VERSION_ID;
      this.aCaseRelatedInfoType.case_VERSION_ID = row.case_VERSION_ID;
      this.aCaseRelatedInfoType.working_CASE_ID = row.case_ID;
      this.aCaseRelatedInfoType.offer_EXPIRATION_DT = row.offer_EXPIRATION_DT;
      this.aCaseRelatedInfoType.implementing_AGENCY_ID = row.implementing_AGENCY_ID;
      this.aCaseRelatedInfoType.case_USAGE_INDICATOR_CD = tmpCaseRelatedInfoType.case_USAGE_INDICATOR_CD;
      this.aCaseRelatedInfoType.case_MASTER_STATUS_CD = tmpCaseRelatedInfoType.case_MASTER_STATUS_CD;
      if (this.aCaseLineRelatedInfoType) {
        this.aCaseLineRelatedInfoType.case_ID = row.case_ID;
        this.aCaseLineRelatedInfoType.case_VERSION_ID = row.case_VERSION_ID;
        this.aCaseLineRelatedInfoType.case_VERSION_TYPE_CD = row.case_VERSION_TYPE_CD;
        this.aCaseLineRelatedInfoType.case_VERSION_NUMBER_ID = row.case_VERSION_NUMBER_ID;
        this.aCaseLineRelatedInfoType.case_VERSION_STATUS_CD = row.case_VERSION_STATUS_CD;
        this.aCaseLineRelatedInfoType.implementing_AGENCY_ID = row.implementing_AGENCY_ID;
        this.aCaseLineRelatedInfoType.security_ASSISTANCE_PROGRAM_CD = row.security_ASSISTANCE_PROGRAM_CD;
        this.aCaseLineRelatedInfoType.customer_REQUEST_ID = row.customer_REQUEST_ID;
      }
    }
    else {
      this.aCaseRelatedInfoType = {
        working_CASE_VERSION_ID: row.case_VERSION_ID,
        case_VERSION_ID : row.case_VERSION_ID,
        working_CASE_ID: row.case_ID,
        offer_EXPIRATION_DT: row.offer_EXPIRATION_DT,
        implementing_AGENCY_ID: row.implementing_AGENCY_ID,
        case_MASTER_STATUS_CD: row.case_MASTER_STATUS_CD,
        case_USAGE_INDICATOR_CD : row.case_USAGE_INDICATOR_CD,
      }
      this.aCaseLineRelatedInfoType = {
        case_ID: row.case_ID,
        case_VERSION_ID : row.case_VERSION_ID,
        case_VERSION_TYPE_CD : row.case_VERSION_TYPE_CD,
        case_VERSION_NUMBER_ID: row.case_VERSION_NUMBER_ID,
        case_VERSION_STATUS_CD: row.case_VERSION_STATUS_CD,
        implementing_AGENCY_ID: row.implementing_AGENCY_ID,
        security_ASSISTANCE_PROGRAM_CD: row.security_ASSISTANCE_PROGRAM_CD,
        customer_REQUEST_ID: row.customer_REQUEST_ID
      }
    }
  }

  // Method to handle click event on Search results case version table row
  getRow(row: any, index) {   
    //populate the dropdown list fields
    this.getCasMasterLineListData(row.case_ID, row.case_VERSION_ID);
    this.aCaseRelatedInfoType.wm_CASE_VERSION_TYPE_CD = row.case_VERSION_TYPE_CD;

    this.setupCaseRelatedInfo(row); 
    this.caseUIService.setCaseLineRelatedInfoValues(this.aCaseLineRelatedInfoType);
    this.caseUIService.setCaseRelatedInfoValues(this.aCaseRelatedInfoType);
  }

  //DSAMS-5346 DH 04/22
  initializeLinkCaseDataObject(pRow: any) {
    this.linkCaseDataObject = {
      case_ID: pRow.case_ID,
      case_VERSION_ID: 0,
      serviceDbId: this.serviceDbId,
      case_MASTER_STATUS_CD: pRow.case_MASTER_STATUS_CD,
    }
  }

  //DSAMS-5346 DH 04/22
  onLinkCaseDataClick(pRow: any) {
    if (this.linkCaseDataObject.case_VERSION_ID == 0) {
      this.linkCaseDataObject.case_VERSION_ID = pRow.case_VERSION_ID;
      this.linkCaseDataObject.case_VERSION_STATUS_CD = pRow.case_VERSION_STATUS_CD;
      this.linkCaseDataObject.case_MASTER_STATUS_CD = pRow.case_MASTER_STATUS_CD;
      this.linkCaseDataObject.security_ASSISTANCE_PROGRAM_CD = pRow.security_ASSISTANCE_PROGRAM_CD;
      this.linkCaseDataObject.case_VERSION_TYPE_CD = pRow.case_VERSION_TYPE_CD;
      this.linkCaseDataObject.case_VERSION_NUMBER_ID = pRow.case_VERSION_NUMBER_ID;
      this.linkCaseDataObject.user_CASE_ID = this.aCaseLineRelatedInfoType.user_CASE_ID;
      this.linkCaseDataObject.customer_ORGANIZATION_ID = this.aCaseLineRelatedInfoType.case_CUSTOMER_ORGANIZATION_ID;
      this.linkCaseDataObject.wm_CASE_VERSION_TYPE_CD = pRow.case_VERSION_TYPE_CD;
      this.linkCaseDataObject.case_USAGE_INDICATOR_CD = 
         this.aCaseRelatedInfoType.case_USAGE_INDICATOR_CD?this.aCaseRelatedInfoType.case_USAGE_INDICATOR_CD:pRow.case_USAGE_INDICATOR_CD;
      this.linkCaseData = LinkCaseDataClass.setTheLinkCaseDataObject(this.linkCaseDataObject);
    }
  }

  onClickNoteNavigation(pElement: any) {
    // Make sure correct fields are checked.
    let tmpCaseRelatedInfoType: CaseRelatedInfoType = JSON.parse(JSON.stringify(this.aCaseRelatedInfoType));
    tmpCaseRelatedInfoType.case_ID = pElement.case_ID;
    tmpCaseRelatedInfoType.case_VERSION_ID = pElement.case_VERSION_ID;
    tmpCaseRelatedInfoType.working_CASE_VERSION_ID = pElement.case_VERSION_ID;
    //
    let tmpCaseLineRelatedInfoType: CaseLineRelatedInfoType = JSON.parse(JSON.stringify(this.aCaseLineRelatedInfoType));
    tmpCaseLineRelatedInfoType.case_VERSION_STATUS_CD = pElement.case_VERSION_STATUS_CD;
    tmpCaseLineRelatedInfoType.case_VERSION_TYPE_CD = pElement.case_VERSION_TYPE_CD;
    tmpCaseLineRelatedInfoType.case_VERSION_NUMBER_ID = pElement.case_VERSION_NUMBER_ID;
    tmpCaseLineRelatedInfoType.security_ASSISTANCE_PROGRAM_CD = pElement.security_ASSISTANCE_PROGRAM_CD;
    tmpCaseLineRelatedInfoType.case_VERSION_ID = pElement.case_VERSION_ID;
    //console.log('aCaseLineRelatedInfoType',tmpCaseLineRelatedInfoType)
    //console.log('aCaseRelatedInfoType',this.aCaseRelatedInfoType)
    this.caseUIService.setCaseRelatedInfoValues(tmpCaseRelatedInfoType);
    this.caseUIService.setCaseLineRelatedInfoValues(tmpCaseLineRelatedInfoType);
    this.caseUIService.noteListNav.next(false);  // Make sure edit toggle starts in the off position.
  }

  onClickAttachmentNavigation(pElement: any) {
    // Make sure correct fields are checked.
    let tmpCaseRelatedInfoType: CaseRelatedInfoType = JSON.parse(JSON.stringify(this.aCaseRelatedInfoType));
    tmpCaseRelatedInfoType.case_ID = pElement.case_ID;
    tmpCaseRelatedInfoType.case_VERSION_ID = pElement.case_VERSION_ID;
    tmpCaseRelatedInfoType.working_CASE_VERSION_ID = pElement.case_VERSION_ID;
    let tmpCaseLineRelatedInfoType: CaseLineRelatedInfoType = JSON.parse(JSON.stringify(this.aCaseLineRelatedInfoType));
    tmpCaseLineRelatedInfoType.case_VERSION_STATUS_CD = pElement.case_VERSION_STATUS_CD;
    tmpCaseLineRelatedInfoType.case_VERSION_TYPE_CD = pElement.case_VERSION_TYPE_CD;
    tmpCaseLineRelatedInfoType.case_VERSION_NUMBER_ID = pElement.case_VERSION_NUMBER_ID;
    tmpCaseLineRelatedInfoType.security_ASSISTANCE_PROGRAM_CD = pElement.security_ASSISTANCE_PROGRAM_CD;
    tmpCaseLineRelatedInfoType.case_VERSION_ID = pElement.case_VERSION_ID;
    this.caseUIService.setCaseRelatedInfoValues(tmpCaseRelatedInfoType);
    this.caseUIService.setCaseLineRelatedInfoValues(tmpCaseLineRelatedInfoType);
    //this.caseUIService.noteListNav.next(false);  // Make sure edit toggle starts in the off position.
  }
}