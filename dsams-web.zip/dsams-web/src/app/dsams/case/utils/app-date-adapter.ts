import { NativeDateAdapter } from '@angular/material';
import { MatDateFormats } from '@angular/material/core';
import { Injectable } from '@angular/core';

/**
 * This class will allow you to format dates on the UI as the proper format
 * (mm/dd/yyyy), with leading zeroes.
 * 
 * Author: CBanta
 */

 @Injectable({
    providedIn: 'root'
  })
  
export class AppDateAdapter extends NativeDateAdapter {
  /**
   * Format the date on the UI in the proper format (mm/dd/yyyy with leading zeroes)
   * @param date Date field you want to convert.
   * @param displayFormat Format object to denote mm/dd/yyyy.
   */
  format(date: Date, displayFormat: Object): string {
    if (displayFormat === 'input') {
      let day: string = date.getDate().toString();
      day = +day < 10 ? '0' + day : day;
      let month: string = (date.getMonth() + 1).toString();
      month = +month < 10 ? '0' + month : month;
      let year = date.getFullYear();
      return `${month}/${day}/${year}`;
    }
    return date.toDateString();
  }
}

/**
 * This is the formatter that specified mm/dd/yyyy.
 */
export const APP_DATE_FORMATS: MatDateFormats = {
  parse: {
    dateInput: { month: 'short', year: 'numeric', day: 'numeric' },
  },
  display: {
    dateInput: 'input',
    monthYearLabel: { year: 'numeric', month: 'numeric' },
    dateA11yLabel: { year: 'numeric', month: 'long', day: 'numeric'
    },
    monthYearA11yLabel: { year: 'numeric', month: 'long' },
  }
};