import { ICaseNoteParameter } from "./dto/case-note-parameter";
import { ICaseVersion } from "./dto/icase-version";
import { INoteType } from "./dto/note-type";
import { NoteModel } from "./note-model";

export interface CaseNoteModel {
    entityName?: string;
    status?: string;

    case_ID?: number,
    note_ID?: number,
    case_VERSION_ID?: number,
    case_NOTE_ID?: number,
    note_VERSION_ID?: number,
    user_NOTE_NUMBER_ID?: number,
    ipc_CATEGORY_CD?:string,
    change_ACTION_CD?:string,
    assignment_IN?:boolean,
    theNoteId?:NoteModel,
    theNoteTypeCd?: INoteType,
    theCaseVersionId?: ICaseVersion,
    caseNoteParameterList?: ICaseNoteParameter[]
}