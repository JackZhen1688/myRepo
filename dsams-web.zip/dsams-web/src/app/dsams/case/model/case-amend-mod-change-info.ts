export interface CaseAmendModChangeInfo {
    typeCd:string,
    caseId:number,
    verNumId:number,
    versionId:number
}