
/* Author: David HUynh
   Date:   05/06/2020
   Will add more attributes like case Line, Version, Milestone, etc..
   when needed */
export interface CaseRelatedInfoType {
    // This data object is being used for on-screen display
    // CASE_LINE entity for dealing with non-legacy Rest API call

    //required entity attibutes
    entityName?: string;
    status?: string;
    //This entityStatus attribute is being utilized for making use 
    // of existing DSAMS legacy methods on delete/save 
    entityStatus?: string;
    case_ID?: number,
    case_MASTER_LINE_ID?: number,
    working_CASE_ID?: number,
    working_CASE_VERSION_ID?: number,

    activity_ID?: string;
    activity_NM?: string;
    apply_PROFILE_LINE_CD?: string;
    article_DESCRIPTION_TX?: string;
    acquisition_VALUE_AM?: string;
    budget_APPROPRIATION_CD?: string;
    budget_APPROPRIATION_TITLE_NM?: string;
    calendar_YEAR_ID?: string;
    case_LINE_AVAILABILITY_LEAD_QY?: string;
    case_LINE_DEL_SET_Q1_QY?: string;
    case_LINE_DEL_SET_Q2_QY?: string;
    case_LINE_DEL_SET_Q3_QY?: string;
    case_LINE_DEL_SET_Q4_QY?: string;
    case_LINE_PAY_PERIOD_START_QY?: string;
    case_LINE_PAY_PERIOD_END_QY?: string;
    case_LINE_PERIOD_START_QY?: string;
    case_LINE_PERIOD_END_QY?: string;
    case_LINE_ITEM_QY?: string;
    case_LINE_NOTE_QY?: string;
    case_LINE_ATTACHMENT_QY?: string;
    case_LINE_SHIPMENT_TX?: string;
    case_LINE_MARK_FOR_DELETION_IN?: string;
    case_USAGE_INDICATOR_CD?: string,
    case_DESIGNATOR?: string,
    case_MASTER_STATUS_CD?: string,
    case_STATUS_TITLE_NM?: string,
    case_VERSION_ID?: string,
    case_CUSTOMER_TYPE_CD?: string;
    case_CATEGORY_CD?: string;
    change_ACTION_CD?: string,
    change_ACTION_TITLE_NM?: string,
    condition_CD?: string;
    condition_TITLE_NM?: string;
    customer_ORGANIZATION_ID?: string,
    customer_NICKNAME_NM?: string;
    estimated_DELIVERY_END_DT?: string;
    estimated_DELIVERY_DT?: string;
    equipment_TYPE_TITLE_NM?: string;
    generic_CD?: string;
    implementing_AGENCY_ID?: string,
    inventory_VALUE_AM?: string;
    issue_UNIT_CD?: string;
    line_MANAGER_ID?: string;
    line_MANAGER_TITLE_NM?: string;
    line_PURPOSE_CD?: string;
    line_PURPOSE_TITLE_NM?: string;
    major_DEFENSE_EQUIPMENT_CD?: string;
    mde_SME_CD?: string;
    missile_TECH_CNTRL_REGIME_ID?: string;
    mtcr_TITLE_NM?: string;
    military_ARTICLE_SERVICE_CD?: string;
    national_STOCK_NUMBER_ID?: string;
    offer_EXPIRATION_DT?: string;
    operating_AGENCY_CD?: string;
    operating_AGENCY_TITLE_NM?: string;
    other_NATIONAL_STOCK_NUMBER_ID?: string;
    other_PART_NUMBER_IN?: boolean;
    part_NUMBER_IN?: boolean;
    percent_STOCK_RT?: string;
    prior_YEAR_AM?: number;
    recalculation_IN?: boolean;
    security_ASSISTANCE_PROGRAM_CD?: string,
    service_DB_ID?: string,
    shipment_STATUS_ID?: string,
    stock_ON_ORDER_COST_AM?: string;
    stock_ON_HAND_COST_AM?: string;
    supporting_ORGANIZATION_ID?: string;
    support_ORGANIZATION_TITLE_NM?: string;
    case_LINE_ITEM_DESCRIPTION_TX?: string;
    supply_SOURCE_NUMBER_ID?: string;
    supply_SOURCE_TITLE_NM?: string;
    training_NOTE_CD?: string;
    training_NOTE_NM?: string;
    title_NM?: string; //shipment status title
    total_ABOVE_LINE_COST_AM?: string;
    unit_ABOVE_LINE_COST_AM?: string;
    program_OF_RECORD_ID?: number;
    //reference tables
    caseLineAssistanceTypeList?: ifaceCaseLineAssistanceTypeEntity[];
    caseLineDeliveryItemList?: ifaceCaseLineDeliveryItemEntity[];
    caseLineDeliveryTermList?: ifaceCaseLineDeliveryTermEntity[];
    caseLineOfferReleaseList?: ifaceCaseLineOfferReleaseEntity[];

    //window mapping attributes 
    //for Case master Line attributes
    wm_USER_CASE_LINE_NUMBER_ID?: string,
    wm_USER_CASE_SUBLINE_TX?: string,
    wm_CASE_LINE_LOI_IN?: boolean,
    wm_CML_SERVICES_COMPLETE_IN?: boolean,
    wm_EXCLUSION_IN?: boolean,
    wm_CASE_LINE_REMARK_QY?: string;
    wm_CML_CLOSURE_STATUS_CD?: string;
    wm_PARENT_CASE_ID?: number,
    wm_PARENT_CASE_MASTER_LINE_ID?: number,
    wm_CASE_VERSION_TYPE_CD?: string,
    wm_CASE_VERSION_STATUS_CD?: string,
    wm_CM_CUSTOMER_ORGANIZATION_ID?: string,
    wm_PARENT_CHANGE_ACTION_CD?: string,
    wm_PARENT_IS_PRICED?: boolean,
    wm_LINE_IS_PRICED?: boolean,
    //for non-entity attributes
    wm_HAS_SUBLINES?: boolean,
    wm_HAS_SUBLINES_A?: boolean,
    wm_HAS_SUBLINES_PRICED?: boolean,
    wm_PARENT_IS_MDE?: boolean,
    wm_CML_IMPLEMENTED_CASE_ID?: number,
    wm_CML_IMPLEMENTED_CASE_VRSN_ID?: number,    
    wm_CM_IMPLEMENTED_CASE_ID?: number,
    wm_CM_IMPLEMENTED_CASE_VERSION_ID?: number,   
    wm_POST_SAVE_MESSAGES?: Array<string>,
    wm_CHECK_NPOR?: boolean,
    wm_SaveCL?: boolean,
    wm_SaveCML?: boolean,
    isEntityNew?: boolean;
    isLineNumberChanged?: boolean;
    isDataChanged?: boolean,
    isTemporarilySkipSavePrompt?: boolean,
    isOfferReleaseValid?: boolean,
    isDeliveryTermValid?: boolean,
    isDeliveryItemValid?: boolean,
    isLinePurposeDisabled?: boolean,
    doesCaseLineHaveSCM?: boolean,
    parent_MDE_SME_CD?: string;
    previousLPValue?:string,

    //for testing purpose only - do not use
    testLineList?: boolean;
}

export interface ifaceCaseLineAssistanceTypeEntity {
    // CASE_LINE_ASSISTANCE_TYPE entity
    //required entity attibutes
    entityName?: string;
    status?: string;
    assistance_TYPE_TITLE_TX?: string;
    case_ID?: number,
    case_MASTER_LINE_ID?: number,
    working_CASE_ID?: number,
    working_CASE_VERSION_ID?: number,
    assistance_TYPE_CD?: string,
    theAssistanceTypeCd?: ifaceAssistanceTypeEntity,
    isFieldDisabled?: boolean,
}

export interface ifaceAssistanceTypeEntity {
    // ASSISTANCE_TYPE entity
    assistance_TYPE_CD?: string,
    assistance_TYPE_TITLE_TX?: string,
    assistance_TYPE_DESCRIPTION_TX?: string,
}

export interface ifaceCaseLineDeliveryItemEntity {
    // CASE_LINE_DELIVERY_ITEM entity
    entityName?: string;
    status?: string;
    case_ID?: number,
    case_MASTER_LINE_ID?: number,
    working_CASE_ID?: number,
    working_CASE_VERSION_ID?: number,
    case_LINE_DELIVERY_ITEM_ID?: string,
    item_CD?: string,
    aCurrentCalendarYear?: number;
    bgColor?: string,
    isDeleteAllowed?: boolean;
    sumOfAllItemQuantities?: number;
    deleteBgColor?: string,
    caseLineDeliveryScheduleList?: ifaceCaseLineDeliveryScheduleEntity[];
}

export interface ifaceCaseLineDeliveryScheduleEntity {
    // CASE_LINE_DELIVERY_SCHEDULE entity
    entityName?: string;
    status?: string;
    case_ID?: number,
    case_MASTER_LINE_ID?: number,
    working_CASE_ID?: number,
    working_CASE_VERSION_ID?: number,
    calendar_YEAR_ID?: number,
    case_LINE_DELIVERY_ITEM_ID?: string,
    case_LINE_DELIVERY_SCHEDULE_ID?: number,
    case_LINE_DEL_SET_Q1_QY?: number,
    case_LINE_DEL_SET_Q2_QY?: number,
    case_LINE_DEL_SET_Q3_QY?: number,
    case_LINE_DEL_SET_Q4_QY?: number,
    deleteBgColor?: string,
    isDeleteAllowed?: boolean;
    isFieldModifiable?: boolean,
    isCLDSQ1Modifiable?: boolean,
    isCLDSQ2Modifiable?: boolean,
    isCLDSQ3Modifiable?: boolean,
    isCLDSQ4Modifiable?: boolean,
}

export interface ifaceCaseLineDeliveryTermEntity {
    // CASE_LINE_DELIVERY_TERM entity
    //required entity attibutes
    entityName?: string;
    status?: string;
    delivery_TERM_TITLE_NM?: string,
    case_ID?: number,
    case_MASTER_LINE_ID?: number,
    working_CASE_ID?: number,
    working_CASE_VERSION_ID?: number,
    sequence_CD?: number,
    delivery_TERM_ID?: string,
    theDeliveryTermId?: ifaceDeliveryTermEntity,
    isFieldDisabled?: boolean,
    deleteBgColor?: string,
    isDeleteAllowed?: boolean,
}

export interface ifaceDeliveryTermEntity {
    // DELIVERY_TERM entity
    delivery_TERM_ID?: string,
    delivery_TERM_TITLE_NM?: string,
    delivery_TERM_DESCRIPTION_TX?: string,
}

export interface ifaceCaseLineOfferReleaseEntity {
    // CASE_LINE_OFFER_RELEASE entity
    //required entity attibutes
    entityName?: string;
    status?: string;
    offer_RELEASE_TITLE_NM?: string,
    case_ID?: number,
    case_MASTER_LINE_ID?: number,
    working_CASE_ID?: number,
    working_CASE_VERSION_ID?: number,
    sequence_CD?: number,
    offer_RELEASE_ID?: string,
    theOfferReleaseId?: ifaceOfferReleaseEntity,
    isFieldDisabled?: boolean,
    deleteBgColor?: string,
    isDeleteAllowed?: boolean,
}

export interface ifaceOfferReleaseEntity {
    // OFFER_RELEASE entity
    offer_RELEASE_ID?: string,
    offer_RELEASE_TITLE_NM?: string,
    offer_RELEASE_DESCRIPTION_TX?: string,
}