import { ActivatedRoute } from "@angular/router";
import { DsamsConstants } from "../../dsams.constants";

//begin Jira DSAMS-5346 DH 04/22
export interface LinkCaseDataIface {
    case_ID: number,
    case_VERSION_ID: number,
    serviceDbId: string,
    case_VERSION_NUMBER_ID?: number,
    customer_ORGANIZATION_ID?: string,
    user_CASE_ID?: string,
    case_VERSION_STATUS_CD?: string,
    case_VERSION_TYPE_CD?: string,
    security_ASSISTANCE_PROGRAM_CD?: string,
    case_USAGE_INDICATOR_CD?: string,
    case_MASTER_STATUS_CD?: string,
    wm_CASE_VERSION_TYPE_CD?: string,
}

export class LinkCaseDataClass {
    //Set up individual link attributes for Case Details page per pre-existing implementation
    public static get linkCaseID(): string { return "caseId"; }
    public static get linkServiceDbId(): string { return "serviceDbId"; }
    public static get linkCaseVersionId(): string { return "caseVersionId"; }
    public static get linkCaseUsageIndCd(): string { return "caseUsageIndCd"; }
    public static get linkCaseVersionTypeCd(): string { return "caseVersionTypeCd"; }
    public static get linkUserCaseId(): string { return "userCaseId"; }
    //Set up common link object variables for use on other web pages
    public static get theLinkCaseData(): string { return "linkObj"; }
    public static get linkCaseVersionInfoData(): string { return "linkCaseVersionData"; }

    //DH: Encapsulate logic for getter and setter functions
    public static getTheLinkCaseData(activatedRoute: ActivatedRoute): LinkCaseDataIface {
        let linkCaseData: LinkCaseDataIface = JSON.parse(atob(activatedRoute.snapshot.queryParamMap.get(LinkCaseDataClass.theLinkCaseData)));
        if (linkCaseData.case_ID > 0) return (linkCaseData);
        else return (this.initalizeLinkCaseData());
    }
    public static getTheLinkCaseDataObject(pLinkCaseDataObject: string): LinkCaseDataIface {
        let linkCaseData: LinkCaseDataIface = JSON.parse(atob(pLinkCaseDataObject));
        if (linkCaseData.case_ID > 0) return (linkCaseData);
        else return (this.initalizeLinkCaseData());
    }
    public static setTheLinkCaseDataObject(linkCaseDataObject: LinkCaseDataIface): string {
        return (btoa(JSON.stringify(linkCaseDataObject)));
    }
    public static initalizeLinkCaseData(): LinkCaseDataIface {
        let aCaseVersionInfoData: LinkCaseDataIface = LinkCaseDataClass.getTheLinkCaseDataObject(localStorage.getItem(LinkCaseDataClass.linkCaseVersionInfoData));
        let aServiceDBId: string = aCaseVersionInfoData.serviceDbId ? aCaseVersionInfoData.serviceDbId : '';
        return ({
            case_ID: 0, case_VERSION_ID: 0,
            serviceDbId: sessionStorage.getItem(DsamsConstants.SESSION_SDB_ID) ? sessionStorage.getItem(DsamsConstants.SESSION_SDB_ID) : aServiceDBId,
        })
    }
    //for debugging purposes
    public static printLinkCaseData(pComponentName:string, pAdditionalObject:any="") {
        console.log(pComponentName,
            LinkCaseDataClass.getTheLinkCaseDataObject(localStorage.getItem(LinkCaseDataClass.linkCaseVersionInfoData)),
            pAdditionalObject);    
    }
}
//end Jira DSAMS-5346 DH 04/22
