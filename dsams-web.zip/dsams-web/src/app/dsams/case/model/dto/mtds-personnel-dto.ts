import { mtdsPersonnelModel } from "../mtds-personnel-model";

export interface mtdsPersonnelDto extends mtdsPersonnelModel {
    wm_status?: string;
    isDisabled?: boolean;   // Is row enabled?
    
    wm_MTDS_PERSON_BASE_COST_AM_SUM?: string;
    wm_TOTAL_COST?: string;

    tempStatus?: boolean;
}