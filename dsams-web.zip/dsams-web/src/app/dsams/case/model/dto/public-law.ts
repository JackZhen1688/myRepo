import { IServiceDatabase } from './service-database';

export interface IPublicLaw {
    entityName: string,
    status: number,    
    theServiceDbId: IServiceDatabase,
    inactive_IN: boolean,
    public_LAW_DESCRIPTION_TX: string,
    public_LAW_ID: string,
    public_LAW_TITLE_NM: string,
    service_DB_ID: string
}