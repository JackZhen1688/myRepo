export interface IServiceDatabase {
    entityName: string,
    status: number,
    service_DB_ID: string,
    inactive_IN: boolean,
    service_DB_DESCRIPTION_TX: string,
    service_DB_TITLE_NM: string
}