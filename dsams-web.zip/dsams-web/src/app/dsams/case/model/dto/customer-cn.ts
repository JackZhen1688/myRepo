export interface ICustomerCn {
    entityName: string,
    status: number,
    cong_nOTIFICATION_END_DT: Date,
    cong_NOTIFICATION_START_DT: Date,
    cong_NOTIFICATION_COMMENT_TX: string,
    cong_NOTIFICATION_DESC_TX: string,
    cong_NOTIFICATION_NUMBER_CD: string,
    cong_NOTIFICATION_TYPE_CD: string,
    customer_CN_ID: number,
    customer_ORGANIZATION_ID: string,
    implementing_AGENCY_ID: string,
    implementing_AGENCY_NM: string,
    inactive_IN: boolean,
    parent_CN_ID: number,
    prenotification_IN: boolean
}