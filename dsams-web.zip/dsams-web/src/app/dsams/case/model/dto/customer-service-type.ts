export interface ICustomerServiceType {
    entityName: string,
    status: number,
    customer_SERVICE_TYPE_ID: string,
    inactive_IN: boolean,
    service_DB_ID: string,
    service_TYPE_DESCRIPTION_TX: string,
    service_TYPE_TITLE_NM: string
}