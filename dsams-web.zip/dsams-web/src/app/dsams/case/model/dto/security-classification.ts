export interface ISecurityClassification {
    entityName: string,
    status: number,    
    security_CD: string,
    security_TITLE_NM: string,
    security_DESCRIPTION_TX:string,
    inactive_IN: boolean
}