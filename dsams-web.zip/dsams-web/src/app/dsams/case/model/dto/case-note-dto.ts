import { CaseNoteModel } from "../case-note-model";
import { FieldDisabledMap } from "../field-disabled-map";
import { ICaseNote } from "./case-note";

export interface CaseNoteDto extends CaseNoteModel {
    status?: string;
    wm_official_NOTE_TITLE_TX?:string,
    wm_RR_VISIBLE?: boolean,
    wm_REFRESH_DONE?: boolean,
    ent_status?:number,
    isRenumberAllowed?: boolean,
    theICaseNote?: ICaseNote,
    isFieldDisabled?: FieldDisabledMap
}