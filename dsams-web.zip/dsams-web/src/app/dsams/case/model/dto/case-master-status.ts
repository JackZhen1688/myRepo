export interface ICaseMasterStatus {
    entityName: string,
    status: number,    
    case_MASTER_STATUS_CD: string,
    case_STATUS_DESCRIPTION_TX: string,
    case_STATUS_TITLE_NM: string,
    inactive_IN: boolean
}