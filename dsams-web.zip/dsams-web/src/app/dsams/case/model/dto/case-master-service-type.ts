import { ICustomerServiceType } from './customer-service-type';

export interface ICaseMasterServiceType {
    entityName: string,
    status: number,
    case_ID: number,
    customer_SERVICE_ROLE_CD: string,
    customer_SERVICE_TYPE_ID: string,
    theCustomerServiceTypeId?: ICustomerServiceType,
    businessRuleMap?: Map<string,string>
}