import { IServiceDatabase } from './service-database';

export interface ISaleTerm {
    entityName: string,
    status: number,
    theServiceDbId: IServiceDatabase,
    inactive_IN: boolean,
    sale_TERM_APPLICABLE_LAW_NM: string,
    sale_TERM_DESCRIPTION_TX: string,
    sale_TERM_ID: string,
    sale_TERM_REFERENCE_TX: string,
    sale_TERM_STATEMENT_TX: string,
    sale_TERM_TITLE_NM: string,
    service_DB_ID: string
}