import { IServiceDatabase } from './service-database';

export interface IFiscalYear {
    entityName: string,
    status: number,
    fiscal_YEAR_ID: string,
    external_FISCAL_YEAR_CD: string,
    fiscal_YEAR_DESCRIPTION_TX: string,
    fiscal_YEAR_TITLE_NM: string,
    inactive_IN: string,
    service_DB_ID: string,
    theServiceDbId: IServiceDatabase
}