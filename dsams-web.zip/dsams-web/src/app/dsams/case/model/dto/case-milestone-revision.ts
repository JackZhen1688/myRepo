import { IActivity } from './activity';
import { IDateType } from './date-type';
import { IPerson } from './person';

export interface ICaseMilestoneRevision {
    entityName: string,
    status: number,    
    case_VERSION_MILESTONE_DT: Date,
    theActivityId: IActivity,
    theDateTypeCd: IDateType,
    theUserId: IPerson,
    activity_ID: string,
    case_ID: number,
    case_MILESTONE_ID: number,
    case_MILESTONE_REVISION_ID: number,
    case_VERSION_ID: number,
    date_TYPE_CD: string,
    user_ID: number
}