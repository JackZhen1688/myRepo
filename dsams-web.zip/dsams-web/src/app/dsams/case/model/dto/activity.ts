import { IImplementingAgency } from './implementing-agency';
import { IServiceDatabase } from './service-database';

export interface IActivity {
    entityName: string,
    status: number,
    theImplementingAgencyId: IImplementingAgency,
    theSeniorActivityId: IActivity
    theServiceDbId: IServiceDatabase,
    activity_ABBREVIATION_NM: string,
    activity_ID: string,
    activity_MANAGER_ID: string,
    activity_NM: string,
    activity_OFFICE_SYMBOL_NM: string,
    activity_ROUTING_CD: string,
    case_PREPARER_IN: boolean,
    case_SIGNATORY_IN: boolean,
    case_WRITING_IN: boolean,
    implementing_AGENCY_ID: string,
    inactive_IN: boolean,
    lease_ACTIVITY_SIGNATORY_IN: boolean,
    regional_CENTER_IN: boolean,
    senior_ACTIVITY_ID: string,
    service_DB_ID: string,
    training_PGM_COORD_ACTIVITY_IN: boolean,
    training_PGM_COORDINATOR_IN: boolean
}