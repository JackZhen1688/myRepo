export interface IDateType {
    entityName: string,
    status: number,
    date_TYPE_CD: string,
    date_TYPE_DESCRIPTION_TX: string,
    date_TYPE_TITLE_NM: string,
    inactive_IN: boolean
}