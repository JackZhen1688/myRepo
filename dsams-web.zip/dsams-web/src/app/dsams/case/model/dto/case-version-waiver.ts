export interface ICaseVersionWaiver {
    entityName: string,
    status: number,
    case_VERSION_WAIVER_EFFECT_DT: Date,
    case_VERSION_WAIVER_EXPIRAT_DT: Date,
    case_WAIVER_PERCENT_RT: number,
    case_ID: number,
    case_VERSION_ID: number,
    case_VERSION_WAIVER_ID: number,
    case_WAIVER_JUSTIFICATION_TX: string,
    copy_WAIVER_IN: boolean,
    ipc_NUMBER_ID: string,
    requester_APPROVER_REMARK_TX?: string,
    waiver_TYPE_ID: string,
    businessRuleMap?: Map<string, string>
}