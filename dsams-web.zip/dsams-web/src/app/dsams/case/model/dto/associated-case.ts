export interface IAssociatedCase {
    entityName: string,
    status: number,
    associated_CASE_RATIONALE_TX: string,
    case_DESIGNATOR_CD: string,
    case_ID: number,
    customer_ORGANIZATION_ID: string,
    implementing_AGENCY_ID: string
}