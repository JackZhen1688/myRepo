import { mtdsTravelModel } from "../mtds-travel-model";

export interface mtdsTravelDto extends mtdsTravelModel {
    wm_status?: string;
    isDisabled?: boolean;   // Is row enabled?

    wm_MTDS_TRAVEL_TOTAL_COST_AM?: string;
    tempStatus?: boolean;
}