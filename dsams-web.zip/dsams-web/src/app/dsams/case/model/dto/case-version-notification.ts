import { ICustomerCn } from './customer-cn';

export interface ICaseVersionNotification {
    entityName: string,
    status: number,
    theCustomerCnId?: ICustomerCn,
    case_ID: number,
    case_VERSION_ID: number,
    customer_CN_ID: number
}