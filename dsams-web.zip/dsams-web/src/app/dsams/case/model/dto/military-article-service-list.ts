export interface IMilitaryArticleServiceList {
    military_ARTICLE_SERVICE_CD?: string,
    official_MASL_DESCRIPTION_TX?: string,
    major_DEFENSE_EQUIPMENT_CD?: string,
    mde_SME?: string,
    missile_TECH_CNTRL_REGIME_ID?: string,
    generic_CD?: string,
    issue_UNIT_CD?: string,
    itar_CD?: string,
    end_USE_MONITORING_ID?: string,
    article_SERVICE_ROUTING_CD?: string,
    inactive_IN?: boolean
}