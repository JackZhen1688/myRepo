export interface ICaseUsageIndicator {
    entityName: string,
    status: number,
    case_USAGE_DESCRIPTION_TX: string,
    case_USAGE_INDICATOR_CD: string,
    case_USAGE_TITLE_NM: string,
    inactive_IN: boolean
}
