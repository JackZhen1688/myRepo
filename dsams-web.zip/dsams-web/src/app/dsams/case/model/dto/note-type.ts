export interface INoteType {
    entityName?: string,
    status?: number,
    note_TYPE_CD?: string,
    note_TYPE_DESCRIPTION_TX?: string
}