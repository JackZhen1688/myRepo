import {caseLinePricingModel} from '../case-line-pricing-model';

export interface caseLinePricingDto extends caseLinePricingModel {
     //no window mappping attributes needed
     wm_status?: string;
     isDisabled?: boolean;   // Is row enabled?

    primary_CATEGORY_CD?: string,
    primary_CATEGORY_TITLE_NM?: string,
    price_ELEMENT_CD?: string,
    price_ELEMENT_TITLE_NM?: string,
    fund_CD?: string,
    base_PRICE_SOURCE_CD?: number,
    component_UNIT_BASE_PRICE_AM?: number,
    case_LINE_COMPONENT_QY?: number,
    target_PERCENT_RT?: number,
    target_COST_AM?: number,    
    above_THE_LINE_PC_COST?: string,
    component_DESCRIPTION_TX?: string,
    total_PC_VALUE?: string,

    case_LINE_COMPONENT_ID?: number,
}