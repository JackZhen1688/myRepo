// This is the "new" case master (using legacy).

import { ICaseMasterStatus } from './case-master-status';
import { ICustomerOrganization } from './icustomer-organization';
import { ICaseUsageIndicator } from './case-usage-indicator';
import { ISecurityAssistanceProgram } from './security-assistance-program';
import { ICaseCategory } from './case-category';
import { IImplementingAgency } from './implementing-agency';
import { IPerson } from './person';
import { IAppropriatedFundsType } from './appropriated-funds-type';
import { ICasePersonnelRole } from './case-personnel-role';
import { ICaseMasterServiceType } from './case-master-service-type';
import { IAssociatedCase } from './associated-case';
import { IRelatedCase } from './related-case';
import { ICaseVersion } from './icase-version';
import { IActivity } from './activity';


// The filename has an i in front of it because the current filename is taken by the entity that uses the "old" method.
export interface ICaseMaster {
    entityName?: string,
    status?: number,
    activity_ID?: string,
    allow_SCHEDULING_IN?: boolean,
    appropriated_FUNDS_CD?: string,
    appr_FUNDS_EFFECTIVE_DT?: Date,
    appr_FUNDS_EXPIRED_DT?: Date,
    appr_FUNDS_CLOSED_DT?: Date,
     billing_CUSTOMER_ADDRESS_ID?: number,
    billing_CUSTOMER_ORGANIZATION?: string,
    bypass_CONG_NOTIFICATION_IN?: boolean,
    case_CATEGORY_CD?: string,
    case_DESCRIPTION_TX?: string,
    case_DESIGNATOR_CD?: string,
     case_ID?: number,
     case_MANAGER_USER_ID?: number,
    case_MANAGER_USERNAME?: string,
    case_MASTER_STATUS_CD?: string,
    case_STATUS_TITLE_NM?: string,
    case_NICKNAME_NM?: string,
    case_USAGE_INDICATOR_CD?: string,
    case_USAGE_TITLE_NM?: string,
    closure_STATUS_CD?: string,
    closure_TYPE_CD?: string,
    co_PRODUCTION_IN?: boolean,
    customer_ORGANIZATION_ID?: string,
    end_FISCAL_YEAR_ID?: string,
     finance_MANAGER_USER_ID?: number,
    fiscal_YEAR_ID?: string,
    fouo_APPROVAL_IN?: boolean,
    funding_SOURCE_CD?: string,
    imet_ROLLOVER_EXCLUSION_IN?,
     implemented_CASE_ID?: number,
     implemented_CASE_VERSION_ID?: number,
    implementing_AGENCY_ID?: string,
    inactive_IN?: boolean,
    lease_CONDITION_ID?: string,
    lease_UN_CONTINGENT_TX?: string,
    legacy_DESIGNATOR_CD?: string,
    netsaf_ONE_IN?: boolean,
    oa_PULL_CD?: string,
    person_FULL_NM?: string,
    planning_DOCUMENT_NUMBER_CD?: string,
    program_TYPE_ID?: string,
    sces_INTERFACE_CD?: string,
    security_ASSISTANCE_PROGRAM_CD?: string,
    send_TO_SAN_IN?: boolean,
    services_COMPLETE_IN?: boolean,
    special_PGM_FUNDING_IN?: boolean,
    training_PLANNING_CASE_IN?: boolean,
    user_CASE_ID?: string,

    theCaseMasterStatusCd?: ICaseMasterStatus,
    theCustomerOrganizationId?: ICustomerOrganization,    
    theCaseUsageIndicatorCd?: ICaseUsageIndicator,
    theSecurityAssistanceProgramCd?: ISecurityAssistanceProgram,
    theCaseCategoryCd?: ICaseCategory,
    theImplementingAgencyId?: IImplementingAgency,
    theCaseManagerUserId?: IPerson,
    theAppropriatedFundsCd?: IAppropriatedFundsType,
    theActivityId?: IActivity,
    
   caseMasterLineList?: Array<string>,
    caseVersionList?: Array<ICaseVersion>,
   casePersonnelRoleList?: Array<ICasePersonnelRole>,
    caseMasterServiceTypeList?: Array<ICaseMasterServiceType>,
    associatedCaseList?: Array<IAssociatedCase>,
    relatedCaseCaseIdList?: Array<IRelatedCase>,
    businessRuleMap?: Map<string,string>
}