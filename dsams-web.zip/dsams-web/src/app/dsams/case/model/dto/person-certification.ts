export interface IPersonCertification {
    user_ID: number,
    service_DB_ID: string,
    fbh_TOOL_NM: string,    
    certification_EFFECTIVE_DT: Date,
    certification_EXPIRATION_DT: Date,
    certification_COMMENT_TX: string,
    certification_TYPE_ID: string
}