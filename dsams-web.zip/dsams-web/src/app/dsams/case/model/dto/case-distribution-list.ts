import { IActivity } from './activity';
import { IPerson } from './person';

export interface ICaseDistributionList {
    entityName: string,
    status: number,    
    theActivityId?: IActivity,
    theUserId?: IPerson,
    activity_ID: string,
    case_DISTRIBUTION_ATTACH_IN: boolean,
    case_DISTRIBUTION_LIST_ID: number,
    case_DISTRIBUTION_LIST_TX: string,
    case_ID: number,
    case_VERSION_ID: number,
    original_DOCUMENT_IN?: boolean,
    user_ID: number
}