export interface mtdsPersonnelModel {
    entityName?: string;
    status?: string,

    personnel_POSITION_NM?: string,
    personnel_POSITION_ID?: number,
    personnel_GRADE_RANK_NM?: string,
    personnel_GRADE_RANK_ID?: string,
    mtds_PERSON_ORGAN_TX?: string,
    mtds_PERSON_WORK_YEARS_QY?: number,
    mtds_PERSON_WORK_YEARS_TX?: string,
    mtds_PERSON_BASE_COST_AM?: number,
    mtds_PERSON_BASE_COST_AM_String?: string,
    mtds_PERSON_TOTAL_COST_AM?: number,
    mtds_PERSON_TOTAL_COST_AM_String?: string,
    mtds_MANPOWER_MATRIX_TX?: string,
    mtds_MANPOWER_MATRIX_TX_USER_FORMAT?: string,
    case_LINE_MTDS_PERSON_ID?: number,
    case_ID?: number,
    case_MASTER_LINE_ID?: number,
    working_CASE_ID?: number,
    working_CASE_VERSION_ID?: number,
    case_LINE_COMPONENT_ID?: number
}