export interface IReserveIdentifier {
    reserveCountry: string,
    pseudoCountry: string,
    reserveIa: string,
    reserveDesignator: string,
    originalCountry: string
}