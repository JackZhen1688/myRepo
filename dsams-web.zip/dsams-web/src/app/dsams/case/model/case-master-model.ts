import { CustomerOrganizationRefList } from "./dto/customer-organization";

export interface CaseSaleTermCI {
    sale_TERM_ID:string,
    case_SALE_TERM_SEQ_CD:number,
    fiscal_YEAR_ID:number,
    case_SALE_TERM_AM:number,
    sale_TERM_TITLE_NM:string,
    public_LAW_ID:string,
    public_LAW_TITLE_NM:string,
    sale_TERM_APPLICABLE_LAW_NM:string,
    is_FISCAL_YEAR_EDITABLE:boolean
}

export interface CaseMasterServiceTypeCI {
    case_ID:number,
    customer_SERVICE_TYPE_ID:string,
    service_TYPE_DESCRIPTION_TX:string,
    procuringAgencyIn:boolean
}

export interface CasePersonnelRoleCI {
    case_ID:number,
    user_ID:number,
    personNm:string,
    management_ROLE_ID:string,
    management_ROLE_TITLE_NM:string
}


export interface CaseVersionCI {
    case_ID:number,
    case_VERSION_ID:number,
    case_VERSION_TYPE_CD:string,
    case_VERSION_NUMBER_ID:number,
    case_INITIATOR_ACTIVITY_ID:string,
    security_ASSISTANCE_PROGRAM_CD:string,
    implementing_AGENCY_ID:string,
    caseVersionTypeWithNumber:string,
    case_VERSION_STATUS_CD:string,
    version_STATUS_TITLE_NM:string,
    document_INITIALIZATION_DT:string,
    offer_EXPIRATION_DT:string,
    case_VERSION_STATUS_DT:string,
    customer_ORGANIZATION_ID:string,
    aod_GROUP_CD:string,
    current_AOD_DT:string,
    customer_REQUEST_ID:number,
    isEditable:boolean,
    caseSaleTermList:Array<CaseSaleTermCI>
}

export interface CaseMasterCI {
    case_ID:number,
    user_CASE_ID:string,
    case_USAGE_INDICATOR_CD:string,
    case_USAGE_TITLE_NM:string,
    case_MASTER_STATUS_CD:string,
    case_STATUS_TITLE_NM:string,
    customer_ORGANIZATION_ID:string,
    implementing_AGENCY_ID:string,
    implementing_AGENCY_TITLE_NM:string,
    security_ASSISTANCE_PROGRAM_CD:string,
    program_TITLE_NM:string,
    case_CATEGORY_CD:string,
    case_CATEGORY_TITLE_NM:string,
    activity_ID:string,
    case_NICKNAME_NM:string,
    person_FULL_NM:string,
    person_NICKNAME_NM:string,
    person_FIRST_NM:string,
    person_LAST_NM:string,
    person_LAST_NAME_SUFFIX_NM:string,
    rank_ID:string,
    person_ACTIVITY_ID:string,
    customer_TYPE_CD:string,
    isBenefittingCountry:boolean,
    caseVersionList:Array<CaseVersionCI>,
    caseMasterServiceTypeList:Array<CaseMasterServiceTypeCI>,
    casePersonnelRoleList:Array<CasePersonnelRoleCI>
}

//Case Master entity
export interface CaseMasterModel {
    case_ID:number,
    case_USAGE_INDICATOR_CD:string,
    customer_ORGANIZATION_ID?: string,
    theCustomerOrganizationId?:CustomerOrganizationRefList;
 
}