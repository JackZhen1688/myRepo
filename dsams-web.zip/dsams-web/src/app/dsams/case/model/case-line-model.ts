import { CaseRelatedInfoType } from "../model/case-related-info-type";
import { ICaseLinePricing } from "./dto/icase-line-pricing";
export interface ifaceCaseLineListArray extends CaseRelatedInfoType {
    LINESUBLINESEQVIR?: string;
    virtualSublineList?: string[];
    isDeleteAllowed?: boolean;
    isRefreshAllowed?: boolean;
    isRowBeingMoved?: boolean;
    isRenumberAllowed?: boolean;
    isRowSelected?: boolean;
    // encapsulate the implementation of functions
    getTOTAL_ABOVE_LINE_COST_AM?(CASE_LINE_ITEM_QY: string,
        UNIT_ABOVE_LINE_COST_AM: string): number;
    getSublineInd?(LINESUBLINESEQVIR: string): boolean;
}

export interface ifaceCaseLineEntity {
    //required entity attibutes
    entityName?: string;
    status?: string;
    //This entityStatus attribute is being utilized for making use 
    // of existing DSAMS legacy methods on delete/save 
    entityStatus?: string;

    case_ID?: number,
    case_MASTER_LINE_ID?: number,
    working_CASE_ID?: number,
    working_CASE_VERSION_ID?: number,

    activity_ID?: string;
    activity_NM?: string;
    apply_PROFILE_LINE_CD?: string;
    article_DESCRIPTION_TX?: string;
    acquisition_VALUE_AM?: string;
    budget_APPROPRIATION_CD?: string;
    budget_APPROPRIATION_TITLE_NM?: string;
    case_LINE_AVAILABILITY_LEAD_QY?: string;
    case_LINE_PAY_PERIOD_START_QY?: string;
    case_LINE_PAY_PERIOD_END_QY?: string;
    case_LINE_PERIOD_START_QY?: string;
    case_LINE_PERIOD_END_QY?: string;
    case_LINE_ITEM_QY?: string;
    case_LINE_NOTE_QY?: string;
    case_LINE_ATTACHMENT_QY?: string;
    case_LINE_SHIPMENT_TX?: string;
    case_LINE_MARK_FOR_DELETION_IN?: string;
    case_USAGE_INDICATOR_CD?: string,
    case_DESIGNATOR?: string,
    case_MASTER_STATUS_CD?: string,
    case_STATUS_TITLE_NM?: string,
    case_VERSION_ID?: string,
    change_ACTION_CD?: string,
    change_ACTION_TITLE_NM?: string,
    condition_CD?: string;
    condition_TITLE_NM?: string;
    customer_ORGANIZATION_ID?: string,
    customer_NICKNAME_NM?: string;
    estimated_DELIVERY_END_DT?: string;
    estimated_DELIVERY_DT?: string;
    equipment_TYPE_TITLE_NM?: string;
    generic_CD?: string;
    inventory_VALUE_AM?: string;
    issue_UNIT_CD?: string;
    implementing_AGENCY_ID?: string;
    line_MANAGER_ID?: string;
    line_MANAGER_TITLE_NM?: string;
    line_PURPOSE_CD?: string;
    line_PURPOSE_TITLE_NM?: string;
    major_DEFENSE_EQUIPMENT_CD?: string;
    missile_TECH_CNTRL_REGIME_ID?: string;
    mtcr_TITLE_NM?: string;
    military_ARTICLE_SERVICE_CD?: string;
    theMilitaryArticleServiceCd?: ifaceMASL,
    national_STOCK_NUMBER_ID?: string;
    offer_EXPIRATION_DT?: string;
    operating_AGENCY_CD?: string;
    operating_AGENCY_TITLE_NM?: string;
    other_NATIONAL_STOCK_NUMBER_ID?: string;
    other_PART_NUMBER_IN?: boolean;
    part_NUMBER_IN?: boolean;
    percent_STOCK_RT?: string;
    program_OF_RECORD_ID?: number;
    service_DB_ID?: string;
    shipment_STATUS_ID?: string,
    stock_ON_ORDER_COST_AM?: string;
    stock_ON_HAND_COST_AM?: string;
    supporting_ORGANIZATION_ID?: string;
    support_ORGANIZATION_TITLE_NM?: string;
    case_LINE_ITEM_DESCRIPTION_TX?: string;
    supply_SOURCE_NUMBER_ID?: string;
    supply_SOURCE_TITLE_NM?: string;
    training_NOTE_CD?: string;
    training_NOTE_NM?: string;
    total_ABOVE_LINE_COST_AM?: string;
    unit_ABOVE_LINE_COST_AM?: string;
    theCaseMasterLineId?: ifaceCaseMasterLine,
    wm_CASE_VERSION_TYPE_CD?: string,
    wm_USER_CASE_LINE_NUMBER_ID?: string,
    wm_USER_CASE_SUBLINE_TX?: string,
    wm_HAS_SUBLINES?: boolean,
    wm_HAS_SUBLINES_A?: boolean,
    wm_HAS_SUBLINES_PRICED?: boolean,
    wm_PARENT_IS_MDE?: boolean,
    wm_CML_IMPLEMENTED_CASE_ID?: number,
    wm_CML_IMPLEMENTED_CASE_VRSN_ID?: number,
    wm_CM_IMPLEMENTED_CASE_ID?: number,
    wm_CM_IMPLEMENTED_CASE_VERSION_ID?: number,
    wm_CM_CUSTOMER_ORGANIZATION_ID?: string,
    wm_PARENT_CHANGE_ACTION_CD?: string,
    wm_PARENT_IS_PRICED?: boolean,
    wm_LINE_IS_PRICED?: boolean,
    wm_CHECK_NPOR?: boolean
}
export interface ifaceCaseMasterLineEntity {
    //required entity attibutes
    entityName?: string;
    status?: string;
    service_DB_ID?: string;
    caseLineList?: ifaceCaseLineEntity[];
    theICaseLinePricing?: ICaseLinePricing,
}

export interface ifaceCaseMasterLine {
    case_LINE_REMARK_QY?: string;
    exclusion_IN?: boolean;
    user_CASE_SUBLINE_TX?: string;
    user_CASE_LINE_NUMBER_ID?: string;
    case_ID?: number;
    case_MASTER_LINE_ID?: number;
    cml_SERVICES_COMPLETE_IN?: boolean,
    case_LINE_LOI_IN?: string;
    service_DB_ID?: string;
    caseLineList?: ifaceCaseLineListArray[];
}

export interface ifaceDeletedCaseLineArray {
    //required entity attibutes
    entityName?: string;
    status?: string;
    case_ID: number;
    case_MASTER_LINE_ID?: number;
    working_CASE_VERSION_ID: number;
    working_CASE_ID?: number;
    service_DB_ID?: string;
    change_ACTION_CD?: string;
    wm_USER_CASE_LINE_NUMBER_ID?: string,
    wm_USER_CASE_SUBLINE_TX?: string,
    wm_PARENT_CASE_MASTER_LINE_ID?: number,
}

export interface ifaceCaseLineData extends ifaceCaseLineListArray {
    linePurposeRefList?: ifaceGenericRefItem[];
    shipmentStatusRefList?: ifaceGenericRefItem[];
    trainingNoteRefList?: ifaceGenericRefItem[];
    supportingOrgRefList?: ifaceGenericRefItem[];
    supplySourceRefList?: ifaceGenericRefItem[];
    conditionRefList?: ifaceGenericRefItem[];
    deliveryTermList?: ifaceGenericRefItem[];
    activityList?: ifaceGenericRefItem[];
    calendarYearList?: ifaceGenericRefItem[];
    assistanceTypeList?: ifaceGenericRefItem[];
    offerReleaseList?: ifaceGenericRefItem[];
    budgetAppropriationList?: ifaceGenericRefItem[];
    customerStructureList?: ifaceGenericRefItem[];
    issueUnitList?: ifaceGenericRefItem[];
    programOfRecordList?: ifaceGenericRefItem[];
    lineManagerRefList?: ifaceGenericRefItem[];
    lineManagerOARefList?: ifaceGenericRefItem[];
    operatingAgencyRefList?: ifaceGenericRefItem[];
    sumOfAllQuantities?: number,
    isPricingDataChanged?: boolean,
    PORTitle?: string,
}

export interface ifaceMASL {
    military_ARTICLE_SERVICE_CD?: string,
    article_DESCRIPTION_TX?: string
}

export interface ifaceGenericRefItem {
    integer_VALUE_CD?: number;
    integer_VALUE_CD1?: number;
    value_CD?: string;
    value_CD1?: string;
    value_TITLE_NM?: string;
    value_TITLE_NM1?: string;
    value_TITLE_DESC?: string;
    value_IN?: boolean;
    value_IN1?: boolean;
}

export interface ifaceCaseLineSubsetArray {
    case_ID?: number;
    case_MASTER_LINE_ID?: number;
    working_CASE_ID?: number;
    working_CASE_VERSION_ID?: number;
    wm_USER_CASE_LINE_NUMBER_ID?: string;
    theCaseMasterLineId?: ifaceCaseMasterLineSubset;
    theCMLChildList?: ifaceCaseMasterLineSubset[];
}

export interface ifaceCaseMasterLineSubset {
    case_ID?: number;
    case_MASTER_LINE_ID?: number;
    parent_CASE_ID?: number;
    parent_CASE_MASTER_LINE_ID?: number;
    user_CASE_LINE_NUMBER_ID?: string;
    user_CASE_SUBLINE_TX?: string;
}