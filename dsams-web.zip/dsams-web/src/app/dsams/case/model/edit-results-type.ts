export interface IEditResultsType {
    canEdit:boolean,
    errorMessage: string
}