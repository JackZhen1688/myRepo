/**
 * This class stores a mapping of fields and/or panels and whether they're disabled per business rules 
 * (as set in the individual panels)
 * 
 * Author: CBanta
 */

export interface FieldDisabledMap {
    [fieldName:string]:boolean
}