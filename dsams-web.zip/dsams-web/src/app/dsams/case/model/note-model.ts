import { INoteContent } from "./dto/note-content";
import { INoteParameter } from "./dto/note-parameter";
import { INoteType } from "./dto/note-type";

export interface NoteModel {
    entityName?: string;
    status?: string;
    
    note_ID?: number,
    note_VERSION_ID?: number,
    note_DESCRIPTION_TX?:string,
    official_NOTE_TITLE_TX?:string,
    note_TYPE_CD?:string,
    note_EXPIRATION_DT?:string,
    user_NOTE_ID?:string,
    fillin_IN?:boolean,
    theNoteTypeCd?: INoteType,
    note_INPUT_RESPONSIBILITY_CD?:string,
    noteContentList?: INoteContent[],
    noteParameterList?: INoteParameter[]
}