import { Component, OnInit, Input, Output, EventEmitter, SimpleChanges } from '@angular/core';
import { FormArray, FormBuilder, FormGroup } from '@angular/forms';
import { formatDate } from '@angular/common';
import { MatSnackBar } from '@angular/material/snack-bar';
import { CaseRestfulService } from './../../services/case-restful.service';
import { DsamsMethodsService } from './../../../services/dsams-methods.service';
import { DsamsConstants } from './../../../dsams.constants';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { DsamsRestfulService } from './../../../../dsams/services/dsams-restful.service';
import { DialogMessageYesnoComponent } from './../../../utilitis/dialogs/dialog-message-yesno/dialog-message-yesno.component';
import { PopCaseMilestoneComponent } from 'src/app/dsams/utilitis/popups/pop-case-milestone/pop-case-milestone.component';
import { PopCommonMilestoneComponent } from 'src/app/dsams/utilitis/popups/pop-common-milestone/pop-common-milestone.component';
import { ValidateWebComponentInput } from './../../../entities/specialEntities/validate-web-component-input.model';
import { MessageMgr } from './../../validation/message-mgr';
// begin DSAMS-5944 09/22 DB
import { ImessageData } from 'src/app/dsams/interfaces/imessage-data';
import { DsamsUserMessageService } from '../../../services/dsams-user-message.service';
// end DSAMS-5944 09/22 DB


@Component({
  selector: 'app-case-milestone',
  templateUrl: './case-milestone.component.html',
  styleUrls: ['./case-milestone.component.css']
})
export class CaseMilestoneComponent implements OnInit {

  @Input() caseId: string;
  @Input() caseVerId: string;
  @Input() serviceId: string;
  @Input() isEditable: boolean;
  @Input() isRefresh: number;
  @Output() editToggleEvent = new EventEmitter<boolean>();
  @Output() milestoneId = new EventEmitter<string>();
// begin DSAMS-5944 09/22 DB
   static LIST_LOCK_SESSION_ID = "MileStoneListLockSessionId";
   public messageData: ImessageData;
// end DSAMS-5944 09/22 DB
   durationInSeconds = 5;
   spinnerDisplay: boolean = false;
   color = "primary";
   mode  = "indeterminate";
   diameter = 60;
   value = 50;

  delMilestoneIds: string = '';
  delCommReasons: string  = '';
  btnDelDisabled: boolean;
  txtActualDtDisabled: boolean;
  txtplannedDtDisabled: boolean;
  txtplanRevDtDisabled: boolean;
  txtCommentsDisabled: boolean;  
  aryComReasonDisabled: boolean;
  csuWP004DELDisabled: boolean = true;
  csuWP004AODDisabled: boolean = true;
  csuWP004STLSTDisabled: boolean = true;
  csuWP004ADATEDisabled: boolean = true;
  recentAODFlage: boolean = false;
  zeroValueEDAGrant: number;
  aodEffectiveDate: string;
  aodExpirationDate: string;
  emptyMilestoneFlage: boolean;
  cancelBtnClick: boolean = false;
  caseVersionTypeCd: string;

  expandedIndex: number;
  milestonesFormChanged: boolean;
  milestonesForm: FormGroup;

  megsTitle:string = 'Validate Milestone';
  keyName:string   = 'Milestone Id';
  valueName:string = 'Invalid Message';
  invalidActPlanDate  = new Map();
  invalidRevPlannDate = new Map();
  invalidPrerequistes = new Map();
  invalidFormValues   = new Map();
  prereWithActualDate = new Map();
  cacheWithActualDate = new Map();
  duplicateMilestones: string[] = [];
 
  textareaEditable:string    = "textarea-editable";
  textareaNonEditable:string = "textarea-customize";
  dateEditable    = "date-editable";
  dateNonEditable = "date-container";
  fieldEditable    = "matfield-outline-editable";
  fieldNonEditable = "matfield-outline";
  btnEditable    = "btn-default btn-dot-black";
  btnNonEditable = " btn-default btn-dot";

  personUserId: string;
  personFullName: string;
  personActivityId: string;

  constructor(private formBuilder: FormBuilder,
           // begin DSAMS-5944 09/22 DB
              private messageService: DsamsUserMessageService,
           // end DSAMS-5944 09/22 DB
              private dialog: MatDialog,
              private _snackBar: MatSnackBar,
              private caseRestService: CaseRestfulService,
              private dsamsRestService: DsamsRestfulService,
              private dsamsMethodsService: DsamsMethodsService)
  {
    this.milestonesForm = formBuilder.group({
      'milestones': formBuilder.array([]), 
    });
  }

  ngOnInit() 
  {
    this.getUserInfo();
    this.getPageAttrAccess('WP004DEL');
    this.getPageAttrAccess('WP004STLST');
    this.getPageAttrAccess('WP004AOD');
    this.getPageAttrAccess('WP004ADATE');
    this.getZeroValueEDAGrant(encodeURIComponent(this.caseId+"@"+this.caseVerId+"#"+this.serviceId));

    this.getRecentAOD(encodeURIComponent(this.caseId+"@"+this.caseVerId+"#"+this.serviceId));
    this.getCaseMilestones(encodeURIComponent(this.caseId+"@"+this.caseVerId+"#"+this.serviceId));
  }

  ngOnChanges(changes: SimpleChanges) 
  { 
    console.log("isEditable=="+this.isEditable);
    if (changes.isEditable != undefined) {
        if (this.isEditable) {
            this.callWI005('WP004', this.caseId, this.caseVerId, null, null);
            console.log("## setLock here...##");
            // begin DSAMS-5944 09/22 DB
            this.prepareMilestoneListForEdit( this.caseVerId, this.caseId);
            // end DSAMS-5944 09/22 DB
          } else {
            this.checkValuesChanged(); 
        }
    }
    if (changes.isRefresh != undefined) {
        if (this.isRefresh) {
            console.log("===== Milestone refreshed by control =====")
            this.refreshPage();
        }

    }
  }

  get milestones() {
    return this.milestonesForm.get('milestones') as FormArray;
  }

  getActualDate_A(idx:number) {
    return this.milestones.controls[idx].get('txtActualDate_A');
  }

  getActualDate_P(idx:number) {
    return this.milestones.controls[idx].get('txtPlannedDate_P');
  }

  getActualDate_R(idx:number) {
    return this.milestones.controls[idx].get('txtRevisedDate_R');
  }

  getComments(idx:number) {
    return this.milestones.controls[idx].get('txtComments');
  }
  
  getPageAttrAccess(csu_cd: string) {
    this.dsamsRestService.getPageAttrAccess(csu_cd)
    .subscribe(
      data => { 
        /**console.log(csu_cd+"==>PageAttries Access==="+data);*/
        if (data == 1) {
          switch (csu_cd) {
            case 'WP004DEL': {
              this.csuWP004DELDisabled = false;
              break;
            }
            case 'WP004STLST': {
              this.csuWP004STLSTDisabled = false;
              break;
            }
            case 'WP004AOD': {
              this.csuWP004AODDisabled = false;
              break;
            }
            case 'WP004ADATE': {
              this.csuWP004ADATEDisabled = false;
              break;
            }
          }
        } 
      },
      err => {
        console.log("Error occured: getPageAttrAccess()", err)
      }
    );   
  }

  getUserInfo() {
    this.dsamsRestService.getUserInfo()
    .subscribe(
      data => { 
        this.personUserId = data.userProfile.userId
        this.personFullName = data.userProfile.firstNm+" "+data.userProfile.lastNm;
        this.personActivityId = data.userProfile.activityId
      },
      err => {
        console.log("Error occured: getUserInfo()"+err.message);
        this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, JSON.stringify(err.message))
      }
    );
  }

  getZeroValueEDAGrant(filter: string) {
    this.caseRestService.getZeroValueEDAGrant(filter)
    .subscribe(
      data => { 
        console.log("===== ZeroValueEDAGrant ====="+JSON.stringify(data))
        this.zeroValueEDAGrant = data;
      },
      err => {
        console.log("Error occured: getRecentAOD()"+err.message);
        this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, JSON.stringify(err.message))
      }
    );
  }

  getRecentAOD(filter: string) {
    this.caseRestService.getRecentAOD(filter)
    .subscribe(
      data => { 
        console.log("===== RecentAOD ====="+JSON.stringify(data))
        if (Object.keys(data).length > 0) {
            this.recentAODFlage = data.RecentAOD;
            this.aodEffectiveDate = data.EffectiveDt;
            this.aodExpirationDate= data.ExpirationDt;
        }
      },
      err => {
        console.log("Error occured: getRecentAOD()"+err.message);
        this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, JSON.stringify(err.message))
      }
    );
  }

  getCaseMilestones(filter: string) {
    this.spinnerDisplay = true;
    this.caseRestService.getCaseMilestones(filter)
    .subscribe(
      milestoneData => {
        console.log("===== getMilestone List=====")
        if (milestoneData.length == 0) {
            this.addMilestone();
        } else {
            milestoneData.forEach(milestone => {
              this.addMilestone(milestone);
            });
            this.spinnerDisplay = false;
        }
      },
      err => {
        console.log("Error occured: getCaseMilestones()"+err.message);
        this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, JSON.stringify(err.message))
      }
    );    
  }


  addCommReason(milestonesIndex: number, commReason?: any) 
  {
      const comReason = this.formBuilder.group({ 
         'txtNewReason': [commReason?'':'insert'],
         'txtRejectId': [commReason?commReason.reject_REASON_ID:''],
         'txtCode': [commReason?commReason.milestone_REJECT_REASON_ID:''],
         'txtCodeOri': [commReason?commReason.milestone_REJECT_REASON_ID:''],
         'txtReason': [commReason?commReason.reject_TITLE_NM:''],
         'txtDaysProposed': [commReason?commReason.proposed_DAYS_FOR_CDEF_QY:''],
         'txtDaysProposedOri': [commReason?commReason.proposed_DAYS_FOR_CDEF_QY:''],
         'txtDaysActual': [commReason?commReason.actual_DAYS_FOR_CDEF_QY:''],
         'txtDaysActualOri': [commReason?commReason.actual_DAYS_FOR_CDEF_QY:''],
         'txtComments': [commReason?commReason.cdef_COMMENT_TX:''],
         'txtCommentsOri': [commReason?commReason.cdef_COMMENT_TX:''],
      });
      (<FormArray>(<FormGroup>this.milestones
          .controls[milestonesIndex]).controls['commReasons']).push(comReason);   
  }

  delCommReason(milestonesIndex: number, index: number) 
  {
    if ((<FormArray>(<FormGroup>this.milestones
              .controls[milestonesIndex]).controls['commReasons']).controls[index].get("txtCode").value != null && 
        (<FormArray>(<FormGroup>this.milestones
              .controls[milestonesIndex]).controls['commReasons']).controls[index].get("txtNewReason").value !='insert') {

         this.delCommReasons = this.delCommReasons +"@"+(<FormArray>(<FormGroup>this.milestones
             .controls[milestonesIndex]).controls['commReasons']).controls[index].get("txtRejectId").value+"#"+
              this.milestones.controls[milestonesIndex].get("txtCaseMilestoneId").value;          
    }

    (<FormArray>(<FormGroup>this.milestones
        .controls[milestonesIndex]).controls['commReasons']).removeAt(index);
  }

  addMilestone(milestone?: any) 
  {
      this.checkBtnDelDidsabled(milestone);
      this.checkTxtDateDidsabled(milestone);
      this.checkAryReasonDisabled(milestone);
      this.checkTextAreaDisabled(milestone);
      this.getCaseVersionTypeCd(milestone);
  
      const user = this.formBuilder.group({ 
        'txtNewMilestone': [milestone?'':'insert'],
        'txtCaseMilestoneId': [milestone?milestone.case_MILESTONE_ID:""],
        'txtMilestoneId':[milestone?milestone.milestone_ID:""],             
        'txtMilestoneIdOri':[milestone?milestone.milestone_ID:""],             
        'txtMilestoneName':[milestone?milestone.milestone_TITLE_NM:""],             
        'txtMilestoneCategoryCd':[milestone?milestone.milestone_CATEGORY_CD:""],             
        'txtActualDate_A':[this.getMilestoneDateA(milestone)],             
        'txtActualDate_AOri':[this.getMilestDateAOri(milestone)],             
        'txtPersonId_A':[this.getPersonIdA(milestone)],             
        'txtPlannedDate_P':[this.getMilestoneDateP(milestone)],             
        'txtPlannedDate_POri':[this.getMilestDatePOri(milestone)],             
        'txtPersonId_P':[this.getPersonIdP(milestone)],             
        'txtRevisedDate_R':[this.getMilestoneDateR(milestone)],             
        'txtRevisedDate_ROri':[this.getMilestDateROri(milestone)],             
        'txtPersonId_R':[this.getPersonIdR(milestone)],  
        'txtOverideIn':[{value:this.getMilestoneOverrideIn(milestone), disabled: true}],             
        'txtFirstOccurDate':[this.getFirstOccurDate(milestone)],             
        'txtComments':[this.getDescriptTx(milestone)],   
        'txtCommsOri':[this.getDescriTxOri(milestone)], 
        'txtPersonName_A':[this.getPersonNMA(milestone)],             
        'txtPersonName_P':[this.getPersonNMP(milestone)],             
        'txtPersonName_R':[this.getPersonNMR(milestone)],             
        'txtActivityId_A':[this.getActivityIdA(milestone)],             
        'txtActivityId_P':[this.getActivityIdP(milestone)],     
        'txtActivityId_R':[this.getActivityIdR(milestone)],
        'txtCommRequired' :[this.getComRequiredIn(milestone)],
        'txtCustReceiptDt':[milestone?milestone.customer_REQUEST_RECEIPT_DT:""],
        'txtCustRequestId':[milestone?milestone.customer_REQUEST_ID:""],
        'btnDelDisabled' :[this.btnDelDisabled],
        'txtAdateDisabled':[this.txtActualDtDisabled],             
        'txtPdateDisabled':[this.txtplannedDtDisabled],             
        'txtRdateDisabled':[this.txtplanRevDtDisabled], 
        'txtCommDisabled':[this.txtCommentsDisabled],   
        'aryReasonDisabled':[this.aryComReasonDisabled],         

        'commReasons': this.formBuilder.array([]),    

      });
      this.milestones.push(user);

      let milestoneIndex = this.milestones.length-1;
      if (!milestone) {                                   
          this.addCommReason(milestoneIndex);
          this.expandedIndex = milestoneIndex;
      } else {
          milestone.commReasons.forEach(commReason => {
              this.addCommReason(milestoneIndex, commReason);
          });
      }
  }

  delMilestone(index: number) 
  {
    if (this.milestones.controls[index].get("txtNewMilestone").value !='insert') 
    {
        this.setPanel(-1);
        this.delMilestoneIds = this.delMilestoneIds +"@"+this.milestones.controls[index].get("txtCaseMilestoneId").value;
    } else {
        if (this.invalidPrerequistes.has(index)) 
            this.invalidPrerequistes.delete(index);
        if (this.prereWithActualDate.has(index)) 
            this.prereWithActualDate.delete(index);


    }
    this.milestones.removeAt(index);
  }

  setPanel(index: number) {
    this.expandedIndex = index;
  }

  checkBtnDelDidsabled(milestone?: any) 
  {
    if (!milestone) {
        this.btnDelDisabled = false;
    } else if (milestone.milestone_ID ==='S1REJECT' || milestone.milestone_ID ==='CPYCASE' || milestone.milestone_ID ==='CPYLEASE') {
        this.btnDelDisabled = true;
    } else {
        this.checkBtnDelDidsabledSub(milestone) ;
    }
  }

  checkBtnDelDidsabledSub(milestone:any) 
  {
      if ( !this.csuWP004DELDisabled   && (milestone.milestone_TYPE_CD ==='UR' || milestone.milestone_TYPE_CD ==='US')  
                                       && (this.personActivityId === milestone.activity_ID_A || this.personActivityId === milestone.activity_ID_P || this.personActivityId === milestone.activity_ID_R) ||
          (!this.csuWP004STLSTDisabled && milestone.milestone_ID ==='STLST' && !milestone.case_VERSION_MILESTONE_DT_A && milestone.dsa_APPROVAL_IN ==='1' &&  milestone.state_DEPARTMENT_APPROVAL_IN ==='0') ||
          /**
          (!this.csuWP004AODDisabled   && (milestone.milestone_ID ==='AODGRPA' || milestone.milestone_ID ==='AODGRPB' || milestone.milestone_ID ==='AODGRPC' || milestone.milestone_ID ==='AODGRPD') 
                                       && (milestone.case_VERSION_STATUS_CD ==='D' || milestone.case_VERSION_STATUS_CD ==='W' || milestone.case_VERSION_STATUS_CD ==='R') 
                                       && (this.recentAODFlage && (milestone.milestone_ID !='RESTATE' || milestone.milestone_ID !='REACTIVATE'))) ||  */
           !milestone.case_VERSION_MILESTONE_DT_A && !milestone.case_VERSION_MILESTONE_DT_P ) 
      {
          this.btnDelDisabled = false;
      } else {  
          this.btnDelDisabled = true;
      }
  }

  checkTxtDateDidsabled(milestone?: any) 
  {
    if (!milestone) {
        this.txtActualDtDisabled  = false;
        this.txtplannedDtDisabled = false;
        this.txtplanRevDtDisabled = true;
    } else {
        this.checkActualDateDisabled(milestone);
        this.checkPlannedDateDisabled(milestone);
        this.checkRevPlanDateDisabled(milestone);
    }
  }

  checkActualDateDisabled(milestone: any) {
    if (!milestone.case_VERSION_MILESTONE_DT_A && (milestone.milestone_TYPE_CD ==='UR' || milestone.milestone_TYPE_CD ==='US') ||
        (milestone.case_VERSION_MILESTONE_DT_A !=null && milestone.milestone_ID==='PMTSHDREV') ||
        (milestone.case_VERSION_MILESTONE_DT_A !=null && !this.csuWP004ADATEDisabled && milestone.milestone_TYPE_CD ==='SE')) {
        this.txtActualDtDisabled = false; 
    } else{
        this.txtActualDtDisabled = true;
    }
  }

  checkPlannedDateDisabled(milestone: any) {
    if (!milestone.case_VERSION_MILESTONE_DT_A && !milestone.case_VERSION_MILESTONE_DT_P) {
        this.txtplannedDtDisabled = false;
    } else {
        this.txtplannedDtDisabled = true;
    }
  }  

  checkRevPlanDateDisabled(milestone: any) {
    if (milestone.milestone_TYPE_CD ==='SG') {
        this.txtplanRevDtDisabled = true;
    } else {
      if  ((milestone.milestone_ID ==='AODGRPA' || milestone.milestone_ID ==='AODGRPB' || milestone.milestone_ID ==='AODGRPC' || milestone.milestone_ID ==='AODGRPD') &&
           (this.recentAODFlage && (milestone.milestone_ID !='RESTATE' || milestone.milestone_ID !='REACTIVATE'))) 
      {
           this.txtplanRevDtDisabled = false;
      } else {
           if (milestone.case_VERSION_MILESTONE_DT_A !=null || milestone.case_VERSION_MILESTONE_DT_P !=null) 
               this.txtplanRevDtDisabled = true;
           else
               this.txtplanRevDtDisabled = false;
      }
    }
  }  

  checkTextAreaDisabled(milestone?: any) 
  {
    if (!milestone) {
        this.txtCommentsDisabled = false;
    } else {
        if (milestone.milestone_ID ==='S1REJECT' || milestone.milestone_ID ==='CPYCASE' || milestone.milestone_ID ==='CPYLEASE') 
            this.txtCommentsDisabled = true;
        else
            this.txtCommentsDisabled = false;
    }
  }

  checkAryReasonDisabled(milestone?: any) 
  {
    if (!milestone) {
        this.aryComReasonDisabled = true;
    } else {
        if (!milestone.function_COMMAND_CD)
            this.aryComReasonDisabled = true;
        else
            this.aryComReasonDisabled = false;
    }
  }

  getCaseVersionTypeCd(milestone?: any) {
     if (milestone != null && this.caseVersionTypeCd == null)
         this.caseVersionTypeCd = milestone.case_VERSION_TYPE_CD;
  }

  getMilestoneId(milestoneId: any) {
    this.milestoneId.emit(milestoneId);
  }

  checkValuesChanged() {
    if (this.checkObjectChanged()) {
        this.milestonesFormChanged = true;
        const dialogConfig = new MatDialogConfig();
        dialogConfig.disableClose = true;
        dialogConfig.autoFocus = true;
        dialogConfig.width= "550px"; 
        dialogConfig.data = {message: DsamsConstants.TOGGLE_EDIT_CHANGE, indecator: 'Save'};
        const dialogRef = this.dialog.open(DialogMessageYesnoComponent, dialogConfig);
        dialogRef.afterClosed().subscribe(result => {
          if (result == 0) {   //Cancel  
              this.editToggleEvent.emit(true);
              this.cancelBtnClick = true;
          }
          if (result == 1) {   //Save
              this.onSubmit();
              this.editToggleEvent.emit(false);
              this.cancelBtnClick = true;
          }
          if (result == 2) {   //Continue
              console.log("## unLock...##");
              // begin DSAMS-5944 09/22 DB
              this.unLockMilestoneList();
              // end DSAMS-5944 09/22 DB
              this.cancelBtnClick = false;
              this.refreshPage();
          }
        });
    } else {
        this.milestonesFormChanged = false;
      console.log("## unLock...##");
       // begin DSAMS-5944 09/22 DB
       this.unLockMilestoneList();
       // end DSAMS-5944 09/22 DB
    }
  }

  checkObjectChanged() 
  {
    if (this.checkDelRecords()) {
        this.checkValueChanged();
        return true;
    } else {
        return this.checkValueChanged();
    }
  }

  checkDelRecords() {
    if (this.delMilestoneIds.replace(/@/gi,"") !='' || this.delCommReasons.replace(/@/gi,"") !='')
        return true;
    else
        return false; 
  }

  checkValueChanged() {
    let valueChanged: boolean = false;
    this.milestones.controls.forEach(milestone => {
      if (this.checkCommDatesChanged(milestone)) 
          valueChanged = true;
      if (this.checkCommReasonsChanged(milestone))     
          valueChanged = true;    
    })
    return valueChanged;
  }

  checkCommDatesChanged(milestone:any) 
  {
    if (milestone.get("txtMilestoneId").value != milestone.get("txtMilestoneIdOri").value || milestone.get("txtComments").value != milestone.get("txtCommsOri").value ||
        formatDate(milestone.get("txtActualDate_A").value, 'yyyy-MM-dd', 'en')  != formatDate(milestone.get("txtActualDate_AOri").value, 'yyyy-MM-dd', 'en') ||
        formatDate(milestone.get("txtPlannedDate_P").value, 'yyyy-MM-dd', 'en') != formatDate(milestone.get("txtPlannedDate_POri").value, 'yyyy-MM-dd', 'en')  ||
        formatDate(milestone.get("txtRevisedDate_R").value, 'yyyy-MM-dd', 'en') != formatDate(milestone.get("txtRevisedDate_ROri").value, 'yyyy-MM-dd', 'en') )
    {
        if (milestone.get("txtNewMilestone").value === '') 
            milestone.get("txtNewMilestone").setValue('update');
        return true;
    }    
    return false;
  }  

  checkCommReasonsChanged(milestone:any) 
  {
    let reasonsChaged: boolean = false;
    milestone.get("commReasons").value.forEach(reason=>{
      if (reason.txtCode != reason.txtCodeOri || reason.txtDaysProposed != reason.txtDaysProposedOri ||
          reason.txtDaysActual != reason.txtDaysActualOri || reason.txtComments != reason.txtCommentsOri) 
      {
          if (reason.txtNewReason === '')
              reason.txtNewReason = 'update';
          if (milestone.get("txtNewMilestone").value === '')
              milestone.get("txtNewMilestone").setValue('update');
          reasonsChaged = true;
      }
    })
    return reasonsChaged;
  }

  cleanUpTxtInsertUpdate() 
  {
    this.milestones.controls.forEach(milestone => {
      if (milestone.get("txtNewMilestone").value != '' && milestone.get("txtNewMilestone").value !=null) {
          milestone.get("txtNewMilestone").setValue(null);
      }
      milestone.get("commReasons").value.forEach(reason=>{
        if (reason.txtNewReason !='' && reason.txtNewReason !=null) {
            reason.txtNewReason = null;
        }
      })
    })
    this.delMilestoneIds = '' 
    this.delCommReasons  = '';
  }

  caseMilestonePopup(index:number) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width  = "1170px";
    dialogConfig.height = "610px";
    dialogConfig.data   = {passingCaseID: this.caseId,
                           passingCaseVerId: this.caseVerId};

    const dialogRef = this.dialog.open(PopCaseMilestoneComponent, dialogConfig);
    dialogRef.afterClosed().subscribe(result => {
       if (result.length != 0 ) {
           if (result.milestone_ID === 'ESTCLOSE' && this.caseVersionTypeCd != 'I' && this.zeroValueEDAGrant === 0) {
               this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, 'The ESTCLOSE milestone can only be used on the I version')
           } else if (result.milestone_ID === 'CLSEDAGRNT' && this.caseVersionTypeCd != 'I' ) {
               this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, 'The CLSEDAGRNT milestone can only be used on the I version for zero-value EDA Grant cases')
           } else {
               this.milestones.controls[index].get("txtMilestoneId").setValue(result.milestone_ID);
               this.milestones.controls[index].get("txtMilestoneName").setValue(result.milestone_TITLE_NM);
               this.checkCommRequired(index, result.milestone_ID);
               this.checkPrerequiste(index, result.milestone_ID);
           }
       } 
    });
  }

  commonMilestonePopup(milestone:string, index:number, idx: number) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width  = "1170px";
    dialogConfig.height = "610px";
    dialogConfig.data   = {passingMilestoneId: milestone};

    const dialogRef = this.dialog.open(PopCommonMilestoneComponent, dialogConfig);
    dialogRef.afterClosed().subscribe(result => {
       if (result.length != 0 ) {
          (<FormArray>(<FormGroup>this.milestones.controls[index]).controls['commReasons']).controls[idx].get("txtRejectId").setValue(result.reject_REASON_ID);
          (<FormArray>(<FormGroup>this.milestones.controls[index]).controls['commReasons']).controls[idx].get("txtCode").setValue(result.milestone_REJECT_REASON_ID);
          (<FormArray>(<FormGroup>this.milestones.controls[index]).controls['commReasons']).controls[idx].get("txtReason").setValue(result.reject_TITLE_NM);
       } 
    });
  }

  onBlurActualDate(index:number) {
    if (this.milestones.controls[index].get('txtActualDate_A').value !=null && !this.milestones.controls[index].get('txtActualDate_A').invalid) {
        this.milestones.controls[index].get('txtPersonId_A').setValue(this.personUserId);
        this.milestones.controls[index].get('txtPersonName_A').setValue(this.personFullName);
        this.milestones.controls[index].get('txtActivityId_A').setValue(this.personActivityId);
    } else {
        this.milestones.controls[index].get('txtPersonId_A').setValue('');
        this.milestones.controls[index].get('txtPersonName_A').setValue('');
        this.milestones.controls[index].get('txtActivityId_A').setValue('');
    }
  }

  onBlurPlannedDate(index:number) {
    if (this.milestones.controls[index].get('txtPlannedDate_P').value !=null && !this.milestones.controls[index].get('txtPlannedDate_P').invalid) {
        this.milestones.controls[index].get('txtPersonId_P').setValue(this.personUserId);
        this.milestones.controls[index].get('txtPersonName_P').setValue(this.personFullName);
        this.milestones.controls[index].get('txtActivityId_P').setValue(this.personActivityId);
    } else {
        this.milestones.controls[index].get('txtPersonId_P').setValue('');
        this.milestones.controls[index].get('txtPersonName_P').setValue('');
        this.milestones.controls[index].get('txtActivityId_P').setValue('');
    }
  }

  onBlurRevisedDate(index:number) {
    if (this.milestones.controls[index].get('txtRevisedDate_R').value !=null && !this.milestones.controls[index].get('txtRevisedDate_R').invalid) {
        this.milestones.controls[index].get('txtPersonId_R').setValue(this.personUserId);
        this.milestones.controls[index].get('txtPersonName_R').setValue(this.personFullName);
        this.milestones.controls[index].get('txtActivityId_R').setValue(this.personActivityId);
    } else {
        this.milestones.controls[index].get('txtPersonId_R').setValue('');
        this.milestones.controls[index].get('txtPersonName_R').setValue('');
        this.milestones.controls[index].get('txtActivityId_R').setValue('');
    }
  }

  buildNewFormValue() 
  {
    var newFormValue = {};
    newFormValue["serviceId"]  = this.serviceId;
    newFormValue["caseId"]     = this.caseId;
    newFormValue["caseVerId"]  = this.caseVerId;
    newFormValue["delMilIds"]  = this.delMilestoneIds.substring(1);
    newFormValue["delRejIds"]  = this.delCommReasons.substring(1);
    newFormValue["milestones"] = this.getMilestones(this.milestones).value;
  
    return newFormValue;
  }

  getMilestones(milestones: FormArray) 
  {
    var formArray = this.formBuilder.array([]);
      milestones.controls.forEach(milestone => {
        if (milestone.get("txtNewMilestone").value != '' && milestone.get("txtNewMilestone").value !=null) {
            formArray.push(this.formBuilder.group({
              new_MILESTONE: [milestone.get("txtNewMilestone").value],
              case_MILESTONE_ID: [milestone.get("txtCaseMilestoneId").value],
              milestone_ID: [milestone.get("txtMilestoneId").value],
              milestone_TITLE_NM: [milestone.get("txtMilestoneName").value],
              milestone_CATEGORY_CD: [milestone.get("txtMilestoneCategoryCd").value],
              case_VERSION_MILESTONE_DT_A: [milestone.get("txtActualDate_A").value],
              case_VERSION_MILESTONE_DT_P: [milestone.get("txtPlannedDate_P").value],
              case_VERSION_MILESTONE_DT_R: [milestone.get("txtRevisedDate_R").value],
              milestone_OVERRIDE_IN: [milestone.get("txtOverideIn").value],
              create_DT: [milestone.get("txtFirstOccurDate").value],
              user_ID_A: [milestone.get("txtPersonId_A").value],
              person_NM_A: [milestone.get("txtPersonName_A").value],
              activity_ID_A: [milestone.get("txtActivityId_A").value],
              user_ID_P: [milestone.get("txtPersonId_P").value],
              activity_ID_P: [milestone.get("txtActivityId_P").value],
              person_NM_P: [milestone.get("txtPersonName_P").value],
              user_ID_R: [milestone.get("txtPersonId_R").value],
              activity_ID_R: [milestone.get("txtActivityId_R").value],
              person_NM_R: [milestone.get("txtPersonName_R").value],
              milestone_DESCRIPTION_TX: [milestone.get("txtComments").value],
              customer_REQUEST_RECEIPT_DT: [milestone.get("txtCustReceiptDt").value],
              customer_REQUEST_ID: [milestone.get("txtCustRequestId").value],
              commReasons: [this.getComReasons(milestone).value],
            }));
        }  
      });
      return formArray;
  }

  getComReasons(milestone: any) 
  {
    var formArray = this.formBuilder.array([]);
      milestone.get("commReasons").value.forEach(reason => {
        formArray.push(this.formBuilder.group({
          new_REASON: [reason.txtNewReason],
          reject_REASON_ID: [reason.txtRejectId],
          milestone_REJECT_REASON_ID: [reason.txtCode],
          reject_TITLE_NM: [reason.txtReason], 
          proposed_DAYS_FOR_CDEF_QY: [reason.txtDaysProposed],
          actual_DAYS_FOR_CDEF_QY: [reason.txtDaysActual],
          cdef_COMMENT_TX: [reason.txtComments],
        }));
      });
    return formArray;
  }

  checkCommRequired(index:number, milestoneId:any) {
    this.caseRestService.getCommRequiredIn(encodeURIComponent(milestoneId+"#"+this.serviceId))
    .subscribe(
      data => {
        this.milestones.controls[index].get("txtCommRequired").setValue(data.toString());
      },
      err => {
        console.log("Error occured: getCommRequiredIn()"+err.message);
        this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, JSON.stringify(err.message))
      }
    );  
  }

  checkPrerequiste(index:number, milestoneId:any) {
    this.caseRestService.getMilestonePrerequiste(encodeURIComponent(milestoneId+"@"+this.caseId+"@"+this.caseVerId+"#"+this.serviceId))
    .subscribe(
      data => {
        console.log("===data==="+JSON.stringify(data));
        if (data.length === 0) {
            console.log("data.length=0 No row return!");
            if (this.invalidPrerequistes.has(index)) 
                this.invalidPrerequistes.delete(index);
            if (this.prereWithActualDate.has(index)) 
                this.prereWithActualDate.delete(index);
        } else {
            if (!data[0].actualDATE) {
                console.log("Date = null (Set Prereq)")
                this.invalidPrerequistes.set(index, data[0]);
                if (this.prereWithActualDate.has(index)) 
                    this.prereWithActualDate.delete(index);
            } else {
                console.log("Date != null (Set Prereq Date)")
                this.prereWithActualDate.set(index, data[0]);
                if (this.invalidPrerequistes.has(index)) 
                    this.invalidPrerequistes.delete(index);
            }
        }
      },
      err => {
        console.log("Error occured: checkPrerequiste()"+err.message);
        this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, JSON.stringify(err.message))
      }
    );  
  }

  checkFormValues(formValue) 
  {
    var minVerMilestoneDate = formatDate('1899-01-01', 'yyyy-MM-dd', 'en');
    var maxVerMilestoneDate = formatDate('2999-12-31', 'yyyy-MM-dd', 'en');
    let jsonFormValue = JSON.parse(JSON.stringify(formValue));
    jsonFormValue.milestones.forEach(milestone => {
      if (milestone.new_MILESTONE === 'insert' && milestone.milestone_ID ==='') {
          this.emptyMilestoneFlage = true;
      } else {
          this.checkActualandPlannedDate(milestone, minVerMilestoneDate, maxVerMilestoneDate);  
          this.checkRevisedPlannedDate(milestone, minVerMilestoneDate, maxVerMilestoneDate);
      }
    });
  }

  checkActualandPlannedDate(milestone:any, minVerDate:any, maxVerDate:any) 
  {
    let invalidMessages:string = '';
    if (!milestone.case_VERSION_MILESTONE_DT_A && !milestone.case_VERSION_MILESTONE_DT_P) {
         invalidMessages = " mandatory fields Actual Date and/or Planned Date are missing.";
    } else {
         if (this.checkActualDate(milestone, minVerDate, maxVerDate) !='')
             invalidMessages = invalidMessages +"&"+ this.checkActualDate(milestone, minVerDate, maxVerDate);
 
         if (this.checkPlannedDate(milestone, minVerDate, maxVerDate) !='')
             invalidMessages = invalidMessages +"&"+ this.checkPlannedDate(milestone, minVerDate, maxVerDate);
    }
    if (invalidMessages !='')
        this.invalidActPlanDate.set(milestone.milestone_ID, "The "+milestone.milestone_ID+" milestone "+invalidMessages.substring(1));
  }

  checkActualDate(milestone:any, minVerDate:any, maxVerDate:any) 
  {
    let invalidMessages:string = '';
    const currentDate = formatDate(new Date(), 'yyyy-MM-dd', 'en');
    if (milestone.case_VERSION_MILESTONE_DT_A !=null) {
        if (formatDate(new Date(milestone.case_VERSION_MILESTONE_DT_A).valueOf(), 'yyyy-MM-dd', 'en') < minVerDate ||
            formatDate(new Date(milestone.case_VERSION_MILESTONE_DT_A).valueOf(), 'yyyy-MM-dd', 'en') > maxVerDate) 
        {   
            invalidMessages = " Actual date invalid. ";
        } else {
            if (currentDate < formatDate(new Date(milestone.case_VERSION_MILESTONE_DT_A).valueOf(), 'yyyy-MM-dd', 'en')) {
                invalidMessages = " Actual date cannot be greater than the current date. ";
            } 
        }
    }
    return invalidMessages;
  }

  checkPlannedDate(milestone:any, minVerDate:any, maxVerDate:any) 
  {
    let invalidMessages:string = '';
    if (milestone.case_VERSION_MILESTONE_DT_P !=null) { 
        if (formatDate(new Date(milestone.case_VERSION_MILESTONE_DT_P).valueOf(), 'yyyy-MM-dd', 'en') < minVerDate ||
            formatDate(new Date(milestone.case_VERSION_MILESTONE_DT_P).valueOf(), 'yyyy-MM-dd', 'en') > maxVerDate) 
        {
            invalidMessages = " Planned date invalid. ";
        }
    }
    return invalidMessages;
  }

  checkRevisedPlannedDate(milestone:any, minVerDate:any, maxVerDate:any) 
  {
    let invalidMessages:string = '';
    if (milestone.case_VERSION_MILESTONE_DT_R !=null) {
        if (formatDate(new Date(milestone.case_VERSION_MILESTONE_DT_R).valueOf(), 'yyyy-MM-dd', 'en') < minVerDate ||
            formatDate(new Date(milestone.case_VERSION_MILESTONE_DT_R).valueOf(), 'yyyy-MM-dd', 'en') > maxVerDate) 
        {
            invalidMessages = " Revised planned date invalid. ";
        } else {
            if (this.recentAODFlage) { /** && (milestone.milestone_ID ==='AODGRPA' || milestone.milestone_ID ==='AODGRPB' || milestone.milestone_ID ==='AODGRPC' || milestone.milestone_ID ==='AODGRPD')) { */ 
                if (milestone.customer_REQUEST_ID === null)
                    invalidMessages = invalidMessages +"&"+ " The Rev. Planned milestone date cannot be entered because case version is not associated with a customer request";
                else {
                    invalidMessages = this.checkCustReceiptDt(milestone);
                }
            }
        }
    }
    if (invalidMessages !='')
        this.invalidRevPlannDate.set(milestone.milestone_ID, "The "+milestone.milestone_ID+" milestone "+invalidMessages.substring(1));
  }

  checkCustReceiptDt(milestone:any) 
  {
    let invalidMessages:string = '';
    let aodEffectiveDt  = formatDate(new Date(this.aodEffectiveDate).valueOf(), 'yyyy-MM-dd', 'en');
    let aodExpirationDt: any = null;
    if (this.aodExpirationDate !=null)
        aodExpirationDt = formatDate(new Date(this.aodExpirationDate).valueOf(), 'yyyy-MM-dd', 'en');
    let custReceiptDt   = formatDate(new Date(milestone.customer_REQUEST_RECEIPT_DT).valueOf(), 'yyyy-MM-dd', 'en');
    let plannedDt       = formatDate(new Date(milestone.case_VERSION_MILESTONE_DT_P).valueOf(), 'yyyy-MM-dd', 'en') ;
    let revPlannedDt    = formatDate(new Date(milestone.case_VERSION_MILESTONE_DT_R).valueOf(), 'yyyy-MM-dd', 'en') ;
    console.log("custReceiptDt=="+custReceiptDt+"==aodEffectiveDt=="+aodEffectiveDt+"==aodExpirationDt=="+aodExpirationDt)
    if (custReceiptDt < aodEffectiveDt || plannedDt > revPlannedDt || (aodExpirationDt !=null && custReceiptDt > aodExpirationDt)) {
        invalidMessages = invalidMessages +"&"+ " Planned Date for the AOD Group milestones cannot be reduced.";
    }
    if (custReceiptDt > revPlannedDt) {
        invalidMessages = invalidMessages +"&"+ " Rev Planned milestone date cannot be less than the "+custReceiptDt+" date of the LOR for this AOD.";
    } 
    return invalidMessages;
  }

  checkdupMilestones() 
  {
    let milestoneArray:string[] = [];
    let mileExistArray:string[] = [];
    let mileNewArray:string[]   = [];
    let dstatusDate = this.getDstatusDate();
    let rstatusDate = this.getRstatusDate();
    console.log("dstatusDate=="+dstatusDate+"==rstatusDate=="+rstatusDate)

    this.milestones.controls.forEach(milestone => {
      if (milestone.get("txtNewMilestone").value === '') {
          mileExistArray = this.getMileExistArray(milestone, rstatusDate, dstatusDate, mileExistArray);
      } else {
          mileNewArray = this.getMileNewArray(milestone, mileNewArray);
      }
    });

    milestoneArray = [...new Set(mileExistArray)].concat(mileNewArray)
    this.duplicateMilestones = milestoneArray.reduce(function(acc, el, i, arr) 
    {
      if (arr.indexOf(el) !== i && acc.indexOf(el) < 0) 
          acc.push(el); 
      return acc;
    }, []);

    return this.duplicateMilestones;
  }

  getDstatusDate() 
  {
    let dstatusDate: any = null;
    this.milestones.controls.forEach(milestone => {
      if (milestone.get("txtNewMilestone").value ===null || milestone.get("txtNewMilestone").value ==='') {
          if (milestone.get("txtMilestoneId").value === 'DSTATUS') {
              if (milestone.get("txtActualDate_A").value !=null)
                  dstatusDate = formatDate(new Date(milestone.get("txtActualDate_A").value).valueOf(), 'yyyy-MM-dd', 'en');
              if (milestone.get("txtPlannedDate_P").value !=null)
                  dstatusDate = formatDate(new Date(milestone.get("txtPlannedDate_P").value).valueOf(), 'yyyy-MM-dd', 'en');
              if (milestone.get("txtRevisedDate_R").value !=null)
                  dstatusDate = formatDate(new Date(milestone.get("txtRevisedDate_R").value).valueOf(), 'yyyy-MM-dd', 'en');
          }
      }
    });
    return dstatusDate;
  }

  getRstatusDate() 
  {
    let rstatusDate: any = null;
    this.milestones.controls.forEach(milestone => {
      if (milestone.get("txtNewMilestone").value ===null || milestone.get("txtNewMilestone").value ==='') {
          if (milestone.get("txtMilestoneId").value === 'RSTATUS') {
            if (milestone.get("txtActualDate_A").value !=null)
                rstatusDate = formatDate(new Date(milestone.get("txtActualDate_A").value).valueOf(), 'yyyy-MM-dd', 'en');
            if (milestone.get("txtPlannedDate_P").value !=null)
                rstatusDate = formatDate(new Date(milestone.get("txtPlannedDate_P").value).valueOf(), 'yyyy-MM-dd', 'en');
            if (milestone.get("txtRevisedDate_R").value !=null)
                rstatusDate = formatDate(new Date(milestone.get("txtRevisedDate_R").value).valueOf(), 'yyyy-MM-dd', 'en');
          }
      }
    });
    return rstatusDate;
  }

  getMileExistArray(milestone: any, rstatusDate: any, dstatusDate: any, mileExistArray: string[]) 
  {     
    if (milestone.get("txtMilestoneId").value === 'MILSGN') {
        if (rstatusDate != null) 
            this.getMileExistMILSIGArray(milestone, rstatusDate, mileExistArray);
    } else {
        if (dstatusDate != null) 
            this.getMileExistNonMILSIGArray(milestone, dstatusDate, mileExistArray);
    }

    return mileExistArray;
  }

  getMileExistMILSIGArray(milestone:any, rstatusDate:any, mileExistArray:string[]) 
  {
    if (rstatusDate <= formatDate(new Date(milestone.get("txtActualDate_A").value).valueOf(), 'yyyy-MM-dd', 'en')) 
        mileExistArray.push(milestone.get("txtMilestoneId").value+"@"+milestone.get("txtActualDate_A").value+"@A");
    if (rstatusDate <= formatDate(new Date(milestone.get("txtPlannedDate_P").value).valueOf(), 'yyyy-MM-dd', 'en')) 
        mileExistArray.push(milestone.get("txtMilestoneId").value+"@"+milestone.get("txtPlannedDate_P").value+"@P");
    if (rstatusDate <= formatDate(new Date(milestone.get("txtRevisedDate_R").value).valueOf(), 'yyyy-MM-dd', 'en')) 
        mileExistArray.push(milestone.get("txtMilestoneId").value+"@"+milestone.get("txtRevisedDate_R").value+"@R");

    return mileExistArray;
  }

  getMileExistNonMILSIGArray(milestone:any, dstatusDate:any, mileExistArray:string[]) 
  {
    if (dstatusDate <= formatDate(new Date(milestone.get("txtActualDate_A").value).valueOf(), 'yyyy-MM-dd', 'en')) 
        mileExistArray.push(milestone.get("txtMilestoneId").value+"@"+milestone.get("txtActualDate_A").value+"@A");
    if (dstatusDate <= formatDate(new Date(milestone.get("txtPlannedDate_P").value).valueOf(), 'yyyy-MM-dd', 'en')) 
        mileExistArray.push(milestone.get("txtMilestoneId").value+"@"+milestone.get("txtPlannedDate_P").value+"@P");
    if (dstatusDate <= formatDate(new Date(milestone.get("txtRevisedDate_R").value).valueOf(), 'yyyy-MM-dd', 'en')) 
        mileExistArray.push(milestone.get("txtMilestoneId").value+"@"+milestone.get("txtRevisedDate_R").value+"@R");

    return mileExistArray;
  }

  getMileNewArray(milestone: any, mileNewArray:string[]) 
  {
    if (milestone.get("txtActualDate_A").value !=null) 
        mileNewArray.push(milestone.get("txtMilestoneId").value+"@"+milestone.get("txtActualDate_A").value+"@A");
    if (milestone.get("txtPlannedDate_P").value !=null) 
        mileNewArray.push(milestone.get("txtMilestoneId").value+"@"+milestone.get("txtPlannedDate_P").value+"@P");
    if (milestone.get("txtRevisedDate_R").value !=null) 
        mileNewArray.push(milestone.get("txtMilestoneId").value+"@"+milestone.get("txtRevisedDate_R").value+"@R");

    return mileNewArray;
  }

  validateFormValues(formValue: any) {
    this.checkFormValues(formValue);
    if (this.emptyMilestoneFlage) {
        this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, "The milestone Id & milestone name are missing.");
        return false;
    } else {
        if (this.invalidActPlanDate.size > 0 || this.invalidRevPlannDate.size > 0) {
            let invalidDates = new Map([...this.invalidActPlanDate.entries(), ...this.invalidRevPlannDate.entries()]);
            this.dsamsMethodsService.openMegsListDialog(DsamsConstants.diaLsWidth, invalidDates);
            return false;
        } else {
            if (this.invalidActPlanDate.size > 0 || this.invalidRevPlannDate.size > 0) {
                let invalidDates = new Map([...this.invalidActPlanDate.entries(), ...this.invalidRevPlannDate.entries()]);
                this.dsamsMethodsService.openMegsListDialog(DsamsConstants.diaLsWidth, invalidDates);
                return false;
            } else {
                let invalidPrereqMessages =  new Map([...this.invalidPrerequistesMegs(formValue).entries(), ...this.prereWithActualDateMegs(formValue).entries()]);
                if (invalidPrereqMessages.size > 0) {
                    this.dsamsMethodsService.openMegsListDialog(DsamsConstants.diaLsWidth, invalidPrereqMessages);
                    return false;
                }
            }
        }
    }
    return true;
  }

  invalidPrerequistesMegs(formValue:any) {
    let invalidPrerequistesNew  = new Map(); 
    if (this.invalidPrerequistes.size > 0) {
        let jsonFormValue = JSON.parse(JSON.stringify(formValue));
        jsonFormValue.milestones.forEach(milestone => {
          if (milestone.new_MILESTONE === 'insert' || milestone.new_MILESTONE === 'update') {
            for (let data of this.invalidPrerequistes.values()) {
                 invalidPrerequistesNew = this.addPrerequistesMegs(milestone, data, invalidPrerequistesNew);
            }
          }
        });
    }
    return invalidPrerequistesNew;
  }

  addPrerequistesMegs(milestone:any, data:any, invalidPrerequistesTmp:any) 
  {
    if (milestone.milestone_ID === data.milestone_ID) {
        if (milestone.case_VERSION_MILESTONE_DT_A != null) 
            invalidPrerequistesTmp.set(data.milestone_ID, "The "+data.prerequisite_MILESTONE_ID+" milestone with an actual date must occur prior to "+data.milestone_ID+".");
    }
    return invalidPrerequistesTmp;
  }

  prereWithActualDateMegs(formValue:any) {
    let prereWithActualDateNew  = new Map(); 
    if (this.prereWithActualDate.size > 0 || this.cacheWithActualDate.size > 0) {
        let jsonFormValue = JSON.parse(JSON.stringify(formValue));
        jsonFormValue.milestones.forEach(milestone => {
          if (milestone.new_MILESTONE === 'insert' || milestone.new_MILESTONE === 'update') {
            for (let data of this.prereWithActualDate.values()) {
                 prereWithActualDateNew = this.addPrereActualDateMegs(milestone, data, prereWithActualDateNew);
            } 
            for (let data of this.cacheWithActualDate.values()) {
                 prereWithActualDateNew = this.addCacheActualDateMegs(milestone, data, prereWithActualDateNew);
            }  
          }
        });
    }
    return prereWithActualDateNew;
  }

  addPrereActualDateMegs(milestone:any, data:any, prereWithActualDateTmp:any) 
  {
    if (milestone.case_VERSION_MILESTONE_DT_A != null) {
        let prereqDate = formatDate(new Date(data.actualDATE).valueOf(), 'yyyy-MM-dd', 'en');
        let actualDate = formatDate(new Date(milestone.case_VERSION_MILESTONE_DT_A).valueOf(), 'yyyy-MM-dd', 'en');
        console.log(data.milestone_ID+"==>pre"+prereqDate+"==act"+actualDate)
        if (prereqDate > actualDate)
            prereWithActualDateTmp.set(data.milestone_ID, "The "+data.prerequisite_MILESTONE_ID+" milestone with an actual date must occur prior to "+data.milestone_ID+".");
    } else {
        this.cacheWithActualDate.set(data.milestone_ID, data);
    }
    return prereWithActualDateTmp;
  }

  addCacheActualDateMegs(milestone:any, data:any, prereWithActualDateTmp:any) 
  {
    if (milestone.case_VERSION_MILESTONE_DT_A != null) {
        if (milestone.milestone_ID === data.milestone_ID) {
            let prereqDate = formatDate(new Date(data.actualDATE).valueOf(), 'yyyy-MM-dd', 'en');
            let actualDate = formatDate(new Date(milestone.case_VERSION_MILESTONE_DT_A).valueOf(), 'yyyy-MM-dd', 'en');
            console.log(data.milestone_ID+"cache==>pre"+prereqDate+"==act"+actualDate)
            if (prereqDate > actualDate)
                prereWithActualDateTmp.set(data.milestone_ID, "The "+data.prerequisite_MILESTONE_ID+" milestone with an actual date must occur prior to "+data.milestone_ID+".");
        } 
    } 
    return prereWithActualDateTmp;
  }

  saveCaseMilestones(formValue: any) {
    this.caseRestService.postCaseMilestones(formValue)
    .subscribe(
      saveFlag => {
        if (saveFlag) {
            this._snackBar.open("Case milestone data has been saved successfully!", 'close',  {
              duration: this.durationInSeconds * 1000,
              panelClass: ['mat-toolbar', 'mat-primary']  
            });
        } else {
            this._snackBar.open("Case milestone data saved failure!", 'close',  {
              duration: this.durationInSeconds * 1000,
              panelClass: ['mat-toolbar', 'mat-warn']     
            });
       }
       this.refreshPage();
      },
      err => {
        console.log("Error occured: saveCaseMilestones()"+err.message);
        this.editToggleEvent.emit(true);
        this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, JSON.stringify(err.message))
      }
    );    
  }

  refreshPage() {
    this.invalidActPlanDate.clear();
    this.invalidRevPlannDate.clear();
    this.invalidPrerequistes.clear();
    this.prereWithActualDate.clear();
    this.invalidFormValues.clear();
    this.cleanUpTxtInsertUpdate();
    this.setPanel(-1);
    this.milestones.clear();
    this.getCaseMilestones(encodeURIComponent(this.caseId+"@"+this.caseVerId+"#"+this.serviceId));
  }

  checkFormInvalid() {
    this.milestones.controls.forEach(milestone => { 
     if (milestone.get('txtNewMilestone').value === 'insert' && milestone.get('txtMilestoneId').value ==='') {
          this.emptyMilestoneFlage = true;
      } else {
          this.checkFormInvalidDates(milestone);
      }
    });
  }

  checkFormInvalidDates(milestone:any) 
  {
    let invalidMessages:string = '';
    if (milestone.get('txtActualDate_A') !=null && milestone.get('txtActualDate_A').invalid)
        invalidMessages= invalidMessages +"&"+ " Actual date invalid ";
    if (milestone.get('txtPlannedDate_P') !=null && milestone.get('txtPlannedDate_P').invalid)
        invalidMessages= invalidMessages +"&"+ " Planned date invalid ";
    if (milestone.get('txtRevisedDate_R') !=null && milestone.get('txtRevisedDate_R').invalid)
        invalidMessages= invalidMessages +"&"+ " Revised planned date invalid ";
    if (milestone.get('txtComments').invalid)
        invalidMessages= invalidMessages +"&"+ " 	mandatory fields Comments is missing. ";

    if (invalidMessages !='')
        this.invalidFormValues.set(milestone.get('txtMilestoneId').value, "The "+milestone.get('txtMilestoneId').value+" milestone "+invalidMessages.substring(1));
  }

  onSubmit() {
    this.emptyMilestoneFlage = false;
    if (this.milestonesForm.invalid) {
        this.checkFormInvalid();
        if (this.emptyMilestoneFlage) 
            this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, "The milestone Id & milestone name are missing.");
        else {
            if (this.invalidFormValues.size > 0) 
                this.dsamsMethodsService.openMegsListDialog(DsamsConstants.diaLsWidth, this.invalidFormValues);
        }
        return;
    }    
    if (this.checkObjectChanged()) {
        this.invalidActPlanDate.clear();
        this.invalidRevPlannDate.clear();
        this.invalidFormValues.clear();
        if (this.validateFormValues(this.buildNewFormValue())) {
            if (this.checkdupMilestones().length == 0) 
                this.saveCaseMilestones(this.buildNewFormValue()); 
            else 
                this.dupMilestonesPopup();
        }
    } else
        this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, DsamsConstants.NO_DATA_CHANGES_FOR_SAVE);
  }

  dupMilestonesPopup() 
  {
    let dupMilestoneIds: string = '';
    if (this.duplicateMilestones.length > 0) {
        this.duplicateMilestones.forEach(item =>{
          dupMilestoneIds = dupMilestoneIds +","+item.split('@')[0];
        })
        const dialogConfig = new MatDialogConfig();
        dialogConfig.disableClose = true;
        dialogConfig.autoFocus = true;
        dialogConfig.width= DsamsConstants.diaWidth;
        dialogConfig.data = {message: "You are saving a duplicate milestone "+dupMilestoneIds+". Do you want to continue?", indecator: null};
        const dialogRef = this.dialog.open(DialogMessageYesnoComponent, dialogConfig);
        dialogRef.afterClosed().subscribe(result => {
          if (result == 1) {
              this.duplicateMilestones.splice(0);
              this.saveCaseMilestones(this.buildNewFormValue()); 
          }
        });
    }
  }

  /*=======================================
    SonarQube fix for Cognitive Complexity
  =========================================*/
  getMilestoneDateA(milestone?:any) {
    let milestoneDateA:any;
    if (milestone) {
      if (milestone.case_VERSION_MILESTONE_DT_A != null)
          milestoneDateA = new Date(milestone.case_VERSION_MILESTONE_DT_A);
    }
    return milestoneDateA;
  }
  getMilestDateAOri(milestone?:any) {
    let mileDateAOri:any;
    if (milestone) {
      if (milestone.case_VERSION_MILESTONE_DT_A != null)
          mileDateAOri = new Date(milestone.case_VERSION_MILESTONE_DT_A);
    }
    return mileDateAOri;
  }
  getMilestoneDateP(milestone?:any) {
    let milestoneDateP:any;
    if (milestone) {
      if (milestone.case_VERSION_MILESTONE_DT_P != null)
          milestoneDateP = new Date(milestone.case_VERSION_MILESTONE_DT_P);     
    }
    return milestoneDateP;
  }
  getMilestDatePOri(milestone?:any) {
    let milesDatePOri:any;
    if (milestone) {
      if (milestone.case_VERSION_MILESTONE_DT_P != null)
          milesDatePOri = new Date(milestone.case_VERSION_MILESTONE_DT_P);     
    }
    return milesDatePOri;
  }
  getMilestoneDateR(milestone?:any) {
    let milestoneDateR:any;
    if (milestone) {
      if (milestone.case_VERSION_MILESTONE_DT_R != null)
          milestoneDateR = new Date(milestone.case_VERSION_MILESTONE_DT_R);     
    }
    return milestoneDateR;
  }
  getMilestDateROri(milestone?:any) {
    let milesDateROri:any;
    if (milestone) {
      if (milestone.case_VERSION_MILESTONE_DT_R != null)
          milesDateROri = new Date(milestone.case_VERSION_MILESTONE_DT_R);     
    }
    return milesDateROri;
  }
  getDescriptTx(milestone?:any) {
    let descriptTx:any = "";
    if (milestone) {
      if (milestone.milestone_DESCRIPTION_TX)
          descriptTx = milestone.milestone_DESCRIPTION_TX;
    }
    return descriptTx;
  }
  getDescriTxOri(milestone?:any) {
    let descriTxOri:any = "";
    if (milestone) {
      if (milestone.milestone_DESCRIPTION_TX)
          descriTxOri = milestone.milestone_DESCRIPTION_TX;
    }
    return descriTxOri;
  }
  getPersonNMA(milestone?:any) {
    return milestone?milestone.person_NM_A:"";
  }
  getPersonNMP(milestone?:any) {
    return milestone?milestone.person_NM_P:"";
  }
  getPersonNMR(milestone?:any) {
    return milestone?milestone.person_NM_R:"";
  }
  getActivityIdA(milestone?:any) {
    return milestone?milestone.activity_ID_A:"";
  }
  getActivityIdP(milestone?:any) {
    return milestone?milestone.activity_ID_P:"";
  }
  getActivityIdR(milestone?:any) {
    return milestone?milestone.activity_ID_R:"";
  }
  getComRequiredIn(milestone?:any) {
    return milestone?milestone.milestone_COMMENTS_REQUIRED_IN:"0";
  }
  getMilestoneOverrideIn(milestone?:any) {
    let overrideIn = false;
    if (milestone) {
      if (milestone.milestone_OVERRIDE_IN == '1')
          overrideIn = true;
    }
    return overrideIn;
  }
  getPersonIdA(milestone?:any) {
    return milestone?milestone.user_ID_A:"";
  }
  getPersonIdP(milestone?:any) {
    return milestone?milestone.user_ID_P:"";
  }
  getPersonIdR(milestone?:any) {
    return milestone?milestone.user_ID_R:"";
  }
  getFirstOccurDate(milestone?:any) {
    let firstOccrDate = "";
    if (milestone) {
      if (milestone.create_DT != null)
          firstOccrDate = milestone.create_DT;
    }
    return firstOccrDate;
  }

  /*==================
   * Begin Call WI005
   *==================*/
  callWI005(csuCd:string, caseId:string, caseVersionId:string, optUsage:string, milestoneId:string ): void  
  { 
    let passingData = new ValidateWebComponentInput();
    passingData.csuCd = csuCd;
    passingData.caseId = caseId;
    passingData.caseVersionId = caseVersionId;
   
    this.validateWebComponent(passingData , optUsage, milestoneId);
  }  

  validateWebComponent(inputData: ValidateWebComponentInput, optUsage:string, milestoneId:string)  {  
    console.log("InputData: csuCd==" + inputData.csuCd + " CaseId==" + inputData.caseId + " CaseVersionId==" + inputData.caseVersionId); 
    this.caseRestService.postValidateWebComponent(inputData)
    .subscribe(
      data => { 
        let result = data;       
        JSON.stringify(result);
        if (!result.success) {
            const errorMsg: string = MessageMgr.getMesssage(result.theErrorId).messageText;          
            let errorMsgWithParamVal = errorMsg.replace('%1', result.param1).replace('%2', result.param2).replace('%3', result.param3);
            this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, JSON.stringify(errorMsgWithParamVal)); 
            this.editToggleEvent.emit(false);        
        } else {
            if (!this.cancelBtnClick)
                this.refreshPage();
        }
      },
      err => {
        console.log("Errors in validateWebComponent()"+JSON.stringify(err.message));
        this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, JSON.stringify(err.message))
      }
    );      
  }

  
   // begin DSAMS-5944 09/22 DB
   getMilestoneListLockSessionId(): number {
    let lockId: string = sessionStorage.getItem(CaseMilestoneComponent.LIST_LOCK_SESSION_ID);
    if (lockId == null) {
      lockId = "0";
      sessionStorage.setItem(CaseMilestoneComponent.LIST_LOCK_SESSION_ID, lockId);
    }
    return parseInt(lockId);
  }
  
  setMileStoneListLockSessionId(lockSessionId) {
       sessionStorage.setItem(CaseMilestoneComponent.LIST_LOCK_SESSION_ID,lockSessionId);
   
  
  }
  
 
  prepareMilestoneListForEdit(caseVersionId, caseId) {
    let lockSessionId = this.getMilestoneListLockSessionId();
    if (lockSessionId > 0) {
      this.lockMilestoneList(caseVersionId, caseId, lockSessionId);
    } else {
      this.caseRestService.openLegacyLockSession()
        .subscribe(
          newLockSessionId => {
            this.setMileStoneListLockSessionId(newLockSessionId);
            this.lockMilestoneList(caseVersionId, caseId, newLockSessionId);
             
           },
    err => {
      this.handleError("prepareMilestoneListForEdit", err);
    }
        );
  }
    }
    
  private listLock: boolean = false;
  private locking: boolean = false;
  lockMilestoneList(caseVersionId: string, caseId: string, lockSessionId) {
    if (lockSessionId > 0 && !this.listLock && !this.locking) {
      this.locking = true;
       this.caseRestService.setCaseVersionListLock("CASE_VERSION_MILESTONE", caseVersionId, caseId, lockSessionId.toString())
         .subscribe(
           lockMsg => {
             if (lockMsg.length > 1) {
             //   this.setEditToggleMode(false);
                //post M7
               this.messageService.infoMessage("Lock Conflict", lockMsg);
               this.editToggleEvent.emit(false);  
               this.locking = false;
             
             } else {
               this.listLock = true;
               this.locking = false;
             }
           
           },
           err => {
            this.listLock = false;
            this.locking = false;
             this.handleError("lockMilestoneList", err);
             this.editToggleEvent.emit(false); 
          }
      );
        }
  }
  
  
  unLockMilestoneList() {
    let lockSessionId = this.getMilestoneListLockSessionId();
    if (lockSessionId > 0) {
      this.caseRestService.closeLegacyLockSession(lockSessionId.toString())
        .subscribe(
          data => {
            sessionStorage.setItem(CaseMilestoneComponent.LIST_LOCK_SESSION_ID, "0");
            this.listLock = false;
          },
          err => {
            this.handleError("unLockMilestoneList", err);
          }
        );
    }

  }
  
 
  
  handleError(apiUrl: string, error: any) {
    let errorMsgTitle: string = "";
    let errorMsg: string = "";
    let details: string = "";
    let errorCode: string = "";
    if (error.error == null) {
      /**SonarQube issue: useless assignment
         errorMsgTitle = error.name;
         details = null;
         errorMsg = "Status Code " + errorCode + ", " + errorMsg;
         errorMsg = error.message;
         errorCode = (typeof error.status !== 'undefined') ? error.status : 0;
      */
    } else if (error.error instanceof ErrorEvent) {
      errorMsg = 'An error event occurred: ' + error.error.message;
      errorMsgTitle = "Local Error"
      this.messageService.infoMessage(errorMsgTitle, errorMsg);
      if (!!details) {
        console.log(errorMsg);
      }
      
    } else {
      this.handleSubError(error);
    }
  }

  handleSubError(error: any) {
    let errorMsgTitle: string;
    let errorMsg: string;
    let details: string;
    if (error.error != null && typeof error.error.lockConflict !== 'undefined' && error.error.lockConflict != null) {
      if (error.error.lockConflict) {
        errorMsgTitle = "Lock Conflict";
        errorMsg = error.error.message;
        this.messageService.infoMessage(errorMsgTitle, errorMsg);
      } else {
        if (error.error.exceptionType !== 'undefined') {
          errorMsg = error.error.exceptionType +
            ' - "' + error.error.message + '"';
          details = errorMsg + "\n" + error.error.stackTrace;
        }
      }
    }
    console.log(errorMsg);
    if (!!details) {
      console.log(errorMsg);
    }
    
  }

  ngOnDestroy() {
    // begin DSAMS-5944 09/22 DB
    this.unLockMilestoneList();
    // end DSAMS-5944 09/22 DB

  }



}
