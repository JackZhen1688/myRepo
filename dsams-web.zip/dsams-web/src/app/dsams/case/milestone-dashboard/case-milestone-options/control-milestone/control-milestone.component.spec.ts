import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ControlMilestoneComponent } from './control-milestone.component';

describe('ControlMilestoneComponent', () => {
  let component: ControlMilestoneComponent;
  let fixture: ComponentFixture<ControlMilestoneComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ControlMilestoneComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ControlMilestoneComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
