import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { MatDialog, MatDialogConfig} from '@angular/material/dialog';
import { FormBuilder, FormGroup } from '@angular/forms';
import { CaseRestfulService } from './../../services/case-restful.service';
import { DsamsConstants } from './../../../dsams.constants';
import { DsamsMethodsService } from './../../../services/dsams-methods.service';
import { ControlMilestoneComponent } from  '../case-milestone-options/control-milestone/control-milestone.component';
import { ValidateWebComponentInput } from './../../../entities/specialEntities/validate-web-component-input.model';
import { ValidateWebComponentResult } from './../../../entities/specialEntities/validate-web-component-result.model';
import { MessageMgr } from './../../validation/message-mgr';
import { MatSnackBar } from '@angular/material/snack-bar';
import { DialogMessageYesnoComponent } from './../../../../dsams/utilitis/dialogs/dialog-message-yesno/dialog-message-yesno.component';
import { CaseUtils } from '../../utils/case-utils';
import { ErrorParameter } from '../../../entities/specialEntities/error-parameter.model';
import { SaveResultsType } from '../../validation/save-results-type';
import { DsamsUserMessageService } from '../../../services/dsams-user-message.service';

interface Options {
  csuCd:string;
  label:string;
  milId:string;
  usage:string;
  disabled:boolean;
}
interface OptionGroup {
  disabled?: boolean;
  name: string;
  options: Options[];
}
@Component({
  selector: 'app-case-milestone-options',
  templateUrl: './case-milestone-options.component.html',
  styleUrls: ['./case-milestone-options.component.css']
})
export class CaseMilestoneOptionsComponent implements OnInit {

  @Input() caseId: string;
  @Input() userCaseId: string;
  @Input() caseVerId: string;
  @Input() typeWithNum: string;
  @Input() milestoneId: string;
  @Input() serviceId: string;
  @Input() isEditable: boolean;
  @Output() isRefresh = new EventEmitter<number>();

  optionGroups: OptionGroup[];
  
  durationInSeconds = 3;
  caseHeaderData: any = {};
  caseValidationLevel: number = MessageMgr.MSG_TYPE_NONE;
  // begin jiracard DSAMS-5848 08/2022 AKP
  validateWebComponentResult: ValidateWebComponentResult;
  validateWebComponentInput: ValidateWebComponentInput;
  // end jiracard DSAMS-5848 08/2022 AKP

  milestoneOptForm: FormGroup;

  constructor(public dialog: MatDialog,
              private formBuilder: FormBuilder,
              private caseRestService: CaseRestfulService,
              private dsamsMethodsService: DsamsMethodsService,
              private messageService: DsamsUserMessageService,
              private _snackBar: MatSnackBar) { 

    this.milestoneOptForm = this.formBuilder.group({
     'txtOption': this.formBuilder.control('selectOption'),
    });
  }

  ngOnInit() {

    this.getOptionGroups(encodeURIComponent(this.caseId+"@"+this.caseVerId+"#"+this.serviceId));
  }

  get txtOption() {
    return this.milestoneOptForm.get('txtOption');
  }
    
  getOptionGroups(filter: string) {
    this.caseRestService.getOptionGroups(filter)
    .subscribe(
      data => { 
        this.optionGroups = data;   
        console.log("reload the options")
      },
      err => {
        this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, JSON.stringify(err.message))
      }
    );    
  }

  // begin jiracard DSAMS-5848 08/2022 AKP
  callWI005(csuCd:string, caseId:string, caseVersionId:string, optUsage:string, milestoneId:string )  { 
    let passingData = new ValidateWebComponentInput();
    passingData.csuCd = csuCd;
    passingData.caseId = caseId;
    passingData.caseVersionId = caseVersionId;
    
    this.validateWebComponent(passingData , optUsage, milestoneId);
  }  
  validateWebComponent(inputData: ValidateWebComponentInput, optUsage:string, milestoneId:string)  {  
    console.log("InputData: csuCd==" + inputData.csuCd + " CaseId==" + inputData.caseId + " CaseVersionId==" + inputData.caseVersionId); 
    this.caseRestService.postValidateWebComponent(inputData)
    .subscribe(
      data => { 
        let result = data;       
        JSON.stringify(result);
        if (!result.success) {
                            
          // Format message and dispaly it.
          // Get error message text based on the errorId and replace % signs with passed param1, param2, param3 values
          const errorMsg: string = MessageMgr.getMesssage(result.theErrorId).messageText;          
          let errorMsgWithParamVal = errorMsg.replace('%1', result.param1).replace('%2', result.param2).replace('%3', result.param3);
          this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, errorMsgWithParamVal);         
          this.txtOption.setValue('selectOption');
        }
        else {
          // Additional validations on some selected options
          this.validateSelectedOption(inputData.csuCd, inputData.caseId, inputData.caseVersionId, optUsage, milestoneId);
        }       
      },
      err => {
        console.log("Errors in validateWebComponent()");
      }
    );      
  }
  // end jiracard DSAMS-5848 08/2022 AKP

  validateSelectedOption(csuCd:string, caseId:string, caseVersionId:string, optUsage:string, milestoneId:string) {
    console.log("==========validateSelectedOption: csuCd==" + csuCd + " CaseId==" + caseId + " CaseVersionId==" + caseVersionId); 
    this.caseRestService.validateSelectedOption(csuCd, caseId, caseVersionId).subscribe(
      data => {
        let result = data;
        if (!result.success) {
          const errorMsg: string = MessageMgr.getMesssage(result.messageId).messageText;
          let errorMsgWithParamVal = errorMsg.replace('%1', result.param1).replace('%2', result.param2);
          const dialogConfig = new MatDialogConfig();
          dialogConfig.disableClose = true;
          dialogConfig.autoFocus = true;
          dialogConfig.width= "550px";
          dialogConfig.data = {message: errorMsgWithParamVal, indecator: null};
      
          if (result.messageType == "Simple") {
            this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, errorMsgWithParamVal);
            if (result.continueRule) {
              //------- call WP004a -----
              this.popupCtlMilestone(optUsage, milestoneId);         
            }
            else {
              this.txtOption.setValue('selectOption');
            }
          }
          else if (result.messageType == "Confirm") {
            const dialogRef = this.dialog.open(DialogMessageYesnoComponent, dialogConfig);
            dialogRef.afterClosed().subscribe(dialogResult => {
              if (dialogResult == 1) {       
                //------- call WP004a -----
                this.popupCtlMilestone(optUsage, milestoneId);         
              }
              else {
                this.txtOption.setValue('selectOption');
              }
            });     
          }
        }
        else {
          //------- call WP004a -----
          this.popupCtlMilestone(optUsage, milestoneId);         
        }
      },
      err => {
        console.log("Errors in validateSelectedOption()");
      }
    ); 
  }

  selectedOption() 
  { 
    let csuCd:string       = (this.txtOption.value).split('@')[0];
    let milestoneId:string = (this.txtOption.value).split('@')[1];
    let optUsage:string    = (this.txtOption.value).split('@')[2];
    console.log("csuCd="+csuCd+" milId=="+milestoneId+" usage="+optUsage)
    if (csuCd != 'WP0043A1' && csuCd !='WP0043A2'){
        if (csuCd == 'WP0043A02') {
            this._snackBar.open("Case validation processing ...", 'close',  {
              duration: this.durationInSeconds * 1000,
              verticalPosition: 'top',
              panelClass: ['mat-toolbar', 'mat-primary']     
            });
            this.validateCase(parseInt(this.caseId), parseInt(this.caseVerId));
        }
        else {
            // begin jiracard DSAMS-5848 08/2022 AKP
            // Call WI005 and display error if it returns error otherwise call WP004a
            this.callWI005(csuCd, this.caseId, this.caseVerId, optUsage, milestoneId);
            // end jiracard DSAMS-5848 08/2022 AKP
        }
    }        

  }

  popupCtlMilestone(optUsage:string, milestoneId:string) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width  = "700px";
    dialogConfig.height = "675px";
    dialogConfig.data   = {passingCaseID: this.caseId,
                           passingCaseVerId: this.caseVerId,
                           passingUsage: optUsage,
                           passingMilestoneId: milestoneId};
    const dialogRef = this.dialog.open(ControlMilestoneComponent, dialogConfig);
    dialogRef.afterClosed().subscribe(result => {
       this.txtOption.setValue('selectOption');
       if (result.length != 0 ) {
           console.log("get result=="+JSON.stringify(result.data));
           if (result.data)
               this.isRefresh.emit(this.getRandomNumber(10000));
       }
    });
  }

  getRandomNumber(pRange: number): number {
    var byteArray = new Uint8Array(1);
    window.crypto.getRandomValues(byteArray);
    return Math.floor(byteArray[0] % pRange);
  }

  private validateCase(pCaseId: number, pCaseVersionId: number) {
    this.caseRestService
      .validateCase(pCaseId, pCaseVersionId)
      .subscribe((pMessageList: Array<ErrorParameter>) => {
        if (pMessageList.length == 0) {
            MessageMgr.displaySuccess("No validation messages.");
        } else {
            let title: string = "DSAMS: Validate Case: " + this.userCaseId + " " + this.typeWithNum;
            this.messageService.displayMessageListTc(title, pMessageList).subscribe(() => '');
        }
        this.caseValidationLevel = SaveResultsType.caseValidationLevel(pMessageList);
        this.txtOption.setValue('selectOption');
      },
        err => {
          CaseUtils.ReportHTTPError(err, "Error validating case");
        }
      );
  }

  onSubmit() {
    console.log("form value==="+JSON.stringify(this.milestoneOptForm.value))
  }

  
}
