import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { FormBuilder, FormGroup } from '@angular/forms';
import { CaseUIService } from '../services/case-ui-service';
import { DsamsConstants } from './../../dsams.constants';
import { DsamsRestfulService } from './../../../dsams/services/dsams-restful.service';
import { CaseLineRelatedInfoType } from '../model/case-line-related-info-type';

@Component({
  selector: 'app-milestone-dashboard',
  templateUrl: './milestone-dashboard.component.html',
  styleUrls: ['./milestone-dashboard.component.css']
})
export class MilestoneDashboardComponent implements OnInit {

  serviceId: string;
  isEditable: boolean = false;
  isRefresh: number = 0;

  caseId: string;
  userCaseId: string;
  caseVerId: string;
  caseVerTypeCd: string;
  caseVerNumId: number; 
  typeWithNum: string;
  milestoneId: string;

  readonly PAGE_CASE_MILESTONE: string = DsamsConstants.PAGE_CASE_MILESTONE;

  caseLineRelatedInfoData: CaseLineRelatedInfoType;

  milestoneForm: FormGroup;
  
  constructor(private route: ActivatedRoute,
              public dialog: MatDialog,
              private formBuilder: FormBuilder,
              private caseUIService: CaseUIService,
              private dsamsReferenceService: DsamsRestfulService) 
  {
    this.milestoneForm = this.formBuilder.group({
      'txtEdit': this.formBuilder.control({value: false, disabled: false}),
    });              
  }
 
  ngOnInit(){

    let verTypeCdAndNums = this.route.snapshot.queryParamMap.get("typeWithNumber").split(' ');
    this.caseVerTypeCd = verTypeCdAndNums[0];
    if (verTypeCdAndNums[1] === undefined)
        this.caseVerNumId = 0;
    else 
        this.caseVerNumId = parseInt(verTypeCdAndNums[1]);

    this.caseId      = this.route.snapshot.queryParamMap.get("caseId");
    this.userCaseId  = this.route.snapshot.queryParamMap.get("userCaseId");
    this.caseVerId   = this.route.snapshot.queryParamMap.get("caseVersionId");
    this.typeWithNum = this.route.snapshot.queryParamMap.get("typeWithNumber").replace(' ','');

    this.serviceId = this.route.snapshot.queryParamMap.get("serviceDbId");
    sessionStorage.setItem(DsamsConstants.SESSION_SDB_ID, this.serviceId);
    
    sessionStorage.setItem('lockSessionId', "0");

    this.caseUIService.setIsOptionsMenuHidden(true);
    this.caseUIService.setIsShortcutsMenuHidden(true);

    this.getEditableAccess(encodeURIComponent("WP004#"+this.serviceId));


    this.caseLineRelatedInfoData = {
        user_CASE_ID: this.route.snapshot.queryParamMap.get("caseId"),
        case_VERSION_TYPE_CD: this.caseVerTypeCd,
        case_VERSION_NUMBER_ID: this.caseVerNumId,
    }
    this.caseUIService.setCaseLineRelatedInfoValues(this.caseLineRelatedInfoData);

  }

  ngAfterViewInit() {
    this.caseUIService.submitBreadcrumbTitleChangeRequest("Milestone List");
  }

  get txtEdit() {
    return this.milestoneForm.get('txtEdit');
  }

  onToggleEdit(event: any) {
    if (event.checked) {
        this.isEditable = true;
        console.log("ToggleEdit==>true")
    } else {
        this.isEditable = false;
        console.log("ToggleEdit==>false")
    }
  }

  getEditableAccess(filter: string) {
    this.dsamsReferenceService.getEditableAccess(filter)
    .subscribe(
      data => { 
        console.log("==>Editable Access==="+data);
        if (data == 1)  
            this.txtEdit.enable();
        else
            this.txtEdit.disable();
      });    
  }

  setEditToggleMode(event: any) {
    console.log("getToggleEdit=="+event);
    this.txtEdit.setValue(event);
    if (event)
        this.isEditable = true;
    else
        this.isEditable = false;
  }

  getMilestoneId(milestoneId:string) {
    this.milestoneId = milestoneId;
  }

  getIsRefresh(isRefresh:number) {
    this.isRefresh = isRefresh;
  }

  onSubmit() {
    console.log("form value==="+JSON.stringify(this.milestoneForm.value))
  }


}
