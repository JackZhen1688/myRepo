/* This class is used to handle all business logic for 
   the Note Detail List page.
   Date:   09/07/2021 
*/

import { formatDate } from '@angular/common';
import { Component, EventEmitter, OnDestroy, OnInit, Output, ChangeDetectorRef, Injector } from '@angular/core';
import { MatTableDataSource } from '@angular/material';
import { ActivatedRoute, Router } from '@angular/router';
import { BehaviorSubject, Subscription } from 'rxjs';
import { DsamsConstants } from 'src/app/dsams/dsams.constants';
import { CaseLineRelatedInfoType } from '../../model/case-line-related-info-type';
import { CaseNoteModel } from '../../model/case-note-model';
import { CaseRelatedInfoType } from '../../model/case-related-info-type';
import { CaseNoteDto } from '../../model/dto/case-note-dto';
import { CaseRestfulService } from '../../services/case-restful.service';
import { CaseUIService } from '../../services/case-ui-service';
import { CaseUtils } from '../../utils/case-utils';
import { MessageMgr } from '../../validation/message-mgr';
import { PopCaseNoteComponent } from 'src/app/dsams/utilitis/popups/pop-case-note/pop-case-note.component';
import { DsamsMethodsService } from 'src/app/dsams/services/dsams-methods.service';
import { FormGroup } from '@angular/forms';
import { MatDialog } from '@angular/material';
import { IEditResponseType } from '../../model/edit-response-type';
import { IActivity } from '../../../case/model/dto/activity';
import { DateValidator } from '../../validation/date-validator';
import { ReplaceExpiredVersionComponent } from '../../dialogs/replace-expired-version/replace-expired-version.component';
import { DatePipe } from '@angular/common';
import { DsamsRestfulService } from 'src/app/dsams/services/dsams-restful.service';
import { NoteModel } from '../../model/note-model';
import { INoteParameter } from '../../model/dto/note-parameter';
import { ICaseNoteParameter } from '../../model/dto/case-note-parameter';
import { AssignReferenceNotesComponent } from '../../dialogs/assign-reference-notes/assign-reference-notes.component';
import { ICaseVersion } from '../../model/dto/icase-version';
import { CaseCommonValidator } from '../../validation/case-common-validator';
import { LineUtils } from '../../line-dashboard/line-utils';
import { CdkDragDrop, moveItemInArray } from '@angular/cdk/drag-drop';
import { LineSublineRefComponent } from '../../line-dashboard/line-reference.component';
import { CsuCompNameHashTable } from 'src/app/dsams/utilitis/csu-component-hashtable';
import { take } from 'rxjs/operators';

export interface replaceExpiredVersionLines {
  noteNumber: number,
  noteId: number,
  noteVersionNumber: number,
  noteStatus: string,
  noteOfficialTitle: string
}

@Component({
  selector: 'app-note-list',
  templateUrl: './note-list.component.html',
  styleUrls: ['./note-list.component.css']
})

export class NoteListComponent implements OnInit, OnDestroy {
  @Output() sendNoteListTabIndex = new EventEmitter<number>();

  
  naString: string = 'N/A';
  isLoading: BehaviorSubject<boolean> = new BehaviorSubject(false);

  caseNoteVersion: ICaseVersion;
  tmpCaseNoteDtoData: CaseNoteDto[] = [];
  checkedDataList: CaseNoteDto[] = [];
  reconciledNoteListData: CaseNoteDto[] = [{}];
  dataSourceNoteListData: CaseNoteDto[] = [{
    theNoteId: {
      user_NOTE_ID: '',
      note_INPUT_RESPONSIBILITY_CD: ''
    },
    isFieldDisabled: {},
    isRenumberAllowed: false
  }];
  dataSourceNoteListTable = new MatTableDataSource(this.dataSourceNoteListData);
  columnsToDisplayNote =
    ['Note No.', 'Note ID', 'Note Version', 'Status', 'Official Title', 'Note Type',
      'Expiration Date', 'Fill-Ins', 'Auto', 'Restate', 'Refresh', 'DeleteRow'];

  iActivity: IActivity;
  theCaseRelatedInfoType: CaseRelatedInfoType;
  theCaseRelatedInfoData: CaseRelatedInfoType;
  theCaseLineRelatedInfoType: CaseLineRelatedInfoType;
  noCaseNoteListFoundInd: boolean = false;
  theDeletedCaseNoteList: CaseNoteModel[] = [];
  revDisabled: boolean = true;
  assignDisabled: boolean = true;
  addNewDisabled: boolean = true;
  previousDragRowIndex: number = 0; //set default to zero to prevent hung on drag
  isNoteBeingMoved: boolean = false;
  oldNoteNumber: number = null;
  newNoteNumber: number = null;

  private _noteDialogSubscription: Subscription = null;
  private _editSubscription: Subscription = null;
  private _caseLineRelatedInfoValuesSubscription: Subscription = null;
  private _caseRelatedInfoValuesSubscription: Subscription = null;
  private _revertEditSubscription: Subscription = null;
  private _editToggleState: boolean;
  private _listNavSubscription: Subscription = null;
  private _changesMade: boolean = false;
  private _ucirSubscription: Subscription = null;
  private _penInkSubscription: Subscription = null;
  private _caseUIServiceSubscription1: Subscription = null;
  private _getCaseNoteApplicableReferenceNotesSubscription: Subscription = null;

  // Form for new popup for note
  caseNoteForm: FormGroup;

  // For new note
  caseNoteObject: CaseNoteDto = {};

  //
  replaceExpiredVersionDataList: replaceExpiredVersionLines[] = [];

  //DSAMS-5461 DH 05/22
  theCSUId: string;
  isEditRightAccessGranted: boolean = true;

  public dialog: MatDialog;
  public dsamsDialogMsgService: DsamsMethodsService;
  public datepipe: DatePipe;
  private dsamsRestfulService: DsamsRestfulService;
 
  constructor(
    private injector: Injector,
    private lineShareService: LineSublineRefComponent,
    private changeDetectorRef: ChangeDetectorRef,
    private route: ActivatedRoute,
    private router: Router,
    private caseRestService: CaseRestfulService,
    private caseUIService: CaseUIService,
  ) { 
    this.dialog = injector.get<MatDialog>(MatDialog);
    this.datepipe = injector.get<DatePipe>(DatePipe);
    this.dsamsRestfulService = injector.get<DsamsRestfulService>(DsamsRestfulService);
    this.dsamsDialogMsgService = injector.get<DsamsMethodsService>(DsamsMethodsService);

    //begin DSAMS-5461 DH 05/22
    let aCsuId = CsuCompNameHashTable.getCSUCd(this.route.routeConfig.component.name);
    this.theCSUId = aCsuId ? aCsuId : CsuCompNameHashTable.CSU_CD_WP007;
    //end DSAMS-5461 DH 05/22   
  }

  ngOnInit() {
    this.getEditAccessRight();

    console.log("======================");
    console.log("note List Init");
    console.log("======================");
    this.isNoteBeingMoved = false;
   
    this.dataSourceNoteListTable = new MatTableDataSource([]);    // So they don't get undefined row.

    this._caseRelatedInfoValuesSubscription = this.caseUIService.getCaseRelatedInfoValues().subscribe((pInfo: CaseRelatedInfoType) => {
      this.theCaseRelatedInfoType = pInfo;
      this.refreshEverything();
    });
    this._caseLineRelatedInfoValuesSubscription = this.caseUIService.getCaseLineRelatedInfoValues()
      .subscribe((pInfo: CaseLineRelatedInfoType) => {
        this.theCaseLineRelatedInfoType = pInfo;
        this.refreshEverything();
      });

    // Options for Case in Review and Pen / Ink
    if (this.theCaseLineRelatedInfoType != null && !CaseUtils.isBlankStr(this.theCaseLineRelatedInfoType.case_VERSION_STATUS_CD)) {
      let versionStatus: string = this.theCaseLineRelatedInfoType.case_VERSION_STATUS_CD;
      let versionType: string = this.theCaseLineRelatedInfoType.case_VERSION_TYPE_CD;
      let usageCd: string = this.theCaseRelatedInfoType.case_USAGE_INDICATOR_CD;
      this.caseUIService.setIsCaseInReviewEnabled(CaseUtils.isOptionEnabledForCaseInReviewShortcut(versionStatus));
      this.caseUIService.setIsPenInkEnabled(CaseUtils.isOptionEnabledForPenInkShortcut(versionStatus, versionType, usageCd));
    }

    this.subscribeToEditService();
    this.subscribeToOtherServices();

    // Subscriptions for options
    this.subscribeToOptionCaseInReview();
    this.subscribeToOptionCasePenInk();

    this.clobberLockSession();
    // begin dsams-5371 04/22 DB
    this.subscribeToDiscardNoteListChanges();
   this.subscribeToNoteTabNbrChanged();
    // end  dsams-5371 04/22 DB
   
  }

  ngAfterViewChecked() {
    this.changeDetectorRef.detectChanges();
  }

  //begin DSAMS-5461 DH 05/22
  getEditAccessRight(): void {
    this.lineShareService.getEditAccessRight(this.theCSUId)
      .pipe(take(1))
      .subscribe(result => {
        if (result == 1) this.isEditRightAccessGranted = true;
        else this.isEditRightAccessGranted = false;
      });
  }
  //end DSAMS-5461 DH 05/22

  // Call this to refresh the list, such as:
  // * When we have everything we need from the case search.
  // * After edit slider gets toggled 
  private refreshEverything() {
    if (!!this.theCaseRelatedInfoType && !!this.theCaseLineRelatedInfoType) {
      sessionStorage.setItem(DsamsConstants.SESSION_CASE_NOTE_TAB, DsamsConstants.PAGE_CASE_NOTE_LIST);
      this.makeSureEditToggleIsOff();
      this.populateCaseLineNoteList(this.theCaseRelatedInfoType);
      this.setUnchanged();
    }
  }

  ngOnDestroy() {
    console.log("======================");
    console.log("note List destroy");
    console.log("======================");
     if (!!this._noteDialogSubscription) {
      this._noteDialogSubscription.unsubscribe();
    }
    if (!!this._editSubscription) {
      this._editSubscription.unsubscribe();
      this._editSubscription = null;
    }
    if (!!this._caseLineRelatedInfoValuesSubscription) {
      this._caseLineRelatedInfoValuesSubscription.unsubscribe();
    }
    if (!!this._caseRelatedInfoValuesSubscription) {
      this._caseRelatedInfoValuesSubscription.unsubscribe();
    }
    if (!!this._listNavSubscription) {
      this._listNavSubscription.unsubscribe();
    }
    if (!!this._revertEditSubscription) {
      this._revertEditSubscription.unsubscribe();
    }
    if (!!this._ucirSubscription) {
      this._ucirSubscription.unsubscribe();
      this._ucirSubscription = null;
    }
    if (!!this._penInkSubscription) {
      this._penInkSubscription.unsubscribe();
      this._penInkSubscription = null;
    }

   
    
    this.clobberLockSession();
  }

  // Set the changed status.
  private setChanged() {
    this._changesMade = true;
    this.caseUIService.hasEditBeenMadeService.next({ ID: DsamsConstants.NOTE_LIST_EDITOR, editToggle: true });
  }

  // Set to changed status for an individual row (number).
  private setChangedRow(pCurrStatus: number): number {
    return (pCurrStatus == DsamsConstants.ENT_UNCHANGED) ? DsamsConstants.ENT_CHANGED : pCurrStatus;
  }

  // Set to changed status for an individual row (string).
  private setChangedRowStr(pCurrStatus: string): string {
    return (pCurrStatus == DsamsConstants.ENT_UNCHANGED.toString()) ? DsamsConstants.ENT_CHANGED.toString() : pCurrStatus;
  }


  // Set the changed status to unchanged.
  private setUnchanged() {
    this._changesMade = false;
    this.caseUIService.hasEditBeenMadeService.next({ ID: DsamsConstants.NOTE_LIST_EDITOR, editToggle: false });
  }

  // Populate the case note list.
  populateCaseLineNoteList(pCaseInfo: CaseRelatedInfoType) {
    this.isLoading.next(true);
    this.caseRestService.getCaseNoteListDto(pCaseInfo.case_ID, pCaseInfo.working_CASE_VERSION_ID).subscribe((value) => {
      //console.log('CaseNoteList', value)
      this.dataSourceNoteListData = value;
      if (!!this.dataSourceNoteListData) {
        this.dataSourceNoteListData.forEach(eachRow => {
          eachRow.theCaseVersionId = {
            case_ID: pCaseInfo.case_ID,
            case_VERSION_ID: pCaseInfo.working_CASE_VERSION_ID,
          }
          eachRow.wm_REFRESH_DONE = false;
          eachRow.isRenumberAllowed = false;
          if (!CaseUtils.isBlankStr(eachRow.theNoteId.note_EXPIRATION_DT))
            eachRow.theNoteId.note_EXPIRATION_DT = formatDate(eachRow.theNoteId.note_EXPIRATION_DT, 'MM/dd/yyyy', 'en-US');
        })
        this.isLoading.next(false);
      }
      this.dataSourceNoteListTable = new MatTableDataSource(this.dataSourceNoteListData);
      if (this.dataSourceNoteListData == null || this.dataSourceNoteListData.length == 0) {
        this.noCaseNoteListFoundInd = true;
      }
      this.refreshAllICaseNotes();
      this.theDeletedCaseNoteList = [];
      this.caseUIService.caseNoteListDetails.next(this.dataSourceNoteListData);
      this.enableOrDisableFields();
    });
  }

  /* This procedure checks the returned result value from the 
     popover Yes/No dialog window. */
  onClickYesDeleteNote(isDeleteConfirmed: any, rowElement: any) {
    if (isDeleteConfirmed) {
       this.deleteNoteListItem(rowElement);
    }
  }

  //per Sonarqube rule
  performDeleteOperation(rowIndex: number) {
    if (!!this.theCaseLineRelatedInfoType) {
      if ((this.theCaseLineRelatedInfoType.case_VERSION_TYPE_CD == 'A' ||
        this.theCaseLineRelatedInfoType.case_VERSION_TYPE_CD == 'M') &&
        (this.theCaseLineRelatedInfoType.case_VERSION_STATUS_CD == 'D' ||
          this.theCaseLineRelatedInfoType.case_VERSION_STATUS_CD == 'W' ||
          this.theCaseLineRelatedInfoType.case_VERSION_STATUS_CD == 'R')) {
        this.dataSourceNoteListTable.data[rowIndex].change_ACTION_CD = 'D';
        this.refreshSingleICaseNote(this.dataSourceNoteListTable.data[rowIndex]);
        this.dataSourceNoteListTable.data[rowIndex].status = this.setChangedRowStr(this.dataSourceNoteListTable.data[rowIndex].status);
        this.dataSourceNoteListTable.data[rowIndex].theICaseNote.status = this.setChangedRow(this.dataSourceNoteListTable.data[rowIndex].theICaseNote.status);
      }
    }
    else {
      // If a note contains a Note Status = A on any Case Version (Basic, Amendment, Modification), 
      // it must be disassociated from the Case, do logical delete Note only
      if (!!this.theCaseLineRelatedInfoType) {
        if (this.theCaseLineRelatedInfoType.case_VERSION_TYPE_CD == 'B' ||
          this.theCaseLineRelatedInfoType.case_VERSION_TYPE_CD == 'A' ||
          this.theCaseLineRelatedInfoType.case_VERSION_TYPE_CD == 'M') {
          this.dataSourceNoteListTable.data[rowIndex].change_ACTION_CD = 'D';
          this.refreshSingleICaseNote(this.dataSourceNoteListTable.data[rowIndex]);
          this.dataSourceNoteListTable.data[rowIndex].status = this.setChangedRowStr(this.dataSourceNoteListTable.data[rowIndex].status);
          this.dataSourceNoteListTable.data[rowIndex].theICaseNote.status = this.setChangedRow(this.dataSourceNoteListTable.data[rowIndex].theICaseNote.status);
        }
      }
    }
  }

  /* This procedure is used to remove the note from the case note list. */
  deleteNoteListItem(rowElement: any) {
    let rowIndex = this.dataSourceNoteListTable.data.indexOf(rowElement);
    //console.log('theCaseLineRelatedInfoType', this.theCaseLineRelatedInfoType);
    //Regardless of the Note Status, if the CASE_VERSION is in Write Status (WSTATUS), 
    //determine if the Users ACTIVITY, CASE_WRITING_IN is set to true (1).  
    //If so, allow deletion of the note, if not provide error message 20698
    if (!!this.theCaseLineRelatedInfoType) {
      if (this.theCaseLineRelatedInfoType.case_VERSION_STATUS_CD == 'W') {
        MessageMgr.swalFire({
          text: 'The selected function is not available due to the status of the selected case.',
          icon: 'error',
          width: 400,
          focusConfirm: true,
          confirmButtonText: 'OK'
        })
        return;
      }
     }

    if (this.dataSourceNoteListTable.data[rowIndex].change_ACTION_CD == 'A') {
      //FR24: If the Note Status = Added (A) and NOTE TYPE = standard (ST) or (CT), physically delete the Case Note 
      this.dataSourceNoteListTable.data[rowIndex].status = DsamsConstants.ENT_DELETED.toString();
      this.theDeletedCaseNoteList.push(this.dataSourceNoteListTable.data[rowIndex]);
      this.dataSourceNoteListTable.data.splice(rowIndex, 1);
      this.dataSourceNoteListTable = new MatTableDataSource(this.dataSourceNoteListTable.data);
      this.isNoteBeingMoved = true;
    }
    else if (this.dataSourceNoteListTable.data[rowIndex].change_ACTION_CD !== 'A' ||
      this.dataSourceNoteListTable.data[rowIndex].change_ACTION_CD !== 'D') {
      //FR24: If a Note contains a Note Status that is ‘U’, ‘C’, or ‘R’; and is an Amendment/Mod in
      //Development (DSTATUS/WSTATUS and RSTATUS), do logical delete Note only
      this.performDeleteOperation(rowIndex);
     
      this.dataSourceNoteListData = this.dataSourceNoteListTable.data;
      this.dataSourceNoteListTable._updateChangeSubscription();
    }
    this.setChanged();
  }

  //back to previous Case Search Summary page 
  goBackToCaseSearchSummary() {
    this.caseUIService.setbackToCaseSearchSummaryValue(true);
    this.router.navigateByUrl('/case/search', { relativeTo: this.route });
  }

  // Check to make sure they have access to create a new note.
  private checkIfTheyCanAddNew(): boolean {
    // I got rid of the check for adding new because the button will be disabled if they don't have the ability.
    return true;
  }

  onClickStandardNote() {
    if (this.checkIfTheyCanAddNew()) {
      this.caseUIService.setNoteType(DsamsConstants.NOTE_TYPE_STANDARD);
      this.popupCaseNote("Standard");
    }
  }

  onClickCustomizeNote() {
    if (this.checkIfTheyCanAddNew()) {
      this.caseUIService.setNoteType(DsamsConstants.NOTE_TYPE_CUSTOMIZABLE);
      this.popupCaseNote("Customizable");
    }
  }

  onClickUniqueNote() {
    if (this.checkIfTheyCanAddNew()) {
      this.caseUIService.setNoteType(DsamsConstants.NOTE_TYPE_UNIQUE);

      // For new Unique Note
      this.caseNoteObject.case_ID = this.theCaseRelatedInfoType.case_ID;
      this.caseNoteObject.case_VERSION_ID = parseInt(this.theCaseRelatedInfoType.case_VERSION_ID);
      this.caseNoteObject.case_NOTE_ID = null;
      this.caseNoteObject.note_ID = null;
      this.caseNoteObject.note_VERSION_ID = null;
      // Temporary - User Note Id
      this.caseNoteObject.theNoteId = {};
      this.caseNoteObject.theNoteId.user_NOTE_ID = null;
      this.caseNoteObject.theNoteId.official_NOTE_TITLE_TX = null;
      // Put in Note Type as Unique
      this.caseNoteObject.theNoteId.note_TYPE_CD = DsamsConstants.NOTE_TYPE_UNIQUE;

      // Need to set data - For note object that does not have content (New Note)
      this.caseNoteObject.status = 'NEW';
      this.caseNoteObject.ent_status = DsamsConstants.ENT_NEW;
      this.gotoCaseNote(this.caseNoteObject);
    }
  }

  onClickLineNote() {
    if (this.checkIfTheyCanAddNew()) {
      this.caseUIService.setNoteType(DsamsConstants.NOTE_TYPE_LINE_ITEM);
      // For new Line Item Note
      this.caseNoteObject.case_ID = this.theCaseRelatedInfoType.case_ID;
      this.caseNoteObject.case_VERSION_ID = parseInt(this.theCaseRelatedInfoType.case_VERSION_ID);
      this.caseNoteObject.case_NOTE_ID = null;
      this.caseNoteObject.note_ID = null;
      this.caseNoteObject.note_VERSION_ID = null;
      // Temporary - User Note Id
      this.caseNoteObject.theNoteId = {};
      this.caseNoteObject.theNoteId.user_NOTE_ID = null;
      this.caseNoteObject.theNoteId.official_NOTE_TITLE_TX = null;
      // Put in Note Type as Line Item
      this.caseNoteObject.theNoteId.note_TYPE_CD = DsamsConstants.NOTE_TYPE_LINE_ITEM;

      // Need to set data - For note object that does not have content (New Note)
      this.caseNoteObject.status = 'NEW';
      this.caseNoteObject.ent_status = DsamsConstants.ENT_NEW;
      this.gotoCaseNote(this.caseNoteObject);
    }
  }

  // Jump to the case note selected.
  private gotoCaseNote(pCaseNote: CaseNoteDto) {

    if (pCaseNote.theNoteTypeCd == null)
      pCaseNote.theNoteTypeCd = {
        note_TYPE_DESCRIPTION_TX: ''
      }

    this.caseUIService.setNoteType(pCaseNote.theNoteTypeCd.note_TYPE_DESCRIPTION_TX);
    this.caseUIService.caseNoteSelected.next(pCaseNote);
    this.sendTabId();
  }

  // Notify the receiving panel that we have the note selected!
  doubleClick(pIndex: number) {
    this.caseNoteObject.status = '';
    this.gotoCaseNote(this.dataSourceNoteListTable.data[pIndex]);
  }

  sendTabId() {
    this.caseUIService.flipToDisabledService.next(DsamsConstants.NOTE_LIST_EDITOR);
    //send new Line tab index as output
    if (!!this.caseNoteObject.status && this.caseNoteObject.status != 'NEW') {
      this.caseUIService.flipToDisabledService.next(DsamsConstants.NOTE_EDITOR);
    }
    this.sendNoteListTabIndex.emit(1);
  }

  // Case Note Popup
  popupCaseNote(elementName: string): void {
    let diaWidth: string = "70%";
    let diaHeight: string = "68%";

    // Pass in elementName - Note for now
    let popupCaseNoteDialog = this.dialog.open(PopCaseNoteComponent, {
      width: diaWidth,
      height: diaHeight,
      data: {
        noteListData: this.dataSourceNoteListData, noteType: elementName
      }
    });

    // Return object
    this._noteDialogSubscription = popupCaseNoteDialog.afterClosed().subscribe(resp => {
      if (resp != null && resp.data != null) {
        // return object is the note selected
        // console.log("resp is: " + resp);
        // console.log("resp.data is: " + JSON.stringify(resp.data));

        this.caseNoteObject.case_ID = this.theCaseRelatedInfoType.case_ID;
        this.caseNoteObject.case_VERSION_ID = parseInt(this.theCaseRelatedInfoType.case_VERSION_ID);
        this.caseNoteObject.case_NOTE_ID = resp.data.case_NOTE_ID;
        this.caseNoteObject.note_ID = resp.data.note_ID;
        this.caseNoteObject.note_VERSION_ID = resp.data.note_VERSION_ID;
        // Temporary - User Note Id
        this.caseNoteObject.theNoteId = {};
        this.caseNoteObject.theNoteId.user_NOTE_ID = resp.data.user_NOTE_ID;
        this.caseNoteObject.theNoteId.official_NOTE_TITLE_TX = resp.data.official_NOTE_TITLE_TX;

        // Put in Note Type as Standard or Customizable
        if (elementName == DsamsConstants.NOTE_TYPE_STANDARD) {
          this.caseNoteObject.theNoteId.note_TYPE_CD = DsamsConstants.NOTE_TYPE_STANDARD;
        }
        else if (elementName == DsamsConstants.NOTE_TYPE_CUSTOMIZABLE) {
          this.caseNoteObject.theNoteId.note_TYPE_CD = DsamsConstants.NOTE_TYPE_CUSTOMIZABLE;
        }

        // Need to set data - For note object that does not have content (New Note)
        this.caseNoteObject.status = 'NEW';
        this.caseNoteObject.ent_status = DsamsConstants.ENT_NEW;
        this.gotoCaseNote(this.caseNoteObject);
      }
    });
  }

  private isRRInvisible(): boolean {
    // Always visible per dsams-web standards.
    return false;
  }

  // Set the button refresh/restate styles according to whether the restate/refresh buttons are visible.
  setRRButtonStyle(): object {
    return this.isRRInvisible() ? { "width": "0%" } : { "width": "5%" };
  }

  // Set the Refresh Button style according to if it's been refreshed.
  getRefreshButtonClass(rowIndex: number): string {
    return this.dataSourceNoteListTable.data[rowIndex].wm_REFRESH_DONE ? "refresh-button-refreshed" : "refresh-button";
  }

  // Set the button delete styles according to whether the restate/refresh buttons are visible.
  setDelButtonStyle(): object {
    return this.isRRInvisible() ? { "width": "15%" } : { "width": "5%" };
  }

  // Enable or disable fields according to toggle.
  private enableOrDisableFields() {
    if (!this.theCaseRelatedInfoType) {
      return;
    }
    let disableRev: boolean = true;
    const disabledState: boolean = !this._editToggleState;
    const wholeCaseVersionNotEditable: boolean = ((this.theCaseRelatedInfoType.case_MASTER_STATUS_CD != "P" && this.theCaseRelatedInfoType.case_MASTER_STATUS_CD != "N") ||
      this.theCaseLineRelatedInfoType.case_VERSION_STATUS_CD != "D");
    this.dataSourceNoteListData.forEach((eachCaseNote: CaseNoteDto) => {
      if (!eachCaseNote.isFieldDisabled) {
        eachCaseNote.isFieldDisabled = {};
      }
      eachCaseNote.wm_RR_VISIBLE = !this.isRRInvisible();
      const cwdCriteria: boolean = (
        eachCaseNote.theNoteId.note_INPUT_RESPONSIBILITY_CD == "CWD" &&
        this.theCaseLineRelatedInfoType.case_VERSION_STATUS_CD != "W" &&
        this.theCaseLineRelatedInfoType.case_VERSION_STATUS_CD != "R"
      );
      eachCaseNote.isFieldDisabled['RestateButton'] = (disabledState ||
        eachCaseNote.change_ACTION_CD == 'R' ||
        eachCaseNote.change_ACTION_CD == 'A' ||
        this.theCaseLineRelatedInfoType.case_VERSION_TYPE_CD == "B" ||
        cwdCriteria
      );
      eachCaseNote.isFieldDisabled['RefreshButton'] = (disabledState ||
        eachCaseNote.change_ACTION_CD == 'U' ||
        eachCaseNote.change_ACTION_CD == 'A' ||
        this.theCaseLineRelatedInfoType.case_VERSION_TYPE_CD == "B" ||
        cwdCriteria
      );
      eachCaseNote.isFieldDisabled['DeleteButton'] = (disabledState || cwdCriteria || eachCaseNote.change_ACTION_CD == 'D');

      // Toggle fields for REV button (refresh expired version)
      // * Enable in view mode when selected note is a standard reference note (note type "ST") and its expiration date is before current system date.
      // * Disabled always for leases.
      // * Disable this button/function if the current highlighted Note Change Action Code is equal to deleted (D). 
      // * Do not allow edit mode if the note.note_input_responsibility_cd = ‘CWD’ and the case_version.case_version_status_cd <> ‘W’ or ‘R’
      // If any of the case notes are editable, then enable the REV button, otherwise disable.   
      if (
        !this._editToggleState &&    // Disable when toggle is on.
        !wholeCaseVersionNotEditable &&
        !cwdCriteria &&
        (!disabledState ||
          (CaseUtils.isLTSysdate(eachCaseNote.theNoteId.note_EXPIRATION_DT) &&
            eachCaseNote.theNoteId.note_TYPE_CD == "ST")) &&
        (eachCaseNote.change_ACTION_CD != "D") &&
        (this.theCaseLineRelatedInfoType.security_ASSISTANCE_PROGRAM_CD != "LEASE")
      ) {
        disableRev = false;
      }
    });
    this.revDisabled = disableRev || !this.isEditRightAccessGranted;
    this.assignDisabled = (disabledState || this.dataSourceNoteListData.length == 0);
    this.addNewDisabled = wholeCaseVersionNotEditable || !this.isEditRightAccessGranted;
    this.dataSourceNoteListData.forEach(eachRow => {
      if (this._editToggleState && (CaseCommonValidator.isEqual(eachRow.change_ACTION_CD, LineUtils.CHANGE_ACTION_CD_ADDED)))
        eachRow.isRenumberAllowed = true;
      else eachRow.isRenumberAllowed = false;
    })
  }

  // Determine if save is disabled.
  isSaveDisabled() {
    return !this._editToggleState || !this._changesMade;
  }

  // Determine if cancel is disabled.
  isCancelDisabled() {
    return !this._editToggleState || !this._changesMade;
  }

  // Subscribe to case ui service for option Update Case In Review
  subscribeToOptionCaseInReview() {
    if (!this._ucirSubscription) {
      this._ucirSubscription = this.caseUIService.optionSelectedUCIRRegSub.subscribe((value) => {
        // Set edit slider to on
        if (value) {
          const editResponse: IEditResponseType = {
            ID: DsamsConstants.NOTE_LIST_EDITOR,
            editToggle: true
          };
          this.caseUIService.caseEditService.next(editResponse);
        }
      });
    }
  }

  // Subscribe to case ui service for option Pen and Ink
  subscribeToOptionCasePenInk() {
    if (!this._penInkSubscription) {
      this._penInkSubscription = this.caseUIService.optionSelectedUCPIRegSub.subscribe((value) => {
        // Set edit slider to on
        if (value) {
          const editResponse: IEditResponseType = {
            ID: DsamsConstants.NOTE_LIST_EDITOR,
            editToggle: true
          };
          this.caseUIService.caseEditService.next(editResponse);
        }
      });
    }
  }

 //begin  DSAMS-5371
 subscribeToNoteTabNbrChanged() {
  this.caseUIService.caseNoteTabNbrChanged.subscribe((value: number) => {
    if (value == DsamsConstants.CASE_NOTE_LIST_TAB_NBR ) {
     
      this.refreshEverything();
    }
    if ( this.getCurrentLockSessionId() > 0) {
      this.clobberLockSession();
       this.caseUIService.flipToDisabledService.next(DsamsConstants.NOTE_LIST_EDITOR);
    }
   
  });
  }
  
  subscribeToDiscardNoteListChanges() {
    this.caseUIService.checkDiscardNoteListChanges.subscribe((value: boolean) => {
      if (!value) {
        setTimeout(() => { this.setChanged(); }, 300);
        this.turnEditOn();
      }
      else {
        this.clobberLockSession();
        this.refreshEverything();
      }  
     
    });
  }

 

 
  // end dsams-5371
   // Turn on Edit
   private turnEditOn() {
      this.caseUIService.caseEditService.next(
        {
          ID: DsamsConstants.NOTE_LIST_EDITOR,
          editToggle: true
        }
      );
  }

  // Turn off Edit
  private turnEditOff() {
      this.caseUIService.caseEditService.next(
        {
          ID: DsamsConstants.NOTE_LIST_EDITOR,
          editToggle: false
        }
      );
  }

  getCurrentLockSessionId(): number {
    const sessionLockSessionId: string = sessionStorage.getItem(DsamsConstants.SESSION_CASE_NOTE_LIST_LOCK_ID);
    return (!!sessionLockSessionId && sessionLockSessionId.length > 1) ? Number(sessionLockSessionId) : 0;
  }

  // Clobber the existing session IDs.
  private clobberLockSession() {
    const sessionIdForNoteLock: string = sessionStorage.getItem(DsamsConstants.SESSION_CASE_NOTE_LIST_LOCK_ID);
    if (!!sessionIdForNoteLock && (+sessionIdForNoteLock) > 0) {
      this.dsamsRestfulService.closeLegacyLockSession(sessionIdForNoteLock).subscribe((pResult: any) => {
        sessionStorage.setItem(DsamsConstants.SESSION_CASE_NOTE_LIST_LOCK_ID, "0");
      },
        err => {
          CaseUtils.ReportHTTPError(err, "Removing Note Lock from Note List");
        });
    }
  }


  // Subscribe to edit service.
  private subscribeToEditService() {
    if (!this._editSubscription) {
      this._editSubscription = this.caseUIService.caseEditServiceRegSub.subscribe((pEditResponse: IEditResponseType) => {
        if (!!pEditResponse && pEditResponse.ID == DsamsConstants.NOTE_LIST_EDITOR) {
          this.caseUIService.forceEditDisabledSubscription.next(false);
          this._editToggleState = pEditResponse.editToggle;
          if (pEditResponse.editToggle && (!this._changesMade || this.getCurrentLockSessionId() == 0)) {
            this.loadDataForEditing();
          }
          else {
            this.finishEditServiceEvent();
          }
        }
      });
    }
  }

  private finishEditServiceEvent() {
    this.enableOrDisableFields();
    this.newNoteNumber = null;
    if (!this._changesMade) {
      this.clobberLockSession();
    }

  }

  private loadDataForEditing() {
    setTimeout(() => { this.populateCaseLineNoteList(this.theCaseRelatedInfoType) }, 1000);
    // Perform locking and throw an error if the lock is not available.
   if (sessionStorage.getItem(DsamsConstants.SESSION_CASE_NOTE_TAB) == DsamsConstants.PAGE_CASE_NOTE_LIST) {
     this.caseRestService.lockCaseNoteList(this.theCaseRelatedInfoType.case_ID, +this.theCaseRelatedInfoType.case_VERSION_ID).subscribe((pLockSessionId: number) => {
       sessionStorage.setItem(DsamsConstants.SESSION_CASE_NOTE_LIST_LOCK_ID, pLockSessionId.toString());
       this.caseUIService.forceEditDisabledSubscription.next(false);
     },
       err => {
         CaseUtils.ReportHTTPError(err, "locking case note list");
         this.makeSureEditToggleIsOff();
         this.enableOrDisableFields();
         this.caseUIService.forceEditDisabledSubscription.next(false);
       });
   }
  }


  private makeSureEditToggleIsOff() {
    this._editToggleState = false;
    this.caseUIService.flipToDisabledService.next(DsamsConstants.NOTE_LIST_EDITOR);
  }

  // Subcribe to other services
  private subscribeToOtherServices() {
    // begin dsams-5371 05/22 DB -- this routine is no longer needed.  removed
    // Listen for navigating to the list from the case detail.
    //end  dsams-5371 05/22 DB

    // Subscribe to an edit being reverted.
    this._revertEditSubscription = this.caseUIService.revertEditService.subscribe((pEditResponse: IEditResponseType) => {
      if (!!pEditResponse && pEditResponse.ID == DsamsConstants.NOTE_LIST_EDITOR) {
        this.refreshEverything();
      }
    });
  }



  /********************* Restate Button Note************************/
  onClickRestate(rowIndex: number) {
    const caseVersionStatusCd: string = this.theCaseLineRelatedInfoType.case_VERSION_STATUS_CD;
    const caseNoteStatus: string = this.dataSourceNoteListTable.data[rowIndex].change_ACTION_CD;
    if (caseVersionStatusCd !== 'R' && caseVersionStatusCd !== 'W') {
      if (caseNoteStatus === 'C') {
        MessageMgr.swalFire({
          text: 'The note was changed previously. ' + 'If reinstates, the note will be marked as restated ' +
            'although the changes will ' +
            'remain with the %1.  Do you want to proceed?',
          icon: 'warning',
          width: 300,
          showCancelButton: true,
          cancelButtonText: 'No',
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: 'Yes',
        }).then((result) => {
          if (result.value) {
            this.changeToRestate(rowIndex);
            this.enableOrDisableFields();
          }
        });
      } else {
        this.changeToRestate(rowIndex);
        this.enableOrDisableFields();
      }
    } else if (this.iActivity.case_WRITING_IN === true) {
      this.changeToRestate(rowIndex);
      this.enableOrDisableFields();
    } else {
      MessageMgr.swalFire({
        text: 'The selected function is not available due to the status of the selected case',
        icon: 'error',
        width: 300,
        showCancelButton: false,
        confirmButtonColor: '#3085d6',
        confirmButtonText: 'Ok'
      });
    }
  }

  private changeToRestate(index: number) {
    let currCaseNote: CaseNoteDto = this.dataSourceNoteListData[index];
    currCaseNote.change_ACTION_CD = 'R';
    this.refreshSingleICaseNote(currCaseNote);
    currCaseNote.theICaseNote.status = this.setChangedRow(currCaseNote.theICaseNote.status);
    this.dataSourceNoteListTable.data[index] = currCaseNote;
    this.setChanged();
  }

  /**
   * Get the change action cd
   */
  getChangeActionCd(rowIndex: number): string {
    let caCd: string;
    if (this.dataSourceNoteListTable.data[rowIndex].change_ACTION_CD !== null) {
      caCd = this.dataSourceNoteListTable.data[rowIndex].change_ACTION_CD;
    } else {
      caCd = "N/A";
    }
    return !!caCd ? caCd : this.naString;
  }

  /**
   * Refresh an individual case note.
   */
  private refreshSingleICaseNote(pCaseNoteDto: CaseNoteDto) {
    const theNoteDto: NoteModel = pCaseNoteDto.theNoteId;
    pCaseNoteDto.theICaseNote = {
      case_ID: pCaseNoteDto.case_ID,
      case_VERSION_ID: pCaseNoteDto.case_VERSION_ID,
      note_ID: pCaseNoteDto.note_ID,
      note_VERSION_ID: pCaseNoteDto.note_VERSION_ID,
      case_NOTE_ID: pCaseNoteDto.case_NOTE_ID,
      user_NOTE_NUMBER_ID: pCaseNoteDto.user_NOTE_NUMBER_ID,
      ipc_CATEGORY_CD: pCaseNoteDto.ipc_CATEGORY_CD,
      change_ACTION_CD: pCaseNoteDto.change_ACTION_CD,
      assignment_IN: pCaseNoteDto.assignment_IN,
      caseNoteParameterList: pCaseNoteDto.caseNoteParameterList,
      status: !pCaseNoteDto.theICaseNote ? DsamsConstants.ENT_UNCHANGED : this.setChangedRow(+pCaseNoteDto.theICaseNote.status),
      theNoteId: {
        note_ID: theNoteDto.note_ID,
        note_VERSION_ID: theNoteDto.note_VERSION_ID,
        note_DESCRIPTION_TX: theNoteDto.note_DESCRIPTION_TX,
        official_NOTE_TITLE_TX: theNoteDto.official_NOTE_TITLE_TX,
        note_TYPE_CD: theNoteDto.note_TYPE_CD,
        note_EXPIRATION_DT: this.datepipe.transform(theNoteDto.note_EXPIRATION_DT, 'yyyy-MM-dd'),
        user_NOTE_ID: theNoteDto.user_NOTE_ID,
        fillin_IN: theNoteDto.fillin_IN,
        note_INPUT_RESPONSIBILITY_CD: theNoteDto.note_INPUT_RESPONSIBILITY_CD,
        noteContentList: theNoteDto.noteContentList,
        noteParameterList: theNoteDto.noteParameterList,
        status: DsamsConstants.ENT_UNCHANGED
      }
    };
  }

  /**
   * Refresh the iCaseNote entity objects from CaseNoteDTO so they can be saved.
   */
  private refreshAllICaseNotes() {
    this.dataSourceNoteListData.forEach((eachCaseNoteDto: CaseNoteDto) => {
      this.refreshSingleICaseNote(eachCaseNoteDto);
    });
  }

  /**
   * Refresh the Case Note with the I-version.
   */
  public onClickRefreshNote(rowIndex: number) {
    const currCaseNote: CaseNoteDto = this.dataSourceNoteListData[rowIndex];
    this.isLoading.next(true);
    this.caseRestService.refreshCaseNoteForList(currCaseNote.case_ID, currCaseNote.user_NOTE_NUMBER_ID).subscribe((pCaseNoteDto: CaseNoteDto) => {
      if (!pCaseNoteDto) {
        MessageMgr.swalFire({
          text: 'The corresponding Case Note for the Implemented Case Version does not exist.',
          icon: 'error',
          width: 300,
          showCancelButton: false,
          confirmButtonColor: '#3085d6',
          confirmButtonText: 'Ok'
        });
      }
      else {
        let currCaseNote2: CaseNoteDto = this.dataSourceNoteListData[rowIndex];
        currCaseNote2.change_ACTION_CD = "U";
        currCaseNote2.theNoteId.official_NOTE_TITLE_TX = pCaseNoteDto.theNoteId.official_NOTE_TITLE_TX;
        currCaseNote2.theNoteId.user_NOTE_ID = pCaseNoteDto.theNoteId.user_NOTE_ID;
        currCaseNote2.theNoteId.note_TYPE_CD = pCaseNoteDto.theNoteId.note_TYPE_CD;
        currCaseNote2.theNoteId.note_EXPIRATION_DT = DateValidator.dateToString(<Date>(CaseUtils.toDate(pCaseNoteDto.theNoteId.note_EXPIRATION_DT)));
        currCaseNote2.assignment_IN = pCaseNoteDto.assignment_IN;
        currCaseNote2.theNoteId.note_INPUT_RESPONSIBILITY_CD = pCaseNoteDto.theNoteId.note_INPUT_RESPONSIBILITY_CD;
        currCaseNote2.caseNoteParameterList = pCaseNoteDto.caseNoteParameterList;
        currCaseNote2.theNoteId.noteContentList = [];
        if (!!pCaseNoteDto.theNoteId.noteContentList && pCaseNoteDto.theNoteId.noteContentList.length > 0) {
          currCaseNote2.theNoteId.noteContentList.push(pCaseNoteDto.theNoteId.noteContentList[0]);
        }
        currCaseNote2.theNoteId.noteParameterList = pCaseNoteDto.theNoteId.noteParameterList;
        this.refreshSingleICaseNote(currCaseNote2);
        const isUniqueNote: boolean = (pCaseNoteDto.theNoteId.note_TYPE_CD == "CU");
        currCaseNote2.theICaseNote.status = DsamsConstants.ENT_CHANGED;
        currCaseNote2.theICaseNote.theNoteId.status = isUniqueNote ? DsamsConstants.ENT_NEW : DsamsConstants.ENT_CHANGED;
        if (!!currCaseNote2.caseNoteParameterList) {
          currCaseNote2.caseNoteParameterList.forEach((eachCnp: ICaseNoteParameter) => {
            eachCnp.status = DsamsConstants.ENT_CHANGED;
          });
        }
        if (currCaseNote2.theNoteId.noteContentList.length > 0) {
          currCaseNote2.theNoteId.noteContentList[0].status = DsamsConstants.ENT_CHANGED;
        }
        if (!!currCaseNote2.theNoteId.noteParameterList) {
          currCaseNote2.theNoteId.noteParameterList.forEach((eachNp: INoteParameter) => {
            eachNp.status = DsamsConstants.ENT_CHANGED;
          });
        }
        currCaseNote2.wm_REFRESH_DONE = true;
        this.dataSourceNoteListData[rowIndex] = currCaseNote2;
        this.dataSourceNoteListTable.data[rowIndex] = currCaseNote2;
        // Re-check enabledness since fields have changed.
        this.enableOrDisableFields();
        this.setChanged();
      }
      this.isLoading.next(false);
    },
      err => {
        CaseUtils.ReportHTTPError(err, "Refreshing Case Note");
        this.isLoading.next(false);
      });
  }

  //on Dragging row to the new position in the list
  onDragRow(draggedRow: any, rowIndex: any) {
    this.previousDragRowIndex = rowIndex;
    //console.log(draggedRow)
  }

  //DH- check whether note can be renumbered
  isRowValidForRenumber(dropRowIndex: number): boolean {
    if (this.dataSourceNoteListTable.data[dropRowIndex].change_ACTION_CD !== 'A') {
      MessageMgr.swalFire({
        text: 'Cannot move note before an Implemented note.',
        icon: 'error',
        width: 300,
        showCancelButton: false,
        confirmButtonColor: '#3085d6',
        confirmButtonText: 'Ok'
      });
      return false;
    }
    return true;
  }

  //on Dropping row to the new postion in the list
  onDropRow(event: CdkDragDrop<string[]>) {
    let currentIndex = event.currentIndex;
    if (currentIndex !== this.previousDragRowIndex && this.isRowValidForRenumber(currentIndex)) {
      moveItemInArray(this.dataSourceNoteListTable.data, this.previousDragRowIndex, currentIndex);
      this.dataSourceNoteListTable._updateChangeSubscription();
      this.changeDetectorRef.detectChanges();
      this.isNoteBeingMoved = true;
      this.setChanged();
      this.refreshSingleICaseNote(this.dataSourceNoteListTable.data[this.previousDragRowIndex]);
      this.refreshSingleICaseNote(this.dataSourceNoteListTable.data[currentIndex]);
      this.dataSourceNoteListTable.data[this.previousDragRowIndex].theICaseNote.status = this.setChangedRow(this.dataSourceNoteListTable.data[this.previousDragRowIndex].theICaseNote.status);
      this.dataSourceNoteListTable.data[currentIndex].theICaseNote.status = this.setChangedRow(this.dataSourceNoteListTable.data[currentIndex].theICaseNote.status);
      this.dataSourceNoteListData[this.previousDragRowIndex] = this.dataSourceNoteListTable.data[this.previousDragRowIndex];
      this.dataSourceNoteListData[currentIndex] = this.dataSourceNoteListTable.data[currentIndex];
    }
  }

  //update current note number to a new available number
  setNoteNumber(rowIndex: any, noteNumVal: any) {
    this.dataSourceNoteListTable.data[rowIndex].user_NOTE_NUMBER_ID = noteNumVal;
    this.refreshSingleICaseNote(this.dataSourceNoteListTable.data[rowIndex]);
    this.dataSourceNoteListTable.data[rowIndex].theICaseNote.status = this.setChangedRow(this.dataSourceNoteListTable.data[rowIndex].theICaseNote.status);
    this.dataSourceNoteListData[rowIndex] = this.dataSourceNoteListTable.data[rowIndex];
  }

  //search for an available note
  getAvailableNoteNumber(newNoteNum: number): number {
    let dataSourceLength = this.dataSourceNoteListTable.data.length;
    for (var i = 0; i < dataSourceLength; i++) {
      //check whether newNoteNum is already taken
      if (newNoteNum == this.dataSourceNoteListTable.data[i].user_NOTE_NUMBER_ID
        && !this.dataSourceNoteListTable.data[i].isRenumberAllowed)
        //increase to check for next available note 
        newNoteNum = newNoteNum + 1;
    }
    return newNoteNum;
  }

  //renumber Note
  renumberNotesInList() {
    var newNoteNumber: number = 1;
    if (this.isNoteBeingMoved) {
      let dataSourceLength = this.dataSourceNoteListTable.data.length;
      for (var i = 0; i < dataSourceLength; i++) {
        if (this.dataSourceNoteListTable.data[i].isRenumberAllowed) {
          newNoteNumber = this.getAvailableNoteNumber(newNoteNumber);
          this.setNoteNumber(i, newNoteNumber);
        }
        else {
          //just skip assigning new number to this unmovable note
          if (newNoteNumber >= this.dataSourceNoteListTable.data[i].user_NOTE_NUMBER_ID)
            newNoteNumber = newNoteNumber - 1;
        }
        newNoteNumber = newNoteNumber + 1;
      }
    }
    this.dataSourceNoteListTable._updateChangeSubscription();
    //console.log(this.dataSourceNoteListTable.data)
  }

  /**
   * ***********************************************************************
   * Save functionality.
   * ***********************************************************************
   */

  // Pre-save: Prepare for sending to the back-end for saving.
  private preSave() {
    // DH - Jira 4638 - Renumber Note when applicable
    this.renumberNotesInList()

    // Re-copy the deleted case note to the case note list (with status of 3).
    this.theDeletedCaseNoteList.forEach((delCaseNoteDto: CaseNoteDto) => {
      this.dataSourceNoteListData.push({
        ...delCaseNoteDto,
        theICaseNote: { ...delCaseNoteDto.theICaseNote, status: DsamsConstants.ENT_DELETED }
      });
    });
    // Save the lock session ID to the first element in the list so we can pass it to the back-end for saving.
    if (this.dataSourceNoteListData.length > 0) {
      const caseNoteLockId: number = +(sessionStorage.getItem(DsamsConstants.SESSION_CASE_NOTE_LIST_LOCK_ID));
      this.dataSourceNoteListData.filter((eachCnDto: CaseNoteDto) => eachCnDto.theICaseNote.status != DsamsConstants.ENT_UNCHANGED)[0].theICaseNote.lockSessionId = caseNoteLockId;
    }
  }

  onSave() {
    this.isLoading.next(true);
    this.preSave();
    this.caseRestService.saveCaseNoteList(this.dataSourceNoteListData).subscribe((pSuccess: boolean) => {
      MessageMgr.swalFire({
        text: 'Save complete.',
        icon: 'success',
        width: 300,
        showCancelButton: false,
        confirmButtonColor: '#3085d6',
        confirmButtonText: 'Ok'
      });
      this.postSave();
      this.isLoading.next(false);
    },
      err => {
        CaseUtils.ReportHTTPError(err, "Saving Case Note List");
        this.isLoading.next(false);
      });
  }

  // Post-save
  private postSave() {
    this.populateCaseLineNoteList(this.theCaseRelatedInfoType);
    this.isNoteBeingMoved = false;
    this.setUnchanged();
  }

  /***************** Replace Expired Version Button Click *******************/
  onClickReplaceExpiredVersion() {
    const dialogRef = this.dialog.open(ReplaceExpiredVersionComponent, {
      width: '1700px',
      height: '800px',
      data: {
        noteList: this.dataSourceNoteListData
      },
      autoFocus: true,
      disableClose: true
    });
    dialogRef.afterClosed().subscribe((data) => {
      if (data) {
        this.checkedDataList = data;
        this.isLoading.next(true);
        this.checkedDataList.forEach((value) => {
          value.theNoteId.note_EXPIRATION_DT = this.datepipe.transform(value.theNoteId.note_EXPIRATION_DT, 'yyyy-MM-dd');
        });
        this.caseRestService.getLatestCaseNoteListVersionDto(this.checkedDataList).subscribe((result) => {
          this.isLoading.next(false);
          if (result !== null) {
            this.populateCaseLineNoteList(this.theCaseRelatedInfoType);
            let errorMessage: string = "";
            for (let t = 0; t < Object.keys(result).length; t++) {
              if (result[t].note_VERSION_ID < result[t].theNoteId.note_VERSION_ID) {
                errorMessage += "Note " + result[t].user_NOTE_NUMBER_ID + ":" + " Update Successful                 " + "<br/>"
              } else {
                errorMessage += "Note " + result[t].user_NOTE_NUMBER_ID + ":" + " No newer version of note was found" + "<br/>"
              }
            }
            MessageMgr.displayInfo(errorMessage.trim());
          }
          else {
            this.isLoading.next(false);
            MessageMgr.displayErrorMessage("E102");
          }
        },
          err => {
            this.isLoading.next(false);
          });
      }
    });
  }
  /**********************Assign Reference Notes********************/
  onClickAssignReferenceNotes() {
    if (!this.isDuplicate()) {
      if (!!this.theCaseRelatedInfoData) {
        this.isLoading.next(true);
        this._getCaseNoteApplicableReferenceNotesSubscription = this.caseRestService.getCaseNoteApplicableReferenceNotes(this.theCaseRelatedInfoData.case_ID,
          this.theCaseRelatedInfoData.case_VERSION_ID).subscribe((data) => {
            if (data !== null) {
              //Do comparison to existing list... if not result = 0 then proceed with dialog.
              //data.forEach((row, index, arr) => {              
              for (let i = 0; i < this.dataSourceNoteListData.length; i++) {
                for (let t = data.length - 1; t >= 0; t--) {
                  if (data[t].theNoteId.note_ID == this.dataSourceNoteListData[i].theNoteId.note_ID &&
                    data[t].theNoteId.note_VERSION_ID == this.dataSourceNoteListData[i].theNoteId.note_VERSION_ID) {
                    data.splice(t, 1);
                  }
                }
              }
            }
            if (data.length > 0) {
              this.reconciledNoteListData = data;
              const dialogRef = this.dialog.open(AssignReferenceNotesComponent, {
                height: '180px',
                width: '360px',
                data: { value: "OK" },
                autoFocus: true,
                disableClose: true
              });
              dialogRef.afterClosed().subscribe((value) => {
                if (value === 'OK') {
                  let caseNoteDTO: CaseNoteDto = {};
                  // Need to get the max note number un the list and then add 1 to that.
                  this.newNoteNumber = (!this.dataSourceNoteListData || this.dataSourceNoteListData.length == 0) ? 1 : this.dataSourceNoteListData[this.dataSourceNoteListData.length - 1].user_NOTE_NUMBER_ID + 1;
                  for (let m = 0; m < this.reconciledNoteListData.length; m++) {
                    caseNoteDTO.case_ID = this.theCaseRelatedInfoType.case_ID;
                    caseNoteDTO.case_VERSION_ID = Number.parseInt(this.theCaseRelatedInfoType.case_VERSION_ID);
                    caseNoteDTO.note_ID = this.reconciledNoteListData[m].theNoteId.note_ID;
                    caseNoteDTO.note_VERSION_ID = this.reconciledNoteListData[m].theNoteId.note_VERSION_ID;
                    caseNoteDTO.user_NOTE_NUMBER_ID = this.newNoteNumber;
                    caseNoteDTO.assignment_IN = true;
                    caseNoteDTO.theNoteId = this.reconciledNoteListData[m].theNoteId;
                    caseNoteDTO.theNoteId.note_EXPIRATION_DT = this.datepipe.transform(this.reconciledNoteListData[m].theNoteId.note_EXPIRATION_DT, 'MM/dd/yyyy', 'en-US');
                    caseNoteDTO.change_ACTION_CD = this.reconciledNoteListData[m].change_ACTION_CD;
                    if (this.reconciledNoteListData[m].theNoteId.note_TYPE_CD === 'RC') {
                      caseNoteDTO.theNoteId.note_TYPE_CD = 'CT';
                    }
                    this.refreshSingleICaseNote(caseNoteDTO);
                    caseNoteDTO.theICaseNote.status = DsamsConstants.ENT_NEW;
                    this.dataSourceNoteListData.push(caseNoteDTO);
                    this.newNoteNumber += 1;
                    caseNoteDTO = {};
                  }
                  this.dataSourceNoteListTable = new MatTableDataSource<CaseNoteDto>(this.dataSourceNoteListData);
                  this.dataSourceNoteListTable._updateChangeSubscription();
                  this.enableOrDisableFields();
                  let successMessage: string = "";
                  successMessage = "(" + this.reconciledNoteListData.length + ") Applicable Reference Notes Appended";
                  MessageMgr.displayInfo(successMessage);
                  this.isLoading.next(false);
                  this.setChanged();
                }
                this.isLoading.next(false);
              },
                err => {
                  this.isLoading.next(false);
                  MessageMgr.displayErrorMessage("Unsuccessful: No Applicable Reference Notes");
                });
            } else {
              let errorMessage: string = "";
              errorMessage = "(0) Applicable Reference Notes to Append";
              MessageMgr.displayInfo(errorMessage);
              this.isLoading.next(false);
            }
          })
      } else {
        let errorMessage: string = "";
        errorMessage = "(0) Applicable Reference Notes Appended";
        MessageMgr.displayInfo(errorMessage);
        this.isLoading.next(false);
      }
    }
  }

  isDuplicate(): boolean {
    if (this.newNoteNumber !== null) {
      return true;
    } else {
      return false;
    }
  }
}
