/* This class is used to handle all business logic for 
   the Note Dashboard page.
   Author: David Huynh
   Date:   09/07/2021 
*/

import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { CaseLineRelatedInfoType } from '../model/case-line-related-info-type';
import { CaseRelatedInfoType } from '../model/case-related-info-type';
import { CaseUIService } from '../services/case-ui-service';
import { CaseUtils } from '../utils/case-utils';
import { MatTabChangeEvent, MatTabGroup } from '@angular/material';
import { ICaseNote } from '../model/dto/case-note';
import { DsamsConstants } from '../../dsams.constants';
import { IEditResponseType } from '../model/edit-response-type';
import { NoteUtils } from './note-utils';
import { LinkCaseDataClass } from '../model/link-case-data';
import { DsamsShareService } from '../../services/dsams-share.service';
import { BehaviorSubject } from 'rxjs';
import { CsuCompNameHashTable } from '../../utilitis/csu-component-hashtable';
import { LineSublineRefComponent } from '../line-dashboard/line-reference.component';
import { take } from 'rxjs/operators';

@Component({
  selector: 'app-note-dashboard',
  templateUrl: './note-dashboard.component.html',
  styleUrls: ['./note-dashboard.component.css']
})
export class NoteDashboardComponent implements OnInit {
  @ViewChild("mtg", { static: false }) theTabGroup: MatTabGroup;

  selectedTab: any;

  aCaseUserId: any = '';
  caseRelatedInfoData: CaseRelatedInfoType;
  caseLineRelatedInfoData: CaseLineRelatedInfoType;
  private _caseUIServiceSubscription: Subscription = null;
  private _caseUIServiceSubscription2: Subscription = null;
  noteListorNote: any = 'Note List (WP007)';
  private _noteTypeSubscription: Subscription = null;
  private _notePopulatedSubscription: Subscription = null;
  private _autoNavigateToNoteListSubscription: Subscription = null;
  private _detailChangedSubscription: Subscription = null;
  private _listChangedSubscription: Subscription = null;
  // Only necessary for static data: Standard, Customizable, Unique
  noteTypeParameter: string = 'Standard';
  caseNoteEntity: ICaseNote = null;
  isEditDisabled: boolean = true;
  noteEditor: string;
  private _changesMadeToDetail: boolean = false;
  private _changesMadeToList: boolean = false;
  aCaseId: any;
  aCaseVersionId: any;
  aCaseVersionNumId: any;
  aCaseVersionTypeCd: any;
  aCaseVersionTypeDesc: any;
  aCustomerOrgId: any;
  aUserCaseId:any;

  isNoteTabDisabled: any; 

  readonly PAGE_CASE_NOTE_LIST: string = DsamsConstants.PAGE_CASE_NOTE_LIST;
  //DSAMS-5461 DH 05/22
  theCSUId: string;
  isEditRightAccessGranted: boolean = true;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private CSUHashTable : CsuCompNameHashTable,
    private caseUIService: CaseUIService,
    private lineShareService: LineSublineRefComponent,
    private dataSharingService: DsamsShareService,
  ) {
    this.selectedTab = this.route.snapshot.params['1'];
    //begin DSAMS-5461 DH 05/22
    let aCsuId = this.CSUHashTable.getCSUId(this.route.routeConfig.component.name);
    this.theCSUId = aCsuId ? aCsuId : CsuCompNameHashTable.CSU_CD_WP007;
    //end DSAMS-5461 DH 05/22
  }

  ngOnInit() {
    this.getEditAccessRight();

    this.dataSharingService.csuname.next(null);
    this.dataSharingService.csuname.next(this.theCSUId);

    if (!!this.route.snapshot.queryParamMap.get(LinkCaseDataClass.theLinkCaseData)){
      this.dataSharingService.breadcrumbForNewPage.next(LinkCaseDataClass.theLinkCaseData);
      this.getLinkCaseDataForNewPage();
    }
    this.caseUIService.setPageNavigation(DsamsConstants.PAGE_CASE_NOTE_LIST);
    this._caseUIServiceSubscription = this.caseUIService.getCaseLineRelatedInfoValues().subscribe((value) => {
      this.caseLineRelatedInfoData = value;
      //console.log('caseLineRelatedInfoData=', value)
      if (!!this.caseLineRelatedInfoData) {
        this.aUserCaseId = this.caseLineRelatedInfoData.user_CASE_ID;
        if (!CaseUtils.isBlankStr(this.caseLineRelatedInfoData.case_VERSION_NUMBER_ID))
          this.aCaseUserId = '(' + this.caseLineRelatedInfoData.user_CASE_ID + ' '
            + this.caseLineRelatedInfoData.case_VERSION_TYPE_CD +
            this.caseLineRelatedInfoData.case_VERSION_NUMBER_ID + ')';
        else
          this.aCaseUserId = '(' + this.caseLineRelatedInfoData.user_CASE_ID + ' '
            + this.caseLineRelatedInfoData.case_VERSION_TYPE_CD + ')';

        this.populateCaseNoteForEditabilityForNoteList();
      }
    });
    this._caseUIServiceSubscription2 = this.caseUIService.getCaseRelatedInfoValues().subscribe((value) => {
      this.caseRelatedInfoData = value;
      if (!!this.caseRelatedInfoData) {
        if (this.caseRelatedInfoData.case_ID != null) {
          this.aCaseId = this.caseRelatedInfoData.case_ID;
        } else {
          this.aCaseId = this.caseRelatedInfoData.working_CASE_ID;
        }
        this.aCaseVersionId = this.caseRelatedInfoData.working_CASE_VERSION_ID;
        this.aCustomerOrgId = this.caseRelatedInfoData.customer_ORGANIZATION_ID;
      }

      this.populateCaseNoteForEditabilityForNoteList();
    });
    this.aCaseVersionNumId = 0;
    this.aCaseVersionTypeCd = "";
    this.aCaseVersionTypeDesc = "";
    this.caseUIService.setIsOptionsMenuHidden(false);
    this.caseUIService.setIsShortcutsMenuHidden(false);
    this.getNoteTypeFromSubscription();
    this.subscribeToCaseNoteBeingPopulated();
    this.subscribeToAutoNavigateToNoteList();
    this.subscribeToDetailChangesMade();
    this.subscribeToListChangesMade();
    this.noteEditor = DsamsConstants.NOTE_LIST_EDITOR;
  }

  ngOnDestroy() {
    this.dataSharingService.csuname.next(null);
    if (this._caseUIServiceSubscription) this._caseUIServiceSubscription.unsubscribe();
    if (this._caseUIServiceSubscription2) this._caseUIServiceSubscription2.unsubscribe();

    if (!!this._noteTypeSubscription) {
      this._noteTypeSubscription.unsubscribe();
      this._noteTypeSubscription = null;
    }
    if (!!this._notePopulatedSubscription) {
      this._notePopulatedSubscription.unsubscribe();
      this._notePopulatedSubscription = null;
    }
    if (!!this._autoNavigateToNoteListSubscription) {
      this._autoNavigateToNoteListSubscription.unsubscribe();
      this._autoNavigateToNoteListSubscription = null;
    }
    if (!!this._detailChangedSubscription) {
      this._detailChangedSubscription.unsubscribe();
      this._detailChangedSubscription = null;
    }
    if (!!this._listChangedSubscription) {
      this._listChangedSubscription.unsubscribe();
      this._listChangedSubscription = null;
    }
  }

  //begin DSAMS-5461 DH 05/22
  getEditAccessRight(): void {
    this.lineShareService.getEditAccessRight(this.theCSUId)
      .pipe(take(1))
      .subscribe(result => {
        if (result == 1) this.isEditRightAccessGranted = true;
        else {
          this.isEditRightAccessGranted = false;
          this.caseUIService.setIsOptionsMenuHidden(true);
        }
      });
  }
  //end DSAMS-5461 DH 05/22

  //back to previous Case Search Summary page 
  goBackToCaseSearchSummary() {
    this.caseUIService.setbackToCaseSearchSummaryValue(true);
    this.router.navigateByUrl('/case/search', { relativeTo: this.route });
  }

  prevTab: number = 0;
  onTabChanged(tabChangeEvent: MatTabChangeEvent): void {
    //console.log('before', this.noteListorNote, this.noteTypeParameter)
    // Update the label
    if (tabChangeEvent.index != this.prevTab) {
      console.log("tab index: "+tabChangeEvent.index);
 
      this.prevTab = tabChangeEvent.index;
      if (this.noteListorNote === 'Note List (WP007)') {
        if (this.noteTypeParameter == DsamsConstants.NOTE_TYPE_UNIQUE)
          this.noteListorNote = this.noteTypeParameter + ' Note (WP007A)'
        else this.noteListorNote = 'Case ' + this.noteTypeParameter + ' Note (WP007A)'
        sessionStorage.setItem(DsamsConstants.SESSION_CASE_NOTE_TAB, DsamsConstants.PAGE_CASE_NOTE_DETAIL);
        let aCsuId = CsuCompNameHashTable.getCSUCd('NoteDetailsComponent');
        this.theCSUId = aCsuId ? aCsuId : CsuCompNameHashTable.CSU_CD_WP007A;  
       }
      else {
        this.noteListorNote = 'Note List (WP007)';
        this.populateCaseNoteForEditabilityForNoteList();
        sessionStorage.setItem(DsamsConstants.SESSION_CASE_NOTE_TAB, DsamsConstants.PAGE_CASE_NOTE_LIST);
        // begin dsams-5371 05/22 DB -- this routine is no longer needed.  removed
        // Listen for navigating to the case note detail from note list
        //end  dsams-5371 05/22 DB
        let aCsuId = CsuCompNameHashTable.getCSUCd('NoteDashboardComponent');
        this.theCSUId = aCsuId ? aCsuId : CsuCompNameHashTable.CSU_CD_WP007;  
      }
      // Reset Option Flags
      this.caseUIService.resetOptionFlags('Case Note');
      this.caseUIService.optionSelectCounter.next(0);
      this.caseUIService.setNotifyToSetDefaultOption(true);
    }
    this.dataSharingService.csuname.next(null);
    this.dataSharingService.csuname.next(this.theCSUId);
    this.caseUIService.caseNoteTabNbrChanged.next(this.selectedTab);
  }

  //Jira DSAMS-5346 DH 04/22
  getLinkCaseDataForNewPage() {
    let linkCaseData = LinkCaseDataClass.getTheLinkCaseData(this.route);
    if (!!linkCaseData) {
      sessionStorage.setItem(DsamsConstants.SESSION_SDB_ID, linkCaseData.serviceDbId);
      this.caseRelatedInfoData = {
        case_ID: linkCaseData.case_ID,
        working_CASE_VERSION_ID: linkCaseData.case_VERSION_ID,
        case_VERSION_ID: linkCaseData.case_VERSION_ID.toString(),
        customer_ORGANIZATION_ID: linkCaseData.customer_ORGANIZATION_ID,
        case_MASTER_STATUS_CD: linkCaseData.case_MASTER_STATUS_CD,
      }
      this.caseLineRelatedInfoData = {
        case_ID: linkCaseData.case_ID,
        case_VERSION_STATUS_CD: linkCaseData.case_VERSION_STATUS_CD,
        case_VERSION_TYPE_CD: linkCaseData.case_VERSION_TYPE_CD,
        security_ASSISTANCE_PROGRAM_CD: linkCaseData.security_ASSISTANCE_PROGRAM_CD,
        user_CASE_ID: linkCaseData.user_CASE_ID,
        case_VERSION_NUMBER_ID: linkCaseData.case_VERSION_NUMBER_ID,
      }
      //emit updated case/case line info data 
      this.caseUIService.setCaseLineRelatedInfoValues(this.caseLineRelatedInfoData);
      this.caseUIService.setCaseRelatedInfoValues(this.caseRelatedInfoData);
    }
  }

  //listen for note type
  /* Note Type Subscription */
  getNoteTypeFromSubscription() {
    if (!this._noteTypeSubscription) {
      this._noteTypeSubscription = this.caseUIService.getNoteType().subscribe((value: string) => {
        setTimeout(() => { this.noteTypeParameter = value; }, 0);
      });
    }
  }

  isSelectedIx: BehaviorSubject<boolean> = new BehaviorSubject(false);
  setTabActive($event) {
    if (this.selectedTab != $event) {
      if (!this.isSelectedIx.value) {
        this.onSelectedIndexChanged($event);
      } else {
        this.selectedTab = $event;
      }
    }
  }


  onSelectedIndexChanged(pEventNum: number) {
    this.isSelectedIx.next(true);
    if (pEventNum == 0 && this._changesMadeToDetail) {
     this.onNoteListSelected();
    } else  if (pEventNum == 1 && this._changesMadeToList) {
      this.onNoteDetailSelected();
    } else {
      this.noteEditor = pEventNum == 0 ? DsamsConstants.NOTE_LIST_EDITOR : DsamsConstants.NOTE_EDITOR
      this.selectedTab = pEventNum;
      this.isSelectedIx.next(false);
      this.caseUIService.caseNoteTabNbrChanged.next(pEventNum);
     }
  }

  onNoteListSelected() {
      NoteUtils.showConfirmLoseChanges("Case Note Details not saved.").then((result) => {
        if (result.value) {
          // Yes selected, proceed with navigating to first tab.
          this.selectedTab = 0;
          this.noteEditor = DsamsConstants.NOTE_LIST_EDITOR;
          this._changesMadeToDetail = false;
          this.caseUIService.checkDiscardNoteChanges.next(true);
        
         
        }
       
        else {
          // No selected. Stay on current tab.
          this.selectedTab =  1;
          this.noteEditor = DsamsConstants.NOTE_EDITOR;
          this._changesMadeToDetail = true;
          this.caseUIService.checkDiscardNoteChanges.next(false);
        }
        this.isSelectedIx.next(false);
      });
    }

  
onNoteDetailSelected() {
  NoteUtils.showConfirmLoseChanges("Case Note List not saved.").then((result) => {
    if (result.value) {
      // Yes selected, proceed with navigating to first tab.
      this.selectedTab = 1;
      this.noteEditor = DsamsConstants.NOTE_LIST_EDITOR;
       this._changesMadeToDetail = false;
      this._changesMadeToList = false;
    
    }
   
    else {
      // No selected. Stay on current tab.
      this.selectedTab =  0;
      this.noteEditor = DsamsConstants.NOTE_EDITOR;
      this._changesMadeToList = true;
      this.caseUIService.checkDiscardNoteListChanges.next(false);
     
    }
    this.isSelectedIx.next(false);
  });
}




  // Populate a slimmed down caseNoteDto object for the edit toggle for the note list.
  private populateCaseNoteForEditabilityForNoteList() {
    if (!!this.caseRelatedInfoData && !!this.caseLineRelatedInfoData) {
      const caseNoteStub: ICaseNote = {
        case_ID: this.caseRelatedInfoData.case_ID,
        case_VERSION_ID: this.caseRelatedInfoData.working_CASE_VERSION_ID,
        theCaseVersionId: {
          case_VERSION_STATUS_CD: this.caseLineRelatedInfoData.case_VERSION_STATUS_CD,
          theCaseId: {
            case_MASTER_STATUS_CD: this.caseRelatedInfoData.case_MASTER_STATUS_CD
          }
        }
      };
      this.caseUIService.caseNotePopulated.next(caseNoteStub);
    }
  }

  // Subscribe to the case note being populated so we can pass that to the edit toggle.
  subscribeToCaseNoteBeingPopulated() {
    if (!this._notePopulatedSubscription) {
      this._notePopulatedSubscription = this.caseUIService.caseNotePopulated.subscribe((pCaseNote: ICaseNote) => {
        this.caseNoteEntity = pCaseNote;
        this.isEditDisabled = false;
      });
    }
  }

  subscribeToAutoNavigateToNoteList() {
    if (!this._autoNavigateToNoteListSubscription) {
      this._autoNavigateToNoteListSubscription = this.caseUIService.autoNavigateToNoteList.subscribe(() => {
        this.selectedTab = this.route.snapshot.params['1'];
      });
    }
  }

  private subscribeToDetailChangesMade() {
    if (!this._detailChangedSubscription) {
      this._detailChangedSubscription = this.caseUIService.hasEditBeenMadeService.subscribe((pEditResponse: IEditResponseType) => {
        if (!!pEditResponse && pEditResponse.ID == DsamsConstants.NOTE_EDITOR) {
          this._changesMadeToDetail = pEditResponse.editToggle;
        }
      });
    }
  }
  private subscribeToListChangesMade() {
    if (!this._listChangedSubscription) {
      this._listChangedSubscription = this.caseUIService.hasEditBeenMadeService.subscribe((pEditResponse: IEditResponseType) => {
        if (!!pEditResponse && pEditResponse.ID == DsamsConstants.NOTE_LIST_EDITOR) {
          this._changesMadeToList = pEditResponse.editToggle;
        }
      });
    }
  }
  ngAfterViewInit() {
    this.caseUIService.submitBreadcrumbTitleChangeRequest("Note List");

    // Reset Option Flags
    console.log("###### In ngAfterViewInit(), caseLineRelatedInfoData.case_VERSION_STATUS_CD is ", this.caseLineRelatedInfoData.case_VERSION_STATUS_CD);
    this.caseUIService.resetOptionFlags('Case Note');
    // After resetOptionFlags service, it appears the Services Complete option is still not reset, manually set it to false.
    this.caseUIService.setIsStatusCompleteEnabled(false);
    this.caseUIService.optionSelectCounter.next(0);
    this.caseUIService.setNotifyToSetDefaultOption(true);

    this.caseUIService.setIsCaseInReviewEnabled(CaseUtils.isOptionEnabledForCaseInReviewShortcut(this.caseLineRelatedInfoData.case_VERSION_STATUS_CD));
    this.caseUIService.setIsPenInkEnabled(CaseUtils.isOptionEnabledForPenInkShortcut(this.caseLineRelatedInfoData.case_VERSION_STATUS_CD));

  }
}
