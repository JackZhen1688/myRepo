/* This class is used to handle all business logic for 
   the Note Details page.
   Author: Francis Shu 
   Date:   09/07/2021 
*/

import { Component, OnInit,OnDestroy, ViewChild, EventEmitter,Output, ChangeDetectorRef, Injector } from '@angular/core';
import { BehaviorSubject,  Subscription } from 'rxjs';
import { MatTableDataSource } from '@angular/material/table';
import { MdePopoverTrigger } from '@material-extended/mde';
import { CaseUIService } from '../../services/case-ui-service';
import { ifaceCaseLineData } from '../../model/case-line-model';
import { Router } from '@angular/router';
import { CaseUtils } from '../../utils/case-utils';
import { DsamsConstants } from 'src/app/dsams/dsams.constants';
import { CaseRestfulService } from '../../services/case-restful.service';
import { CaseLineRelatedInfoType } from '../../model/case-line-related-info-type';
import { FormControl } from '@angular/forms';
import { IEditResponseType } from '../../model/edit-response-type';
import { DsamsMethodsService } from '../../../services/dsams-methods.service';
import { DsamsUserMessageService } from 'src/app/dsams/services/dsams-user-message.service';
import { ICaseVersion } from '../../model/dto/icase-version';
import { MilestoneCommentComponent } from '../../dialogs/milestone-comment/milestone-comment.component';
import { MatDialog, MatDialogRef, MatDialogState } from '@angular/material';
import { AssoLinesComponent } from 'src/app/dsams/case/dialogs/asso-lines/asso-lines.component';
import { ISelectOptions } from 'src/app/dsams/interfaces/i-select-options';
import { ICaseNote } from '../../model/dto/case-note';
import { CaseNoteDto } from '../../model/dto/case-note-dto';
import { INote } from '../../model/note';
import { MessageMgr } from '../../validation/message-mgr';
import { NoteUtils } from '../note-utils';
import { INoteType } from '../../model/dto/note-type';
import { INoteContent } from '../../model/dto/note-content';
import { MatSort } from '@angular/material/sort';
import { DsamsRestfulService } from 'src/app/dsams/services/dsams-restful.service';
import { IEditResultsType } from '../../model/edit-results-type';
import { CaseCommonValidator } from '../../validation/case-common-validator';
import { LineUtils } from '../../line-dashboard/line-utils';
import { ErrorParameter } from 'src/app/dsams/entities/specialEntities/error-parameter.model';
import { DialogMessageListComponentTc } from 'src/app/dsams/utilitis/dialogs/dialog-message-list-tc/dialog-message-list-tc.component';
import { MessageType } from 'src/app/dsams/enums/user-message.enum';
import { ICaseLineNote } from '../../model/dto/case-line-note';
import { ICaseNoteParameter } from '../../model/dto/case-note-parameter';



declare function focusItem(pItem: string): any;

export interface iAssoLines {
  wm_status?: string;
  isDisabled?: boolean;   // Is row enabled?
  caseId?: number;
  caseMasterLineId?: number;
  caseVersionId?: number;
  lineNum: string;
  status: string;
  masl: string;
  maslDesc: string;
  quantity: string;
  issue: string;
  ent_status: number;
  tempStatus?: boolean;
}

export interface fillIns {
  name: string;
  prompt: string;
  value: string;
  theICaseNoteParameter?: ICaseNoteParameter,
}

export interface caseMasterlineDto {
  case_ID?: number,
  case_MASTER_LINE_ID?: number,
  wm_USER_CASE_LINE_NUMBER_ID?: string,
  wm_USER_CASE_SUBLINE_TX?: string,
  wm_PARENT_CASE_ID?: number,
  wm_PARENT_CASE_MASTER_LINE_ID?: number,
  virtualSublineList?: string[];
}
@Component({
  selector: 'app-note-details',
  templateUrl: './note-details.component.html',
  styleUrls: ['./note-details.component.css',
    '../../line-dashboard/common-CSS.component.css'],
  providers: [
    {
      provide: MatDialogRef,
      useValue: {}
    }
  ]
})
export class NoteDetailsComponent implements OnInit, OnDestroy  {
  @Output() sendNoteDetailsTabIndex = new EventEmitter<number>();
 
  @ViewChild(MdePopoverTrigger, { static: true }) trigger: MdePopoverTrigger;

  @ViewChild(MatSort, { static: true }) sort: MatSort;

  //Color Attibutes
  ActiveBtnColor: any = '#e7eff6';
  ActiveBgColor: any = 'white';
  InactiveBtnColor = 'darkgrey';
  ActiveDeleteBtnColor = 'red'

  // Field
  txtNoteNumber = '';
  txtNoteStatus = 'A - Added';
  txtLineNumber: string = '';
  txtSublineNumber: string = '';
  txtOfficialTitle = 'N/A';
  txtBelowLineCategory = 'N/A';
  txtNoteId = '';
  txtNoteVersion = '1';
  txtNoteText = '';
  txtNoteStandardFillinA = '[A]';
  txtNoteStandardFillinB = '[B]';
  ipcCategoryCd = '';
  theCustomerTypeCode: string = '';

  // Note type
  readonly NOTE_TYPE_STANDARD: string = DsamsConstants.NOTE_TYPE_STANDARD;
  readonly NOTE_TYPE_CUSTOMIZABLE: string = DsamsConstants.NOTE_TYPE_CUSTOMIZABLE;
  readonly NOTE_TYPE_UNIQUE: string = DsamsConstants.NOTE_TYPE_UNIQUE;
  readonly NOTE_TYPE_LINE_ITEM: string = DsamsConstants.NOTE_TYPE_LINE_ITEM;
  // *** Set the Note Type ***
  noteType: string;

  private _milestoneSubscription: Subscription = null;
  private _caseUIServiceSubscription1: Subscription = null;
  private _caseUIServiceSubscription2: Subscription = null;
  private _caseUIServiceSubscription3: Subscription = null;
  private _caseUIServiceSubscription4: Subscription = null;
  private _refreshDataSubscription: Subscription = null;
  private _noteListSubscription: Subscription = null;
  private _assocListPopupSubscription: Subscription = null;
  private _detailNavSubscription: Subscription = null;
  private _revertEditSubscription: Subscription = null;
  private _ucirSubscription: Subscription = null;
  private _penInkSubscription: Subscription = null;
  programOfRecordDisp: string = "N/A";
  isRefreshDataNeeded: boolean = false;
  isLoading: BehaviorSubject<boolean> = new BehaviorSubject(false);
  private _noteTypeSubscription: Subscription = null;
  private fullNoteList: CaseNoteDto[] = null;
  prevCaseNote: CaseNoteDto = null;
  nextCaseNote: CaseNoteDto = null;
  currCaseNote: CaseNoteDto = null;
  private _changesMade: boolean = false;
  
  caseLineInfoData: ifaceCaseLineData;
  caseLineRelatedInfoData: CaseLineRelatedInfoType;
  aCaseUserId: any;
  theInitialCaseLineInfoData: ifaceCaseLineData;

  addAssistanceBtnColor: any = this.InactiveBtnColor;

  //Use form control for built-in required field validation

  //Editable fields
  isNewMode: boolean = false;

  // Line Number Change Update
  caseLineNumberUpdate: string;

  // Warning message to display prior to save.
  private _warningMsg: any = null;

  caseVersionData: ICaseVersion;

  lineExists: boolean = false;
  sublineExists: boolean = false;
  caseVersionStatusDevelopmentType: string = "D";
  dialogState: MatDialogState;

  dataSourceAssoLines = new MatTableDataSource<iAssoLines>();
  aAssoLinesArray = [];

  assoLinesColumnsFooter = ['AddRow'];
  columnsToDisplayAssoLines = ['LineNum', 'Status', 'MASL', 'Quantity', 'Issue', 'DeleteRow'];
  assoLineRowIndex: number = 0;

  dataSourceFillIns = new MatTableDataSource<fillIns>();

  columnsToDisplayFillIns = ['Name', 'Prompt', 'Value'];
  fillInsRowIndex: number = 0;

  //Use form control for built-in required field validation
  fillInFormCtl: FormControl;

  // Note master entity.
  caseNoteEntity: ICaseNote;

  // Set up initial dataSource
  assoLinesDataList: iAssoLines[] = [];
  theDeletedAssoLinesDataList: iAssoLines[] = [];

  // Set up initial dataSource for fill-ins
  fillInsDataList: fillIns[] = [];

  private readonly IPC_CAT_AD: string = "AD";
  private readonly IPC_CAT_AU: string = "AU";
  private readonly IPC_CAT_BL: string = "BL";
  private readonly IPC_CAT_PC: string = "PC";
  private readonly IPC_CAT_SG: string = "SG";
  private readonly IPC_CAT_SS: string = "SS";
  private readonly IPC_CAT_ST: string = "ST";
  private readonly IPC_CAT_TR: string = "TR";

  validIPCCategory: ISelectOptions[] = [
    { value: '', viewValue: '' },
    { value: this.IPC_CAT_AD, viewValue: 'AD - Administrative Charge' },
    { value: this.IPC_CAT_AU, viewValue: 'AU - Asset Use' },
    { value: this.IPC_CAT_BL, viewValue: 'BL - Misc Below Line Cost' },
    { value: this.IPC_CAT_PC, viewValue: 'PC - Packing, Crating, and Handling' },
    { value: this.IPC_CAT_SG, viewValue: 'SG - Staging' },
    { value: this.IPC_CAT_SS, viewValue: 'SS - Supply Support Arrangement' },
    { value: this.IPC_CAT_ST, viewValue: 'ST - Storage' },
    { value: this.IPC_CAT_TR, viewValue: 'TR - Transportation' }
  ];

  // Editability
  private editSubscription: Subscription = null;
  isNoteDetailsPanelEditable: boolean = false;
  isNoteOfficialTitleEditable: boolean = false;
  isBelowLineCategoryEditable: boolean = false;
  isNoteTextEditable: boolean = false;
  isRestateButtonEditable: boolean = false;
  isRefreshButtonEditable: boolean = false;
  isReplaceButtonEditable: boolean = false;
  isDeleteButtonEditable: boolean = false;
  isRestateButtonAmendMod: boolean = false;
  isNoteDetailsLineEditable: boolean = false;

  _editToggleState: boolean = false;

  //Restate Button
  restateCaseVersionTypeCd: String = null;

  theCaseLineListArray: caseMasterlineDto[] = [];
  theCaseLineListTempArray: caseMasterlineDto[] = [];

  //sublineListArray: string[] = [];
  caseRestService: CaseRestfulService;
  dsamsRestfulService: DsamsRestfulService;
  messageService: DsamsUserMessageService;

  constructor(
    private injector : Injector,
    private caseUIService: CaseUIService,
    public dsamsDialogMsgService: DsamsMethodsService,
    // DSAMS-5371
    private changeDetectorRef: ChangeDetectorRef,
     // DSAMS-5371
    public dialog: MatDialog,
    public dialogRef: MatDialogRef<MilestoneCommentComponent>) {
      this.caseRestService = injector.get<CaseRestfulService>(CaseRestfulService);
      this.dsamsRestfulService = injector.get<DsamsRestfulService>(DsamsRestfulService);
      this.messageService = injector.get<DsamsUserMessageService>(DsamsUserMessageService);

     }

  ngOnInit() {
   
    this.theCustomerTypeCode = '';
    this.theDeletedAssoLinesDataList = [];
    // Set edit to false
    this.resetEdit();

    this.subscribeToEditService();

    this.subscribeToRevertEditSubscription();

    if (!this._caseUIServiceSubscription1) {
      this._caseUIServiceSubscription1 = this.caseUIService.getCaseLineRelatedInfoValues().subscribe((value) => {
        this.caseLineRelatedInfoData = value;
      });
    }

    if (!this._caseUIServiceSubscription2) {
      this._caseUIServiceSubscription2 = this.caseUIService.getCaseLineInfoValues().subscribe((value) => {
        this.caseLineInfoData = value;

        if (!!this.caseLineInfoData) {
          this.theCustomerTypeCode = this.caseLineInfoData.case_CUSTOMER_TYPE_CD;
          if (!CaseUtils.isBlankStr(this.caseLineInfoData.wm_CASE_VERSION_STATUS_CD)) {
            let versionStatus: string = this.caseLineInfoData.wm_CASE_VERSION_STATUS_CD;
            this.caseUIService.setIsCaseInReviewEnabled(CaseUtils.isOptionEnabledForCaseInReviewShortcut(versionStatus));
            this.caseUIService.setIsPenInkEnabled(CaseUtils.isOptionEnabledForPenInkShortcut(versionStatus, this.caseLineInfoData.wm_CASE_VERSION_TYPE_CD, this.caseLineInfoData.case_USAGE_INDICATOR_CD));
          }
          else this.caseLineInfoData.wm_CASE_VERSION_STATUS_CD = '';
        }
      });
    }

    // Subscribe to Case UI Service caseLineNumberUpdate
    if (!this._caseUIServiceSubscription3) {
      this._caseUIServiceSubscription3 = this.caseUIService.caseLineNumberUpdate.subscribe((value) => {
        this.caseLineNumberUpdate = value;
      });
    }

    // Subscribe to the Case Note Previous/Next Arrows    
    if (!this._noteListSubscription) {
      this._noteListSubscription = this.caseUIService.caseNoteListDetails.subscribe((pNoteList: CaseNoteDto[]) => {
        if (!!pNoteList) {
          this.fullNoteList = pNoteList;
          this.prepareBeforeAfterList();
        }
      });
    }

    // Fetch Case Note Info from database.
    this.fetchNote();

    // Subscribe to options.
    this.subscribeToOptionCaseInReview();
    this.subscribeToOptionCasePenInk();

    // Subscription to when user switches from note list to note details
    this.subscribeToOtherServices();
    // begin dsams-5371 04/22 DB
    this.subscribeToDiscardNoteChanges();
    this.subscribeToNoteTabNbrChanged();
    // end  dsams-5371 04/22 DB
   
   
  }

  ngAfterViewChecked() {
    this.changeDetectorRef.detectChanges();
  }



  //begin  DSAMS-5371
  subscribeToNoteTabNbrChanged() {
    this.caseUIService.caseNoteTabNbrChanged.subscribe((value: number) => {
      if (value != DsamsConstants.CASE_NOTE_DETAIL_TAB_NBR) {
        if (!this._changesMade) {
          this.setUnchanged();
          if (this.getCurrentLockSessionId() > 0) {
            this.clobberLockSessionId(0);
          }
        }
      } else {
        
       if (this._changesMade || this.isNewNoteEntity()) {
          this.caseNoteEntity.status == DsamsConstants.ENT_NEW;
          this.setChanged();
          this.turnEditOn();
       } else {
        this.setUnchanged();
        this.turnEditOff();
        }
         
      

      }
    });
  }
 
  subscribeToDiscardNoteChanges() {
   
      this.caseUIService.checkDiscardNoteChanges.subscribe((value: boolean) => {
        if (this._changesMade || this.isNewNoteEntity()) {
          if (!value ) {
            this.setChanged();
            this.turnEditOn();
          } else {
            setTimeout(() => {  this.setUnchanged();}, 300);
            this.caseUIService.flipToDisabledService.next(DsamsConstants.NOTE_EDITOR);
               this.clobberLockSessionId(0);
              this.sendTabId();
            }
        
        } else {
          this.clobberLockSessionId(0);
            this.caseUIService.flipToDisabledService.next(DsamsConstants.NOTE_LIST_EDITOR);
         }
    
      });
   
  }

  isNewNoteEntity(): boolean {
    let answer: boolean =
      (!!this.caseNoteEntity && (this.caseNoteEntity.status == DsamsConstants.ENT_NEW || this.caseNoteEntity.status == DsamsConstants.ENT_RESTATED)) ? true : false;
    return answer;
  }
  

 

  // end dsams-5371

  // Method to get sublines
  getParentLineCMLId(pParentCaseId: any, pParentCaseMasterLineId: any): string {
    //set up parent line for subline
    for (let i = 0; i < this.theCaseLineListTempArray.length; i++) {
      if (this.theCaseLineListTempArray[i].case_ID == pParentCaseId &&
        this.theCaseLineListTempArray[i].case_MASTER_LINE_ID == pParentCaseMasterLineId) {
        return (this.theCaseLineListTempArray[i].wm_USER_CASE_LINE_NUMBER_ID);
      }
    }
    return '';
  }

  //DH - Jira 2946 populate line/subline dropdown lists
  getLineDropdownList(pCaseId: number, pCaseVersionId: number) {
    this.caseRestService.getLineSublineListForCVDto(pCaseId,pCaseVersionId).subscribe(value => {
      this.theCaseLineListArray = [];
      this.theCaseLineListTempArray = [];
      this.theCaseLineListTempArray = value;
      this.theCaseLineListTempArray.forEach((eachRow) => {
        if (eachRow.wm_PARENT_CASE_MASTER_LINE_ID == null || eachRow.wm_PARENT_CASE_MASTER_LINE_ID == undefined ||
          eachRow.wm_PARENT_CASE_MASTER_LINE_ID == 0) {
          // Adding Line
          this.theCaseLineListArray.push(eachRow);
        }
        if (!!eachRow.wm_PARENT_CASE_MASTER_LINE_ID) {
          let caseMasterlineDtoObject = {
            case_ID: eachRow.case_ID,
            case_MASTER_LINE_ID: eachRow.case_MASTER_LINE_ID,
            wm_USER_CASE_LINE_NUMBER_ID: this.getParentLineCMLId(eachRow.wm_PARENT_CASE_ID, eachRow.wm_PARENT_CASE_MASTER_LINE_ID),
            wm_USER_CASE_SUBLINE_TX: eachRow.wm_USER_CASE_SUBLINE_TX,
            wm_PARENT_CASE_ID: eachRow.wm_PARENT_CASE_ID,
            wm_PARENT_CASE_MASTER_LINE_ID: eachRow.wm_PARENT_CASE_MASTER_LINE_ID,
          }
          // Adding Subline
          this.theCaseLineListArray.push(caseMasterlineDtoObject);
        }
      })
      this.theCaseLineListArray.sort(this.GetSortNumberOrder("wm_USER_CASE_LINE_NUMBER_ID"));
    });
  }

  ngOnDestroy() {
    //clear out the selected case line entity 
    this.caseUIService.setCaseLineInfoValues(this.caseLineInfoData);
    if (this._caseUIServiceSubscription1) {
      this._caseUIServiceSubscription1.unsubscribe();
      this._caseUIServiceSubscription1 = null;
    }
    if (this._caseUIServiceSubscription2) {
      this._caseUIServiceSubscription2.unsubscribe();
      this._caseUIServiceSubscription2 = null;
    }
    if (this._caseUIServiceSubscription3) {
      this._caseUIServiceSubscription3.unsubscribe();
      this._caseUIServiceSubscription3 = null;
    }
    if (this._caseUIServiceSubscription4) {
      this._caseUIServiceSubscription4.unsubscribe();
      this._caseUIServiceSubscription4 = null;
    }
    if (this.editSubscription) {
      this.editSubscription.unsubscribe();
      this.editSubscription = null;
    }
    if (this._refreshDataSubscription) {
      this._refreshDataSubscription.unsubscribe();
      this._refreshDataSubscription = null;
    }
    if (!!this._milestoneSubscription) {
      this._milestoneSubscription.unsubscribe();
      this._milestoneSubscription = null;
    }
    if (!!this._noteTypeSubscription) {
      this._noteTypeSubscription.unsubscribe();
      this._noteTypeSubscription = null;
    }
    if (!!this._noteListSubscription) {
      this._noteListSubscription.unsubscribe();
      this._noteListSubscription = null;
    }
    if (!!this._assocListPopupSubscription) {
      this._assocListPopupSubscription.unsubscribe();
      this._assocListPopupSubscription = null;
    }
    if (!!this._detailNavSubscription) {
      this._detailNavSubscription.unsubscribe();
      this._detailNavSubscription = null;
    }
    if (!!this._revertEditSubscription) {
      this._revertEditSubscription.unsubscribe();
      this._revertEditSubscription = null;
    }
    if (!!this._ucirSubscription) {
      this._ucirSubscription.unsubscribe();
      this._ucirSubscription = null;
    }
  
   
    this.clobberLockSessionId(0);
  }

  getCurrentLockSessionId(): number {
    const sessionLockSessionId: string = sessionStorage.getItem(DsamsConstants.SESSION_CASE_NOTE_DETAILS_LOCK_ID);
    return (!!sessionLockSessionId && sessionLockSessionId.length > 1) ? Number(sessionLockSessionId) : 0;
  }
  
  // Clobber Lock Session ID   
  private clobberLockSessionId(pNewLockSessionId: number) {
    if (this.getCurrentLockSessionId() > 0) {
      const sessionLockSessionId: string = sessionStorage.getItem(DsamsConstants.SESSION_CASE_NOTE_DETAILS_LOCK_ID);
      if (!!this.caseNoteEntity && this.caseNoteEntity.status != 1 && !!sessionLockSessionId && sessionLockSessionId != pNewLockSessionId.toString()) {
        this.dsamsRestfulService.closeLegacyLockSession(sessionLockSessionId).subscribe((pResult: any) => {
          sessionStorage.setItem(DsamsConstants.SESSION_CASE_NOTE_DETAILS_LOCK_ID, pNewLockSessionId.toString());
          this.checkReplaceButton();
          this.caseUIService.forceEditDisabledSubscription.next(false);
          this.isLoading.next(false);
        },
          err => {
            CaseUtils.ReportHTTPError(err, "Removing Note Lock");
          });
      }
      else if (pNewLockSessionId > 0) {
        sessionStorage.setItem(DsamsConstants.SESSION_CASE_NOTE_DETAILS_LOCK_ID, pNewLockSessionId.toString());
        this.checkReplaceButton();
        this.caseUIService.forceEditDisabledSubscription.next(false);
        this.isLoading.next(false);
      }
      else {
        this.caseUIService.forceEditDisabledSubscription.next(false);
        this.isLoading.next(false);
      }
    } else {
      sessionStorage.setItem(DsamsConstants.SESSION_CASE_NOTE_DETAILS_LOCK_ID, pNewLockSessionId.toString());
       this.isLoading.next(false);
    }
  }


  // Prepare before/after lists.
  private prepareBeforeAfterList() {
    if (!!this.caseNoteEntity && !!this.fullNoteList) {
      // Find the index of the case note we're currently on.
      let indexOfCurrentNote: number = 0;
      for (let currNote of this.fullNoteList) {
        if (this.caseNoteEntity.user_NOTE_NUMBER_ID == currNote.user_NOTE_NUMBER_ID) {
          break;
        }
        indexOfCurrentNote++;
      }
      this.currCaseNote = this.fullNoteList[indexOfCurrentNote];
      this.prevCaseNote = null;
      this.nextCaseNote = null;
      if (indexOfCurrentNote > 0) {
        this.prevCaseNote = this.fullNoteList[indexOfCurrentNote - 1];
      }
      if (indexOfCurrentNote < (this.fullNoteList.length - 1)) {
        this.nextCaseNote = this.fullNoteList[indexOfCurrentNote + 1];
      }
      // Get next User Note Number ID for new notes.
      if (this.caseNoteEntity.status == DsamsConstants.ENT_NEW) {
        if (!this.fullNoteList || this.fullNoteList.length == 0) {
          this.caseNoteEntity.user_NOTE_NUMBER_ID = 1;
        }
        else {
          this.caseNoteEntity.user_NOTE_NUMBER_ID = this.fullNoteList[this.fullNoteList.length - 1].user_NOTE_NUMBER_ID + 1;
        }
        this.txtNoteNumber = this.caseNoteEntity.user_NOTE_NUMBER_ID.toString();
      }
    }
  }

  private navigateToNote(pCaseNote: CaseNoteDto) {
    if (!!pCaseNote) {
      this.caseUIService.caseNoteSelected.next(pCaseNote);
      // Reset fields and buttons to false
      this.resetEdit();
    }
  }

  // Previous Note
  navigateToPrevNote() {
    this.navigateToNote(this.prevCaseNote);
  }

  // Next Note
  navigateToNextNote() {
    this.navigateToNote(this.nextCaseNote);
  }


  openAssoLinesDialog(): any {
    let assoLinesDialog = this.dialog.open(AssoLinesComponent, {
      width: '50em',
      height: '35em',
      data: {
        assoLineData: this.assoLinesDataList,
        caseLineRelatedInfoData: this.caseLineRelatedInfoData
      }
    });
    this._assocListPopupSubscription = assoLinesDialog.afterClosed().subscribe(resp => {
      if (resp != null && resp.data != null) {
        // Add selected associated lines from popup to the table
        resp.data.assoLines.forEach(row => {
          row.ent_status = DsamsConstants.ENT_NEW;
          this.assoLinesDataList.push(row);
        }
        )
        this.dataSourceAssoLines = new MatTableDataSource(this.assoLinesDataList);
        this.setChanged();
      }
    });
  }

  // Set note type from data
  setNoteTypeToSubscription() {
    this.caseUIService.setNoteType(this.noteType);
  }

  // Subscribe to edit service
  private subscribeToEditService() {
    if (this.caseNoteEntity != null && this.caseNoteEntity != undefined && !this.editSubscription) {
      this.editSubscription = this.caseUIService.caseEditServiceRegSub.subscribe((pEditResult: IEditResponseType) => {
        if (!!pEditResult && pEditResult.ID === DsamsConstants.NOTE_EDITOR) {
          this.caseUIService.forceEditDisabledSubscription.next(false);
            this.enableDisableFields(pEditResult.editToggle);
           
              if (pEditResult.editToggle && !this.isNewNoteEntity() && (!this._changesMade  || this.getCurrentLockSessionId() == 0) && (!sessionStorage.getItem(DsamsConstants.SESSION_CASE_NOTE_TAB) || sessionStorage.getItem(DsamsConstants.SESSION_CASE_NOTE_TAB) != DsamsConstants.PAGE_CASE_NOTE_LIST)) {
                this.populateCaseNoteFromDb(this.caseNoteEntity.case_ID, this.caseNoteEntity.case_VERSION_ID, this.caseNoteEntity.note_ID, this.caseNoteEntity.note_VERSION_ID, this.caseNoteEntity.case_NOTE_ID,true);
              }
        }
      });
    }
  }

  sendTabId() {
    //send new Line tab index as output
    if (!!this.caseNoteEntity && this.caseNoteEntity.status == DsamsConstants.ENT_NEW) {
      this.caseNoteEntity.status = DsamsConstants.ENT_RESTATED;
      this.sendNoteDetailsTabIndex.emit(0);
    }
  }

  // Subscribe to revert edit.
  subscribeToRevertEditSubscription() {
    if (!this._revertEditSubscription) {
      this._revertEditSubscription = this.caseUIService.revertEditService.subscribe((pEditResult: IEditResponseType) => {
        if (!!pEditResult &&  (pEditResult.ID == DsamsConstants.NOTE_EDITOR || pEditResult.ID == DsamsConstants.NOTE_LIST_EDITOR) && !pEditResult.editToggle) {
          // Set the note lock ID to 0, since it's already been removed.
          this.clobberLockSessionId(0);
          this.caseUIService.caseNoteSelected.next(this.currCaseNote);
        }
      });
    }
  }


  // Subscribe to case ui service for option Update Case In Review
  private subscribeToOptionCaseInReview() {
    if (!this._ucirSubscription) {
      this._ucirSubscription = this.caseUIService.optionSelectedUCIRRegSub.subscribe((value) => {
        // Set edit slider to on
        if (value) {
          const editResponse: IEditResponseType = {
            ID: DsamsConstants.NOTE_EDITOR,
            editToggle: true
          };
          this.caseUIService.caseEditService.next(editResponse);
          this.caseUIService.caseEditServiceRegSub.next(editResponse);
        }
      });
    }
  }

  // Subscribe to case ui service for option Pen and Ink
  private subscribeToOptionCasePenInk() {
    if (!this._penInkSubscription) {
      this._penInkSubscription = this.caseUIService.optionSelectedUCPIRegSub.subscribe((value) => {
        // Set edit slider to on
        if (value) {
          const editResponse: IEditResponseType = {
            ID: DsamsConstants.NOTE_EDITOR,
            editToggle: true
          };
          this.caseUIService.caseEditService.next(editResponse);
          this.caseUIService.caseEditServiceRegSub.next(editResponse);
        }
      });
    }
  }

  // Delete row from Associated Line Table
  delAssoLineRow(rowElement: any) {
    let rowIndex = this.assoLinesDataList.indexOf(rowElement);
    this.assoLinesDataList[rowIndex].ent_status = DsamsConstants.ENT_DELETED;
    this.theDeletedAssoLinesDataList.push(this.assoLinesDataList[rowIndex]);
    this.assoLinesDataList.splice(rowIndex, 1);
    this.dataSourceAssoLines = new MatTableDataSource(this.assoLinesDataList);
    this.setChanged();
  }

  /* This procedure checks the returned result value from the 
     popover Yes/No dialog window. */
  yesButtonAssoLineDeleteOnClick(isDeleteConfirmed: any, rowElement: any) {
    if (isDeleteConfirmed)
      this.delAssoLineRow(rowElement);
  }

  // Populate the case note from the database.
  // Indicate if we should lock too.
  private populateCaseNoteFromDb(pCaseId: number, pCaseVersionId: number, pNoteId: number, pNoteVersionId: number, pCaseNoteId: number, pLock: boolean) {
    this.isLoading.next(true);
    //DH - Jira 2946
    /* *** Do not need drop downs for existing note
    if (this.theCaseLineListArray === undefined || this.theCaseLineListArray.length == 0) {
      this.getLineSublineDropdownList(pCaseId);
      //console.log("Populating dropdown from populateCaseNoteFromDb");
    }*/

    this.caseRestService.getCaseNote(pCaseId, pCaseVersionId, pNoteId, pNoteVersionId, pCaseNoteId, pLock)
      .subscribe((pCaseNoteFromDatabase: ICaseNote) => {
        this.caseNoteEntity = pCaseNoteFromDatabase;
        this.caseNoteEntity.status = DsamsConstants.ENT_UNCHANGED;
        if (!!this.caseNoteEntity.caseLineNoteRelatedNoteIdList && !!this.caseNoteEntity.caseLineNoteRelatedNoteIdList[0]) {
          if (!!this.caseNoteEntity.caseLineNoteRelatedNoteIdList[0].theCaseLine.theCaseMasterLineId) {
            this.txtLineNumber = this.caseNoteEntity.caseLineNoteRelatedNoteIdList[0].theCaseLine.theCaseMasterLineId.user_CASE_LINE_NUMBER_ID;
            this.txtSublineNumber = this.caseNoteEntity.caseLineNoteRelatedNoteIdList[0].theCaseLine.theCaseMasterLineId.user_CASE_SUBLINE_TX;
          }
        }
        else {
          this.txtLineNumber = '';
          this.txtSublineNumber = '';
        }
        this.prepareBeforeAfterList();
        // Set Note attributes from rest api db call
        this.setNoteAttributes();
        this.caseUIService.caseNotePopulated.next(this.caseNoteEntity);
        // Edit subscription if it did not get setup in init
        this.subscribeToEditService();
        // Clobber the previous lock ID if it's different.
        if (this.caseNoteEntity.lockSessionId.toString() != sessionStorage.getItem(DsamsConstants.SESSION_CASE_NOTE_DETAILS_LOCK_ID) ) {
          this.clobberLockSessionId(this.caseNoteEntity.lockSessionId);
        }
        else {
          // Check if Replace button should be enabled in view mode
          this.checkReplaceButton();
          this.isLoading.next(false);
          this.caseUIService.forceEditDisabledSubscription.next(false);
        }
     },
        err => {
          if (pLock) {
            CaseUtils.ReportHTTPError(err, "locking case note");
            this.caseUIService.flipToDisabledService.next(DsamsConstants.NOTE_EDITOR);
            this.enableDisableFields(false);
          }
          else {
            CaseUtils.ReportHTTPError(err, "Fetching Case Note (existing)");
          }
          this.isLoading.next(false);
          this.caseUIService.forceEditDisabledSubscription.next(false);
        });
  }


  // Fetch note
  fetchNote() {
    // Fetch Case Note Info from database.
    if (!this._caseUIServiceSubscription4) {
      this._caseUIServiceSubscription4 = this.caseUIService.caseNoteSelected.subscribe((pSelectedNote: CaseNoteDto) => {
        if (!!pSelectedNote) {
          this.isNoteDetailsPanelEditable = (pSelectedNote.status == 'NEW');
          if (this.isNoteDetailsPanelEditable) {
            this.caseUIService.flipToEnabledService.next(DsamsConstants.NOTE_EDITOR);
          }
          this.isLoading.next(true);
          if (pSelectedNote.status != 'NEW') {
            // Reset Line number
            this.txtLineNumber = '';
            this.txtSublineNumber = '';
            this.populateCaseNoteFromDb(pSelectedNote.case_ID, pSelectedNote.case_VERSION_ID, pSelectedNote.note_ID, pSelectedNote.note_VERSION_ID, pSelectedNote.case_NOTE_ID, false);
            this.turnEditOff();
          }
          // ******************  New Note  ************************************
          else {  // New Note - query from database for note
            // New Standard Note or Reference Customizable
            if (pSelectedNote.theNoteId.note_TYPE_CD == DsamsConstants.NOTE_TYPE_STANDARD ||
              pSelectedNote.theNoteId.note_TYPE_CD == DsamsConstants.NOTE_TYPE_CUSTOMIZABLE) {
              this.caseRestService.getNote(pSelectedNote.note_ID, pSelectedNote.note_VERSION_ID)
                .subscribe((pNoteFromDatabase: INote) => {
                  this.caseNoteEntity = {
                    status: DsamsConstants.ENT_NEW,
                    case_ID: pSelectedNote.case_ID,
                    case_VERSION_ID: pSelectedNote.case_VERSION_ID,
                    note_ID: pSelectedNote.note_ID,
                    note_VERSION_ID: pSelectedNote.note_VERSION_ID,
                    case_NOTE_ID: pSelectedNote.case_NOTE_ID,
                    change_ACTION_CD: "A",
                    theChangeActionCd: {
                      change_ACTION_CD: "A",
                      change_ACTION_TITLE_NM: "Added"
                    },
                    ipc_CATEGORY_CD: "",
                    theNoteId: pNoteFromDatabase,
                    caseLineNoteRelatedNoteIdList: [{ status: DsamsConstants.ENT_NEW }],
                    caseNoteParameterList: []
                  };

                  // Copy over the case note parameter from note parameter.
                  if (!!this.caseNoteEntity.theNoteId.noteParameterList) {
                    this.caseNoteEntity.theNoteId.noteParameterList.forEach(eachNoteParameter => {
                      this.caseNoteEntity.caseNoteParameterList.push({
                        status: DsamsConstants.ENT_NEW,
                        case_ID: pSelectedNote.case_ID,
                        case_VERSION_ID: pSelectedNote.case_VERSION_ID,
                        note_ID: pSelectedNote.note_ID,
                        note_VERSION_ID: pSelectedNote.note_VERSION_ID,
                        case_NOTE_ID: pSelectedNote.case_NOTE_ID,
                        case_NOTE_PARAMETER_ID: 0,
                        case_NOTE_PARAMETER_TX: "",
                        prompting_NOTE_ID: eachNoteParameter.note_ID,
                        prompting_NOTE_PARAMETER_ID: eachNoteParameter.note_PARAMETER_ID,
                        prompting_NOTE_VERSION_ID: eachNoteParameter.note_VERSION_ID,
                        thePromptingNoteParameterId: eachNoteParameter
                      });
                    });
                  }
                  this.prepareBeforeAfterList();
                  this.setNoteAttributes();
                  this.caseUIService.caseNotePopulated.next(this.caseNoteEntity);
                  this.turnEditOn();
                  // Edit subscription if it did not get setup in init
                  this.subscribeToEditService();
                  this.caseNoteEntity.status = pSelectedNote.ent_status;
                  this.setChanged();
                  this.isLoading.next(false);
                },
                  err => {
                    CaseUtils.ReportHTTPError(err, "Fetching Case Note (new)");
                    this.isLoading.next(false);
                  });
            }

            // New Unique Note
            else if (pSelectedNote.theNoteId.note_TYPE_CD == DsamsConstants.NOTE_TYPE_UNIQUE) {
              this.prepareNote(DsamsConstants.NOTE_TYPE_UNIQUE, pSelectedNote);
              this.prepareBeforeAfterList();
              this.setNoteAttributes();
              this.caseUIService.caseNotePopulated.next(this.caseNoteEntity);
              this.turnEditOn();
              // Edit subscription if it did not get setup in init
              this.subscribeToEditService();
              this.isNoteOfficialTitleEditable = true;
              this.caseNoteEntity.status = pSelectedNote.ent_status;
              this.setChanged();
              this.isLoading.next(false);
            }

            // New Line Item Note
            else if (pSelectedNote.theNoteId.note_TYPE_CD == DsamsConstants.NOTE_TYPE_LINE_ITEM) {
              this.prepareNote(DsamsConstants.NOTE_TYPE_LINE_ITEM, pSelectedNote);
              this.prepareBeforeAfterList();
              this.setNoteAttributes();
              this.caseUIService.caseNotePopulated.next(this.caseNoteEntity);
              this.turnEditOn();
              // Edit subscription if it did not get setup in init
              this.subscribeToEditService();
              // Populate line drop downs
              this.theCaseLineListArray = [];
              this.getLineDropdownList(pSelectedNote.case_ID, pSelectedNote.case_VERSION_ID);
              // Enable Line dropdowns and official title
              this.isNoteDetailsLineEditable = true;
              this.isNoteOfficialTitleEditable = true;
              // Reset Line number
              this.txtLineNumber = '';
              this.txtSublineNumber = '';
              this.caseNoteEntity.status = pSelectedNote.ent_status;
              this.setChanged();
              this.isLoading.next(false);
             }
          }
        }
      });
    }
  }


  // Set Note Attributes from Data Model Object
  setNoteAttributes() {
    // Set Note Type
    this.noteType = this.caseNoteEntity.theNoteId.theNoteTypeCd.note_TYPE_DESCRIPTION_TX;

    // Set Note Type for Customizable from Menu
    if (this.noteType == 'Reference Customizable') {
      this.noteType = 'Customizable';
      this.isNoteOfficialTitleEditable = false;
    }
    if (this.noteType == this.NOTE_TYPE_STANDARD)
      this.isNoteOfficialTitleEditable = false;

    this.setNoteTypeToSubscription();

    // Reset fill-ins
    this.fillInsDataList = null;
    this.fillInsDataList = [];
    this.dataSourceFillIns = new MatTableDataSource(this.fillInsDataList);

    // Reset asso lines
    this.assoLinesDataList = [];
    this.dataSourceAssoLines = new MatTableDataSource(this.assoLinesDataList);

    this.txtNoteNumber = this.caseNoteEntity.user_NOTE_NUMBER_ID.toString();
    this.txtNoteId = this.caseNoteEntity.theNoteId.user_NOTE_ID;
    if (this.caseNoteEntity.theNoteId.note_VERSION_ID != null) {
      this.txtNoteVersion = this.caseNoteEntity.theNoteId.note_VERSION_ID.toString();
    }
    this.txtNoteStatus = this.caseNoteEntity.theChangeActionCd.change_ACTION_CD + ' - ' + this.caseNoteEntity.theChangeActionCd.change_ACTION_TITLE_NM;
    this.txtOfficialTitle = this.caseNoteEntity.theNoteId.official_NOTE_TITLE_TX;
    if (!!this.caseNoteEntity.caseLineNoteRelatedNoteIdList && !!this.caseNoteEntity.caseLineNoteRelatedNoteIdList[0]) {
      if (!!this.caseNoteEntity.caseLineNoteRelatedNoteIdList[0].theCaseLine &&
        !!this.caseNoteEntity.caseLineNoteRelatedNoteIdList[0].theCaseLine.theCaseMasterLineId) {
        this.txtLineNumber = this.caseNoteEntity.caseLineNoteRelatedNoteIdList[0].theCaseLine.theCaseMasterLineId.user_CASE_LINE_NUMBER_ID;
        this.txtSublineNumber = this.caseNoteEntity.caseLineNoteRelatedNoteIdList[0].theCaseLine.theCaseMasterLineId.user_CASE_SUBLINE_TX;
      }
    }
    else {
      this.txtLineNumber = '';
      this.txtSublineNumber = '';
    }
    if (this.caseNoteEntity.theNoteId.noteContentList != null) {
      this.txtNoteText = this.caseNoteEntity.theNoteId.noteContentList[0].note_TX;
    }
    else this.txtNoteText = '';
    this.ipcCategoryCd = this.caseNoteEntity.ipc_CATEGORY_CD;

    // Fill ins
    if (this.caseNoteEntity.caseNoteParameterList != null) {
      for (var i = 0; i <= this.caseNoteEntity.caseNoteParameterList.length - 1; i++) {
        if (this.caseNoteEntity.caseNoteParameterList[i].status != DsamsConstants.ENT_DELETED) {
          let item: fillIns = { name: '', prompt: '', value: '' };
          //console.log("row: " + JSON.stringify(this.caseNoteEntity.caseNoteParameterList[i]));
          item.name = this.caseNoteEntity.caseNoteParameterList[i].thePromptingNoteParameterId.note_FILL_IN_NM;
          item.prompt = this.caseNoteEntity.caseNoteParameterList[i].thePromptingNoteParameterId.note_FILL_IN_PROMPT_TX;
          item.value = this.caseNoteEntity.caseNoteParameterList[i].case_NOTE_PARAMETER_TX;
          item.theICaseNoteParameter = {
            case_ID: this.caseNoteEntity.caseNoteParameterList[i].case_ID,
            case_VERSION_ID: this.caseNoteEntity.caseNoteParameterList[i].case_VERSION_ID,
            case_NOTE_ID: this.caseNoteEntity.caseNoteParameterList[i].case_NOTE_ID,
            case_NOTE_PARAMETER_ID: this.caseNoteEntity.caseNoteParameterList[i].case_NOTE_PARAMETER_ID,
            prompting_NOTE_ID: this.caseNoteEntity.caseNoteParameterList[i].prompting_NOTE_ID,
            prompting_NOTE_PARAMETER_ID: this.caseNoteEntity.caseNoteParameterList[i].prompting_NOTE_PARAMETER_ID,
            prompting_NOTE_VERSION_ID: this.caseNoteEntity.caseNoteParameterList[i].prompting_NOTE_VERSION_ID,
          }
          this.fillInsDataList.push(item);

          if (item.value != null && item.value != '') {
            // Token in the text
            var token = '{' + item.name + '}';

            // Regex token for all instances
            var re = new RegExp(token, 'g');

            // Replace the token with value
            this.txtNoteText = this.txtNoteText.replace(re, item.value);
          }
        }
      }
      // Sort Fill-Ins on Name
      this.fillInsDataList.sort(this.GetSortOrder("name"));
      this.dataSourceFillIns = new MatTableDataSource(this.fillInsDataList);
    }

    // Associated Lines
    let quantity: string;
    if (this.caseNoteEntity.caseLineNoteRelatedNoteIdList != null) {
      for (var j = 0; j <= this.caseNoteEntity.caseLineNoteRelatedNoteIdList.length - 1; j++) {
        if (this.caseNoteEntity.caseLineNoteRelatedNoteIdList[j].status != DsamsConstants.ENT_DELETED) {
          let item: iAssoLines = {
            lineNum: '', status: '', masl: '', maslDesc: '', quantity: null, issue: '',
            ent_status: DsamsConstants.ENT_UNCHANGED,
          };
          quantity = '';
          if (!!this.caseNoteEntity.caseLineNoteRelatedNoteIdList[j].theCaseLine) {
            item.lineNum = this.caseNoteEntity.caseLineNoteRelatedNoteIdList[j].theCaseLine.wm_USER_CASE_LINE_NUMBER_ID;
            item.status = this.caseNoteEntity.caseLineNoteRelatedNoteIdList[j].theCaseLine.change_ACTION_CD;
            if (!!this.caseNoteEntity.caseLineNoteRelatedNoteIdList[j].theCaseLine.theMilitaryArticleServiceCd) {
              item.masl = this.caseNoteEntity.caseLineNoteRelatedNoteIdList[j].theCaseLine.theMilitaryArticleServiceCd.military_ARTICLE_SERVICE_CD;
              item.maslDesc = this.caseNoteEntity.caseLineNoteRelatedNoteIdList[j].theCaseLine.theMilitaryArticleServiceCd.article_DESCRIPTION_TX;
            }
            if (this.caseNoteEntity.caseLineNoteRelatedNoteIdList[j].theCaseLine.case_LINE_ITEM_QY != null &&
              this.caseNoteEntity.caseLineNoteRelatedNoteIdList[j].theCaseLine.case_LINE_ITEM_QY != '' &&
              this.caseNoteEntity.caseLineNoteRelatedNoteIdList[j].theCaseLine.case_LINE_ITEM_QY != '0' &&
              this.caseNoteEntity.caseLineNoteRelatedNoteIdList[j].theCaseLine.case_LINE_ITEM_QY != '0.0') {
              quantity = parseInt(this.caseNoteEntity.caseLineNoteRelatedNoteIdList[j].theCaseLine.case_LINE_ITEM_QY).toString();
            }
            item.quantity = quantity;
            item.issue = this.caseNoteEntity.caseLineNoteRelatedNoteIdList[j].theCaseLine.issue_UNIT_CD;
            item.caseId = this.caseNoteEntity.caseLineNoteRelatedNoteIdList[j].theCaseLine.case_ID;
            item.caseMasterLineId = this.caseNoteEntity.caseLineNoteRelatedNoteIdList[j].theCaseLine.case_MASTER_LINE_ID;
          }
          item.caseVersionId = this.caseNoteEntity.case_VERSION_ID;
          this.assoLinesDataList.push(item);
        }
      }
      this.dataSourceAssoLines = new MatTableDataSource(this.assoLinesDataList);
    }
  }

  GetSortOrder(prop: any) {
    return function (a: any, b: any) {
      if (a[prop] > b[prop]) {
        return 1;
      } else if (a[prop] < b[prop]) {
        return -1;
      }
      return 0;
    }
  }

  GetSortNumberOrder(prop: any) {
    return function (a: any, b: any) {
      if (parseInt(a[prop]) > parseInt(b[prop])) {
        return 1;
      } else if (parseInt(a[prop]) < parseInt(b[prop])) {
        return -1;
      }
      return 0;
    }
  }

  // Update fill-in value on user input
  onChangeFillInValue(pElement: any) {
    // Reset fill-ins
    let fillInsDataListChanged: fillIns[] = [];

    if (this.caseNoteEntity.theNoteId.noteContentList != null) {
      this.txtNoteText = this.caseNoteEntity.theNoteId.noteContentList[0].note_TX;
    }

    for (let i = 0; i <= this.fillInsDataList.length - 1; i++) {
      let item: fillIns = { name: '', prompt: '', value: '' };

      item.name = this.fillInsDataList[i].name;
      item.prompt = this.fillInsDataList[i].prompt;
      item.value = this.fillInsDataList[i].value;
      //copy primary keys and data 
      item.theICaseNoteParameter = this.fillInsDataList[i].theICaseNoteParameter;
      item.theICaseNoteParameter.case_NOTE_PARAMETER_TX = item.value;
      //always a changed entity
      item.theICaseNoteParameter.status = DsamsConstants.ENT_CHANGED;

      // Token in the text
      let token = '{' + item.name + '}';

      // Regex token for all instances
      let re = new RegExp(token, 'g');

      // Replace the token with value
      if (item.value != null && item.value != '') {
        this.txtNoteText = this.txtNoteText.replace(re, item.value);
      }
      fillInsDataListChanged.push(item);
    }
    this.fillInsDataList = fillInsDataListChanged;
    this.dataSourceFillIns = new MatTableDataSource(this.fillInsDataList);
    this.setChanged();
  }

  // Reset Editability
  resetEdit() {
    //console.log("Inside resetEdit");
    this.isNoteDetailsPanelEditable = false;
    this.isNoteOfficialTitleEditable = false;
    this.isBelowLineCategoryEditable = false;
    this.isNoteTextEditable = false;
    this.isRestateButtonEditable = false;
    this.isRefreshButtonEditable = false;
    this.isReplaceButtonEditable = false;
    this.isDeleteButtonEditable = false;
    this.isNoteDetailsLineEditable = false;
  }

  // Subscription to when user switches from note list to note details
  private subscribeToOtherServices() {
    this._detailNavSubscription = this.caseUIService.noteDetailNav.subscribe((pEditToggle: boolean) => {
      // Make sure edit is off
      if (this.caseNoteEntity != null && this.caseNoteEntity.status == DsamsConstants.ENT_NEW) {
        this.turnEditOn();
      } else {
        this.turnEditOff();
      }
    });
  }

  // Mark the record as changed so we know to tell the user.
  setChanged() {
    this._changesMade = true;
    if (this.caseNoteEntity.status !== DsamsConstants.ENT_NEW &&
      this.caseNoteEntity.status !== DsamsConstants.ENT_DELETED) {
      this.caseNoteEntity.status = DsamsConstants.ENT_CHANGED;
    }
    this.caseUIService.hasEditBeenMadeService.next({ ID: DsamsConstants.NOTE_EDITOR, editToggle: true });
  }

  // Mark the record as unchanged.
  setUnchanged() {
    this._changesMade = false;
    this.caseUIService.hasEditBeenMadeService.next({ ID: DsamsConstants.NOTE_EDITOR, editToggle: false });
  }

  //Mark note record
  setNoteOfficialTitleChanged() {
    this.setChanged();
    this.caseNoteEntity.theNoteId.official_NOTE_TITLE_TX = this.txtOfficialTitle;
    this.caseNoteEntity.theNoteId.status = DsamsConstants.ENT_CHANGED;
  }

  //Mark Note Text record
  setNoteTextChanged() {
    this.setChanged();
    if (!!this.caseNoteEntity.theNoteId.noteContentList &&
      this.caseNoteEntity.theNoteId.noteContentList.length > 0) {
      this.caseNoteEntity.theNoteId.noteContentList[0].status = DsamsConstants.ENT_CHANGED;
    }
  }

  //this dropw down is only enabled in NEW mode
  setLineSublineChanged(pValue: any) {
    this.setChanged();
    this.txtLineNumber = pValue;
    let aLineEntity: caseMasterlineDto;
    this.theCaseLineListArray.forEach(eachRow => {
      if (eachRow.wm_USER_CASE_LINE_NUMBER_ID == this.txtLineNumber) {
        aLineEntity = eachRow;
      }
    })
    if (!!this.caseNoteEntity.caseLineNoteRelatedNoteIdList) {
      this.caseNoteEntity.caseLineNoteRelatedNoteIdList[0] = {
        case_ID: aLineEntity.case_ID,
        case_MASTER_LINE_ID: aLineEntity.case_MASTER_LINE_ID,
        working_CASE_VERSION_ID: this.caseNoteEntity.case_VERSION_ID,
        working_CASE_ID: aLineEntity.case_ID,
        related_CASE_ID: aLineEntity.case_ID,
        related_CASE_VERSION_ID: this.caseNoteEntity.case_VERSION_ID,
        status: DsamsConstants.ENT_NEW,
      }
    }
  }

  // Ensure that edit is off - Todo: Check if alternate method is working - If so, remove
  private makeSureEditToggleIsOff() {
      this._editToggleState = false;
    this.caseUIService.flipToDisabledService.next(DsamsConstants.NOTE_EDITOR);
    this.enableDisableFields(false);
  }


  // Turn on Edit
  private turnEditOn() {
    this.caseUIService.caseEditService.next(    {
          ID: DsamsConstants.NOTE_EDITOR,
          editToggle: true
        }
      );
  }

  // Turn off Edit
  private turnEditOff() {
       this.caseUIService.caseEditService.next(
        {
          ID: DsamsConstants.NOTE_EDITOR,
          editToggle: false
        }
      );

  }

  enableDisableFields(pEditToggle: boolean) {
    this._editToggleState = pEditToggle;
    if (pEditToggle) {
      this.caseUIService.flipToEnabledService.next(DsamsConstants.NOTE_EDITOR)
    } else {
      this.caseUIService.flipToDisabledService.next(DsamsConstants.NOTE_EDITOR)
    }
    this.isNoteDetailsPanelEditable = pEditToggle;
    //console.log("Inside enableDisableFeilds pEdittoggle is: " + pEditToggle);

    // Restate Button
    if (this.caseNoteEntity != null
      && this.caseNoteEntity != undefined
      && this.caseNoteEntity.theChangeActionCd.change_ACTION_CD != 'R'
      && this.caseNoteEntity.theChangeActionCd.change_ACTION_CD != 'A') {

      this.isRestateButtonEditable = pEditToggle;
    }

    // Refresh Button
    if (this.caseNoteEntity != null
      && this.caseNoteEntity != undefined
      && this.caseNoteEntity.theChangeActionCd.change_ACTION_CD != 'U'
      && this.caseNoteEntity.theChangeActionCd.change_ACTION_CD != 'A') {

      this.isRefreshButtonEditable = pEditToggle;
    }

    // Delete Button
    if (this.caseNoteEntity != null
      && this.caseNoteEntity != undefined
      && this.caseNoteEntity.theChangeActionCd.change_ACTION_CD != 'D') {

      this.isDeleteButtonEditable = pEditToggle;
    }

    this.checkReplaceButton();

    // Standard

    // Customizable

    // Unique
    if (this.noteType == DsamsConstants.NOTE_TYPE_UNIQUE) {
      this.isNoteOfficialTitleEditable = pEditToggle;
    }

    // Line/Subline
    if (this.noteType == DsamsConstants.NOTE_TYPE_LINE_ITEM) {
      this.isNoteOfficialTitleEditable = pEditToggle;
    }
  }

  checkReplaceButton() {
    if (this.caseNoteEntity != null && this.caseNoteEntity != undefined) {
      // Replace Button
      //console.log("Check replace button ", this);

      let enableRev: boolean = false;

      let isLease: boolean = false;

      if (!!this.caseNoteEntity.theCaseVersionId && 
          !!this.caseNoteEntity.theCaseVersionId.theCaseId &&
         this.caseNoteEntity.theCaseVersionId.theCaseId.theSecurityAssistanceProgramCd != null && this.caseNoteEntity.theCaseVersionId.theCaseId.theSecurityAssistanceProgramCd.security_ASSISTANCE_PROGRAM_CD == "LEASE") {
        isLease = true;
      }

      //console.log("CaseUtils.isLTSysdate(this.caseNoteEntity.theNoteId.wm_NOTE_EXPIRATION_DT_STR is " + CaseUtils.isLTSysdate(this.caseNoteEntity.theNoteId.wm_NOTE_EXPIRATION_DT_STR));

      // Toggle fields for REV button (refresh expired version)
      // * Enable in view mode when selected note is a standard reference note (note type "ST") and its expiration date is before current system date.
      // * Disabled always for leases.
      // * Disable this button/function if the current highlighted Note Change Action Code is equal to deleted (D). 
      // * Do not allow edit mode if the note.note_input_responsibility_cd = ‘CWD’ and the case_version.case_version_status_cd <> ‘W’ or ‘R’
      // If any of the case notes are editable, then enable the REV button, otherwise disable.   
      if ((CaseUtils.isLTSysdate(this.caseNoteEntity.theNoteId.wm_NOTE_EXPIRATION_DT_STR)) &&
        (this.caseNoteEntity.theNoteId.note_TYPE_CD == "ST") &&
        (this.caseNoteEntity.change_ACTION_CD != "D") &&
        (!isLease) &&
        (!this.isNoteDetailsPanelEditable)   // Disable in edit mode, only view mode.
      ) {
        enableRev = true;
        //console.log("replace button should be enabled.");
      }
      this.isReplaceButtonEditable = enableRev;
    }
  }

  // ************************** Delete the case note *********************************

  deleteCaseNotePrompt() {
    if (this.canDeleteCaseNote()) {
      // Prompt the user to delete
      MessageMgr.swalFire({
        text: 'Are you sure you want to delete this Case Note?',
        icon: 'warning',
        width: 300,
        showCancelButton: true,
        cancelButtonText: 'No',
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes',
      }).then((result) => {
        if (result.value) {
          this.deleteCaseNote();
        }
      });
    }
    else {
      MessageMgr.displaySinglePopupError("E205");
    }
  }


  // Determine if we can delete case note.
  private canDeleteCaseNote(): boolean {
    // Modelled on dsams-core.CaseNoteWin.deleteWindowData
    const caseVersionStatusCd: string = this.caseNoteEntity.theCaseVersionId.case_VERSION_STATUS_CD;
    if (!this.caseNoteEntity.wm_CASE_WRITING_IN && (caseVersionStatusCd == "W" || caseVersionStatusCd == "R")) {
      return false;
    }
    return true;
  }

  // Determine if the user can refresh the case note
  private canRefreshCaseNote(): boolean {
    const caseVersionStatusCd: string = this.caseNoteEntity.theCaseVersionId.case_VERSION_STATUS_CD;
    if (!this.caseNoteEntity.wm_CASE_WRITING_IN && caseVersionStatusCd == "W") {
      return false;
    }
    return true;
  }

  // Actual delete
  private deleteCaseNote() {
    // Modelled on dsams-core.CaseNoteWin.deleteWindowData
    // Determine if we're doing a real delete or logical delete.
    const caseVersionStatusCd: string = this.caseNoteEntity.theCaseVersionId.case_VERSION_STATUS_CD;
    const caseVersionTypeCd: string = this.caseNoteEntity.theCaseVersionId.case_VERSION_TYPE_CD;
    let isRealDelete: boolean = false;
    if (this.caseNoteEntity.change_ACTION_CD == "A" &&
      (caseVersionStatusCd == "D" || caseVersionStatusCd == "W" || caseVersionStatusCd == "R") &&
      (caseVersionTypeCd == "B" || caseVersionTypeCd == "A" || caseVersionTypeCd == "M")
    ) {
      // Physical delete.
      this.caseNoteEntity.status = DsamsConstants.ENT_DELETED;
      isRealDelete = true;
    }
    else {
      // Logical delete.
      this.caseNoteEntity.change_ACTION_CD = NoteUtils.changeCaseNoteStatus(this.caseNoteEntity.change_ACTION_CD, "D");
      this.caseNoteEntity.theNoteId.status = DsamsConstants.ENT_UNCHANGED;
      this.caseNoteEntity.status = DsamsConstants.ENT_CHANGED;
    }

    this.isLoading.next(true);
    this.caseRestService.saveCaseNote(this.caseNoteEntity).subscribe((pReturnedCaseNote: ICaseNote) => {
      this.caseNoteEntity = { ...pReturnedCaseNote, status: DsamsConstants.ENT_UNCHANGED };
      MessageMgr.swalFire({
        text: isRealDelete ? "Case Note deleted." : "Case Note logically deleted.",
        icon: 'success',
        width: 300,
        showCancelButton: false,
        confirmButtonColor: '#3085d6',
        confirmButtonText: 'OK',
      });
      this.isLoading.next(false);
      if (isRealDelete) {
        // Navigate to note list (like if we do a real delete).
        this.caseUIService.autoNavigateToNoteList.next();
      }
      else {
        // Staying on this screen.
        this.isLoading.next(false);
        this.postSave();
      }
    },
      err => {
        CaseUtils.ReportHTTPError(err, "Saving Case Note for Delete");
        this.isLoading.next(false);
      });
  }

  /********************* Restate Button Note************************/
  onClickRestate() {
    const caseVersionStatusCd: string = this.caseNoteEntity.theCaseVersionId.case_VERSION_STATUS_CD;
    if (caseVersionStatusCd !== 'R' && caseVersionStatusCd !== 'W') {
      if (this.caseNoteEntity.change_ACTION_CD === 'C') {
        MessageMgr.swalFire({
          text: 'The note was changed previously. ' + 'If reinstates, the note will be marked as restated ' +
            'although the changes will ' +
            'remain with the %1.  Do you want to proceed?',
          icon: 'warning',
          width: 300,
          showCancelButton: true,
          cancelButtonText: 'No',
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: 'Yes',
        }).then((result) => {
          if (result.value) {
            this.changeToR();
            this.subscribeToEditService();
          }
        });
      } else {
        this.changeToR();
        this.subscribeToEditService();
      }
    } else if (this.caseNoteEntity.wm_CASE_WRITING_IN === true) {
      this.changeToR();
      this.subscribeToEditService();
    } else {
      MessageMgr.swalFire({
        text: 'The selected function is not available due to the status of the selected case',
        icon: 'error',
        width: 300,
        showCancelButton: false,
        confirmButtonColor: '#3085d6',
        confirmButtonText: 'Ok'
      });
    }
  }

  private changeToR() {
    this.caseNoteEntity.theChangeActionCd.change_ACTION_CD = 'R';
    this.txtNoteStatus = 'R - Restated';
    this.isRestateButtonEditable = false;
    this.setChanged();
  }

  /** 
   * check edit abitlity before replacing the Expired Version
   */
  onClickReplaceExpiredVersion() {
    this.isLoading.next(true);
    // Check editability after we click but before we run REV.
    this.caseRestService.getCaseNoteEditability(this.caseNoteEntity)
      .subscribe((editResult: IEditResultsType) => {
        if (!!editResult) {
          if (editResult.canEdit) {
            // If editable, call REV.
            this.doReplaceExpiredVersion();
          }
          else {
            // If not, show error
            MessageMgr.swalFire({
              html: MessageMgr.getMesssage(editResult.errorMessage).messageText,
              icon: 'error',
              showConfirmButton: true,
              width: 400,
              focusConfirm: true,
              confirmButtonText: 'OK'
            });
            this.isLoading.next(false);
          }
        }
      });
  }

  /** 
    * Replaced Expire Version function
    * @Author: David Huynh
    * @Date: 10/22/2021
    * @Jira Card: 4405
    */
  private doReplaceExpiredVersion() {
    var originalNoteversion: number = this.caseNoteEntity.note_VERSION_ID;
    const noLatestVersionMsg: string = "No newer version of the selected case reference note exists. Replace failed."
    const msgTimer: number = 2500;
    this.caseRestService.getLatestCaseNoteVersionDto(this.caseNoteEntity).subscribe(latestNoteVersion => {
      this.caseNoteEntity = latestNoteVersion;
      if (!!this.caseNoteEntity && !!this.caseNoteEntity.theNoteId) {
        this.caseNoteEntity.note_ID = this.caseNoteEntity.theNoteId.note_ID;
        this.caseNoteEntity.note_VERSION_ID = this.caseNoteEntity.theNoteId.note_VERSION_ID;
        this.caseNoteEntity.status = DsamsConstants.ENT_CHANGED;
        this.setNoteAttributes();
        if (originalNoteversion != this.caseNoteEntity.note_VERSION_ID)
          MessageMgr.displayInfoWithTimer("Note replaced successfully.", 1500);
        else MessageMgr.displayInfoWithTimer(noLatestVersionMsg, msgTimer);
      }
      else MessageMgr.displayInfoWithTimer(noLatestVersionMsg, msgTimer);
      this.isLoading.next(false);
    },
      err => {
        MessageMgr.displayInfoWithTimer(noLatestVersionMsg, msgTimer);
        this.isLoading.next(false);
      });
  }

  /**
   * Refresh Case Version
   */
  onClickRefresh() {
    if (this.canRefreshCaseNote()) {
      this.isLoading.next(true);
      this.caseRestService.refreshCaseNoteForDetail(this.caseNoteEntity.case_ID, this.caseNoteEntity.user_NOTE_NUMBER_ID).subscribe((pRefreshedCaseNote: ICaseNote) => {
        if (!pRefreshedCaseNote) {
          MessageMgr.swalFire({
            text: 'The corresponding Case Note for the Implemented Case Version does not exist.',
            icon: 'error',
            width: 300,
            showCancelButton: false,
            confirmButtonColor: '#3085d6',
            confirmButtonText: 'Ok'
          });
        }
        else {
          const originalNoteObj: INote = JSON.parse(JSON.stringify(this.caseNoteEntity.theNoteId));
          this.caseNoteEntity = {
            ... this.caseNoteEntity,
            change_ACTION_CD: "U",
            theChangeActionCd: {
              change_ACTION_CD: "U",
              change_ACTION_TITLE_NM: "Unaffected"
            },
            theNoteId: JSON.parse(JSON.stringify(pRefreshedCaseNote.theNoteId)),
            ipc_CATEGORY_CD: pRefreshedCaseNote.ipc_CATEGORY_CD,
            status: DsamsConstants.ENT_CHANGED
          };
          // *** Unique note ***
          if (this.caseNoteEntity.theNoteId.note_TYPE_CD == "CU") {
            this.caseNoteEntity.theNoteId.status = DsamsConstants.ENT_NEW;
            // Copy over note_content to new note.
            this.caseNoteEntity.theNoteId.noteContentList = [];
            if (!!pRefreshedCaseNote.theNoteId.noteContentList) {
              pRefreshedCaseNote.theNoteId.noteContentList.forEach(eachNc => {
                this.caseNoteEntity.theNoteId.noteContentList.push(
                  {
                    ...eachNc,
                    status: DsamsConstants.ENT_NEW
                  });
              });
            }
            // Copy over note parameter list.
            this.caseNoteEntity.theNoteId.noteParameterList = [];
            if (!!pRefreshedCaseNote.theNoteId.noteParameterList) {
              pRefreshedCaseNote.theNoteId.noteParameterList.forEach(eachNp => {
                this.caseNoteEntity.theNoteId.noteParameterList.push(
                  {
                    ...eachNp,
                    status: DsamsConstants.ENT_NEW
                  });
              });
            }
          }
          // *** Non-unique note ***
          else {
            this.caseNoteEntity.theNoteId.status = DsamsConstants.ENT_CHANGED;
            this.caseNoteEntity.note_ID = originalNoteObj.note_ID;
            this.caseNoteEntity.note_VERSION_ID = originalNoteObj.note_VERSION_ID;
            this.caseNoteEntity.theNoteId.note_ID = originalNoteObj.note_ID;
            this.caseNoteEntity.theNoteId.note_VERSION_ID = originalNoteObj.note_VERSION_ID;
            // Note Content List
            if (!!this.caseNoteEntity.theNoteId.noteContentList) {
              this.caseNoteEntity.theNoteId.noteContentList.forEach(eachNc => {
                eachNc.status = DsamsConstants.ENT_CHANGED;
                eachNc.note_ID = originalNoteObj.note_ID;
                eachNc.note_VERSION_ID = originalNoteObj.note_VERSION_ID;
              });
            }
            // Note Parameter List
            if (!!this.caseNoteEntity.theNoteId.noteParameterList) {
              this.caseNoteEntity.theNoteId.noteParameterList.forEach(eachNp => {
                eachNp.status = DsamsConstants.ENT_CHANGED;
                eachNp.note_ID = originalNoteObj.note_ID;
                eachNp.note_VERSION_ID = originalNoteObj.note_VERSION_ID;
              });
            }
          }
          // Case_note_parameter: Delete and re-add new parameters from implemented version.
          // Set existing rows to deleted.
          // Same for both unique and non-unique note.
          if (!!this.caseNoteEntity.caseNoteParameterList) {
            this.caseNoteEntity.caseNoteParameterList.forEach(eachCnp => eachCnp.status = DsamsConstants.ENT_DELETED);
          }
          // Copy over new CNP-s.
          if (!!pRefreshedCaseNote.caseNoteParameterList) {
            pRefreshedCaseNote.caseNoteParameterList.forEach(eacnCnp => {
              this.caseNoteEntity.caseNoteParameterList.push(
                {
                  ...eacnCnp,
                  status: DsamsConstants.ENT_NEW,
                  case_ID: this.caseNoteEntity.case_ID,
                  case_VERSION_ID: this.caseNoteEntity.case_VERSION_ID,
                  note_ID: this.caseNoteEntity.note_ID,
                  note_VERSION_ID: this.caseNoteEntity.note_VERSION_ID,
                  case_NOTE_ID: this.caseNoteEntity.case_NOTE_ID
                });
            });
          }
          this.setNoteAttributes();
          this.enableDisableFields(true);
          this.setChanged();
        }
        this.isLoading.next(false);
      },
        err => {
          CaseUtils.ReportHTTPError(err, "Refreshing Case Note");
          this.isLoading.next(false);
        });
    }
    else {
      MessageMgr.displaySinglePopupError("E205");
    }
  }

  // ***************************** Case Note Save *********************************
  /** 
  * Validate country code
  * @Author: David Huynh
  * @Date: 12/03/2021
  * @Jira Card: 2934
  */
  //make sure madatory fields have values
  areFieldsValidForSave(): boolean {
    var displayMsg: boolean = false;
    let msgArray: Array<ErrorParameter> = [];

    if (CaseUtils.isBlankStr(this.txtNoteText)) {
      DialogMessageListComponentTc.addMessageRefToList(msgArray,
        'Note Text', '', MessageType.ERROR,
        "Note Text is required.");
      displayMsg = true;
    }

    //Display validation warning/error messages if applicable
    if (displayMsg) {
      this.isLoading.next(false);
      this.messageService.displayMessageListTc("Validate Note", msgArray).subscribe();
    }
    return !displayMsg;
  }

  isPSCountryCode() {
    if (!this.areFieldsValidForSave()) return;
    if (CaseCommonValidator.isEqual(this.theCustomerTypeCode, LineUtils.CUSTOMER_TYPE_PS)) {
      MessageMgr.swalFire({
        text: 'This is a 36(b) Congressional Notification document!!! Please ensure that no references are made to classified information!!! Do you want to continue with Save?',
        icon: 'question',
        width: 550,
        showCancelButton: true,
        cancelButtonText: 'No',
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes',
      }).then((result) => {
        if (result.isConfirmed)
          this.performSaveOperation();
      })
    }
    else this.performSaveOperation();
  }

  //prepare deleted CLN data for save
  prepareDeletedCLNForSave(){
    this.theDeletedAssoLinesDataList.forEach(eachRow => {
      let aCaseLineNote: ICaseLineNote = {
        status: eachRow.ent_status,
        case_ID: eachRow.caseId,
        case_MASTER_LINE_ID: eachRow.caseMasterLineId,
        related_CASE_VERSION_ID: eachRow.caseVersionId,
        related_CASE_ID: this.caseNoteEntity.case_ID,
        related_CASE_NOTE_ID: this.caseNoteEntity.case_NOTE_ID,
        related_NOTE_ID: this.caseNoteEntity.note_ID,
        related_NOTE_VERSION_ID: this.caseNoteEntity.note_VERSION_ID,
      }
      if (this.caseNoteEntity.caseLineNoteRelatedNoteIdList == null)
        this.caseNoteEntity.caseLineNoteRelatedNoteIdList = [];
      this.caseNoteEntity.caseLineNoteRelatedNoteIdList.push(aCaseLineNote);
    })
  }

  //reset entity status
  resetCLNStatus(){
    if (!!this.caseNoteEntity.caseLineNoteRelatedNoteIdList){
      this.caseNoteEntity.caseLineNoteRelatedNoteIdList.forEach(eachRow=>{
        if (eachRow.case_ID == null) eachRow.status = DsamsConstants.ENT_UNCHANGED;
      })
    }
  }

  //prepare CLN data for save
  prepareCaseLineNoteForSave() {
    this.dataSourceAssoLines.data.forEach((eachRow, index) => {
      if (eachRow.ent_status == DsamsConstants.ENT_NEW) {
        if (index == 0) this.caseNoteEntity.caseLineNoteRelatedNoteIdList = [];
        let aCaseLineNote: ICaseLineNote = {
          status: eachRow.ent_status,
          case_ID: eachRow.caseId,
          case_MASTER_LINE_ID: eachRow.caseMasterLineId,
          related_CASE_VERSION_ID: eachRow.caseVersionId,
          related_CASE_ID: this.caseNoteEntity.case_ID,
          related_CASE_NOTE_ID: this.caseNoteEntity.case_NOTE_ID,
          related_NOTE_ID: this.caseNoteEntity.note_ID,
          related_NOTE_VERSION_ID: this.caseNoteEntity.note_VERSION_ID,
          theCaseLine: {
            case_ID: this.caseNoteEntity.case_ID,
            working_CASE_VERSION_ID: this.caseNoteEntity.case_VERSION_ID,
            working_CASE_ID: this.caseNoteEntity.case_ID,
            case_MASTER_LINE_ID: eachRow.caseMasterLineId,
            status: DsamsConstants.ENT_CHANGED.toString(),
            // military_ARTICLE_SERVICE_CD: eachRow.masl,
            // issue_UNIT_CD: eachRow.quantity,
            theCaseMasterLineId: {
              case_ID: this.caseNoteEntity.case_ID,
              case_MASTER_LINE_ID: eachRow.caseMasterLineId,
              user_CASE_LINE_NUMBER_ID: eachRow.lineNum,
              user_CASE_SUBLINE_TX: '', //it is a bug in Associated Line that does not show subline 
            }
          }
        }
        if (eachRow.ent_status == DsamsConstants.ENT_NEW)
          aCaseLineNote.theCaseLine.case_LINE_NOTE_QY = (parseInt(eachRow.quantity) + 1).toString();
        else if (eachRow.ent_status == DsamsConstants.ENT_DELETED)
          aCaseLineNote.theCaseLine.case_LINE_NOTE_QY = (parseInt(eachRow.quantity) - 1).toString();
        if (this.caseNoteEntity.status == DsamsConstants.ENT_NEW) {
          aCaseLineNote.related_NOTE_ID = null;
          aCaseLineNote.related_CASE_NOTE_ID = null;
          aCaseLineNote.related_NOTE_VERSION_ID = null;
        }
        this.caseNoteEntity.caseLineNoteRelatedNoteIdList.push(aCaseLineNote);
      }
    })
    this.prepareDeletedCLNForSave();
    this.resetCLNStatus();
  }

  //prepare CNP data for save
  prepareCaseNoteParameterForSave() {
    this.dataSourceFillIns.data.forEach((eachRow, index) => {
      if (eachRow.theICaseNoteParameter.status == DsamsConstants.ENT_CHANGED ||
        eachRow.theICaseNoteParameter.status == DsamsConstants.ENT_NEW) {
        this.caseNoteEntity.caseNoteParameterList[index].case_NOTE_PARAMETER_TX =
          eachRow.theICaseNoteParameter.case_NOTE_PARAMETER_TX;
      }
    });
  }
  
  /** 
    * Save Note data
    * @Author: David Huynh
    * @Date: 12/03/2021
    * @Jira Card: 2934
    */
  prepareDataForSave() {
    this.caseNoteEntity.user_NOTE_NUMBER_ID = +this.txtNoteNumber;
    if (this.caseNoteEntity.status == DsamsConstants.ENT_NEW){
      this.caseNoteEntity.theNoteId.status = DsamsConstants.ENT_NEW;
     }
    //FR49
    if (this.caseNoteEntity.change_ACTION_CD == LineUtils.CHANGE_ACTION_DELETED ||
      this.caseNoteEntity.change_ACTION_CD == LineUtils.CHANGE_ACTION_UNAFFECTED ||
      this.caseNoteEntity.change_ACTION_CD == LineUtils.CHANGE_ACTION_RESTATED)
      this.caseNoteEntity.change_ACTION_CD = LineUtils.CHANGE_ACTION_CD_CHANGED;
    else
      this.caseNoteEntity.change_ACTION_CD = this.txtNoteStatus.substring(0, 1);
    if (!!this.caseNoteEntity.theNoteId.noteContentList && this.caseNoteEntity.theNoteId.noteContentList.length > 0) {
      this.caseNoteEntity.theNoteId.noteContentList[0].note_TX = this.txtNoteText;
    }
    this.caseNoteEntity.ipc_CATEGORY_CD = this.ipcCategoryCd;
    switch (this.caseNoteEntity.theNoteId.note_TYPE_CD) {
      case DsamsConstants.NOTE_TYPE_UNIQUE: {
        this.caseNoteEntity.theNoteId.note_TYPE_CD = 'CU';
        break;
      }
      case 'DsamsConstants.NOTE_TYPE_STANDARD':
      case 'ST': {  //DSAMS 5510. When creating a new Case Note, the new Case Note will reference a Standard Note, 
                    //but we don't need to create/insert a new Standard Note. The code below will set the Standard Note (theNoteId) status
                    //to UNCHANGED, so a new one will not get created.
        this.caseNoteEntity.theNoteId.note_TYPE_CD = 'ST';
        if (this.caseNoteEntity.status == DsamsConstants.ENT_NEW) {
          this.caseNoteEntity.theNoteId.status = DsamsConstants.ENT_UNCHANGED;
        }
        break;
      }
      case DsamsConstants.NOTE_TYPE_CUSTOMIZABLE: 
      case 'RC': {
        this.caseNoteEntity.theNoteId.note_TYPE_CD = 'CT';
        break;
      }
      case DsamsConstants.NOTE_TYPE_LINE_ITEM: {
        this.caseNoteEntity.theNoteId.note_TYPE_CD = 'LI';
        break;
      }
    }
    this.prepareCaseLineNoteForSave();
    this.prepareCaseNoteParameterForSave();
  }

  /** 
   * Save Note data
   * @Author: David Huynh
   * @Date: 12/03/2021
   * @Jira Card: 2934
   */
  performSaveOperation() {
    this.isLoading.next(true);
    this.caseRestService.saveCaseNote(this.caseNoteEntity).subscribe((pReturnedCaseNote: ICaseNote) => {
      MessageMgr.swalFire({
        text: 'Save complete.',
        icon: 'success',
        width: 300,
        showCancelButton: false,
        confirmButtonColor: '#3085d6',
        confirmButtonText: 'Ok'
      });
      this.caseNoteEntity = pReturnedCaseNote;
      this.isLoading.next(false);
      this.postSave();
    },
      err => {
        CaseUtils.ReportHTTPError(err, "Saving Case Note");
        this.isLoading.next(false);
      });
  }

  onClickSave() {
    if (this._changesMade) {
      let msgArray: Array<ErrorParameter> = [];
      this.prepareDataForSave();
      //Avoid checking for duplicate on new row
      if (this.caseNoteEntity.status == DsamsConstants.ENT_NEW)
        //perform save validation and then invoke save
        this.isPSCountryCode();
      else {
        this.caseRestService.checkCaseNoteDupVersion(this.caseNoteEntity).subscribe(isDupFound => {
          if (this.caseNoteEntity.status !== DsamsConstants.ENT_NEW && isDupFound) {
            this.isLoading.next(false);
            DialogMessageListComponentTc.addMessageRefToList(msgArray,
              'Note', '', MessageType.ERROR,
              "Note Number is not unique. To continue new processing, change the Note Number.  " +
              "To continue open processing, select valid note number.");
            this.messageService.displayMessageListTc("Validate Note", msgArray).subscribe();
          }
          else
            //perform save validation and then invoke save
            this.isPSCountryCode();
        })
      }
    }
    else {
      let nctsPrompt: any = {
        text: 'No change has been made.',
        icon: 'info',
        showConfirmButton: false,
        timer: 1500,
        width: 350
      };
      this.isLoading.next(false);
      MessageMgr.swalFire(nctsPrompt);
    }
  }

  // Post-save
  private postSave() {
    this.txtNoteStatus = this.caseNoteEntity.theChangeActionCd.change_ACTION_CD + ' - ' + this.caseNoteEntity.theChangeActionCd.change_ACTION_TITLE_NM;
    this.isDeleteButtonEditable = (this.caseNoteEntity.theChangeActionCd.change_ACTION_CD != "D");
    // Set everything to status unchanged.
    this._changesMade = false;
    this.caseNoteEntity.status = DsamsConstants.ENT_UNCHANGED;
    this.caseNoteEntity.theNoteId.status = DsamsConstants.ENT_UNCHANGED;
    this.caseUIService.hasEditBeenMadeService.next({ ID: DsamsConstants.NOTE_EDITOR, editToggle: false });
    this.theDeletedAssoLinesDataList = [];

    if (!!this.caseNoteEntity.caseLineNoteRelatedNoteIdList) {
      this.caseNoteEntity.caseLineNoteRelatedNoteIdList =
        this.caseNoteEntity.caseLineNoteRelatedNoteIdList.filter(eachRec => eachRec.status != DsamsConstants.ENT_DELETED);
      this.caseNoteEntity.caseLineNoteRelatedNoteIdList.forEach(eachRec => eachRec.status = DsamsConstants.ENT_UNCHANGED);
     }
    if (!!this.caseNoteEntity.caseNoteParameterList) {
      this.caseNoteEntity.caseNoteParameterList = this.caseNoteEntity.caseNoteParameterList.filter(eachRec => eachRec.status != DsamsConstants.ENT_DELETED);
      this.caseNoteEntity.caseNoteParameterList.forEach(eachRec => eachRec.status = DsamsConstants.ENT_UNCHANGED);
    }
    if (!!this.caseNoteEntity.theNoteId.noteContentList) {
      this.caseNoteEntity.theNoteId.noteContentList = this.caseNoteEntity.theNoteId.noteContentList.filter(eachRec => eachRec.status != DsamsConstants.ENT_DELETED);
      this.caseNoteEntity.theNoteId.noteContentList.forEach(eachRec => eachRec.status = DsamsConstants.ENT_UNCHANGED);
    }
    if (!!this.caseNoteEntity.theNoteId.noteParameterList) {
      this.caseNoteEntity.theNoteId.noteParameterList = this.caseNoteEntity.theNoteId.noteParameterList.filter(eachRec => eachRec.status != DsamsConstants.ENT_DELETED);
      this.caseNoteEntity.theNoteId.noteParameterList.forEach(eachRec => eachRec.status = DsamsConstants.ENT_UNCHANGED);
    }
    //too bugy so comment out for now
    //this.setNoteAttributes();
  }

  // Prepare Note (Unique and Line)
  prepareNote(pNoteType: string, pSelectedNote: CaseNoteDto) {
    let theNoteIdItem: INote = {};
    theNoteIdItem.note_TYPE_CD = pSelectedNote.theNoteId.note_TYPE_CD;
    let theNoteTypeCdItem: INoteType = {};
    theNoteIdItem.theNoteTypeCd = theNoteTypeCdItem;
    theNoteIdItem.theNoteTypeCd.note_TYPE_DESCRIPTION_TX = pNoteType;
    let theNoteContentListArray: INoteContent[];
    let theNoteContent: INoteContent = { note_TX: '' };
    theNoteContentListArray = [];
    theNoteContentListArray.push(theNoteContent);
    theNoteIdItem.noteContentList = theNoteContentListArray;
    theNoteIdItem.official_NOTE_TITLE_TX = "";

    this.caseNoteEntity = {
      status: DsamsConstants.ENT_NEW,
      case_ID: this.caseLineRelatedInfoData.case_ID,
      case_VERSION_ID: this.caseLineRelatedInfoData.case_VERSION_ID,
      change_ACTION_CD: "A",
      theChangeActionCd: {
        change_ACTION_CD: "A",
        change_ACTION_TITLE_NM: "Added"
      },
      ipc_CATEGORY_CD: "",
      theNoteId: theNoteIdItem,
      caseLineNoteRelatedNoteIdList: [],
      caseNoteParameterList: []
    };
  }

 
}