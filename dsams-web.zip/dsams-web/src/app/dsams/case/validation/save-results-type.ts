import { MessageDetail } from './message-detail';
import { DsamsConstants } from '../../dsams.constants';
import { MessageMgr } from './message-mgr';
import { ICaseVersion } from '../model/dto/icase-version';
import { ICaseMaster } from '../model/dto/icase-master';
import { ErrorParameter } from '../../entities/specialEntities/error-parameter.model';

/**
 * This class stores the results of a save or attempted save, including:
 * 1) Validation errors
 * 2) REST API errors
 * 3) Database errors
 * 
 * Author: CBanta
 */
export class SaveResultsType {
    private _dbError: string = DsamsConstants.NO_ERROR;
    private _apiError: string = DsamsConstants.NO_ERROR;
    private _messageList: Array<MessageDetail> = [];
    private _currentPanel: string = "";
    private _caseVersionPanelData: ICaseVersion = null;    

    constructor() { 
        this._messageList = [];
    }

    // Getter for database error
    public get DBError():string {
        return this._dbError;
    }

    // Getter for REST API error
    public get APIError():string {
        return this._apiError;
    }

    // Getter for current panel
    public get currentPanel():string {
        return this._currentPanel;
    }

    // Getter for validation message list
    public get messageList():Array<MessageDetail> {
        return this._messageList;
    }

    // Setter for database error
    public set DBError(pValue:string) {
        this._dbError = pValue;
    }

    // Setter for API error
    public set APIError(pValue:string) {
        this._apiError = pValue;
    }

    // Setter for current panel
    public set currentPanel(pValue:string) {
        this._currentPanel = pValue;
    }

    // Setter for validation message list
    public set messageList(pMessageList: Array<MessageDetail>) {
        this._messageList = pMessageList;
    }

    // // Getter for  ICaseVersion data
    public get caseVersionPanelData():ICaseVersion {
        return this._caseVersionPanelData;
    }

    // // Setter for ICaseVersion data
    public set caseVersionPanelData (pCaseVersionPanelData:ICaseVersion) {
        this._caseVersionPanelData = pCaseVersionPanelData;
    }

    /**
    * Merge the data status of two entities so that the proper one takes priority.
    */
    private mergeStatuses(pCurrentStatus:number, pAppendedStatus:number):number {
        // First set changed status if one of them is changed.
        let statusWeWantToUse:number = (pAppendedStatus == DsamsConstants.ENT_CHANGED || pCurrentStatus == DsamsConstants.ENT_CHANGED)?DsamsConstants.ENT_CHANGED:DsamsConstants.ENT_UNCHANGED;
        // Then set to new if one of them is new, since that takes priority over changed.
        statusWeWantToUse = (pAppendedStatus == DsamsConstants.ENT_NEW || pCurrentStatus == DsamsConstants.ENT_NEW)?DsamsConstants.ENT_NEW:statusWeWantToUse;        
        return statusWeWantToUse;
    }
    
    /**
     * Append a SaveResultsType (say from another panel) to the current SaveResultsType,
     * so you can accumulate all the validation messages from multiple panels.
     * @param pSaveResultsType SaveResultsType whose info you want to append to this instance's SaveResultsType
     */
    public appendSRT(pSaveResultsType:SaveResultsType):void {
        if (this.APIError === DsamsConstants.NO_ERROR &&
            pSaveResultsType.APIError !== DsamsConstants.NO_ERROR) 
        {
            this.APIError = pSaveResultsType.APIError;
        }

        if (this.DBError === DsamsConstants.NO_ERROR &&
            pSaveResultsType.DBError !== DsamsConstants.NO_ERROR)
        {
            this.DBError = pSaveResultsType.DBError;
        }

        // Append the lists of that other panel to this one.
        for (let msgDetail of pSaveResultsType._messageList) {
            this.messageList.push(msgDetail);
        }

        // Append the Save Results Type to this SRT.
        if (!!pSaveResultsType.caseVersionPanelData) {
            // Determine what the case version status should be.
            const currCVStatus:number = !this.caseVersionPanelData?DsamsConstants.ENT_UNCHANGED:this.caseVersionPanelData.status;            
            const cvStatusWeWantToUse:number = this.mergeStatuses(currCVStatus, pSaveResultsType.caseVersionPanelData.status);

            // Merge the Case Master entities within case versions.
            let caseMasterToUse:ICaseMaster = null;

            // Keep the previous case_master if the new case master is null.
            // If both case_master-s are not null, merge them together.
            if (!!pSaveResultsType.caseVersionPanelData.theCaseId && !!this.caseVersionPanelData && !!this.caseVersionPanelData.theCaseId) {
                const cmStatusWeWantToUse:number = this.mergeStatuses(this.caseVersionPanelData.theCaseId.status, pSaveResultsType.caseVersionPanelData.theCaseId.status);
                caseMasterToUse = Object.assign({}, this.caseVersionPanelData.theCaseId, pSaveResultsType.caseVersionPanelData.theCaseId);   
                caseMasterToUse.status = cmStatusWeWantToUse; 
            }

            // Merge the Case Version entities.
            this.caseVersionPanelData = Object.assign({}, this.caseVersionPanelData, pSaveResultsType.caseVersionPanelData);
            this.caseVersionPanelData.status = cvStatusWeWantToUse; 
            if (!!caseMasterToUse) {
                this.caseVersionPanelData.theCaseId = caseMasterToUse;
            }
        }            
    }

    /**
     * Add a validation message to the current SaveResultsType.
     * @param pMessageKey Message key (such as "E012")
     * @param pReference Reference to identify the location of the error (such as "Row 2")
     */
    public addMessage(pMessageKey:string, pReference:string = "") {        
        this._messageList.push ({
            message: MessageMgr.getMesssage(pMessageKey),
            reference: pReference,
            panel: this._currentPanel,
            params: []
         });
    }

    /**
     * Add a validation message to the current SaveResultsType with an array of placeholder params.
     * @param pMessageKey Message key (such as "E012")
     * @param pParams String array of parameters to fill the placeholders in the message.
     * @param pReference Reference to identify the location of the error (such as "Row 2")
     */
    public addMessageWithParams(pMessageKey:string, pParams:string[], pReference:string = "") {        
        this._messageList.push ({
            message: MessageMgr.getMesssage(pMessageKey),
            reference: pReference,
            panel: this._currentPanel,
            params: pParams
         });
    }

    /**
     * Indicates if the save was successful - no API/database errors
     */
    public isSaveSuccessful():boolean {
        return (this.DBError !== DsamsConstants.NO_ERROR && this.APIError !== DsamsConstants.NO_ERROR);
    }

    /**
     * Validation level of the SRT. Indicates the highest error level of all the validation messages,
     * so we know if we should show an error or warning label.
     * @param: pPanelName: Name of Panel (blank for all panels)
     */
    public validationLevel(pPanelName:string = DsamsConstants.CASE_PANEL_ALL):number {
        let maxLevel:number = MessageMgr.MSG_TYPE_NONE;
        for (let msgDetail of this._messageList) {
            if ((pPanelName === DsamsConstants.CASE_PANEL_ALL || pPanelName === msgDetail.panel) && 
                 msgDetail.message.messageType > maxLevel)
            {
                maxLevel = msgDetail.message.messageType;
            }
        }
        return maxLevel;
    }

    /**
     * Validation level of the entire case validation (real case validation, not completeness check)
     */
    public static caseValidationLevel(pMessageList:Array<ErrorParameter>) {
        let lvl:number = MessageMgr.MSG_TYPE_NONE;
        for (let msg of pMessageList) {
            if (msg.errorType === "Information" && lvl < MessageMgr.MSG_TYPE_INFO) {
                lvl = MessageMgr.MSG_TYPE_INFO;
            }
            else if (msg.errorType === "Warning" && lvl < MessageMgr.MSG_TYPE_WARNING) {
                lvl = MessageMgr.MSG_TYPE_WARNING;
            }
            else if (msg.errorType === "Error" && lvl < MessageMgr.MSG_TYPE_ERROR) {
                lvl = MessageMgr.MSG_TYPE_ERROR;
            } 
        }
        return lvl;
    }

    /**
     * Indicates if validation is successful, namely no showstopper errors.
     * @returns true if validation is succuessful (warnings or lower), false if not.
     */
    public isValidationSuccessful():boolean {
        return this.validationLevel() < MessageMgr.MSG_TYPE_ERROR;
    }
}