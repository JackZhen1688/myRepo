import { SaveResultsType } from './save-results-type';
import { SweetAlertIcon } from 'sweetalert2';
import { MessageMgr } from './message-mgr';
import { DsamsConstants } from '../../dsams.constants';

/**
 * This class contains the common methods for validation across case modules.
 * 
 * @author CBanta
 */
export class CaseCommonValidator {

    /**
     * Determines if a non-numeric field is blank (null or blank value supplied)
     * @param pFieldContents Contents of the field
     * @returns True if the field contains a blank value, false if not.
     */
    public static isBlank(pFieldContents:string):boolean {
        if (pFieldContents == null || pFieldContents === "") {
            return true;
        }
        return false;
    }


    /**
     * Determine if a numeric field is blank.
     * 
     * @param pFieldContents Contents of the field
     * @param pFieldName Fiend name so we can determine if 0 should denote null or not.
     */
    public static isBlankNumber(pFieldContents:number, pFieldName:string) {
        if (pFieldContents == null) {
            return true;
        }
        // If field name ends with an _ID or _CD then 0 means blank.
        const sfx:string = pFieldName.substring(pFieldName.length - 3);
        if (sfx === "_ID" || sfx === "_CD") {
            return (pFieldContents <= 0);
        }
        else {
            return (pFieldContents.toString() === "");
        }
        
    }

    
    /**
     * Determine if two fields have the same value depending on their contents.
     * 
     * @param pField1 String representing field 1
     * @param pField2 String representing field 1
     */
    public static isEqual(pField1:string, pField2:string):boolean {
        if (CaseCommonValidator.isBlank(pField1) && CaseCommonValidator.isBlank(pField2)) {
            return true;
        }
        if (pField1 === pField2) {
            return true;            
        }
        return false;
    }


    /**
     * Add a unique ID to an array row so that we can accurately compare rows on a grid without 
     * comparing a row to itself.
     * 
     * @param pArray Array we want to add the unique ID to.
     */
    
    public static addUniqueId(pArray:any) {
        if (pArray == null) {
            return;
        }
        let uniqueId:number = 1;
        for (let arrayRow of pArray) {
            arrayRow[DsamsConstants.UNIQUE_ID_FIELD] = uniqueId++;
        }
    }


    /**
     * Display the validation results popup to the UI.
     * @param pSaveResults SaveResultsType object containing all the validation results.
     */
    public static ShowValidationMessage(pSaveResults:SaveResultsType):any {
        let htmlStr:string = '<hr><div align="left">';
        let colorStr:string;
        let typeStr:string;
        let msgFound:boolean = false;

        for (const msgDetail of pSaveResults.messageList) {
            msgFound = true;  
            // Styling doesn't work yet for 
            switch(msgDetail.message.messageType) { 
                case MessageMgr.MSG_TYPE_INFO: { 
                   colorStr = "blue";
                   typeStr = "Info";
                   break; 
                } 
                case MessageMgr.MSG_TYPE_WARNING: { 
                   colorStr = "orange";
                   typeStr = "Warning";
                   break; 
                } 
                case MessageMgr.MSG_TYPE_ERROR: { 
                    colorStr = "red";
                    typeStr = "Error";
                    break; 
                }
                default: { 
                   colorStr = "blue";
                   typeStr = "";
                   break; 
                } 
             }
             
             let msgText:string = msgDetail.message.messageText;
             
             if (msgDetail.reference !== "") {
                msgText = msgText + " (" + msgDetail.reference + ")";
             }

             for (let i = 0; i < msgDetail.params.length; i++) {
                msgText = msgText.replace("%", msgDetail.params[i]);
             }
             
             // Using CSS styles don't work in sweetalert2, so you need to use the font tag.
             htmlStr += '<font color="' + colorStr + '">' + typeStr + " (" + msgDetail.message.messageKey + "): " + msgText + "</font>";
             htmlStr += "<br>";
        }

        if (!msgFound) {
            htmlStr += "No validation messages.";
        }
        htmlStr += "</div>";
        
        let swIcon:SweetAlertIcon;
        switch(pSaveResults.validationLevel()) { 
            case MessageMgr.MSG_TYPE_NULL: {
                swIcon = 'success';                
                break;
            }
            case MessageMgr.MSG_TYPE_NONE: {
                swIcon = 'success';                
                break;
            }
            case MessageMgr.MSG_TYPE_INFO: {
                swIcon = 'info';
                break;
            }
            case MessageMgr.MSG_TYPE_WARNING: {
                swIcon = 'warning';
                break;
            }
            case MessageMgr.MSG_TYPE_ERROR: {
                swIcon = 'error';
                break;
            }
            default: {
                swIcon = null;
            }
        }

        if (swIcon !== 'success') {
            return {
                title: 'Case Validation Results',
                icon: swIcon,
                html: htmlStr,
                width: 800,
                focusConfirm: true,
                confirmButtonText: 'OK'
            };
        }
        else {
            return null;
        }
    }
}