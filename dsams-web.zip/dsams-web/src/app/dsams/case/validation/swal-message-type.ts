export interface ISwalMessageType {
    title?: string,
    icon: string,
    showConfirmButton?: boolean,
    showCancelButton?: boolean,
    cancelButtonText?: string,
    confirmButtonColor?: string,
    cancelButtonColor?: string,
    confirmButtonText?: string,
    focusConfirm?: boolean,
    width?: number,
    html?: string,
    text?: string,
    timer?: number
}