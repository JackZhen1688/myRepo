/**
 * This class stores the Message Type of a validation messages, such as warning||info and the text.
 * This is not tied to a panel or have reference data (MessageDetail has that info)
 * 
 * @author CBanta
 */

export class MessageType {
    private _messageKey:string;
    private _messageText:string;
    private _messageType:number;

    public get messageKey():string {
        return this._messageKey;
    }

    public get messageText():string {
        return this._messageText;
    }

    public get messageType():number {
        return this._messageType;
    }

    constructor (pKey:string, pText:string, pType:number) {
        this._messageKey = pKey;
        this._messageText = pText;
        this._messageType = pType;
    }
}