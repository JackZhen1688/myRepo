import { MessageType } from './message-type';
import swal, { SweetAlertIcon, SweetAlertResult } from 'sweetalert2';
import { HttpErrorResponse } from '@angular/common/http';
import { ISwalMessageType } from './swal-message-type';
import { DsamsConstants } from '../../dsams.constants';
import { MatDialog, MatDialogRef, MatDialogConfig } from '@angular/material';
import { DialogMessageYesnoComponent } from '../../utilitis/dialogs/dialog-message-yesno/dialog-message-yesno.component';


/**
 * This is the message manager for storing the messages and their types 
 * for the various validation messages that can be encountered and displayed
 * to the user upon validation or save.
 * 
 * @author CBanta
 */
export class MessageMgr {
    public static get MSG_TYPE_ERROR(): number { return 4; }
    public static get MSG_TYPE_WARNING(): number { return 3; }
    public static get MSG_TYPE_INFO(): number { return 2; }
    public static get MSG_TYPE_NONE(): number { return 1; }
    public static get MSG_TYPE_NULL(): number { return 0; }
    private static _msgMap: Map<string, MessageType> = null;

    constructor() {
        MessageMgr.setMessages();
    }

    /**
     * Defines the error/warning/info messages by key.
     */
    private static setMessages() {
        const error: number = MessageMgr.MSG_TYPE_ERROR;
        const warning: number = MessageMgr.MSG_TYPE_WARNING;
        const info: number = MessageMgr.MSG_TYPE_INFO;
        let tmpMsgMap: Map<string, MessageType> = new Map<string, MessageType>();

        let key: string;
        key = "D001"; tmpMsgMap[key] = new MessageType(key, "Start Date is greater than End Date, Please Correct.", error);
        key = "E001"; tmpMsgMap[key] = new MessageType(key, "% is required.", error);
        key = "E002"; tmpMsgMap[key] = new MessageType(key, "% is required for %.", error);
        key = "W003"; tmpMsgMap[key] = new MessageType(key, "Authority must be entered on Cases for Benefitting Countries.", warning);
        key = "E005"; tmpMsgMap[key] = new MessageType(key, "Combination of Sale Term, Authority, and Fiscal Year must be unique.", error);
        key = "E006"; tmpMsgMap[key] = new MessageType(key, "Different Authorities or Fiscal Years if enabled are required if using the same term of sale", error);
        key = "E007"; tmpMsgMap[key] = new MessageType(key, "Invalid combination of Category and AOD Group.", error);
        key = "E008"; tmpMsgMap[key] = new MessageType(key, "Exactly one Customer Service row must have Procuring Agency checked.", error);
        key = "E009"; tmpMsgMap[key] = new MessageType(key, "Duplicate entry for Service Name", error);
        key = "E010"; tmpMsgMap[key] = new MessageType(key, "Authority Fiscal Year must be entered on Cases for Benefitting Countries.", error);
        key = "E011"; tmpMsgMap[key] = new MessageType(key, "Customer Request ID is required.", error);
        key = "E012"; tmpMsgMap[key] = new MessageType(key, "Customer Request ID must be numeric.", error);
        key = "E013"; tmpMsgMap[key] = new MessageType(key, "Customer Request ID not found.", error);
        key = "W014"; tmpMsgMap[key] = new MessageType(key, "DSCA should be notified within 10 days of the case.", warning);
        key = "W015"; tmpMsgMap[key] = new MessageType(key, "The Security Classification is different from the Security Classification under the Customer Request.", warning);
        key = "E016"; tmpMsgMap[key] = new MessageType(key, "Security Classification is required.", error);
        key = "W017"; tmpMsgMap[key] = new MessageType(key, "This Country has a Special Billing Agreement. This is disabled for this case. If this is not correct use Tools/Special Billing Agreement to enable.", warning);
        key = "W018"; tmpMsgMap[key] = new MessageType(key, "This Country does not have a Special Billing Agreement. This is enabled for this case. If this is not correct use Tools/Special Billing Agreement to disable.", warning);
        key = "E019"; tmpMsgMap[key] = new MessageType(key, "MTDS selection is required.", error);
        key = "E035"; tmpMsgMap[key] = new MessageType(key, "At least one Term of Sale is required.", error);
        key = "E036"; tmpMsgMap[key] = new MessageType(key, "There are unsaved changes. Continue?", info);
        key = "M011"; tmpMsgMap[key] = new MessageType(key, "Duplicate MASL", error);

        //Requirement List
        key = "E105"; tmpMsgMap[key] = new MessageType(key, "At least one Item is required.", error);

        // Waivers Panel
        key = "E020"; tmpMsgMap[key] = new MessageType(key, "IPC is required when Waiver Type is 1.", error);
        key = "E021"; tmpMsgMap[key] = new MessageType(key, "The Waiver Expiration date must occur on or after today’s date.", error);
        key = "E022"; tmpMsgMap[key] = new MessageType(key, "The Waiver Expiration date must occur on or after the Waiver Effective date.", error);

        // Associations Panel
        key = "E023"; tmpMsgMap[key] = new MessageType(key, "Associated User Case ID must be 6 characters long.", error);
        key = "E024"; tmpMsgMap[key] = new MessageType(key, "The case's implementing agency ID cannot equal the associated case's implementing agency ID.", error);
        key = "E025"; tmpMsgMap[key] = new MessageType(key, "Associated Case Customer Organization cannot be a pseudo-country.", error);
        key = "E026"; tmpMsgMap[key] = new MessageType(key, "Associated Case does not exist.", error);

        // Generic Date Messages        
        key = "E030"; tmpMsgMap[key] = new MessageType(key, "% date is invalid.", error);        

        // Generic Numeric Messages        
        key = "E031"; tmpMsgMap[key] = new MessageType(key, "% is an invalid number.", error);
        key = "E032"; tmpMsgMap[key] = new MessageType(key, "% must be between % and %.", error);

        // More date messages.
        key = "E034"; tmpMsgMap[key] = new MessageType(key, "IA Training Date cannot be after today. Date not saved.", error);
        key = "E037"; tmpMsgMap[key] = new MessageType(key, "IA Training Date cannot be more than one year in the past. Date not saved.", error);

        // Descriptions Panel
        key = "E040"; tmpMsgMap[key] = new MessageType(key, "S1 Description is required.", error);
        key = "E041"; tmpMsgMap[key] = new MessageType(key, "S1 Description must be at least 16 characters.", error);
        key = "E042"; tmpMsgMap[key] = new MessageType(key, "State Description is required.", error);

        // Signatories Panel
        key = "E050"; tmpMsgMap[key] = new MessageType(key, "Only one item can be indicated in a distribution list. Pick either an activity, a person or enter some text.", error);
        key = "E051"; tmpMsgMap[key] = new MessageType(key, "Activity ID is invalid.", error);

        // Document Requirements Panel
        key = "E060"; tmpMsgMap[key] = new MessageType(key, "The Transmittal Number does not exist in the Congressional Notification Table.", error);  // EW22499
        key = "E061"; tmpMsgMap[key] = new MessageType(key, "The Transmittal Number is not valid for this country.", error);  // EW22525
        key = "E062"; tmpMsgMap[key] = new MessageType(key, "The Transmittal Number is not part of the CN already on this case.", error);  // EW22526 
        key = "E063"; tmpMsgMap[key] = new MessageType(key, "MTDS must be set to Yes if MTDS is used as the Base Price Source.", error);  // EW22398 
        key = "E064"; tmpMsgMap[key] = new MessageType(key, "Congressional Transmittals list cannot be empty once Congressional Notification has taken place.", error);  // EW22347

        // Custom errors with two placeholders.
        key = "E100"; tmpMsgMap[key] = new MessageType(key, "%: %", error);
        key = "E101"; tmpMsgMap[key] = new MessageType(key, "Invalid query parameters", error);
        key = "E102"; tmpMsgMap[key] = new MessageType(key, "Null Pointer Exception", error);
        key = "I102"; tmpMsgMap[key] = new MessageType(key, "Search returns more than " + DsamsConstants.DEFAULT_MAX_RECORDS + " rows. Only first " + DsamsConstants.DEFAULT_MAX_RECORDS + " records returned. Please refine your search criteria.", error);

        // Editability Messages
        key = "E200"; tmpMsgMap[key] = new MessageType(key, "Case cannot be edited because it is not in development status.", error);
        key = "E201"; tmpMsgMap[key] = new MessageType(key, "New case is not in the database. Please save the case before validating.", error);
        key = "E202"; tmpMsgMap[key] = new MessageType(key, "Validate case only validates data that has been saved. There is data on the window that has not been saved. Do you want to continue with the validation?", info);
        key = "E203"; tmpMsgMap[key] = new MessageType(key, "Case cannot be edited because it is not pending or open.", error);
        key = "E204"; tmpMsgMap[key] = new MessageType(key, "Note cannot be edited because it is CWD and Case in not in Writing or Review.", error);
        key = "E205"; tmpMsgMap[key] = new MessageType(key, "The selected function is not available due to the status of the selected case.", error);
        key = "E146"; tmpMsgMap[key] = new MessageType(key, "Function not available. Another activity has rights to the data", error);

        // Case Line Messages
        key = "E301"; tmpMsgMap[key] = new MessageType(key, "Subline cannot be created on a priced line.", error);
        key = "E302"; tmpMsgMap[key] = new MessageType(key, "For Security Cooperation Program cases, the Offer Release Code should be X.", warning);
        key = "E303"; tmpMsgMap[key] = new MessageType(key, "Line Number is not unique. To continue \'new\' processing, enter a different value. To continue \'open\' processing, use pop-up button for selection", error);
        key = "E304"; tmpMsgMap[key] = new MessageType(key, "Subline Number is not unique. To continue \'new\' processing, enter a different value. To continue \'open\' processing, use pop-up button for selection", error);
        key = "E305"; tmpMsgMap[key] = new MessageType(key, "Subline cannot be edited on a priced line.", error);        
        key = "E306"; tmpMsgMap[key] = new MessageType(key, "The selected line is priced on the current implemented (I) version and priced lines cannot contain sublines. The sublines must be deleted.", error);  // EW21545
        key = "W307"; tmpMsgMap[key] = new MessageType(key, "The Refresh line/subline function will update the line/subline highlighted with data from the last implemented version and will overlay any changes made to the line/subline. Do you want to continue?", warning);  // WW21537
        key = "I308"; tmpMsgMap[key] = new MessageType(key, "Refresh complete.", info);
        key = "E309"; tmpMsgMap[key] = new MessageType(key, "Subline cannot be refreshed since its parent line is deleted.", error);   // EW30491
        key = "E310"; tmpMsgMap[key] = new MessageType(key, "Subline cannot be refreshed because the line is priced. If you want to refresh the subline, you must first delete pricing for the line.", error);   // EW22306
        key = "E311"; tmpMsgMap[key] = new MessageType(key, "Pricing needs deleted on the parent line prior to the remove/refresh being done.", error);   // EW22232
        key = "W312"; tmpMsgMap[key] = new MessageType(key, "This line has been changed or marked for deletion.  Do you want to automatically refresh this line/subline?", error);   // WW21540
        key = "E313"; tmpMsgMap[key] = new MessageType(key, "POR/NPOR is required.", error);   // EW22591/M18 (currently not used)
        key = "W314"; tmpMsgMap[key] = new MessageType(key, "A different MASL was identified on a corresponding case line(s), so POR/NPOR update was not applied to corresponding case line(s).", warning);   // WW22592/M21
        key = "W315"; tmpMsgMap[key] = new MessageType(key, "Certain corresponding case line(s) were locked by other user(s), other windows in your application, or other processes (e.g., batch), so POR/NPOR update was not applied to corresponding case line(s).", warning);   // WW22593/M20

        // Test Messages
        key = "E501"; tmpMsgMap[key] = new MessageType(key, "Test Error", error);
        key = "W502"; tmpMsgMap[key] = new MessageType(key, "Test Warning", warning);
        key = "I503"; tmpMsgMap[key] = new MessageType(key, "Test Info", info);

        // begin jiracard DSAMS-5848 08/2022 AKP
        // Web Component Validation Messages (WI005)
        key = "EW21195"; tmpMsgMap[key] = new MessageType(key, "The selected DSAMS function is not available for %1s.", error);       
        key = "EW21196"; tmpMsgMap[key] = new MessageType(key, "The selected DSAMS function is not available due to the occurrence of the %1 milestone. The %2 milestone must occur for the function to be available.", error);
        key = "EW20693"; tmpMsgMap[key] = new MessageType(key, "The selected DSAMS function is not available due to the document being in %1 status.", error);
        key = "EW21317"; tmpMsgMap[key] = new MessageType(key, "The selected DSAMS function is not available due to the ownership of %1.", error);
        // end jiracard DSAMS-5848 08/2022 AKP

        // DSAMS-5851 Case Milestone options 09/2022 ZW
        key = "EW20156"; tmpMsgMap[key] = new MessageType(key, "The %1 milestone must occur prior to %2.", error);
        key = "EW20661"; tmpMsgMap[key] = new MessageType(key, "DSCA Advance Congressional Notification has not been recorded for this case and is mandatory for this country.  Do you want to continue?", warning);
        key = "EW20662"; tmpMsgMap[key] = new MessageType(key, "Countersignature cannot occur before a planned state list is posted.", error);
        // Rename message M20, M2, M3 in requirement to M00420, M00402, M00403 respectively to match the message naming convention.
        key = "M00420"; tmpMsgMap[key] = new MessageType(key, "The actual country code must be changed to a pseudo country code prior to disapproving FOUO.", error);
        key = "M00402"; tmpMsgMap[key] = new MessageType(key, "A PAYAUTH milestone already exists on this version.", error);
        key = "M00403"; tmpMsgMap[key] = new MessageType(key, "The AOD Group milestones must have Days Actual values before MILSGN can be processed.", error);

        MessageMgr._msgMap = tmpMsgMap;
    }

    /**
     * Obtain the MessageType for a given error key (such as type warning||error and message).
     * If none found, show "unknown error, EUNK".
     * @param pKey Message Key (such as "E001", "W003", etc)
     */
    public static getMesssage(pKey: string): MessageType {
        if (MessageMgr._msgMap == null) {
            MessageMgr.setMessages();
        }
        const msgFetched: MessageType = MessageMgr._msgMap[pKey];
        if (msgFetched == null) {
            return new MessageType("EUNK", "Unknown error (" + pKey + ")", MessageMgr.MSG_TYPE_ERROR);
        }
        return msgFetched;
    }

    /**
     * Display an error message to the user.
     */
    public static displayError(pErrorInfo: string, pError: HttpErrorResponse) {
        let errorDetails: string = !pError.error ? pError.message : pError.error.message;
        MessageMgr.swalFire({
            title: 'Error in ' + pErrorInfo,
            icon: 'error',
            html: '<font color="black">' + errorDetails + '</font>',
            width: 750,
            focusConfirm: true,
            confirmButtonText: 'OK'
        });
    }

    /**
     * Display a single popup error to the user.
     */
    public static displaySinglePopupError(pErrorCd: string) {
        const errorMsg: string = MessageMgr.getMesssage(pErrorCd).messageText;
        MessageMgr.swalFire({
            title: 'Error',
            icon: 'error',
            html: '<font color="black">' + errorMsg + '</font>',
            width: 500,
            focusConfirm: true,
            confirmButtonText: 'OK'
        });
    }

    /**
     * Display a single popup warning to the user.
     */
    public static displaySinglePopupWarning(pErrorCd: string) {
        const errorMsg: string = MessageMgr.getMesssage(pErrorCd).messageText;
        MessageMgr.swalFire({
            title: 'Warning',
            icon: 'warning',
            html: '<font color="orange">' + errorMsg + '</font>',
            width: 500,
            focusConfirm: true,
            confirmButtonText: 'OK'
        });
    }

    /**
     * Display a single popup warning to the user.
     */
    public static displaySinglePopupInfo(pErrorCd: string) {
        const errorMsg: string = MessageMgr.getMesssage(pErrorCd).messageText;
        MessageMgr.swalFire({
            title: 'Info',
            icon: 'info',
            html: '<font color="black">' + errorMsg + '</font>',
            width: 500,
            focusConfirm: true,
            confirmButtonText: 'OK'
        });
    }

    /**
     * Display a success message for a message queue.
     */
    public static displaySuccessForQueue(pInfo: string): any {
        return {
            title: 'Success',
            icon: 'success',
            html: '<font color="black">' + pInfo + '</font>',
            width: 500,
            focusConfirm: true,
            confirmButtonText: 'OK'
        };
    }

    /**
     * DH: Display any given message with a timer set to close the dialog 
     */
    public static displayMessageWithTimer(pTitle:string,
        pIcon: string,
        pInfo: string, 
        pTimer: number): any {
        return MessageMgr.swalFire({
            title: pTitle,
            icon: pIcon,
            html: '<font color="black">' + pInfo + '</font>',
            width: 500,
            timer: pTimer,
            focusConfirm: true,
            showConfirmButton: false            
        });
    }

    /**
     * DH: Display a success message with a timer set to close the dialog 
     */
    public static displaySuccessWithTimer(pSuccessStr: string, pTimer: number): any {
        return this.displayMessageWithTimer('Success','success',pSuccessStr,pTimer);
    }

    /**
     * DH: Display a single popup error to the user with a timer set to close the dialog 
     */
    public static displayErrorWithTimer(pErrorStr: string, pTimer: number) {
        return this.displayMessageWithTimer('Error','error',pErrorStr,pTimer);
    }

    /**
     * DH: Display an information to the user with a timer set to close the dialog 
     */
    public static displayInfoWithTimer(pInfoStr: string, pTimer: number) {
        return this.displayMessageWithTimer('Information','info',pInfoStr,pTimer);
    }

    /**
     * DH: Just simply display any given error message
     */
     public static displayErrorMessage(pInfo: string): any {
        MessageMgr.swalFire({
            title: 'Error',
            icon: 'error',
            html: '<font color="black">' + pInfo + '</font>',
            width: 500,
            focusConfirm: true,
            confirmButtonText: 'OK'
        });
    }

    /**
     * Show a SWAL message
     */
    public static swalFire(pMsgInfo: ISwalMessageType): Promise<SweetAlertResult<unknown>> {
        const dialogWidth: number = (!pMsgInfo.width || pMsgInfo.width == 0) ? 500 : pMsgInfo.width;
        let dialogIcon: SweetAlertIcon = <SweetAlertIcon>pMsgInfo.icon;
        return swal.fire({
            title: pMsgInfo.title,
            icon: dialogIcon,
            html: pMsgInfo.html,
            text: pMsgInfo.text,
            width: dialogWidth,
            focusConfirm: pMsgInfo.focusConfirm,
            confirmButtonText: pMsgInfo.confirmButtonText,
            confirmButtonColor: pMsgInfo.confirmButtonColor,
            cancelButtonText: pMsgInfo.cancelButtonText,
            cancelButtonColor: pMsgInfo.cancelButtonColor,
            showConfirmButton: (pMsgInfo.showConfirmButton == undefined)?true:pMsgInfo.showConfirmButton,
            showCancelButton: pMsgInfo.showCancelButton,
            timer: pMsgInfo.timer
        });
    }


    /**
     * Display a success message.
     */
    public static displaySuccess(pInfo: string) {
        swal.fire(this.displaySuccessForQueue(pInfo));
    }

    /**
     * Display an info message
     */
    public static displayInfoForQueue(pInfo: string): any {
        return {
            title: 'Information',
            icon: 'info',
            html: '<font color="black">' + pInfo + '</font>',
            width: 500,
            focusConfirm: true,
            confirmButtonText: 'OK'
        };
    }

    /**
     * Display an info message for a queue.
     */
    public static displayInfo(pInfo: string) {
        swal.fire(this.displayInfoForQueue(pInfo));
    }

    /**
    * Append a message to a queue.
    */
    public static appendMsgToQueue(pMsgQueue: Array<any>, pMsg: any) {
        if (!!pMsg) {
            pMsgQueue.push(pMsg);
        }
    }

    /**
    * Show messages on the queue.
     */
    public static showMessageQueue(pMsgQueue: Array<any>) {
        swal.queue(pMsgQueue);
        pMsgQueue = [];         // This is needed because the array might be used from outside and needs to be initialized.
    }

    /**
    * Display an info message for a queue.
    */
    public static swalClose() {
        swal.close();
    }

    //DSAMS-5451 - DH 05/22
    public static showConfirmSaveChanges(popUpDialog: MatDialog):MatDialogRef<DialogMessageYesnoComponent, any>{
        const dialogConfig = new MatDialogConfig();
        dialogConfig.disableClose = true;
        dialogConfig.autoFocus = true;
        dialogConfig.width = "550px";
        dialogConfig.data = { message: DsamsConstants.TOGGLE_EDIT_CHANGE, indecator: 'Save' };
        return (popUpDialog.open(DialogMessageYesnoComponent, dialogConfig));       
    }
}