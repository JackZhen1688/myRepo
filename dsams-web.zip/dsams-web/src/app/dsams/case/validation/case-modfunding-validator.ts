import { SaveResultsType } from './save-results-type';
import { PanelExpansionProperties } from '../model/panel-expansion-properties';
import { DsamsConstants } from '../../dsams.constants';
import { CaseCommonValidator } from './case-common-validator';

/**
 * Validator class for Case ModFunding panel.
 * 
 * */
export class CaseModFundingValidator {
    public static validateModFundingPanel(pModFundingData:any, 
                                           pPanelExpansionProperties:PanelExpansionProperties,
                                           pErrorMessageList:string[]):SaveResultsType 
    {
        let validateResults:SaveResultsType = new SaveResultsType();
        validateResults.currentPanel = DsamsConstants.CASE_PANEL_MODFUNDING;
        console.log('pModFundingData');
               
       

        return validateResults;
    }
}