import { PanelExpansionProperties } from '../model/panel-expansion-properties';
import { SaveResultsType } from './save-results-type';
import { DsamsConstants } from '../../dsams.constants';

export class CaseCustomerRequestValidator {
    public static validateCustomerRequestPanel(pCustomerRequestData:any, 
                                               pPanelExpansionProperties:PanelExpansionProperties,
                                               pErrorMessageList:string[]):SaveResultsType 
    {
        let validateResults:SaveResultsType = new SaveResultsType();
        validateResults.currentPanel = DsamsConstants.CASE_PANEL_CUSTOMER_REQUEST;
        const isNew:boolean = pPanelExpansionProperties.isNewMode;
        let showSecurityCdWarning:boolean = true;

        // Show message list currently on screen.
        for (let errMsg of pErrorMessageList) {
            if (errMsg !== DsamsConstants.NO_ERROR) {
                validateResults.addMessage(errMsg);
                if (errMsg === "E011" || errMsg === "E012" || errMsg === "E013") {
                    showSecurityCdWarning = false;
                }
            }
        }

        // Now save-specific validations.
        if (!isNew && !(pCustomerRequestData['has_S1ACCEPT_S1ADD'])) {
            validateResults.addMessage("W014");
        }

        // Check if Security Classification is present.
        if (pCustomerRequestData['security_CD'] == null || pCustomerRequestData['security_CD'] === "") 
        {
            showSecurityCdWarning = false;
            validateResults.addMessage("E016");
        }

        // Check if Security Classification Cd is different from the one for the CR.
        if (showSecurityCdWarning &&
            pCustomerRequestData['customer_REQUEST_ID'] && 
            pCustomerRequestData['customer_REQUEST_ID'] > 0 &&            
            pCustomerRequestData['security_CD_CR'] !== pCustomerRequestData['security_CD'])
        {
            validateResults.addMessage("W015");
        }

        return validateResults;
    }
}
