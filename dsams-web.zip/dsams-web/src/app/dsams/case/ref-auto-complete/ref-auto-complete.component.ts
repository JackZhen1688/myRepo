import { Component, OnInit, Input, Output } from '@angular/core';
import { ReferenceDataType } from '../model/reference-data-type';
import { Observable } from 'rxjs';
import { FormControl } from '@angular/forms';
import { startWith, map, tap } from 'rxjs/operators';
import { EventEmitter } from '@angular/core';
import { MatOptionSelectionChange } from '@angular/material';
import { CaseUtils } from '../utils/case-utils';

/**
 * The ref-auto-complete is a custom mat-auto-complete Material component 
 * that allows you to wire it up to a reference table. It allows consistent
 * behavior across all reference auto-complete dropdown components
 * in DSAMS-Web (at least on the case side).
 * 
 * @author CBanta
 */
@Component({
  selector: 'app-ref-auto-complete',
  templateUrl: './ref-auto-complete.component.html',
  styleUrls: [ '../case-dashboard/common-CSS.component.css', './ref-auto-complete.component.css']
})
export class RefAutoCompleteComponent implements OnInit {
  @Input() InitialValue:string;
  @Input() FilterIndex: number = 0;
  @Input() DisplayIndex: number;
  @Input() PlaceholderText: string;
  @Input() TooltipText: string;
  @Input() TooltipStyle: string = "mat-tooltip-style";
  @Input() FieldID: string;
  @Input() Required: boolean = false;
  @Input() AllUpperCase: boolean = true;
  @Input() FieldWidth: number = 200;
  @Input() FieldWidthPct: number = 0;
  @Input() DropdownWidth: string;
  @Output() ListValueChanged = new EventEmitter();  
  @Output() FieldCleared = new EventEmitter();
  filteredOptions: Observable<Array<ReferenceDataType>>;
  formCtl:FormControl = new FormControl();
  isDisabled: boolean = false;
  altDropdownText: string = "Dropdown Selector"
  ddWidth: string;
  displayedValue: string = "";
  private _usePctWidth: boolean = false;
  private _itemSelected: boolean = false;
  private _singleItemFromSelection: ReferenceDataType;
  private _filterDisabled: boolean = true;
  private _referenceDataList: Array<ReferenceDataType>;
  private _databaseValue: string = "";

  // Flag to indicate if we waht to show the whole list after the user has made a selection.
  private _showWholeListAfterSelectionIsMade = true;  // Toggle back and forth depending on user preferences.

  @Input() set ReferenceDataList (pReferenceDataList: Array<ReferenceDataType>) {
    this._referenceDataList = pReferenceDataList;
    this.ngOnInitPrc();
    // If list was not populated in time for the selected value to be selected,
    // try to re-select it.
    if (!(this._itemSelected) && this._databaseValue !== "") {
      this.setDropdownRow(this._databaseValue);
    } 
  }

  private setDropdownRow(pValue:string) {
    const initRDTRow: ReferenceDataType = CaseUtils.fetchRefereneDataTypeByValue(this._referenceDataList, pValue);
    let currDisplayValue:string = "";
    currDisplayValue = this.DisplayField(initRDTRow);
    this.formCtl.setValue(currDisplayValue);
    this._itemSelected = (currDisplayValue != null && currDisplayValue !== "");
    this.displayedValue = currDisplayValue;
  }


  /**
   * Set the initial value from the database.
   */
  @Input() set DatabaseValue (pValue:string) {
    this._databaseValue = pValue;
    this.setDropdownRow(pValue);
  }


  /**
   * Initialize procedure that is called initially, upon reset, or setting the list.
   * (or wherever else it would need to be initialized)
   */
  private ngOnInitPrc() {
    this.clearSifs();

    this.setDropdownRow(this.InitialValue);

    // Filter-as-you type.
    this.filteredOptions = this.formCtl
                               .valueChanges
                               .pipe(startWith(''),
                                     map(textEntered => textEntered ? this._filter(textEntered) : this._referenceDataList.slice()),
                                     tap(
                                         { 
                                           next: filteredList => 
                                             {
                                             if (filteredList.length == 1) {
                                               // If there's one item left, save it for when the user tabs out
                                               // so that it's selected.
                                               this._singleItemFromSelection = filteredList[0];
                                             }
                                             else {
                                               // Clear the single item form selection if filter length not 1.
                                                 this.clearSifs();
                                               }
                                             }
                                         })
                                     );
  }


  /**
   * Enable or disable the RAC list.
   */
  @Input() set Disabled(pDisabled : string|boolean) {
    if (pDisabled === "disabled" || pDisabled === "true" || pDisabled == true) {
      this.formCtl.disable();
      this.isDisabled = true;
    }
    else {
      this.formCtl.enable();
      this.isDisabled = false;
    }
  }

  /**
   * Clear the RAC dropdown, like if the user clicks Reset.
   * @param pFlag Indicates if we need to reset the field or initialize it.
   */
  @Input() set ClearValue(pFlag : boolean) {
      if (pFlag === true) {
        if (this.InitialValue === "") {
          this.formCtl.setValue(''); 
          this.formCtl.reset();
          this.formCtl.updateValueAndValidity();    
          this._itemSelected = false;
        }
        else {
          this.ngOnInitPrc();
        }
      }
  }
  
  @Input() set MarkAsTouch (pFlag : boolean) {
    if (pFlag === true) {
      this.formCtl.markAsTouched();
    }
    else {
      this.formCtl.markAsUntouched();
    }
  }
  constructor() { }


  /**
   * Clear SIFS (single item from selection) so the user can start typing in the list again.
   */
  private clearSifs() {
    this._singleItemFromSelection = null;
  }


  ngOnInit() {
    // Set the alt dropdown selector.
    if (this.PlaceholderText != null && this.PlaceholderText.length > 0) {
      this.altDropdownText += " for " + this.PlaceholderText;
    }
  }

    
    doBlur() {
      // If the user leaves the item and there's only one item in the dropdown,
      // set the field to that item.
      if (this._singleItemFromSelection != null) {
        this._itemSelected = true;
        this.setAndEmiltRow(this._singleItemFromSelection);        
      }
      this.clearSifs();
      this._filterDisabled = true;
    }


    // Notify the parent page of the change in dropdown value.
    setAndEmiltRow(pSelectedRow: ReferenceDataType) {
      this._filterDisabled = true;
      this._itemSelected = true;
      this.formCtl.setValue(this.DisplayField(pSelectedRow));
      this.ListValueChanged.emit(pSelectedRow);
    }


    autoCompleteSelectionChange(pEvent: MatOptionSelectionChange, pSelectedRow: ReferenceDataType) {      
        if (pEvent.source.selected) {
          this.setAndEmiltRow(pSelectedRow);
        }
    }
    

    /**
     * Intercept the backspace so that it blanks out the whole field 
     * so you don't end up with weired text in the dropdown.
     */
    doBackspace() {
      if (this._itemSelected) {
        this.formCtl.setValue("");
        this._itemSelected = false;
      }
      this._filterDisabled = false;
      this.FieldCleared.emit();
    }

    /**
     * Intercept key press so that we can prevent it if the user has something 
     * selected already so we don't get weird text in the dropdown.
     * 
     * @param pEvent KeyBoardEvent we want to intercept and prevent if necessary.
     */
    doKeyPress(pEvent: KeyboardEvent) {
      if (this._itemSelected) {
        pEvent.preventDefault();
      }
      else {
        this._filterDisabled = false;
      }
    }


    doUpperCase(pText:string ):string {
      // Uppercase only if typing, not when selecting.
      if (pText != null && this.AllUpperCase && !(this._itemSelected)) {
        return pText.toUpperCase();
      }
      return pText;
    }

  /**
   * Get the field with style (percent or pixels)
   * @param pValue string containing the style string.
   */
  getMFFStyle():object {
    if (this.FieldWidthPct > 0) {
      return {"width.%" : this.FieldWidthPct};    
    }
    else {
      return {"width.px" : this.FieldWidth};    
    }
  }

  getRequiredMsg():string {
    if (this.FieldWidthPct <= 0 && this.FieldWidth < 150) {
      return "Required";
    }
    return "This is a required entry.";
  }


  // Filter the auto-complete based based on what is set as the FilterIndex column.
  private _filter(pValue: string): Array<ReferenceDataType> {
      // If fiter is disabled (like when user comes into field for first time, show whole list)
     if (this._filterDisabled && this._showWholeListAfterSelectionIsMade) {
       return this._referenceDataList;
     }
     
      const filterValue = pValue.toUpperCase();

      if (this.FilterIndex === 0) {
          return this._referenceDataList
                     .filter (rdlOption => 
                              rdlOption.key_FIELD == null? false: rdlOption.key_FIELD.toUpperCase().indexOf(filterValue) === 0);
      }
      else if (this.FilterIndex === 1) {
          return this._referenceDataList
                     .filter(rdlOption => 
                             rdlOption.field_1 == null? false : rdlOption.field_1.toUpperCase().indexOf(filterValue) === 0);
      }
      else if (this.FilterIndex === 2) {
          return this._referenceDataList                     
                     .filter(rdlOption =>  
                             rdlOption.field_2 == null? false : rdlOption.field_2.toUpperCase().indexOf(filterValue) === 0);
      }
      else if (this.FilterIndex === 3) {
        return this._referenceDataList                     
                   .filter(rdlOption =>  
                           rdlOption.field_3 == null? false : rdlOption.field_3.toUpperCase().indexOf(filterValue) === 0);
      }
      else if (this.FilterIndex === 4) {
        return this._referenceDataList                     
                   .filter(rdlOption =>  
                           rdlOption.field_4 == null? false : rdlOption.field_4.toUpperCase().indexOf(filterValue) === 0);
      }
      else if (this.FilterIndex === 5) {
        return this._referenceDataList                     
                   .filter(rdlOption =>  
                           rdlOption.field_5 == null? false : rdlOption.field_5.toUpperCase().indexOf(filterValue) === 0);
      }
      return null;
 }


public DisplayField(pRefDataType:ReferenceDataType):string {
  let retVal: string;

  if (!pRefDataType) {
    return "";
  }

  switch(this.DisplayIndex) {
    case 0:
      retVal = pRefDataType.key_FIELD; break;
    case 1: 
      retVal = pRefDataType.field_1; break;
    case 2: 
      retVal = pRefDataType.field_2; break;
    case 3: 
      retVal = pRefDataType.field_3; break;
    case 4: 
      retVal = pRefDataType.field_4; break;
    case 5: 
      retVal = pRefDataType.field_5; break;
    default:
      retVal = "";
    }
    return retVal;
}

}
