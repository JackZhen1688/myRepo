import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RefAutoCompleteComponent } from './ref-auto-complete.component';

describe('RefAutoCompleteComponent', () => {
  let component: RefAutoCompleteComponent;
  let fixture: ComponentFixture<RefAutoCompleteComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RefAutoCompleteComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RefAutoCompleteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
