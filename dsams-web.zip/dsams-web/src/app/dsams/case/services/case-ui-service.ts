/* --------------------------------------------------------------------------
This class is the UI service for cases for passing information between panels.
----------------------------------------------------------------------------- */
import { Injectable } from '@angular/core';
import { PanelExpansionProperties } from '../model/panel-expansion-properties';
import { BehaviorSubject, Subject, Observable } from 'rxjs';
import { CaseRequestParamsType } from '../model/search-params/case-request-params-type';
import { CaseRelatedInfoType, ifaceCaseLineAssistanceTypeEntity, ifaceCaseLineDeliveryItemEntity, ifaceCaseLineDeliveryScheduleEntity, ifaceCaseLineDeliveryTermEntity, ifaceCaseLineOfferReleaseEntity } from '../model/case-related-info-type';
import { CaseLineRelatedInfoType } from '../model/case-line-related-info-type';
import { SaveResultsType } from '../validation/save-results-type';
import { ifaceCaseLineData } from '../model/case-line-model';
import { ICaseVersion } from '../model/dto/icase-version';
import { IUsedUserCase } from '../model/dto/used-user-case';
import { IEditResponseType } from '../model/edit-response-type';
import { CaseSaveInfo } from '../model/case-save-info';
import { CaseAmendModChangeInfo } from '../model/case-amend-mod-change-info';
import { CasePanelStatusType } from '../model/case-panel-status-type';
import { DsamsConstants } from '../../dsams.constants';
import { ISearchPageEvent } from '../../utilitis/search-page-event';
import { customerRequestDto } from '../../customer-request/model/dto/customer-request-dto';
import { IOptionConfig } from '../shortcuts/shortcut-model';
import { CaseLinePK } from '../model/case-line-pk';
import { CaseLineIPCDto } from '../line-dashboard/line-pricing/ipc-tab-dashboard/model/dto/case-line-ipc-dto';
import { caseLineComponentDto } from '../model/dto/case-line-component-dto';
import { caseLineComponentModel } from '../model/case-line-component-model';
import { supplementalLineNoteDto } from '../line-dashboard/line-pricing/ipc-tab-dashboard/model/dto/supplemental-line-note-dto';
import { CASE_LINE_COMP_DEL_TERM } from '../model/dto/icase-line-pricing';
import { CaseNoteDto } from '../model/dto/case-note-dto';
import { ICaseNote } from '../model/dto/case-note';
import { remarksDto } from '../remarks-dashboard/model/dto/case-remarks-dto';
import { ICustomerCn } from 'src/app/dsams/case/model/dto/customer-cn';
import { summaryNotifyDto } from '../../congressional-notification/summary-notify-panel/model/dto/summary-notify-dto';
import { congressionalNotificationModel } from '../../congressional-notification/cong-notification-dashboard/model/congressional-notification';
import { CongressNotifyCommentsDTO } from '../../congressional-notification/case-comments-panel/model/view-case-comments';
import { CongressNotifyLineCommentsDTO } from '../../congressional-notification/case-comments-panel/model/view-case-comments';
import { deletedEntity } from '../../congressional-notification/summary-notify-panel/model/summary-notify';
import { CongressNotifyOverageDTO } from '../../congressional-notification/case-overage-panel/model/view-case-overage';

export interface ComponentSaveState{
  isSaveConfirmed?: BehaviorSubject<boolean>,
  isDataChanged?: boolean,
  isContinueConfirmed?: BehaviorSubject<boolean>,
} 

export interface ComponentSaveCaseLineState{
  [compName:string]: ComponentSaveState,
} 
export interface CommonReferenceData{
  refName: string[],
  defaultValue: string[],
  sortFieldNum: number[],
  allowNull: boolean[],
  showInactive: boolean[],
  extraInfo: string[],
  ruleSet: number[],
} 
@Injectable({
  providedIn: 'root'
})

export class CaseUIService {
  

  
  public static readonly SAVE_CASE_DETAILS_STATE = "caseDetails";
  public static readonly SAVE_CASE_LINE_LIST_STATE = "caseLineList";
  public static readonly SAVE_CASE_LINE_DETAILS_STATE = "caseLineDetails";
  public static readonly SAVE_CASE_LINE_PRICING_STATE = "caseLinePricing";
  public theComponentSaveState: ComponentSaveState = {};
  public theComponentSaveCaseLineState : ComponentSaveCaseLineState = {};

  public isEditOnSaveAttachmentConfirmed = new BehaviorSubject<boolean>(false);

  public breadcrumbTitleChangeRequest: Subject<string> = new Subject<string>();
  public panelExpanded: BehaviorSubject<PanelExpansionProperties> = new BehaviorSubject<PanelExpansionProperties>(null);
  public panelCollapsed: Subject<string> = new Subject<string>();
  public caseDetailSelected: BehaviorSubject<CaseRequestParamsType> = new BehaviorSubject<CaseRequestParamsType>(null);
  public popoverBooleanData = new BehaviorSubject<boolean>(false);
  public allowLineChange = new BehaviorSubject<boolean>(false);
  public allowSublineChange = new BehaviorSubject<boolean>(false);
  public isLineManagerDisabled = new BehaviorSubject<boolean>(true);
 
   // begin DSAMS-5983 09/22 DB
   public caseLineLockRequest: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
   public caseLineUnlockRequest: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
 // end DSAMS-5983 09/22 DB
  public caseLineInfo: BehaviorSubject<ifaceCaseLineData> =  new BehaviorSubject<ifaceCaseLineData>(null);
  public caseRelatedInfoDetail: BehaviorSubject<CaseRelatedInfoType> = new BehaviorSubject<CaseRelatedInfoType>(null);
  public caseLineRelatedInfoDetail: BehaviorSubject<CaseLineRelatedInfoType> = new BehaviorSubject<CaseLineRelatedInfoType>(null);
  private customerRequestDTO: BehaviorSubject<customerRequestDto> = new BehaviorSubject<customerRequestDto>(null);
  private remarksDTO: BehaviorSubject<remarksDto> = new BehaviorSubject<remarksDto>(null);
  public canSave = new Subject<boolean>();
  public saveRequest: Subject<boolean> = new Subject<boolean>();
  public saveReturnRequest: Subject<SaveResultsType> = new Subject<SaveResultsType>();
  public backToCaseSearchSummary = new BehaviorSubject<boolean>(false);
  public theDeletedCLDIList: BehaviorSubject<ifaceCaseLineDeliveryItemEntity[]> =
    new BehaviorSubject<ifaceCaseLineDeliveryItemEntity[]>(null);
  public theDeletedCLDTList: BehaviorSubject<ifaceCaseLineDeliveryTermEntity[]> =
    new BehaviorSubject<ifaceCaseLineDeliveryTermEntity[]>(null);
  public theDeletedCLORList: BehaviorSubject<ifaceCaseLineOfferReleaseEntity[]> =
    new BehaviorSubject<ifaceCaseLineOfferReleaseEntity[]>(null);
  public theDeletedCLDSList: BehaviorSubject<ifaceCaseLineDeliveryScheduleEntity[]> =
    new BehaviorSubject<ifaceCaseLineDeliveryScheduleEntity[]>(null);
  public theDeletedCLATList: BehaviorSubject<ifaceCaseLineAssistanceTypeEntity[]> =
    new BehaviorSubject<ifaceCaseLineAssistanceTypeEntity[]>(null);

  public sizbacService: BehaviorSubject<Array<string>> = new BehaviorSubject<Array<string>>(null);
  
  public caseEditService: BehaviorSubject<IEditResponseType> = new BehaviorSubject<IEditResponseType>(null);
  public caseEditServiceRegSub: Subject<IEditResponseType> = new Subject<IEditResponseType>();  // Regular Subscription
  public caseUnEditService: BehaviorSubject<IEditResponseType> = new BehaviorSubject<IEditResponseType>(null);
  public caseNewService: BehaviorSubject<IEditResponseType> = new BehaviorSubject<IEditResponseType>(null);
  public caseInitToggleService: BehaviorSubject<IEditResponseType> = new BehaviorSubject<IEditResponseType>(null);
  public hasEditBeenMadeService: Subject<IEditResponseType> = new Subject<IEditResponseType>();
  public forceEditDisabledSubscription: Subject<boolean> = new Subject<boolean>();
  public revertEditService: Subject<IEditResponseType> = new Subject<IEditResponseType>();
  public optionsMenuService: Subject<string> = new Subject<string>();
  public milestoneAddService: BehaviorSubject<string> = new BehaviorSubject<string>(null);
  public flipToDisabledService: BehaviorSubject<string> = new BehaviorSubject<string>(null);
  public flipToEnabledService: BehaviorSubject<string> = new BehaviorSubject<string>(null);
  public saveCaseVersionComplete: BehaviorSubject<ICaseVersion> = new BehaviorSubject<ICaseVersion>(null);
  public saveCaseVersionCompleteForEditToggle: Subject<ICaseVersion> = new Subject<ICaseVersion>();
  public saveCustomerRequestComplete: BehaviorSubject<customerRequestDto> = new BehaviorSubject<customerRequestDto>(null);
  public newModeInfo: BehaviorSubject<CaseSaveInfo> = new BehaviorSubject<CaseSaveInfo>(null);
  public caseAmendModChange: Subject<CaseAmendModChangeInfo> = new Subject<CaseAmendModChangeInfo>();
  public countryChange: Subject<string> = new Subject<string>();
  public showSearchSpinner: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(null);
  public validateCaseSubscription: Subject<void> = new Subject<void>();
  private panelCaseVersionStatusQuerySubscription: Subject<void> = new Subject<void>();
  private panelCaseVersionStatusResponseSubscription: BehaviorSubject<CasePanelStatusType> = new BehaviorSubject<CasePanelStatusType>(null);

  public isDocInitiatorEnabled = new BehaviorSubject<boolean>(false);
  public isOfferedEnabled = new BehaviorSubject<boolean>(false);
  //begin DSAMS-1849 DH 03/22
  public enableCalculateFMSOOption = new BehaviorSubject<boolean>(false);
  public disableCalculateFMSOOption = new BehaviorSubject<boolean>(false);
  //end DSAMS-1849 DH 03/22
  public isDevelopmentEnabled = new BehaviorSubject<boolean>(false);
  public isWritingEnabled = new BehaviorSubject<boolean>(false);
  public isReviewEnabled = new BehaviorSubject<boolean>(false);
  public isProposedEnabled = new BehaviorSubject<boolean>(false);
  public isAcceptedEnabled = new BehaviorSubject<boolean>(false);
  public isImplementedEnabled = new BehaviorSubject<boolean>(false);
  public isCountryEnabled = new BehaviorSubject<boolean>(false);
  public isAttachmentStatus = new BehaviorSubject<boolean>(false);
  public isS1DescriptionEnabled = new BehaviorSubject<boolean>(false);
  public isAmendModEnabled = new BehaviorSubject<boolean>(false);
  public isCustomerInformationEnabled = new BehaviorSubject<boolean>(false);
  public isSpecialBillingAgreementEnabled = new BehaviorSubject<boolean>(false);
  public isCongressionalNotificationEnabled = new BehaviorSubject<boolean>(false);
  public isMgrEnabled = new BehaviorSubject<boolean>(false);
  public isMgrEnabled2 = new BehaviorSubject<boolean>(false);
  public isPenInkEnabled = new BehaviorSubject<boolean>(false);
  public isStatusCompleteEnabled = new BehaviorSubject<boolean>(false);
  public isMildepEnabled = new BehaviorSubject<boolean>(false);
  public isCaseInReviewEnabled = new BehaviorSubject<boolean>(false);
  public isCaseInProposedEnabled = new BehaviorSubject<boolean>(false);
  public isDscaEnabled = new BehaviorSubject<boolean>(false);
  public isUpdImplCaseEnabled = new BehaviorSubject<boolean>(false);
  public isRequisitionForcastIndicatorEnabled = new BehaviorSubject<boolean>(false);
  public isReserveCaseIdentifierEnabled = new BehaviorSubject<boolean>(false);
  public isValidateCaseEnabled = new BehaviorSubject<boolean>(false);
  public fieldDocInitatorDisabled = new BehaviorSubject<boolean>(true);
  private isNoprEnabled = new BehaviorSubject<IOptionConfig>(null);
  public isDisabledIPCbutton = new BehaviorSubject<IOptionConfig>(null);
  public updateNopr = new Subject();
  public skipValidation: Subject<boolean> = new Subject<boolean>();
  public fieldS1DescriptionDisabled = new BehaviorSubject<boolean>(true);
  public fieldProcuringAgencyDisabled = new BehaviorSubject<boolean>(true);
  public fieldSignatoryNameDisabled = new BehaviorSubject<boolean>(true);
  public fieldLineManagerDisabled = new BehaviorSubject<boolean>(true);
  public isOptionsMenuHidden: Subject<boolean> = new BehaviorSubject<boolean>(true);
  public isShortcutsMenuHidden: Subject<boolean> = new BehaviorSubject<boolean>(true);
  public securityClassificationChanged: BehaviorSubject<string> = new BehaviorSubject<string>(null);
  public nporChanged: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
  public nporListReady: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);

  // Needed to keep track of option selects to not interfere with normal edit toggle
  public saveInViewModeWhenOptionsMenuSelected = new BehaviorSubject<boolean>(false); // Jira Card DSAMS-5689 06/2022 AKP
  public optionSelectedUCAM = new BehaviorSubject<boolean>(false);
  public optionSelectedUCCI = new BehaviorSubject<boolean>(false);
  public optionSelectedUCDI = new BehaviorSubject<boolean>(false);
  public optionSelectedUCCS = new BehaviorSubject<boolean>(false);
  public optionSelectedUCDU = new BehaviorSubject<boolean>(false);
  public optionSelectedUCMP = new BehaviorSubject<boolean>(false); // Update Manager
  public optionSelectedUCM2 = new BehaviorSubject<boolean>(false); // Update Manager 2
  public optionSelectedUCMS = new BehaviorSubject<boolean>(false); // MILDEP Signatory
  public optionSelectedUCSB = new BehaviorSubject<boolean>(false); // Special Billing Agreement
  public optionSelectedUCAI = new BehaviorSubject<boolean>(false); // Req. Allowed Indicator
  public optionSelectedUCRC = new BehaviorSubject<boolean>(false); // Reserve Case Identifier
  public optionSelectedUCPI = new BehaviorSubject<boolean>(false); // Pen and Ink
  public optionSelectedUCIR = new BehaviorSubject<boolean>(false); // Review
  public optionSelectedUCIP = new BehaviorSubject<boolean>(false); // Proposed
  public optionSelectedFMSO = new BehaviorSubject<boolean>(false); //Calculate FMSO
  // Non-Behavior Subject versions of options,
  // since we might not want them firing off until our window is open.
  public optionSelectedUCPIRegSub = new Subject<boolean>(); // Pen and Ink
  public optionSelectedUCIRRegSub = new Subject<boolean>(); // Review

  public checkMarkSBLInd = new BehaviorSubject<boolean>(false);
  public isLineTabDisabled = new BehaviorSubject<boolean>(true);
  public optionSelectCounter = new BehaviorSubject<number>(0);
  public previousLineNumber = new BehaviorSubject<number>(0);
  public isLineDataInEditMode: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
  public notifyToRefreshLineData: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(null);
  public notifyToRefreshPricingData = new BehaviorSubject<boolean>(false);
  //reset case options to default
  public notifyToSetDefaultOption: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(null);

  public resetCaseLineFromRefreshButtonSubscription: BehaviorSubject<ifaceCaseLineData> = new BehaviorSubject<ifaceCaseLineData>(null);
  public repopulateCaseLineSubscription: BehaviorSubject<ifaceCaseLineData> = new BehaviorSubject<ifaceCaseLineData>(null);
  public isLineDataChanged: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
  // Subject for pulling CaseVersion info for the case detail screen.
  public caseDetailData: BehaviorSubject<ICaseVersion> = new BehaviorSubject<ICaseVersion>(null);
  public pageNavigation: Subject<string> = new BehaviorSubject<string>("");

  public isMilestoneCommentNull: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(true);

  // Case Reserve Identifier
  public caseUsedUserData: BehaviorSubject<IUsedUserCase> = new BehaviorSubject<IUsedUserCase>(null);

  // Case Line Number Update.  Used to track Case Line Number Changes.
  // Note: Will need to reinitialize when going to a new case line details page.
  public caseLineNumberUpdate = new BehaviorSubject<string>("0");

  // Tracking when the user paginates in case search.
  public caseSearchPaginate: Subject<ISearchPageEvent> = new Subject<ISearchPageEvent>();

  // This is used to see if a Customer Request is New Entity
  public isNewCustomerRequest = new BehaviorSubject<boolean>(false);
  public isNewCongNotification = new BehaviorSubject<boolean>(false);
  public isRepopulateData = new BehaviorSubject<boolean>(false);
  public isPostSavePopulateData = new BehaviorSubject<boolean>(false);

  // This is used to see if a Remarks is New Entity
  public isNewRemarks = new BehaviorSubject<boolean>(false);

  // Case Line Pricing Subscriptions
  public caseLinePricingChanged: Subject<void> = new Subject<void>();
  public ipcTabChanged: Subject<Array<CaseLineIPCDto>> = new Subject<Array<CaseLineIPCDto>>();
  public ipcTabDeleted: Subject<CaseLineIPCDto> = new Subject<CaseLineIPCDto>();
  public cbTabChanged: Subject<caseLineComponentModel> = new Subject<caseLineComponentModel>();
  public supplementalTabSubscription: BehaviorSubject<caseLineComponentDto> = new BehaviorSubject<caseLineComponentDto>(null);
  public civilianPersonnelChosen: Subject<caseLineComponentDto> = new Subject<caseLineComponentDto>();
  public mtdsInfoChosen: Subject<caseLineComponentDto> = new Subject<caseLineComponentDto>();
  public publicationInfoChosen: Subject<any> = new Subject<any>();
  public dtcDataChanged: Subject<Array<CASE_LINE_COMP_DEL_TERM>> = new Subject<Array<CASE_LINE_COMP_DEL_TERM>>();
  public suppTabChanged: Subject<caseLineComponentDto> = new Subject<caseLineComponentDto>();
  public suppTabDeleted: Subject<supplementalLineNoteDto> = new Subject<supplementalLineNoteDto>();
  public pricingPostSave: Subject<caseLineComponentDto> = new Subject<caseLineComponentDto>();
  public pricingPostRecal: Subject<caseLineComponentDto> = new Subject<caseLineComponentDto>();
  public pricingIpcTabData: BehaviorSubject<CaseLineIPCDto[]> = new BehaviorSubject<CaseLineIPCDto[]>(null);
  public pricingReset = new BehaviorSubject<boolean>(false);

  // Note Type
  public noteType = new BehaviorSubject<string>(DsamsConstants.NOTE_TYPE_STANDARD);
  public congNumCd = new BehaviorSubject<string>('');

  // Congressional Notification
  public congNotificationFromPopup: BehaviorSubject<ICustomerCn> = new BehaviorSubject<ICustomerCn>(null);

  public caseCustReqId: BehaviorSubject<number> = new BehaviorSubject<number>(0);

  public isCongNewSearch = new BehaviorSubject<boolean>(false);

  // Summary Notification Data
  public summaryNotifyPanelData: BehaviorSubject<summaryNotifyDto[]> = new BehaviorSubject<summaryNotifyDto[]>(null);

  // Congressional Notification Data
  public congressionalNotificationData: BehaviorSubject<congressionalNotificationModel> = new BehaviorSubject<congressionalNotificationModel>(null);

  // Congressional Notification Comments Data
  public congressionalNotificationCommentsData: BehaviorSubject<CongressNotifyCommentsDTO[]> = new BehaviorSubject<CongressNotifyCommentsDTO[]>(null);
  public deletedEnitytCNData: BehaviorSubject<deletedEntity> = new BehaviorSubject<deletedEntity>(null);

  // Congressional Notification Line Comments Data
  public congressionalNotificationLineCommentsData: BehaviorSubject<CongressNotifyLineCommentsDTO[]> = new BehaviorSubject<CongressNotifyLineCommentsDTO[]>(null);

  // Congressional Notification Overages Data
  public congressionalNotificationOveragesData: BehaviorSubject<CongressNotifyOverageDTO[]> = new BehaviorSubject<CongressNotifyOverageDTO[]>(null);

  // Congressional Notification Banner
  public bannerCountry = new BehaviorSubject<string>('');
  public bannerCNCode = new BehaviorSubject<string>('');

  // Congressional Notification Change Prompt
  public checkDiscardCNChanges = new BehaviorSubject<boolean>(false);

  // begin DSAMS-5371 04/22 DB
  public checkDiscardNoteChanges = new BehaviorSubject<boolean>(true); 
  public checkDiscardNoteListChanges = new BehaviorSubject<boolean>(true); 
  public caseNoteTabNbrChanged = new BehaviorSubject<number>(0);
 // begin DSAMS-5371 04/22 DB
  // Subscription to pass the note from the note list to the note tab.
  // This needs to be Subject instead of BehaviorSubject because otherwise the event will fire when the page is not active.
  public caseNoteSelected: Subject<CaseNoteDto> = new Subject<CaseNoteDto>();

  // This will indicate if we're jumping to the Note List Tab so we know to disable the correct fields.
  public noteListNav: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(true);

  // This will indicate if we're jumping to the Note Detail Tab so we know to disable the correct fields.
  public noteDetailNav: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(true);

  // Subscription to indicate when the note has been populated.
  public caseNotePopulated: BehaviorSubject<ICaseNote> = new BehaviorSubject<ICaseNote>(null);

  // Subscription to pass the note list to the detail screen,
  // so the previous and next note arrows will have data to work with.
  public caseNoteListDetails: BehaviorSubject<CaseNoteDto[]> = new BehaviorSubject<CaseNoteDto[]>(null);

  // This will tell the note dashboard to flip to the case note list (say after a real delete of a note)
  public autoNavigateToNoteList: Subject<void> = new Subject<void>();

  //This is being commonly used by Line List, Line Detail, and Line Delivery components
  public getCaseLineInfoValues(): Observable<ifaceCaseLineData> {
    return this.caseLineInfo.asObservable();
  }
  public setCaseLineInfoValues(pCaseLineInfoType: ifaceCaseLineData) {
    this.caseLineInfo.next(pCaseLineInfoType);
  }

  //This is being commonly used by Line List, Line Detail, and Line Delivery components
  public caseLineDetailData: BehaviorSubject<ifaceCaseLineData> = new BehaviorSubject<ifaceCaseLineData>(null);
  public getCaseLineDetail(): ifaceCaseLineData {
    return this.caseLineInfo.getValue();
  }
  public setCaseLineDetail(pCaseLineDetailData: ifaceCaseLineData) {
    return this.caseLineDetailData.next(pCaseLineDetailData);
  }

  //This is being commonly used by Line Detail, and Line Delivery components
  public getTheDeletedCLDIList(): Observable<ifaceCaseLineDeliveryItemEntity[]> {
    return this.theDeletedCLDIList.asObservable();
  }
  public setTheDeletedCLDIList(pCLDIDeletedList: ifaceCaseLineDeliveryItemEntity[]) {
    this.theDeletedCLDIList.next(pCLDIDeletedList);
  }

  //This is being commonly used by  Line Detail, and Line Delivery components
  public getTheDeletedCLDTList(): Observable<ifaceCaseLineDeliveryTermEntity[]> {
    return this.theDeletedCLDTList.asObservable();
  }
  public setTheDeletedCLDTList(pCLDTDeletedList: ifaceCaseLineDeliveryTermEntity[]) {
    this.theDeletedCLDTList.next(pCLDTDeletedList);
  }

  //This is being commonly used by  Line Detail, and Line Delivery components
  public getTheDeletedCLDSList(): Observable<ifaceCaseLineDeliveryScheduleEntity[]> {
    return this.theDeletedCLDSList.asObservable();
  }
  public setTheDeletedCLDSList(pCLDTDeletedList: ifaceCaseLineDeliveryScheduleEntity[]) {
    this.theDeletedCLDSList.next(pCLDTDeletedList);
  }

  //This is being commonly used by Line Detail, and Line Delivery components
  public getTheDeletedCLORList(): Observable<ifaceCaseLineOfferReleaseEntity[]> {
    return this.theDeletedCLORList.asObservable();
  }
  public setTheDeletedCLORList(pCLDIDeletedList: ifaceCaseLineOfferReleaseEntity[]) {
    this.theDeletedCLORList.next(pCLDIDeletedList);
  }

  //This is being commonly used by Line Detail, and Line Delivery components
  public getTheDeletedCLATList(): Observable<ifaceCaseLineAssistanceTypeEntity[]> {
    return this.theDeletedCLATList.asObservable();
  }
  public setTheDeletedCLATList(pCLATDeletedList: ifaceCaseLineAssistanceTypeEntity[]) {
    this.theDeletedCLATList.next(pCLATDeletedList);
  }

  //This is being commonly used by Line List, Line Detail, and Line Delivery components
  public setCaseLineRelatedInfoValues(pCaseRelatedInfoType: CaseLineRelatedInfoType) {
    this.caseLineRelatedInfoDetail.next(pCaseRelatedInfoType);
  }
  public getCaseLineRelatedInfoValues(): Observable<CaseLineRelatedInfoType> {
    return this.caseLineRelatedInfoDetail.asObservable();
  }

  //This is being commonly used by Line List, Line Detail, and Line Delivery components
  public setCaseRelatedInfoValues(pCaseRelatedInfoType: CaseRelatedInfoType) {
    this.caseRelatedInfoDetail.next(pCaseRelatedInfoType);
  }
  public getCaseRelatedInfoValues(): Observable<CaseRelatedInfoType> {
    return this.caseRelatedInfoDetail.asObservable();
  }

  //This is being commonly used by Customer Request panel
  public setRemarksDTO(pRDto: remarksDto) {
    this.remarksDTO.next(pRDto);
  }
  public getRemarksDTO(): Observable<remarksDto> {
    return this.remarksDTO.asObservable();
  }

  //This is being commonly used by Customer Request panel
  public setCustomerRequestDTO(pCRDto: customerRequestDto) {
    this.customerRequestDTO.next(pCRDto);
  }
  public getCustomerRequestDTO(): Observable<customerRequestDto> {
    return this.customerRequestDTO.asObservable();
  }

  //This is being commonly used by Case Line IPC tabs
  private caseLinePK: BehaviorSubject<CaseLinePK> = new BehaviorSubject<CaseLinePK>(null);
  public setCaseLinePK(pCaseLinePk: CaseLinePK) {
    this.caseLinePK.next(pCaseLinePk);
  }
  public getCaseLinePK(): Observable<CaseLinePK> {
    return this.caseLinePK.asObservable();
  }

  //get and set value flag to determine whether to return back to Case Search summary page
  getbackToCaseSearchSummaryValue(): Observable<boolean> {
    return this.backToCaseSearchSummary.asObservable();
  }
  setbackToCaseSearchSummaryValue(pValue: any) {
    this.backToCaseSearchSummary.next(pValue)
  }

  //get and set value for Line Tab index
  public theOriginalLineTabIndex: BehaviorSubject<number> = new BehaviorSubject<number>(0);
  getTheOriginalLineTabIndex(): Observable<number> {
    return this.theOriginalLineTabIndex.asObservable();
  }
  setTheOriginalLineTabIndex(pValue: number) {
    this.theOriginalLineTabIndex.next(pValue);
  }

  //get and set value for Reserve Case option
  getReserveCaseIdentifierData(): Observable<IUsedUserCase> {
    return this.caseUsedUserData.asObservable();
  }
  setReserveCaseIdentifierData(pValue: IUsedUserCase) {
    this.caseUsedUserData.next(pValue);
  }

  //get and set value for Document Initiator option
  getIsDocInitiatorEnabled(): Observable<boolean> {
    return this.isDocInitiatorEnabled.asObservable();
  }
  setIsDocInitiatorEnabled(pValue: any) {
    this.isDocInitiatorEnabled.next(pValue);
  }

  //get and set value for Special Billing Agreement option
  getIsSpecialBillingAgreementEnabled(): Observable<boolean> {
    return this.isSpecialBillingAgreementEnabled.asObservable();
  }
  /* changed pValue from any to boolean here, hmm doesn't seem right but works */
  setIsSpecialBillingAgreementEnabled(pValue: boolean) {
    this.isSpecialBillingAgreementEnabled.next(pValue);
  }

  //begin DSAMS-1849 DH 03/22
  //get and set value for calculate FMSO option
  getEnableCalculateFMSOOption(): BehaviorSubject<boolean> {
    return this.enableCalculateFMSOOption;
  }
  setEnableCalculateFMSOOption(pValue: boolean) {
    this.enableCalculateFMSOOption.next(pValue);
  }
  //get and set value for calculate FMSO option
  getDisableCalculateFMSOOption(): BehaviorSubject<boolean> {
    return this.disableCalculateFMSOOption;
  }
  setDisableCalculateFMSOOption(pValue: boolean) {
    this.disableCalculateFMSOOption.next(pValue);
  }
  //end DSAMS-1849 DH 03/22

  //get and set value for Case Status for Case Attachment Edit
  getIsAttachmentStatus(): Observable<boolean> {
    return this.isAttachmentStatus.asObservable();
  }
  /* changed pValue from any to boolean here, hmm doesn't seem right but works */
  setIsAttachmentStatus(pValue: boolean) {
    this.isAttachmentStatus.next(pValue);
  }

  //get and set value for Congressional Notification option
  getIsCongressionalNotificationEnabled(): Observable<boolean> {
    return this.isCongressionalNotificationEnabled.asObservable();
  }
  /* changed pValue from any to boolean here, hmm doesn't seem right but works */
  setIsCongressionalNotificationEnabled(pValue: boolean) {
    this.isCongressionalNotificationEnabled.next(pValue);
  }

  //get and set value for Document Initiator option
  getFieldDocInitatorDisabled(): Observable<boolean> {
    return this.fieldDocInitatorDisabled.asObservable();
  }
  setFieldDocInitatorDisabled(pValue: any) {
    this.fieldDocInitatorDisabled.next(pValue);
  }

  //get and set value for S1 Description
  getIsS1DescriptionEnabled(): Observable<boolean> {
    return this.isS1DescriptionEnabled.asObservable();
  }
  setIsS1DescriptionEnabled(pValue: any) {
    this.isS1DescriptionEnabled.next(pValue);
  }

  //get and set value for S1 Description option
  getFieldS1DescriptionDisabled(): Observable<boolean> {
    return this.fieldS1DescriptionDisabled.asObservable();
  }
  setFieldS1DescriptionDisabled(pValue: any) {
    this.fieldS1DescriptionDisabled.next(pValue);
  }

  //get and set value for AmendMod option
  getIsAmendModEnabled(): Observable<boolean> {
    return this.isAmendModEnabled.asObservable();
  }
  setIsAmendModEnabled(pValue: any) {
    this.isAmendModEnabled.next(pValue);
  }

  //get and set value for Customer Information option
  getIsCustomerInformationEnabled(): Observable<boolean> {
    return this.isCustomerInformationEnabled.asObservable();
  }
  setIsCustomerInformationEnabled(pValue: any) {
    this.isCustomerInformationEnabled.next(pValue);
  }

  //get and set value for Update Mgr/?/ option
  getIsMgrEnabled(): Observable<boolean> {
    return this.isMgrEnabled.asObservable();
  }
  setIsMgrEnabled(pValue: any) {
    this.isMgrEnabled.next(pValue);
  }

  //get and set value for Update Mgr/?/ option
  getIsMgrEnabled2(): Observable<boolean> {
    return this.isMgrEnabled2.asObservable();
  }
  setIsMgrEnabled2(pValue: any) {
    this.isMgrEnabled2.next(pValue);
  }

  //get and set value for Pen&Ink option
  getIsPenInkEnabled(): Observable<boolean> {
    return this.isPenInkEnabled.asObservable();
  }
  setIsPenInkEnabled(pValue: any) {
    this.isPenInkEnabled.next(pValue);
  }

  //get and set value for Update Manager
  getIsStatusCompleteEnabled(): Observable<boolean> {
    return this.isStatusCompleteEnabled.asObservable();
  }
  setIsStatusCompleteEnabled(pValue: any) {
    this.isStatusCompleteEnabled.next(pValue);
  }

  //get and set value for MILDEP option
  getIsMildepEnabled(): Observable<boolean> {
    return this.isMildepEnabled.asObservable();
  }
  setIsMildepEnabled(pValue: any) {
    this.isMildepEnabled.next(pValue);
  }

  // get and set for NOPR
  getIsNoprEnabled(): Observable<IOptionConfig> {
    return this.isNoprEnabled.asObservable();
  }
  setIsNoprEnabled(pValue: IOptionConfig) {
    this.isNoprEnabled.next(pValue);
  }

  //get and set value for Case In Review option
  getIsCaseInReviewEnabled(): Observable<boolean> {
    return this.isCaseInReviewEnabled.asObservable();
  }
  setIsCaseInReviewEnabled(pValue: any) {
    this.isCaseInReviewEnabled.next(pValue);
  }

  //get and set value for Case In Proposed option
  getIsCaseInProposedEnabled(): Observable<boolean> {
    return this.isCaseInProposedEnabled.asObservable();
  }
  setIsCaseInProposedEnabled(pValue: any) {
    this.isCaseInProposedEnabled.next(pValue);
  }
  //get and set value for DSCA option
  getIsDscaEnabled(): Observable<boolean> {
    return this.isDscaEnabled.asObservable();
  }
  setIsDscaEnabled(pValue: any) {
    this.isDscaEnabled.next(pValue);
  }
  //get and set value for Update Impl Case option
  getIsUpdImplCaseEnabled(): Observable<boolean> {
    return this.isUpdImplCaseEnabled.asObservable();
  }
  setIsUpdImplCaseEnabled(pValue: any) {
    this.isUpdImplCaseEnabled.next(pValue);
  }

  //get and set value for Procuring Agency Field status for 
  //Change Customer Information Option
  getFieldProcuringAgencyDisabled(): Observable<boolean> {
    return this.fieldProcuringAgencyDisabled.asObservable();
  }
  setFieldProcuringAgencyDisabled(pValue: any) {
    this.fieldProcuringAgencyDisabled.next(pValue);
  }

  //get and set value for Signatory Name Field status for 
  //Change Customer Information Option
  getFieldSignatoryNameDisabled(): Observable<boolean> {
    return this.fieldSignatoryNameDisabled.asObservable();
  }
  setFieldSignatoryNameDisabled(pValue: any) {
    this.fieldSignatoryNameDisabled.next(pValue);
  }

  //Line Manager getter and setter
  getFieldLineManagerDisabled(): Observable<boolean> {
    return this.fieldLineManagerDisabled.asObservable();
  }
  setFieldLineManagerDisabled(pValue: any) {
    this.fieldLineManagerDisabled.next(pValue);
  }

  //get and set value for Indicator 
  //Change Customer Req. Allowed Indicator
  getIsRequisitionForcastIndicatorEnabled(): Observable<boolean> {
    return this.isRequisitionForcastIndicatorEnabled.asObservable();
  }
  setIsRequisitionForcastIndicatorEnabled(pValue: any) {
    this.isRequisitionForcastIndicatorEnabled.next(pValue);
  }

  //get and set value for Reserve Case Indicator
  getIsReserveCaseIdentifierEnabled(): Observable<boolean> {
    return this.isReserveCaseIdentifierEnabled.asObservable();
  }
  setIsReserveCaseIdentifierEnabled(pValue: any) {
    this.isReserveCaseIdentifierEnabled.next(pValue);
  }

  // Get and set values for validate case
  getIsValidateCaseEnabled(): Observable<boolean> {
    return this.isValidateCaseEnabled.asObservable();
  }
  setIsValidateCaseEnabled(pValue: any) {
    this.isValidateCaseEnabled.next(pValue);
  }

  // Get/set if the options menu is hidden.
  getIsOptionsMenuHidden(): Observable<boolean> {
    return this.isOptionsMenuHidden.asObservable();
  }
  setIsOptionsMenuHidden(pValue: any) {
    this.isOptionsMenuHidden.next(pValue);
  }
  // Get/set if the shortcut menu is hidden.
  getIsShortcutsMenuHidden(): Observable<boolean> {
    return this.isShortcutsMenuHidden.asObservable();
  }
  setIsShortcutsMenuHidden(pValue: any) {
    this.isShortcutsMenuHidden.next(pValue);
  }
  //get and set value for pricing tabs
  getNotifyToRefreshPricingData(): Observable<boolean> {
    return this.notifyToRefreshPricingData.asObservable();
  }
  setNotifyToRefreshPricingData(pValue: boolean) {
    this.notifyToRefreshPricingData.next(pValue);
  }

  // Set the page nagivation sub
  getPageNavigation(): Observable<string> {
    return this.pageNavigation.asObservable();
  }
  setPageNavigation(pValue: string) {
    this.pageNavigation.next(pValue);
  }

  //get and set value for SBL indicator
  getcheckMarkSBLInd(): boolean {
    return this.checkMarkSBLInd.getValue();
  }
  setcheckMarkSBLInd(pIndValue: any) {
    this.checkMarkSBLInd.next(pIndValue);
  }

  //get and set value for enabling Line and Pricing tabs
  getIsLineTabDisabled(): boolean {
    return this.isLineTabDisabled.getValue();
  }
  setIsLineTabDisabled(pIndValue: any) {
    this.isLineTabDisabled.next(pIndValue);
  }

  //get and set value for Line tabs
  getNotifyToRefreshLineData(): boolean {
    return this.notifyToRefreshLineData.getValue();
  }
  setNotifyToRefreshLineData(pValue: boolean) {
    this.notifyToRefreshLineData.next(pValue);
  }


  //get and set value for options defaults
  getNotifyToSetDefaultOption(): boolean {
    return this.notifyToSetDefaultOption.getValue();
  }
  setNotifyToSetDefaultOption(pValue: boolean) {
    this.notifyToSetDefaultOption.next(pValue);
  }

  getCongNewSearch(): boolean {
    return this.isCongNewSearch.getValue();
  }
  setCongNewSearch(pValue: boolean) {
    this.isCongNewSearch.next(pValue);
  }

  // get and set for resetCaseLineFromRefreshButtonSubscription
  getResetCaseLineFromRefreshButton(): Observable<ifaceCaseLineData> {
    return this.resetCaseLineFromRefreshButtonSubscription.asObservable();
  }
  setResetCaseLineFromRefreshButton(pValue: ifaceCaseLineData) {
    this.resetCaseLineFromRefreshButtonSubscription.next(pValue);
  }

  // get and set for repopulateCaseLineSubscription
  getRepopulateCaseLine(): Observable<ifaceCaseLineData> {
    return this.repopulateCaseLineSubscription.asObservable();
  }
  setRepopulateCaseLine(pValue: ifaceCaseLineData) {
    this.repopulateCaseLineSubscription.next(pValue);
  }

  //get and set value for Line tabs
  getIsLineDataInEditMode(): boolean {
    return this.isLineDataInEditMode.getValue();
  }
  setIsLineDataInEditMode(pValue: boolean) {
    this.isLineDataInEditMode.next(pValue);
  }

  //get and set value for Line tabs
  getIsLineDataChanged(): boolean {
    return this.isLineDataChanged.getValue();
  }
  setIsLineDataChanged(pValue: boolean) {
    this.isLineDataChanged.next(pValue);
  }

  getPopoverBooleanValue(): Observable<boolean> {
    return this.popoverBooleanData.asObservable();
  }
  setPopoverBooleanValue(pValue: any) {
    this.popoverBooleanData.next(pValue)
  }

  //get and set value for Note Type
  getNoteType(): Observable<string> {
    return this.noteType.asObservable();
  }
  setNoteType(pValue: string) {
    this.noteType.next(pValue);
  }
  getCongNumCd(): Observable<string> {
    return this.congNumCd.asObservable();
  }
  setCongNumCd(pValue: string) {
    this.congNumCd.next(pValue);
  }
  // get and set for Congressional Notification from Popup
  getCongNotificationFromPopup(): Observable<ICustomerCn> {
    return this.congNotificationFromPopup.asObservable();
  }
  setCongNotificationFromPopup(pValue: ICustomerCn) {
    this.congNotificationFromPopup.next(pValue);
    this.setCongNewSearch(true);
  }

  getCaseCustReqId(): Observable<number> {
    return this.caseCustReqId.asObservable();
  }
  setCaseCustReqId(pValue: number) {
    this.caseCustReqId.next(pValue);
   }

  // get and set for Summary Notification Data
  getSummaryNotifyPanelData(): Observable<summaryNotifyDto[]> {
    return this.summaryNotifyPanelData.asObservable();
  }
  setSummaryNotifyPanelData(pValue: summaryNotifyDto[]) {
    this.summaryNotifyPanelData.next(pValue);
  }

  // get and set for Congressional Notification Data
  getCongressionalNotificationData(): Observable<congressionalNotificationModel> {
    return this.congressionalNotificationData.asObservable();
  }
  setCongressionalNotificationData(pValue: congressionalNotificationModel) {
    this.congressionalNotificationData.next(pValue);
  }

  // get and set for Congressional Notification Comments Data
  getCongressionalNotificationCommentsData(): Observable<CongressNotifyCommentsDTO[]> {
    return this.congressionalNotificationCommentsData.asObservable();
  }
  setCongressionalNotificationCommentsData(pValue: CongressNotifyCommentsDTO[]) {
    this.congressionalNotificationCommentsData.next(pValue);
  }

  // get and set for deleted Congressional Notification Data
  getDeletedEntityCNData(): Observable<deletedEntity> {
    return this.deletedEnitytCNData.asObservable();
  }
  setDeletedEntityCNData(pValue: deletedEntity) {
    this.deletedEnitytCNData.next(pValue);
  }

  // get and set for Congressional Notification Line Comments Data
  getCongressionalNotificationLineCommentsData(): Observable<CongressNotifyLineCommentsDTO[]> {
    return this.congressionalNotificationLineCommentsData.asObservable();
  }
  setCongressionalNotificationLineCommentsData(pValue: CongressNotifyLineCommentsDTO[]) {
    this.congressionalNotificationLineCommentsData.next(pValue);
  }

  // get and set for Congressional Notification Overages Data
  getCongressionalNotificationOveragesData(): Observable<CongressNotifyOverageDTO[]> {
    return this.congressionalNotificationOveragesData.asObservable();
  }
  setCongressionalNotificationOveragesData(pValue: CongressNotifyOverageDTO[]) {
    this.congressionalNotificationOveragesData.next(pValue);
  }

  //get and set value for Country option
  getIsCountryEnabled(): Observable<boolean> {
    return this.isCountryEnabled.asObservable();
  }
  /* changed pValue from any to boolean here, hmm doesn't seem right but works */
  setIsCountryEnabled(pValue: boolean) {
    this.isCountryEnabled.next(pValue);
  }
//added for card 5231 validate overridden IPC 
  getIsIPCValidationEnabled(): Observable<IOptionConfig> {
    return this.isDisabledIPCbutton.asObservable();
  }
  setIsIPCValidationEnabled(pValue: IOptionConfig) {
    this.isDisabledIPCbutton.next(pValue);
  }


  public submitBreadcrumbTitleChangeRequest(pNewTitle: string) {
    this.breadcrumbTitleChangeRequest.next(pNewTitle);
  }

  private msgSource = new BehaviorSubject('Message from caseUIdataservice')
  currentMsg = this.msgSource.asObservable();

  changeMessage(message: string) {
    this.msgSource.next(message)
  }

  CaseDashboardComponent: any;

  public setPanelExpanded(pPanelExpansionProperties: PanelExpansionProperties) {
    this.panelExpanded.next(pPanelExpansionProperties);
  }

  // Reset Option flags
  public resetOptionFlags(pPageName: string) {
    if (pPageName === DsamsConstants.PAGE_CASE_DETAIL) {
      this.setIsMgrEnabled2(false);
      this.setIsStatusCompleteEnabled(false);
      this.setIsNoprEnabled({ visible: false, disabled: true });
    }
    else {
      this.setIsAmendModEnabled(false);
      this.setIsCountryEnabled(false);
      this.setIsDocInitiatorEnabled(false);
      this.setIsMildepEnabled(false);
      this.setIsDscaEnabled(false);
      this.setIsUpdImplCaseEnabled(false);
      this.setIsRequisitionForcastIndicatorEnabled(false);
      this.setIsS1DescriptionEnabled(false);
      this.setIsAmendModEnabled(false);
      this.setIsReserveCaseIdentifierEnabled(false);
      this.setIsSpecialBillingAgreementEnabled(false);
      this.setIsCongressionalNotificationEnabled(false);
      this.setIsValidateCaseEnabled(false);
      this.setIsCustomerInformationEnabled(false);
      this.setIsMgrEnabled(false);
    }
    this.optionSelectedUCAM.next(false);
    this.optionSelectedUCCI.next(false);
    this.optionSelectedUCDI.next(false);
    this.optionSelectedUCCS.next(false);
    this.optionSelectedUCDU.next(false);
    this.optionSelectedUCMP.next(false);
    this.optionSelectedUCMS.next(false);
    this.optionSelectedUCSB.next(false);
    this.optionSelectedUCAI.next(false);
    this.optionSelectedUCRC.next(false);
    this.optionSelectedUCM2.next(false);
    this.optionSelectedUCPI.next(false);
    this.optionSelectedUCIR.next(false);
    this.optionSelectedUCIP.next(false);
    this.optionSelectedFMSO.next(false);
  }


  // Check if an Option flag was set
  public checkOptionFlag() {
    if (this.optionSelectedUCCI ||
      this.optionSelectedUCDI ||
      this.optionSelectedUCCS ||
      this.optionSelectedUCDU ||
      this.optionSelectedUCMP ||
      this.optionSelectedUCMS ||
      this.optionSelectedUCSB ||
      this.optionSelectedUCAI ||
      this.optionSelectedUCRC ||
      this.optionSelectedUCM2 ||
      this.optionSelectedUCPI ||
      this.optionSelectedUCIR ||
      this.optionSelectedUCIP ||
      this.optionSelectedFMSO 
     ) {
      return true;
    }
    else
      return false;
  }

  /** Validate Case services */
  public panelCaseVersionStatusQuerySubscriptionNext() {
    this.panelCaseVersionStatusQuerySubscription.next();
  }
  public getPanelCaseVersionStatusQuerySubscription(): Observable<void> {
    return this.panelCaseVersionStatusQuerySubscription.asObservable();
  }
  public panelCaseVersionStatusResponseSubscriptionNext(pPanelName: string, pStatus: number, pCaseId: number, pCaseVersionId: number) {
    const cpst: CasePanelStatusType = { panelName: pPanelName, status: pStatus, caseId: pCaseId, caseVersionId: pCaseVersionId };
    this.panelCaseVersionStatusResponseSubscription.next(cpst);
  }
  public getPanelCaseVersionStatusResponseSubscription(): Observable<CasePanelStatusType> {
    return this.panelCaseVersionStatusResponseSubscription.asObservable();
  }

  public caseLineToggleAction: BehaviorSubject<string> = new BehaviorSubject<string>('');
  getCaseLineToggleAction(): Observable<string> {
    return this.caseLineToggleAction.asObservable();
  }
  setCaseLineToggleAction(pValue: string) {
    this.caseLineToggleAction.next(pValue);
  }
  
}