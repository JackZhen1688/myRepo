import { TestBed } from '@angular/core/testing';

import { CaseRestfulService } from './case-restful.service';

describe('CaseRestfulService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CaseRestfulService = TestBed.get(CaseRestfulService);
    expect(service).toBeTruthy();
  });
});
