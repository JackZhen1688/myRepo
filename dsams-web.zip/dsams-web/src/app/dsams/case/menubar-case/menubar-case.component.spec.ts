import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MenubarCaseComponent } from './menubar-case.component';

describe('MenubarCaseComponent', () => {
  let component: MenubarCaseComponent;
  let fixture: ComponentFixture<MenubarCaseComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MenubarCaseComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MenubarCaseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
