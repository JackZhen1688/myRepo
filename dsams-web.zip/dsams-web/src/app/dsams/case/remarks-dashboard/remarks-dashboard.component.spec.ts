import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RemarksDashboardComponent } from './remarks-dashboard.component';

describe('RemarksDashboardComponent', () => {
  let component: RemarksDashboardComponent;
  let fixture: ComponentFixture<RemarksDashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RemarksDashboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RemarksDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
