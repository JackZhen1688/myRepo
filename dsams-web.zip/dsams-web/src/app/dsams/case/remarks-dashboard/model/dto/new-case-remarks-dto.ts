import { remarksDto } from "./case-remarks-dto";

export interface newremarksDto extends remarksDto {
    isNewElement?: Boolean;
}
