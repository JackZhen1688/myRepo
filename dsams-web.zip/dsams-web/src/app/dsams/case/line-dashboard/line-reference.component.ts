import { Injectable } from '@angular/core';
import { CaseRestfulService } from '../services/case-restful.service';
import { ifaceCaseLineData, ifaceGenericRefItem } from '../model/case-line-model';
import { tap } from 'rxjs/operators';
import { CaseUtils } from '../utils/case-utils';
import { BehaviorSubject } from 'rxjs';
import { DsamsRestfulService } from '../../services/dsams-restful.service';

@Injectable({
  providedIn: 'root'
})

export class LineSublineRefComponent {
  private static CHANGE_ACTION_ADDED: string = "A";
  public resetDynamicRefListFlag = new BehaviorSubject<boolean>(false);
  public isReferenceLineDataReady: boolean = false;
  public static theReferenceLineDataList: ifaceCaseLineData;
  public static _theLineManagerRefList: ifaceGenericRefItem[] = [];
  public static _theOperatingAgencyRefList: ifaceGenericRefItem[] = [];

  private emptyObject: ifaceGenericRefItem = { value_CD: '', value_TITLE_NM: '', value_TITLE_DESC: '' };

  constructor(private caseRestService: CaseRestfulService,
    private dsamsRestfulService: DsamsRestfulService) { }

  //begin DSAMS-5269 DH 03/2022 - Redo the implementation of the entire class to improve performance 
  //and make code logic look OO cleaner and meaner for future maintenace purpose
  private initializeReferenceList(): ifaceCaseLineData {
    return ({
      linePurposeRefList: [], shipmentStatusRefList: [],
      trainingNoteRefList: [], supportingOrgRefList: [],
      supplySourceRefList: [], lineManagerRefList: [],
      lineManagerOARefList: [], conditionRefList: [],
      operatingAgencyRefList: [], deliveryTermList: [],
      activityList: [], calendarYearList: [], assistanceTypeList: [],
      offerReleaseList: [], budgetAppropriationList: [],
      issueUnitList: [], programOfRecordList: [],
    })
  }

  //get reference data from database
  public populateReferenceDataForCaseLine() {
    //check to make Rest API call only when applicable
    if (LineSublineRefComponent.theReferenceLineDataList == null ||
      LineSublineRefComponent.theReferenceLineDataList.linePurposeRefList == null) {
      let tempSub = this.caseRestService.getLineReferenceList()
        .subscribe(
          result => {
            if (!!result) {
              LineSublineRefComponent.theReferenceLineDataList = result;
              //Stipple out unapplicable data values for specific dropdown lists
              this.excludeSpecificRefValues();
              //Add an empty object to display N/A value
              this.addEmptyObjectToApplicableRef(LineSublineRefComponent.theReferenceLineDataList);
              //store dynamic reference list
              this.storeOriginalRefDataList(LineSublineRefComponent.theReferenceLineDataList);
              this.isReferenceLineDataReady = true;
            }
            else {
              //should not get here, but do initializing values just in case to avoid html undefined errors
              LineSublineRefComponent.theReferenceLineDataList = this.initializeReferenceList();
              this.isReferenceLineDataReady = true;
            }
          },
          err => {
            console.log('Error getting case line reference data');
            CaseUtils.ReportHTTPError(err, "getting case line reference data.");
            this.isReferenceLineDataReady = true;
            //http request and take operation will automatically unsubscribe it when returned result is success/complete, 
            //although it is not needed but manually unsubscribe it just in case of error. 
            tempSub.unsubscribe();
          });
    }
    else this.isReferenceLineDataReady = true;
  }

  //Empty object is needed for displaying the N/A string for a certain set of dropwdown selections per Analysts.
  //It is not needed for any mandatory dropdown list.
  private addEmptyObjectToApplicableRef(pRefList: ifaceCaseLineData) {
    let objectListEntry: keyof typeof pRefList;
    var notApplicableList: string[] = ["linePurposeRefList", "assistanceTypeList", "supportingOrgRefList",
      "offerReleaseList", "deliveryTermList", "operatingAgencyRefList"];
    for (objectListEntry in pRefList) {
      if (!notApplicableList.includes(objectListEntry))
        (pRefList[objectListEntry] as ifaceGenericRefItem[]).unshift(this.emptyObject);
    }
  }

  //Clone these specific reference lists due to their data values 
  //being dynamicly altered at run time
  private storeOriginalRefDataList(pCopyRefList: ifaceCaseLineData) {
    let objectListEntry: keyof typeof pCopyRefList;
    for (objectListEntry in pCopyRefList) {
      if (objectListEntry.valueOf() == "lineManagerRefList")
        LineSublineRefComponent._theLineManagerRefList = Object.assign(pCopyRefList.lineManagerRefList);
      else if (objectListEntry.valueOf() == "operatingAgencyRefList")
        LineSublineRefComponent._theOperatingAgencyRefList = Object.assign(pCopyRefList.operatingAgencyRefList);
    }
  }

  //Leave out unapplicable reference values
  private excludeSpecificRefValues() {
    LineSublineRefComponent.theReferenceLineDataList.deliveryTermList = this.getCaseLineDeliveryTermRefList();
    LineSublineRefComponent.theReferenceLineDataList.supportingOrgRefList = this.getCaseLineSupportingOrgRefList();
  }

  //Get the static reference list for all reference data in case line details/delivery web page
  public getReferenceDataForCaseLine(): ifaceCaseLineData {
    if (!!LineSublineRefComponent.theReferenceLineDataList)
      return LineSublineRefComponent.theReferenceLineDataList;
    else {
      return this.initializeReferenceList();
    }
  }

  //Restore the reference data list to their intial values that had been cached
  public restoreInitialReferenceDataList() {
    if (!!LineSublineRefComponent.theReferenceLineDataList &&  
        !!LineSublineRefComponent.theReferenceLineDataList.lineManagerRefList) {
      LineSublineRefComponent.theReferenceLineDataList.lineManagerRefList = [];
      LineSublineRefComponent.theReferenceLineDataList.lineManagerRefList =
        Object.assign(LineSublineRefComponent._theLineManagerRefList);
      LineSublineRefComponent.theReferenceLineDataList.operatingAgencyRefList = [];
      LineSublineRefComponent.theReferenceLineDataList.operatingAgencyRefList =
        Object.assign(LineSublineRefComponent._theOperatingAgencyRefList);
    }
  }

  //set up line manager reference list with data that belongs to a specific line_MANAGER_ID
  public getLineManagerRefData(pCaseLineInfoData: ifaceCaseLineData): ifaceGenericRefItem[] {
    //WP003a FR12
    var aLineManagerRefList: ifaceGenericRefItem[] = Object.assign(
      LineSublineRefComponent.theReferenceLineDataList.lineManagerRefList);
    if (!!pCaseLineInfoData.line_MANAGER_ID && pCaseLineInfoData.line_MANAGER_ID !== 'N/A') {
      aLineManagerRefList = LineSublineRefComponent.theReferenceLineDataList.lineManagerRefList.filter(
        eachLMRow => eachLMRow.value_CD1 == pCaseLineInfoData.operating_AGENCY_CD);
      aLineManagerRefList.unshift(this.emptyObject);
    }
    return aLineManagerRefList;
  }

  //set up operating agency reference list with data that belongs to a specific line_MANAGER_ID
  public getOperatingAgencyRefData(pCaseLineInfoData: ifaceCaseLineData): ifaceGenericRefItem[] {
    //WP003a FR13
    var anOARefList: ifaceGenericRefItem[] = Object.assign(
      LineSublineRefComponent.theReferenceLineDataList.operatingAgencyRefList);
    if (!!pCaseLineInfoData.line_MANAGER_ID && pCaseLineInfoData.line_MANAGER_ID !== 'N/A') {
      anOARefList = [];
      anOARefList.push(this.emptyObject);
      for (let eachOARow of LineSublineRefComponent.theReferenceLineDataList.lineManagerOARefList) {
        if (eachOARow.value_CD == pCaseLineInfoData.line_MANAGER_ID) {
          //swap the values as value_CD1 and value_TITLE_NM1 are from OPERATING_AGENCY_CD table
          anOARefList.push({
            value_CD: eachOARow.value_CD1,
            value_TITLE_NM: eachOARow.value_TITLE_NM1,
          });
        }
      }
    }
    return anOARefList;
  }

  //set up Supporting Organization reference list that excludes PEO ID value
  private getCaseLineSupportingOrgRefList(): ifaceGenericRefItem[] {
    let refList: ifaceGenericRefItem[] = [];
    let NO_PEO_ID: string = '134';
    refList = LineSublineRefComponent.theReferenceLineDataList.supportingOrgRefList.filter(
      eachSPRow => eachSPRow.value_CD !== NO_PEO_ID);
    return refList;
  }

  //set up Delivery Term reference list with data that belongs to a given set of values
  private getCaseLineDeliveryTermRefList(): ifaceGenericRefItem[] {
    let refList: ifaceGenericRefItem[] = [];
    var allowableDeliveryValues: string[] = ['2', '3', '4', '5', '6', '7', '8', '9', '0'];
    let movingIndex: number = 0;
    for (var i = 0; i < LineSublineRefComponent.theReferenceLineDataList.deliveryTermList.length; i++) {
      if (LineSublineRefComponent.theReferenceLineDataList.deliveryTermList[i]) {
        if (LineSublineRefComponent.theReferenceLineDataList.deliveryTermList[i].value_CD == '0') movingIndex = i;
        if (allowableDeliveryValues.includes(LineSublineRefComponent.theReferenceLineDataList.deliveryTermList[i].value_CD, 0))
          refList.push(LineSublineRefComponent.theReferenceLineDataList.deliveryTermList[i]);
        //moving object to another position in the array list
        if (i == LineSublineRefComponent.theReferenceLineDataList.deliveryTermList.length - 1) {
          refList.push(refList[movingIndex]);
          refList.splice(movingIndex, 1);
        }
      }
    }
    return refList;
  }

  //get and set boolean flag to restore initial reference data
  public getResetDynamicRefList(): BehaviorSubject<boolean> {
    return this.resetDynamicRefListFlag;
  }
  public setResetDynamicRefList(pValue: boolean) {
    this.resetDynamicRefListFlag.next(pValue);
  }
  //end DSAMS-5269 DH 03/2022 

  //begin DSAMS-5461 DH 05/22
  public getEditAccessRight(pCSUId: string) {
    let aQueryCriteria: string = encodeURIComponent(pCSUId + "#" + CaseUtils.getServiceDatabaseId());
    return (this.dsamsRestfulService.getEditableAccess(aQueryCriteria)
      .pipe(tap(result => 
        console.log("result=" + result, "queryCriteria=" + decodeURIComponent(aQueryCriteria)))));
  }
  //end DSAMS-5461 DH 05/22

  //*********************************************************** */
  //Not used - this method is kept for future reference as a 
  //sample model of how to get individual reference data list
  private getIndividualRefExample() {
    LineSublineRefComponent.theReferenceLineDataList.conditionRefList = [];
    this.caseRestService.getCaseLineRefList("CONDITION").subscribe(result => {
      LineSublineRefComponent.theReferenceLineDataList.conditionRefList.push(result);
    })
  }
}
