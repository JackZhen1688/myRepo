import { formatCurrency } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatTableDataSource } from '@angular/material';
import { BehaviorSubject, Subscription } from 'rxjs';
import { TextAreaComponent } from 'src/app/dsams/case/dialogs/text-area/text-area.component';
import { CaseLinePK } from 'src/app/dsams/case/model/case-line-pk';
import { caseLineComponentDto, fundDto, priceElementDto } from 'src/app/dsams/case/model/dto/case-line-component-dto';
import { IEditResponseType } from 'src/app/dsams/case/model/edit-response-type';
import { CaseRestfulService } from 'src/app/dsams/case/services/case-restful.service';
import { CaseUIService } from 'src/app/dsams/case/services/case-ui-service';
import { CaseUtils } from 'src/app/dsams/case/utils/case-utils';
import { CaseCommonValidator } from 'src/app/dsams/case/validation/case-common-validator';
import { DsamsConstants } from 'src/app/dsams/dsams.constants';
import { DsamsMethodsService } from 'src/app/dsams/services/dsams-methods.service';
import { CaseLineIPCDto, CaseLineIPCStatusDTO, FundDTO, IndirectPricingComponentDTO, PriceElementDTO, PriceElementFundDTO } from '../model/dto/case-line-ipc-dto';
import { DefaultPricingComponentDTO } from '../model/dto/default-pricing-compoenet-dto';
@Component({
  selector: 'app-ipc-tab',
  templateUrl: './ipc-tab.component.html',
  styleUrls: ['./ipc-tab.component.css']
})
export class IpcTabComponent implements OnInit {
  naString: string = 'N/A';
  dataSourceIPCListData: CaseLineIPCDto[] = [];
  savedDataSourceIPCListData: CaseLineIPCDto[] = [];
  dataSourceIPCTable = new MatTableDataSource(this.dataSourceIPCListData);
  columnsToDisplayFooter = ['AddRow'];
  columnsToDisplayIPC =
    ['IPC', 'Status', 'Price', 'IPC Fund', 'Percent', 'Waiver Cost', 'IPC Unit Cost', 'IPC Total Cost', 'Remarks', 'DeleteRow'];

  theCaseLineIPCDto: CaseLineIPCDto;
  anEmptyCLIPC: CaseLineIPCDto;
  isIPCPanelEditable: boolean = false;
  caseLinePkData: CaseLinePK;
  IsRecalCost: boolean = false;

  //Static dropdown List
  thePriceElementList: PriceElementDTO[] = [];
  theFundList: FundDTO[] = [];
  thePriceElementFundList: PriceElementFundDTO[] = [];
  theIndirectPricingCompList: IndirectPricingComponentDTO[] = [];
  theDefaultPricingCompList: DefaultPricingComponentDTO[] = [];
  theCaseLineIPCStatusList: CaseLineIPCStatusDTO[] = [];

  //form controls
  fcIPC_NUMBER_ID: FormControl = new FormControl('');
  fcPRICE_ELEMENT_CD: FormControl = new FormControl('');
  fcFUND_CD: FormControl = new FormControl('');
  fcCASE_LINE_IPC_STATUS_CD: FormControl = new FormControl('');

  //Subscription/Observable variables
  private textAreaSubscription: Subscription = null;
  private editSubscription: Subscription = null;
  private unEditSubscription: Subscription = null;
  private caseLineIPCSubscription: Subscription = null;
  private postSaveSubscription: Subscription = null;
  private postRecalSubscription: Subscription = null;
  private pricingIpcTabSubscription: Subscription = null;
  private _componentPriceElementFundString: string = "";
  private _fundFullList: Array<fundDto> = [];
  private _priceElementFullList: Array<priceElementDto> = [];
  private _textIndex: number = -1;
  isLoading: BehaviorSubject<boolean> = new BehaviorSubject(false);

  constructor(public dsamsDialogMsgService: DsamsMethodsService,
    private caseUIService: CaseUIService,
    private caseLineIPCRestService: CaseRestfulService) { }

  ngOnInit() {
    if (!this.caseLineIPCSubscription) {
      this.caseLineIPCSubscription = this.caseUIService.getCaseLinePK().subscribe((data) => {
        this.caseLinePkData = data;
        this.populateReferenceData(this.caseLinePkData.primary_CATEGORY_CD);
      });
    }
    this.subscribeToPostSave();
    this.subscribeToPostRecal();
    this.subscribeToTextAreaDialog();
    this.subscribeToEditService();
  }

  //get specific Ref data
  populateReferenceData(pPrimaryCategoryCd: string) {
    this.isLoading.next(true);
    this.caseLineIPCRestService.getCLIPCRefData(pPrimaryCategoryCd).subscribe(
      refData => {
        this.thePriceElementList = refData.priceElementList;
        this.theFundList = refData.fundList;
        this.theIndirectPricingCompList = refData.indirectPricingCompList;
        this.theDefaultPricingCompList = refData.defaultPricingCompList;
        this.theCaseLineIPCStatusList = refData.caseLineIPCStatusList;
        this.thePriceElementFundList = refData.priceElementFundList;
        for (let elem of this.theFundList) {
          this._fundFullList.push({ fund_CD: elem.fund_CD, fund_TITLE_NM: elem.fund_TITLE_NM });
        }
        for (let elem of this.thePriceElementList) {
          this._priceElementFullList.push({ price_ELEMENT_CD: elem.price_ELEMENT_CD, price_ELEMENT_TITLE_NM: elem.price_ELEMENT_TITLE_NM });
        }
        for (let elem of this.thePriceElementFundList) {
          this._componentPriceElementFundString = this._componentPriceElementFundString + "*" + elem.fund_CD + "@" + elem.price_ELEMENT_CD + "*";
        }
        this.populateCaseLineIPCDto();
        this.isLoading.next(false);
      });
  }

  // Destroy any non-HTTP subscriptions
  ngOnDestroy(): void {
    if (!!this.editSubscription) {
      this.editSubscription.unsubscribe();
    }
    if (!!this.unEditSubscription) {
      this.unEditSubscription.unsubscribe();
    }
    if (!!this.textAreaSubscription) {
      this.textAreaSubscription.unsubscribe();
    }
    if (!!this.caseLineIPCSubscription) {
      this.caseLineIPCSubscription.unsubscribe();
      this.caseLineIPCSubscription = null;
    }
    if (!!this.pricingIpcTabSubscription) {
      this.pricingIpcTabSubscription.unsubscribe();
      this.pricingIpcTabSubscription = null;
    }
    if (!!this.postSaveSubscription) {
      this.postSaveSubscription.unsubscribe();
    }
    if (!!this.postRecalSubscription) {
      this.postRecalSubscription.unsubscribe();
    }
  }

  // Subscribe to edit service
  private subscribeToEditService() {
    this.caseUIService.caseEditService.forEach((pEditResult: IEditResponseType) => {
      if (!!pEditResult && pEditResult.ID === DsamsConstants.CASE_LINE_EDITOR) {
        this.isIPCPanelEditable = pEditResult.editToggle;
        if (this.isIPCPanelEditable) {
          this.setStatusFieldState(false);
          this.populateIPCStatusList();
        }
        else this.setStatusFieldState(true);
      }
    });
    this.unEditSubscription = this.caseUIService.caseUnEditService.subscribe((pEditResult: IEditResponseType) => {
      if (!!pEditResult && pEditResult.ID === DsamsConstants.CASE_LINE_EDITOR) {
        this.isLoading.next(true);
        // Removed pricingIpcTabData set with this.savedDataSourceIPCListData.
        // It was setting ipc list to empty (FS 04/08/2022)
        this.isIPCPanelEditable = false;
      }
    });
  }

  InitializeCLIPCDto(pNotNewRow: boolean): CaseLineIPCDto {
    return ({
      ipc_NUMBER_ID: '',
      case_LINE_IPC_STATUS_CD: 'NA',     // This is the default in legacy.
      case_LINE_IPC_WAIVER_COST_AM: 0,
      case_LINE_IPC_PERCENT_RT: '',
      wm_CASE_LINE_IPC_PERCENT_RT: '',
      case_LINE_IPC_UNIT_COST_AM: 0,
      case_LINE_IPC_TOTAL_COST_AM: 0,
      case_LINE_IPC_REASON_TX: '',
      fund_CD: '',
      price_ELEMENT_CD: '',
      wm_CASE_LINE_IPC_WAIVER_COST_AM: '',
      fundList: this._fundFullList,
      priceElementList: this._priceElementFullList,
      indirectPricingCompList: this.theIndirectPricingCompList,
      defaultPricingCompList: this.theDefaultPricingCompList,
      theCaseLineIpcStatusCd: {
        case_LINE_IPC_STATUS_CD: '',
      },
      status: DsamsConstants.ENT_UNCHANGED.toString(),
      populatePEFlag: true,
      pouplateFundFlag: true,
      wm_OLD_IPC_NUMBER_ID: '',
      theIpcNumberId: { ipc_NUMBER_ID: '', waiver_ALLOWED_IN: false },
      isFieldDisabled: {
        case_LINE_IPC_PERCENT_RT: true,
        wm_CASE_LINE_IPC_UNIT_COST_AM: true,
        wm_CASE_LINE_IPC_WAIVER_COST_AM: true,
        case_LINE_IPC_REASON_TX: true,
        newIPCRow: pNotNewRow,
        ipc_NUMBER_ID: true,
      },
    })
  }

  resetFormControlValues() {
    this.fcIPC_NUMBER_ID.reset();
    this.fcPRICE_ELEMENT_CD.reset();
    this.fcFUND_CD.reset();
    this.fcCASE_LINE_IPC_STATUS_CD.reset();
  }

  /* This procedure checks the returned result value from the 
      popover Yes/No dialog window. */
  onClickYesDeleteIPC(isDeleteConfirmed: any, rowElement: any) {
    if (isDeleteConfirmed) {
      this.deleteIPC(rowElement);
    }
  }

  //delete existing IPC Row
  deleteIPC(rowElement: any) {
    let rowIndex = this.dataSourceIPCTable.data.indexOf(rowElement);
    this.caseUIService.ipcTabDeleted.next(this.dataSourceIPCTable.data[rowIndex]);
    this.dataSourceIPCTable.data.splice(rowIndex, 1);
    this.caseUIService.ipcTabChanged.next(this.dataSourceIPCTable.data);
    this.dataSourceIPCTable = new MatTableDataSource(this.dataSourceIPCTable.data);
    this.dataSourceIPCTable._updateChangeSubscription();
    this.setChanged(-1);
  }

  //Add a new IPC
  addNewIPC() {
    this.resetFormControlValues();
    this.anEmptyCLIPC = this.InitializeCLIPCDto(false);
    this.anEmptyCLIPC.status = DsamsConstants.ENT_NEW.toString();
    //add new object to the entity list
    this.dataSourceIPCTable.data.push(this.anEmptyCLIPC);
    this.dataSourceIPCTable = new MatTableDataSource(this.dataSourceIPCTable.data);
    //refresh the table
    this.dataSourceIPCTable._updateChangeSubscription();
    //enable all IPC fields
    this.setIPCFieldsState(false, false);
    //override options
    this.dataSourceIPCTable.data.forEach((eachRow) => {
      if (eachRow.status == DsamsConstants.ENT_NEW.toString()) {
        eachRow.caseLineIPCStatusList = JSON.parse(JSON.stringify(this.theCaseLineIPCStatusList));
        eachRow.indirectPricingCompList = Object.assign(this.theIndirectPricingCompList);
        eachRow.isFieldDisabled['case_LINE_IPC_STATUS_CD'] = false;
        eachRow.isFieldDisabled['ipc_NUMBER_ID'] = false;
      }
    });
    this.setChanged(-1);
  }

  //format the amounts for display purposes
  formatDataForDisplay() {
    this.dataSourceIPCTable.data.forEach(eachRow => {
      if (!this.caseLinePkData.primaryCategoryChanged && eachRow.status != DsamsConstants.ENT_NEW.toString()) {
        eachRow.status = DsamsConstants.ENT_UNCHANGED.toString();
      }
      eachRow.wm_OLD_IPC_NUMBER_ID = eachRow.ipc_NUMBER_ID;
      eachRow.wm_CASE_LINE_IPC_WAIVER_COST_AM = formatCurrency(eachRow.case_LINE_IPC_WAIVER_COST_AM, 'en', '$');
      eachRow.wm_CASE_LINE_IPC_UNIT_COST_AM = formatCurrency(eachRow.case_LINE_IPC_UNIT_COST_AM, 'en', '$');
      eachRow.wm_CASE_LINE_IPC_TOTAL_COST_AM = formatCurrency(eachRow.case_LINE_IPC_TOTAL_COST_AM, 'en', '$');
      if (!CaseUtils.isBlankStr(eachRow.case_LINE_IPC_PERCENT_RT)) {
        eachRow.wm_CASE_LINE_IPC_PERCENT_RT = (parseFloat(eachRow.case_LINE_IPC_PERCENT_RT) * 100).toFixed(2).toString();
      }
      eachRow.populatePEFlag = true;
      eachRow.pouplateFundFlag = true;
    })
  }

  //just keep it for now
  populateDynamicIPCStatusList() {
    this.dataSourceIPCTable.data.forEach((eachRow) => {
      if (!!eachRow.indirectPricingCompList) {
        let eachIPCStatus = eachRow.indirectPricingCompList.find(
          value => value.ipc_NUMBER_ID == eachRow.ipc_NUMBER_ID);
        if (!!eachIPCStatus) {
          eachRow.IPCStatusList = this.populateIPCStatusListForAll(eachIPCStatus);
        }
      }
    })
  }

  //break out logic per sonarqube rule
  setWaiverOrPecent(eachIPCStatus: any, eachRow: any, pIPCStatusList: CaseLineIPCStatusDTO[], pWaiver: boolean) {
    if (pWaiver) {
      if (eachIPCStatus.waiver_ALLOWED_IN &&
        (CaseCommonValidator.isEqual(this.caseLinePkData.case_USAGE_INDICATOR_CD, "C") ||
          CaseCommonValidator.isEqual(this.caseLinePkData.case_USAGE_INDICATOR_CD, "P") ||
          CaseCommonValidator.isEqual(this.caseLinePkData.case_USAGE_INDICATOR_CD, "M")))
        pIPCStatusList.push(eachRow);
    }
    else {
      if ((eachIPCStatus.rate_BASED_IN && eachIPCStatus.waiver_ALLOWED_IN) &&
        (CaseCommonValidator.isEqual(this.caseLinePkData.case_USAGE_INDICATOR_CD, "C") ||
          CaseCommonValidator.isEqual(this.caseLinePkData.case_USAGE_INDICATOR_CD, "P") ||
          CaseCommonValidator.isEqual(this.caseLinePkData.case_USAGE_INDICATOR_CD, "M")))
        pIPCStatusList.push(eachRow);
    }
  }

  //break out logic per sonarqube rule
  populateIPCStatusListForAll(eachIPCStatus: any): CaseLineIPCStatusDTO[] {
    var pIPCStatusList: CaseLineIPCStatusDTO[] = [];
    for (let eachRow of this.theCaseLineIPCStatusList) {
      switch (eachRow.case_LINE_IPC_STATUS_CD) {
        case 'NA': {
          pIPCStatusList.push(eachRow);
          break;
        }
        case 'AP': {
          pIPCStatusList.push(eachRow);
          break;
        }
        case 'AX': {
          if (eachIPCStatus.user_ENTERED_CD == 1) pIPCStatusList.push(eachRow);
          break;
        }
        case 'OP': {
          if (eachIPCStatus.rate_BASED_IN) pIPCStatusList.push(eachRow);
          break;
        }
        case 'OC': {
          if (eachIPCStatus.user_ENTERED_CD == 2) pIPCStatusList.push(eachRow);
          break;
        }
        case 'WC': {
          this.setWaiverOrPecent(eachIPCStatus, eachRow, pIPCStatusList, true);
          break;
        }
        case 'WP': {
          this.setWaiverOrPecent(eachIPCStatus, eachRow, pIPCStatusList, false);
          break;
        }
      }
    }
    return pIPCStatusList;
  }

  //do the opposite way
  populateIPCStatusListForNew(eachIPCStatus: any): CaseLineIPCStatusDTO[] {
    var pIPCStatusList: CaseLineIPCStatusDTO[] = [];
    for (let eachRow of this.theCaseLineIPCStatusList) {
      switch (eachRow.case_LINE_IPC_STATUS_CD) {
        case 'NA':
        case 'AP': { pIPCStatusList.push(eachRow); break; }
        case 'AX': {
          if (eachIPCStatus.user_ENTERED_CD == 1) pIPCStatusList.push(eachRow);
          break;
        }
        case 'OP': {
          if (eachIPCStatus.rate_BASED_IN) pIPCStatusList.push(eachRow);
          break;
        }
        case 'OC': {
          if (eachIPCStatus.user_ENTERED_CD == 2) pIPCStatusList.push(eachRow);
          break;
        }
        case 'WC': {
          this.setWaiverOrPecent(eachIPCStatus, eachRow, pIPCStatusList, true);
          break;
        }
        case 'WP': {
          this.setWaiverOrPecent(eachIPCStatus, eachRow, pIPCStatusList, false);
          break;
        }
      }
    }
    return pIPCStatusList;
  }

  //break out logic per sonarqube rule
  spliceWaiverOrPercentRow(eachRow: CaseLineIPCDto, eachIPCStatus: IndirectPricingComponentDTO, 
    pIndex: number, pWaiver: boolean) {
    if (pWaiver) {
      if (!eachIPCStatus.waiver_ALLOWED_IN &&
        (!CaseCommonValidator.isEqual(this.caseLinePkData.case_USAGE_INDICATOR_CD, "C") ||
          !CaseCommonValidator.isEqual(this.caseLinePkData.case_USAGE_INDICATOR_CD, "P") ||
          !CaseCommonValidator.isEqual(this.caseLinePkData.case_USAGE_INDICATOR_CD, "M")))
          eachRow.IPCStatusList.splice(pIndex, 1);
    }
    else {
      if ((!eachIPCStatus.rate_BASED_IN || !eachIPCStatus.waiver_ALLOWED_IN) &&
        (!CaseCommonValidator.isEqual(this.caseLinePkData.case_USAGE_INDICATOR_CD, "C") ||
          !CaseCommonValidator.isEqual(this.caseLinePkData.case_USAGE_INDICATOR_CD, "P") ||
          !CaseCommonValidator.isEqual(this.caseLinePkData.case_USAGE_INDICATOR_CD, "M")))
          eachRow.IPCStatusList.splice(pIndex, 1);
    }
    return false;
  }

  //break out logic per sonarqube rule
  setUpIPCDropdownList(eachRow: CaseLineIPCDto, eachIPCStatus: IndirectPricingComponentDTO) {
    for (let i = eachRow.IPCStatusList.length - 1; i >= 0; i--) {
      switch (eachRow.IPCStatusList[i].case_LINE_IPC_STATUS_CD) {
        case 'OC': {
          if (eachIPCStatus.user_ENTERED_CD == 1) eachRow.IPCStatusList.splice(i, 1);
          break;
        }
        case 'OP': {
          if (!eachIPCStatus.rate_BASED_IN) eachRow.IPCStatusList.splice(i, 1);
          break;
        }
        case 'AX': {
          if (eachIPCStatus.user_ENTERED_CD == 2) eachRow.IPCStatusList.splice(i, 1);
          break;
        }
        case 'WC': {
         this.spliceWaiverOrPercentRow(eachRow, eachIPCStatus, i, true);
          break;
        }
        case 'WP': {
          this.spliceWaiverOrPercentRow(eachRow, eachIPCStatus, i, false);
          break;
        }
      }
    }
  }

  //Jira card 3577-DH - populate IPC list
  populateIPCStatusList() {
    this.dataSourceIPCTable.data.forEach((eachRow) => {
      if (!!eachRow.indirectPricingCompList) {
        let eachIPCStatus = eachRow.indirectPricingCompList.find(
          value => value.ipc_NUMBER_ID == eachRow.ipc_NUMBER_ID);
        if (!!eachIPCStatus) {
          if (eachRow.status == DsamsConstants.ENT_NEW.toString() || this.IsRecalCost) {
            if (!!this.theCaseLineIPCStatusList) this.theCaseLineIPCStatusList =
              JSON.parse(JSON.stringify(eachRow.caseLineIPCStatusList));
            eachRow.IPCStatusList = this.populateIPCStatusListForNew(eachIPCStatus);
          }
          else {
            this.setUpIPCDropdownList(eachRow, eachIPCStatus);
          }
        }
      }
    })
    this.dataSourceIPCTable._updateChangeSubscription();
  }


  //breaout logic per sonarqube rule
  setUpDataForDisplay() {
    this.savedDataSourceIPCListData = JSON.parse(JSON.stringify(this.dataSourceIPCListData));
    //Sort by making sure N/A rows are last.
    this.dataSourceIPCListData.sort((a, b) => (!a.ipc_NUMBER_ID || a.ipc_NUMBER_ID == "" ? "ZZZZZ" : a.ipc_NUMBER_ID)
      .localeCompare(!b.ipc_NUMBER_ID || b.ipc_NUMBER_ID == "" ? "ZZZZZ" : b.ipc_NUMBER_ID));
    this.formatDataForDisplay();
  }

  //populate IPC data for IPC tab
  populateCaseLineIPCDto() {
    if (!this.pricingIpcTabSubscription) {
      this.pricingIpcTabSubscription = this.caseUIService.pricingIpcTabData.subscribe((data: CaseLineIPCDto[]) => {
        if (!!data) {
          this.dataSourceIPCListData = data;
          this.setUpDataForDisplay();
          this.dataSourceIPCTable = new MatTableDataSource(this.dataSourceIPCListData);
          this.dataSourceIPCTable.data.forEach((eachRow) => {
            eachRow.isFieldDisabled = { ipc_NUMBER_ID: (eachRow.status != DsamsConstants.ENT_NEW.toString() || !this.isIPCPanelEditable) };
            eachRow.priceElementList = Object.assign(this.thePriceElementList);
            eachRow.fundList = Object.assign(this.theFundList);
            eachRow.caseLineIPCStatusList = JSON.parse(JSON.stringify(this.theCaseLineIPCStatusList));
            eachRow.indirectPricingCompList = Object.assign(this.theIndirectPricingCompList);
            eachRow.IPCStatusList = eachRow.caseLineIPCStatusList;
          })
          this.populateIPCStatusList();
          this.setIPCFieldsState(!this.isIPCPanelEditable, true);
          this.isLoading.next(false);
        }
        else {
          this.dataSourceIPCListData = [];
          this.dataSourceIPCListData.push(this.InitializeCLIPCDto(true));
          this.dataSourceIPCTable = new MatTableDataSource(this.dataSourceIPCListData);
          this.isLoading.next(false);
        }
      });
    }
  }

  // Text area popup
  popupTextAreaOpen(pElement: any, pIndex: number): void {
    let diaWidth: string = "50%";
    let diaHeight: string = "60%";
    let passingData: string = pElement.case_LINE_IPC_REASON_TX;
    let pTitle: string = "IPC Description";
    this._textIndex = pIndex;
    this.dsamsDialogMsgService.openTextAreaIpcDialog(diaWidth, diaHeight, passingData,
      TextAreaComponent, pIndex.toString(), pTitle,
      !this.isIPCPanelEditable);
  }

  // Subscribe to Text Area Dialog Save
  private subscribeToTextAreaDialog() {
    this.textAreaSubscription = this.dsamsDialogMsgService.textAreaFromIpcDialog.subscribe((textAreaValue: string) => {
      setTimeout(() => {
        if (!!this.dataSourceIPCTable.data[this._textIndex]) {
          this.dataSourceIPCTable.data[this._textIndex].case_LINE_IPC_REASON_TX = textAreaValue;
          this.dataSourceIPCTable._updateChangeSubscription();
          this.setChanged(this._textIndex);
        }
      }, 0);
    });
  }

  fixupTargetPct(pValue: string): string {
    return CaseUtils.fixupNumber(pValue);
  }

  //Jira card 3577-DH-Enable/Disable relevant IPC Status fields
  onChangeStatus(pStatusCd: CaseLineIPCStatusDTO, pIndex: number) {
    this.dataSourceIPCTable.data[pIndex].isFieldDisabled['case_LINE_IPC_STATUS_CD'] = false;
    this.dataSourceIPCTable.data[pIndex].isFieldDisabled['case_LINE_IPC_PERCENT_RT'] = true;
    this.dataSourceIPCTable.data[pIndex].isFieldDisabled['wm_CASE_LINE_IPC_UNIT_COST_AM'] = true;
    this.dataSourceIPCTable.data[pIndex].isFieldDisabled['wm_CASE_LINE_IPC_WAIVER_COST_AM'] = true;
    this.dataSourceIPCTable.data[pIndex].isFieldDisabled['case_LINE_IPC_REASON_TX'] = true;
    let aStatusCd = this.dataSourceIPCTable.data[pIndex].caseLineIPCStatusList.find(
      statusCd => statusCd.case_LINE_IPC_STATUS_CD == pStatusCd.case_LINE_IPC_STATUS_CD);
    if (!!aStatusCd) {
      this.dataSourceIPCTable.data[pIndex].case_LINE_IPC_STATUS_CD = aStatusCd.case_LINE_IPC_STATUS_CD;
      this.setSpecificFieldsState(aStatusCd.case_LINE_IPC_STATUS_CD, pIndex);
      this.setChanged(pIndex);
    }
    this.dataSourceIPCTable._updateChangeSubscription();
  }

  onChangeIPC_NUMBER_ID(pElement: any, pSelectedIpc: IndirectPricingComponentDTO, pIndex: number) {
    pElement.ipc_NUMBER_ID = pSelectedIpc.ipc_NUMBER_ID;
    // Get the IPC Number based on the value the user selected.
    for (let currIpc of this.theIndirectPricingCompList) {
      if (pElement.ipc_NUMBER_ID === currIpc.ipc_NUMBER_ID) {
        pElement.theIpcNumberId = currIpc;
      }
    }
    this.dataSourceIPCTable.data[pIndex].isFieldDisabled['case_LINE_IPC_STATUS_CD'] = false;
    //Jira 3577
    this.populateIPCStatusList();
    this.setChanged(pIndex);
    this.dataSourceIPCTable._updateChangeSubscription();
  }

  //breakout per sonarque rule
  setRelevantFieldEditAbility(pCode: string, pIndex: number, pUserEnterCode: number) {
    switch (pCode) {
      case "AP": {
        if (pUserEnterCode == 1 &&
          this.dataSourceIPCTable.data[pIndex].status == DsamsConstants.ENT_NEW.toString()) {
          this.dataSourceIPCTable.data[pIndex].isFieldDisabled['wm_CASE_LINE_IPC_UNIT_COST_AM'] = false;
        }
        this.dataSourceIPCTable.data[pIndex].isFieldDisabled['case_LINE_IPC_REASON_TX'] = false;
        break;
      }
      case "AX": {
        if ((pUserEnterCode == 1 &&
          this.dataSourceIPCTable.data[pIndex].status == DsamsConstants.ENT_NEW.toString()) ||
          this.dataSourceIPCTable.data[pIndex].status !== DsamsConstants.ENT_NEW.toString()) {
          this.dataSourceIPCTable.data[pIndex].isFieldDisabled['case_LINE_IPC_PERCENT_RT'] = false;
          this.dataSourceIPCTable.data[pIndex].isFieldDisabled['wm_CASE_LINE_IPC_UNIT_COST_AM'] = false;
        }
        this.dataSourceIPCTable.data[pIndex].isFieldDisabled['case_LINE_IPC_REASON_TX'] = false;
        break;
      }
      case "WP":
      case "OP": {
        if ((pUserEnterCode == 2 &&
          this.dataSourceIPCTable.data[pIndex].status == DsamsConstants.ENT_NEW.toString()) ||
          this.dataSourceIPCTable.data[pIndex].status !== DsamsConstants.ENT_NEW.toString()) {
          this.dataSourceIPCTable.data[pIndex].isFieldDisabled['case_LINE_IPC_PERCENT_RT'] = false;
        }
        this.dataSourceIPCTable.data[pIndex].isFieldDisabled['case_LINE_IPC_REASON_TX'] = false;
        break;
      }
    }
  }

  //break out logic per sonarqube rule
  setPercent(pCode: string, pIndex: number, aUserEnterCode: IndirectPricingComponentDTO) {
    if (!!aUserEnterCode)
      this.setRelevantFieldEditAbility(pCode, pIndex, aUserEnterCode.user_ENTERED_CD);
  }

  //Jira card 3577-DH-Override edit rules
  setSpecificFieldsState(pCode: string, pIndex: number) {
    if (!!this.dataSourceIPCTable.data[pIndex].indirectPricingCompList) {
      let ipcNumberId = this.dataSourceIPCTable.data[pIndex].ipc_NUMBER_ID;
      let aUserEnterCode = this.dataSourceIPCTable.data[pIndex].indirectPricingCompList.find(value => value.ipc_NUMBER_ID == ipcNumberId);
      this.dataSourceIPCTable.data[pIndex].theIpcNumberId = aUserEnterCode;
      this.dataSourceIPCTable.data[pIndex].isFieldDisabled['ipc_NUMBER_ID'] = (this.dataSourceIPCTable.data[pIndex].status != DsamsConstants.ENT_NEW.toString());
      switch (pCode) {
        case "AX":
        case "AP":
        case "WP":
        case "OP": {
          this.setPercent(pCode, pIndex, aUserEnterCode);
          break;
        }
        case "OC": {
          if ((aUserEnterCode.user_ENTERED_CD == 2 &&
            this.dataSourceIPCTable.data[pIndex].status == DsamsConstants.ENT_NEW.toString()) ||
            this.dataSourceIPCTable.data[pIndex].status !== DsamsConstants.ENT_NEW.toString()) {
            this.dataSourceIPCTable.data[pIndex].isFieldDisabled['wm_CASE_LINE_IPC_UNIT_COST_AM'] = false;
          }
          this.dataSourceIPCTable.data[pIndex].isFieldDisabled['case_LINE_IPC_REASON_TX'] = false;
          break;
        }
        case "WC": {
          if (this.dataSourceIPCTable.data[pIndex].status !== DsamsConstants.ENT_NEW.toString()) {
            this.dataSourceIPCTable.data[pIndex].isFieldDisabled['wm_CASE_LINE_IPC_WAIVER_COST_AM'] = false;
          }
          else if (aUserEnterCode.user_ENTERED_CD == 1 &&
            this.dataSourceIPCTable.data[pIndex].status == DsamsConstants.ENT_NEW.toString()) {
            this.dataSourceIPCTable.data[pIndex].isFieldDisabled['wm_CASE_LINE_IPC_WAIVER_COST_AM'] = false;
            this.dataSourceIPCTable.data[pIndex].isFieldDisabled['wm_CASE_LINE_IPC_UNIT_COST_AM'] = false;
          }
          this.dataSourceIPCTable.data[pIndex].isFieldDisabled['case_LINE_IPC_REASON_TX'] = false;
          break;
        }
        default: {
          this.dataSourceIPCTable.data[pIndex].isFieldDisabled['case_LINE_IPC_REASON_TX'] = false;
          break;
        }
      }
    }
  }

  //Jira card 3577-DH-Enable IPC status and its related fields
  setStatusFieldState(pValue: boolean) {
    if (!!this.dataSourceIPCTable.data) {
      this.dataSourceIPCTable.data.forEach((eachRow, index) => {
        if (!!eachRow.isFieldDisabled)
          eachRow.isFieldDisabled['case_LINE_IPC_STATUS_CD'] = pValue;
        if (this.isIPCPanelEditable)
          this.setSpecificFieldsState(eachRow.case_LINE_IPC_STATUS_CD, index);
        else this.setIPCFieldsState(true, true);
      });
    }
  }

  //Jira card 3577-DH-Enable/disable IPC related fields
  setIPCFieldsState(pValue: boolean, pNotNewRow: boolean) {
    this.dataSourceIPCTable.data.forEach((eachRow, index) => {
      eachRow.isFieldDisabled = {
        case_LINE_IPC_STATUS_CD: pValue,
        case_LINE_IPC_PERCENT_RT: true,
        wm_CASE_LINE_IPC_UNIT_COST_AM: true,
        wm_CASE_LINE_IPC_WAIVER_COST_AM: true,
        case_LINE_IPC_REASON_TX: true,
        ipc_NUMBER_ID: true,
        newIPCRow: pNotNewRow,
      };
      //override state of each applicable field in Edit mode
      if (this.isIPCPanelEditable)
        this.setSpecificFieldsState(eachRow.case_LINE_IPC_STATUS_CD, index);
    })
  }

  setChanged(pIndex: number) {
    // If -1 then we have a new rec.
    if (pIndex >= 0 && (!this.dataSourceIPCTable.data[pIndex].status || this.dataSourceIPCTable.data[pIndex].status === DsamsConstants.ENT_UNCHANGED.toString())) {
      this.dataSourceIPCTable.data[pIndex].status = DsamsConstants.ENT_CHANGED.toString();
      this.caseUIService.theComponentSaveCaseLineState[CaseUIService.SAVE_CASE_LINE_PRICING_STATE].isDataChanged = true;
    }
    this.caseUIService.ipcTabChanged.next(this.dataSourceIPCTable.data);
  }

  onChangeCASE_LINE_IPC_PERCENT_RT(pValue: string, pIndex: number) {
    if (!pValue || pValue == "") {
      this.dataSourceIPCTable.data[pIndex].case_LINE_IPC_PERCENT_RT = "";
      this.dataSourceIPCTable.data[pIndex].wm_CASE_LINE_IPC_PERCENT_RT = "";
    }
    else {
      this.dataSourceIPCTable.data[pIndex].case_LINE_IPC_PERCENT_RT = (+CaseUtils.fixupNumber(pValue) / 100).toString();
      this.dataSourceIPCTable.data[pIndex].wm_CASE_LINE_IPC_PERCENT_RT = (parseFloat(pValue)).toFixed(2).toString();
    }
    this.setChanged(pIndex);
  }

  // Rerun populate list.
  private subscribeToPostSave() {
    this.postSaveSubscription = this.caseUIService.pricingPostSave.subscribe((pClc: caseLineComponentDto) => {
      if (!!pClc) {
        this.caseLinePkData.case_LINE_COMPONENT_ID = pClc.case_LINE_COMPONENT_ID;
        this.caseLinePkData.primaryCategoryChanged = false;
        //
        this.caseUIService.pricingIpcTabData.next(pClc.caseLineIpcList);
        this.resetFormControlValues();
      }
    });
  }

  //jira 4138-DH
  private subscribeToPostRecal() {
    this.postRecalSubscription = this.caseUIService.pricingPostRecal.subscribe((pClc: caseLineComponentDto) => {
      this.caseLinePkData.case_LINE_COMPONENT_ID = pClc.case_LINE_COMPONENT_ID;
      this.caseLinePkData.primaryCategoryChanged = false;
      this.dataSourceIPCListData = [];   // Clear out results first.
      for (let eachRow of pClc.caseLineIpcList) {
        eachRow.isFieldDisabled = {
          case_LINE_IPC_STATUS_CD: true,
          case_LINE_IPC_PERCENT_RT: true,
          wm_CASE_LINE_IPC_UNIT_COST_AM: true,
          wm_CASE_LINE_IPC_WAIVER_COST_AM: true,
          case_LINE_IPC_REASON_TX: true,
          ipc_NUMBER_ID: (eachRow.status != DsamsConstants.ENT_NEW.toString() || !this.isIPCPanelEditable),
          newIPCRow: true,
        };
        eachRow.caseLineIPCStatusList = JSON.parse(JSON.stringify(this.theCaseLineIPCStatusList));
        eachRow.indirectPricingCompList = Object.assign(this.theIndirectPricingCompList);
        eachRow.IPCStatusList = JSON.parse(JSON.stringify(this.theCaseLineIPCStatusList));
        if (eachRow.status !== DsamsConstants.ENT_NEW.toString())
          eachRow.status = DsamsConstants.ENT_CHANGED.toString();
        this.dataSourceIPCListData.push(eachRow);
      }
      this.dataSourceIPCTable = new MatTableDataSource(this.dataSourceIPCListData);
      this.formatDataForDisplay();
      this.resetFormControlValues();
      if (this.caseLinePkData.primaryCategoryChanged) {
        this.setChanged(-1);
        this.caseUIService.ipcTabChanged.next(this.dataSourceIPCTable.data);
      }
      this.IsRecalCost = true;
      this.populateIPCStatusList();
      this.IsRecalCost = false;
      this.setStatusFieldState(false);
      this.dataSourceIPCTable._updateChangeSubscription();
    });
  }

  setWaiverCost(pValue: string, pIndex: number) {
    this.dataSourceIPCTable.data[pIndex].case_LINE_IPC_WAIVER_COST_AM = +(CaseUtils.unformatCurrency(CaseUtils.fixupNumber(pValue)));
    this.dataSourceIPCTable.data[pIndex].wm_CASE_LINE_IPC_WAIVER_COST_AM = formatCurrency(this.dataSourceIPCTable.data[pIndex].case_LINE_IPC_WAIVER_COST_AM, 'en', '$');
    this.setChanged(pIndex);
  }

  waiverCostOnFocus(pElement: any) {
    if (!pElement.wm_CASE_LINE_IPC_WAIVER_COST_AM) {
      pElement.wm_CASE_LINE_IPC_WAIVER_COST_AM = '';
    }
  }

  // Change the fund code list according to what the user selects in the price element.
  populateFundList(pPriceElementCd: string, pIndex: number) {
    if (this.dataSourceIPCTable.data[pIndex].populatePEFlag || !this.dataSourceIPCTable.data[pIndex].fund_CD || this.dataSourceIPCTable.data[pIndex].fund_CD === "") {
      const filterdPriceElementFundArray: FundDTO[] = this.theFundList.filter(elem => {
        return (!pPriceElementCd || pPriceElementCd === "" || !elem.fund_CD || elem.fund_CD === "" || this._componentPriceElementFundString.indexOf("*" + elem.fund_CD + "@" + pPriceElementCd + "*") >= 0);
      });
      this.dataSourceIPCTable.data[pIndex].fundList = [];
      for (let dropdown of filterdPriceElementFundArray) {
        this.dataSourceIPCTable.data[pIndex].fundList.push({ fund_CD: dropdown.fund_CD, fund_TITLE_NM: dropdown.fund_TITLE_NM });
      }
      this.dataSourceIPCTable.data[pIndex].fund_CD = "";
    }
    if (!pPriceElementCd || pPriceElementCd === "") {
      this.dataSourceIPCTable.data[pIndex].priceElementList = this._priceElementFullList;
    }
    this.setChanged(pIndex);
    this.fcFUND_CD.reset();
    this.dataSourceIPCTable.data[pIndex].populatePEFlag = true;
    this.dataSourceIPCTable.data[pIndex].pouplateFundFlag = false;
  }


  // Change PE list according to the fund code value.
  populatePriceElementList(pFundCd: string, pIndex: number) {
    if (this.dataSourceIPCTable.data[pIndex].pouplateFundFlag || !this.dataSourceIPCTable.data[pIndex].price_ELEMENT_CD || this.dataSourceIPCTable.data[pIndex].price_ELEMENT_CD === "") {
      const filterdPriceElementPEArray: PriceElementDTO[] = this.thePriceElementList.filter(elem => {
        return (!pFundCd || pFundCd === "" || !elem.price_ELEMENT_CD || elem.price_ELEMENT_CD === "" || this._componentPriceElementFundString.indexOf("*" + pFundCd + "@" + elem.price_ELEMENT_CD + "*") >= 0);
      });
      this.dataSourceIPCTable.data[pIndex].priceElementList = [];
      for (let dropdown of filterdPriceElementPEArray) {
        this.dataSourceIPCTable.data[pIndex].priceElementList.push({ price_ELEMENT_CD: dropdown.price_ELEMENT_CD, price_ELEMENT_TITLE_NM: dropdown.price_ELEMENT_TITLE_NM });
      }
      this.dataSourceIPCTable.data[pIndex].price_ELEMENT_CD = "";
    }
    if (!pFundCd || pFundCd === "") {
      this.dataSourceIPCTable.data[pIndex].fundList = this._fundFullList;
    }
    this.setChanged(pIndex);
    this.fcPRICE_ELEMENT_CD.reset();
    this.dataSourceIPCTable.data[pIndex].populatePEFlag = false;
    this.dataSourceIPCTable.data[pIndex].pouplateFundFlag = true;
  }

  //Jira card 4217-DH
  onChangeUnitCost(pValue: string, pIndex: number) {
    this.dataSourceIPCTable.data[pIndex].case_LINE_IPC_UNIT_COST_AM = +(CaseUtils.unformatCurrency(CaseUtils.fixupNumber(pValue)));
    this.dataSourceIPCTable.data[pIndex].wm_CASE_LINE_IPC_UNIT_COST_AM = formatCurrency(this.dataSourceIPCTable.data[pIndex].case_LINE_IPC_UNIT_COST_AM, 'en', '$');

    //FR53 - If IPC Unit Cost and Base Unit Price are provided, 
    // then the AX percentage is calculated; otherwise, the IPC Percentage is set to NULL.
    if ((CaseUtils.isBlankStr(this.dataSourceIPCTable.data[pIndex].case_LINE_IPC_UNIT_COST_AM) ||
      this.dataSourceIPCTable.data[pIndex].case_LINE_IPC_UNIT_COST_AM == 0.0) &&
      (!CaseUtils.isBlankStr(this.caseLinePkData.component_UNIT_BASE_PRICE_AM) ||
        (this.caseLinePkData.component_UNIT_BASE_PRICE_AM == 0.0))) {
      this.dataSourceIPCTable.data[pIndex].case_LINE_IPC_PERCENT_RT = '';
    }

    if (CaseUtils.isBlankStr(this.dataSourceIPCTable.data[pIndex].case_LINE_IPC_UNIT_COST_AM) ||
      this.dataSourceIPCTable.data[pIndex].case_LINE_IPC_UNIT_COST_AM == 0.0) {
      //do this for blank ipc unit costs
      this.dataSourceIPCTable.data[pIndex].case_LINE_IPC_TOTAL_COST_AM = 0;
      this.dataSourceIPCTable.data[pIndex].wm_CASE_LINE_IPC_TOTAL_COST_AM =
        formatCurrency(this.dataSourceIPCTable.data[pIndex].case_LINE_IPC_TOTAL_COST_AM, 'en', '$');
      return (this.dataSourceIPCTable.data[pIndex].case_LINE_IPC_UNIT_COST_AM);
    }
    else {
      let aStatusCd: string = this.dataSourceIPCTable.data[pIndex].case_LINE_IPC_STATUS_CD;
      this.computeIPCTotalCost(aStatusCd, pIndex, this.dataSourceIPCTable.data[pIndex].case_LINE_IPC_UNIT_COST_AM);
      this.computeAXPercentage(pIndex, this.dataSourceIPCTable.data[pIndex].case_LINE_IPC_UNIT_COST_AM);
    }
    this.setChanged(pIndex);
    this.dataSourceIPCTable._updateChangeSubscription();
  }

  //Jira card 4217-DH
  computeIPCTotalCost(pCode: string, pIndex: number, pUnitCost: number) {
    //  Compute IPC Total Cost only for IPC Status of OP,AP or AX.
    if (pCode == "OC" || pCode == "AP" || pCode == "AX") {
      if (!CaseUtils.isBlankStr(this.caseLinePkData.case_LINE_COMPONENT_QY) &&
        !CaseUtils.isBlankStr(pUnitCost)) {
        this.dataSourceIPCTable.data[pIndex].case_LINE_IPC_TOTAL_COST_AM =
          pUnitCost * this.caseLinePkData.case_LINE_COMPONENT_QY;
        this.dataSourceIPCTable.data[pIndex].wm_CASE_LINE_IPC_TOTAL_COST_AM =
          formatCurrency(this.dataSourceIPCTable.data[pIndex].case_LINE_IPC_TOTAL_COST_AM, 'en', '$');
      }
    }
  }

  //Jira card 4217-DH
  computeAXPercentage(pIndex: number, pUnitCost: number) {
    if (!CaseUtils.isBlankStr(this.caseLinePkData.component_UNIT_BASE_PRICE_AM)) {
      if (this.caseLinePkData.component_UNIT_BASE_PRICE_AM !== 0.0) {
        let computedPercentage: number = pUnitCost / this.caseLinePkData.component_UNIT_BASE_PRICE_AM;
        if (!CaseUtils.isBlankStr(computedPercentage)) {
          this.dataSourceIPCTable.data[pIndex].case_LINE_IPC_PERCENT_RT = computedPercentage.toFixed(2).toString();
          this.dataSourceIPCTable.data[pIndex].wm_CASE_LINE_IPC_PERCENT_RT = (parseFloat(this.dataSourceIPCTable.data[pIndex].case_LINE_IPC_PERCENT_RT) * 100).toFixed(2).toString();
        }
      }
    }
  }
}
