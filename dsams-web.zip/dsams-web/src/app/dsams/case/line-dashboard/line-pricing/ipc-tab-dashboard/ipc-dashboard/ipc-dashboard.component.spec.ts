import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IpcDashboardComponent } from './ipc-dashboard.component';

describe('IpcDashboardComponent', () => {
  let component: IpcDashboardComponent;
  let fixture: ComponentFixture<IpcDashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IpcDashboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IpcDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
