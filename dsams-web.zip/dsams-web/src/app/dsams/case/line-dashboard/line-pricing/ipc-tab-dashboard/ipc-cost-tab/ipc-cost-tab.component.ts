import { Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { CaseLinePK } from 'src/app/dsams/case/model/case-line-pk';
import { CaseRestfulService } from 'src/app/dsams/case/services/case-restful.service';
import { CaseUIService } from 'src/app/dsams/case/services/case-ui-service';
import { CaseUtils } from 'src/app/dsams/case/utils/case-utils';
import { FundDTO, FiscalYearDTO } from '../model/dto/case-line-ipc-dto';
import { ISelectOptions } from 'src/app/dsams/interfaces/i-select-options';
import { caseLineComponentModel } from 'src/app/dsams/case/model/case-line-component-model';
import { IEditResponseType } from 'src/app/dsams/case/model/edit-response-type';
import { DsamsConstants } from 'src/app/dsams/dsams.constants';
import { take } from 'rxjs/operators';

@Component({
  selector: 'app-ipc-cost-tab',
  templateUrl: './ipc-cost-tab.component.html',
  styleUrls: ['./ipc-cost-tab.component.css']
})
export class IpcCostTabComponent implements OnInit {
  naString: string = 'N/A';
  caseLinePkData: CaseLinePK;
  testbase_FISCAL_YEAR_ID: string = '';
  theCLCData: caseLineComponentModel = {};
  wm_PRICE_YEAR_NM: string = this.naString;
  isIPCCostTabEditable: boolean = false;

  //Static dropdown List
  theFundList: FundDTO[] = [];
  theFYList: FiscalYearDTO[] = [];
  //Base Unit Pice Year options
  theBaseUnitPriceYearList: ISelectOptions[] = [
    { value: '1', viewValue: 'Base Fiscal Year' },
    { value: '2', viewValue: 'Then Fiscal Year' }
  ];

  private caseLineIPCSubscription: Subscription = null;
  private editSubscription: Subscription = null;

  constructor(private caseUIService: CaseUIService,
    private caseLineIPCRestService: CaseRestfulService) { }

  ngOnInit() {
    if (this.theFYList.length == 0 || this.theFundList.length == 0) {
      this.populateReferenceData();
    }
    if (!this.caseLineIPCSubscription) {
      this.caseLineIPCSubscription = this.caseUIService.getCaseLinePK().subscribe((data) => {
        this.caseLinePkData = data;
        this.theCLCData = data;
        this.wm_PRICE_YEAR_NM = null;
        //override when applicable
        if (!CaseUtils.isBlankStr(this.theCLCData.price_YEAR_CD)) 
          this.wm_PRICE_YEAR_NM = this.theBaseUnitPriceYearList.find(fy => fy.value == this.theCLCData.price_YEAR_CD.toString()).viewValue;
      });
    }
    this.subscribeToEditService();
  }

  // Destroy any non-HTTP subscriptions
  ngOnDestroy(): void {
    if (this.caseLineIPCSubscription) {
      this.caseLineIPCSubscription.unsubscribe();
      this.caseLineIPCSubscription = null;
    }
    if (this.editSubscription) {
      this.editSubscription.unsubscribe();
      this.editSubscription = null;
    }
  }

  //get specific Ref data
  populateReferenceData() {
    this.caseLineIPCRestService.getCLIPCCostRefData().pipe(take(1)).subscribe(
      refData => {
        this.theFundList = refData.fundList;
        this.theFYList = refData.fiscalYearList;
      })
  }

  // Subscribe to edit service
  private subscribeToEditService() {
    this.editSubscription = this.caseUIService.caseEditService.subscribe((pEditResult: IEditResponseType) => {
      if (!!pEditResult && pEditResult.ID === DsamsConstants.CASE_LINE_EDITOR) {
        this.isIPCCostTabEditable = pEditResult.editToggle;
      }
    });
  }

  fixupStorageField(pValue: string): number {
    return (pValue === "" || isNaN(+pValue)) ? 0 : +pValue;
  }

  setChanged() {
    this.caseUIService.cbTabChanged.next(this.theCLCData);
    this.caseUIService.theComponentSaveCaseLineState[CaseUIService.SAVE_CASE_LINE_PRICING_STATE].isDataChanged = true;
  }
}
