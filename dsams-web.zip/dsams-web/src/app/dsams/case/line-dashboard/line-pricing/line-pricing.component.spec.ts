import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LinePricingComponent } from './line-pricing.component';

describe('LinePricingComponent', () => {
  let component: LinePricingComponent;
  let fixture: ComponentFixture<LinePricingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LinePricingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LinePricingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
