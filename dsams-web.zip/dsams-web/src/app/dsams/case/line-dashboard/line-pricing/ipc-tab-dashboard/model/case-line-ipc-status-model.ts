export interface CaseLineIPCStatusModel {
    ipc_NUMBER_ID?: string,
    case_LINE_IPC_STATUS_CD?: string,
    case_LINE_IPC_STATUS_NM?: string,
    case_LINE_IPC_STATUS_TX?: string,
}