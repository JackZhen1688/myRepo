import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SupplementalNoteTabComponent } from './supplemental-note-tab.component';

describe('SupplementalNoteTabComponent', () => {
  let component: SupplementalNoteTabComponent;
  let fixture: ComponentFixture<SupplementalNoteTabComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SupplementalNoteTabComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SupplementalNoteTabComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
