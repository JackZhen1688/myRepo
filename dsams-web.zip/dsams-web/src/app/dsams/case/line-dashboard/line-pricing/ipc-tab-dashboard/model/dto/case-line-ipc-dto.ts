import { fundDto, priceElementDto } from "src/app/dsams/case/model/dto/case-line-component-dto";
import { FieldDisabledMap } from "src/app/dsams/case/model/field-disabled-map";
import { CaseLineIPCModel } from "../case-line-ipc-model";
import { IndirectPricingComponentModel } from "../indirect-pricing-component-model";
import { DefaultPricingComponentDTO } from "./default-pricing-compoenet-dto";

export interface PriceElementDTO {
    price_ELEMENT_CD?: string,
    price_ELEMENT_TITLE_NM?: string,
}

//DH: since more attributes are needed, just inherit from the model class
export interface IndirectPricingComponentDTO
    extends IndirectPricingComponentModel { }
export interface FundDTO {
    fund_CD?: string,
    fund_TITLE_NM?: string,
}

export interface PriceElementFundDTO {
    fund_CD?: string,
    price_ELEMENT_CD?: string
}

export interface CaseLineIPCStatusDTO {
    case_LINE_IPC_STATUS_NM?: string,
    case_LINE_IPC_STATUS_CD?: string,
}

export interface FiscalYearDTO {
    fiscal_YEAR_ID?: string,
    fiscal_YEAR_TITLE_NM?: string,
}
export interface CaseLineIPCDto extends CaseLineIPCModel {
    //window mapping attributes
    wm_CASE_LINE_IPC_WAIVER_COST_AM?: string,
    wm_CASE_LINE_IPC_UNIT_COST_AM?: string,
    wm_CASE_LINE_IPC_TOTAL_COST_AM?: string,
    wm_CASE_LINE_IPC_PERCENT_RT?: string,
    case_ID?: number,
    case_MASTER_LINE_ID?: number,
    working_CASE_ID?: number,
    working_CASE_VERSION_ID?: number,
    theIpcNumberId?: IndirectPricingComponentDTO,
    IPCStatusList?: Array<CaseLineIPCStatusDTO>,
    caseLineIPCStatusList?: Array<CaseLineIPCStatusDTO>,
    fundList?: Array<fundDto>,
    priceElementList?: Array<priceElementDto>,
    indirectPricingCompList?: Array<IndirectPricingComponentDTO>,
    defaultPricingCompList?: Array<DefaultPricingComponentDTO>,
    populatePEFlag?: boolean,
    pouplateFundFlag?: boolean,
    isFieldDisabled?: FieldDisabledMap,
    wm_OLD_IPC_NUMBER_ID?: string,
    primary_CATEGORY_CD?: string,
    dpc_IN?:boolean,
    theCaseLineIpcStatusCd?: CaseLineIPCStatusDto
}

export interface CaseLineIPCStatusDto {
    case_LINE_IPC_STATUS_CD: string
}