export interface IndirectPricingComponentModel {
    entityName?: string;
    status?: string;

    ipc_NUMBER_ID?: string,
    dollar_FACTOR_CD?: number,
    formula_DESCRIPTION_TX?: string,
    ipc_CATEGORY_CD?: string,
    ipc_DESCRIPTION_TX?: string,
    ipc_TITLE_NM?: string,
    rate_BASED_IN?: boolean,
    revision_IPC_IN?: boolean,
    target_VALUE_IPC_IN?: boolean,
    user_ENTERED_CD?: number,
    waiver_ALLOWED_IN?: boolean,
}
