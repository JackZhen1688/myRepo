export interface DefaultPricingComponentModel {
    entityName?: string;
    status?: string;

    ipc_NUMBER_ID?: string,
    fund_CD?: string,
    price_ELEMENT_CD?: string,
}