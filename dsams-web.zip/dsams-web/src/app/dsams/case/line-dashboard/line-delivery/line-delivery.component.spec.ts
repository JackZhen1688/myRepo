import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LineDeliveryComponent } from './line-delivery.component';

describe('LineDeliveryComponent', () => {
  let component: LineDeliveryComponent;
  let fixture: ComponentFixture<LineDeliveryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LineDeliveryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LineDeliveryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
