/* This class is used to handle all common business logic for 
   the Line  page.
   Author: David Huynh 
   Date:   10/28/2020 
*/

import { DsamsConstants } from '../../dsams.constants';
import { ifaceCaseLineData, ifaceCaseLineEntity, ifaceCaseMasterLineEntity } from '../model/case-line-model';
import { CaseLineRelatedInfoType } from '../model/case-line-related-info-type';
import { CaseRelatedInfoType, ifaceCaseLineAssistanceTypeEntity, ifaceCaseLineDeliveryItemEntity, ifaceCaseLineDeliveryScheduleEntity, ifaceCaseLineDeliveryTermEntity, ifaceCaseLineOfferReleaseEntity } from '../model/case-related-info-type';
import { CaseUtils } from '../utils/case-utils';
import { DateValidator } from '../validation/date-validator';
import { IMilitaryArticleServiceList } from '../model/dto/military-article-service-list';
import { ErrorParameter } from '../../entities/specialEntities/error-parameter.model';
import { MessageType } from '../../enums/user-message.enum';
import { DialogMessageListComponentTc } from '../../utilitis/dialogs/dialog-message-list-tc/dialog-message-list-tc.component';
import { CaseCommonValidator } from '../validation/case-common-validator';
import { MessageMgr } from '../validation/message-mgr';
import { SweetAlertResult } from 'sweetalert2';
// begin DSAMS-5212 03/22 dB
import { CaseRestfulService } from '../services/case-restful.service';
// end DSAMS-5212 03/22 DB


export class LineUtils {
    static areMandatoryFieldsValidForLineDetails(caseLineInfoData: ifaceCaseLineData): boolean {
        throw new Error('Method not implemented.');
    }
    public static CHANGE_ACTION_DELETED: string = "D";
    public static CHANGE_ACTION_CD_ADDED: string = "A";
    public static CHANGE_ACTION_CD_CHANGED: string = "C"
    public static CHANGE_ACTION_UNAFFECTED: string = "U";
    public static CHANGE_ACTION_RESTATED: string = "R";
    public static UNIT_OF_ISSUE_XX: string = "XX";
    public static LINE_PURPOSE_CE: string = "CE";
    public static LINE_PURPOSE_TR: string = "TR";
    public static CUSTOMER_TYPE_PS: string = "PS";
    public static OPERATING_AGENCY_X: string = "X";
    public static MASL_SMALLCASESUPT: string = "SMALLCASESUPT";
    public static SUPPLY_SOURCE_EDA: string = "E";
    public static SUPPLY_SOURCE_MIXED: string = "X";
    public static CASE_CATEGORY_CD_FMSOI: string = "FMSOI";
    public static CASE_LINE_CATEGORY: string = "Case Line";
    public static PSCaseMessage: string =
        "This is a 36(b), Congressional Notification document. Please ensure that no references are made to classified information! ";
    //Line Delivery/Details deleted entity arrays
    public static theDeletedCLDSListArray: ifaceCaseLineDeliveryScheduleEntity[];
    public static theDeletedCLDIListArray: ifaceCaseLineDeliveryItemEntity[];
    public static theDeletedCLDTListArray: ifaceCaseLineDeliveryTermEntity[];
    public static theDeletedCLORListArray: ifaceCaseLineOfferReleaseEntity[];
    public static theDeletedCLATListArray: ifaceCaseLineAssistanceTypeEntity[];

    //This function returns the case line entity that has been mapped with proper passing data 
    //required for use with legacy Data Manager.
    public static getMappingCaseLineEntityForFinancial(pCaseLineData: ifaceCaseLineData): ifaceCaseLineEntity {
        const aCaseLineEntity: ifaceCaseLineEntity = {
            service_DB_ID: CaseUtils.getServiceDatabaseId(),
            case_ID: pCaseLineData.case_ID,
            case_MASTER_LINE_ID: pCaseLineData.case_MASTER_LINE_ID,
            working_CASE_ID: pCaseLineData.working_CASE_ID,
            working_CASE_VERSION_ID: pCaseLineData.working_CASE_VERSION_ID,
            case_VERSION_ID: pCaseLineData.case_VERSION_ID,
            case_LINE_ITEM_QY: pCaseLineData.case_LINE_ITEM_QY,
            change_ACTION_CD: pCaseLineData.change_ACTION_CD,
            line_PURPOSE_CD: pCaseLineData.line_PURPOSE_CD,
            wm_CASE_VERSION_TYPE_CD: pCaseLineData.wm_CASE_VERSION_TYPE_CD,
        }
        return aCaseLineEntity;
    }

    //This function returns the case line entity that has been mapped with passing case line primary keys 
    //required for use with legacy Data Manager.
    public static getMappingCaseLineEntityPK(pCaseLineData: ifaceCaseLineData): ifaceCaseLineEntity {
        const aCaseLineEntity: ifaceCaseLineEntity = {
            service_DB_ID: CaseUtils.getServiceDatabaseId(),
            case_ID: pCaseLineData.case_ID,
            case_MASTER_LINE_ID: pCaseLineData.case_MASTER_LINE_ID,
            working_CASE_ID: pCaseLineData.working_CASE_ID,
            working_CASE_VERSION_ID: pCaseLineData.working_CASE_VERSION_ID,
            change_ACTION_CD: pCaseLineData.change_ACTION_CD,
        }
        return aCaseLineEntity;
    }

    /* This method converts currency to string for calculation */
    public static removeDollarSign(pVal: string): string {
        // Strip off dollar sign
        if (!!pVal)
            return (pVal.replace(/[^0-9.-]+/g, ""));
        else return (pVal);
    }

    public static convertBlankToNull(pValue: string): string {
        if ((!!pValue) && (pValue !== '')  && (pValue !== 'N/A')) return pValue;
        return null;
    }

    //This method sets up the case line entity for saving using legacy data manager. 
    //This is being used by Line Subdash board component for logical/physical delete function
    public static prepareCLDataForSave(pCaseLineData: ifaceCaseLineData): ifaceCaseLineEntity {
        const aCaseLineEntity: ifaceCaseLineEntity = {
            entityName: 'CASE_LINE',
            service_DB_ID: CaseUtils.getServiceDatabaseId(),
            // entityStatus: DsamsConstants.ENT_CHANGED.toString(),
            // status: DsamsConstants.ENT_CHANGED.toString(),
            entityStatus: pCaseLineData.entityStatus,
            status: pCaseLineData.status,
            case_ID: pCaseLineData.case_ID,
            case_MASTER_LINE_ID: pCaseLineData.case_MASTER_LINE_ID,
            working_CASE_ID: pCaseLineData.working_CASE_ID,
            working_CASE_VERSION_ID: pCaseLineData.working_CASE_VERSION_ID,
            activity_ID: pCaseLineData.activity_ID,
            apply_PROFILE_LINE_CD: pCaseLineData.apply_PROFILE_LINE_CD,
            acquisition_VALUE_AM: pCaseLineData.acquisition_VALUE_AM,
            budget_APPROPRIATION_CD: pCaseLineData.budget_APPROPRIATION_CD,
            case_LINE_AVAILABILITY_LEAD_QY: pCaseLineData.case_LINE_AVAILABILITY_LEAD_QY,
            case_LINE_PAY_PERIOD_START_QY: pCaseLineData.case_LINE_PAY_PERIOD_START_QY,
            case_LINE_PAY_PERIOD_END_QY: pCaseLineData.case_LINE_PAY_PERIOD_END_QY,
            case_LINE_PERIOD_START_QY: pCaseLineData.case_LINE_PERIOD_START_QY,
            case_LINE_PERIOD_END_QY: pCaseLineData.case_LINE_PERIOD_END_QY,
            case_LINE_ITEM_QY: pCaseLineData.case_LINE_ITEM_QY,
            case_LINE_NOTE_QY: pCaseLineData.case_LINE_NOTE_QY,
            case_LINE_ATTACHMENT_QY: pCaseLineData.case_LINE_ATTACHMENT_QY,
            case_LINE_SHIPMENT_TX: pCaseLineData.case_LINE_SHIPMENT_TX,
            case_LINE_MARK_FOR_DELETION_IN: pCaseLineData.case_LINE_MARK_FOR_DELETION_IN,
            case_USAGE_INDICATOR_CD: pCaseLineData.case_USAGE_INDICATOR_CD,
            case_VERSION_ID: pCaseLineData.case_VERSION_ID,
            change_ACTION_CD: pCaseLineData.change_ACTION_CD,
            condition_CD: pCaseLineData.condition_CD,
            customer_NICKNAME_NM: pCaseLineData.customer_NICKNAME_NM,
            estimated_DELIVERY_END_DT: pCaseLineData.estimated_DELIVERY_END_DT,
            estimated_DELIVERY_DT: pCaseLineData.estimated_DELIVERY_DT,
            inventory_VALUE_AM: pCaseLineData.inventory_VALUE_AM,
            issue_UNIT_CD: pCaseLineData.issue_UNIT_CD,
            implementing_AGENCY_ID: pCaseLineData.implementing_AGENCY_ID,
            line_MANAGER_ID: pCaseLineData.line_MANAGER_ID,
            line_PURPOSE_CD: pCaseLineData.line_PURPOSE_CD,
            major_DEFENSE_EQUIPMENT_CD: pCaseLineData.major_DEFENSE_EQUIPMENT_CD,
            military_ARTICLE_SERVICE_CD: pCaseLineData.military_ARTICLE_SERVICE_CD,
            national_STOCK_NUMBER_ID: pCaseLineData.national_STOCK_NUMBER_ID,
            offer_EXPIRATION_DT: pCaseLineData.offer_EXPIRATION_DT,
            operating_AGENCY_CD: pCaseLineData.operating_AGENCY_CD,
            other_NATIONAL_STOCK_NUMBER_ID: pCaseLineData.other_NATIONAL_STOCK_NUMBER_ID,
            other_PART_NUMBER_IN: pCaseLineData.other_PART_NUMBER_IN,
            part_NUMBER_IN: pCaseLineData.part_NUMBER_IN,
            percent_STOCK_RT: pCaseLineData.percent_STOCK_RT,
            program_OF_RECORD_ID: pCaseLineData.program_OF_RECORD_ID,
            shipment_STATUS_ID: pCaseLineData.shipment_STATUS_ID,
            supporting_ORGANIZATION_ID: pCaseLineData.supporting_ORGANIZATION_ID,
            supply_SOURCE_NUMBER_ID: pCaseLineData.supply_SOURCE_NUMBER_ID,
            training_NOTE_CD: pCaseLineData.training_NOTE_CD,
            stock_ON_ORDER_COST_AM: this.removeDollarSign(pCaseLineData.stock_ON_ORDER_COST_AM),
            stock_ON_HAND_COST_AM: this.removeDollarSign(pCaseLineData.stock_ON_HAND_COST_AM),
            total_ABOVE_LINE_COST_AM: this.removeDollarSign(pCaseLineData.total_ABOVE_LINE_COST_AM),
            unit_ABOVE_LINE_COST_AM: this.removeDollarSign(pCaseLineData.unit_ABOVE_LINE_COST_AM),
        }

        //numeric data type must be set to null for saving when it is blank/empty
        aCaseLineEntity.unit_ABOVE_LINE_COST_AM = this.convertBlankToNull(aCaseLineEntity.unit_ABOVE_LINE_COST_AM);
        aCaseLineEntity.total_ABOVE_LINE_COST_AM = this.convertBlankToNull(aCaseLineEntity.total_ABOVE_LINE_COST_AM);
        aCaseLineEntity.stock_ON_HAND_COST_AM = this.convertBlankToNull(aCaseLineEntity.stock_ON_HAND_COST_AM);
        aCaseLineEntity.stock_ON_ORDER_COST_AM = this.convertBlankToNull(aCaseLineEntity.stock_ON_ORDER_COST_AM);
        aCaseLineEntity.percent_STOCK_RT = this.convertBlankToNull(aCaseLineEntity.percent_STOCK_RT);

        if (!!aCaseLineEntity.national_STOCK_NUMBER_ID &&
            aCaseLineEntity.national_STOCK_NUMBER_ID.length > 0)
            aCaseLineEntity.part_NUMBER_IN = true;
        else aCaseLineEntity.part_NUMBER_IN = false;

        if (!!aCaseLineEntity.other_NATIONAL_STOCK_NUMBER_ID &&
            aCaseLineEntity.other_NATIONAL_STOCK_NUMBER_ID.length > 0)
            aCaseLineEntity.other_PART_NUMBER_IN = true;
        else aCaseLineEntity.other_PART_NUMBER_IN = false;

        return aCaseLineEntity;
    }

    //This is being commonly used by both Line Detail and Line Delivery components
    public static prepareCLATEntity(pCaseLineInfoData: ifaceCaseLineData,
        pDeletedCLATListArray: ifaceCaseLineAssistanceTypeEntity[]) {
        if (pDeletedCLATListArray) {
            var isRowMatchedFound: boolean = false;
            //Reattach deleted row
            pDeletedCLATListArray.forEach(deletedRow => {
                pCaseLineInfoData.caseLineAssistanceTypeList.forEach(savedRow => {
                    if (deletedRow.assistance_TYPE_CD == savedRow.assistance_TYPE_CD) {
                        savedRow.status = DsamsConstants.ENT_CHANGED.toString();
                        isRowMatchedFound = true;
                    }
                })
                if (!isRowMatchedFound) pCaseLineInfoData.caseLineAssistanceTypeList.push(deletedRow);
            })
        }
    }

    //This is being commonly used by both Line Detail and Line Delivery components
    public static prepareCLOREntity(pCaseLineInfoData: ifaceCaseLineData,
        pDeletedCLORListArray: ifaceCaseLineOfferReleaseEntity[]) {
        if (pDeletedCLORListArray) {
            var isRowMatchedFound: boolean = false;
            //Reattach deleted row
            pDeletedCLORListArray.forEach(deletedRow => {
                pCaseLineInfoData.caseLineOfferReleaseList.forEach(savedRow => {
                    if (deletedRow.offer_RELEASE_ID == savedRow.offer_RELEASE_ID) {
                        savedRow.status = DsamsConstants.ENT_CHANGED.toString();
                        isRowMatchedFound = true;
                    }
                })
                if (!isRowMatchedFound) pCaseLineInfoData.caseLineOfferReleaseList.push(deletedRow);
            })
        }
    }

    //
    //
    //
    public static resetCLATEntityToUnChanged(pCaseLineInfoData: ifaceCaseLineData) {
        if (!!pCaseLineInfoData.caseLineAssistanceTypeList) {
            pCaseLineInfoData.caseLineAssistanceTypeList.forEach(savedRow => {
                savedRow.status = DsamsConstants.ENT_UNCHANGED.toString();
            });
        }
    }

    public static resetCLDIEntityToUnChanged(pCaseLineInfoData: ifaceCaseLineData) {
        pCaseLineInfoData.caseLineDeliveryItemList.forEach(savedRow => {
            savedRow.status = DsamsConstants.ENT_UNCHANGED.toString();
        })
    }

    public static resetCLDTEntityToUnChanged(pCaseLineInfoData: ifaceCaseLineData) {
        pCaseLineInfoData.caseLineDeliveryTermList.forEach(savedRow => {
            savedRow.status = DsamsConstants.ENT_UNCHANGED.toString();
        })
    }

    public static resetCLOREntityToUnChanged(pCaseLineInfoData: ifaceCaseLineData) {
        pCaseLineInfoData.caseLineOfferReleaseList.forEach(savedRow => {
            savedRow.status = DsamsConstants.ENT_UNCHANGED.toString();
        })
    }


    //This is being commonly used by both Line Detail and Line Delivery components
    public static prepareCLDTEntity(pCaseLineInfoData: ifaceCaseLineData,
        pDeletedCLDTListArray: ifaceCaseLineDeliveryTermEntity[]) {
        if (pDeletedCLDTListArray) {
            var isRowMatchedFound: boolean = false;
            //Reattach deleted row
            pDeletedCLDTListArray.forEach(deletedRow => {
                pCaseLineInfoData.caseLineDeliveryTermList.forEach(savedRow => {
                    if (deletedRow.delivery_TERM_ID == savedRow.delivery_TERM_ID) {
                        savedRow.status = DsamsConstants.ENT_CHANGED.toString();
                        isRowMatchedFound = true;
                    }
                })
                if (!isRowMatchedFound) pCaseLineInfoData.caseLineDeliveryTermList.push(deletedRow);
            })
        }
    }

    //This is being commonly used by both Line Detail and Line Delivery components
    public static prepareCLDIEntity(pCaseLineInfoData: ifaceCaseLineData,
        pDeletedCLDIListArray: ifaceCaseLineDeliveryItemEntity[]) {
        if (pDeletedCLDIListArray) {
            var isRowMatchedFound: boolean = false;
            //Reattach deleted row
            pDeletedCLDIListArray.forEach(deletedRow => {
                pCaseLineInfoData.caseLineDeliveryItemList.forEach(savedRow => {
                    if (deletedRow.case_LINE_DELIVERY_ITEM_ID == savedRow.case_LINE_DELIVERY_ITEM_ID) {
                        savedRow.status = DsamsConstants.ENT_CHANGED.toString();
                        isRowMatchedFound = true;
                    }
                })
                if (!isRowMatchedFound) {
                    //****** still more work */
                    //need to delete all CLDS rows
                    pCaseLineInfoData.caseLineDeliveryItemList.push(deletedRow);
                }
            })
        }
    }

    //This is being commonly used by both Line Detail and Line Delivery components
    public static prepareCLDSEntity(pCaseLineInfoData: ifaceCaseLineData,
        pDeletedCLDSListArray: ifaceCaseLineDeliveryScheduleEntity[]) {
        if (pDeletedCLDSListArray) {
            // var isRowMatchedFound: boolean = false;
            //****** still more work */
            //Reattach deleted row
            pDeletedCLDSListArray.forEach(deletedRow => {
                pCaseLineInfoData.caseLineDeliveryItemList.forEach(cldiList =>
                    cldiList.caseLineDeliveryScheduleList.forEach(savedRow => {
                        if (deletedRow.calendar_YEAR_ID == savedRow.calendar_YEAR_ID) {
                            savedRow.status = DsamsConstants.ENT_CHANGED.toString();
                        }
                    })
                )
            })
        }
    }

    //This is being used by both Line Detail and Line Delivery components.
    //This function is to normalize data for legacy Save on Case Line entity
    public static prepareCaselineEntity(pCaseLineInfoData: ifaceCaseLineData) {
        pCaseLineInfoData.apply_PROFILE_LINE_CD = "N";
        //amount cannot be null for saving so set default values when applicable
        // pCaseLineInfoData.case_LINE_ITEM_QY = pCaseLineInfoData.case_LINE_ITEM_QY;
        // pCaseLineInfoData.case_LINE_ATTACHMENT_QY = pCaseLineInfoData.case_LINE_ATTACHMENT_QY;
        // pCaseLineInfoData.case_LINE_AVAILABILITY_LEAD_QY = pCaseLineInfoData.case_LINE_AVAILABILITY_LEAD_QY;
        // pCaseLineInfoData.case_LINE_PAY_PERIOD_START_QY = pCaseLineInfoData.case_LINE_PAY_PERIOD_START_QY;
        // pCaseLineInfoData.case_LINE_PAY_PERIOD_END_QY = pCaseLineInfoData.case_LINE_PAY_PERIOD_END_QY;
        // pCaseLineInfoData.case_LINE_PERIOD_START_QY = pCaseLineInfoData.case_LINE_PERIOD_START_QY;
        // pCaseLineInfoData.case_LINE_PERIOD_END_QY = pCaseLineInfoData.case_LINE_PERIOD_END_QY;
        // pCaseLineInfoData.stock_ON_ORDER_COST_AM = pCaseLineInfoData.stock_ON_ORDER_COST_AM;
        // pCaseLineInfoData.stock_ON_HAND_COST_AM = pCaseLineInfoData.stock_ON_HAND_COST_AM;
        // pCaseLineInfoData.total_ABOVE_LINE_COST_AM = pCaseLineInfoData.total_ABOVE_LINE_COST_AM;
        // pCaseLineInfoData.unit_ABOVE_LINE_COST_AM = pCaseLineInfoData.unit_ABOVE_LINE_COST_AM;
        // pCaseLineInfoData.acquisition_VALUE_AM = pCaseLineInfoData.acquisition_VALUE_AM;
        // pCaseLineInfoData.inventory_VALUE_AM = pCaseLineInfoData.inventory_VALUE_AM;
        if (pCaseLineInfoData.percent_STOCK_RT == 'N/A')
       pCaseLineInfoData.percent_STOCK_RT =   this.convertBlankToNull(pCaseLineInfoData.percent_STOCK_RT);
        // else if (!!pCaseLineInfoData.percent_STOCK_RT) {
        //     pCaseLineInfoData.percent_STOCK_RT = (parseFloat(pCaseLineInfoData.percent_STOCK_RT) / 100).toFixed(2);
        // }
        if (pCaseLineInfoData.case_LINE_ITEM_QY == 'N/A')
        pCaseLineInfoData.case_LINE_ITEM_QY  =  this.convertBlankToNull(pCaseLineInfoData.case_LINE_ITEM_QY);

        if ((!!pCaseLineInfoData.estimated_DELIVERY_DT) &&
            pCaseLineInfoData.estimated_DELIVERY_DT !== 'N/A')
            pCaseLineInfoData.estimated_DELIVERY_DT =
                DateValidator.dateToString(CaseUtils.toDate(pCaseLineInfoData.estimated_DELIVERY_DT) as Date);
        if ((!!pCaseLineInfoData.estimated_DELIVERY_END_DT) &&
            pCaseLineInfoData.estimated_DELIVERY_END_DT !== 'N/A')
            pCaseLineInfoData.estimated_DELIVERY_END_DT =
                DateValidator.dateToString(CaseUtils.toDate(pCaseLineInfoData.estimated_DELIVERY_END_DT) as Date);

        //there is some data had been modified on the case line data
        if (pCaseLineInfoData.status !== DsamsConstants.ENT_NEW.toString() &&
            pCaseLineInfoData.status !== DsamsConstants.ENT_DELETED.toString()) {
            pCaseLineInfoData.status = DsamsConstants.ENT_CHANGED.toString();
            pCaseLineInfoData.entityStatus = DsamsConstants.ENT_CHANGED.toString();
        }
        else if (pCaseLineInfoData.status == DsamsConstants.ENT_NEW.toString()) {
            pCaseLineInfoData.wm_USER_CASE_LINE_NUMBER_ID = pCaseLineInfoData.LINESUBLINESEQVIR;
            //will do one for subline
        }
    }

    //This is being used by both Line Detail and Line Delivery components
    public static prepareCaseMasterLineEntity(pCaseLineInfoData: ifaceCaseLineData): ifaceCaseMasterLineEntity {
        var aCaseMasterLine: ifaceCaseMasterLineEntity = {};
        aCaseMasterLine.caseLineList = [];

        if (pCaseLineInfoData.entityStatus == DsamsConstants.ENT_NEW.toString()) {
            //set case master line entity status to new to create parent line
            if (pCaseLineInfoData.isEntityNew) {
                aCaseMasterLine.status = DsamsConstants.ENT_CHANGED.toString();
                pCaseLineInfoData.wm_SaveCL = true;
            } else {
                aCaseMasterLine.status = DsamsConstants.ENT_NEW.toString();
            }
            pCaseLineInfoData.isEntityNew = false;
        }
        else {
            pCaseLineInfoData.wm_SaveCL = true;
            if (pCaseLineInfoData.isLineNumberChanged) {
                pCaseLineInfoData.wm_SaveCML = true;
            }
            else pCaseLineInfoData.wm_SaveCML = false;
        }
        //prepare data for saving
        aCaseMasterLine.service_DB_ID = CaseUtils.getServiceDatabaseId();
        // console.log('line detail=', aCaseMasterLine)
        return aCaseMasterLine;
    }

    //This is being used by both Line Detail and Line Delivery components
    public static prepareLineDetailDataForSave(pCaseLineInfoData: ifaceCaseLineData): ifaceCaseLineData {
        //set up proper data format for saving
        pCaseLineInfoData.unit_ABOVE_LINE_COST_AM =
            this.removeDollarSign(pCaseLineInfoData.unit_ABOVE_LINE_COST_AM);
        pCaseLineInfoData.total_ABOVE_LINE_COST_AM =
            this.removeDollarSign(pCaseLineInfoData.total_ABOVE_LINE_COST_AM);
        pCaseLineInfoData.stock_ON_HAND_COST_AM =
            this.removeDollarSign(pCaseLineInfoData.stock_ON_HAND_COST_AM);
        pCaseLineInfoData.stock_ON_ORDER_COST_AM =
            this.removeDollarSign(pCaseLineInfoData.stock_ON_ORDER_COST_AM);

        if (!!pCaseLineInfoData.national_STOCK_NUMBER_ID &&
            pCaseLineInfoData.national_STOCK_NUMBER_ID.length > 0)
            pCaseLineInfoData.part_NUMBER_IN = true;
        else pCaseLineInfoData.part_NUMBER_IN = false;

        if (!!pCaseLineInfoData.other_NATIONAL_STOCK_NUMBER_ID &&
            pCaseLineInfoData.other_NATIONAL_STOCK_NUMBER_ID.length > 0)
            pCaseLineInfoData.other_PART_NUMBER_IN = true;
        else pCaseLineInfoData.other_PART_NUMBER_IN = false;

        //number data type  must be set to null for saving when empty
        if (pCaseLineInfoData.percent_STOCK_RT == null ||
            pCaseLineInfoData.percent_STOCK_RT == 'undefined' ||
            pCaseLineInfoData.percent_STOCK_RT == '')
            pCaseLineInfoData.percent_STOCK_RT = null;

        //remove overhead attributes and objects for data saving purposes
        //Manually mapping object for now
        const aCaseLineData: ifaceCaseLineData = {
            activity_NM: pCaseLineInfoData.activity_NM,
            case_ID: pCaseLineInfoData.case_ID,
            case_MASTER_LINE_ID: pCaseLineInfoData.case_MASTER_LINE_ID,
            working_CASE_ID: pCaseLineInfoData.working_CASE_ID,
            working_CASE_VERSION_ID: pCaseLineInfoData.working_CASE_VERSION_ID,
            entityName: pCaseLineInfoData.entityName,
            status: pCaseLineInfoData.status,
            entityStatus: pCaseLineInfoData.entityStatus,
            activity_ID: pCaseLineInfoData.activity_ID,
            apply_PROFILE_LINE_CD: pCaseLineInfoData.apply_PROFILE_LINE_CD,
            acquisition_VALUE_AM: pCaseLineInfoData.acquisition_VALUE_AM,
            budget_APPROPRIATION_CD: pCaseLineInfoData.budget_APPROPRIATION_CD,
            case_LINE_AVAILABILITY_LEAD_QY: pCaseLineInfoData.case_LINE_AVAILABILITY_LEAD_QY,
            case_LINE_PAY_PERIOD_START_QY: pCaseLineInfoData.case_LINE_PAY_PERIOD_START_QY,
            case_LINE_PAY_PERIOD_END_QY: pCaseLineInfoData.case_LINE_PAY_PERIOD_END_QY,
            case_LINE_PERIOD_START_QY: pCaseLineInfoData.case_LINE_PERIOD_START_QY,
            case_LINE_PERIOD_END_QY: pCaseLineInfoData.case_LINE_PERIOD_END_QY,
            case_LINE_ITEM_QY: pCaseLineInfoData.case_LINE_ITEM_QY,
            case_LINE_NOTE_QY: pCaseLineInfoData.case_LINE_NOTE_QY,
            case_LINE_ATTACHMENT_QY: pCaseLineInfoData.case_LINE_ATTACHMENT_QY,
            case_LINE_SHIPMENT_TX: pCaseLineInfoData.case_LINE_SHIPMENT_TX,
            case_LINE_MARK_FOR_DELETION_IN: pCaseLineInfoData.case_LINE_MARK_FOR_DELETION_IN,
            case_USAGE_INDICATOR_CD: pCaseLineInfoData.case_USAGE_INDICATOR_CD,
            case_VERSION_ID: pCaseLineInfoData.case_VERSION_ID,
            change_ACTION_CD: pCaseLineInfoData.change_ACTION_CD,
            condition_CD: pCaseLineInfoData.condition_CD,
            customer_NICKNAME_NM: pCaseLineInfoData.customer_NICKNAME_NM,
            estimated_DELIVERY_END_DT: pCaseLineInfoData.estimated_DELIVERY_END_DT,
            estimated_DELIVERY_DT: pCaseLineInfoData.estimated_DELIVERY_DT,
            inventory_VALUE_AM: pCaseLineInfoData.inventory_VALUE_AM,
            issue_UNIT_CD: pCaseLineInfoData.issue_UNIT_CD,
            implementing_AGENCY_ID: pCaseLineInfoData.implementing_AGENCY_ID,
            line_MANAGER_ID: pCaseLineInfoData.line_MANAGER_ID,
            line_PURPOSE_CD: pCaseLineInfoData.line_PURPOSE_CD,
            major_DEFENSE_EQUIPMENT_CD: pCaseLineInfoData.major_DEFENSE_EQUIPMENT_CD,
            military_ARTICLE_SERVICE_CD: pCaseLineInfoData.military_ARTICLE_SERVICE_CD,
            national_STOCK_NUMBER_ID: pCaseLineInfoData.national_STOCK_NUMBER_ID,
            offer_EXPIRATION_DT: pCaseLineInfoData.offer_EXPIRATION_DT,
            operating_AGENCY_CD: pCaseLineInfoData.operating_AGENCY_CD,
            other_NATIONAL_STOCK_NUMBER_ID: pCaseLineInfoData.other_NATIONAL_STOCK_NUMBER_ID,
            other_PART_NUMBER_IN: pCaseLineInfoData.other_PART_NUMBER_IN,
            part_NUMBER_IN: pCaseLineInfoData.part_NUMBER_IN,
            percent_STOCK_RT: pCaseLineInfoData.percent_STOCK_RT,
            program_OF_RECORD_ID: pCaseLineInfoData.program_OF_RECORD_ID,
            shipment_STATUS_ID: pCaseLineInfoData.shipment_STATUS_ID,
            stock_ON_ORDER_COST_AM: pCaseLineInfoData.stock_ON_ORDER_COST_AM,
            stock_ON_HAND_COST_AM: pCaseLineInfoData.stock_ON_HAND_COST_AM,
            supporting_ORGANIZATION_ID: pCaseLineInfoData.supporting_ORGANIZATION_ID,
            supply_SOURCE_NUMBER_ID: pCaseLineInfoData.supply_SOURCE_NUMBER_ID,
            training_NOTE_CD: pCaseLineInfoData.training_NOTE_CD,
            total_ABOVE_LINE_COST_AM: pCaseLineInfoData.total_ABOVE_LINE_COST_AM,
            unit_ABOVE_LINE_COST_AM: pCaseLineInfoData.unit_ABOVE_LINE_COST_AM,
            wm_USER_CASE_LINE_NUMBER_ID: pCaseLineInfoData.wm_USER_CASE_LINE_NUMBER_ID,
            wm_USER_CASE_SUBLINE_TX: pCaseLineInfoData.wm_USER_CASE_SUBLINE_TX,
            wm_CASE_LINE_LOI_IN: pCaseLineInfoData.wm_CASE_LINE_LOI_IN,
            wm_CML_SERVICES_COMPLETE_IN: pCaseLineInfoData.wm_CML_SERVICES_COMPLETE_IN,
            wm_EXCLUSION_IN: pCaseLineInfoData.wm_EXCLUSION_IN,
            wm_CASE_LINE_REMARK_QY: pCaseLineInfoData.wm_CASE_LINE_REMARK_QY,
            wm_CML_CLOSURE_STATUS_CD: pCaseLineInfoData.wm_CML_CLOSURE_STATUS_CD,
            wm_PARENT_CASE_ID: pCaseLineInfoData.wm_PARENT_CASE_ID,
            wm_PARENT_CASE_MASTER_LINE_ID: pCaseLineInfoData.wm_PARENT_CASE_MASTER_LINE_ID,
            wm_CM_CUSTOMER_ORGANIZATION_ID: pCaseLineInfoData.wm_CM_CUSTOMER_ORGANIZATION_ID,
            wm_PARENT_CHANGE_ACTION_CD: pCaseLineInfoData.wm_PARENT_CHANGE_ACTION_CD,
            wm_PARENT_IS_PRICED: pCaseLineInfoData.wm_PARENT_IS_PRICED,
            wm_LINE_IS_PRICED: pCaseLineInfoData.wm_LINE_IS_PRICED,
            wm_SaveCL: pCaseLineInfoData.wm_SaveCL,
            wm_SaveCML: pCaseLineInfoData.wm_SaveCML,
            wm_CML_IMPLEMENTED_CASE_ID: pCaseLineInfoData.wm_CML_IMPLEMENTED_CASE_ID,
            wm_CML_IMPLEMENTED_CASE_VRSN_ID: pCaseLineInfoData.wm_CML_IMPLEMENTED_CASE_VRSN_ID,
            wm_CM_IMPLEMENTED_CASE_ID: pCaseLineInfoData.wm_CM_IMPLEMENTED_CASE_ID,
            wm_CM_IMPLEMENTED_CASE_VERSION_ID: pCaseLineInfoData.wm_CM_IMPLEMENTED_CASE_VERSION_ID,
            case_LINE_ITEM_DESCRIPTION_TX: pCaseLineInfoData.case_LINE_ITEM_DESCRIPTION_TX,
            wm_CHECK_NPOR: pCaseLineInfoData.wm_CHECK_NPOR,
            //Form control has to be removed before passing object over to server
            caseLineAssistanceTypeList: [],
            caseLineDeliveryItemList: [],
            caseLineDeliveryTermList: [],
            caseLineOfferReleaseList: [],
            wm_POST_SAVE_MESSAGES: []
        };
        if (!!pCaseLineInfoData.caseLineOfferReleaseList) {
            pCaseLineInfoData.caseLineOfferReleaseList.forEach(eachRow => {
                //set up entity to exclude form control attribute
                var aCLOfferReleaseObject: ifaceCaseLineOfferReleaseEntity =
                {
                    entityName: eachRow.entityName,
                    status: eachRow.status,
                    offer_RELEASE_TITLE_NM: eachRow.offer_RELEASE_ID,
                    case_ID: eachRow.case_ID,
                    case_MASTER_LINE_ID: eachRow.case_MASTER_LINE_ID,
                    working_CASE_ID: eachRow.working_CASE_ID,
                    working_CASE_VERSION_ID: eachRow.working_CASE_VERSION_ID,
                    sequence_CD: eachRow.sequence_CD,
                    offer_RELEASE_ID: eachRow.offer_RELEASE_ID,
                    theOfferReleaseId: eachRow.theOfferReleaseId,
                }
                aCaseLineData.caseLineOfferReleaseList.push(aCLOfferReleaseObject);
            })
        }
        if (!!pCaseLineInfoData.caseLineDeliveryItemList) {
            pCaseLineInfoData.caseLineDeliveryItemList.forEach((eachRow, anItemIndex) => {
                var aCLDeliverItemObject: ifaceCaseLineDeliveryItemEntity =
                {
                    entityName: eachRow.entityName,
                    status: eachRow.status,
                    case_ID: eachRow.case_ID,
                    case_MASTER_LINE_ID: eachRow.case_MASTER_LINE_ID,
                    working_CASE_ID: eachRow.working_CASE_ID,
                    working_CASE_VERSION_ID: eachRow.working_CASE_VERSION_ID,
                    item_CD: eachRow.item_CD,
                    case_LINE_DELIVERY_ITEM_ID: eachRow.case_LINE_DELIVERY_ITEM_ID,
                    caseLineDeliveryScheduleList: [],
                };
                if (!!eachRow.caseLineDeliveryScheduleList) {
                    eachRow.caseLineDeliveryScheduleList.forEach(eachCalRow => {
                        var aCLDeliverScheduleObject: ifaceCaseLineDeliveryScheduleEntity =
                        {
                            entityName: eachCalRow.entityName,
                            status: eachCalRow.status,
                            case_ID: eachCalRow.case_ID,
                            case_MASTER_LINE_ID: eachCalRow.case_MASTER_LINE_ID,
                            working_CASE_ID: eachCalRow.working_CASE_ID,
                            working_CASE_VERSION_ID: eachCalRow.working_CASE_VERSION_ID,
                            calendar_YEAR_ID: eachCalRow.calendar_YEAR_ID,
                            case_LINE_DELIVERY_ITEM_ID: eachCalRow.case_LINE_DELIVERY_ITEM_ID,
                            case_LINE_DELIVERY_SCHEDULE_ID: eachCalRow.case_LINE_DELIVERY_SCHEDULE_ID,
                            case_LINE_DEL_SET_Q1_QY: eachCalRow.case_LINE_DEL_SET_Q1_QY,
                            case_LINE_DEL_SET_Q2_QY: eachCalRow.case_LINE_DEL_SET_Q2_QY,
                            case_LINE_DEL_SET_Q3_QY: eachCalRow.case_LINE_DEL_SET_Q3_QY,
                            case_LINE_DEL_SET_Q4_QY: eachCalRow.case_LINE_DEL_SET_Q4_QY,
                        }
                        aCLDeliverItemObject.caseLineDeliveryScheduleList.push(aCLDeliverScheduleObject);
                    })
                }
                aCaseLineData.caseLineDeliveryItemList.push(aCLDeliverItemObject);
            })
        }
        if (!!pCaseLineInfoData.caseLineDeliveryTermList) {
            pCaseLineInfoData.caseLineDeliveryTermList.forEach(eachRow => {
                //set up entity to exclude form control attribute
                var aCLDeliverTermObject: ifaceCaseLineDeliveryTermEntity =
                {
                    entityName: eachRow.entityName,
                    status: eachRow.status,
                    case_ID: eachRow.case_ID,
                    case_MASTER_LINE_ID: eachRow.case_MASTER_LINE_ID,
                    working_CASE_ID: eachRow.working_CASE_ID,
                    working_CASE_VERSION_ID: eachRow.working_CASE_VERSION_ID,
                    sequence_CD: eachRow.sequence_CD,
                    delivery_TERM_ID: eachRow.delivery_TERM_ID,
                    theDeliveryTermId: eachRow.theDeliveryTermId,
                }
                aCaseLineData.caseLineDeliveryTermList.push(aCLDeliverTermObject);
            })
        }
        if (!!pCaseLineInfoData.caseLineAssistanceTypeList) {
            pCaseLineInfoData.caseLineAssistanceTypeList.forEach(eachRow => {
                var aCLAssistanceTypeObject: ifaceCaseLineAssistanceTypeEntity =
                {
                    entityName: eachRow.entityName,
                    status: eachRow.status,
                    case_ID: eachRow.case_ID,
                    case_MASTER_LINE_ID: eachRow.case_MASTER_LINE_ID,
                    working_CASE_ID: eachRow.working_CASE_ID,
                    working_CASE_VERSION_ID: eachRow.working_CASE_VERSION_ID,
                    assistance_TYPE_CD: eachRow.assistance_TYPE_CD,
                    theAssistanceTypeCd: eachRow.theAssistanceTypeCd,
                }
                aCaseLineData.caseLineAssistanceTypeList.push(aCLAssistanceTypeObject);
            })
        }
        return aCaseLineData;
    }

    //This method resets reference title name values to work with case line detail tab
    public static resetReferenceTitleValues(pCaseLineInfoData: ifaceCaseLineData) {
        //since values are being populated for Line List and being reused for Line Detail/Delivery, 
        //clear out all N/A string as not needed
        pCaseLineInfoData.line_PURPOSE_TITLE_NM = CaseUtils.convertNAStrToBlank(pCaseLineInfoData.line_PURPOSE_TITLE_NM);
        pCaseLineInfoData.line_MANAGER_TITLE_NM = CaseUtils.convertNAStrToBlank(pCaseLineInfoData.line_MANAGER_TITLE_NM);
        pCaseLineInfoData.activity_NM = CaseUtils.convertNAStrToBlank(pCaseLineInfoData.activity_NM);
        pCaseLineInfoData.supply_SOURCE_TITLE_NM = CaseUtils.convertNAStrToBlank(pCaseLineInfoData.supply_SOURCE_TITLE_NM);
        pCaseLineInfoData.condition_TITLE_NM = CaseUtils.convertNAStrToBlank(pCaseLineInfoData.condition_TITLE_NM);
        pCaseLineInfoData.operating_AGENCY_TITLE_NM = CaseUtils.convertNAStrToBlank(pCaseLineInfoData.operating_AGENCY_TITLE_NM);
        pCaseLineInfoData.training_NOTE_NM = CaseUtils.convertNAStrToBlank(pCaseLineInfoData.training_NOTE_NM);
        pCaseLineInfoData.support_ORGANIZATION_TITLE_NM = CaseUtils.convertNAStrToBlank(pCaseLineInfoData.support_ORGANIZATION_TITLE_NM);
        pCaseLineInfoData.budget_APPROPRIATION_TITLE_NM = CaseUtils.convertNAStrToBlank(pCaseLineInfoData.budget_APPROPRIATION_TITLE_NM);
        pCaseLineInfoData.title_NM = CaseUtils.convertNAStrToBlank(pCaseLineInfoData.title_NM);
        pCaseLineInfoData.mtcr_TITLE_NM = CaseUtils.convertNAStrToBlank(pCaseLineInfoData.mtcr_TITLE_NM);
        pCaseLineInfoData.unit_ABOVE_LINE_COST_AM = CaseUtils.getUSCurrency(pCaseLineInfoData.unit_ABOVE_LINE_COST_AM);
        pCaseLineInfoData.total_ABOVE_LINE_COST_AM = CaseUtils.getUSCurrency(pCaseLineInfoData.total_ABOVE_LINE_COST_AM);
        if (pCaseLineInfoData.stock_ON_ORDER_COST_AM == null)
            pCaseLineInfoData.stock_ON_ORDER_COST_AM = '0';
        if (pCaseLineInfoData.stock_ON_HAND_COST_AM == null)
            pCaseLineInfoData.stock_ON_HAND_COST_AM = '0';
        if (pCaseLineInfoData.acquisition_VALUE_AM == null)
            pCaseLineInfoData.acquisition_VALUE_AM = '0';
        if (pCaseLineInfoData.inventory_VALUE_AM == null)
            pCaseLineInfoData.inventory_VALUE_AM = '0';
    }

    //This method formats the MDE/SME field
    public static getFormattedMDEValue(pCaseLineInfoData: ifaceCaseLineData) {
        if (pCaseLineInfoData.major_DEFENSE_EQUIPMENT_CD) {
            if (pCaseLineInfoData.major_DEFENSE_EQUIPMENT_CD.toUpperCase() == 'S')
                pCaseLineInfoData.mde_SME_CD = 'SME';
            else if (pCaseLineInfoData.major_DEFENSE_EQUIPMENT_CD.toUpperCase() == 'Y')
                pCaseLineInfoData.mde_SME_CD = 'MDE';
            else pCaseLineInfoData.mde_SME_CD = 'N/A';
        } else pCaseLineInfoData.mde_SME_CD = 'N/A';
    }

    //This method formats the MDE/SME field for MASL Data
    public static getFormattedMDEValueForMASL(pCaseLineInfoDataMASL: IMilitaryArticleServiceList) {
        if (pCaseLineInfoDataMASL.major_DEFENSE_EQUIPMENT_CD) {
            if (pCaseLineInfoDataMASL.major_DEFENSE_EQUIPMENT_CD.toUpperCase() == 'S')
                pCaseLineInfoDataMASL.mde_SME = 'SME';
            else if (pCaseLineInfoDataMASL.major_DEFENSE_EQUIPMENT_CD.toUpperCase() == 'Y')
                pCaseLineInfoDataMASL.mde_SME = 'MDE';
            else pCaseLineInfoDataMASL.mde_SME = 'N/A';
        } else pCaseLineInfoDataMASL.mde_SME = 'N/A';
    }

    // This method sets MC title 
    public static getMTCRTitleValue(pCaseLineInfoData: ifaceCaseLineData) {
        if (pCaseLineInfoData.missile_TECH_CNTRL_REGIME_ID) {
            if (pCaseLineInfoData.missile_TECH_CNTRL_REGIME_ID.toUpperCase() == 'M')
                pCaseLineInfoData.mtcr_TITLE_NM = 'Line item contains MTCR components';
            else if (pCaseLineInfoData.missile_TECH_CNTRL_REGIME_ID.toUpperCase() == 'X')
                pCaseLineInfoData.mtcr_TITLE_NM = 'MTCR items unknown, requires MTCR review';
            else if (pCaseLineInfoData.missile_TECH_CNTRL_REGIME_ID.toUpperCase() == 'N')
                pCaseLineInfoData.mtcr_TITLE_NM = 'Line item does not contain any MTCR components';
            else pCaseLineInfoData.mtcr_TITLE_NM = 'N/A';
        } else pCaseLineInfoData.mtcr_TITLE_NM = 'N/A';
    }

    //FR35
    public static getTotalQuantity(pCaseLineInfoData: ifaceCaseLineData) {
        //must get the sum of all CLDS per item
        if ((!!pCaseLineInfoData) &&
            pCaseLineInfoData.caseLineDeliveryItemList) {
            pCaseLineInfoData.sumOfAllQuantities = 0;
            //foreach loop will run until it reaches the end of loop
            pCaseLineInfoData.caseLineDeliveryItemList.forEach(element => {
                if (!!element.sumOfAllItemQuantities)
                    pCaseLineInfoData.sumOfAllQuantities += element.sumOfAllItemQuantities;
            })
        }
    }

    //check to avoid intialization error
    public static isCaseLineInfoDataReady(pCaseLineInfoData: ifaceCaseLineData): boolean {
        if (!!pCaseLineInfoData) return true;
        return false;
    }

    public static isLineDeleteAllowed(pCaseLineInfoData: ifaceCaseLineData): boolean {
        if (!!pCaseLineInfoData) {
            const CHANGE_ACTION_UNAFFECTED: string = "U";
            const CHANGE_ACTION_ADDED: string = "A";
            const CLOSURE_STATUS_FINAL: string = '3';
            const CLOSURE_STATUS_INTERIM: string = '2';
            const CLOSURE_STATUS_SSC: string = '1';
            //FR14
            if ((!!pCaseLineInfoData.wm_CASE_LINE_LOI_IN && pCaseLineInfoData.wm_CASE_LINE_LOI_IN)
                || (!!pCaseLineInfoData.wm_CASE_VERSION_STATUS_CD) && (pCaseLineInfoData.wm_CASE_VERSION_STATUS_CD.toUpperCase() !== 'D')
                || pCaseLineInfoData.wm_CML_CLOSURE_STATUS_CD == CLOSURE_STATUS_FINAL
                || pCaseLineInfoData.wm_CML_CLOSURE_STATUS_CD == CLOSURE_STATUS_INTERIM
                || pCaseLineInfoData.wm_CML_CLOSURE_STATUS_CD == CLOSURE_STATUS_SSC
                || (!!pCaseLineInfoData.change_ACTION_CD) && pCaseLineInfoData.change_ACTION_CD.toUpperCase() == LineUtils.CHANGE_ACTION_DELETED
                || ((CaseCommonValidator.isEqual(pCaseLineInfoData.line_PURPOSE_CD, LineUtils.LINE_PURPOSE_CE))
                    && ((!!pCaseLineInfoData.change_ACTION_CD) && pCaseLineInfoData.change_ACTION_CD.toUpperCase() !== CHANGE_ACTION_ADDED))
                || ((!!pCaseLineInfoData.change_ACTION_CD) && pCaseLineInfoData.change_ACTION_CD.toUpperCase() == CHANGE_ACTION_UNAFFECTED
                    && pCaseLineInfoData.case_LINE_MARK_FOR_DELETION_IN)
            ) return false;
        }
        return true;
    }

    /**
     * Prompt the user if they want to perform a case line refresh.
     */
    public static promptUserToCaseLineRefresh(): Promise<SweetAlertResult<unknown>> {
        return MessageMgr.swalFire({
            text: MessageMgr.getMesssage("W307").messageText,
            icon: 'question',
            width: 500,
            showCancelButton: true,
            cancelButtonText: 'No',
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes',
        });
    }

    /**
      * Prompt the user if they want to perform a case line refresh (for change_action_cd = D)
      */
    public static promptUserToCaseLineRefreshForDeleted(): Promise<SweetAlertResult<unknown>> {
        return MessageMgr.swalFire({
            text: MessageMgr.getMesssage("W312").messageText,
            icon: 'question',
            width: 500,
            showCancelButton: true,
            cancelButtonText: 'No',
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes',
        });
    }

    //intialize case line data interface
    public static initializeCaseInfoData(pCaseLineInfoData: ifaceCaseLineData): ifaceCaseLineData {
        //since it is an interface, we need to initialize them
        let aCaseLineInfoData: ifaceCaseLineData = {};
        //Set initial values to avoid display undefined values error
        aCaseLineInfoData = {
            //this is for Header section
            wm_USER_CASE_LINE_NUMBER_ID: '',
            wm_USER_CASE_SUBLINE_TX: '',
            wm_CASE_LINE_LOI_IN: false,
            wm_CML_SERVICES_COMPLETE_IN: false,
            wm_EXCLUSION_IN: false,
            wm_CASE_VERSION_STATUS_CD: '',
            change_ACTION_TITLE_NM: '',
            offer_EXPIRATION_DT: '',
            implementing_AGENCY_ID: '',
            LINESUBLINESEQVIR: '',
            case_CUSTOMER_TYPE_CD: '',
            customer_ORGANIZATION_ID: '',
            //this is for pricing tab
            recalculation_IN: false,
            //this is for Line Detail tab
            case_LINE_ITEM_QY: '', generic_CD: '', military_ARTICLE_SERVICE_CD: '',
            line_PURPOSE_CD: '', line_PURPOSE_TITLE_NM: '', issue_UNIT_CD: '',
            article_DESCRIPTION_TX: '', major_DEFENSE_EQUIPMENT_CD: '', equipment_TYPE_TITLE_NM: '',
            stock_ON_ORDER_COST_AM: '0', stock_ON_HAND_COST_AM: '0', total_ABOVE_LINE_COST_AM: '',
            unit_ABOVE_LINE_COST_AM: '', part_NUMBER_IN: false, other_PART_NUMBER_IN: false,
            acquisition_VALUE_AM: '0', inventory_VALUE_AM: '0', percent_STOCK_RT: '',
            missile_TECH_CNTRL_REGIME_ID: '', mtcr_TITLE_NM: '', mde_SME_CD: '', parent_MDE_SME_CD: '',
            national_STOCK_NUMBER_ID: '', other_NATIONAL_STOCK_NUMBER_ID: '',
            caseLineAssistanceTypeList: [],
            //this is for delivery tab
            case_LINE_PERIOD_START_QY: '', case_LINE_PERIOD_END_QY: '',
            case_LINE_PAY_PERIOD_START_QY: '', case_LINE_PAY_PERIOD_END_QY: '',
            case_LINE_AVAILABILITY_LEAD_QY: '', case_LINE_SHIPMENT_TX: '',
            estimated_DELIVERY_END_DT: '',
            estimated_DELIVERY_DT: '',
            shipment_STATUS_ID: '',
            title_NM: '',
            sumOfAllQuantities: 0,
            caseLineDeliveryItemList: [], caseLineOfferReleaseList: [], caseLineDeliveryTermList: [],
            //private attributes
            isLinePurposeDisabled: false,
            isPricingDataChanged: false,
            isDataChanged: false,
        }
        //sonarqube workaround
        return aCaseLineInfoData;
    }

    //common validation 
    //FR8
    public static isQuantityRequired(pCaseLineInfoData: ifaceCaseLineData): boolean {
        if (!CaseUtils.isBlankStr(pCaseLineInfoData.issue_UNIT_CD) &&
            !CaseUtils.isBlankStr(pCaseLineInfoData.change_ACTION_CD)) {
            if (pCaseLineInfoData.issue_UNIT_CD.toUpperCase() !== LineUtils.UNIT_OF_ISSUE_XX &&
                pCaseLineInfoData.change_ACTION_CD == LineUtils.CHANGE_ACTION_CD_ADDED) {
                if (CaseUtils.isBlankStr(pCaseLineInfoData.case_LINE_ITEM_QY)) return true;
            }
        }
        return false;
    }

    //FR14
    public static isPEORequired(pCaseLineInfoData: ifaceCaseLineData,
        pCaseLineRelatedInfoData: CaseLineRelatedInfoType): boolean {
        if (CaseUtils.getServiceDatabaseId() == 'A' && !!pCaseLineInfoData.case_USAGE_INDICATOR_CD &&
            (   pCaseLineInfoData.case_USAGE_INDICATOR_CD.toUpperCase() == 'C' ||
                pCaseLineInfoData.case_USAGE_INDICATOR_CD.toUpperCase() == 'P') &&
            (pCaseLineInfoData.supporting_ORGANIZATION_ID == null ||
                pCaseLineInfoData.supporting_ORGANIZATION_ID == '' ||
                pCaseLineInfoData.supporting_ORGANIZATION_ID == 'N/A') &&
            !!(pCaseLineInfoData.implementing_AGENCY_ID)) {
            if (pCaseLineInfoData != null && pCaseLineInfoData.implementing_AGENCY_ID.toUpperCase() == 'B' &&
                pCaseLineRelatedInfoData.case_VERSION_STATUS_CD.toUpperCase() == 'D' &&
                (pCaseLineRelatedInfoData.case_VERSION_TYPE_CD.toUpperCase() == 'B' ||
                    pCaseLineRelatedInfoData.case_VERSION_TYPE_CD.toUpperCase() == 'A' ||
                    pCaseLineRelatedInfoData.case_VERSION_TYPE_CD.toUpperCase() == 'M') &&
                pCaseLineInfoData.change_ACTION_CD.toUpperCase() == LineUtils.CHANGE_ACTION_CD_ADDED) {
                return true;
            }
        }
        return false;
    }

    //FR15 
    public static isConditionCdRequired(pCaseLineInfoData: ifaceCaseLineData): boolean {
        if (pCaseLineInfoData.supply_SOURCE_NUMBER_ID == '' || pCaseLineInfoData.supply_SOURCE_NUMBER_ID == null
            || pCaseLineInfoData.supply_SOURCE_NUMBER_ID == 'N/A') return false;
        if (pCaseLineInfoData.supply_SOURCE_NUMBER_ID.toUpperCase() == LineUtils.SUPPLY_SOURCE_EDA &&
            (pCaseLineInfoData.condition_CD == '' || pCaseLineInfoData.condition_CD == null
                || pCaseLineInfoData.condition_CD == 'N/A'))
            return true;
        return false;
    }

    public static isPerformancePeriodDataValid(pCaseLineInfoData: ifaceCaseLineData): boolean {
        if (pCaseLineInfoData.change_ACTION_CD.toUpperCase() == LineUtils.CHANGE_ACTION_CD_ADDED &&
            !CaseUtils.isBlankStr(pCaseLineInfoData.case_LINE_ITEM_QY)) {
            if ( //comment out for now - waiting for analyst's clarification
                // (CaseUtils.isBlankStr(pCaseLineInfoData.case_LINE_AVAILABILITY_LEAD_QY) ||
                // pCaseLineInfoData.case_LINE_AVAILABILITY_LEAD_QY == '0') ||
                (CaseUtils.isBlankStr(pCaseLineInfoData.case_LINE_PERIOD_START_QY) ||
                    pCaseLineInfoData.case_LINE_PERIOD_START_QY == '0' ||
                    CaseUtils.isBlankStr(pCaseLineInfoData.case_LINE_PERIOD_END_QY ||
                        pCaseLineInfoData.case_LINE_PERIOD_END_QY == '0'))) {
                return false;
            }
        }
        return true;
    }

    //FR21 Payment Schedule Override From
    public static isPaymentScheduleOverrideFromValid(pCaseLineInfoData: ifaceCaseLineData): boolean {
        //no need to do further field validation when Payment Schedule Override From is null
        if (CaseUtils.isBlankStr(pCaseLineInfoData.case_LINE_PAY_PERIOD_START_QY)) return true;
        else if (CaseUtils.isBlankStr(pCaseLineInfoData.case_LINE_PAY_PERIOD_END_QY)) return false;
        return true;
    }
    //FR22 Payment Schedule Override To
    public static isPaymentScheduleOverrideToValid(pCaseLineInfoData: ifaceCaseLineData): boolean {
        //no need to do further field validation when Payment Schedule Override From is null
        if (CaseUtils.isBlankStr(pCaseLineInfoData.case_LINE_PAY_PERIOD_END_QY)) return true;
        else if (CaseUtils.isBlankStr(pCaseLineInfoData.case_LINE_PAY_PERIOD_START_QY)) return false;
        return true;
    }
    public static isQuantityEqualSumOfCLDS(pCaseLineInfoData: ifaceCaseLineData): boolean {
        if (!CaseUtils.isNumeric(pCaseLineInfoData.case_LINE_ITEM_QY)) return true;
        var aQuantity: number = parseInt(pCaseLineInfoData.case_LINE_ITEM_QY);
        if (aQuantity !== pCaseLineInfoData.sumOfAllQuantities)
            return false;
        return true;
    }

    public static isESFromDateGreaterThanESTo(pCaseLineInfoData: ifaceCaseLineData): boolean {
        //no need to do further field validation when Estimated Service Dates From is null
        if (pCaseLineInfoData.estimated_DELIVERY_DT == null) return true;
        if (pCaseLineInfoData.estimated_DELIVERY_DT > pCaseLineInfoData.estimated_DELIVERY_END_DT) return false;
        return true;
    }
    //FR25 Estimated Service Dates To (for the line/subline)
    public static isESToDateValid(pCaseLineInfoData: ifaceCaseLineData): boolean {
        //no need to do further field validation when Estimated Service Dates From is null
        if (pCaseLineInfoData.estimated_DELIVERY_END_DT == null) return true;
        if (pCaseLineInfoData.estimated_DELIVERY_DT == null) return false;
        return true;
    }

    //FR24 Estimated Service Dates From (for the line/subline) 
    public static isESFromDateValid(pCaseLineInfoData: ifaceCaseLineData): boolean {
        //no need to do further field validation when Estimated Service Dates From is null
        if (pCaseLineInfoData.estimated_DELIVERY_DT == null) return true;
        if (pCaseLineInfoData.estimated_DELIVERY_END_DT == null) return false;
        return true;
    }

    //This function returns true if at least one CLDI row is populated
    public static isCLDIpopulated(pCaseLineInfoData: ifaceCaseLineData): boolean {
        if (pCaseLineInfoData.caseLineDeliveryItemList) {
            if (pCaseLineInfoData.caseLineDeliveryItemList.length !== 0) {
                return true;
            }
        }
        return false;
    }

    //This function returns true if at least one CLDS row is populated
    public static isCLDSpopulated(pCaseLineInfoData: ifaceCaseLineData): boolean {
        var result: boolean = true;
        if (this.isCLDIpopulated(pCaseLineInfoData)) {
            pCaseLineInfoData.caseLineDeliveryItemList.forEach(element => {
                if (element.caseLineDeliveryScheduleList == null ||
                    element.caseLineDeliveryScheduleList.length == 0) {
                    result = false;
                }
                else {
                    element.caseLineDeliveryScheduleList.forEach(cldsElement => {
                        if (cldsElement.calendar_YEAR_ID == null ||
                            cldsElement.calendar_YEAR_ID == 0) {
                            result = false;
                        }
                    })
                }
            })
        }
        else result = false;
        return result;
    }

    //sonarqube rule
    private static isPPFieldValid(pCaseLineInfoData: ifaceCaseLineData): boolean {
        if ((pCaseLineInfoData.case_LINE_PERIOD_START_QY && parseInt(pCaseLineInfoData.case_LINE_PERIOD_START_QY) !== 0) ||
            (pCaseLineInfoData.case_LINE_PERIOD_END_QY && parseInt(pCaseLineInfoData.case_LINE_PERIOD_END_QY) !== 0) ||
            (pCaseLineInfoData.case_LINE_AVAILABILITY_LEAD_QY && parseInt(pCaseLineInfoData.case_LINE_AVAILABILITY_LEAD_QY) !== 0) ||
            (pCaseLineInfoData.case_LINE_PAY_PERIOD_START_QY && parseInt(pCaseLineInfoData.case_LINE_PAY_PERIOD_START_QY) !== 0) ||
            (pCaseLineInfoData.case_LINE_PAY_PERIOD_END_QY && parseInt(pCaseLineInfoData.case_LINE_PAY_PERIOD_END_QY) !== 0))
            return true;
        return false;

    }

    //FR23 - performance Period check
    public static isThereValueInPPFields(pCheckLeadTime: boolean, pCaseLineInfoData: ifaceCaseLineData): boolean {
        if (pCheckLeadTime) {
            return (this.isPPFieldValid(pCaseLineInfoData))
        }
        else {
            if ((pCaseLineInfoData.case_LINE_PERIOD_START_QY && parseInt(pCaseLineInfoData.case_LINE_PERIOD_START_QY) !== 0) ||
                (pCaseLineInfoData.case_LINE_PERIOD_END_QY && parseInt(pCaseLineInfoData.case_LINE_PERIOD_END_QY) !== 0) ||
                (pCaseLineInfoData.case_LINE_PAY_PERIOD_START_QY && parseInt(pCaseLineInfoData.case_LINE_PAY_PERIOD_START_QY) !== 0) ||
                (pCaseLineInfoData.case_LINE_PAY_PERIOD_END_QY && parseInt(pCaseLineInfoData.case_LINE_PAY_PERIOD_END_QY) !== 0))
                return true;
        }
        return false;
    }

    //FR23 - estimate service date check
    public static isThereValueInESFields(pCheckLeadTime: boolean, pCaseLineInfoData: ifaceCaseLineData): boolean {
        if (pCheckLeadTime) {
            if ((pCaseLineInfoData.estimated_DELIVERY_DT ||
                pCaseLineInfoData.estimated_DELIVERY_END_DT ||
                pCaseLineInfoData.case_LINE_AVAILABILITY_LEAD_QY) && parseInt(pCaseLineInfoData.case_LINE_AVAILABILITY_LEAD_QY) !== 0 &&
                pCaseLineInfoData.estimated_DELIVERY_DT !== '' && pCaseLineInfoData.estimated_DELIVERY_END_DT !== '')
                return true;
        }
        else {
            if ((pCaseLineInfoData.estimated_DELIVERY_DT ||
                pCaseLineInfoData.estimated_DELIVERY_END_DT) &&
                pCaseLineInfoData.estimated_DELIVERY_DT !== '' && pCaseLineInfoData.estimated_DELIVERY_END_DT !== '')
                return true;
        }
        return false;
    }

    //FR27
    //sonarqube rule
    private static isParentCLDSReqired(pCaseLineInfoData: ifaceCaseLineData): boolean {
        if ((pCaseLineInfoData.parent_MDE_SME_CD == 'SME' || pCaseLineInfoData.parent_MDE_SME_CD == 'MDE') &&
            pCaseLineInfoData.change_ACTION_CD.toUpperCase() == LineUtils.CHANGE_ACTION_CD_ADDED &&
            pCaseLineInfoData.case_USAGE_INDICATOR_CD.toUpperCase() == 'C' &&
            pCaseLineInfoData.issue_UNIT_CD.toUpperCase() !== LineUtils.UNIT_OF_ISSUE_XX) {
            if (!this.isCLDSpopulated(pCaseLineInfoData))
                return true;
        }
        return false;
    }

    //FR27
    //sonarqube rule
    public static isCLDSRequiredForMASL(pCaseLineInfoData: ifaceCaseLineData) {
        if (!!pCaseLineInfoData.wm_USER_CASE_SUBLINE_TX) {
            //get the parent line
            return (this.isParentCLDSReqired(pCaseLineInfoData));
        }
        else {
            if ((pCaseLineInfoData.mde_SME_CD == 'SME' || pCaseLineInfoData.mde_SME_CD == 'MDE') &&
                pCaseLineInfoData.change_ACTION_CD.toUpperCase() == LineUtils.CHANGE_ACTION_CD_ADDED &&
                pCaseLineInfoData.case_USAGE_INDICATOR_CD.toUpperCase() == 'C' &&
                pCaseLineInfoData.issue_UNIT_CD.toUpperCase() !== LineUtils.UNIT_OF_ISSUE_XX) {
                if (!this.isCLDSpopulated(pCaseLineInfoData))
                    return true;
            }
        }
        return false;
    }
    //FR35/36
    public static isFieldRequiredForEDA(pCaseLineInfoData: ifaceCaseLineData): boolean {
        if (pCaseLineInfoData.supply_SOURCE_NUMBER_ID == '' ||
            pCaseLineInfoData.supply_SOURCE_NUMBER_ID == null
            || pCaseLineInfoData.supply_SOURCE_NUMBER_ID == 'N/A') return false;
        if (pCaseLineInfoData.supply_SOURCE_NUMBER_ID.toUpperCase() == LineUtils.SUPPLY_SOURCE_EDA)
            return true;
        return false;
    }

    //check mandatory fields for line details
    public static areFieldsValidForLineDetails(pCaseLineInfoData: ifaceCaseLineData,
        msgArray: Array<ErrorParameter>): boolean {
        var retStatus: boolean = true;

        if (pCaseLineInfoData.line_PURPOSE_CD == '' ||
            pCaseLineInfoData.line_PURPOSE_CD == null) {
            retStatus = false;
            DialogMessageListComponentTc.addMessageRefToList(msgArray,
                LineUtils.CASE_LINE_CATEGORY, pCaseLineInfoData.LINESUBLINESEQVIR,
                MessageType.ERROR,
                "Line Purpose is required.");
        }
        if ((pCaseLineInfoData.military_ARTICLE_SERVICE_CD == '' ||
            pCaseLineInfoData.military_ARTICLE_SERVICE_CD == null) && !pCaseLineInfoData.wm_USER_CASE_SUBLINE_TX) {
            retStatus = false;
            DialogMessageListComponentTc.addMessageRefToList(msgArray,
                LineUtils.CASE_LINE_CATEGORY, pCaseLineInfoData.LINESUBLINESEQVIR, MessageType.ERROR, "MASL Number is required.");
        }
        //FR31
        if (pCaseLineInfoData.operating_AGENCY_CD == LineUtils.OPERATING_AGENCY_X) {
            retStatus = false;
            DialogMessageListComponentTc.addMessageRefToList(msgArray,
                LineUtils.CASE_LINE_CATEGORY, pCaseLineInfoData.LINESUBLINESEQVIR,
                MessageType.INFO,
                "Operating Agency X will use Marine Corps Civilian Personnel Rate.");
        }
        // FR105
        // Validate that POR/NPOR is present if it's required.
        if (this.isNPORRequired(pCaseLineInfoData)) {
            retStatus = false;
            DialogMessageListComponentTc.addMessageRefToList(msgArray,
                LineUtils.CASE_LINE_CATEGORY, pCaseLineInfoData.LINESUBLINESEQVIR,
                MessageType.ERROR,
                "POR/NPOR is required");
        }
        return retStatus;
    }
    
    //FR15
    public static isLinePurposeDisabled(pCaseLineInfoData: ifaceCaseLineData): boolean {
        if (CaseCommonValidator.isEqual(pCaseLineInfoData.line_PURPOSE_CD, LineUtils.LINE_PURPOSE_CE)) {
            return true;
        }
        return false;
    }

    //breaout per Sonarube rule
    private static areAllDataValid(pCaseLineInfoData: ifaceCaseLineData,
        msgArray: Array<ErrorParameter>): boolean {
        var retStatus: boolean = true;
        //FR35
        if (!CaseUtils.isNumeric(pCaseLineInfoData.acquisition_VALUE_AM) && this.isFieldRequiredForEDA(pCaseLineInfoData)) {
            retStatus = false;
            DialogMessageListComponentTc.addMessageRefToList(msgArray,
                LineUtils.CASE_LINE_CATEGORY, pCaseLineInfoData.LINESUBLINESEQVIR, MessageType.ERROR, "Original Acquisition Value is required when Source of Supply is EDA.");
        }
        //FR36
        if (!CaseUtils.isNumeric(pCaseLineInfoData.inventory_VALUE_AM) && this.isFieldRequiredForEDA(pCaseLineInfoData)) {
            retStatus = false;
            DialogMessageListComponentTc.addMessageRefToList(msgArray,
                LineUtils.CASE_LINE_CATEGORY, pCaseLineInfoData.LINESUBLINESEQVIR, MessageType.ERROR, "Current Estimated Value is required when Source of Supply is EDA.");
        }
        //FR15
        if (this.isConditionCdRequired(pCaseLineInfoData)) {
            retStatus = false;
            DialogMessageListComponentTc.addMessageRefToList(msgArray,
                LineUtils.CASE_LINE_CATEGORY, pCaseLineInfoData.LINESUBLINESEQVIR, MessageType.ERROR, "Condition is required when Source of Supply is EDA.");
        }
        //FR8
        if (this.isQuantityRequired(pCaseLineInfoData)) {
            retStatus = false;
            DialogMessageListComponentTc.addMessageRefToList(msgArray,
                LineUtils.CASE_LINE_CATEGORY, pCaseLineInfoData.LINESUBLINESEQVIR, MessageType.ERROR, "Quantity is required when Unit of Issue is not ‘XX'.");
        }
        //FR21 Payment Schedule Override To
        if (!this.isPaymentScheduleOverrideToValid(pCaseLineInfoData)) {
            retStatus = false;
            DialogMessageListComponentTc.addMessageRefToList(msgArray,
                LineUtils.CASE_LINE_CATEGORY, pCaseLineInfoData.LINESUBLINESEQVIR, MessageType.ERROR, "Payment Schedule Override From is required.");
        }
        //FR21 Payment Schedule Override From
        if (!this.isPaymentScheduleOverrideFromValid(pCaseLineInfoData)) {
            retStatus = false;
            DialogMessageListComponentTc.addMessageRefToList(msgArray,
                LineUtils.CASE_LINE_CATEGORY, pCaseLineInfoData.LINESUBLINESEQVIR, MessageType.ERROR, "Payment Schedule Override To is required.");
        }
        //FR37
        if (this.isPercentageExceeded(pCaseLineInfoData.percent_STOCK_RT)) {
            retStatus = false;
            DialogMessageListComponentTc.addMessageRefToList(msgArray,
                LineUtils.CASE_LINE_CATEGORY, pCaseLineInfoData.LINESUBLINESEQVIR,
                MessageType.ERROR, "Percentage cannot exceed 100%.");
        }
        //FR72 - partial
        if (this.doesCaseLineHaveSCM(pCaseLineInfoData)) {
            retStatus = false;
            DialogMessageListComponentTc.addMessageRefToList(msgArray,
                LineUtils.CASE_LINE_CATEGORY, pCaseLineInfoData.LINESUBLINESEQVIR,
                MessageType.ERROR, "A Small Case Management Line already exists for this case.");
        }
        // FR45: Subline warnings
        if (!!pCaseLineInfoData.wm_USER_CASE_SUBLINE_TX || !pCaseLineInfoData.wm_HAS_SUBLINES) {
            if (!!pCaseLineInfoData.customer_ORGANIZATION_ID &&
                !!pCaseLineInfoData.wm_CM_CUSTOMER_ORGANIZATION_ID &&
                pCaseLineInfoData.customer_ORGANIZATION_ID === pCaseLineInfoData.wm_CM_CUSTOMER_ORGANIZATION_ID) {
                retStatus = false;
                DialogMessageListComponentTc.addMessageRefToList(msgArray,
                    LineUtils.CASE_LINE_CATEGORY, pCaseLineInfoData.LINESUBLINESEQVIR, MessageType.WARNING, "A Security Cooperation (SC) program was selected as a benefitting country for this line.");
            }
        }
        return retStatus;
    }

    //check specific fields for line details
    public static areSpecificFieldsValidForLineDetails(pCaseLineInfoData: ifaceCaseLineData,
        pCaseLineRelatedInfoData: CaseLineRelatedInfoType,
        msgArray: Array<ErrorParameter>): boolean {
        var retStatus: boolean = true;
        this.areAllDataValid(pCaseLineInfoData, msgArray);

        //FR14
        if (this.isPEORequired(pCaseLineInfoData, pCaseLineRelatedInfoData)) {
            retStatus = false;
            DialogMessageListComponentTc.addMessageRefToList(msgArray,
                LineUtils.CASE_LINE_CATEGORY, pCaseLineInfoData.LINESUBLINESEQVIR, MessageType.ERROR, "PEO/PM is Mandatory for all added lines.");
        }
        //FR24
        if (!this.isESFromDateValid(pCaseLineInfoData)) {
            if (!!pCaseLineInfoData.wm_USER_CASE_SUBLINE_TX) {
                DialogMessageListComponentTc.addMessageRefToList(msgArray,
                    LineUtils.CASE_LINE_CATEGORY, pCaseLineInfoData.LINESUBLINESEQVIR, MessageType.ERROR, "If entered, the Estimated Service Dates for the subline must contain both “From” and “To” portions.");
            }
            else {
                DialogMessageListComponentTc.addMessageRefToList(msgArray,
                    LineUtils.CASE_LINE_CATEGORY, pCaseLineInfoData.LINESUBLINESEQVIR, MessageType.ERROR, "If entered, the Estimated Service Dates for the line must contain both “From” and “To” portions.");
            }
            retStatus = false;
        }
        else if (!this.isESToDateValid(pCaseLineInfoData)) {
            retStatus = false;
            if (!!pCaseLineInfoData.wm_USER_CASE_SUBLINE_TX) {
                DialogMessageListComponentTc.addMessageRefToList(msgArray,
                    LineUtils.CASE_LINE_CATEGORY, pCaseLineInfoData.LINESUBLINESEQVIR, MessageType.ERROR, "If entered, the Estimated Service Dates for the subline must contain both “From” and “To” portions.");
            }
            else {
                DialogMessageListComponentTc.addMessageRefToList(msgArray,
                    LineUtils.CASE_LINE_CATEGORY, pCaseLineInfoData.LINESUBLINESEQVIR, MessageType.ERROR, "If entered, the Estimated Service Dates for the line must contain both “From” and “To” portions.");
            }
        }
        if (pCaseLineInfoData.wm_PARENT_IS_MDE && !LineUtils.isCLDSpopulated(pCaseLineInfoData)) {
            retStatus = false;
            DialogMessageListComponentTc.addMessageRefToList(msgArray,
                LineUtils.CASE_LINE_CATEGORY, pCaseLineInfoData.LINESUBLINESEQVIR, MessageType.WARNING, "A Delivery Schedule should be entered if the parent case line has a MASL that is SME/MDE.");
        }
        //validate MASL and Line Purpose
        let isValid = this.isMASLAndLPValid(pCaseLineInfoData, msgArray);
        if (retStatus) retStatus = isValid;

        return retStatus;
    }

    //FR72 - Line Purpose and MASL
    public static isMASLAndLPValid(pCaseLineInfoData: ifaceCaseLineData,
        msgArray: Array<ErrorParameter>): boolean {
        var retStatus: boolean = true;
        if ((CaseCommonValidator.isEqual(pCaseLineInfoData.line_PURPOSE_CD, LineUtils.LINE_PURPOSE_CE) &&
            !CaseCommonValidator.isEqual(pCaseLineInfoData.military_ARTICLE_SERVICE_CD, LineUtils.MASL_SMALLCASESUPT)) ||
            (!CaseCommonValidator.isEqual(pCaseLineInfoData.line_PURPOSE_CD, LineUtils.LINE_PURPOSE_CE) &&
                CaseCommonValidator.isEqual(pCaseLineInfoData.military_ARTICLE_SERVICE_CD, LineUtils.MASL_SMALLCASESUPT))) {
            DialogMessageListComponentTc.addMessageRefToList(msgArray,
                LineUtils.CASE_LINE_CATEGORY, pCaseLineInfoData.LINESUBLINESEQVIR,
                MessageType.ERROR, "The MASL number must be compatible with the Line Purpose Code.");
            retStatus = false;
        }
        return retStatus;
    }

    //Check Delivery Term list for any required value
    public static isMandatoryDTFieldValid(pCaseLineInfoData: ifaceCaseLineData): boolean {
        if (pCaseLineInfoData.caseLineDeliveryTermList.length == 0) {
            return false;
        }
        else {
            for (let i = 0; i < pCaseLineInfoData.caseLineDeliveryTermList.length; i++) {
                if (!!pCaseLineInfoData.caseLineDeliveryTermList[i].delivery_TERM_ID) continue;
                else
                    return false;
            }
        }
        return true;
    }

    //Check Offer Release list for required value
    public static isMandatoryORFieldValid(pCaseLineInfoData: ifaceCaseLineData): boolean {
        if (pCaseLineInfoData.caseLineOfferReleaseList.length == 0) {
            return false;
        }
        else {
            for (let i = 0; i < pCaseLineInfoData.caseLineOfferReleaseList.length; i++) {
                if (!!pCaseLineInfoData.caseLineOfferReleaseList[i].offer_RELEASE_ID) continue;
                else
                    return false;
            }
        }
        return true;
    }

    //Check Item list for any existing value
    public static isMandatoryItemFieldValid(pCaseLineInfoData: ifaceCaseLineData): boolean {
        if (pCaseLineInfoData.caseLineDeliveryItemList.length == 0) {
            return false;
        }
        else {
            for (let i = 0; i < pCaseLineInfoData.caseLineDeliveryItemList.length; i++) {
                if (!!pCaseLineInfoData.caseLineDeliveryItemList[i].item_CD) continue;
                else
                    return false;
            }
        }
        return true;
    }

    //check mandatory fields for Line Delivery
    public static areFieldsValidForLineDelivery(pCaseLineInfoData: ifaceCaseLineData,
        msgArray: Array<ErrorParameter>): boolean {
        /*  Sonaqube rule
        var retStatus: boolean = true;
        // if (!this.isMandatoryORFieldValid(pCaseLineInfoData)) {
        //     retStatus = false;
        //     DialogMessageListComponentTc.addMessageRefToList(msgArray,
        //         LineUtils.CASE_LINE_CATEGORY, pCaseLineInfoData.LINESUBLINESEQVIR, MessageType.ERROR, "Offer Release is required.");
        // }
        // if (!this.isMandatoryDTFieldValid(pCaseLineInfoData)) {
        //     retStatus = false;
        //     DialogMessageListComponentTc.addMessageRefToList(msgArray,
        //         LineUtils.CASE_LINE_CATEGORY, pCaseLineInfoData.LINESUBLINESEQVIR, MessageType.ERROR, "Delivery Term is required.");
        // }
    
        return retStatus;
        */
        return true;
    }

    //check specific fields for Line Delivery
    public static areSpecificFieldsValidForLineDelivery(pCaseLineInfoData: ifaceCaseLineData,
        pCaseLineRelatedInfoData: CaseLineRelatedInfoType,
        msgArray: Array<ErrorParameter>): boolean {
        var retStatus: boolean = true;
        //Warning message only
        if (!this.isPerformancePeriodDataValid(pCaseLineInfoData)) {
            DialogMessageListComponentTc.addMessageRefToList(msgArray,
                LineUtils.CASE_LINE_CATEGORY, pCaseLineInfoData.LINESUBLINESEQVIR, MessageType.WARNING, "A Period of Performance is required for all defined order lines.");
        }

        //FR27 and FR28
        if (!this.isQuantityEqualSumOfCLDS(pCaseLineInfoData)) {
            retStatus = false;
            DialogMessageListComponentTc.addMessageRefToList(msgArray,
                LineUtils.CASE_LINE_CATEGORY, pCaseLineInfoData.LINESUBLINESEQVIR, MessageType.ERROR, "The sum of the line/subline delivery schedule total quantity must equal the line/subline quantity.");
        }
        //FR27 A delivery schedule must be entered if MASL is MDE/SME and Unit of Issue is not ‘XX’
        if (this.isCLDSRequiredForMASL(pCaseLineInfoData)) {
            retStatus = false;
            DialogMessageListComponentTc.addMessageRefToList(msgArray,
                LineUtils.CASE_LINE_CATEGORY, pCaseLineInfoData.LINESUBLINESEQVIR, MessageType.ERROR, "A delivery schedule must be entered if MASL is MDE/SME and Unit of Issue is not 'XX'.");
        }
        else {
            if (this.isCLDIpopulated(pCaseLineInfoData) && !this.isCLDSpopulated(pCaseLineInfoData)) {
                retStatus = false;
                DialogMessageListComponentTc.addMessageRefToList(msgArray,
                    LineUtils.CASE_LINE_CATEGORY, pCaseLineInfoData.LINESUBLINESEQVIR, MessageType.ERROR, "A delivery schedule must be entered if an item is given.");
            }
        }

        if (!this.isESFromDateGreaterThanESTo(pCaseLineInfoData)) {
            retStatus = true;
            DialogMessageListComponentTc.addMessageRefToList(msgArray,
                LineUtils.CASE_LINE_CATEGORY, pCaseLineInfoData.LINESUBLINESEQVIR,
                MessageType.ERROR, "The Estimated Services From date must occur on or before the Estimated Services To date.");
        }
        return retStatus;
    }


    // Determine if POR/NPOR is required.
    public static isNPORRequired(pCaseLineInfoData: ifaceCaseLineData): boolean {
        if (pCaseLineInfoData.status == DsamsConstants.ENT_NEW.toString() && CaseUtils.isBlankStr(pCaseLineInfoData.program_OF_RECORD_ID)){
            return true;
        }
        else if ((pCaseLineInfoData.wm_CASE_VERSION_TYPE_CD === "B"|| 
             pCaseLineInfoData.wm_CASE_VERSION_TYPE_CD === "A"||
             pCaseLineInfoData.wm_CASE_VERSION_TYPE_CD === "M") &&
            pCaseLineInfoData.wm_CASE_VERSION_STATUS_CD === "D" &&
            pCaseLineInfoData.change_ACTION_CD === "A" && 
            (pCaseLineInfoData.case_USAGE_INDICATOR_CD === "C" || pCaseLineInfoData.case_USAGE_INDICATOR_CD === "P")){
                console.log('pCaseLineInfoData.program_OF_RECORD_ID',pCaseLineInfoData.program_OF_RECORD_ID)
             if (CaseUtils.isBlankStr(pCaseLineInfoData.program_OF_RECORD_ID))
                return true;
           }
        return false;
    }


    //check to ensure percentage value is less than or equal to 100
    public static isPercentageExceeded(pStrValue: string): boolean {
        if (!CaseUtils.isBlankStr(pStrValue)) {
            if (parseInt(pStrValue) > 100) return true;
        }
        return false;
    }

    //return true if value is zero 
    public static isValueEqualZero(pStrValue: string): boolean {
        if (!CaseUtils.isBlankStr(pStrValue)) {
            if (parseInt(pStrValue) == 0) return true;
        }
        return false;
    }

    //sonarqube rule
    private static areSubsetPPFieldsValid(pCaseLineInfoData: ifaceCaseLineData,
        msgArray: Array<ErrorParameter>): boolean {
        var retStatus: boolean = true;
        //Performance Period From value must be ≤ the Period To value.
        if (!(CaseUtils.isBlankStr(pCaseLineInfoData.case_LINE_PERIOD_START_QY)) &&
            !(CaseUtils.isBlankStr(pCaseLineInfoData.case_LINE_PERIOD_END_QY))) {
            if ((parseInt(pCaseLineInfoData.case_LINE_PERIOD_START_QY)) > (parseInt(pCaseLineInfoData.case_LINE_PERIOD_END_QY))) {
                if (!!pCaseLineInfoData.wm_USER_CASE_SUBLINE_TX) {
                    DialogMessageListComponentTc.addMessageRefToList(msgArray,
                        LineUtils.CASE_LINE_CATEGORY, pCaseLineInfoData.LINESUBLINESEQVIR,
                        MessageType.ERROR, "The subline Performance Period start month (From) must not exceed the subline Performance Period end month (To).");
                }
                else {
                    DialogMessageListComponentTc.addMessageRefToList(msgArray,
                        LineUtils.CASE_LINE_CATEGORY, pCaseLineInfoData.LINESUBLINESEQVIR,
                        MessageType.ERROR, "The line Performance Period start month (From) must not exceed the line performance period end month (To).");
                }
                retStatus = false;
            }
        }
        return retStatus;
    }
    //sonarqube rule
    private static areAllPPFieldsValid(pCaseLineInfoData: ifaceCaseLineData,
        msgArray: Array<ErrorParameter>): boolean {
        var retStatus: boolean = true;
        //Performance Period From value must be ≤ the Period To value.
        retStatus = this.areSubsetPPFieldsValid(pCaseLineInfoData, msgArray);

        if (!this.isValueEqualZero(pCaseLineInfoData.case_LINE_PERIOD_END_QY) &&
            !this.isValueEqualZero(pCaseLineInfoData.case_LINE_PERIOD_START_QY)) {
            if (this.isValueEqualZero(pCaseLineInfoData.case_LINE_PERIOD_END_QY)) {
                DialogMessageListComponentTc.addMessageRefToList(msgArray,
                    LineUtils.CASE_LINE_CATEGORY, pCaseLineInfoData.LINESUBLINESEQVIR,
                    MessageType.ERROR, "Performance Period To must be greater than 0.");
                retStatus = false;
            }
            if (this.isValueEqualZero(pCaseLineInfoData.case_LINE_PERIOD_START_QY)) {
                DialogMessageListComponentTc.addMessageRefToList(msgArray,
                    LineUtils.CASE_LINE_CATEGORY, pCaseLineInfoData.LINESUBLINESEQVIR,
                    MessageType.ERROR, "Performance Period From must be greater than 0.");
                retStatus = false;
            }
        }
        return retStatus;
    }

    //Performance Period values must be greater than 0 
    public static arePPFieldsValid(pCaseLineInfoData: ifaceCaseLineData,
        msgArray: Array<ErrorParameter>): boolean {
        var retStatus: boolean = true;
        retStatus = this.areAllPPFieldsValid(pCaseLineInfoData, msgArray);
        if (((CaseUtils.isBlankStr(pCaseLineInfoData.case_LINE_PERIOD_START_QY)) &&
            !(CaseUtils.isBlankStr(pCaseLineInfoData.case_LINE_PERIOD_END_QY))) ||
            ((CaseUtils.isBlankStr(pCaseLineInfoData.case_LINE_PERIOD_END_QY)) &&
                !(CaseUtils.isBlankStr(pCaseLineInfoData.case_LINE_PERIOD_START_QY)))) {
            if (!!pCaseLineInfoData.wm_USER_CASE_SUBLINE_TX) {
                DialogMessageListComponentTc.addMessageRefToList(msgArray,
                    LineUtils.CASE_LINE_CATEGORY, pCaseLineInfoData.LINESUBLINESEQVIR,
                    MessageType.ERROR, "If entered, the Performance Period for the subline must contain both “From” and “To” portions.");
            }
            else {
                DialogMessageListComponentTc.addMessageRefToList(msgArray,
                    LineUtils.CASE_LINE_CATEGORY, pCaseLineInfoData.LINESUBLINESEQVIR,
                    MessageType.ERROR, "If entered, the Performance Period for the line must contain both “From” and “To” portions.");
            }
            retStatus = false;
        }
        return retStatus;
    }

    /* FR72
     Validate that there is only one Small Case Management line on the case. 
     If there is more than one, display error message (XXXXXX, A Small Case Management Line already exists for this case)
     (In the CASE_LINE table, IF a LINE_PURPOSE_CD of ‘CE’ exists for the WORKING_CASE_VERSION_ID)
    */
    public static doesCaseLineHaveSCM(pCaseLineInfoData: ifaceCaseLineData): boolean {
        if (CaseCommonValidator.isEqual(pCaseLineInfoData.line_PURPOSE_CD, LineUtils.LINE_PURPOSE_CE)
            && pCaseLineInfoData.doesCaseLineHaveSCM) return true;
        return false;
    }
    /* FR72 
    If the CUSTOMER_ORGANIZATION.CUSTOMER_TYPE_CD = PS, display confirmation message [M1]. 
    "This is a 36(b), Congressional Notification document Please ensure that no references are made to 
    classified information!
    */
    public static isPSCode(pCaseLineInfoData: ifaceCaseLineData): boolean {
        if (CaseCommonValidator.isEqual(pCaseLineInfoData.case_CUSTOMER_TYPE_CD, LineUtils.CUSTOMER_TYPE_PS))
            return true;
        return false;
    }

    //transfer data from CML down to CL entity. 
    //These CaseRelatedInfoType values are being populated on the Case Search Summary screen.
    public static transferCMLDataToCL(pCaseLineInfoData: ifaceCaseLineData,
        pCaseRelatedInfoData: CaseRelatedInfoType) {
        pCaseLineInfoData.case_ID = pCaseRelatedInfoData.case_ID;
        pCaseLineInfoData.working_CASE_ID = pCaseRelatedInfoData.working_CASE_ID;
        pCaseLineInfoData.case_MASTER_LINE_ID = pCaseRelatedInfoData.case_MASTER_LINE_ID;
        pCaseLineInfoData.working_CASE_VERSION_ID = pCaseRelatedInfoData.working_CASE_VERSION_ID;
        pCaseLineInfoData.implementing_AGENCY_ID = pCaseRelatedInfoData.implementing_AGENCY_ID;
        pCaseLineInfoData.case_USAGE_INDICATOR_CD = pCaseRelatedInfoData.case_USAGE_INDICATOR_CD;
        pCaseLineInfoData.offer_EXPIRATION_DT = pCaseRelatedInfoData.offer_EXPIRATION_DT;
        pCaseLineInfoData.case_CUSTOMER_TYPE_CD = pCaseRelatedInfoData.case_CUSTOMER_TYPE_CD;
        //workaround solution for those attributes that are not initialized
        pCaseLineInfoData.wm_CASE_LINE_LOI_IN = false;
        pCaseLineInfoData.wm_USER_CASE_LINE_NUMBER_ID = '';
        pCaseLineInfoData.wm_USER_CASE_SUBLINE_TX = '';
        //workaround for those attributes that are not initialized
        pCaseLineInfoData.percent_STOCK_RT = '';
        pCaseLineInfoData.sumOfAllQuantities = 0;
    }

    // Author: Jeff Sniffen
    // Turns on or off the editablity for the line 
    public static isLineEditable(mCaseLineInfoData: ifaceCaseLineData): boolean {
        if (mCaseLineInfoData.change_ACTION_CD === 'A'
            && mCaseLineInfoData.wm_CASE_VERSION_STATUS_CD === 'D'
            && mCaseLineInfoData.wm_CASE_LINE_LOI_IN === false
            && mCaseLineInfoData.case_USAGE_INDICATOR_CD !== 'I') {
            return true;
        }
        else {
            return false;
        }
    }

    // Author: Jeff Sniffen
    // Turns on or off the editablity for the Subline 
    public static isSublineEditable(tCaseLineInfoData: ifaceCaseLineData): boolean {
        if (tCaseLineInfoData.change_ACTION_CD === 'A'
            && tCaseLineInfoData.wm_CASE_VERSION_STATUS_CD === 'D'
            && tCaseLineInfoData.wm_CASE_LINE_LOI_IN === false
            && tCaseLineInfoData.case_USAGE_INDICATOR_CD !== 'I') {
            return true;
        }
        else {
            return false;
        }
    }

    // Determine if the caseLineInfo requires the NPOR to be checked.
    // Does not account for NPOR being changed. That's the responsibility of the panel program.
    public static doNporCheck(pCaseLineInfoData: ifaceCaseLineData): boolean {
        return (pCaseLineInfoData.wm_CASE_VERSION_TYPE_CD === "B" || pCaseLineInfoData.wm_CASE_VERSION_TYPE_CD === "A" || pCaseLineInfoData.wm_CASE_VERSION_TYPE_CD === "M") &&
            (!pCaseLineInfoData.wm_USER_CASE_SUBLINE_TX || pCaseLineInfoData.wm_USER_CASE_SUBLINE_TX === "") &&
            (pCaseLineInfoData.case_USAGE_INDICATOR_CD === "C" || pCaseLineInfoData.case_USAGE_INDICATOR_CD === "P")
        // Legacy has the clause below, but that won't work here because NPOR is only enabled for change_ACTION_CD=A
        // (pCaseLineInfoData.change_ACTION_CD === "C" || pCaseLineInfoData.change_ACTION_CD === "U");
    }

    // Add Post-save messages
    public static collectPostSaveMessages(pMessageList: Array<string>): Array<ErrorParameter> {
        let msgArray: Array<ErrorParameter> = [];
        if (!!pMessageList) {
            for (let currMsg of pMessageList) {
                let msgKey: string = "";
                if (currMsg === "WW22592") {
                    msgKey = "W314";
                }
                else if (currMsg === "WW22593") {
                    msgKey = "W315";
                }
                DialogMessageListComponentTc.addMessageRefToList(msgArray,
                    LineUtils.CASE_LINE_CATEGORY, "", MessageType.WARNING, MessageMgr.getMesssage(msgKey).messageText);
            }
        }
        return msgArray;
    }

    // begin DSAMS-5212 03/22 DB
  
    public static getInitializedCaseLineInfo(): ifaceCaseLineData {
        //since it is an interface, we need to initialize them
        //Set initial values to avoid display undefined values error
        let cliData: ifaceCaseLineData = {
            //this is for Header section
            wm_USER_CASE_LINE_NUMBER_ID: '',
            wm_USER_CASE_SUBLINE_TX: '',
            wm_CASE_LINE_LOI_IN: false,
            wm_CML_SERVICES_COMPLETE_IN: false,
            wm_EXCLUSION_IN: false,
            wm_CASE_VERSION_STATUS_CD: '',
            change_ACTION_TITLE_NM: '',
            offer_EXPIRATION_DT: '',
            implementing_AGENCY_ID: '',
            LINESUBLINESEQVIR: '',
            case_CUSTOMER_TYPE_CD: '',
            customer_ORGANIZATION_ID: '',
            //this is for Line Detail tab
            case_LINE_ITEM_QY: '', generic_CD: '', military_ARTICLE_SERVICE_CD: '',
            line_PURPOSE_CD: '', line_PURPOSE_TITLE_NM: '', issue_UNIT_CD: '',
            article_DESCRIPTION_TX: '', major_DEFENSE_EQUIPMENT_CD: '', equipment_TYPE_TITLE_NM: '',
            stock_ON_ORDER_COST_AM: '0', stock_ON_HAND_COST_AM: '0', total_ABOVE_LINE_COST_AM: '',
            unit_ABOVE_LINE_COST_AM: '', part_NUMBER_IN: false, other_PART_NUMBER_IN: false,
            acquisition_VALUE_AM: '0', inventory_VALUE_AM: '0', percent_STOCK_RT: '',
            missile_TECH_CNTRL_REGIME_ID: '', mtcr_TITLE_NM: '', mde_SME_CD: '', parent_MDE_SME_CD: '',
            national_STOCK_NUMBER_ID: '', other_NATIONAL_STOCK_NUMBER_ID: '',
            caseLineAssistanceTypeList: [],
            //this is for delivery tab
            case_LINE_PERIOD_START_QY: '', case_LINE_PERIOD_END_QY: '',
            case_LINE_PAY_PERIOD_START_QY: '', case_LINE_PAY_PERIOD_END_QY: '',
            case_LINE_AVAILABILITY_LEAD_QY: '', case_LINE_SHIPMENT_TX: '',
            estimated_DELIVERY_END_DT: '',
            estimated_DELIVERY_DT: '',
            shipment_STATUS_ID: '',
            title_NM: '',
            sumOfAllQuantities: 0,
            caseLineDeliveryItemList: [], caseLineOfferReleaseList: [], caseLineDeliveryTermList: [],
           //private attributes
            isLinePurposeDisabled: false
        }
        LineUtils.theDeletedCLATListArray = [];
        return cliData;
    }

    // end DSAMS-5212 03/22 DB

}