import { OnInit, ViewChildren, QueryList, Output, EventEmitter, ViewChild, ChangeDetectorRef, Component, Injector } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { MatTableDataSource, MatPaginator, MatSort } from '@angular/material';
import { ifaceCaseLineListArray, ifaceCaseMasterLine, ifaceDeletedCaseLineArray, ifaceCaseLineData, ifaceCaseMasterLineEntity, ifaceCaseLineEntity, ifaceCaseLineSubsetArray } from '../../model/case-line-model';
import { MdePopoverTrigger } from '@material-extended/mde';
import { CaseUIService } from '../../services/case-ui-service';
import { CaseRestfulService } from '../../services/case-restful.service';
import { formatCurrency } from '@angular/common';
import { CaseUtils } from '../../utils/case-utils';
import { BehaviorSubject, Subscription } from 'rxjs';
import { CaseRelatedInfoType } from '../../model/case-related-info-type';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { DialogMessageYesnoComponent } from '../../../utilitis/dialogs/dialog-message-yesno/dialog-message-yesno.component';
import { DsamsConstants } from 'src/app/dsams/dsams.constants';
import { LineSublineRefComponent } from '../line-reference.component';
import { CaseLineRelatedInfoType } from '../../model/case-line-related-info-type';
import { CdkDragDrop, moveItemInArray } from '@angular/cdk/drag-drop';
import { FormControl } from '@angular/forms';
import { IEditResponseType } from '../../model/edit-response-type';
import { LineUtils } from '../line-utils';
import { MessageMgr } from '../../validation/message-mgr';
import { CaseCommonValidator } from '../../validation/case-common-validator';
import { RollupSublineComponent } from '../../dialogs/rollup-subline/rollup-subline.component';
import { ISelectOptions } from 'src/app/dsams/interfaces/i-select-options';
import { ErrorParameter } from '../../../entities/specialEntities/error-parameter.model';
import { DsamsUserMessageService } from '../../../services/dsams-user-message.service';
import { CsuCompNameHashTable } from 'src/app/dsams/utilitis/csu-component-hashtable';
import { take } from 'rxjs/operators';
// begin DSAMS-5912 09/22 DB
import { ImessageData } from 'src/app/dsams/interfaces/imessage-data';
// end DSAMS-5912 09/22 DB



export class caseLineMethod implements ifaceCaseLineListArray {
  getTOTAL_ABOVE_LINE_COST_AM(Val1: string, Val2: string) {
    return (parseFloat(Val1) * parseFloat(Val2));
  }
}

export interface HashTable {
  lineID: string,
  caseMasterLineId: number,
}
@Component({
  selector: 'app-line-subline',
  templateUrl: './line-subline.component.html',
  styleUrls: ['./line-subline.component.css',
    '../common-CSS.component.css']
})

export class LineSublineComponent implements OnInit {
  private static CHANGE_ACTION_ADDED: string = "A";
  private static alphabeticalString: string = 'abcdefghijklmnopqrstuvwxyz';
  private static CASE_LINE_EDITOR_STR: string = DsamsConstants.CASE_LINE_EDITOR;

  @Output() sendBackFromCaseLineLIst = new EventEmitter<boolean>();
  @Output() sendTabIndex = new EventEmitter<number>();
  @Output() sendTabLabel = new EventEmitter<string>();
  private tabId: number = 1; //indicate new Line/Subline tab
// begin DSAMS-5983 09/22 DB
  private static USER_ID: string = "userId";
  private static USER_ACTIVITY_ID: string = "userActivityId";
 
// end DSAMS-5983
  // @ViewChild(MdePopoverTrigger, { static: true }) trigger: MdePopoverTrigger;
  @ViewChildren(MdePopoverTrigger) trigger: QueryList<MdePopoverTrigger>;
  isLineDisabled: boolean = false;
  noCaseLinesFoundInd: boolean = false;
  @ViewChild(MatPaginator, { static: true }) private paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) private sort: MatSort;

  aCaseLineClass = new caseLineMethod();
  // theCaseLineListArray: ifaceCaseLineListArray[];
  theLineNumberDropdownArray: string[] = [];
  theLineNumberDropdownList: HashTable[] = [];
  theSublineNumberDropdownArray: string[] = [];
  theCaseLineListArray: ifaceCaseMasterLine["caseLineList"];
  _cloneCaseLineList: ifaceCaseMasterLine["caseLineList"];
  theCaseLineSubset: ifaceCaseLineSubsetArray["theCaseMasterLineId"];
  theDeletedCaseLineListArray: ifaceDeletedCaseLineArray[];
  _refreshDataSubscription: Subscription = null;
  isRefreshDataNeeded: boolean = false;
  hasSCM: boolean = false;

  rowDeletedIndex: number = 0;
  isLineListDataChanged: boolean = false;
  isLineSublineBeingMoved: boolean = false;
  lineFormCtl: FormControl = new FormControl();
  lineNumber: string;
  lineIndex: number;
  public isDisabledIPCbutton: boolean;
  public isIPCButtonVisible: boolean;

  columnsToDisplayCaseLineList = ['LineSublineNo', 'LinePurpose', 'Status', 'DeletedInd', 'ProfileInd', 'GenericCode', 'MASLCode',
    'MTCRInd', 'MDEInd', 'Quantity', 'UnitOfIssue', 'UnitCost', 'TotalCost', 'BECtry', 'Notes', 'Remarks', 'Attachments',
    'Exclude', 'RefreshRow', 'DeleteRow'];

  hideBECtryCol: boolean = false;
  hideExcludeCol: boolean = false;

  pageSizeOptions: number[];
  pageSize: any;
  pageIndex: any;
  lastSubLineIndex: number;
  matches: string[] = [];
  sublinesCount: number = 0;
  maxLines: number = 0;

  _caseUIServiceSubscription: Subscription;
  caseRelatedInfoData: CaseRelatedInfoType;
  caseLineRelatedInfoData: CaseLineRelatedInfoType;
  caseLineInfoData: ifaceCaseLineData = {};
  ActiveArrowColor: any = '#007db0';
  InactiveLightGrayColor = 'lightgray'
  InactiveArrowColor: any = 'darkgrey';
  private lastLineNumber: string;

  // Indicate where to fetch data for testing/debugging purposes
  _fetchDataFromJson: boolean = false;

  _clonedataSourcCaseLineList: any;
  dataSourceCaseLineList: any;
  previousDragRowIndex: number = 0; //set default to zero to prevent hung on drag
  selectedRowIndex: number = -1;    //set default to -1
  isLoading: BehaviorSubject<boolean> = new BehaviorSubject(false);
  private _editSubscription: Subscription = null;
  isDataEditAllowed: boolean = false;
  caseVersionStatusDevelopmentType: string = "D";
  isRefreshButtonVisible: boolean = false;
  // cd 5231
  caseHeaderData: any = {};
  CaseId: number = 0;
  CaseVersionId: number = 0;

  // Card 5232
  validApplyProfileCd: ISelectOptions[] = [
    { value: 'Y', viewValue: 'Y' },
    { value: 'A', viewValue: 'A' }
  ];
  // begin DSAMS-5983
  messageService: DsamsUserMessageService;
  // end dsams-5983
  private caseRestService: CaseRestfulService;
  private dialog: MatDialog;
  private CSUHashTable: CsuCompNameHashTable;

  //DSAMS-5461 DH 05/22
  theCSUId: string;
  isEditRightAccessGranted: boolean = true;

  constructor(private injector: Injector,
    private popUpDialog: MatDialog,
    private router: Router, private route: ActivatedRoute,
    private getLineSublineRefData: LineSublineRefComponent,
    private changeDetectorRef: ChangeDetectorRef,
    private caseUIService: CaseUIService) {
    // begin DSAMS-5983 09/22 DB
  this.messageService = injector.get<DsamsUserMessageService>(DsamsUserMessageService);
    // end DSAMS-5983 09/22 DB
    this.caseRestService = injector.get<CaseRestfulService>(CaseRestfulService);
    this.dialog = injector.get<MatDialog>(MatDialog);
    this.CSUHashTable = injector.get<CsuCompNameHashTable>(CsuCompNameHashTable);
  }

  ngOnInit() {

    
    //begin DSAMS-5461 DH 05/22
    let aCsuId = this.CSUHashTable.getCSUId(this.route.routeConfig.component.name);
    this.theCSUId = aCsuId ? aCsuId : CsuCompNameHashTable.CSU_CD_WP003;
    //end DSAMS-5461 DH 05/22

    // Commenting out per analysts, the options should always stay visible.
    //this.caseUIService.setIsOptionsMenuHidden(true);     // Flip the options menu to hidden.
    this.getEditAccessRight();

    //DSASM-1849 - remove the Calculate FMSO option as it is not applicable for line list
    this.caseUIService.setDisableCalculateFMSOOption(true);
    this.caseUIService.setEnableCalculateFMSOOption(false);

    this._clonedataSourcCaseLineList = new MatTableDataSource(this.theCaseLineListArray);
    this.dataSourceCaseLineList = new MatTableDataSource(this.theCaseLineListArray);
    //Disable Line and Pricing tabs
    this.caseUIService.setIsLineTabDisabled(true);
    this.getLineSublineRefData.setResetDynamicRefList(false);

    this.hasSCM = false;
    this.isLineListDataChanged = false;
    this.isLineSublineBeingMoved = false;
    this.rowDeletedIndex = 0;
    this._caseUIServiceSubscription = this.caseUIService.getCaseLineRelatedInfoValues().subscribe((value) => {
      this.caseLineRelatedInfoData = value;
    });
    this._caseUIServiceSubscription = this.caseUIService.getCaseRelatedInfoValues().subscribe((value) => {
      this.caseRelatedInfoData = value;
    });
    setTimeout(() => {
      if (!!this.caseRelatedInfoData) {
        this.populateNewCaseLineListFromServer();
      }
    }, 1000);
    // Set Toggle initially to false.
    this.caseUIService.caseEditService.next({
      ID: LineSublineComponent.CASE_LINE_EDITOR_STR,
      editToggle: this.caseUIService.getIsLineDataInEditMode()
    });
    if (!this.caseUIService.getIsLineDataInEditMode())
      this.caseUIService.flipToDisabledService.next(LineSublineComponent.CASE_LINE_EDITOR_STR);

    this.initializeCaseLineInfoData();
    this.subscribeToEditToggle();
    this.subscribeToSaveOnEditToggle();
    this.subscribeToContinueOnEditToggle();
    this.isContinueConfirmed = false;
    this.isSavedConfirmed = false;
  }

  ngOnDestroy() {
    if (this._caseUIServiceSubscription) this._caseUIServiceSubscription.unsubscribe();
    if (this._refreshDataSubscription) this._refreshDataSubscription.unsubscribe();
    if (!!this.theDeletedCaseLineListArray || this.isLineListDataChanged) {
      this.isLineListDataChanged = false;
      this.caseUIService.caseEditService.next({
        ID: DsamsConstants.CASE_LINE_EDITOR,
        editToggle: false
      });
    }
    if (this.continueOnEditToggleSub) this.continueOnEditToggleSub.unsubscribe();
    if (this.saveOnEditToggleSub) this.saveOnEditToggleSub.unsubscribe();
  }

  ngAfterViewInit() {
    this.dataSourceCaseLineList.sort = this.sort;
    this.dataSourceCaseLineList.paginator = this.paginator;
    this.pageSize = this.paginator.pageSize;
    this.pageIndex = this.paginator.pageIndex;
  }

  ngAfterViewChecked() {
    this.changeDetectorRef.detectChanges();
  }

  //begin DSAMS-5461 DH 05/22
  getEditAccessRight(): void {
    this.getLineSublineRefData.getEditAccessRight(this.theCSUId)
      .pipe(take(1))
      .subscribe(result => {
        if (result == 1) this.isEditRightAccessGranted = true;
        else this.isEditRightAccessGranted = false;
      });
  }
  //end DSAMS-5461 DH 05/22

  // Subscribe to Save on Edit Toggle
  private saveOnEditToggleSub: Subscription = null;
  private isSavedConfirmed: boolean = false;
  subscribeToSaveOnEditToggle() {
    if (!!this.saveOnEditToggleSub) {
      this.saveOnEditToggleSub.unsubscribe();
      this.saveOnEditToggleSub = null;
    }
    this.saveOnEditToggleSub = this.caseUIService.theComponentSaveCaseLineState[CaseUIService.SAVE_CASE_LINE_LIST_STATE].isSaveConfirmed
      .subscribe(isSaveConfirmed => {
        if (isSaveConfirmed) {
          this.performSaveData();
        }
      });
  }

  // Subscribe to Continue on Edit Toggle
  private continueOnEditToggleSub: Subscription = null;
  private isContinueConfirmed: boolean = false;
  subscribeToContinueOnEditToggle() {
    if (!!this.continueOnEditToggleSub) {
      this.continueOnEditToggleSub.unsubscribe();
      this.continueOnEditToggleSub = null;
    }
    this.continueOnEditToggleSub = this.caseUIService.theComponentSaveCaseLineState[CaseUIService.SAVE_CASE_LINE_LIST_STATE].isContinueConfirmed
      .subscribe(isContinueConfirmed => {
        if (isContinueConfirmed) {
          this.isContinueConfirmed = true;
          this.populateNewCaseLineListFromServer();
          this.isLineListDataChanged = false;
          this.dataSourceCaseLineList._updateChangeSubscription();
        }
      });
  }

  // Subscribe to edit toggle event
  subscribeToEditToggle() {
    if (!this._editSubscription) {
      this._editSubscription = this.caseUIService
        .caseEditService
        .subscribe((pResponse: IEditResponseType) => {
          if (pResponse && pResponse.ID === LineSublineComponent.CASE_LINE_EDITOR_STR) {
            this.isDataEditAllowed = pResponse.editToggle;
            this.caseUIService.setIsLineDataInEditMode(pResponse.editToggle);
            //Jira-1849 DH - remove the Calculate FMSO option as it is not applicable for line list
            this.caseUIService.setDisableCalculateFMSOOption(true);
            this.caseUIService.setEnableCalculateFMSOOption(false);
            this.checkEditAbilityForLineList(pResponse.editToggle);
          }
        },
          err => {
            CaseUtils.ReporError("Error in Line List responding to edit toggle");
          }
        );
    }
  }

  /* makeLineSublineEditable() {
  //   if (this.isDataEditAllowed) { // Is the edit toggle disabled
  //     if (//!!this.caseLineInfoData.wm_USER_CASE_SUBLINE_TX ||
  //       !this.caseLineInfoData.wm_USER_CASE_SUBLINE_TX ||
  //       this.caseLineInfoData.wm_USER_CASE_SUBLINE_TX === "") { //Then it's a line 
  //       if (this.caseLineInfoData.change_ACTION_CD === 'A'
  //         && this.caseLineRelatedInfoData.case_VERSION_STATUS_CD === this.caseVersionStatusDevelopmentType
  //         && this.caseLineInfoData.wm_CASE_LINE_LOI_IN === false
  //         && this.caseLineInfoData.case_USAGE_INDICATOR_CD !== 'I')
  //       //if validation passes
  //       {
  //         this.caseUIService.allowLineChange.next(true);
  //         this.caseUIService.allowSublineChange.next(false);
  //       }
  //       // if validation fails
  //       else {
  //         this.caseUIService.allowLineChange.next(false);
  //         this.caseUIService.allowSublineChange.next(false);
  //       }
  //     } else { // It's a subline
  //       if (this.caseLineInfoData.change_ACTION_CD === 'A'
  //         && this.caseLineRelatedInfoData.case_VERSION_STATUS_CD === this.caseVersionStatusDevelopmentType
  //         && this.caseLineInfoData.wm_CASE_LINE_LOI_IN === false
  //         && this.caseLineInfoData.case_USAGE_INDICATOR_CD !== 'I')
  //       //if validation passes 
  //       {
  //         this.caseUIService.allowLineChange.next(false);
  //         this.caseUIService.allowSublineChange.next(true);
  //       } else { // if validation fails
  //         this.caseUIService.allowLineChange.next(false);
  //         this.caseUIService.allowSublineChange.next(false);
  //       }
  //     }
  //   } else {
  //     this.caseUIService.allowLineChange.next(false);
  //     this.caseUIService.allowSublineChange.next(false);
  //   }
  // }
  */

  checkEditAbilityForLineList(pEditToggle: boolean) {
    if (pEditToggle) {
      this.setRenumberAllowedVal(pEditToggle);
    }
    else {
    
      if (!this.isLineListDataChanged) {
        this.isDataEditAllowed = false;
        this.dataSourceCaseLineList.data.forEach(element => {
          element.isDeleteAllowed = false;
          element.isRefreshAllowed = false;
          element.isRenumberAllowed = false;
          element.isRowBeingMoved = false;
        })
      }
    }
  }

  onSelectClick(line: string, index: number) {
    this.lineNumber = line;
    this.lineIndex = index;
  }

  //per sonarqube rule
  //get the parent case master line id from dropdown line list
  getParentCaseMasterLineID(): number {
    for (let eachRow of this.theLineNumberDropdownList) {
      if (CaseCommonValidator.isEqual(eachRow.lineID, this.lineNumber)) {
        return (eachRow.caseMasterLineId);
      }
    }
    return 0;
  }

  //recursive loop to get next available sublines
  searchAvailableSubline(eachVirtualSubline: any): string {
    let lastIndex = eachVirtualSubline.length - 1;
    //get the last subline string to be used for obtaining the next string in the alphabeticalString list
    let lastSubline: string = eachVirtualSubline[lastIndex];
    //truncate the last subline string to get the prefix string
    let truncateSubline: string = lastSubline.substring(0, eachVirtualSubline[lastIndex].length - 1);
    //parsing to get the last character of the last subline
    let lastChar: string = lastSubline.substring(lastSubline.length - 1);

    //get the last char index of the the last character above
    let lastPosIndex: number = LineSublineComponent.alphabeticalString.indexOf(lastChar);

    var nextAvailChar: string;
    var appendSubline: string;
    if (lastPosIndex == LineSublineComponent.alphabeticalString.length - 1) {
      //get next avail char in the alphabeticalString using the first position
      nextAvailChar = this.getSublineChar(0);
      /* append the next avail to current subline string (hardcode a)
      //appendSubline truncateSubline.concat('a'+ nextAvailChar);
      */
      appendSubline = truncateSubline.concat(nextAvailChar);
    }
    else {
      //get next avail char in the alphabeticalString using the last index position
      nextAvailChar = this.getSublineChar(lastPosIndex + 1);
      //append the next avail to current subline string
      appendSubline = truncateSubline.concat(nextAvailChar);
    }
    return appendSubline;
  }

  //get next available subline
  getNextNewSubline(eachLine: any): string {
    if (!!eachLine.virtualSublineList) {
      if (eachLine.virtualSublineList.length >= LineSublineComponent.alphabeticalString.length) {
        return this.searchAvailableSubline(eachLine.virtualSublineList)
      }
      else return this.getSublineChar(eachLine.virtualSublineList.length);
    }
    else return this.getSublineChar(0);
  }

  //Jira 2661-DH
  createNewSubline() {
    // Call REST API to see if sub-line can be edited.
    // CML and Parent CML should be the same because we're already checking the parent to see if we can edit the sub-line.
    // this.caseRelatedInfoData.case_ID is null. use working_CASE_ID - Card 5198
    this.caseRestService
      .getCanSublineBeEdited(this.caseRelatedInfoData.working_CASE_ID,
        this.caseRelatedInfoData.working_CASE_VERSION_ID,
        this.theLineNumberDropdownArray[this.lineIndex])
      .subscribe((pResult: string) => {
        if (!pResult || pResult === DsamsConstants.NO_ERROR) {
          // Create the subline
          let aParentMasterLineId: number = this.getParentCaseMasterLineID();
          for (let eachLine of this.dataSourceCaseLineList.data) {
            if (eachLine.case_MASTER_LINE_ID == aParentMasterLineId) {
              this.dataSourceCaseLineList.data[this.lineIndex].wm_USER_CASE_SUBLINE_TX =
                this.getNextNewSubline(eachLine);
              break;
            }
          }
          this.navigateToDetailSubline(this.dataSourceCaseLineList.data[this.lineIndex].wm_USER_CASE_SUBLINE_TX, parseInt(this.lineNumber));
        }
        else {
          MessageMgr.displaySinglePopupError("E" + pResult);
        }
      },
        err => {
          CaseUtils.ReportHTTPError(err, "Determining if subline can be created. Possible no lines in line list.");
        });
  }

  /* not used 
  createNewSublineBAK() {
    // Call REST API to see if sub-line can be edited.
    // CML and Parent CML should be the same because we're already checking the parent to see if we can edit the sub-line.
    this.caseRestService
      .getCanSublineBeEdited(this.caseRelatedInfoData.case_ID,
        this.caseRelatedInfoData.working_CASE_VERSION_ID,
        this.theLineNumberDropdownArray[this.lineIndex])
      .subscribe((pResult: string) => {
        if (!pResult || pResult === DsamsConstants.NO_ERROR) {
          // Create the subline
          for (let i = 0; i < this.dataSourceCaseLineList.data.length; i++) {
            if (this.dataSourceCaseLineList.data[i].wm_USER_CASE_LINE_NUMBER_ID === this.lineNumber &&
              this.dataSourceCaseLineList.data[i].wm_USER_CASE_SUBLINE_TX !== null) {
              this.sublinesCount = this.sublinesCount + 1;
              this.matches.push(this.dataSourceCaseLineList.data[i].wm_USER_CASE_SUBLINE_TX);
            }
          }
          if (this.sublinesCount === 0) {
            this.dataSourceCaseLineList.data[this.lineIndex].wm_USER_CASE_SUBLINE_TX = this.getSublineChar(0);
          } else {
            this.dataSourceCaseLineList.data[this.lineIndex].wm_USER_CASE_SUBLINE_TX =
              this.getNewSubline(this.matches[--this.sublinesCount]);
          }
          this.navigateToDetailSubline(this.dataSourceCaseLineList.data[this.lineIndex].wm_USER_CASE_SUBLINE_TX, parseInt(this.lineNumber));
        }
        else {
          MessageMgr.displaySinglePopupError("E" + pResult);
        }
      },
        err => {
          CaseUtils.ReportHTTPError(err, "Determining if subline can be created. Possible no lines in line list.");
        });
    // } else {
    //   MessageMgr.swalFire({
    //     title: "Line " + this.lineNumber + " cannot be used to generate the subline," +
    //       "because it did not pass validation ",
    //     icon: 'error',
    //     showCancelButton: false,
    //     cancelButtonText: 'No',
    //     confirmButtonColor: '#3085d6',
    //     cancelButtonColor: '#d33',
    //     confirmButtonText: 'OK'
    //   });
    // }
  }

   getNewSubline(currentSublineChar: string): string {
    return this.getSublineChar(LineSublineComponent.alphabeticalString.indexOf(currentSublineChar) + 1);
  }
  */

  sortColumns(sort: MatSort) {
    const data = this.dataSourceCaseLineList.data.slice();
    if (!sort.active || sort.direction === '') {
      this.dataSourceCaseLineList.data = data;
      return;
    }
    this.dataSourceCaseLineList.data = data.sort((a, b) => {
      const isAsc = sort.direction === 'asc';
      switch (sort.active) {
        case 'LineSublineNo': return this.compare(a.LINESUBLINESEQVIR, b.LINESUBLINESEQVIR, isAsc);
        case 'LinePurpose': return this.compare(a.line_PURPOSE_TITLE_NM, b.line_PURPOSE_TITLE_NM, isAsc);
        case 'Status': return this.compare(a.change_ACTION_CD + '-' + a.change_ACTION_TITLE_NM, b.change_ACTION_CD + '-' + b.change_ACTION_TITLE_NM, isAsc);
        case 'DeletedInd': return this.compare(a.case_LINE_MARK_FOR_DELETION_IN, b.case_LINE_MARK_FOR_DELETION_INs, isAsc);
        case 'ProfileInd': return this.compare(a.apply_PROFILE_LINE_CD, b.apply_PROFILE_LINE_CD, isAsc);
        case 'GenericCode': return this.compare(a.generic_CD, b.generic_CD, isAsc);
        case 'MASLCode': return this.compare(a.military_ARTICLE_SERVICE_CD, b.military_ARTICLE_SERVICE_CD, isAsc);
        case 'MTCRInd': return this.compare(a.missile_TECH_CNTRL_REGIME_ID, b.missile_TECH_CNTRL_REGIME_ID, isAsc);
        case 'MDEInd': return this.compare(a.mde_SME_CD, b.mde_SME_CD, isAsc);
        case 'Quantity': return this.compare(a.case_LINE_ITEM_QY, b.case_LINE_ITEM_QY, isAsc);
        case 'UnitOfIssue': return this.compare(a.issue_UNIT_CD, b.issue_UNIT_CD, isAsc);
        case 'UnitCost': return this.compare(a.unit_ABOVE_LINE_COST_AM, b.unit_ABOVE_LINE_COST_AM, isAsc);
        case 'TotalCost': return this.compare(a.total_ABOVE_LINE_COST_AM, b.total_ABOVE_LINE_COST_AM, isAsc);
        case 'BECtry': return this.compare(a.customer_ORGANIZATION_ID, b.customer_ORGANIZATION_ID, isAsc);
        case 'Notes': return this.compare(a.case_LINE_NOTE_QY, b.case_LINE_NOTE_QY, isAsc);
        case 'Remarks': return this.compare(a.wm_CASE_LINE_REMARK_QY, b.wm_CASE_LINE_REMARK_QY, isAsc);
        case 'Attachments': return this.compare(a.case_LINE_ATTACHMENT_QY, b.case_LINE_ATTACHMENT_QY, isAsc);
        case 'Exclude': return this.compare(a.wm_EXCLUSION_IN, b.wm_EXCLUSION_IN, isAsc);
        default: return 0;
      }
    });
  }

  compare(a: number | string, b: number | string, isAsc: boolean) {
    return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
  }

  setPageSizeOptions(setPageSizeOptionsInput: string) {
    if (setPageSizeOptionsInput) {
      return this.pageSizeOptions = setPageSizeOptionsInput.split(',').map(str => +str);
    }
  }

  onPaginateEvent(event) {
    this.dataSourceCaseLineList.paginator.pageSize = event.pageSize;
    this.dataSourceCaseLineList.paginator.pageIndex = event.pageIndex;
    this.dataSourceCaseLineList.paginator.length = event.length;
    this.dataSourceCaseLineList.paginator.pageSizeOptions = this.paginator.pageSizeOptions;
    this.paginator.pageSize = event.pageSize;
    this.paginator.pageIndex = event.pageIndex;
    this.paginator.length = event.length;

    //delete button
    this.pageSize = event.pageSize;
    this.pageIndex = event.pageIndex;
  }

  //back to previous Case Search Summary page 
  goBackToCaseSearchSummary() {
    this.caseUIService.setbackToCaseSearchSummaryValue(true);
    //Disable Line and Pricing tabs
    this.caseUIService.setIsLineTabDisabled(true);
    this.router.navigateByUrl('/case/search');
  }

  //switch to the tab ID
  sendTabId() {
    //send new Line tab index as output
    this.caseUIService.setIsLineTabDisabled(false);
    this.caseUIService.setTheOriginalLineTabIndex(this.tabId);
    this.sendTabIndex.emit(this.tabId);
  }

  sendTabLabelId(pLabel: string) {
    //send new Line tab label as output
    this.sendTabLabel.emit(pLabel);
  }

  initializetheLineNumberDropdownArray() {
    this.theLineNumberDropdownArray = [];
  }

  //Initialize object here so that reference data can be prepopulated
  initializeCaseLineInfoData() {
    //since it is an interface, we need to initialize them
    //Set iniital values to avoid display undefined values error
    this.caseLineInfoData = {
      //this is for Header section
      wm_USER_CASE_LINE_NUMBER_ID: '',
      wm_USER_CASE_SUBLINE_TX: '',
      wm_CASE_LINE_LOI_IN: false,
      wm_CML_SERVICES_COMPLETE_IN: false,
      wm_EXCLUSION_IN: false,
      wm_CASE_VERSION_STATUS_CD: '',
      change_ACTION_TITLE_NM: '',
      offer_EXPIRATION_DT: '',
      implementing_AGENCY_ID: '',
      LINESUBLINESEQVIR: '',
      case_CUSTOMER_TYPE_CD: '',
      customer_ORGANIZATION_ID: '',
      //this is for Pricing tab
      recalculation_IN: false,
      //this is for Line Detail tab
      case_LINE_ITEM_QY: '', generic_CD: '', military_ARTICLE_SERVICE_CD: '',
      line_PURPOSE_CD: '', line_PURPOSE_TITLE_NM: '', issue_UNIT_CD: '',
      article_DESCRIPTION_TX: '', major_DEFENSE_EQUIPMENT_CD: '', equipment_TYPE_TITLE_NM: '',
      stock_ON_ORDER_COST_AM: '0', stock_ON_HAND_COST_AM: '0', total_ABOVE_LINE_COST_AM: '',
      unit_ABOVE_LINE_COST_AM: '', part_NUMBER_IN: false, other_PART_NUMBER_IN: false,
      acquisition_VALUE_AM: '0', inventory_VALUE_AM: '0', percent_STOCK_RT: '',
      missile_TECH_CNTRL_REGIME_ID: '', mtcr_TITLE_NM: '', mde_SME_CD: '', parent_MDE_SME_CD: '',
      national_STOCK_NUMBER_ID: '', other_NATIONAL_STOCK_NUMBER_ID: '',
      caseLineAssistanceTypeList: [],
      //this is for Delivery tab
      case_LINE_PERIOD_START_QY: '', case_LINE_PERIOD_END_QY: '',
      case_LINE_PAY_PERIOD_START_QY: '', case_LINE_PAY_PERIOD_END_QY: '',
      case_LINE_AVAILABILITY_LEAD_QY: '', case_LINE_SHIPMENT_TX: '',
      estimated_DELIVERY_END_DT: '',
      estimated_DELIVERY_DT: '',
      shipment_STATUS_ID: '',
      title_NM: '',
      sumOfAllQuantities: 0,
      caseLineDeliveryItemList: [], caseLineOfferReleaseList: [], caseLineDeliveryTermList: [],
      //private attributes
      isLinePurposeDisabled: false,
      isPricingDataChanged: false,
      isDataChanged: false,
    }
  }

  //FR2 - search for an available line
  // Occasionally there is a new set of sub line numbers that do not have a line with wm_USER_CASE_SUBLINE_TX == null to go with the set of sublines
  // so the else if to increment the line number is never increased and as soon as line number changes it numline is < so it is returned.
  generateLineNumber(): number {
    let dataSourceLength = this.dataSourceCaseLineList.data.length;
    let nextLineNbrId: number = 1;
    let lastLineNumberId: number = -1;
    for (var i = 0; i < dataSourceLength; i++) {
      let dsLineNbrId = parseInt(this.dataSourceCaseLineList.data[i].wm_USER_CASE_LINE_NUMBER_ID);
      if (nextLineNbrId < dsLineNbrId)
        return nextLineNbrId;
      if (dsLineNbrId > lastLineNumberId) {
        lastLineNumberId = dsLineNbrId;
        nextLineNbrId++;
      }
    }
    return nextLineNbrId;
  }


  //Add a new line
  menuNewLineButtonOnClick() {
    this.caseUIService.pricingReset.next(true);
    if (this.caseLineRelatedInfoData.case_VERSION_STATUS_CD.toUpperCase() == 'D') {
      this.initializeCaseLineInfoData();
      this.caseUIService.theComponentSaveCaseLineState[CaseUIService.SAVE_CASE_LINE_DETAILS_STATE].isDataChanged = true;
      if (!!this.dataSourceCaseLineList.data) {
        if (this.dataSourceCaseLineList.data.length >= 0) {
          this.caseLineInfoData.LINESUBLINESEQVIR = CaseUtils.formatLineNumber(this.generateLineNumber());
          this.lastLineNumber = this.caseLineInfoData.LINESUBLINESEQVIR;
        }
      }
      if (parseInt(this.lastLineNumber) > 999) {
        MessageMgr.swalFire({
          text: 'Line Number cannot exceed 999',
          icon: 'error',
          width: 400,
          focusConfirm: true,
          confirmButtonText: 'OK'
        })
      }
      else {
        this.caseLineInfoData.change_ACTION_CD = 'A';
        this.caseLineInfoData.change_ACTION_TITLE_NM = 'Added';
        this.caseLineInfoData.wm_CASE_VERSION_STATUS_CD = "D";
        LineUtils.transferCMLDataToCL(this.caseLineInfoData, this.caseRelatedInfoData);
        this.caseLineInfoData.doesCaseLineHaveSCM = this.hasSCM;
        this.caseLineInfoData.entityStatus = DsamsConstants.ENT_NEW.toString();
        if (!!this.caseLineInfoData.case_MASTER_LINE_ID) {
          this.caseLineInfoData.case_MASTER_LINE_ID = null;
        }
        this.caseLineInfoData.status = DsamsConstants.ENT_NEW.toString();
        this.caseLineInfoData.case_MASTER_LINE_ID = null;
        this.caseLineInfoData.isDataChanged = false;
        this.caseLineInfoData.isPricingDataChanged = false;
        this.caseUIService.setCaseLineInfoValues(this.caseLineInfoData);
        this.changeDetectorRef.detectChanges();
        this.caseUIService.setIsLineTabDisabled(false);
        this.caseUIService.setIsLineDataInEditMode(true);
        this.isLoading.next(false);
        //DSAMS-5269-03/22 DH
        this.getLineSublineRefData.setResetDynamicRefList(true);
        this.caseUIService.caseEditService.next({
          ID: LineSublineComponent.CASE_LINE_EDITOR_STR,
          editToggle: true
        });
        this.sendTabId();
        this.sendTabLabelId("Line");
      }
    }
    else {
      MessageMgr.swalFire({
        text: 'The selected DSAMS function is only available for the document being in Development status.',
        icon: 'error',
        width: 400,
        focusConfirm: true,
        confirmButtonText: 'OK'
      })
    }
  }


  //Add a new subline when clicked on the menu in line list (Add) button. 
  navigateToDetailSubline(sublineNum: string, lineNum: number) {
    if (this.caseLineRelatedInfoData.case_VERSION_STATUS_CD.toUpperCase() == 'D') {
      var lineNumberIndex = this.convertlineNumToInt(lineNum);
      this.initializeCaseLineInfoData();
      LineUtils.transferCMLDataToCL(this.caseLineInfoData, this.caseRelatedInfoData);
      //DSAMS-5269-03/22 DH
      this.getLineSublineRefData.setResetDynamicRefList(true);
      this.caseLineInfoData.isEntityNew = true;
      this.caseLineInfoData.wm_PARENT_CASE_ID = this.dataSourceCaseLineList.data[lineNumberIndex].case_ID;
      this.caseLineInfoData.wm_PARENT_CASE_MASTER_LINE_ID = this.dataSourceCaseLineList.data[lineNumberIndex].case_MASTER_LINE_ID;
      this.caseLineInfoData.customer_ORGANIZATION_ID = this.dataSourceCaseLineList.data[lineNumberIndex].customer_ORGANIZATION_ID;
      this.caseLineInfoData.wm_CM_CUSTOMER_ORGANIZATION_ID = this.dataSourceCaseLineList.data[lineNumberIndex].wm_CM_CUSTOMER_ORGANIZATION_ID;
      this.caseLineInfoData.wm_PARENT_CHANGE_ACTION_CD = this.dataSourceCaseLineList.data[lineNumberIndex].wm_PARENT_CHANGE_ACTION_CD;
      this.caseLineInfoData.wm_PARENT_IS_PRICED = this.dataSourceCaseLineList.data[lineNumberIndex].wm_PARENT_IS_PRICED;
      this.caseLineInfoData.wm_LINE_IS_PRICED = this.dataSourceCaseLineList.data[lineNumberIndex].wm_LINE_IS_PRICED;
      this.caseLineInfoData.wm_CML_IMPLEMENTED_CASE_ID = this.dataSourceCaseLineList.data[lineNumberIndex].wm_CML_IMPLEMENTED_CASE_ID;
      this.caseLineInfoData.wm_CML_IMPLEMENTED_CASE_VRSN_ID = this.dataSourceCaseLineList.data[lineNumberIndex].wm_CML_IMPLEMENTED_CASE_VRSN_ID;
      this.caseLineInfoData.wm_CM_IMPLEMENTED_CASE_ID = this.dataSourceCaseLineList.data[lineNumberIndex].wm_CM_IMPLEMENTED_CASE_ID;
      this.caseLineInfoData.wm_CM_IMPLEMENTED_CASE_VERSION_ID = this.dataSourceCaseLineList.data[lineNumberIndex].wm_CM_IMPLEMENTED_CASE_VERSION_ID;
      this.caseLineInfoData.wm_CHECK_NPOR = this.dataSourceCaseLineList.data[lineNumberIndex].wm_CHECK_NPOR;
      this.caseLineInfoData.wm_CASE_LINE_LOI_IN = this.dataSourceCaseLineList.data[lineNumberIndex].wm_CASE_LINE_LOI_IN;
      this.caseLineInfoData.LINESUBLINESEQVIR = CaseUtils.formatLineNumber(lineNum);
      this.caseLineInfoData.wm_USER_CASE_LINE_NUMBER_ID = this.caseLineInfoData.LINESUBLINESEQVIR;
      this.caseLineInfoData.wm_USER_CASE_SUBLINE_TX = sublineNum;
      this.caseLineInfoData.change_ACTION_CD = 'A';
      this.caseLineInfoData.change_ACTION_TITLE_NM = 'Added';
      this.caseLineInfoData.wm_CASE_VERSION_STATUS_CD = this.caseLineRelatedInfoData.case_VERSION_STATUS_CD;
      this.caseLineInfoData.case_USAGE_INDICATOR_CD = this.caseRelatedInfoData.case_USAGE_INDICATOR_CD;
      this.caseLineInfoData.entityStatus = DsamsConstants.ENT_NEW.toString();
      this.caseLineInfoData.status = DsamsConstants.ENT_NEW.toString();
      this.caseLineInfoData.isDataChanged = false;
      this.caseLineInfoData.isPricingDataChanged = false;
      this.caseUIService.setCaseLineInfoValues(this.caseLineInfoData);
      this.caseUIService.setIsLineTabDisabled(false);
      this.caseUIService.setIsLineDataInEditMode(true);
      this.caseUIService.theComponentSaveCaseLineState[CaseUIService.SAVE_CASE_LINE_DETAILS_STATE].isDataChanged = true;
      this.caseUIService.caseEditService.next({
        ID: LineSublineComponent.CASE_LINE_EDITOR_STR,
        editToggle: true
      });
      this.sendTabId();
      this.sendTabLabelId("Subline");
      this.caseUIService.pricingReset.next(true);
    } else {
      MessageMgr.swalFire({
        text: 'The selected DSAMS function is only available for the document being in Development status.',
        icon: 'error',
        width: 400,
        focusConfirm: true,
        confirmButtonText: 'OK'
      })
    }
  }

  convertlineNumToInt(line: number): number {
    var index: number = 0;
    for (var x = 0; x < this.dataSourceCaseLineList.data.length; x++) {
      if (this.dataSourceCaseLineList.data[x].wm_USER_CASE_LINE_NUMBER_ID < CaseUtils.formatLineNumber(line)) {
        index = index + 1;
      }
    }
    return index;
  }

  private isAlpha(name: string): boolean {
    if (name.search("[a-zA-Z]") <= 0)
      return false;
    else return true;
  }

  populateParentLineInfo(pCaseId: any, pCaseMasterLineId: any) {
    for (let eachRow of this.dataSourceCaseLineList.data) {
      if (eachRow.case_ID == pCaseId &&
        eachRow.case_MASTER_LINE_ID == pCaseMasterLineId) {
        eachRow.parent_MDE_SME_CD = eachRow.mde_SME_CD;
        break;
      }
    }
    /*
    //  for (var i = 0; i < this.dataSourceCaseLineList.data.length; i++) {
    //   if (this.dataSourceCaseLineList.data[i].case_ID == pCaseId &&
    //     this.dataSourceCaseLineList.data[i].case_MASTER_LINE_ID == pCaseMasterLineId) {
    //     this.caseLineInfoData.parent_MDE_SME_CD = this.dataSourceCaseLineList.data[i].mde_SME_CD;
    //     i += 999;  //exit for loop properly
    //   }
    // }
    */
  }

  //Populate data for the line detail tab using non-legacy Rest API calls
  doubleClick(rowIndex: any) {
    this.caseUIService.pricingReset.next(false);
    //DSAMS-5269-03/22 DH
    this.getLineSublineRefData.setResetDynamicRefList(true);
    this.caseLineInfoData.case_MASTER_LINE_ID = this.caseRelatedInfoData.case_MASTER_LINE_ID;
    //set the original tab index to be the current selected one
    this.caseUIService.setTheOriginalLineTabIndex(1);
    //Enable Line and Pricing tabs
    const turnToggleOff: IEditResponseType = { ID: DsamsConstants.CASE_LINE_EDITOR, editToggle: false };
    this.caseUIService.caseEditService.next(turnToggleOff);
    this.caseUIService.setIsLineTabDisabled(false);
    //clone the data to display on the line tab
    this.caseLineInfoData = { ...this.dataSourceCaseLineList.data[rowIndex] };
    if (!!this.dataSourceCaseLineList.data[rowIndex].wm_USER_CASE_SUBLINE_TX)
      this.populateParentLineInfo(this.dataSourceCaseLineList.data[rowIndex].wm_PARENT_CASE_ID,
        this.dataSourceCaseLineList.data[rowIndex].wm_PARENT_CASE_MASTER_LINE_ID);
    this.caseLineInfoData.case_USAGE_INDICATOR_CD = this.caseRelatedInfoData.case_USAGE_INDICATOR_CD;
    this.caseLineInfoData.case_CATEGORY_CD = this.caseRelatedInfoData.case_CATEGORY_CD;
    this.caseLineInfoData.customer_NICKNAME_NM = CaseUtils.convertNAStrToBlank(this.caseLineInfoData.customer_NICKNAME_NM);
    if (this.dataSourceCaseLineList.data[rowIndex].estimated_DELIVERY_DT !== null)
      this.caseLineInfoData.estimated_DELIVERY_DT = this.dataSourceCaseLineList.data[rowIndex].estimated_DELIVERY_DT.substr(0, 10);

    if (this.dataSourceCaseLineList.data[rowIndex].estimated_DELIVERY_END_DT !== null)
      this.caseLineInfoData.estimated_DELIVERY_END_DT = this.dataSourceCaseLineList.data[rowIndex].estimated_DELIVERY_END_DT.substr(0, 10);

    //populate window mapping attribute case_VERSION_STATUS_CD
    if (this.caseLineRelatedInfoData) {
      this.caseLineInfoData.wm_CASE_VERSION_STATUS_CD = this.caseLineRelatedInfoData.case_VERSION_STATUS_CD;
    }
    this.caseLineInfoData.case_LINE_ITEM_QY = this.dataSourceCaseLineList.data[rowIndex].case_LINE_ITEM_QY;
    this.caseLineInfoData.change_ACTION_CD = this.dataSourceCaseLineList.data[rowIndex].change_ACTION_CD;
    console.log(this.caseLineInfoData.change_ACTION_CD, " Case Line action id 758");
    this.caseLineInfoData.change_ACTION_TITLE_NM = this.dataSourceCaseLineList.data[rowIndex].change_ACTION_TITLE_NM;

    //set refrence title description
    this.setTitleDescription();

    //Set initial value only. 
    this.caseLineInfoData.isDataChanged = false;
    this.caseLineInfoData.isPricingDataChanged = false;

    //console.log('doubleclick=', this.caseLineInfoData)
    //send up the selected case line entity to be used by the Line tab component
    this.caseUIService.setCaseLineInfoValues(this.caseLineInfoData);
    this.caseUIService.setResetCaseLineFromRefreshButton(this.caseLineInfoData);

    // Flip to disabled for opened line, since it won't automatically be eligible even if it's neighbor is.
    // this.caseUIService.flipToDisabledService.next(DsamsConstants.CASE_LINE_EDITOR);
    // this.caseUIService.caseEditService.next({ ID: DsamsConstants.CASE_LINE_EDITOR, editToggle: false });

    this.caseUIService.setNotifyToRefreshLineData(true);
    this.caseUIService.setNotifyToRefreshPricingData(true);

    //set default option - jeff
    this.caseUIService.setNotifyToSetDefaultOption(true);

    //Switch current displayed Tab to the chosen Tab ID
    this.sendTabId();
    if (this.isAlpha(this.dataSourceCaseLineList.data[rowIndex].LINESUBLINESEQVIR) == true)
      this.sendTabLabelId("Subline");
    else this.sendTabLabelId("Line");

  }

  //begin DSAMS-5269 DH 03/22 
  //populate data for case line reference dropdown list
  setTitleDescriptionForPOR() {
    for (let nporItem of LineSublineRefComponent.theReferenceLineDataList.programOfRecordList) {
      if (nporItem.integer_VALUE_CD == this.caseLineInfoData.program_OF_RECORD_ID) {
        this.caseLineInfoData.PORTitle = nporItem.value_TITLE_NM;
        break; //exit loop immediately once a POR ID matching pair is found
      }
    }
  }
  setTitleDescription() {
    //remap title description
    if (!!this.caseLineInfoData && !!this.caseLineInfoData.caseLineAssistanceTypeList) {
      this.caseLineInfoData.caseLineAssistanceTypeList.forEach(element => {
        if (!!element.assistance_TYPE_TITLE_TX)
          element.theAssistanceTypeCd = { assistance_TYPE_TITLE_TX: element.assistance_TYPE_TITLE_TX };
        else element.theAssistanceTypeCd = { assistance_TYPE_TITLE_TX: '' };
      })
      this.caseLineInfoData.caseLineOfferReleaseList.forEach(element => {
        if (!!element.offer_RELEASE_TITLE_NM)
          element.theOfferReleaseId = { offer_RELEASE_TITLE_NM: element.offer_RELEASE_TITLE_NM };
        else element.theOfferReleaseId = { offer_RELEASE_TITLE_NM: '' };
      })
      this.caseLineInfoData.caseLineDeliveryTermList.forEach(element => {
        if (!!element.delivery_TERM_TITLE_NM)
          element.theDeliveryTermId = { delivery_TERM_TITLE_NM: element.delivery_TERM_TITLE_NM };
        else element.theDeliveryTermId = { delivery_TERM_TITLE_NM: '' };
      })
    }
    this.setTitleDescriptionForPOR();
  }
  //end DSAMS-5269 DH 03/22 
  //disbale line
  setLineDisabled() {
    this.dataSourceCaseLineList.data.forEach((_item, index) => {
      if (this.dataSourceCaseLineList.data[index].wm_EXCLUSION_IN) {
        this.isLineDisabled = true;
      }
    })
  }

  /* This procedure converts currency to string for calculation */
  setCurrencyOnChange(rowElement: any, pVal: any) {
    let rowIndex: number = this.dataSourceCaseLineList.data.indexOf(rowElement);
    // Strip off dollar sign
    let pValue: number = Number(pVal.replace(/[^0-9.-]+/g, ""));

    this.dataSourceCaseLineList.data[rowIndex].total_ABOVE_LINE_COST_AM =
      formatCurrency(this.aCaseLineClass.getTOTAL_ABOVE_LINE_COST_AM(
        this.dataSourceCaseLineList.data[rowIndex].case_LINE_ITEM_QY,
        pValue.toString()), 'en', '$')
    this.dataSourceCaseLineList.data[rowIndex].unit_ABOVE_LINE_COST_AM = formatCurrency(pValue, 'en', '$')
    this.dataSourceCaseLineList._updateChangeSubscription();
  }

  /* This procedure checks the returned result value from the 
     popover Yes/No dialog window. */
  yesButtonOnClick(isDeleteConfirmed: any, rowElement: any) {
    if (isDeleteConfirmed) {
      if (this.isSelectedRowDeleteAllowed(rowElement))
        this.deleteLineListItem(rowElement);
      else {
        MessageMgr.swalFire({
          text: 'You have a Price Element/Fund combination with a Prior Year Obligation Value greater than $0.  Do you want to continue?',
          icon: 'warning',
          width: 500,
          showCancelButton: true,
          cancelButtonText: 'No',
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: 'Yes',
        }).then((result) => {
          if (result.value) {
            this.deleteLineListItem(rowElement);
          }
        })
      }
    }
  }

  /* This procedure is used to remove the row from the case line list. */
  deleteLineListItem(rowElement: any) {
    let rowIndex = this.dataSourceCaseLineList.data.indexOf(rowElement);
    let curLine = rowElement.wm_USER_CASE_LINE_NUMBER_ID;

    //do logical delete for any other statuses
    if (this.dataSourceCaseLineList.data[rowIndex].change_ACTION_CD !== 'A') {
      this.dataSourceCaseLineList.data[rowIndex].case_LINE_MARK_FOR_DELETION_IN = 'true';
      this.dataSourceCaseLineList.data[rowIndex].entityStatus = DsamsConstants.ENT_DELETED.toString();
      this.dataSourceCaseLineList.data[rowIndex].status = DsamsConstants.ENT_DELETED.toString();
      if (!!this.dataSourceCaseLineList.data[rowIndex].wm_USER_CASE_SUBLINE_TX) {
        this.dataSourceCaseLineList.data[rowIndex].change_ACTION_CD = 'C';
        this.dataSourceCaseLineList.data[rowIndex].change_ACTION_TITLE_NM = 'Changed';
      }
      else {
        this.dataSourceCaseLineList.data[rowIndex].change_ACTION_CD = 'D';
        this.dataSourceCaseLineList.data[rowIndex].change_ACTION_TITLE_NM = 'Deleted';
      }
    }
    else {
      // save the record being removed into the delete array 
      if (this.theDeletedCaseLineListArray == null) {
        //instantiate the theDeletedCaseLineListArray and create a new row
        this.theDeletedCaseLineListArray = [{
          case_ID: this.dataSourceCaseLineList.data[rowIndex].case_ID,
          case_MASTER_LINE_ID: this.dataSourceCaseLineList.data[rowIndex].case_MASTER_LINE_ID,
          working_CASE_ID: this.dataSourceCaseLineList.data[rowIndex].working_CASE_ID,
          working_CASE_VERSION_ID: this.dataSourceCaseLineList.data[rowIndex].working_CASE_VERSION_ID,
          service_DB_ID: CaseUtils.getServiceDatabaseId(),
          entityName: 'CASE_LINE',
          status: DsamsConstants.ENT_DELETED.toString(),
          change_ACTION_CD: this.dataSourceCaseLineList.data[rowIndex].change_ACTION_CD,
          wm_USER_CASE_LINE_NUMBER_ID: this.dataSourceCaseLineList.data[rowIndex].wm_USER_CASE_LINE_NUMBER_ID,
          wm_USER_CASE_SUBLINE_TX: this.dataSourceCaseLineList.data[rowIndex].wm_USER_CASE_SUBLINE_TX,
          wm_PARENT_CASE_MASTER_LINE_ID: this.dataSourceCaseLineList.data[rowIndex].wm_PARENT_CASE_MASTER_LINE_ID,
        }]
        this.rowDeletedIndex++;
      }
      else {
        //append a new row to the deleted array
        this.appendDeletedRow(rowIndex);
      }

      if (this.dataSourceCaseLineList.data[rowIndex].wm_USER_CASE_SUBLINE_TX == null)
        this.deleteAssociatedSubline(curLine, rowIndex)
      this.dataSourceCaseLineList.data.splice(rowIndex, 1);
      this.dataSourceCaseLineList = new MatTableDataSource(this.dataSourceCaseLineList.data);
      let lineNum = parseInt(this.lastLineNumber);
      if (lineNum > 1) {
        this.lastLineNumber = CaseUtils.formatLineNumber(lineNum - 1);
      }
      else this.lastLineNumber = '001';

      this.paginator.length = this.dataSourceCaseLineList.data.length;
      this.dataSourceCaseLineList.paginator = this.paginator;
    }
    this.isLineListDataChanged = true;
    this.caseUIService.theComponentSaveCaseLineState[CaseUIService.SAVE_CASE_LINE_LIST_STATE].isDataChanged = true;
    this.dataSourceCaseLineList._updateChangeSubscription();
  }

  //add the deleted row to the delete array
  appendDeletedRow(rowIndex: any) {
    this.theDeletedCaseLineListArray[this.rowDeletedIndex++] = {
      case_ID: this.dataSourceCaseLineList.data[rowIndex].case_ID,
      case_MASTER_LINE_ID: this.dataSourceCaseLineList.data[rowIndex].case_MASTER_LINE_ID,
      working_CASE_ID: this.dataSourceCaseLineList.data[rowIndex].working_CASE_ID,
      working_CASE_VERSION_ID: this.dataSourceCaseLineList.data[rowIndex].working_CASE_VERSION_ID,
      service_DB_ID: CaseUtils.getServiceDatabaseId(),
      entityName: 'CASE_LINE',
      status: DsamsConstants.ENT_DELETED.toString(),
      change_ACTION_CD: this.dataSourceCaseLineList.data[rowIndex].change_ACTION_CD,
      wm_USER_CASE_LINE_NUMBER_ID: this.dataSourceCaseLineList.data[rowIndex].wm_USER_CASE_LINE_NUMBER_ID,
      wm_USER_CASE_SUBLINE_TX: this.dataSourceCaseLineList.data[rowIndex].wm_USER_CASE_SUBLINE_TX,
      wm_PARENT_CASE_MASTER_LINE_ID: this.dataSourceCaseLineList.data[rowIndex].wm_PARENT_CASE_MASTER_LINE_ID,
    }
  }

  // delete all applicable sublines of the current deleted line
  deleteAssociatedSubline(pDeletedLine: any, pCurIndex: any) {
    let indexI: number = pCurIndex;
    while (indexI < this.dataSourceCaseLineList.data.length) {
      if (this.dataSourceCaseLineList.data[indexI].wm_USER_CASE_LINE_NUMBER_ID == pDeletedLine &&
        !!this.dataSourceCaseLineList.data[indexI].wm_USER_CASE_SUBLINE_TX) {
        this.appendDeletedRow(indexI);
        this.dataSourceCaseLineList.data.splice(indexI, 1);
        indexI--; //decremented so it will be incremented below
      }
      indexI++;
    }
    /* PRESERVED due to sonarqube undo
    for (let i = pCurIndex; i < this.dataSourceCaseLineList.data.length; i++) {
      if (this.dataSourceCaseLineList.data[i].wm_USER_CASE_LINE_NUMBER_ID == pDeletedLine &&
        !!this.dataSourceCaseLineList.data[i].wm_USER_CASE_SUBLINE_TX) {
        this.appendDeletedRow(i);
        this.dataSourceCaseLineList.data.splice(i, 1);
        --i;
      }
    }
    */
  }

  // Setting up the returned string for http post request
  getDeletedEntity(): string {
    var returnString: string = '';
    this.theDeletedCaseLineListArray.forEach((item, index) => {
      returnString = returnString + JSON.stringify(item);
      if (index < this.theDeletedCaseLineListArray.length - 1)
        returnString = returnString + ','
    })
    return returnString;
  }

  //Manually mapping the object for now since it is used for both save and delete functions
  prepareCaseMasterLineEntity(): ifaceCaseMasterLineEntity {
    var aCaseMasterLine: ifaceCaseMasterLineEntity = {};
    aCaseMasterLine.caseLineList = [];

    if (this.theDeletedCaseLineListArray) {
      for (let i = 0; i < this.theDeletedCaseLineListArray.length; i++) {
        var aCaseLineEntity: ifaceCaseLineEntity = {
          case_ID: this.theDeletedCaseLineListArray[i].case_ID,
          case_MASTER_LINE_ID: this.theDeletedCaseLineListArray[i].case_MASTER_LINE_ID,
          working_CASE_ID: this.theDeletedCaseLineListArray[i].working_CASE_ID,
          working_CASE_VERSION_ID: this.theDeletedCaseLineListArray[i].working_CASE_VERSION_ID,
          entityStatus: this.theDeletedCaseLineListArray[i].status,
          status: this.theDeletedCaseLineListArray[i].status,
          entityName: this.theDeletedCaseLineListArray[i].entityName,
          change_ACTION_CD: this.theDeletedCaseLineListArray[i].change_ACTION_CD,
        }
        aCaseMasterLine.service_DB_ID = CaseUtils.getServiceDatabaseId();
        aCaseMasterLine.caseLineList.push(aCaseLineEntity);
      }
    }

    this.dataSourceCaseLineList.data.forEach(element => {
      //set to update status for line being moved/dragged
      if (this.isLineSublineBeingMoved) element.status = DsamsConstants.ENT_CHANGED.toString();

      if (element.status == DsamsConstants.ENT_CHANGED.toString() ||
        element.status == DsamsConstants.ENT_DELETED.toString()) {
        //when renumbering line status of CML is now updated
        aCaseMasterLine.status = DsamsConstants.ENT_CHANGED.toString();
        aCaseMasterLine.service_DB_ID = CaseUtils.getServiceDatabaseId();
        aCaseMasterLine.caseLineList.push(element);
      }
    })

    // Renumbering the lines after line/subline had been moved
    if (this.isLineSublineBeingMoved) {
      this.renumberLineAndSubline();
      //reset global status
      this.isLineListDataChanged = false;
      this.isLineSublineBeingMoved = false;
    }
    // console.log('line list=', aCaseMasterLine)

    return aCaseMasterLine;
  }

  //Intiate the save process
  performSaveData() {
    //renumber line list when applicable
    this.caseRestService.saveCaseLineListFromServer(this.prepareCaseMasterLineEntity()).subscribe(
      result => {
        this.performAfterSaveData();
      },
      err => {
        CaseUtils.ReportHTTPError(err, "saving Case Line List data");
      }
    );
  }

  //Refresh data after a successful save
  performAfterSaveData() {
    // console.log('**** Saving data success...')
    //Clear the array status after Save/Delete
    this.initializetheLineNumberDropdownArray(); //Jeff
    this.theDeletedCaseLineListArray = [];
    this.isLineListDataChanged = false;
    this.isLineSublineBeingMoved = false;
    this.rowDeletedIndex = 0;
    this.dataSourceCaseLineList.data = [];
    //Reread data
    this.populateNewCaseLineListFromServer();
    this.caseUIService.theComponentSaveCaseLineState[CaseUIService.SAVE_CASE_LINE_LIST_STATE].isDataChanged = false;
    MessageMgr.displaySuccessWithTimer('Save was successful', 2000);
  }

  //Handle Save clicked event
  saveButtonOnClick() {
    var proceedToSaveData: boolean = false;
    if (!!this.theDeletedCaseLineListArray ||
      this.isLineListDataChanged) {
      MessageMgr.swalFire({
        text: 'Are you sure you want to save?',
        icon: 'question',
        width: 350,
        showCancelButton: true,
        cancelButtonText: 'No',
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes',
      }).then((result) => {
        if (result.value) {
          console.log('Saving data...')
          this.performSaveData();
        }
      })
    }
    else {
      MessageMgr.displayInfoWithTimer('No change has been made', 1500);
    }
  }

  openDialog(): void {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = '340px';
    dialogConfig.hasBackdrop = false;
    var strMessage = '\t\t' + "Are you sure to cancel?";
    dialogConfig.data = { message: strMessage };
    const dialogRef = this.dialog.open(DialogMessageYesnoComponent, dialogConfig);

    dialogRef.afterClosed().subscribe(result => {
      if (result == 1) {
        // send back to case search summary screen to re-populate the data
        // this.goBackToCaseSearchSummary();
        this.dataSourceCaseLineList = new MatTableDataSource(this._clonedataSourcCaseLineList.data);
        this.dataSourceCaseLineList._updateChangeSubscription();
      }
    });
  }

  // Removed button for Card 5204 - FS 03/2022
  cancelButtonOnClick() {
    MessageMgr.swalFire({
      text: 'Are you sure you want to cancel?',
      icon: 'question',
      width: 350,
      showCancelButton: true,
      cancelButtonText: 'No',
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes',
    }).then((result) => {
      if (result.value) {
        this.dataSourceCaseLineList.data.splice(0);
        this._clonedataSourcCaseLineList.data.forEach(element => {
          this.dataSourceCaseLineList.data.push(element);
        });
        this.dataSourceCaseLineList = new MatTableDataSource(this.dataSourceCaseLineList.data);
        this.dataSourceCaseLineList.paginator = this.paginator;
        this.dataSourceCaseLineList.paginator.length = this.dataSourceCaseLineList.data.length;
        this.dataSourceCaseLineList._updateChangeSubscription();
      }
    })
  }

  /****************************** Bussiness Logic *******************************/

  getUSCurrency(pValue: string): string {
    if (pValue == null)
      return ("$0.00")
    else return formatCurrency(parseFloat(pValue), 'en', '$')
  }

  setNotApplicable(pValue: string): string {
    if (pValue == 'N/A')
      return 'Not Applicable';
  }

  formatTheLineNumber(lineNumber: any): string {
    if (lineNumber.toString().length == 1)
      return ("00" + lineNumber.toString());
    else if (lineNumber.toString().length == 2)
      return ("0" + lineNumber.toString());
    return lineNumber.toString();
  }

  //recursively to find available line
  private nextLine: number;
  _getNextAvailableLineNum(curRowIndex: number, maxRowIndex: number): number {
    if (curRowIndex >= maxRowIndex)
      this.nextLine = maxRowIndex - 1;

    if (!this.dataSourceCaseLineList.data[curRowIndex].isRenumberAllowed && curRowIndex < maxRowIndex)
      this._getNextAvailableLineNum(curRowIndex + 1, maxRowIndex);
    else this.nextLine = curRowIndex;
    //return the next available line number
    return (this.nextLine + 1);
  }

  //update current line number to a new number
  setLineNumber(rowIndex: any, lineNumVal: any) {
    this.dataSourceCaseLineList.data[rowIndex].wm_USER_CASE_LINE_NUMBER_ID = lineNumVal;
    this.dataSourceCaseLineList.data[rowIndex].LINESUBLINESEQVIR = CaseUtils.formatLineNumber(lineNumVal);
    this.dataSourceCaseLineList.data[rowIndex].status = DsamsConstants.ENT_CHANGED.toString();
    this.dataSourceCaseLineList.data[rowIndex].entityStatus = DsamsConstants.ENT_CHANGED.toString();
  }

  //get the available subline char
  getSublineChar(posNum: number = 0): string {
    return LineSublineComponent.alphabeticalString.charAt(posNum).toString();
  }

  //update current subline number to a new number
  setSubLineNumber(rowIndex: any, pParentLineId: any, pParentCaseId: any, pParentCMLId: any,
    pNextSublineVal: number = 0) {
    this.dataSourceCaseLineList.data[rowIndex].wm_USER_CASE_LINE_NUMBER_ID = pParentLineId;
    this.dataSourceCaseLineList.data[rowIndex].wm_PARENT_CASE_ID = pParentCaseId;
    this.dataSourceCaseLineList.data[rowIndex].wm_PARENT_CASE_MASTER_LINE_ID = pParentCMLId;
    this.dataSourceCaseLineList.data[rowIndex].wm_USER_CASE_SUBLINE_TX = this.getSublineChar(pNextSublineVal);
    this.dataSourceCaseLineList.data[rowIndex].LINESUBLINESEQVIR = CaseUtils.formatLineNumber(pParentLineId) +
      this.dataSourceCaseLineList.data[rowIndex].wm_USER_CASE_SUBLINE_TX;
    this.dataSourceCaseLineList.data[rowIndex].status = DsamsConstants.ENT_CHANGED.toString();
    this.dataSourceCaseLineList.data[rowIndex].entityStatus = DsamsConstants.ENT_CHANGED.toString();
  }

  //search for an available subline
  getAvailableSublinePos(newSublinePos: number, pParentCMLId: number): number {
    let dataSourceLength = this.dataSourceCaseLineList.data.length;
    for (var i = 0; i < dataSourceLength; i++) {
      if (!!this.dataSourceCaseLineList.data[i].wm_PARENT_CASE_MASTER_LINE_ID
        && this.dataSourceCaseLineList.data[i].wm_PARENT_CASE_MASTER_LINE_ID == pParentCMLId) {
        //check whether newlinenum is already taken
        if (this.getSublineChar(newSublinePos) == this.dataSourceCaseLineList.data[i].wm_USER_CASE_SUBLINE_TX
          && !this.dataSourceCaseLineList.data[i].isRenumberAllowed)
          //increase to check for next available line 
          newSublinePos = newSublinePos + 1;
      }
    }
    return newSublinePos;
  }

  //This method is used to renumber sublines to the new parent line
  //when sublines themselves were moved.
  renumberSublineOnCaseLineList(pCurrentIndex: number, pNewSubNumber: number): number {
    var curLineArrayIndex: number = pCurrentIndex;
    var beginSublinePos: number = pNewSubNumber;

    //not needed but check anyway -  make sure parent object does exist
    if (!!this.dataSourceCaseLineList.data[curLineArrayIndex - 1]) {
      let dataSourceLength = this.dataSourceCaseLineList.data.length;
      for (var i = curLineArrayIndex; i < dataSourceLength; i++) {
        if (!!this.dataSourceCaseLineList.data[i].wm_USER_CASE_SUBLINE_TX) {
          if (beginSublinePos > 26) {
            //Need to display a warning message as no more subline available
            console.log('**** no more available subline')
            beginSublinePos = 0;
          }
          //search for available subline and copy parent primary key
          beginSublinePos = this.getAvailableSublinePos(beginSublinePos,
            this.dataSourceCaseLineList.data[curLineArrayIndex - 1].case_MASTER_LINE_ID);
          this.setSubLineNumber(i, this.dataSourceCaseLineList.data[curLineArrayIndex - 1].wm_USER_CASE_LINE_NUMBER_ID,
            this.dataSourceCaseLineList.data[curLineArrayIndex - 1].case_ID,
            this.dataSourceCaseLineList.data[curLineArrayIndex - 1].case_MASTER_LINE_ID,
            beginSublinePos++);
        }
        else {
          //Do a clean exit to get out of for loop properly
          curLineArrayIndex = i - 1;
          return curLineArrayIndex;
        }
      }
    }
    else {
      //need to display an error message as previous parent line cannot be null
      return curLineArrayIndex;
    }
  }

  //check for gap in lines/sublines
  doesLineSublineHaveGap(): boolean {
    let dataSourceLength = this.dataSourceCaseLineList.data.length;
    var curLine: number;
    var nextLine: number;
    for (var i = 0; i < dataSourceLength - 1; i++) {
      curLine = parseInt(this.dataSourceCaseLineList.data[i].wm_USER_CASE_LINE_NUMBER_ID);
      nextLine = parseInt(this.dataSourceCaseLineList.data[i + 1].wm_USER_CASE_LINE_NUMBER_ID);
      if ((nextLine - curLine) > 1) {
        return true;
      }
      //will do subline next
      if (!!this.dataSourceCaseLineList.data[i].wm_PARENT_CASE_MASTER_LINE_ID) {
        let curSubline = this.dataSourceCaseLineList.data[i].wm_USER_CASE_SUBLINE_TX;
        if (!!this.dataSourceCaseLineList.data[i + 1].wm_PARENT_CASE_MASTER_LINE_ID) {
          let nextSubline = this.dataSourceCaseLineList.data[i + 1].wm_USER_CASE_SUBLINE_TX;
          if ((LineSublineComponent.alphabeticalString.charCodeAt(LineSublineComponent.alphabeticalString.indexOf(nextSubline)) -
            LineSublineComponent.alphabeticalString.charCodeAt(LineSublineComponent.alphabeticalString.indexOf(curSubline))) > 1)
            return true;
        }
      }
    }
    return false;
  }

  //search for gap in lines and diplay the message if applicable
  checkLineSublineForGap() {
    if (this.doesLineSublineHaveGap() == true) {
      setTimeout(() => {
        MessageMgr.displayInfoWithTimer('There are gaps in line/subline numbering due to unmovable lines/sublines', 4000);
      }, 2000);
    }
  }

  //search for an available line
  getAvailableLineNumber(newLineNum: number): number {
    let dataSourceLength = this.dataSourceCaseLineList.data.length;
    for (var i = 0; i < dataSourceLength; i++) {
      //check whether newlinenum is already taken
      if (newLineNum == parseInt(this.dataSourceCaseLineList.data[i].wm_USER_CASE_LINE_NUMBER_ID)
        && !this.dataSourceCaseLineList.data[i].isRenumberAllowed)
        //increase to check for next available line 
        newLineNum = newLineNum + 1;
    }
    // requirement changed so now exclude this step
    //check for row that was logically deleted if applicable
    // if (!!this.theDeletedCaseLineListArray) {
    //   for (var delIndex = 0; delIndex < this.theDeletedCaseLineListArray.length; delIndex++) {
    //     //check whether newlinenum is already taken
    //     if (this.theDeletedCaseLineListArray[delIndex].change_ACTION_CD !== LineSublineComponent.CHANGE_ACTION_ADDED
    //       && (this.theDeletedCaseLineListArray[delIndex].wm_PARENT_CASE_MASTER_LINE_ID == null
    //         || this.theDeletedCaseLineListArray[delIndex].wm_PARENT_CASE_MASTER_LINE_ID == 0)
    //       && newLineNum == parseInt(this.theDeletedCaseLineListArray[delIndex].wm_USER_CASE_LINE_NUMBER_ID))
    //       //increase to check for next available line 
    //       newLineNum = newLineNum + 1;
    //   }
    // }
    return newLineNum;
  }

  //On Save, renumbering the line/subline if any line/subline has been rearranged on screen
  renumberLineAndSubline() {
    let dataSourceLength = this.dataSourceCaseLineList.data.length;
    var newLineNumber: number = 1;
    var newSubNumber: number = LineSublineComponent.alphabeticalString.indexOf('a');
    var indexI: number = 0; //sonarqube rule
    while (indexI < dataSourceLength) {
      if (this.dataSourceCaseLineList.data[indexI].isRenumberAllowed) {
        if (this.dataSourceCaseLineList.data[indexI].wm_USER_CASE_SUBLINE_TX == null) {
          newLineNumber = this.getAvailableLineNumber(newLineNumber);
          this.setLineNumber(indexI, newLineNumber);
        }
        else {
          //Process subline
          indexI = this.renumberSublineOnCaseLineList(indexI, newSubNumber);
          //do not change line number for subline
          newLineNumber--; //decrement new line number to be incremented later below
          indexI--;
        }
      }
      else {
        //just skip assigning line number to this unmovable line
        if (newLineNumber >= parseInt(this.dataSourceCaseLineList.data[indexI].wm_USER_CASE_LINE_NUMBER_ID))
          newLineNumber = newLineNumber - 1;
        if (!!this.dataSourceCaseLineList.data[indexI].wm_USER_CASE_SUBLINE_TX)
          newSubNumber = LineSublineComponent.alphabeticalString.indexOf(this.dataSourceCaseLineList.data[indexI].wm_USER_CASE_SUBLINE_TX) + 1;
      }
      newLineNumber++;
      indexI++;
    }

    /*PRESERVED due to Soanrqube undo
    for (var i = 0; i < dataSourceLength; i++) {
      if (this.dataSourceCaseLineList.data[i].isRenumberAllowed) {
        if (this.dataSourceCaseLineList.data[i].wm_USER_CASE_SUBLINE_TX == null) {
          newLineNumber = this.getAvailableLineNumber(newLineNumber);
          this.setLineNumber(i, newLineNumber);
        }
        else {
          //Process subline
          i = this.renumberSublineOnCaseLineList(i, newSubNumber);
          //do not change line number for subline
          newLineNumber--; //decrement new line number to be incremented later below
        }
      }
      else {
        //just skip assigning line number to this unmovable line
        if (newLineNumber >= parseInt(this.dataSourceCaseLineList.data[i].wm_USER_CASE_LINE_NUMBER_ID))
          newLineNumber = newLineNumber - 1;
        if (!!this.dataSourceCaseLineList.data[i].wm_USER_CASE_SUBLINE_TX)
          newSubNumber = LineSublineComponent.alphabeticalString.indexOf(this.dataSourceCaseLineList.data[i].wm_USER_CASE_SUBLINE_TX) + 1;
      }
      newLineNumber = newLineNumber + 1;
    }
    */
    //do not sort the list so that it can be checked for gap in lines
    //this.sortCaseLineList(this.dataSourceCaseLineList.data);
    this.dataSourceCaseLineList._updateChangeSubscription();
    this.checkLineSublineForGap();
  }


  //Handle FR3 and FR14
  setRenumberAllowedVal(pEditToggle: boolean) {
    const NOT_APPLIED: string = "Y";

    this.dataSourceCaseLineList.data.forEach(element => {
      if (pEditToggle) {
        //FR14 moved to Line Utils for sharing
        if (this.caseLineRelatedInfoData) {
          element.wm_CASE_VERSION_STATUS_CD = this.caseLineRelatedInfoData.case_VERSION_STATUS_CD;
        }
        element.isDeleteAllowed = LineUtils.isLineDeleteAllowed(element);
        element.isRefreshAllowed = this.isLineRefreshAllowed(element);

        //FR3 
        if (!element.wm_EXCLUSION_IN
          && !element.wm_CASE_LINE_LOI_IN
          && (!!element.apply_PROFILE_LINE_CD) &&
          element.apply_PROFILE_LINE_CD.toUpperCase() !== NOT_APPLIED
          && (!!element.change_ACTION_CD) &&
          element.change_ACTION_CD.toUpperCase() == LineSublineComponent.CHANGE_ACTION_ADDED) {
          element.isRenumberAllowed = true;
          element.isRowBeingMoved = false;
        }
        else {
          element.isRenumberAllowed = false;
          element.isRowBeingMoved = false;
        }
      }
      else {
        element.isDeleteAllowed = false;
        element.isRefreshAllowed = false;
      }
      //set up parent line for subline
      if (element.wm_USER_CASE_SUBLINE_TX !== null) {
        for (let i = 0; i < this.dataSourceCaseLineList.data.length; i++) {
          if (this.dataSourceCaseLineList.data[i].case_ID == element.wm_PARENT_CASE_ID &&
            this.dataSourceCaseLineList.data[i].case_MASTER_LINE_ID == element.wm_PARENT_CASE_MASTER_LINE_ID) {
            element.LINESUBLINESEQVIR =
              this.dataSourceCaseLineList.data[i].wm_USER_CASE_LINE_NUMBER_ID + element.wm_USER_CASE_SUBLINE_TX;
          }
        }
      }
    });
  }

  isSelectedRowDeleteAllowed(rowElement: any): boolean {
    //FR6 
    let rowIndex = this.dataSourceCaseLineList.data.indexOf(rowElement);
    //Delete a line/subline that has prior_YEAR_AM > 0 is not allowed
    if (this.dataSourceCaseLineList.data[rowIndex].prior_YEAR_AM > 0) {
      return false;
    }
    //Delete a subline that has a parent line with prior_YEAR_AM > 0 is not allowed
    else {
      if (this.dataSourceCaseLineList.data[rowIndex].wm_USER_CASE_SUBLINE_TX !== null) {
        this.dataSourceCaseLineList.data.forEach(element => {
          if (element.wm_USER_CASE_SUBLINE_TX == this.dataSourceCaseLineList.data[rowIndex].wm_USER_CASE_SUBLINE_TX &&
            element.wm_USER_CASE_LINE_NUMBER_ID == this.dataSourceCaseLineList.data[rowIndex].wm_USER_CASE_LINE_NUMBER_ID &&
            this.dataSourceCaseLineList.data[rowIndex].prior_YEAR_AM > 0)
            return false;
        })
      }
    }
    return true;
  }

  performBusinessCheck(caseLineObject: CaseRelatedInfoType) {
    const BENEFITING_COUNTRY: string = "BE";
    const LETTER_OF_INTENT: string = "I";

    //due to the amount field is being editable so avoid using currency pipe
    caseLineObject.total_ABOVE_LINE_COST_AM =
      this.getUSCurrency(caseLineObject.total_ABOVE_LINE_COST_AM);
    caseLineObject.status = DsamsConstants.ENT_UNCHANGED.toString();

    //FR8
    if (caseLineObject.case_LINE_MARK_FOR_DELETION_IN == '1')
      caseLineObject.unit_ABOVE_LINE_COST_AM = 'N/A';
    else {
      caseLineObject.unit_ABOVE_LINE_COST_AM =
        this.getUSCurrency(caseLineObject.unit_ABOVE_LINE_COST_AM);
    }
    //FR10
    if (!!caseLineObject.case_CUSTOMER_TYPE_CD && caseLineObject.case_CUSTOMER_TYPE_CD.toUpperCase() == BENEFITING_COUNTRY) {
      this.hideBECtryCol = false;
    }
    else this.hideBECtryCol = true;

    //FR11
    if (!!this.caseRelatedInfoData.case_USAGE_INDICATOR_CD && this.caseRelatedInfoData.case_USAGE_INDICATOR_CD.toUpperCase() == LETTER_OF_INTENT)
      this.hideExcludeCol = true;
    else this.hideExcludeCol = false;
  }


  /**
   * Determine if line refresh is allowed
   * @param pCaseLineInfo 
   * @param pLocation 
   */
  private isLineRefreshAllowed(pCaseLineInfo: ifaceCaseLineData): boolean {
    if (pCaseLineInfo.wm_CASE_LINE_LOI_IN ||
      pCaseLineInfo.change_ACTION_CD === "U" ||
      pCaseLineInfo.status === DsamsConstants.ENT_NEW.toString()) {
      return false;
    }
    // If both parent and subline have change-action-cd of D, then disable (only applies to case line list).
    if (!!pCaseLineInfo.wm_USER_CASE_SUBLINE_TX &&
      pCaseLineInfo.wm_USER_CASE_SUBLINE_TX !== "" &&
      pCaseLineInfo.wm_PARENT_CHANGE_ACTION_CD === "D" &&
      pCaseLineInfo.change_ACTION_CD === "D") {
      return false;
    }
    return true;
  }

  /*
   * This will perform the refresh (after passing the requisite errors and warnings).
   */
  onRefreshBtnClick(pCaseLineInfo: CaseRelatedInfoType, pIndex: number) {
    // Get the real page index based on pagination.
    const realIndex = pIndex + (this.paginator.pageIndex * this.paginator.pageSize);

    // Display applicable errors. 
    // Error if the line has sublines that are all A-s.
    if (pCaseLineInfo.wm_HAS_SUBLINES_A) {
      MessageMgr.displaySinglePopupError("E306");
      return;
    }

    // If it's a D-subline, and the parent line is D, then error.
    if (!!pCaseLineInfo.wm_USER_CASE_SUBLINE_TX &&
      pCaseLineInfo.wm_USER_CASE_SUBLINE_TX !== "" &&
      pCaseLineInfo.change_ACTION_CD === "D" &&
      pCaseLineInfo.wm_PARENT_CHANGE_ACTION_CD === "D") {
      MessageMgr.displaySinglePopupError("E309");
      return;
    }

    // If it's a D-subline, and the parent line is priced, then error.
    if (!!pCaseLineInfo.wm_USER_CASE_SUBLINE_TX &&
      pCaseLineInfo.wm_USER_CASE_SUBLINE_TX !== "" &&
      pCaseLineInfo.change_ACTION_CD === "D" &&
      pCaseLineInfo.wm_PARENT_IS_PRICED) {
      MessageMgr.displaySinglePopupError("E310");
      return;
    }

    LineUtils.promptUserToCaseLineRefresh().then((resultConfirm) => {
      if (resultConfirm.value == true) {
        this.isLoading.next(true);
        this.caseRestService.refreshCaseLine(pCaseLineInfo).subscribe((pUpdatedCaseLine: ifaceCaseLineData) => {
          this.isLoading.next(false);
          MessageMgr.displaySinglePopupInfo("I308");
          this.dataSourceCaseLineList.data[realIndex].caseLineAssistanceTypeList = pUpdatedCaseLine.caseLineAssistanceTypeList;
          this.dataSourceCaseLineList.data[realIndex].caseLineOfferReleaseList = pUpdatedCaseLine.caseLineOfferReleaseList;
          this.dataSourceCaseLineList.data[realIndex].caseLineDeliveryItemList = pUpdatedCaseLine.caseLineDeliveryItemList;
          this.dataSourceCaseLineList.data[realIndex].caseLineDeliveryTermList = pUpdatedCaseLine.caseLineDeliveryTermList;
          this.dataSourceCaseLineList.data[realIndex].isRefreshAllowed = false;
          this.dataSourceCaseLineList.data[realIndex].case_LINE_MARK_FOR_DELETION_IN = false;
          this.dataSourceCaseLineList.data[realIndex].change_ACTION_CD = "U";
          this.dataSourceCaseLineList.data[realIndex].change_ACTION_TITLE_NM = "Unaffected";
          this.caseUIService.theComponentSaveCaseLineState[CaseUIService.SAVE_CASE_LINE_LIST_STATE].isDataChanged = true;
        },
          err => {
            this.isLoading.next(false);
            CaseUtils.ReportHTTPError(err, "Refreshing Case Line from Line List");
          });
      }
    });
  }

  /* This procedure is used to retrieve and populate data from the server
    to the case line list array. */
  populateNewCaseLineListFromServer() {
    this.isLoading.next(true);
    this.takeDownSpinner();

    this.isRefreshButtonVisible = (this.caseRelatedInfoData.wm_CASE_VERSION_TYPE_CD === "A" || this.caseRelatedInfoData.wm_CASE_VERSION_TYPE_CD === "M");

    this.caseRestService.getCaseLineListFromServer(this.caseRelatedInfoData.working_CASE_ID,
      this.caseRelatedInfoData.working_CASE_VERSION_ID)
      .subscribe(
        data => {
          this.getLineSublineRefData.populateReferenceDataForCaseLine();
          this.getLineSublineRefData.setResetDynamicRefList(true);
          if (data.caseLineList) {
            this._clonedataSourcCaseLineList.data = [];
            this.dataSourceCaseLineList.data = [];
            for (var i = 0; i <= data.caseLineList.length - 1; i++) {
              //Use window mapping attributes to manipulate CML entity for window display purposes
              //console.log('********* = ', data.caseLineList[i])
              this.dataSourceCaseLineList.data.push(data.caseLineList[i]);
              this.dataSourceCaseLineList = new MatTableDataSource(this.dataSourceCaseLineList.data);
              this.dataSourceCaseLineList.data[i].wm_CASE_LINE_REMARK_QY =
                CaseUtils.convertNullStrToZero(this.dataSourceCaseLineList.data[i].wm_CASE_LINE_REMARK_QY);

              this.dataSourceCaseLineList.data[i].line_PURPOSE_CD =
                CaseUtils.convertNullStrToNA(this.dataSourceCaseLineList.data[i].line_PURPOSE_CD);
              this.dataSourceCaseLineList.data[i].line_PURPOSE_TITLE_NM =
                CaseUtils.convertNullStrToNA(this.dataSourceCaseLineList.data[i].line_PURPOSE_TITLE_NM);

              if (!this.hasSCM && (CaseCommonValidator.isEqual(this.dataSourceCaseLineList.data[i].line_PURPOSE_CD,
                LineUtils.LINE_PURPOSE_CE))) this.hasSCM = true;

              if (this.dataSourceCaseLineList.data[i].major_DEFENSE_EQUIPMENT_CD) {
                if (this.dataSourceCaseLineList.data[i].major_DEFENSE_EQUIPMENT_CD.toUpperCase() == 'S')
                  this.dataSourceCaseLineList.data[i].mde_SME_CD = 'SME';
                else if (this.dataSourceCaseLineList.data[i].major_DEFENSE_EQUIPMENT_CD.toUpperCase() == 'Y')
                  this.dataSourceCaseLineList.data[i].mde_SME_CD = 'MDE';
                else this.dataSourceCaseLineList.data[i].mde_SME_CD = 'N/A';
              } else this.dataSourceCaseLineList.data[i].mde_SME_CD = 'N/A';
              //Wp003a FR29 - set default calendar
              this.dataSourceCaseLineList.data[i].offer_EXPIRATION_DT = this.caseRelatedInfoData.offer_EXPIRATION_DT;
              //Wp003a FR14 - require field
              this.dataSourceCaseLineList.data[i].implementing_AGENCY_ID = this.caseRelatedInfoData.implementing_AGENCY_ID;
              //set up virtual line number for line
              if (data.caseLineList[i].wm_USER_CASE_SUBLINE_TX == null)
                this.dataSourceCaseLineList.data[i].LINESUBLINESEQVIR = data.caseLineList[i].wm_USER_CASE_LINE_NUMBER_ID;
              this.dataSourceCaseLineList.data[i].case_USAGE_INDICATOR_CD = data.caseLineList[i].case_USAGE_INDICATOR_CD;
              this.dataSourceCaseLineList.data[i].case_MASTER_STATUS_CD = data.caseLineList[i].case_MASTER_STATUS_CD;
              //For the Add New Subline validations
              this.dataSourceCaseLineList.data[i].total_ABOVE_LINE_COST_AM = data.caseLineList[i].total_ABOVE_LINE_COST_AM;
              this.dataSourceCaseLineList.data[i].total_BELOW_LINE_COST_AM = data.caseLineList[i].total_BELOW_LINE_COST_AM;
              this.dataSourceCaseLineList.data[i].case_LINE_MARK_FOR_DELETION_IN = data.caseLineList[i].case_LINE_MARK_FOR_DELETION_IN;
              this.dataSourceCaseLineList.data[i].subline_ALLOWED_IN = data.caseLineList[i].subline_ALLOWED_IN;
              this.dataSourceCaseLineList.data[i].line_PURPOSE_CD = data.caseLineList[i].line_PURPOSE_CD;
              this.dataSourceCaseLineList.data[i].customer_ORGANIZATION_ID = data.caseLineList[i].customer_ORGANIZATION_ID;
              this.dataSourceCaseLineList.data[i].wm_CM_CUSTOMER_ORGANIZATION_ID = data.caseLineList[i].wm_CM_CUSTOMER_ORGANIZATION_ID;
              this.dataSourceCaseLineList.data[i].wm_PARENT_CHANGE_ACTION_CD = data.caseLineList[i].wm_PARENT_CHANGE_ACTION_CD;
              this.dataSourceCaseLineList.data[i].wm_PARENT_IS_PRICED = data.caseLineList[i].wm_PARENT_IS_PRICED;
              this.dataSourceCaseLineList.data[i].wm_LINE_IS_PRICED = data.caseLineList[i].wm_LINE_IS_PRICED;
              this.dataSourceCaseLineList.data[i].wm_CHECK_NPOR = data.caseLineList[i].wm_CHECK_NPOR;
              this.dataSourceCaseLineList.data[i].wm_ROWID = data.caseLineList[i].wm_ROWID;
              if (data.caseLineList[i].wm_USER_CASE_SUBLINE_TX == null) {
                var aHashObject: HashTable = {
                  lineID: data.caseLineList[i].wm_USER_CASE_LINE_NUMBER_ID,
                  caseMasterLineId: data.caseLineList[i].case_MASTER_LINE_ID
                };
                this.theLineNumberDropdownList.push(aHashObject);
                this.theLineNumberDropdownArray.push(data.caseLineList[i].wm_USER_CASE_LINE_NUMBER_ID);
              }

              this.performBusinessCheck(data.caseLineList[i]);
              /* 
                Requirement changes - Arrow buttons are no longer used; 
                use drag and drop function instead
               this.setInitialIconImageVal(this.dataSourceCaseLineList.data[i], i,
                 (i === data.caseLineList.length - 1) ? true : false);
              */
              // cache the current displayed data for rolling back data purposes
              this._clonedataSourcCaseLineList.data.push(data.caseLineList[i]);
            }
            //perform sort
            if (this.dataSourceCaseLineList.data) {
              this.setRenumberAllowedVal(this.isDataEditAllowed);
              if (this.dataSourceCaseLineList.data.length >= 1) {
                this.sortCaseLineList(this._clonedataSourcCaseLineList.data);
                this.sortCaseLineList(this.dataSourceCaseLineList.data);
                // console.log('populateNewCaseLineListFromServer=', this.dataSourceCaseLineList.data);
                //set up virtual line number for subline
                if (this.dataSourceCaseLineList.data[this.dataSourceCaseLineList.data.length - 1].wm_USER_CASE_SUBLINE_TX !== null)
                  this.lastLineNumber =
                    this.dataSourceCaseLineList.data[this.dataSourceCaseLineList.data.length - 1].wm_USER_CASE_LINE_NUMBER_ID;
                else this.lastLineNumber =
                  this.dataSourceCaseLineList.data[this.dataSourceCaseLineList.data.length - 1].LINESUBLINESEQVIR.substring(0, 3);

              }
            }

            // Determine if a case line has sub-lines.
            if (this.dataSourceCaseLineList.data) {
              for (var j = 0; j <= this.dataSourceCaseLineList.data.length - 1; j++) {
                let parentLineNum: string = this.dataSourceCaseLineList.data[j].LINESUBLINESEQVIR.substring(0, 3);
                let hasSubLines: boolean = (j < (this.dataSourceCaseLineList.data.length - 1) &&
                  parentLineNum === this.dataSourceCaseLineList.data[j + 1].LINESUBLINESEQVIR.substring(0, 3) &&
                  (this.dataSourceCaseLineList.data[j].wm_USER_CASE_SUBLINE_TX == null || this.dataSourceCaseLineList.data[j].wm_USER_CASE_SUBLINE_TX === "") &&
                  this.dataSourceCaseLineList.data[j + 1].wm_USER_CASE_SUBLINE_TX != null &&
                  this.dataSourceCaseLineList.data[j + 1].wm_USER_CASE_SUBLINE_TX !== "");

                this.dataSourceCaseLineList.data[j].wm_HAS_SUBLINES = hasSubLines;
                this._clonedataSourcCaseLineList.data[j].wm_HAS_SUBLINES = hasSubLines;

                // Determine if it has any sublines that are of change_action_cd = 'A' or sublines that are priced.
                let hasSublines_A: boolean = false;
                let hasSublinesPriced: boolean = false;
                if (hasSubLines) {
                  let numSubLines: number = 0;
                  let numSubLines_A: number = 0;
                  let k: number = j + 1;
                  while (k < this.dataSourceCaseLineList.data.length &&
                    this.dataSourceCaseLineList.data[k].LINESUBLINESEQVIR.substring(0, 3) === parentLineNum &&
                    this.dataSourceCaseLineList.data[k].wm_USER_CASE_SUBLINE_TX != null &&
                    this.dataSourceCaseLineList.data[k].wm_USER_CASE_SUBLINE_TX !== "") {
                    numSubLines++;
                    if (this.dataSourceCaseLineList.data[k].change_ACTION_CD === "A") {
                      numSubLines_A++;
                    }
                    if (this.dataSourceCaseLineList.data[k].wm_LINE_IS_PRICED) {
                      hasSublinesPriced = true;
                    }
                    k++;
                  }
                  // All sublines have to be A for this criteria to be met.
                  hasSublines_A = (numSubLines == numSubLines_A);
                }
                this.dataSourceCaseLineList.data[j].wm_HAS_SUBLINES_A = hasSublines_A;
                this._clonedataSourcCaseLineList.data[j].wm_HAS_SUBLINES_A = hasSublines_A;

                this.dataSourceCaseLineList.data[j].wm_HAS_SUBLINES_PRICED = hasSublinesPriced;
                this._clonedataSourcCaseLineList.data[j].wm_HAS_SUBLINES_PRICED = hasSublinesPriced;

                this.dataSourceCaseLineList.data[j].doesCaseLineHaveSCM = this.hasSCM;
                this._clonedataSourcCaseLineList.data[j].doesCaseLineHaveSCM = this.hasSCM;
              }
            }

            //Pagination
            this.dataSourceCaseLineList.paginator = this.paginator;
            this.dataSourceCaseLineList.paginator.length = this.dataSourceCaseLineList.data.length;
            this.dataSourceCaseLineList._updateChangeSubscription();
            this.resetControlVarFlags();
          }
          this.noCaseLinesFoundInd = (this.dataSourceCaseLineList.data.length == 0);
          this.theLineNumberDropdownArray.sort((a, b) => this.compare(a, b, true));
          for (var t = 0; t < this.dataSourceCaseLineList.data.length; t++) {
            if (this.dataSourceCaseLineList.data[t].wm_USER_CASE_SUBLINE_TX == null)
              this.maxLines += 1;
          }
          this.caseRestService.getMaxLinesValueSubject.next(this.maxLines);
          this.setIPCButtonDisabled();

          //perform sort
          if (this.dataSourceCaseLineList.data.length > 1) {
            this.dataSourceCaseLineList.data.sort((object1, object2) => {
              if (object1.LINESUBLINESEQVIR > object2.LINESUBLINESEQVIR) {
                return 1;
              }
              if (object1.LINESUBLINESEQVIR < object2.LINESUBLINESEQVIR) {
                return -1;
              }
              return 0;
            })
          }

        },
        err => {
          CaseUtils.ReportHTTPError(err, "fetching Case Line List data from server");
          this.isLoading.next(false);
        }
      );
  }

  //reset control variable flags
  resetControlVarFlags(){
    if (this.isContinueConfirmed || this.isSavedConfirmed) {
      this.dataSourceCaseLineList.data.forEach(element => {
        element.isRenumberAllowed = false;
        element.isRowBeingMoved = false;
        element.isDeleteAllowed = false;
        element.isRefreshAllowed = false;
      })
      this.isLineListDataChanged = false;
      this.isContinueConfirmed = false;
      this.isSavedConfirmed = false;
      this.isDataEditAllowed = false;
    }
  }

  intervalForSpinner: any;
  takeDownSpinner() {
    this.intervalForSpinner = setInterval(() => {
      if (this.getLineSublineRefData.isReferenceLineDataReady) {
        this.isLoading.next(false);
        clearInterval(this.intervalForSpinner);
      }
    }
      , 1000);
  }

  //This function returns the sorted result by Line/Subline
  sortCaseLineList(pData: ifaceCaseMasterLine["caseLineList"]) {
    pData.sort((object1, object2) => {
      if (object1.LINESUBLINESEQVIR > object2.LINESUBLINESEQVIR) {
        return 1;
      }
      if (object1.LINESUBLINESEQVIR < object2.LINESUBLINESEQVIR) {
        return -1;
      }
      return 0;
    })
  }

  //set up data for row being selected
  onClickRow(selectedRow: any, rowIndex: any) {
    this.selectedRowIndex = rowIndex + (this.paginator.pageSize * this.paginator.pageIndex);
    this.dataSourceCaseLineList.data.forEach((element, index) => {
      if (index == this.selectedRowIndex) {
        //when deselecting row, set value back to default -1 
        if (element.isRowSelected) this.selectedRowIndex = -1;
        element.isRowSelected = !element.isRowSelected;
      }
      else element.isRowSelected = false;
    });
  }

  //Drag and Drop functions 
  canLineBeMoved(pCurIndex: number) {
    if ((CaseUtils.isBlankStr(this.dataSourceCaseLineList.data[this.previousDragRowIndex].wm_USER_CASE_SUBLINE_TX)) &&
      (!CaseUtils.isBlankStr(this.dataSourceCaseLineList.data[pCurIndex].wm_USER_CASE_SUBLINE_TX))) {
      MessageMgr.swalFire({
        text: 'Line cannot be placed within subline(s)',
        icon: 'error',
        confirmButtonText: 'OK',
        width: 450
      })
      //reset previous row that had been moved to 0
      this.previousDragRowIndex = 0;
    }
  }

  //on Dragging row to the new position in the list
  onDragRow(draggedRow: any, rowIndex: any) {
    this.previousDragRowIndex = rowIndex + (this.paginator.pageSize * this.paginator.pageIndex);
  }

  //per sonarqube rule
  insertMovedLineSublineRows(pCurIndex: number, tempDataSourceArray: MatTableDataSource<ifaceCaseLineListArray>,
    dataSourceLength: any) {
    var indexY: number;
    if (pCurIndex == dataSourceLength - 1) {
      //handle line being moved to the last row
      for (indexY = 0; indexY < tempDataSourceArray.data.length; indexY++) {
        this.dataSourceCaseLineList.data.splice(pCurIndex, 0, tempDataSourceArray.data[indexY])
      }
    }
    else {
      for (var x = tempDataSourceArray.data.length - 1; x >= 0; x--) {
        this.dataSourceCaseLineList.data.splice(pCurIndex, 0, tempDataSourceArray.data[x])
      }
    }
  }

  //on dropping and moving parent line and its sublines
  moveLineSublineRows(pPrevIndex: number, pCurIndex: number) {
    let dataSourceLength = this.dataSourceCaseLineList.data.length;
    let numRowRemoved: number = 0;
    let tempDataSourceArray = new MatTableDataSource(this.theCaseLineListArray);
    let indexK: number = 0;
    let indexI: number = 0;
    //prepare rows that are about to be moved
    while (indexK < dataSourceLength) {
      if (indexK == pPrevIndex) {
        //copy parent and its sublines rows
        indexI = pPrevIndex;
        while (indexI < dataSourceLength) {
          numRowRemoved++;
          tempDataSourceArray.data.push(this.dataSourceCaseLineList.data[indexI++]);
          if ((indexI == dataSourceLength) ||
            (CaseUtils.isBlankStr(this.dataSourceCaseLineList.data[indexI].wm_USER_CASE_SUBLINE_TX))) {
            //remove rows that had been moved from the original list
            this.dataSourceCaseLineList.data.splice(pPrevIndex, numRowRemoved);
            indexK = indexI;
            break;
          }
          else indexI--;
        }
      }
      indexK++;
    }
    /* PRESERVE: prepare rows that are about to be moved
    for (var k = 0; k < dataSourceLength; k++) {
      if (k == pPrevIndex) {
        //copy parent and its sublines rows
        for (var i = pPrevIndex; i < dataSourceLength; i++) {
          numRowRemoved++;
          tempDataSourceArray.data.push(this.dataSourceCaseLineList.data[i++]);
          if ((i == dataSourceLength) ||
            (CaseUtils.isBlankStr(this.dataSourceCaseLineList.data[i].wm_USER_CASE_SUBLINE_TX))) {
            //remove rows that are being moved
            this.dataSourceCaseLineList.data.splice(pPrevIndex, numRowRemoved);
            k = i;
            break;
          } else i--;
        }
      }
    }
   */
    //insert rows that are being moved back to line list in sequential order
    this.insertMovedLineSublineRows(pCurIndex, tempDataSourceArray, dataSourceLength);
  }

  //on Dropping row to the new postion in the list
  onDropRow(event: CdkDragDrop<string[]>) {
    let currentIndex = event.currentIndex + (this.paginator.pageSize * this.paginator.pageIndex);
    if (currentIndex == 0 && this.dataSourceCaseLineList.data[this.previousDragRowIndex].wm_USER_CASE_SUBLINE_TX) {
      MessageMgr.swalFire({
        text: 'Subline cannot be placed prior to the first line',
        icon: 'error',
        confirmButtonText: 'OK',
        width: 450
      })
      //reset previous moving row to 0
      this.previousDragRowIndex = 0;
    }
    else {
      if (currentIndex !== this.previousDragRowIndex) {
        //if there are sublines, then move all sublines as well
        if (!!this.dataSourceCaseLineList.data[this.previousDragRowIndex].virtualSublineList)
          this.moveLineSublineRows(this.previousDragRowIndex, currentIndex);
        else
          moveItemInArray(this.dataSourceCaseLineList.data, this.previousDragRowIndex, currentIndex);
        this.dataSourceCaseLineList.data[currentIndex].isRowBeingMoved = true;
        this.dataSourceCaseLineList._updateChangeSubscription();
        this.changeDetectorRef.detectChanges();
        this.isLineListDataChanged = true;
        this.isLineSublineBeingMoved = true;
      }
    }
  }

  /* Open the Rollup Subline Dialog */
  openRollupSublineCommentDialog(): any {
    this.dialog.open(RollupSublineComponent, {
      width: '40em',
      height: '40em',
      data: {
        caseId: this.caseRelatedInfoData.working_CASE_ID,
        versionId: this.caseRelatedInfoData.working_CASE_VERSION_ID
      }
    });
  }
  //card 5231 IPC overridden

  openIPCValidationCommentDialog(): any {

    let pCaseId = this.caseRelatedInfoData.working_CASE_ID;
    let pCaseVersionId = this.caseRelatedInfoData.working_CASE_VERSION_ID;
    console.log(pCaseId, pCaseVersionId, "-------------")
    // validateOverRiddenIPC(pCaseId: number, pVersionId: number);

    this.caseRestService
      .validateOverRiddenIPC(pCaseId, pCaseVersionId)
      .subscribe((pMessageList: Array<ErrorParameter>) => {
        if (pMessageList.length == 0) {
          MessageMgr.displaySuccess("No validation messages.");
          console.log(pMessageList.length, " pmessage length");
        }
        else {

          let title: string = "DSAMS: Validate Case IPC Override: ";
          this.messageService.displayMessageListTc(title, pMessageList).subscribe();
          console.log(pMessageList.length, " message length");
        }

      },
        err => {
          CaseUtils.ReportHTTPError(err, "Error validating case");

        }
      );
  }

  setIPCButtonDisabled() {

    if ((this.caseRelatedInfoData.wm_CASE_VERSION_TYPE_CD === "A") || (this.caseRelatedInfoData.wm_CASE_VERSION_TYPE_CD === "M")) {
      this.isDisabledIPCbutton = false;
    }
    if ((this.caseRelatedInfoData.wm_CASE_VERSION_TYPE_CD === "A" && this.caseLineInfoData.wm_CASE_LINE_LOI_IN === true)) {
      this.isDisabledIPCbutton = true;
    }
    if (this.caseRelatedInfoData.wm_CASE_VERSION_TYPE_CD === "M" && (this.caseLineInfoData.wm_CASE_LINE_LOI_IN === true)) {
      this.isDisabledIPCbutton = true;
    }
    if (this.caseLineInfoData.change_ACTION_CD === "A" || this.caseLineInfoData.change_ACTION_CD == "D" || this.caseLineInfoData.case_LINE_MARK_FOR_DELETION_IN === 'true') {
      this.isDisabledIPCbutton = true;
    }

    this.isIPCButtonVisible = ((this.caseRelatedInfoData.wm_CASE_VERSION_TYPE_CD === "A" || this.caseRelatedInfoData.wm_CASE_VERSION_TYPE_CD === "M")
      && this.dataSourceCaseLineList.data.length != null && this.dataSourceCaseLineList.data.length > 0);

    this.caseUIService.setIsNoprEnabled({ visible: this.isIPCButtonVisible, disabled: this.isDisabledIPCbutton });
  }

  // Card 5232
  setApplyProfileCd(element: any, index: number) {
    this.caseUIService.theComponentSaveCaseLineState[CaseUIService.SAVE_CASE_LINE_LIST_STATE].isDataChanged = true;
    this.dataSourceCaseLineList.data[index].isDataChanged = true;
    element.status = DsamsConstants.ENT_CHANGED.toString();
    this.dataSourceCaseLineList.data[index].entityStatus = DsamsConstants.ENT_CHANGED.toString();
    element.entityStatus = DsamsConstants.ENT_CHANGED.toString();
    this.dataSourceCaseLineList.data[index].wm_SaveCL = true;

    this.dataSourceCaseLineList.data[index].caseLineAssistanceTypeList.forEach(item => {
      item.status = 0;
    });
    this.dataSourceCaseLineList.data[index].caseLineDeliveryItemList.forEach(item => {
      item.caseLineDeliveryScheduleList.forEach(subItem => {
        subItem.status = 0;
      });
      item.status = 0;
    });
    this.dataSourceCaseLineList.data[index].caseLineDeliveryTermList.forEach(item => {
      item.status = 0;
    });
    this.dataSourceCaseLineList.data[index].caseLineOfferReleaseList.forEach(item => {
      item.status = 0;
    });
    this.isLineListDataChanged = true;
  }

 
 }

