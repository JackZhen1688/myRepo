import { DsamsConstants } from "../../dsams.constants";
import { ErrorParameter } from "../../entities/specialEntities/error-parameter.model";
import { DsamsUserMessageService } from "../../services/dsams-user-message.service";
import { caseLineComponentDto } from "../model/dto/case-line-component-dto";
import { ICaseLinePricing } from "../model/dto/icase-line-pricing";
import { CaseUtils } from "../utils/case-utils";
import { CaseLineIPCDto } from "./line-pricing/ipc-tab-dashboard/model/dto/case-line-ipc-dto";
import { supplementalLineNoteDto } from "./line-pricing/ipc-tab-dashboard/model/dto/supplemental-line-note-dto";
/**
 * Line pricing Utilties class.
 * @author CBanta
 * @date 08/2021
 * 
 */
export class LinePricingUtils {
    /**
     * Validate the Case Line Pricing screen pre-save, pre-database calls.
     * This is just the completeness of the screen and basic validation; no fancy checks that dsams legacy does.
     * That is done after this validation check.
     * @param pCaseLineData Case Line object we're validationg.
     * @param pMessageService Message Service used to popup the dialog.
     * @returns true if the validation is sucessful (no errors); false if not.
     */
    public static validateCaseLinePricingPreSave(pCaseLineData: ICaseLinePricing, pMessageService: DsamsUserMessageService): boolean {
        let errorParamList: Array<ErrorParameter> = [];
        let pricingCategoryStr: string = "Pricing";
        if (pCaseLineData.case_LINE_ITEM_QY >= 10000000) {
            errorParamList.push(LinePricingUtils.newMessage(pricingCategoryStr, "", "Case Line Item Quantity cannot be greater than 9,999,999."));
        }
        if (!pCaseLineData.price_EFFECTIVE_DT) {
            errorParamList.push(LinePricingUtils.newMessage(pricingCategoryStr, "", "Pricing Effective Date is required."));
        }
        if (!!pCaseLineData.price_EXPIRATION_DT &&
            !!pCaseLineData.price_EFFECTIVE_DT &&
            pCaseLineData.price_EXPIRATION_DT < pCaseLineData.price_EFFECTIVE_DT) {
            errorParamList.push(LinePricingUtils.newMessage(pricingCategoryStr, "", "Pricing Expiration Date cannot be earlier than the Effective Date."));
        }
        if (pCaseLineData.issue_UNIT_CD == "XX" && (pCaseLineData.case_LINE_ITEM_QY.toString() !== "N/A" &&
            pCaseLineData.case_LINE_ITEM_QY !== 0)) {
            errorParamList.push(LinePricingUtils.newMessage(pricingCategoryStr, "", "Quantity cannot be entered. Unit of issue is XX."));
        }
        if (pCaseLineData.issue_UNIT_CD == "EA" && (pCaseLineData.case_LINE_ITEM_QY.toString() == "N/A" ||
            pCaseLineData.case_LINE_ITEM_QY == 0)) {
            errorParamList.push(LinePricingUtils.newMessage(pricingCategoryStr, "", "Quantity cannot be null or zero (0) if unit of issue is EA."));
        }
        if (!!pCaseLineData.price_EXPIRATION_DT &&
            pCaseLineData.price_EXPIRATION_DT != pCaseLineData.old_PRICE_EXPIRATION_DT &&
            pCaseLineData.price_EXPIRATION_DT < new Date(new Date().toDateString())    // Truncate date
        ) {
            errorParamList.push(LinePricingUtils.newMessage(pricingCategoryStr, "", "Pricing Expiration Date cannot be earlier than today's date."));
        }
        // Case Line Component List
        if (!!pCaseLineData.caseLineComponentList)
            this.validateLineComponentList(pCaseLineData, errorParamList);

        let hasErrors: boolean = (errorParamList.length > 0);
        if (hasErrors) {
            pMessageService.displayMessageListTc("Case Line Pricing Save Validation", errorParamList).subscribe();
        }
        return !hasErrors;
    }

    //per sonarque rule
    private static validateLineComponentList(pCaseLineData: ICaseLinePricing, errorParamList: Array<ErrorParameter>) {
        let clcIndex = 1;
        let pricingCategoryStr = "Component";
        let clcRef: string = "";
        for (let currClc of pCaseLineData.caseLineComponentList) {
            clcRef = "Component " + clcIndex;
            if (CaseUtils.isBlankStr(currClc.primary_CATEGORY_CD)) {
                errorParamList.push(LinePricingUtils.newMessage(pricingCategoryStr, clcRef, "Primary Category is required."));
            }
            if (CaseUtils.isBlankStr(currClc.price_ELEMENT_CD)) {
                errorParamList.push(LinePricingUtils.newMessage(pricingCategoryStr, clcRef, "Price Element Component is required."));
            }
            if (CaseUtils.isBlankStr(currClc.fund_CD)) {
                errorParamList.push(LinePricingUtils.newMessage(pricingCategoryStr, clcRef, "Component Fund is required."));
            }
            if (CaseUtils.isBlankStr(currClc.wm_base_PRICE_SOURCE_NM)) {
                errorParamList.push(LinePricingUtils.newMessage(pricingCategoryStr, clcRef, "Base Price Source is required."));
            }
            if (CaseUtils.isBlankStr(currClc.wm_component_UNIT_BASE_PRICE_AM)) {
                errorParamList.push(LinePricingUtils.newMessage(pricingCategoryStr, clcRef, "Base Unit Price is required."));
            }
            LinePricingUtils.validateIPCRows(currClc.caseLineIpcList, clcIndex).forEach(eachRow => {
                errorParamList.push(eachRow);
            });
            LinePricingUtils.validateCllaRows(currClc.caseLineListAttachmentList, clcIndex).forEach(eachRow => {
                errorParamList.push(eachRow);
            });
            clcIndex++;
        }
    }

    //per sonarque rule
    private static validateIPCData(currIpc: CaseLineIPCDto, pricingCategoryStr: string, ipcRef: string, ipcErrorList: Array<ErrorParameter>) {
        if (CaseUtils.isBlankStr(currIpc.ipc_NUMBER_ID)) {
            ipcErrorList.push(LinePricingUtils.newMessage(pricingCategoryStr, ipcRef, "IPC Number is required."));
        }
        if (CaseUtils.isBlankStr(currIpc.price_ELEMENT_CD)) {
            ipcErrorList.push(LinePricingUtils.newMessage(pricingCategoryStr, ipcRef, "IPC Price Element is required."));
        }
        if (CaseUtils.isBlankStr(currIpc.fund_CD)) {
            ipcErrorList.push(LinePricingUtils.newMessage(pricingCategoryStr, ipcRef, "IPC Fund is required."));
        }
    }

    /**
     * IPC rows
     */
    private static validateIPCRows(ipcList: Array<CaseLineIPCDto>, pClcRow: number): Array<ErrorParameter> {
        let ipcErrorList: Array<ErrorParameter> = [];
        const pricingCategoryStr: string = "IPC";
        let ipcIndex: number = 1;
        let ipcRef: string = "";
        let ipcConcatStr: string = "";
        if (!!ipcList) {
            // First loop - check for regular errors.
            for (let currIpc of ipcList.filter(elem => { return elem.status !== DsamsConstants.ENT_DELETED.toString() })) {
                ipcRef = "Comp " + pClcRow + ", IPC " + ipcIndex;
                this.validateIPCData(currIpc, pricingCategoryStr, ipcRef, ipcErrorList);
                // Concat string for checking dups.
                ipcConcatStr = ipcConcatStr + "," + currIpc.ipc_NUMBER_ID;
                ipcIndex++;
            }
            // Loop 2: Check for Dup IPCs.
            ipcIndex = 1;
            for (let currIpc of ipcList.filter(elem => { return elem.status !== DsamsConstants.ENT_DELETED.toString() })) {
                ipcRef = "Comp " + pClcRow + ", IPC " + ipcIndex;
                let numIpc = (ipcConcatStr.match(new RegExp(currIpc.ipc_NUMBER_ID, "g")) || []).length;   // Num matches in concatenated string.
                if (numIpc > 1) {
                    ipcErrorList.push(LinePricingUtils.newMessage(pricingCategoryStr, ipcRef, "Duplicate IPC: " + currIpc.ipc_NUMBER_ID));
                }
                ipcIndex++;
            }
        }
        return ipcErrorList;
    }

    /**
     * Supplemental Rows
     */
    private static validateCllaRows(pCllaList: Array<supplementalLineNoteDto>, pClcRow: number): Array<ErrorParameter> {
        let suppErrorList: Array<ErrorParameter> = [];
        const pricingCategoryStr: string = "Supplemental";
        let suppIndex: number = 1;
        let suppRef: string = "";
        let suppConcatStr: string = "";
        if (!!pCllaList) {
            // First loop - check for regular errors.
            for (let currClla of pCllaList.filter(elem => { return elem.status !== DsamsConstants.ENT_DELETED.toString() })) {
                suppRef = "Comp " + pClcRow + ", Suppl. " + suppIndex;
                if (CaseUtils.isBlankStr(currClla.list_ITEM_DESCRIPTION_TX)) {
                    suppErrorList.push(LinePricingUtils.newMessage(pricingCategoryStr, suppRef, "Item Description is required."));
                }
                if (!currClla.case_LINE_LIST_ATTACHMENT_QY) {
                    suppErrorList.push(LinePricingUtils.newMessage(pricingCategoryStr, suppRef, "Quantity is required."));
                }
                if (!currClla.case_LINE_LIST_UNIT_PRICE_AM) {
                    suppErrorList.push(LinePricingUtils.newMessage(pricingCategoryStr, suppRef, "Unit Of Cost is required."));
                }
            }
        }
        return suppErrorList;
    }

    /**
     * Validate MTDS window.
     */
    public static validateMtds(pClc: caseLineComponentDto, pMessageService: DsamsUserMessageService): boolean {
        let errorParamList: Array<ErrorParameter> = [];
        //
        // MTDS Person List
        //
        if (!!pClc.caseLineCompMtdsPersonList) {
            let mtdsPersonelIndex = 1;
            let pricingCategoryStr = "MTDS Personnel";
            let clcRef: string = "";
            for (let currMtdsPersonnel of pClc.caseLineCompMtdsPersonList) {
                clcRef = "Pers Row " + mtdsPersonelIndex;
                //
                if ((!CaseUtils.isBlankStr(currMtdsPersonnel.mtds_PERSON_WORK_YEARS_TX) &&
                    !!currMtdsPersonnel.mtds_PERSON_WORK_YEARS_QY &&
                    currMtdsPersonnel.mtds_PERSON_WORK_YEARS_QY > 0) ||
                    (CaseUtils.isBlankStr(currMtdsPersonnel.mtds_PERSON_WORK_YEARS_TX) &&
                        !(currMtdsPersonnel.mtds_PERSON_WORK_YEARS_QY || currMtdsPersonnel.mtds_PERSON_WORK_YEARS_QY > 0))
                ) {
                    errorParamList.push(LinePricingUtils.newMessage(pricingCategoryStr, clcRef, "Either Person Work Years Quantity or Person Work Years must be entered, but not both."));
                }
                mtdsPersonelIndex++;
            }
        }
        //
        let hasErrors: boolean = (errorParamList.length > 0);
        if (hasErrors) {
            pMessageService.displayMessageListTc("Case Line Pricing Validation", errorParamList).subscribe();
        }
        return !hasErrors;
    }


    /**
     * Add an error message to the list.
     */
    private static newMessage(pCategory: string, pReference: string, pMessageText: string): ErrorParameter {
        return {
            businessRule: "",
            category: pCategory,
            column3: "",
            column4: "",
            errorID: "",
            errorType: DsamsConstants.ERROR_TYPE_ERROR,
            messageParameter: "",
            messageParameter2: "",
            messageParameter3: "",
            reference: pReference,
            messageText: pMessageText
        };
    }

    /**
     * Get the line list attachment cost.
     */
    public static setCaseLineListAttachmentCost(pClc: caseLineComponentDto) {
        let cllaTotal: number = 0;
        if (!!pClc.caseLineListAttachmentList) {
            pClc.caseLineListAttachmentList.forEach((eachClla: supplementalLineNoteDto) => {
                cllaTotal += ((!eachClla.case_LINE_LIST_ATTACHMENT_QY ? 0 : eachClla.case_LINE_LIST_ATTACHMENT_QY) * (!eachClla.case_LINE_LIST_UNIT_PRICE_AM ? 0 : eachClla.case_LINE_LIST_UNIT_PRICE_AM));
            });
        }
        pClc.component_UNIT_BASE_PRICE_AM = cllaTotal;
    }

    /**
     * Update the totals for a CLC line.
     */
    public static setClcTotalAmounts(pClc: caseLineComponentDto) {
        let ipcAboveLineCost: number = 0;
        let ipcBelowLineCost: number = 0;
        //Sum up all the IPC-s.
        if (!!pClc.caseLineIpcList) {
            for (let currIpc of pClc.caseLineIpcList) {
                if (!!currIpc.ipc_NUMBER_ID && currIpc.ipc_NUMBER_ID !== "" && !!currIpc.case_LINE_IPC_STATUS_CD && currIpc.case_LINE_IPC_STATUS_CD != "NA") {
                    if (currIpc.ipc_NUMBER_ID.substring(0, 1) == "A") {
                        ipcAboveLineCost += (!currIpc.case_LINE_IPC_UNIT_COST_AM ? 0 : currIpc.case_LINE_IPC_UNIT_COST_AM);
                    }
                    else {
                        ipcBelowLineCost += ((!currIpc.case_LINE_IPC_UNIT_COST_AM ? 0 : currIpc.case_LINE_IPC_UNIT_COST_AM) * (!pClc.case_LINE_COMPONENT_QY ? 0 : pClc.case_LINE_COMPONENT_QY));
                    }
                }
            }
        }
        pClc.above_LINE_COST = (!pClc.component_UNIT_BASE_PRICE_AM ? 0 : pClc.component_UNIT_BASE_PRICE_AM) * (!pClc.case_LINE_COMPONENT_QY ? 0 : pClc.case_LINE_COMPONENT_QY);
        pClc.above_LINE_COST += ipcAboveLineCost;   // Add IPC Above Cost
        pClc.below_LINE_COST = ipcBelowLineCost;    // Just IPC Below Cost
        pClc.total_COST = pClc.above_LINE_COST + pClc.below_LINE_COST;
    }
}