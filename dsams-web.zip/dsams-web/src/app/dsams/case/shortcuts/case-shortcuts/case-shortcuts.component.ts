import { Component, Input, OnInit, OnDestroy } from '@angular/core';
import { DsamsConstants } from '../../../dsams.constants';
import { CaseRelatedInfoType } from '../../model/case-related-info-type';
import { CaseLineRelatedInfoType } from '../../model/case-line-related-info-type';
import { CaseUIService } from '../../services/case-ui-service';
import { DsamsShareService } from '../../../services/dsams-share.service';
import { CaseRestfulService } from '../../services/case-restful.service';
import { Router } from '@angular/router';
import { BehaviorSubject, Subscription } from 'rxjs';
import { MatDialog } from '@angular/material/dialog';
import { CaseAmendModNumberComponent } from '../../case-dashboard/case-amendmod-number/case-amendmod-number.component';
import { CaseUtils } from '../../utils/case-utils';
import { CaseCountryComponent } from '../../case-dashboard/case-country/case-country.component';
import { ReferenceDataType } from '../../model/reference-data-type';
import { caseConstants } from '../../case-dashboard/case-dashboard.component';
import { ICaseVersion } from '../../model/dto/icase-version'
import { MessageMgr } from '../../validation/message-mgr';
import { ifaceCaseLineEntity } from '../../model/case-line-model';
import { CaseReserveComponent } from '../../case-dashboard/case-reserve/case-reserve.component';
import { IUsedUserCase } from '../../model/dto/used-user-case';
import { IOptionConfig, IOptions, IShortcuts } from '../shortcut-model';
import { CaseRequestParamsType } from '../../model/search-params/case-request-params-type';
import { IEditResponseType } from '../../model/edit-response-type';
import { map, take } from 'rxjs/operators';
import { formatCurrency } from '@angular/common';
import { CaseAmendModRefreshComponent } from '../../case-dashboard/case-amendmod-refresh/case-amendmod-refresh.component';
import { LinkCaseDataIface, LinkCaseDataClass } from '../../model/link-case-data';



@Component({
  selector: 'app-case-shortcuts',
  templateUrl: './case-shortcuts.component.html',
  styleUrls: ['./case-shortcuts.component.css', '../shortcut-common.component.css']
})
export class CaseShortcutsComponent implements OnInit, OnDestroy {

  private static CASE_LINE_EDITOR_STR: string = DsamsConstants.CASE_LINE_EDITOR;

  //From case-dashboard.component.html
  @Input() label: string = "";
  @Input() caseId: number;
  @Input() caseVerTypeCd: string;
  @Input() caseVerNumId: number;
  @Input() caseVersionId: number;
  @Input() saProgram: string;
  @Input() env: string;
  @Input() countryCode: string;
  @Input() caseDesignator: string;
  @Input() currentPage: string;
  @Input() userCaseId: string;

  isLoading: BehaviorSubject<boolean> = new BehaviorSubject(false);
  hideOptions: boolean = false;
  hideShortcuts: boolean = false;
  aCaseVersionData: ICaseVersion;
  aCaseLineData: ifaceCaseLineEntity;
  aCaseUsedUserData: IUsedUserCase;
  //DSAMS-5390 04/22 DH
  caseVersionStatusCd: string = '';

  countryRefType: any = {};
  selectedTab: any = 0;
  selectedTabLabel: any = 'Line';
  refCustomerOrganizationList: Array<ReferenceDataType> = [];

  /* Shortcuts */
  /*This one is ok, leave it open */
  shortcutsList: IShortcuts[] = [
    { id: 'AA', label: '--Select Shortcut--', isDisabled: false },
    { id: 'AL', label: 'Attachment List', isDisabled: false },
    { id: 'CR', label: 'Customer Request', isDisabled: false },
    { id: 'LL', label: 'Line List', isDisabled: false },
    { id: 'CD', label: 'Case Detail', isDisabled: false },
    { id: 'NL', label: 'Note List', isDisabled: false },
    { id: 'RM', label: 'Remarks', isDisabled: false },
    // Jira DSAMS-5390 04/22 DH: these shortcuts are not active yet, so set to disable 
    { id: 'CS', label: 'Customer Supplied Information Window', isDisabled: true },
    { id: 'MS', label: 'Milestones', isDisabled: false },
    { id: 'PS', label: 'Payment Schedule', isDisabled: true },
  ];

  optionsList: IOptions[] = [{ id: 'emptyRow', label: '--Select Option--', checkMark: false, disabled: false }];
  optionsListSorted: IOptions[] = [];
  caseRelatedInfoData: CaseRelatedInfoType;
  caseLineRelatedInfoData: CaseLineRelatedInfoType;

  private _isS1DescriptionEnabled: boolean = false;
  private _isBenefittingEnabled: boolean = false;
  private _isCountryEnabled: boolean = false;
  private _isSpecialBillingAgreementEnabled: boolean = false;
  // private _lineNavLabel: string = "";
  private _caseUIServiceSubscription: Subscription;
  private _caseUIServiceLineSubscription: Subscription;
  private _menuChangeSubscription: Subscription;
  private _validateCaseEnabledSubscription: Subscription;
  private _optionsMenuHiddenSubscription: Subscription;
  private _shortcutsMenuHiddenSubscription: Subscription;
  private _requisitionForcastIndicatorSubscription: Subscription;
  private _congressionalNotificationSubscription: Subscription;
  private _countrySubscription: Subscription;
  private _mgrSubscription: Subscription;
  private _mgr2Subscription: Subscription;
  private _penInkSubscription: Subscription;
  private _mildepSubscription: Subscription;
  private _caseInReviewSubscription: Subscription;
  private _caseInProposedSubscription: Subscription;
  private _dscaSubscription: Subscription;
  private _updImplCaseSubscription: Subscription;
  private _specialBillingAgreemengSubscription: Subscription;
  private _amendModSubscription: Subscription;
  private _docInitiatorSubscription: Subscription;
  private _s1DescriptionSubscription: Subscription;
  private _customerInformationSubscription: Subscription;
  private _reserveCaseIdentifierSubscription: Subscription;
  private _statusCompleteSubscription: Subscription;
  private _pageNavSubscription: Subscription;
  private _editSubscription: Subscription;
  private _noprSubscription: Subscription;
  private _calculateFMSOSubscription: Subscription = null;
  private _disableCalculateFMSOSubscription: Subscription = null;

  //selected: string = this.optionsList[0].id; //Default option in the drop down
  selected: string;
  shortcutSelected: string = this.shortcutsList[0].id; //Default option in the drop down

  //public dialogRef: MatDialogRef<CaseAmendModNumberComponent>
  //public countryDialogRef: MatDialogRef<CaseCountryComponent>
  // public reserveDialogRef: MatDialogRef<CaseReserveComponent>
  ShortcutsListSorted: IShortcuts[];
  filterLength: any[] = [];
  showChangeCountryOption: boolean = true;
  isS1DescriptionUpdatable: boolean = false;
  optionFlagNumber: number = 0;
  pseudoInd: boolean = false;
  isLineDetailDisabled: boolean;
  isSpecificSublineFieldDisabled: boolean;
  isEditToggleDisabled: boolean;
  private newCRSubscription: Subscription = null;

  stopClickPropagate(event: any) {
    event.stopPropagation();
    event.preventDefault();
  }

  constructor(private caseRestService: CaseRestfulService,
    private caseUIService: CaseUIService,
    private dataSharingService: DsamsShareService,
    private router: Router,
    public dialog: MatDialog) { }

  /**
   * Add to an options list if it does not already exist.
   * @param pId ID of the dropdown option.
   * @param pLabel Text to display in the dropdown option.
   */
  private pushToOptionsList(pId: string, pLabel: string, pDisabled: boolean) {
    let alreadyExists: boolean = false;
    for (var i = 0; i < this.optionsList.length; i++) {
      if (this.optionsList[i].id === pId) {
        alreadyExists = true;
        this.optionsList[i].disabled = pDisabled;
        break;
      }
    }
    if (!alreadyExists) {
      this.optionsList.push({ id: pId, label: pLabel, disabled: pDisabled });
      this.selected = this.optionsList[0].id;
    }
  }

  /**
   * Splice from the options list, checking first if it exists.
   * @param pId ID of the dropdown option.
   */
  private spliceFromOptionsList(pId: string) {
    for (var i = this.optionsList.length - 1; i >= 0; --i) {
      if (this.optionsList[i].id === pId) {
        this.optionsList.splice(i, 1);
      }
    }
  }

  /**
   * Splice from the shortcutsList list, checking first if it exists.
   * @param pId ID of the dropdown option.
   */
  private spliceFromShortcutList(pId: string) {
    for (var i = this.shortcutsList.length - 1; i >= 0; --i) {
      if (this.shortcutsList[i].id === pId) {
        this.shortcutsList.splice(i, 1);
      }
    }
  }

  //begin DSAMS-5754 07/22 DH - use static ref data
  getCustomerOrgRef() {
    if (CaseUtils.theRefCustomerOrganizationList == null || CaseUtils.theRefCustomerOrganizationList.length == 0)
      this.caseRestService
        .getReferenceData(DsamsConstants.REF_CUSTOMER_ORGANIZATION, "", 0, true)
        .subscribe(
          data => {
            this.refCustomerOrganizationList = data;
          },
          err => {
            CaseUtils.ReportHTTPError(err, caseConstants.REFERENCE_ERROR_HEADER_STR +
              DsamsConstants.REF_CUSTOMER_ORGANIZATION);
          }
        );
    else this.refCustomerOrganizationList = CaseUtils.theRefCustomerOrganizationList;
  }
  //end DSAMS-5754 07/22 DH

  ngOnInit() {
    this.hideOptions = true;
    this.hideShortcuts = false;
    if (!this._caseUIServiceSubscription) {
      this._caseUIServiceSubscription = this.caseUIService.getCaseRelatedInfoValues().subscribe((value) => {
        this.caseRelatedInfoData = value;
      });
    }
    if (!this._caseUIServiceLineSubscription) {
      this._caseUIServiceLineSubscription = this.caseUIService.getCaseLineRelatedInfoValues().subscribe((value) => {
        this.caseLineRelatedInfoData = value;
        this.setCaseVersionStatusCd();
      });
    }
    /* Get Country Codes */
    this.getCustomerOrgRef();

    /* Requitition Forcast Amount */
    this._requisitionForcastIndicatorSubscription = this.caseUIService.getIsRequisitionForcastIndicatorEnabled().subscribe((value) => {
      if (value) {
        this.pushToOptionsList('UCAI', 'Change Customer Req. Allowed Indicator', false);
      } else {
        this.spliceFromOptionsList("UCAI");
      }
    });

    /* Congressional Notification Amounts */
    this._congressionalNotificationSubscription = this.caseUIService.getIsCongressionalNotificationEnabled().subscribe((value) => {
      if (value) {
        this.pushToOptionsList('UCCN', 'Update Congressional Notification Amounts', false);
      } else {
        this.spliceFromOptionsList("UCCN");
      }
    });

    /* Change Country */
    // Special logic - do not use pushToOptionsList because of special logic.
    this._countrySubscription = this.caseUIService.getIsCountryEnabled().subscribe((value) => {
      if (value) {
        if (!this._isCountryEnabled) {
          this.optionsList.push(
            { id: 'UCCC', label: 'Change Country', disabled: false },
          );
        }
        this._isCountryEnabled = value;
        this.selected = this.optionsList[0].id;
        if (this._isS1DescriptionEnabled) {
          this.caseUIService.setFieldS1DescriptionDisabled(false);
          this.caseUIService.optionSelectedUCCS.next(true);
          //  this.caseUIService.skipValidation.next(true);   Causes my window to skip validating unnecessarily, so I commented it out.
        }
      } else {
        this.spliceFromOptionsList("UCCC");
      }
    });

    /* Update Mgr/Procur Agncy/Preparing Actvy */
    this._mgrSubscription = this.caseUIService.getIsMgrEnabled().subscribe((value) => {
      if (value) {
        this.pushToOptionsList('UCMP', 'Update Mgr/Procur Agncy/Preparing Activity', false);
      } else {
        this.spliceFromOptionsList("UCMP");
      }
    });

    /* Pen & Ink */
    this._penInkSubscription = this.caseUIService.getIsPenInkEnabled().subscribe((value) => {
      if (value) {
        this.pushToOptionsList('UCPI', 'Pen & Ink', false);
      } else {
        this.spliceFromOptionsList("UCPI");
      }
    });

    /* MILDEP Signatory */
    this._mildepSubscription = this.caseUIService.getIsMildepEnabled().subscribe((value) => {
      if (value) {
        this.pushToOptionsList('UCMS', 'MILDEP Signatory', false);
      } else {
        this.spliceFromOptionsList("UCMS");
      }
    });

    /* Update Case In Review */
    this._caseInReviewSubscription = this.caseUIService.getIsCaseInReviewEnabled().subscribe((value) => {
      if (value) {
        this.pushToOptionsList('UCIR', 'Update Case in Review', false);
      } else {
        /* if going from one case to another */
        this.spliceFromOptionsList("UCIR");
      }
    });

    /* Update Case In Proposed */
    this._caseInProposedSubscription = this.caseUIService.getIsCaseInProposedEnabled().subscribe((value) => {
      if (value) {
        this.pushToOptionsList('UCIP', 'Update Case in Proposed', false);
      } else {
        /* if going from one case to another */
        this.spliceFromOptionsList("UCIP");
      }
    });

    /* DSCA Update */
    this._dscaSubscription = this.caseUIService.getIsDscaEnabled().subscribe((value) => {
      if (value) {
        this.pushToOptionsList('UCDU', 'DSCA Update', false);
      } else {
        /* if going from one case to another */
        this.spliceFromOptionsList("UCDU");
      }
    });

    /* Update Implemented Case */
    this._updImplCaseSubscription = this.caseUIService.getIsUpdImplCaseEnabled().subscribe((value) => {
      if (value) {
        this.pushToOptionsList('UCUI', 'Update Implemented Case', false);
      } else {
        /* if going from one case to another */
        this.spliceFromOptionsList("UCUI");
      }
    });

    /* Special Billing Agreement */
    // Keep this the way it is, don't use pushToOptionsList because it has special logic.
    this._isBenefittingEnabled = <boolean>CaseUtils.getBusinessRuleMapValue("BE", "BENEFITTING_COUNTRY", false);
    this._specialBillingAgreemengSubscription = this.caseUIService.getIsSpecialBillingAgreementEnabled().subscribe((value) => {
      if (value) {
        if (!this._isSpecialBillingAgreementEnabled && !this._isBenefittingEnabled) {
          this.optionsList.push({
            id: 'UCSB', label: 'Special Billing Agreement', disabled: false
          });
        }
        this._isBenefittingEnabled = value;
        this.selected = this.optionsList[0].id;
        this.setSBLCheckMarkInd();
      } else {
        /* if going from one case to another */
        this.spliceFromOptionsList("UCSB");
      }
    });

    /* Amend Mod Number */
    this._amendModSubscription = this.caseUIService.getIsAmendModEnabled().subscribe((value) => {
      if (value) {
        this.pushToOptionsList('UCAM', 'Change Amend/Mod Number', false);
        this.pushToOptionsList('UCRA', 'Refresh Amend/Mod', false);
      } else {
        /* if going from one case to another */
        this.spliceFromOptionsList("UCAM");
        this.spliceFromOptionsList("UCRA");
      }
    });


    /* Document Initiator */
    this._docInitiatorSubscription = this.caseUIService.getIsDocInitiatorEnabled().subscribe((value) => {
      if (value) {
        this.pushToOptionsList('UCDI', 'Change Document Initiator', false);
      } else {
        /* if going from one case to another */
        this.spliceFromOptionsList("UCDI");
      }
    });

    /* S1 Description */
    this._s1DescriptionSubscription = this.caseUIService.getIsS1DescriptionEnabled().subscribe((value) => {
      if (value) {
        if (!this._isS1DescriptionEnabled)
          this.optionsList.push({ id: 'UCCS', label: 'Change S1 Description', disabled: false });
        this._isS1DescriptionEnabled = value;
        this.selected = this.optionsList[0].id;
      } else {
        /* if going from one case to another */
        this.spliceFromOptionsList("UCCS");
      }
    });

    /* Change Customer Information */
    this._customerInformationSubscription = this.caseUIService.getIsCustomerInformationEnabled().subscribe((value) => {
      if (value) {
        this.pushToOptionsList('UCCI', 'Change Customer Information', false);
      } else {
        /* if going from one case to another */
        this.spliceFromOptionsList("UCCI");
      }
    });

    /* Reserve Case Identifier */
    this._reserveCaseIdentifierSubscription = this.caseUIService.getIsReserveCaseIdentifierEnabled().subscribe((value) => {
      if (value) {
        this.pushToOptionsList('UCRC', 'Reserve Case Identifier', false);
      } else {
        /* if going from one case to another */
        this.spliceFromOptionsList("UCRC");
      }
    });

    /* Validate Case */
    if (!this._validateCaseEnabledSubscription) {
      this._validateCaseEnabledSubscription = this.caseUIService.getIsValidateCaseEnabled().subscribe((value) => {
        if (value) {
          this.pushToOptionsList('VC', 'Validate Case', false);
        } else {
          /* if going from one case to another */
          this.spliceFromOptionsList("VC");
        }
      });
    }

    /* Update Manager 2 */
    this._mgr2Subscription = this.caseUIService.getIsMgrEnabled2().subscribe((value) => {
      if (value) {
        this.pushToOptionsList('UCM2', 'Update Manager', false);
      } else {
        /* if going from one case to another */
        this.spliceFromOptionsList("UCM2");
      }
    });

    /* Status Complete */
    this._statusCompleteSubscription = this.caseUIService.getIsStatusCompleteEnabled().subscribe((value) => {
      if (value) {
        this.pushToOptionsList('STCM', 'Services Complete', false);
      } else {
        /* if going from one case to another */
        this.spliceFromOptionsList("STCM");
      }
    });

    /* NOPR */
    this._noprSubscription = this.caseUIService.getIsNoprEnabled().subscribe((pValue: IOptionConfig) => {
      if (!!pValue) {
        this.spliceFromOptionsList("NPOR");
        if (pValue.visible) {
          this.pushToOptionsList('NPOR', 'Update POR/NPOR', pValue.disabled);
        }
      }
    });

    /* Calculate FMSO option */
    this.subscribeToCalculateFMSOOption();
    this.subscribeToDisableCalculateFMSOOption();

    /* Options Menu Hidden Subscription */
    if (!this._optionsMenuHiddenSubscription) {
      this._optionsMenuHiddenSubscription = this.caseUIService.getIsOptionsMenuHidden().subscribe((value: boolean) => {
        setTimeout(() => { this.hideOptions = value; }, 0);
      });
    }

    /* Options Menu Hidden Subscription */
    if (!this._shortcutsMenuHiddenSubscription) {
      this._shortcutsMenuHiddenSubscription = this.caseUIService.getIsShortcutsMenuHidden().subscribe((value: boolean) => {
        setTimeout(() => { this.hideShortcuts = value; }, 0);
      });
    }
  
    //set custom shortcut for customer request panel
    // this.setCustomShortcutList();

    // Reset flag
    this.caseUIService.setFieldDocInitatorDisabled(true);
    this.filterCurrentPage();
  }

  //DSAMS-5390 04/22 DH 
  setCaseVersionStatusCd() {
    if (!!this.caseLineRelatedInfoData && !!this.caseLineRelatedInfoData.case_VERSION_STATUS_CD)
      this.caseVersionStatusCd = this.caseLineRelatedInfoData.case_VERSION_STATUS_CD;
  }

  //set custom shortcut list for Customer Request panel
  setCustomShortcutList() {
    this._pageNavSubscription = this.caseUIService.getPageNavigation().subscribe((value) => {
      if (value === DsamsConstants.PAGE_CUSTOMER_REQUEST) {
        //not sure what happens to the original shortcutsList, just reintialized for now
        this.shortcutsList = [
          { id: 'AA', label: '--Select Shortcut--', isDisabled: false },
          { id: 'DT', label: 'Details', isDisabled: false },
          { id: 'RM', label: 'Remarks', isDisabled: false },
          { id: 'LL', label: 'Line List', isDisabled: false },
          { id: 'NL', label: 'Note List', isDisabled: false },
          // Jira DSAMS-5390 04/22 DH: these shortcuts are not active yet, so set to disable 
          { id: 'CS', label: 'Customer Supplied Information Window', isDisabled: true },
          { id: 'MS', label: 'Milestones', isDisabled: false },
          { id: 'PS', label: 'Payment Schedule', isDisabled: true },
        ];
      }
    });
  }

  ngDoCheck() {
    //Sort Menus
    this.optionsList = this.sortOptionsList();
    this.shortcutsList = this.sortShortcutsList();
    if (this.caseUIService.getNotifyToSetDefaultOption() === true) {
      this.selectOption('emptyRow', false);
      this.caseUIService.setNotifyToSetDefaultOption(false);
    }
  }

  //Sort Options
  sortOptionsList(): IOptions[] {
    this.optionsListSorted = this.optionsList.sort(function (a, b) {
      return a.label.localeCompare(b.label) || a.id.localeCompare(b.id);
    });
    return this.optionsListSorted;
  }

  //Sort Shortcuts 
  sortShortcutsList(): IShortcuts[] {
    return (this.shortcutsList.sort(function (a, b) {
      if (!a.isDisabled)
        return a.label.localeCompare(b.label) || a.id.localeCompare(b.id);
    }));
  }

  ngOnDestroy() {
    if (!!this._caseUIServiceSubscription) {
      this._caseUIServiceSubscription.unsubscribe();
    }
    if (!!this._caseUIServiceLineSubscription) {
      this._caseUIServiceLineSubscription.unsubscribe();
    }
    if (!!this._menuChangeSubscription) {
      this._menuChangeSubscription.unsubscribe();
    }
    if (!!this._validateCaseEnabledSubscription) {
      this._validateCaseEnabledSubscription.unsubscribe();
    }
    if (!!this._optionsMenuHiddenSubscription) {
      this._optionsMenuHiddenSubscription.unsubscribe();
    }
    if (!!this._requisitionForcastIndicatorSubscription) {
      this._requisitionForcastIndicatorSubscription.unsubscribe();
    }
    if (!!this._congressionalNotificationSubscription) {
      this._congressionalNotificationSubscription.unsubscribe();
    }
    if (!!this._countrySubscription) {
      this._countrySubscription.unsubscribe();
    }
    if (!!this._mgrSubscription) {
      this._mgrSubscription.unsubscribe();
    }
    if (!!this._mgr2Subscription) {
      this._mgr2Subscription.unsubscribe();
    }
    if (!!this._penInkSubscription) {
      this._penInkSubscription.unsubscribe();
    }
    if (!!this._mildepSubscription) {
      this._mildepSubscription.unsubscribe();
    }
    if (!!this._caseInReviewSubscription) {
      this._caseInReviewSubscription.unsubscribe();
    }
    if (!!this._caseInProposedSubscription) {
      this._caseInProposedSubscription.unsubscribe();
    }
    if (!!this._dscaSubscription) {
      this._dscaSubscription.unsubscribe();
    }
    if (!!this._updImplCaseSubscription) {
      this._updImplCaseSubscription.unsubscribe();
    }
    if (!!this._specialBillingAgreemengSubscription) {
      this._specialBillingAgreemengSubscription.unsubscribe();
    }
    if (!!this._amendModSubscription) {
      this._amendModSubscription.unsubscribe();
    }
    if (!!this._docInitiatorSubscription) {
      this._docInitiatorSubscription.unsubscribe();
    }
    if (!!this._s1DescriptionSubscription) {
      this._s1DescriptionSubscription.unsubscribe();
    }
    if (!!this._customerInformationSubscription) {
      this._customerInformationSubscription.unsubscribe();
    }
    if (!!this._reserveCaseIdentifierSubscription) {
      this._reserveCaseIdentifierSubscription.unsubscribe();
    }
    if (!!this._statusCompleteSubscription) {
      this._statusCompleteSubscription.unsubscribe();
    }
    if (!!this._pageNavSubscription) {
      this._pageNavSubscription.unsubscribe();
    }
    if (!!this._noprSubscription) {
      this._noprSubscription.unsubscribe();
    }
    this.destroyCalculateFMSOSubscription();
  }

  selectedShortcut() {
    let newCR: boolean = false;
    this.newCRSubscription = this.caseUIService.isNewCustomerRequest.subscribe((value) => {
      if (value) {
        newCR = value;
      }
    });
    switch (this.shortcutSelected) {
      case 'LL': {
        if (!newCR)
          this.openCaseLineList();
        break;
      }
      case 'CD': {
        if (!newCR)
          this.openCaseDetails();
        break;
      }
      case 'MS': {
        if (!newCR)
          this.openMilestone();
        break;
      }
      case 'RM':
      case 'AL':
      case 'NL': {
        if (!newCR)
          this.openCaseCommon();
        break;
      }
      case 'CR': {
        this.openCustRequest();
        break;
      }
    }

  }

  // Determine if we should skip the confirmation when you switch options.
  skipConfirmPrompt(pSelectedId: string): boolean {
    if (pSelectedId === "VC" || !this.caseUIService.optionSelectedUCAM.getValue()){
      return true;
    }
    return false;
  }


  selectOption(pSelectedId: string, pIsDisabled: boolean) {
    if (pIsDisabled) {
      return;
    }
    let skipChangeConfirmMessage: boolean = false;
    this.optionFlagNumber = this.caseUIService.optionSelectCounter.getValue();
    if (pSelectedId === 'emptyRow') {  //Dont show queue message if --Select Option-- is choosen
      this.optionFlagNumber = 0;
      skipChangeConfirmMessage = true;
      this.selected = this.optionsList[0].id;
    }
    // Check if previous option was selected
    if (this.caseUIService.checkOptionFlag && this.optionFlagNumber > 0 && !this.skipConfirmPrompt(pSelectedId)) {
      let msgQueue: Array<any> = [];
      MessageMgr.appendMsgToQueue(msgQueue,
        MessageMgr.displayInfoForQueue("Changes made on the previous option will be lost if not saved."));
      MessageMgr.showMessageQueue(msgQueue);
    }
    // Reset Option flags
    this.caseUIService.resetOptionFlags(this.currentPage);
    if (pSelectedId === 'UCPI') {
      this.caseUIService.milestoneAddService.next("PENINK");
      const editResponse: IEditResponseType = {
        ID: this.currentPage,
        editToggle: true
      };
      this.caseUIService.caseEditService.next(editResponse);
      this.caseUIService.optionSelectedUCPI.next(true);
      this.caseUIService.optionSelectedUCPIRegSub.next(true);
      this.caseUIService.skipValidation.next(true);
    }
    else if (pSelectedId === 'UCIR') {
      this.caseUIService.milestoneAddService.next("CWDREDIT");
      const editResponse: IEditResponseType = {
        ID: this.currentPage,
        editToggle: true
      };
      this.caseUIService.caseEditService.next(editResponse);
      this.caseUIService.optionSelectedUCIR.next(true);
      this.caseUIService.optionSelectedUCIRRegSub.next(true);
      this.caseUIService.skipValidation.next(true);
    }
    else if (pSelectedId === 'UCIP') {
      this.caseUIService.milestoneAddService.next("CWDPEDIT");
      const editResponse: IEditResponseType = {
        ID: this.currentPage,
        editToggle: true
      };
      this.caseUIService.caseEditService.next(editResponse);
      this.caseUIService.optionSelectedUCIP.next(true);
      this.caseUIService.skipValidation.next(true);
    }
    else if (pSelectedId === 'UCUI') {
      this.caseUIService.milestoneAddService.next("UPDTCASE");
    }
    else if (pSelectedId === 'UCAM') { //Amend Mod
      this.openAmendModDialog();
    }
    else if (pSelectedId === 'UCCC') { //Change Country
      this.openCountryDialog()
    }
    else if (pSelectedId === 'UCDI') { //Change Document Initiator
      this.caseUIService.setFieldDocInitatorDisabled(false);
      this.caseUIService.optionSelectedUCDI.next(true);
      this.caseUIService.skipValidation.next(true);
      this.caseUIService.saveInViewModeWhenOptionsMenuSelected.next(true); // Jira Card DSAMS-5689 06/2022 AKP
    }
    else if (pSelectedId === 'UCCS') { //Change S1 Description
      this.caseUIService.setFieldS1DescriptionDisabled(false);
      this.caseUIService.optionSelectedUCCS.next(true);
      this.caseUIService.skipValidation.next(true);
      this.caseUIService.saveInViewModeWhenOptionsMenuSelected.next(true); // Jira Card DSAMS-5689 06/2022 AKP
    }
    else if (pSelectedId === 'UCCI') { //Change Customer Information
      this.caseUIService.setFieldProcuringAgencyDisabled(false);
      this.caseUIService.setFieldSignatoryNameDisabled(false);
      this.caseUIService.optionSelectedUCCI.next(true);
      this.caseUIService.skipValidation.next(true);
      this.caseUIService.saveInViewModeWhenOptionsMenuSelected.next(true); // Jira Card DSAMS-5689 06/2022 AKP
    }
    else if (pSelectedId === 'UCDU') { //DSCA Update
      this.caseUIService.optionSelectedUCDU.next(true);
      this.caseUIService.skipValidation.next(true);
      this.caseUIService.saveInViewModeWhenOptionsMenuSelected.next(true); // Jira Card DSAMS-5689 06/2022 AKP
    }
    else if (pSelectedId === 'UCMP') { // Update Mgr
      this.caseUIService.optionSelectedUCMP.next(true);
      this.caseUIService.skipValidation.next(true);
      this.caseUIService.saveInViewModeWhenOptionsMenuSelected.next(true); // Jira Card DSAMS-5689 06/2022 AKP
    }
    // Update Manager 2
    else if (pSelectedId === 'UCM2') {
      this.caseUIService.setFieldLineManagerDisabled(false);
      this.caseUIService.optionSelectedUCM2.next(true);
      this.caseUIService.skipValidation.next(true);
    }
    else if (pSelectedId === 'UCMS') { // MILDEP signatory
      this.caseUIService.optionSelectedUCMS.next(true);
      this.caseUIService.skipValidation.next(true);
      this.caseUIService.saveInViewModeWhenOptionsMenuSelected.next(true); // Jira Card DSAMS-5689 06/2022 AKP
    }
    else if (pSelectedId === 'UCAI') { // Req. Allowed Ind.
      this.caseUIService.optionSelectedUCAI.next(true);
      this.caseUIService.skipValidation.next(true);
      this.caseUIService.saveInViewModeWhenOptionsMenuSelected.next(true); // Jira Card DSAMS-5689 06/2022 AKP
    }
    else if (pSelectedId === 'UCRC') { // Reserved Case Identifier
      this.openReserveDialog();
    }
    else if (pSelectedId === 'UCCN') { // Congressional Notification
      this.caseUIService.skipValidation.next(true);
      this.updateCongressionalNotifAmounts();
    }
    else if (pSelectedId === 'UCSB') { // Special Billing
      this.caseUIService.setcheckMarkSBLInd(!this.caseUIService.getcheckMarkSBLInd());
      this.setSBLCheckMarkInd();
      if (!this._caseUIServiceSubscription) {
        this._caseUIServiceSubscription = this.caseUIService.getCaseRelatedInfoValues().subscribe((value) => {
          this.caseRelatedInfoData = value;
        });
      }
      this.caseUIService.caseDetailData.subscribe((caseDetailData) => {
        this.aCaseVersionData = { ...caseDetailData };
      });
      this.updateCaseVersionSBLInd();
    }
    else if (pSelectedId === 'VC') {     // Validate Case
      skipChangeConfirmMessage = true;
      this.caseUIService.validateCaseSubscription.next();
    }
    else if (pSelectedId === 'NPOR') {
      skipChangeConfirmMessage = true;
      this.caseUIService.updateNopr.next();
    }
    // begin Jira card DSAMS-5233 03/2022 AKP
    else if (pSelectedId === 'UCRA') { //Refresh Amend/Mod
      skipChangeConfirmMessage = true;
      this.openAmendModRefreshDialog();
    }
    // end Jira card DSAMS-5233 03/2022 AKP
    this.isCalculateFMSOOptionSelected(pSelectedId);
    if (!skipChangeConfirmMessage) {
      this.optionFlagNumber++;
      this.caseUIService.optionSelectCounter.next(this.optionFlagNumber);
    }
  }

  // /* Open the Pen & Ink Milestone Comment Dialog */
  // openMilestoneCommentDialog(pMilestoneId: string): any {
  //   this.dialog.open(MilestoneCommentComponent, {
  //     width: '40em',
  //     height: '40em',
  //     data: {
  //       caseId: this.caseId,
  //       versionId: this.caseVersionId,
  //       milestoneId: pMilestoneId
  //     }
  //   });
  // }

  subscribeToEditToggle() {
    if (!this._editSubscription) {
      this._editSubscription = this.caseUIService
        .caseEditService
        .subscribe((pResponse: IEditResponseType) => {
          if (pResponse && pResponse.ID === CaseShortcutsComponent.CASE_LINE_EDITOR_STR) {
            this.isEditToggleDisabled = !pResponse.editToggle;
          }
        },
          err => {
            CaseUtils.ReporError("in Line Detail responding to edit toggle");
          }
        );
    }
  }

  //processing the update of Congressional Notification amounts
  updateCongressionalNotifAmounts() {
    this.isLoading.next(true);
    this.caseUIService.caseDetailData.subscribe((caseDetailData) => {
      this.aCaseVersionData = { ...caseDetailData };
    });
    this.aCaseLineData = {
      case_ID: this.aCaseVersionData.case_ID,
      working_CASE_ID: this.aCaseVersionData.case_ID,
      working_CASE_VERSION_ID: this.aCaseVersionData.case_VERSION_ID,
    }
    this.caseRestService.updateCongNotifAmounts(this.aCaseLineData).subscribe(
      (_value) => {
        this.isLoading.next(false);
        MessageMgr.swalFire({
          text: 'Congressional Notification amounts have been updated for this case version',
          icon: 'success',
          showConfirmButton: false,
          timer: 4000,
          width: 300
        })
      },
      err => {
        console.log('Error updating congressional amounts indicator', err);
        this.isLoading.next(false);
        MessageMgr.swalFire({
          text: 'Failed to update data',
          icon: 'error',
          showConfirmButton: false,
          timer: 4000,
          width: 300
        })
      })
    this.isLoading.next(false);
  }

  //setting up the check mark indicator
  setSBLCheckMarkInd() {
    for (var i = this.optionsList.length - 1; i >= 0; --i) {
      if (this.optionsList[i].id == "UCSB") {
        this.optionsList[i].checkMark = this.caseUIService.getcheckMarkSBLInd();
      }
    }
  }

  //processing the update of SBL data
  saveSBLData() {
    this.caseRestService.updateSBLInd(this.aCaseVersionData).subscribe(
      (_value) => {
        this.isLoading.next(false);
        MessageMgr.swalFire({
          text: 'Data was updated successful',
          icon: 'success',
          showConfirmButton: false,
          timer: 2000,
          width: 300
        })
      },
      err => {
        console.log('Error updating SBL indicator', err);
        this.isLoading.next(false);
        MessageMgr.swalFire({
          text: 'Failed to save data',
          icon: 'error',
          showConfirmButton: false,
          timer: 2000,
          width: 300
        })
      })
    this.isLoading.next(false);
  }

  //processing SBL data
  updateCaseVersionSBLInd() {
    var skipSave: boolean = false;
    //set up data for update
    this.aCaseVersionData.sbl_IN = this.caseUIService.getcheckMarkSBLInd();
    this.aCaseVersionData.status = DsamsConstants.ENT_CHANGED;
    //eliminate child database relationship as they are not applicable
    //for updating just the SBL indicator
    this.aCaseVersionData.caseDistributionListList = null;
    this.aCaseVersionData.caseSaleTermList = null;
    this.aCaseVersionData.caseVersionMilestoneList = null;
    this.aCaseVersionData.caseVersionWaiverCaseIdList = null;
    this.aCaseVersionData.caseVersionNotificationList = null;
    this.aCaseVersionData.businessRuleMap = null;
    this.aCaseVersionData.theCaseId.status = DsamsConstants.ENT_UNCHANGED;

    if (!this.aCaseVersionData.sbl_IN) {
      if (this.aCaseVersionData.theCaseId.theCustomerOrganizationId.sbl_IN) {
        MessageMgr.swalFire({
          //text: MessageMgr.getMesssage('W017').messageText,
          text: "This Country has a Special Billing Agreement",
          icon: 'info',
          showConfirmButton: true,
          timer: 20000,
          width: 400
        })
      }
    }
    else {
      if (!this.aCaseVersionData.theCaseId.theCustomerOrganizationId.sbl_IN) {
        MessageMgr.swalFire({
          //text: MessageMgr.getMesssage('W018').messageText,
          icon: 'info',
          text: "This Country does not have a Special Billing Agreement",
          showConfirmButton: true,
          timer: 20000,
          width: 400
        })
      }
    }
    this.isLoading.next(true);
    setTimeout(() => {
      this.saveSBLData();
    }, 5000)
  }

  /* Open the Amend/Mod Dialog */
  openAmendModDialog(): any {
    if (this.env === 'Development') {
      if (this.caseVerTypeCd === 'A' || this.caseVerTypeCd === 'M') {
        this.dialog.open(CaseAmendModNumberComponent, {
          width: '25em',
          height: '25em',
          data: {
            typeCd: this.caseVerTypeCd, verNumId: this.caseVerNumId,
            caseId: this.caseId, versionId: this.caseVersionId
          }
        });
      }
    }
  }

  // begin Jira card DSAMS-5233 03/2022 AKP
  /* Open Amend/Mod Refresh popup*/
  openAmendModRefreshDialog(): any {
    this.dialog.open(CaseAmendModRefreshComponent, {
      width: '25em',
      height: '25em',
      data: {
        caseId: this.caseId, versionId: this.caseVersionId
      }
    })
  }
  // end Jira card DSAMS-5233 03/2022 AKP

  /* Open the change country Dialog */
  openCountryDialog(): any {
    if (this.env === 'Development') {
      if (this.caseVerTypeCd === 'B') {
        this.dialog.open(CaseCountryComponent, {
          width: '25em',
          height: '25em',
          data: {
            countryCodes: [...this.refCustomerOrganizationList],
            countryCode: this.countryCode
          }
        });
      }
    }
  }


  /* Reserve Case Identifier */
  openReserveDialog(): any {
    this.caseUIService.caseDetailData.subscribe((caseDetailData) => {
      this.aCaseVersionData = { ...caseDetailData };
    });
    this.caseUIService.getReserveCaseIdentifierData().subscribe((value) => {
      this.aCaseUsedUserData = value;
    });

    const dialogRef = this.dialog.open(CaseReserveComponent, {
      width: '30em',
      height: '25em',
      data: {
        countryCodes: [...this.refCustomerOrganizationList],
        countryCode: this.aCaseVersionData.theCaseId.theCustomerOrganizationId.customer_ORGANIZATION_ID,
        implAgencyId: !this.aCaseUsedUserData ? this.aCaseVersionData.theCaseId.implementing_AGENCY_ID : this.aCaseUsedUserData.implementing_AGENCY_ID,
        caseDesignator: !this.aCaseUsedUserData ? this.aCaseVersionData.theCaseId.case_DESIGNATOR_CD : this.aCaseUsedUserData.case_DESIGNATOR_CD
      }
    });
    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        //if (!!this.aCaseVersionData.theCaseId.theCustomerOrganizationId) {
        if (this.aCaseVersionData.theCaseId.theCustomerOrganizationId.customer_TYPE_CD === 'PS') {
          if (this.aCaseUsedUserData.pseudo_IN === false) {
            for (let i = 0; i < this.optionsList.length; i++) {
              if (this.optionsList[i].id === 'UCRC')
                this.optionsList.splice(i, 1); // Remove Reserve Identifier from the options menu so it can't be used again
            }
          }
        }
        //}
      }
    });
  }

  /************* Shortcuts for opening Case Details, Line, Note, Remarks, Attachment pages ************/
  //begin Jira DSAMS-5390 04/22 DH - updated all shortcuts to primarily utilize passing input values
  /* Navigate to Line List from Details Page */
  openCaseLineList() {
    if (!this.caseRelatedInfoData) {
      this.caseRelatedInfoData = {
        case_ID: this.caseId,
        case_VERSION_ID: this.caseVersionId.toString(),
        working_CASE_ID: this.caseId ? this.caseId : this.caseRelatedInfoData.case_ID,
        working_CASE_VERSION_ID: this.caseVersionId ? +this.caseVersionId : + this.caseRelatedInfoData.case_VERSION_ID,
        wm_CASE_VERSION_TYPE_CD: this.caseVerTypeCd,
      };
    } else {
      this.caseRelatedInfoData.case_ID = this.caseId;
      this.caseRelatedInfoData.case_VERSION_ID = this.caseVersionId.toString();
      this.caseRelatedInfoData.working_CASE_ID = this.caseId ? this.caseId : this.caseRelatedInfoData.case_ID;
      this.caseRelatedInfoData.working_CASE_VERSION_ID = this.caseVersionId ? +this.caseVersionId : + this.caseRelatedInfoData.case_VERSION_ID;
      this.caseRelatedInfoData.wm_CASE_VERSION_TYPE_CD = this.caseVerTypeCd;
    }

    let aCaseVersionInfoData: LinkCaseDataIface = LinkCaseDataClass.getTheLinkCaseDataObject(localStorage.getItem(LinkCaseDataClass.linkCaseVersionInfoData));
    let theUserCaseId = this.userCaseId ? this.userCaseId : aCaseVersionInfoData.user_CASE_ID;
    if (!this.caseLineRelatedInfoData) {
      let aCase_VERSION_STATUS_CD = this.caseVersionStatusCd ? this.caseVersionStatusCd : aCaseVersionInfoData.case_VERSION_STATUS_CD;
      this.caseLineRelatedInfoData = {
        case_CUSTOMER_ORGANIZATION_ID: this.countryCode,
        case_VERSION_TYPE_CD: this.caseVerTypeCd,
        security_ASSISTANCE_PROGRAM_CD: this.saProgram,
        case_VERSION_NUMBER_ID: this.caseVerNumId,
        implementing_AGENCY_ID: theUserCaseId.substring(3, 1),
        customer_REQUEST_ID: 0,
        case_VERSION_STATUS_CD: aCase_VERSION_STATUS_CD
      };
    }
    this.caseLineRelatedInfoData.user_CASE_ID = theUserCaseId;
    this.caseUIService.setCaseRelatedInfoValues(this.caseRelatedInfoData);
    this.caseUIService.setCaseLineRelatedInfoValues(this.caseLineRelatedInfoData);
    this.dataSharingService.caseSelection.next(DsamsConstants.REQUEST_CLOSE_MENU);
    this.router.navigate(['/case/line-dashboard', '0', 'Line']);
  }

  /* Attachment, Remarks, Note List */
  openCaseCommon() {
    let aCaseVersionInfoData: LinkCaseDataIface = LinkCaseDataClass.getTheLinkCaseDataObject(localStorage.getItem(LinkCaseDataClass.linkCaseVersionInfoData));
    this.caseRelatedInfoData = {
      case_ID: this.caseId,
      case_VERSION_ID: this.caseVersionId.toString(),
      working_CASE_ID: this.caseId ? this.caseId : this.caseRelatedInfoData.case_ID,
      working_CASE_VERSION_ID: this.caseVersionId ? this.caseVersionId : +this.caseRelatedInfoData.case_VERSION_ID,
      wm_CASE_VERSION_TYPE_CD: this.caseVerTypeCd,
      case_MASTER_STATUS_CD: aCaseVersionInfoData.case_MASTER_STATUS_CD ? aCaseVersionInfoData.case_MASTER_STATUS_CD : '',
    };

    let aCase_VERSION_STATUS_CD = this.caseVersionStatusCd ? this.caseVersionStatusCd : aCaseVersionInfoData.case_VERSION_STATUS_CD;
    let theUserCaseId = this.userCaseId ? this.userCaseId : aCaseVersionInfoData.user_CASE_ID;
    this.caseLineRelatedInfoData = {
      case_CUSTOMER_ORGANIZATION_ID: this.countryCode,
      case_VERSION_STATUS_CD: aCase_VERSION_STATUS_CD ? aCase_VERSION_STATUS_CD : aCaseVersionInfoData.case_VERSION_STATUS_CD,
      security_ASSISTANCE_PROGRAM_CD: this.saProgram,
      user_CASE_ID: theUserCaseId,
      case_VERSION_NUMBER_ID: this.caseVerNumId,
      case_VERSION_TYPE_CD: this.caseVerTypeCd ? this.caseVerTypeCd : this.caseLineRelatedInfoData.case_VERSION_TYPE_CD,
      implementing_AGENCY_ID: theUserCaseId.substring(2, 3),
      customer_REQUEST_ID: 0,
    };

    this.caseUIService.setCaseRelatedInfoValues(this.caseRelatedInfoData);
    this.caseUIService.setCaseLineRelatedInfoValues(this.caseLineRelatedInfoData);
    if (this.shortcutSelected === 'AL')
      this.router.navigate(['/case/attachments-dashboard']);
    if (this.shortcutSelected === 'NL')
      this.router.navigate(['/case/note-dashboard']);
    if (this.shortcutSelected === 'RM')
      this.router.navigate(['/case/remarks-dashboard']);
  }

  /* Navigate to the Case Details Page from the Line List */
  openCaseDetails() {
    const caseRequestParamsType: CaseRequestParamsType = {
      caseId: this.caseId,
      caseVersionId: this.caseVersionId,
      customerOrganizationId: this.countryCode,
      caseVersionTypeCd: this.caseVerTypeCd,
      securityAssistanceProgramCd: this.saProgram,
      implementingAgencyId: this.caseLineRelatedInfoData.implementing_AGENCY_ID,
      customerRequestId: this.caseLineRelatedInfoData.customer_REQUEST_ID,
      isEditable: false
    };
    this.caseUIService.caseDetailSelected.next(caseRequestParamsType);
    this.dataSharingService.backToSearchSummary.next(false);
    this.dataSharingService.backToCaseDetail.next(true);
    this.router.navigate(['/case/case-dashboard']);
  }

  openCustRequest() {
    if (!this.caseRelatedInfoData) {
      this.caseRelatedInfoData = {
        case_ID: this.caseId,
        case_VERSION_ID: this.caseVersionId.toString(),
        working_CASE_ID: this.caseId ? this.caseId : this.caseRelatedInfoData.case_ID,
        working_CASE_VERSION_ID: this.caseVersionId ? this.caseVersionId : +this.caseRelatedInfoData.case_VERSION_ID,
        wm_CASE_VERSION_TYPE_CD: this.caseVerTypeCd,
      };
    } else {
      this.caseRelatedInfoData.case_ID = this.caseId;
      this.caseRelatedInfoData.case_VERSION_ID = this.caseVersionId.toString();
      this.caseRelatedInfoData.working_CASE_ID = this.caseId ? this.caseId : this.caseRelatedInfoData.case_ID;
      this.caseRelatedInfoData.working_CASE_VERSION_ID = this.caseVersionId ? this.caseVersionId : +this.caseRelatedInfoData.case_VERSION_ID;
      this.caseRelatedInfoData.wm_CASE_VERSION_TYPE_CD = this.caseVerTypeCd;
    }
    if (!this.caseLineRelatedInfoData) {
      this.caseLineRelatedInfoData = {
        case_CUSTOMER_ORGANIZATION_ID: this.countryCode,
        case_VERSION_TYPE_CD: this.caseVerTypeCd,
        security_ASSISTANCE_PROGRAM_CD: this.saProgram,
        user_CASE_ID: this.userCaseId,
        case_VERSION_NUMBER_ID: this.caseVerNumId,
        implementing_AGENCY_ID: this.userCaseId.substring(3, 1)
        // customer_REQUEST_ID: 0  // Probably not needed for case line.
      };
    }
    this.caseUIService.setCaseRelatedInfoValues(this.caseRelatedInfoData);
    this.caseUIService.setCaseLineRelatedInfoValues(this.caseLineRelatedInfoData);
    this.dataSharingService.caseSelection.next(DsamsConstants.REQUEST_CLOSE_MENU);

    if (this.currentPage !== DsamsConstants.PAGE_CASE_DETAIL) {
      if (this.caseLineRelatedInfoData.customer_REQUEST_ID > 0) {
        this.caseUIService.setCaseCustReqId(this.caseLineRelatedInfoData.customer_REQUEST_ID);
      } else {
        this.caseUIService.setCaseCustReqId(0);
      }
    }
    this.caseUIService.submitBreadcrumbTitleChangeRequest("Customer Request");
    this.router.navigate(['/customer-request/WP005']);
  }
  //end Jira DSAMS-5390 04/22 DH - updated all shortcuts to utilize passing input values
  openMilestone() {
    this.router.navigate(['/case/milestone-dashboard'], 
                         { queryParams: {serviceDbId:CaseUtils.getServiceDatabaseId(), caseId:this.caseId, caseVersionId:this.caseVersionId,
                                         typeWithNumber:this.caseVerTypeCd+this.caseVerNumId, userCaseId:this.userCaseId} });
  }

  filterCurrentPage() {
    let pageId: string;
    switch (this.currentPage) {
      case 'PAGE_CASE_LINE':
        pageId = 'LL';
        break;
      case 'PAGE_CASE_DETAIL':
        pageId = 'CD';
        break;
      case 'PAGE_CASE_REMARKS':
        pageId = 'RM';
        break;
      case 'PAGE_CASE_ATTACHMENTS':
        pageId = 'AL';
        break;
      case 'PAGE_CASE_NOTE_LIST':
        pageId = 'NL';
        break;
      case 'PAGE_CUSTOMER_REQUEST':
        pageId = 'CR';
        break;
      case 'PAGE_CASE_MILESTONE':
        pageId = 'MS';
        break;
    }
    this.shortcutsList = this.shortcutsList.filter(slist => { return slist.id !== pageId });
  }

  //begin DSAMS-1849 DH 03/22
  isCalculateFMSOOptionSelected(pSelectedId: string) {
    if (!!this.caseRelatedInfoData && pSelectedId === 'FMSO') {
      this.caseUIService.getCaseLineInfoValues().pipe(take(1)).subscribe(data => {
        let aCaseLineData = data;
        aCaseLineData.total_ABOVE_LINE_COST_AM = CaseUtils.unformatCurrency(aCaseLineData.total_ABOVE_LINE_COST_AM).toString();
        aCaseLineData.stock_ON_HAND_COST_AM = CaseUtils.unformatCurrency(aCaseLineData.stock_ON_HAND_COST_AM).toString();
        aCaseLineData.stock_ON_ORDER_COST_AM = CaseUtils.unformatCurrency(aCaseLineData.stock_ON_ORDER_COST_AM).toString();
        this.caseRestService.calculateFMSOAmounts(aCaseLineData).pipe(take(1),
          map((result) => {
            if (!!result) {
              aCaseLineData.isDataChanged = true;
              aCaseLineData.total_ABOVE_LINE_COST_AM = formatCurrency(parseFloat(result.total_ABOVE_LINE_COST_AM), 'en', '$');
              aCaseLineData.stock_ON_HAND_COST_AM = result.stock_ON_HAND_COST_AM;
              aCaseLineData.stock_ON_ORDER_COST_AM = result.stock_ON_ORDER_COST_AM;
            }
          })).subscribe()
      });
    }
  }

  subscribeToCalculateFMSOOption() {
    this._calculateFMSOSubscription = this.caseUIService.getEnableCalculateFMSOOption()
      .subscribe((value) => {
        this.spliceFromOptionsList("FMSO");
        if (value) this.pushToOptionsList('FMSO', 'Calculate FMSO Stock', false);
      });
  }

  subscribeToDisableCalculateFMSOOption() {
    this._disableCalculateFMSOSubscription = this.caseUIService.getDisableCalculateFMSOOption()
      .subscribe((value) => {
        if (value) this.spliceFromOptionsList("FMSO");
      });
  }

  destroyCalculateFMSOSubscription() {
    if (!!this._calculateFMSOSubscription) {
      this._calculateFMSOSubscription.unsubscribe();
    }
    if (!!this._disableCalculateFMSOSubscription) {
      this._disableCalculateFMSOSubscription.unsubscribe();
    }
  }
  //end DSAMS-1849 DH 03/22
}