import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CaseShortcutsComponent } from './case-shortcuts.component';

describe('CaseShortcutsComponent', () => {
  let component: CaseShortcutsComponent;
  let fixture: ComponentFixture<CaseShortcutsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CaseShortcutsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CaseShortcutsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
