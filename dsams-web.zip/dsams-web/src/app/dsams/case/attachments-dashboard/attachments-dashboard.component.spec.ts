import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AttachmentsDashboardComponent } from './attachments-dashboard.component';

describe('AttachmentsDashboardComponent', () => {
  let component: AttachmentsDashboardComponent;
  let fixture: ComponentFixture<AttachmentsDashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AttachmentsDashboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AttachmentsDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
