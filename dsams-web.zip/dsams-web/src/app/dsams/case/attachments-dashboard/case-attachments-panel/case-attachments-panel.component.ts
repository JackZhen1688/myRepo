import { Component, OnInit, OnDestroy, ViewChild, ChangeDetectorRef } from '@angular/core';
import { MatTableDataSource } from '@angular/material';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { MdePopoverTrigger } from '@material-extended/mde';
import { DsamsConstants } from '../../../dsams.constants';
import { CaseUIService } from '../../services/case-ui-service';
import { BehaviorSubject, Subscription } from 'rxjs';
import { IEditResponseType } from '../../model/edit-response-type';
import { CaseUtils } from '../../utils/case-utils';
import { DatePipe } from '@angular/common';
import { FormBuilder, FormControl } from '@angular/forms';
import { FieldDisabledMap } from '../../model/field-disabled-map';
import { TextAreaComponent } from '../../dialogs/text-area/text-area.component';
import { DsamsMethodsService } from 'src/app/dsams/services/dsams-methods.service';
import { attachmentsDto } from '../model/dto/case-attachments-dto';
import { attachmentsLineDto } from "../model/dto/case-attachments-line-dto";
import { formatDate } from '@angular/common';
import { CaseRestfulService } from '../../services/case-restful.service';
import { DsamsRestfulService } from 'src/app/dsams/services/dsams-restful.service';
import { MessageMgr } from '../../validation/message-mgr';
import { ISelectOptions } from 'src/app/dsams/interfaces/i-select-options';
import { ifaceCaseLineData, ifaceCaseLineEntity } from '../../model/case-line-model';
import { CaseLineRelatedInfoType } from '../../model/case-line-related-info-type';
import { CaseRelatedInfoType } from '../../model/case-related-info-type';
import { SweetAlertResult } from 'sweetalert2';
import { NoteUtils } from '../../note-dashboard/note-utils';
import { CdkDragDrop, moveItemInArray } from '@angular/cdk/drag-drop';

import { CaseCommonValidator } from '../../validation/case-common-validator';
import { LineUtils } from '../../line-dashboard/line-utils';
import { DialogMessageListComponentTc } from 'src/app/dsams/utilitis/dialogs/dialog-message-list-tc/dialog-message-list-tc.component';
import { MessageType } from 'src/app/dsams/enums/user-message.enum';
import { attachmentsModel, prepareCaseAttachmentDataForSave, prepareCaseAttachmentLineDataForSave, prepareCaseAttachmentTXTDataForSave } from '../model/case-attachments';
import { ErrorParameter } from 'src/app/dsams/entities/specialEntities/error-parameter.model';
import { DsamsUserMessageService } from 'src/app/dsams/services/dsams-user-message.service';
import { attachmentsLineModel } from '../model/case-attachments-line';

import { DateValidator } from '../../validation/date-validator';

export class assoRelCaseConstants {
  static readonly iconImageArrowUp = "arrow_drop_up";
  static readonly iconImageArrowDown = "arrow_drop_down";
}

export interface theAssoLineArray {
  iconImg: string;
  lineSubline: string;
  lineStatus: string;
  masl: string;
  quantity: string;
  unitOfIssue: string;
  caseMasterLineId?: string;
}

export interface caseMasterlineDto {
  case_ID?: number,
  case_MASTER_LINE_ID?: number,
  wm_USER_CASE_LINE_NUMBER_ID?: string,
  wm_USER_CASE_SUBLINE_TX?: string,
  wm_PARENT_CASE_ID?: number,
  wm_PARENT_CASE_MASTER_LINE_ID?: number,
  virtualSublineList?: string[];
}

@Component({
  selector: 'app-case-attachments-panel',
  templateUrl: './case-attachments-panel.component.html',
  styleUrls: ['./case-attachments-panel.component.css'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0', minHeight: '0', display: 'none' })),
      state('expanded', style({ height: '*' })),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
  providers: [DatePipe]
})
export class CaseAttachmentsPanelComponent implements OnInit {

  date = this.fb.control(new Date());
  dates = this.fb.array([
    this.fb.control(new Date())
  ]);

  private readonly DSAMS_ATTACHMENT: string = "DS";
  private readonly NON_DSAMS_ATTACHMENT: string = "ND";

  validAttachmentType: ISelectOptions[] = [
    { value: this.DSAMS_ATTACHMENT, viewValue: 'DS' },
    { value: this.NON_DSAMS_ATTACHMENT, viewValue: 'ND' }
  ];

  isDeleteDisabled: boolean[] = [];

  /**
   * Editability fields
   */
  isPanelEditable: boolean = false;
  private _fieldDisabledMap: FieldDisabledMap = {};
  private editSubscription: Subscription = null;
  private newCRSubscription: Subscription = null;
  private revertEditSubscription: Subscription = null;
  private originalPanelData: attachmentsDto;
  private saveCompleteSubscription: Subscription = null;
  private _ucirSubscription: Subscription = null;
  private _penInkSubscription: Subscription = null;
  private _caseInProposedSubscription: Subscription = null;

  @ViewChild(MdePopoverTrigger, { static: true }) trigger: MdePopoverTrigger;

  /* Attachments Table */
  dataSourceAttachmentTable = new MatTableDataSource<attachmentsDto>();
  dataSourceAttachmentListData: attachmentsDto[] = [];
  attachmentsColumnsToDisplayItems = ['AttachmentsNo', 'AttachmentsType', 'Status', 'OfficialTitle', 'AttachmentsText', 'LastUpdateDate', 'NoOfPages', 'Restate', 'DeleteRow'];
  attachmentsColumnsToDisplayFooter = ['AddRow'];
  dataLineAssociationsTable = new MatTableDataSource<attachmentsLineDto>();
  dataLineAssociationsListData: attachmentsLineDto[] = [];
  expandedElement: null;
  displaySubcolumns = ['LineSubline', 'LineStatus', 'Masl', 'Quantity', 'UnitOfIssue', 'DeleteRow'];
  displaySubcolumnsFooter = ['AddRow'];
  isLoading: BehaviorSubject<boolean> = new BehaviorSubject(false);
  theCustomerTypeCode: string;
  isDataReadyForSave: boolean = false;
  private saveOnEditToggleSubscription: Subscription = null;
  private caseUIServiceSubscription: Subscription = null;
  private popupActivityPreActSubscription: Subscription = null;
  private _caseUIServiceSubscription1: Subscription = null;
  private _caseUIServiceSubscription2: Subscription = null;
  private _caseAttachmentDataSubscription

  caseRelatedInfoData: CaseRelatedInfoType;
  caseLineRelatedInfoData: CaseLineRelatedInfoType;
  aCaseUserId: any;
  theInitialCaseLineInfoData: ifaceCaseLineData;
  caseVersionIdNumber: number;

  //attachmentsPanelData: attachmentsDto[] = [];
  todaysDate: Date;
  emptyString: string = '';
  selected: any[] = [];

  currentlySelectedRowNum: number = 0;
  private _prevCaseIndex: number = -1;

  //Subscription/Observable variables
  private _textIndex: number = -1;

  // Attachment Lines
  theCaseLineListArray: caseMasterlineDto[] = [];
  theCaseLineListTempArray: caseMasterlineDto[] = [];
  theAssoLineArrayForLookup: theAssoLineArray[] = [];
  varSaveTXT: any;
  varExpandedRecordID: any;
  theLineSublineValidator: ifaceCaseLineEntity[] = [];
  theLineAttchNoValidator: attachmentsModel[] = [];
  theCaseLineListTemp: ifaceCaseLineEntity;
  varLine: any;
  theRelatedAttachmentListTemp: attachmentsLineModel;

  constructor(private caseUIService: CaseUIService,
    private changeDetectorRef: ChangeDetectorRef,
    private fb: FormBuilder,
    private caseRestService: CaseRestfulService,
    private dsamsRestfulService: DsamsRestfulService,
    protected messageService: DsamsUserMessageService,
    public dsamsDialogMsgService: DsamsMethodsService) { }

  //Text Area
  private textAreaSubscription: Subscription = null;

  // Renumber Attachments
  previousDragRowIndex: number = 0; //set default to zero to prevent hung on drag
  isAttachmentBeingMoved: boolean = false;
  oldNoteNumber: number = null;
  newNoteNumber: number = null;

  // Track which attachment was expanded
  selectedAttachmentNumberExpanded: number = -1;

  ngOnInit() {
    this.subscribeToEditService();
    this.isAttachmentBeingMoved = false;

    if (!this._caseUIServiceSubscription1) {
      this._caseUIServiceSubscription1 = this.caseUIService.getCaseLineRelatedInfoValues().subscribe((value) => {
        this.caseLineRelatedInfoData = value;
      });
    }

    if (!this._caseUIServiceSubscription2) {
      this._caseUIServiceSubscription2 = this.caseUIService.getCaseRelatedInfoValues().subscribe((value) => {
        this.caseRelatedInfoData = value;
      });
    }

    this.populateAttachmentData();

    this.todaysDate = new Date();

    this.subscribeToTextAreaDialog();
    this.subscribeToTextAreaDialogForOfficialTitle();

    this.getDataForLineDetails();
    this.subscribeToSaveOnEditToggle();
  }

  ngAfterViewChecked() {
    this.changeDetectorRef.detectChanges();
  }

  ngOnDestroy() {
    if (!!this.caseUIServiceSubscription) {
      this.caseUIServiceSubscription.unsubscribe();
    }
    if (!!this.editSubscription) {
      this.editSubscription.unsubscribe();
    }
    if (!!this.newCRSubscription) {
      this.newCRSubscription.unsubscribe();
    }
    if (!!this.revertEditSubscription) {
      this.revertEditSubscription.unsubscribe();
    }
    if (!!this.saveCompleteSubscription) {
      this.saveCompleteSubscription.unsubscribe();
    }
    if (this._caseUIServiceSubscription1) {
      this._caseUIServiceSubscription1.unsubscribe();
      this._caseUIServiceSubscription1 = null;
    }
    if (this._caseUIServiceSubscription2) {
      this._caseUIServiceSubscription2.unsubscribe();
      this._caseUIServiceSubscription2 = null;
    }
    if (!!this._ucirSubscription) {
      this._ucirSubscription.unsubscribe();
      this._ucirSubscription = null;
    }
    if (!!this._penInkSubscription) {
      this._penInkSubscription.unsubscribe();
      this._penInkSubscription = null;
    }
    if (!!this._caseInProposedSubscription) {
      this._caseInProposedSubscription.unsubscribe();
      this._caseInProposedSubscription = null;
    }
    if (!!this.saveOnEditToggleSubscription) {
      this.saveOnEditToggleSubscription.unsubscribe();
      this.saveOnEditToggleSubscription = null;
    }
    this.clobberLockSession();
  }

  // Subscribe to Save on Edit Toggle
  subscribeToSaveOnEditToggle() {
    this.saveOnEditToggleSubscription = this.caseUIService.isEditOnSaveAttachmentConfirmed.subscribe(isSaveConfirmed => {
      if (isSaveConfirmed) { this.onClickSaveCaseAttachmentData() }
    });
  }

  /* Change Restate to an R */
  changeToRestate(index: number) {
    this.dataSourceAttachmentListData[index].change_ACTION_CD = 'R';
    if (this.dataSourceAttachmentListData[index].status == DsamsConstants.ENT_UNCHANGED.toString()) {
      this.dataSourceAttachmentListData[index].status = DsamsConstants.ENT_CHANGED.toString();
    }

    this.dataSourceAttachmentTable = new MatTableDataSource(this.dataSourceAttachmentListData);
    this.dataSourceAttachmentTable._updateChangeSubscription();
    this.enableOrDisableFields();
  }

  /* This procedure checks the returned result value from the popover Yes/No dialog window. */
  yesButtonOnClick(isDeleteConfirmed: any, rowElement: any) {
    if (isDeleteConfirmed)
      this.deleteItem(rowElement);
  }

  /* Delete a row from the Attachment Grid */
  deleteItem(rowElement: any) {
    let rowIndex = this.dataSourceAttachmentListData.indexOf(rowElement);
    if (this.dataSourceAttachmentListData[rowIndex].status === DsamsConstants.ENT_NEW.toString()) {
      this.dataSourceAttachmentListData.splice(rowIndex, 1);
      this.dates.removeAt(rowIndex);
    }
    else {
      if (this.dataSourceAttachmentListData[rowIndex].change_ACTION_CD == 'A') {
        this.dataSourceAttachmentListData[rowIndex].status = DsamsConstants.ENT_DELETED.toString()
      }
      else {
        this.dataSourceAttachmentListData[rowIndex].change_ACTION_CD = 'D';
        this.dataSourceAttachmentListData[rowIndex].status = DsamsConstants.ENT_CHANGED.toString()
      }
    }
    this.dataSourceAttachmentTable = new MatTableDataSource(this.dataSourceAttachmentListData);
    this.dataSourceAttachmentTable._updateChangeSubscription();
    this.enableOrDisableFields();
  }

  /* Add Button in the Attachment Grid */
  addItem(): void {
    let lastAtchNo: number = 0;
    let attAddIndex: number = 0;
    let todayDateString: string = DateValidator.dateToString(this.todaysDate);
    if (!!this.dataSourceAttachmentListData) {
      for (let i = 0; i < this.dataSourceAttachmentListData.length; i++) {
        if (this.dataSourceAttachmentListData[i].case_ATTACHMENT_NUMBER_ID > lastAtchNo) {
          lastAtchNo = this.dataSourceAttachmentListData[i].case_ATTACHMENT_NUMBER_ID;
        }
      }
      attAddIndex = this.dataSourceAttachmentListData.length;
    }

    const anItemObject: attachmentsDto =
    {
      case_ID: this.caseRelatedInfoData.case_ID,
      case_VERSION_ID: this.caseRelatedInfoData.case_VERSION_ID,
      attachment_LAST_UPDATED_DT: todayDateString,
      case_ATTACHMENT_NUMBER_ID: (lastAtchNo + 1),
      case_ATTACHMENT_ID: 0,
      case_ATTACHMENT_PAGE_QY: null,
      case_ATTACHMENT_TX: '',
      case_ATTACHMENT_TYPE_CD: 'DS',
      status: DsamsConstants.ENT_NEW.toString(),
      isDataChanged: false,
      iconImg: 'arrow_drop_down',
      versionTypeData: null,
      change_ACTION_CD: 'A',
      isFieldDisabled: { ['case_ATTACHMENT_NUMBER_ID']: false },
      isAtchNoDisabled: false,
      isAtchTextDisabled: false,
      isAtchTypeDisabled: false,
      isRestateDisabled: true,
      isAtchPageDisabled: true,
      caseLineAttachmentRelatedAttachmentIdList: []
    };
    // if the list is intially empty
    if (this.dataSourceAttachmentListData == null) {
      this.dataSourceAttachmentListData = [];
    }

    this.dates.insert(attAddIndex, new FormControl(todayDateString));

    this.dataSourceAttachmentListData.push(anItemObject);
    this.dataSourceAttachmentTable = new MatTableDataSource(this.dataSourceAttachmentListData);
    //refresh the table
    this.dataSourceAttachmentTable._updateChangeSubscription();

  }

  /* Add Button in the Line Grid */
  addLineItem(element: any, event: any): void {
    this.theCaseLineListTemp =
    {
      wm_USER_CASE_LINE_NUMBER_ID: '',
      change_ACTION_CD: 'A',
      military_ARTICLE_SERVICE_CD: '',
      case_LINE_ITEM_QY: '',
      issue_UNIT_CD: '',
      wm_USER_CASE_SUBLINE_TX: ''
    };

    const anItemObject: attachmentsLineDto =
    {
      status: DsamsConstants.ENT_NEW.toString(),
      isDataChanged: true,

      iconImg: 'arrow_drop_down',
      lineSubline: '',
      lineStatus: '',
      masl: '',
      quantity: '',
      unitOfIssue: '',

      related_CASE_ID: this.caseRelatedInfoData.case_ID,
      related_CASE_VERSION_ID: this.caseRelatedInfoData.case_VERSION_ID,
      related_CASE_ATTACHMENT_ID: 0,

      theCaseLine: this.theCaseLineListTemp
    };
    // if the list is intially empty
    if (this.dataLineAssociationsListData == null) {
      this.dataLineAssociationsListData = [];
    }

    // Populate line drop downs
    this.theCaseLineListArray = [];
    this.getLineDropdownList(this.caseRelatedInfoData.case_ID, this.caseVersionIdNumber);

    //add new object to the entity list
    this.dataLineAssociationsListData.push(anItemObject);
    this.dataLineAssociationsTable = new MatTableDataSource(this.dataLineAssociationsListData);


    //refresh the table
    this.dataLineAssociationsTable._updateChangeSubscription();
    this.dataSourceAttachmentListData[this.varExpandedRecordID].caseLineAttachmentRelatedAttachmentIdList.push(anItemObject);

  }

  /* This procedure checks the returned result value from the popover Yes/No dialog line window. */
  yesLineButtonOnClick(isDeleteConfirmed: any, rowElement: any) {
    if (isDeleteConfirmed == true) {
      this.deleteLineItem(rowElement);
    }
  }

  /* Delete a row from the Attachment Grid */
  deleteLineItem(rowElement: any) {
    let rowIndex = this.dataLineAssociationsListData.indexOf(rowElement);
    if (this.dataSourceAttachmentListData[this.varExpandedRecordID].caseLineAttachmentRelatedAttachmentIdList[rowIndex].status == DsamsConstants.ENT_NEW.toString()) {
      this.dataLineAssociationsListData.splice(rowIndex, 1);
      this.dataSourceAttachmentListData[this.varExpandedRecordID].caseLineAttachmentRelatedAttachmentIdList.splice(rowIndex, 1);
      this.dates.removeAt(rowIndex);
    }
    else {
      this.dataSourceAttachmentListData[this.varExpandedRecordID].caseLineAttachmentRelatedAttachmentIdList[rowIndex].change_ACTION_CD = 'D';
      this.dataSourceAttachmentListData[this.varExpandedRecordID].caseLineAttachmentRelatedAttachmentIdList[rowIndex].status = DsamsConstants.ENT_DELETED.toString()
      this.dataLineAssociationsListData[rowIndex].status = DsamsConstants.ENT_DELETED.toString()
      this.dataSourceAttachmentListData[this.varExpandedRecordID].caseLineAttachmentRelatedAttachmentIdList[rowIndex].theCaseLine.change_ACTION_CD = DsamsConstants.ENT_DELETED.toString();
    }
    this.dataLineAssociationsTable = new MatTableDataSource(this.dataSourceAttachmentListData[this.varExpandedRecordID].caseLineAttachmentRelatedAttachmentIdList);
    this.dataLineAssociationsTable._updateChangeSubscription();
    this.changeIconImages(this.varExpandedRecordID, 'Y');

  }

  // Clobber the existing session IDs.
  private clobberLockSession() {
    const sessionIdForAttachmentLock: string = sessionStorage.getItem(DsamsConstants.SESSION_CASE_ATTACHMENT_LOCK_ID);
    if (!!sessionIdForAttachmentLock && (+sessionIdForAttachmentLock) > 0) {
      this.dsamsRestfulService.closeLegacyLockSession(sessionIdForAttachmentLock).subscribe((pResult: any) => {
        sessionStorage.setItem(DsamsConstants.SESSION_CASE_ATTACHMENT_LOCK_ID, "0");
      });
    }
  }


  /*---------------------------------------------- Edit Toggle --------------------------------------------*/
  // Subscribe to edit service
  private subscribeToEditService() {

    console.log("DsamsConstants.ATTACHMENTS_EDITOR");
    console.log(DsamsConstants.ATTACHMENTS_EDITOR);

    this.editSubscription = this.caseUIService.caseEditService.subscribe((pEditResult: IEditResponseType) => {
      if (!!pEditResult && pEditResult.ID === DsamsConstants.ATTACHMENTS_EDITOR) {
        this.isPanelEditable = pEditResult.editToggle;
        for (let i = 0; i < this.dataSourceAttachmentListData.length; i++) {
          if (this.dataSourceAttachmentListData[i].case_ATTACHMENT_TYPE_CD === 'ND') {
            this.dataSourceAttachmentListData[i].isAtchTextDisabled = true;
            this.dataSourceAttachmentListData[i].isAtchPageDisabled = false;
          }
          else {
            this.dataSourceAttachmentListData[i].case_ATTACHMENT_PAGE_QY = null;
            this.dataSourceAttachmentListData[i].isAtchPageDisabled = true;
            this.dataSourceAttachmentListData[i].isAtchTextDisabled = false;
          }
        }
        if (pEditResult.editToggle) {
          this.caseRestService.lockCaseAttachmentList(this.caseRelatedInfoData.case_ID, this.caseVersionIdNumber).
            subscribe((pLockSessionId: number) => {
                sessionStorage.setItem(DsamsConstants.SESSION_CASE_ATTACHMENT_LOCK_ID, pLockSessionId.toString());
            },
              err => {
                const turnToggleOff: IEditResponseType = { ID: DsamsConstants.ATTACHMENTS_EDITOR, editToggle: false };
                CaseUtils.ReportHTTPError(err, "locking case attachment list");
                this.caseUIService.caseEditService.next(turnToggleOff);
                this.caseUIService.caseEditServiceRegSub.next(turnToggleOff);
                this.caseUIService.revertEditService.next(turnToggleOff);
                this.caseUIService.hasEditBeenMadeService.next(turnToggleOff);
              });
        }
        else {
          if (this.hasDataBeenChanged()) {
            this.isLoading.next(false);
            if (!this.caseUIService.isEditOnSaveAttachmentConfirmed.value)
              this.refreshData();
            this.postSaveData();
          }
          else this.clobberLockSession();

          for (let i = 0; i < this.dataSourceAttachmentListData.length; i++) {
            this.dataSourceAttachmentListData[i].isAtchTextDisabled = true;
            this.dataSourceAttachmentListData[i].isAtchPageDisabled = true;
            this.dataSourceAttachmentListData[i].isAtchNoDisabled = true;
            this.dataSourceAttachmentListData[i].isAtchTypeDisabled = true;
            this.dataSourceAttachmentListData[i].isRestateDisabled = true;
          }
        }
        this.enableOrDisableFields();
      }
    });
  }

  // Determine if a field is disabled.
  isFieldDisabled(pElement: any, pFieldName: string): boolean {
    // Is whole panel disabled?
    if (!this.isPanelEditable) {
      return true;
    }
    if (!!pElement && pElement.isDisabled) {
      return true;
    }
    // Rule for Atch No.
    if (pFieldName === 'case_ATTACHMENT_NUMBER_ID') {
      if (pElement.status !== DsamsConstants.ENT_NEW) {
        return true;
      }
    }
    return this._fieldDisabledMap[pFieldName];
  }

  /**
  * Set the field changed so that the edit toggle is notified.
  */
  setChanged(index: number) {
    const editResp: IEditResponseType = { ID: DsamsConstants.ATTACHMENTS_EDITOR, editToggle: true };
    this.caseUIService.hasEditBeenMadeService.next(editResp);
    if (!!this.dataSourceAttachmentListData[index]) {
      this.dataSourceAttachmentListData[index].isDataChanged = true;
      if (this.dataSourceAttachmentListData[index].status == DsamsConstants.ENT_UNCHANGED.toString()) {
        this.dataSourceAttachmentListData[index].status = DsamsConstants.ENT_CHANGED.toString();
      }
      if (this.dataSourceAttachmentListData[index].case_ATTACHMENT_TYPE_CD === 'ND') {
        this.dataSourceAttachmentListData[index].isAtchTextDisabled = true;
        this.dataSourceAttachmentListData[index].isAtchPageDisabled = false;
      }
      else {
        this.dataSourceAttachmentListData[index].isAtchPageDisabled = true;
        this.dataSourceAttachmentListData[index].isAtchTextDisabled = false;
      }
      this.isDataReadyForSave = true;
    }

  }

  setChangedType(index: number) {
    if (this.dataSourceAttachmentListData[index].case_ATTACHMENT_TYPE_CD == 'DS') {
      this.dataSourceAttachmentListData[index].case_ATTACHMENT_PAGE_QY = null;
      this.dataSourceAttachmentListData[index].isAtchPageDisabled = true;
      this.dataSourceAttachmentListData[index].isAtchTextDisabled = false;
    }
    else {
      this.dataSourceAttachmentListData[index].case_ATTACHMENT_TX = null;
      this.dataSourceAttachmentListData[index].isAtchPageDisabled = false;
      this.dataSourceAttachmentListData[index].isAtchTextDisabled = true;
    }
    this.setChanged(index);
  }

  setChangedLine(index: number) {
    const editResp: IEditResponseType = { ID: DsamsConstants.ATTACHMENTS_EDITOR, editToggle: true };
    this.caseUIService.hasEditBeenMadeService.next(editResp);
    if (!!this.dataSourceAttachmentListData[this.varExpandedRecordID].caseLineAttachmentRelatedAttachmentIdList[index]) {
      this.dataSourceAttachmentListData[this.varExpandedRecordID].caseLineAttachmentRelatedAttachmentIdList[index].isDataChanged = true;
      if (this.dataSourceAttachmentListData[this.varExpandedRecordID].caseLineAttachmentRelatedAttachmentIdList[index].status == DsamsConstants.ENT_UNCHANGED.toString()) {
        this.dataSourceAttachmentListData[this.varExpandedRecordID].caseLineAttachmentRelatedAttachmentIdList[index].status = DsamsConstants.ENT_CHANGED.toString();
      }
      this.isDataReadyForSave = true;
    }
  }

  //check whether data has been changed
  hasDataBeenChanged(): boolean {
    for (let i = 0; i < this.dataSourceAttachmentListData.length; i++) {
      if (!!this.dataSourceAttachmentListData[i].status && this.dataSourceAttachmentListData[i].status !== DsamsConstants.ENT_UNCHANGED.toString()) { return true; }
      else {
        for (let j = 0; j < this.dataSourceAttachmentListData[i].caseLineAttachmentRelatedAttachmentIdList.length; j++) {
          if (!!this.dataSourceAttachmentListData[i].caseLineAttachmentRelatedAttachmentIdList[j].status && this.dataSourceAttachmentListData[i].caseLineAttachmentRelatedAttachmentIdList[j].status !== DsamsConstants.ENT_UNCHANGED.toString()) { return true; }
        }
      }
    }
    return false;
  }

  // Text Area Popup 
  popupTextAreaOpen(pElement: any, pIndex: number): void {
    let diaWidth: string = "50%";
    let diaHeight: string = "60%";

    let passingData: string = pElement.case_ATTACHMENT_TX;
    let pTitle: string = "Attachment Text";
    this._textIndex = pIndex;

    let indexString = '';
    if (!!pIndex) {
      indexString = pIndex.toString();
    }

    if (pElement.case_ATTACHMENT_TYPE_CD !== 'ND') {
      this.dsamsDialogMsgService.openTextAreaIpcDialog(diaWidth, diaHeight, passingData,
        TextAreaComponent, indexString, pTitle, !this.isPanelEditable);
    }
  }

  // Subscribe to Text Area Dialog Save
  subscribeToTextAreaDialog() {
    this.textAreaSubscription = this.dsamsDialogMsgService.textAreaFromIpcDialog.subscribe((textAreaValue: string) => {
      setTimeout(() => {
        if (!!this.dataSourceAttachmentListData[this._textIndex]) {
          this.dataSourceAttachmentListData[this._textIndex].case_ATTACHMENT_TX = textAreaValue;
          this.dataSourceAttachmentTable._updateChangeSubscription();
          this.setChanged(this._textIndex);
        }
      }, 0);
    });
  }

  // Text Area Popup for Official Title
  popupTextAreaOpenOfficialTitle(pElement: any, pIndex: number): void {
    let diaWidth: string = "40%";
    let diaHeight: string = "60%";

    let passingData: string = pElement.case_ATTACHMENT_NM;
    let pTitle: string = "Official Title";
    this._textIndex = pIndex;

    let indexString = '';
    if (!!pIndex) {
      indexString = pIndex.toString();
    }

    this.dsamsDialogMsgService.openTextAreaIpc2Dialog(diaWidth, diaHeight, passingData,
      TextAreaComponent, indexString, pTitle, !this.isPanelEditable);
  }

  // Subscribe to Text Area Dialog For Official Title
  subscribeToTextAreaDialogForOfficialTitle() {
    this.textAreaSubscription = this.dsamsDialogMsgService.textAreaFromIpc2Dialog.subscribe((textAreaValue: string) => {
      setTimeout(() => {
        if (!!this.dataSourceAttachmentListData[this._textIndex]) {
          this.dataSourceAttachmentListData[this._textIndex].case_ATTACHMENT_NM = textAreaValue;
          this.dataSourceAttachmentTable._updateChangeSubscription();
          this.setChanged(this._textIndex);
        }
      }, 0);
    });
  }

  /* This procedure changes the up or down arrow icon based on the 
     user selection and builds the line asso table. */
  changeIconImages(rowElement: any, varDelete: any) {
    // Build Asso Line table

    this.varExpandedRecordID = rowElement;
    rowElement = this.dataSourceAttachmentListData[this.varExpandedRecordID];
    this.dataLineAssociationsListData = [];


    // Need to do a check if collapsing inner grid don't do anything.


    if (!!rowElement.caseLineAttachmentRelatedAttachmentIdList) {
      for (let i = 0; i < rowElement.caseLineAttachmentRelatedAttachmentIdList.length; i++) {
        let sublineString: string = '';


        if (rowElement.caseLineAttachmentRelatedAttachmentIdList[i].theCaseLine !== null && rowElement.caseLineAttachmentRelatedAttachmentIdList[i].theCaseLine.wm_USER_CASE_SUBLINE_TX !== null) {
          sublineString = rowElement.caseLineAttachmentRelatedAttachmentIdList[i].theCaseLine.wm_USER_CASE_SUBLINE_TX;
        }

        const attachmentLineDtoObject: attachmentsLineDto =
        {
          isDataChanged: false,
          iconImg: 'arrow_drop_down',
          lineSubline: rowElement.caseLineAttachmentRelatedAttachmentIdList[i].theCaseLine.wm_USER_CASE_LINE_NUMBER_ID + sublineString,
          lineStatus: rowElement.caseLineAttachmentRelatedAttachmentIdList[i].theCaseLine.change_ACTION_CD,
          masl: rowElement.caseLineAttachmentRelatedAttachmentIdList[i].theCaseLine.military_ARTICLE_SERVICE_CD,
          quantity: rowElement.caseLineAttachmentRelatedAttachmentIdList[i].theCaseLine.case_LINE_ITEM_QY,
          unitOfIssue: rowElement.caseLineAttachmentRelatedAttachmentIdList[i].theCaseLine.issue_UNIT_CD,
          status: rowElement.caseLineAttachmentRelatedAttachmentIdList[i].Status
        };
        this.dataLineAssociationsListData.push(attachmentLineDtoObject);
      }
    }

    let rowN: number = this.dataSourceAttachmentListData.indexOf(rowElement);
    var str: string = ((this.dataSourceAttachmentListData[rowN]).iconImg);
    if (this.expandedElement === rowElement && varDelete == 'N') {
      this.expandedElement = null;
    }
    else {
      this.expandedElement = rowElement;
    }
    if (str === assoRelCaseConstants.iconImageArrowDown) {
      (this.dataSourceAttachmentListData[rowN]).iconImg = assoRelCaseConstants.iconImageArrowUp;
    }
    else {
      (this.dataSourceAttachmentListData[rowN]).iconImg = assoRelCaseConstants.iconImageArrowDown;
    }
    this.dataLineAssociationsTable = new MatTableDataSource(this.dataLineAssociationsListData);
    this.dataLineAssociationsTable._updateChangeSubscription();
  }

  /**
   * Determine if the save button is enabled.
   * (currently only depends on if the edit slider is toggled)
   */
  isSaveEnabled() {
    return this.isPanelEditable;
  }

  isCancelEnabled() {
    return this.isPanelEditable;
  }

  isDuplicateAttachmentNumberRowFound(pValue: number): boolean {
    if (pValue == null) return false;
    var aResult: boolean = false;
    var dupCounter: number = 0;
    //loop through the array to find duplicate values
    this.theLineAttchNoValidator.forEach(searchRow => {
      if (pValue == searchRow.case_ATTACHMENT_NUMBER_ID) {
        //if found then check counter for more than 1 occurrence
        if (dupCounter > 0) {
          aResult = true;
        }
        dupCounter++;
      }
    })
    return (aResult);
  }

  isDuplicateLineSubLineRowFound(pValue: string): boolean {
    if (pValue == '' || pValue == null) return false;
    var aResult: boolean = false;
    var dupCounter: number = 0;
    //loop through the array to find duplicate values
    this.theLineSublineValidator.forEach(searchRow => {
      if (pValue == searchRow.wm_USER_CASE_LINE_NUMBER_ID) {
        //if found then check counter for more than 1 occurrence
        if (dupCounter > 0) {
          aResult = true;
        }
        dupCounter++;
      }
    })
    return (aResult);
  }

  /** 
  * Do save Case Attachment data
 * @Author: Cliff Inks
 * @Date: 12/08/2021
 * @Jira Card: 2953
  */
  performSaveOperation() {
    this.isLoading.next(true);
    let saveCAList = new prepareCaseAttachmentDataForSave(this.dataSourceAttachmentListData);
    if (this.areFieldsValidForSave()) {
      this.caseRestService.saveCaseAttachmentList(saveCAList.theCAEntityList).subscribe(
        result => {
          let counter = 0;

          this.dataSourceAttachmentListData.forEach((eachRow, index) => {
            if (eachRow.status != DsamsConstants.ENT_UNCHANGED.toString()) {
              eachRow.case_ATTACHMENT_ID = result[counter].case_ATTACHMENT_ID;
              counter++;
            }
          })

          this.varSaveTXT = this.saveTXT(result);
          this.varLine = this.saveAttachmentLine(result);


          this.isLoading.next(false);
          if (this.varSaveTXT == 'SUCCESSFUL') {
            if (this.varLine == 'SUCCESSFUL') {
              setTimeout(() => {
                MessageMgr.displaySuccessWithTimer('Save was successful', 2000);
              }, 1200);
            }
          }

        },
        err => {
          this.isLoading.next(false);
          CaseUtils.ReportHTTPError(err, "Saving Case Attachment to the database.");
        })

      this.isLoading.next(false);

    }
  }

  //make sure madatory fields have values
  areFieldsValidForSave(): boolean {
    var displayMsg: boolean = false;
    let msgArray: Array<ErrorParameter> = [];

    this.theLineAttchNoValidator = [];
    this.dataSourceAttachmentListData.forEach((eachRow, index) => {
      if (eachRow.status != DsamsConstants.ENT_DELETED.toString()) {
        this.theLineAttchNoValidator.push(this.dataSourceAttachmentListData[index]);
      }
    })

    this.dataSourceAttachmentListData.forEach((eachRow, index) => {
      if (this.isDuplicateAttachmentNumberRowFound(eachRow.case_ATTACHMENT_NUMBER_ID)) {
        DialogMessageListComponentTc.addMessageRefToList(msgArray,
          'Attachments', 'Row ' + (index + 1).toString(), MessageType.ERROR,
          "Attachment No. must be unique.");
        displayMsg = true;
      }
      if (CaseUtils.isBlankStr(eachRow.case_ATTACHMENT_NUMBER_ID)) {
        DialogMessageListComponentTc.addMessageRefToList(msgArray,
          'Attachments', 'Row ' + (index + 1).toString(), MessageType.ERROR,
          "Attachment No. is required.");
        displayMsg = true;
      }
      if (CaseUtils.isBlankStr(eachRow.case_ATTACHMENT_TYPE_CD)) {
        DialogMessageListComponentTc.addMessageRefToList(msgArray,
          'Attachments', 'Row ' + (index + 1).toString(), MessageType.ERROR,
          "Atch Type is required.");
        displayMsg = true;
      }
      if (CaseUtils.isBlankStr(eachRow.case_ATTACHMENT_NM)) {
        DialogMessageListComponentTc.addMessageRefToList(msgArray,
          'Attachments', 'Row ' + (index + 1).toString(), MessageType.ERROR,
          "Official Title is required.");
        displayMsg = true;
      }
      if (CaseUtils.isBlankStr(eachRow.case_ATTACHMENT_TX)) {
        if (eachRow.case_ATTACHMENT_TYPE_CD == 'DS') {
          DialogMessageListComponentTc.addMessageRefToList(msgArray,
            'Attachments', 'Row ' + (index + 1).toString(), MessageType.ERROR,
            "Attachment Text is required.");
          displayMsg = true;
        }
      }
      if (CaseUtils.isBlankStr(eachRow.case_ATTACHMENT_PAGE_QY)) {
        if (eachRow.case_ATTACHMENT_TYPE_CD == 'ND') {
          DialogMessageListComponentTc.addMessageRefToList(msgArray,
            'Attachments', 'Row ' + (index + 1).toString(), MessageType.ERROR,
            "# of Pages is required for Non-DSAMS attachments.");
          displayMsg = true;
        }
      }

      this.theLineSublineValidator = [];
      this.dataSourceAttachmentListData[index].caseLineAttachmentRelatedAttachmentIdList.forEach((eachCaseLineRow, caseLineIndex) => {
        if (eachCaseLineRow.status != DsamsConstants.ENT_DELETED.toString()) {
          this.theLineSublineValidator.push(eachCaseLineRow.theCaseLine);
        }
      })

      this.dataSourceAttachmentListData[index].caseLineAttachmentRelatedAttachmentIdList.forEach((eachDupCheckRow, dupCheckRowIndex) => {
        if (this.isDuplicateLineSubLineRowFound(eachDupCheckRow.theCaseLine.wm_USER_CASE_LINE_NUMBER_ID)) {
          DialogMessageListComponentTc.addMessageRefToList(msgArray,
            'Attachments', 'Row ' + (index + 1).toString() + ' Line/SubLine ' + (dupCheckRowIndex + 1).toString(), MessageType.ERROR,
            "Line/SubLine must be unique.");
          displayMsg = true;
        }

        if (CaseUtils.isBlankStr(eachDupCheckRow.theCaseLine.wm_USER_CASE_LINE_NUMBER_ID)) {
          DialogMessageListComponentTc.addMessageRefToList(msgArray,
            'Attachments', 'Row ' + (index + 1).toString(), MessageType.ERROR,
            "Line/SubLine is requried.");
          displayMsg = true;
        }


      })
    })
    //Display validation warning/error messages if applicable
    if (displayMsg) {
      this.isLoading.next(false);
      this.messageService.displayMessageListTc("Validate Attachmentss", msgArray).subscribe(result => {
        console.log('MessageList has been displayed');
      });
    }
    return !displayMsg;
  }

  /** 
   * Save Case Attachment function includes validation
   * @Author: Cliff Inks
   * @Date: 12/08/2021
   * @Jira Card: 2953
   */
  onClickSaveCaseAttachmentData() {
    let orderChanges = 0;
    orderChanges = this.orderChanges();

    if (orderChanges != 0) {
      this.saveSetStatus();
    }

    if (this.hasDataBeenChanged()) {
      this.checkSave();
    }
    else {
      let nctsPrompt: any = {
        text: 'No change has been made.',
        icon: 'info',
        showConfirmButton: false,
        timer: 1500,
        width: 350
      };
      MessageMgr.swalFire(nctsPrompt);

    }

  }

  /** 
  * Post save data method to reset applicable attributes
  * @Author: Cliff Inks
  * @Date: 12/08/2021
  * @Jira Card: 2953
 */
  saveTXT(results: any) {
    this.isLoading.next(true);
    let saveCATXTList = new prepareCaseAttachmentTXTDataForSave(this.dataSourceAttachmentListData);
    if (this.areFieldsValidForSave()) {
      this.caseRestService.saveCaseAttachmentListTXT(saveCATXTList.theCATXTEntityList).subscribe(
        result => {
          this.isLoading.next(false);
          return 'SUCCESSFUL';
        },
        err => {
          this.isLoading.next(false);
          CaseUtils.ReportHTTPError(err, "Saving Case Attachment TXT to the database.");
          return 'ERROR';
        })
      this.isLoading.next(false);

    }
  }

  /** 
  * Post save data method to reset applicable attributes
  * @Author: Cliff Inks
  * @Date: 12/08/2021
  * @Jira Card: 2953
 */
  saveAttachmentLine(results: any) {
    this.isLoading.next(true);
    let saveCALINEList = new prepareCaseAttachmentLineDataForSave(this.dataSourceAttachmentListData);
    console.log('before second save result=', this.dataSourceAttachmentListData);

    if (this.areFieldsValidForSave()) {
      this.caseRestService.saveCaseAttachmentListLine(saveCALINEList.theCALINEEntityList).subscribe(
        result => {
          this.isLoading.next(false);
          console.log('Results after saves:');
          console.log(this.dates);
          console.log(this.dataSourceAttachmentListData);
          this.postSaveData();
          return 'SUCCESSFUL';
        },
        err => {
          this.isLoading.next(false);
          CaseUtils.ReportHTTPError(err, "Saving Case Line to the database.");
          return 'ERROR';
        })
      this.isLoading.next(false);
    }
  }

  postSaveData() {
    for (let i = 0; i < this.dataSourceAttachmentListData.length; i++) {
      if (this.dataSourceAttachmentListData[i].status == DsamsConstants.ENT_DELETED.toString()) {
        this.dataSourceAttachmentListData.splice(i, 1);
      }

      else {
        this.dataSourceAttachmentListData[i].status = DsamsConstants.ENT_UNCHANGED.toString();
        this.dataSourceAttachmentListData[i].isDataChanged = false;
        this.isDeleteDisabled[i] = true;

        for (let j = 0; j < this.dataSourceAttachmentListData[i].caseLineAttachmentRelatedAttachmentIdList.length; j++) {
          this.dataSourceAttachmentListData[i].caseLineAttachmentRelatedAttachmentIdList[j].status = DsamsConstants.ENT_UNCHANGED.toString();
          this.dataSourceAttachmentListData[i].caseLineAttachmentRelatedAttachmentIdList[j].theCaseLine.status = DsamsConstants.ENT_UNCHANGED.toString();
        }
      }

    }

    for (let k = 0; k < this.dataLineAssociationsListData.length; k++) {
      this.dataLineAssociationsListData[k].status = DsamsConstants.ENT_UNCHANGED.toString();
    }


    this.dataSourceAttachmentListData.forEach((eachRow, index) => {
      this.dates.removeAt(index);
      this.dates.insert(index, new FormControl(DateValidator.dateToString(<Date>CaseUtils.toDate(this.dataSourceAttachmentListData[index].attachment_LAST_UPDATED_DT))));
    })

    let counter = this.dates.length;

    while (counter > this.dataSourceAttachmentListData.length) {
      console.log("Deleting:" + counter);
      this.dates.removeAt(counter);
      counter--;
    }
    /* Added to fix edit toggle off - Author: JS */
    const editResp: IEditResponseType = { ID: DsamsConstants.ATTACHMENTS_EDITOR, editToggle: false };
    this.caseUIService.hasEditBeenMadeService.next(editResp);

    //dsams-5542 DH 05/22
    if (this.caseUIService.isEditOnSaveAttachmentConfirmed.value){
      this.clobberLockSession();
      const turnToggleOff: IEditResponseType = { ID: DsamsConstants.ATTACHMENTS_EDITOR, editToggle: false };
      this.caseUIService.caseEditService.next(turnToggleOff);
    }
    this.caseUIService.isEditOnSaveAttachmentConfirmed.next(false);
  }

  refreshData() {
    this._caseAttachmentDataSubscription =
      this.caseRestService.getCaseAttachmentsData(this.caseRelatedInfoData.case_ID, this.caseVersionIdNumber)
        .subscribe((values) => {
          if (values !== null) {
            console.log(values)
            this.dataSourceAttachmentListData = values;
            for (let i = 0; i < this.dataSourceAttachmentListData.length; i++) {
              this.dates.insert(i, new FormControl(DateValidator.dateToString(<Date>CaseUtils.toDate(this.dataSourceAttachmentListData[i].attachment_LAST_UPDATED_DT))));

              this.dataSourceAttachmentListData[i].status = DsamsConstants.ENT_UNCHANGED.toString();
              this.dataSourceAttachmentListData[i].iconImg = 'arrow_drop_down';
              if (this.dataSourceAttachmentListData[i].change_ACTION_CD === 'A' && this.isPanelEditable) {
                this.dataSourceAttachmentListData[i].isFieldDisabled = { ['AttachmentDelete']: false }
              }
              else {
                this.dataSourceAttachmentListData[i].isFieldDisabled = { ['AttachmentDelete']: true }
              }
              this.dataSourceAttachmentListData[i].isDataChanged = false;

              this.dataSourceAttachmentListData[i].status = DsamsConstants.ENT_UNCHANGED.toString();
              this.dataSourceAttachmentListData[i].isAtchNoDisabled = true;
              this.dataSourceAttachmentListData[i].isAtchPageDisabled = true;
              this.dataSourceAttachmentListData[i].isAtchTextDisabled = true;
              this.dataSourceAttachmentListData[i].isAtchTypeDisabled = true;
              this.dataSourceAttachmentListData[i].isRestateDisabled = true;

              // This is where you want to populate the lines
              if (this.dataSourceAttachmentListData[i].caseLineAttachmentRelatedAttachmentIdList != null) {
                for (let j = 0; j < this.dataSourceAttachmentListData[i].caseLineAttachmentRelatedAttachmentIdList.length; j++) {
                  this.dataSourceAttachmentListData[i].caseLineAttachmentRelatedAttachmentIdList[j].status = DsamsConstants.ENT_UNCHANGED.toString();
                }
              }
            }
            this.dataSourceAttachmentTable = new MatTableDataSource(this.dataSourceAttachmentListData);
            this.dataSourceAttachmentTable._updateChangeSubscription();

            // Set Options
            let versionStatus: string = this.caseLineRelatedInfoData.case_VERSION_STATUS_CD;
            let versionType: string = this.caseLineRelatedInfoData.case_VERSION_TYPE_CD;
            let caseUsageCode: string = this.caseRelatedInfoData.case_USAGE_INDICATOR_CD;
            this.caseUIService.setIsCaseInReviewEnabled(CaseUtils.isOptionEnabledForCaseInReviewShortcut(versionStatus));
            this.caseUIService.setIsCaseInProposedEnabled(CaseUtils.isOptionEnabledForCaseInProposedShortcut(versionStatus));
            this.caseUIService.setIsUpdImplCaseEnabled(CaseUtils.isOptionEnabledForUpdImplCaseShortcut(versionStatus));
            this.caseUIService.setIsPenInkEnabled(CaseUtils.isOptionEnabledForPenInkShortcut(versionStatus, versionType, caseUsageCode));

            this.isLoading.next(false);

          }
        },
          err => {
            CaseUtils.ReportHTTPError(err, "Getting Attachments");
            this.isLoading.next(false);
          });
  }

  /**
   * Function to denote that the row is expanded.
   */
  isExpanded(pRow) {
    return pRow == this.currentlySelectedRowNum;
  }

  /**
   * Reset the prev case search index.
   */
  private resetPrevCaseIndex() {
    this._prevCaseIndex = -1;
  }

  // Method to handle click event on Search results table row
  getMainRow(expandedElement: any, row: any, index) {
    // Account for the page you're on and LPP for adjusting the index.
    const realIndex = index;
    if (!!expandedElement) {
      if (row.isExpanded) {
        this.initializeAttachmentArray(realIndex);
      }
      this._prevCaseIndex = realIndex;
    }
  }

  initializeAttachmentArray(pIndex) {
    let currAttachmentList: Array<any> = <Array<any>>(this.dataSourceAttachmentListData);
    if (!!currAttachmentList) {
      let currAttachmentItem: any;
      const aCaseResultsRowIndex: number = currAttachmentList.length;
      for (let i = 0; i < aCaseResultsRowIndex; i++) {
        currAttachmentItem = Object.assign({ rowNum: (i + 1), isExpanded: false }, currAttachmentList[i]);
        currAttachmentList[i] = currAttachmentItem;
      }
      this.dataSourceAttachmentTable = new MatTableDataSource(currAttachmentList);
    }

    // Set the row number to what the user cliecked.
    this.currentlySelectedRowNum = pIndex + 1;

    this.dataSourceAttachmentTable._updateChangeSubscription();
  }

  populateAttachmentData() {
    if (!!this.caseRelatedInfoData && !!this.caseRelatedInfoData.case_VERSION_ID) {
      this.caseVersionIdNumber = parseInt(this.caseRelatedInfoData.case_VERSION_ID);
    }
    this.isLoading.next(true);
    if (!this._caseAttachmentDataSubscription) {
      if (!!this.caseRelatedInfoData) {
        this._caseAttachmentDataSubscription =
          this.caseRestService.getCaseAttachmentsData(this.caseRelatedInfoData.case_ID, this.caseVersionIdNumber)
            .subscribe((values) => {
              if (values !== null) {
                this.dataSourceAttachmentListData = values;
                for (let i = 0; i < this.dataSourceAttachmentListData.length; i++) {
                  this.dates.insert(i, new FormControl(DateValidator.dateToString(<Date>CaseUtils.toDate(this.dataSourceAttachmentListData[i].attachment_LAST_UPDATED_DT))));

                  this.dataSourceAttachmentListData[i].status = DsamsConstants.ENT_UNCHANGED.toString();
                  this.dataSourceAttachmentListData[i].iconImg = 'arrow_drop_down';
                  this.dataSourceAttachmentListData[i].isFieldDisabled = { ['AttachmentDelete']: true }
                  this.dataSourceAttachmentListData[i].isDataChanged = false;

                  this.dataSourceAttachmentListData[i].isAtchNoDisabled = true;
                  this.dataSourceAttachmentListData[i].isAtchPageDisabled = true;
                  this.dataSourceAttachmentListData[i].isAtchTextDisabled = true;
                  this.dataSourceAttachmentListData[i].isAtchTypeDisabled = true;
                  this.dataSourceAttachmentListData[i].isRestateDisabled = true;

                  // This is where you want to populate the lines
                  if (this.dataSourceAttachmentListData[i].caseLineAttachmentRelatedAttachmentIdList != null) {
                    for (let j = 0; j < this.dataSourceAttachmentListData[i].caseLineAttachmentRelatedAttachmentIdList.length; j++) {
                      this.dataSourceAttachmentListData[i].caseLineAttachmentRelatedAttachmentIdList[j].status = DsamsConstants.ENT_UNCHANGED.toString();
                    }
                  }
                }
                this.dataSourceAttachmentTable = new MatTableDataSource(this.dataSourceAttachmentListData);
                this.dataSourceAttachmentTable._updateChangeSubscription();

                // Set Options
                let versionStatus: string = this.caseLineRelatedInfoData.case_VERSION_STATUS_CD;
                let versionType: string = this.caseLineRelatedInfoData.case_VERSION_TYPE_CD;
                let caseUsageCode: string = this.caseRelatedInfoData.case_USAGE_INDICATOR_CD;
                this.caseUIService.setIsCaseInReviewEnabled(CaseUtils.isOptionEnabledForCaseInReviewShortcut(versionStatus));
                this.caseUIService.setIsCaseInProposedEnabled(CaseUtils.isOptionEnabledForCaseInProposedShortcut(versionStatus));
                this.caseUIService.setIsUpdImplCaseEnabled(CaseUtils.isOptionEnabledForUpdImplCaseShortcut(versionStatus));
                this.caseUIService.setIsPenInkEnabled(CaseUtils.isOptionEnabledForPenInkShortcut(versionStatus, versionType, caseUsageCode));

                // Set Breadcrumb


                this.isLoading.next(false);
              }
            },
              err => {
                CaseUtils.ReportHTTPError(err, "Getting Attachments");
                this.isLoading.next(false);
              });
      }
    }
  }

  GetSortNumberOrder(prop: any) {
    return function (a: any, b: any) {
      if (parseInt(a[prop]) > parseInt(b[prop])) {
        return 1;
      } else if (parseInt(a[prop]) < parseInt(b[prop])) {
        return -1;
      }
      return 0;
    }
  }

  // Method to get sublines
  getParentLineCMLId(pParentCaseId: any, pParentCaseMasterLineId: any): string {
    //set up parent line for subline
    for (let i = 0; i < this.theCaseLineListTempArray.length; i++) {
      if (this.theCaseLineListTempArray[i].case_ID == pParentCaseId &&
        this.theCaseLineListTempArray[i].case_MASTER_LINE_ID == pParentCaseMasterLineId) {
        return (this.theCaseLineListTempArray[i].wm_USER_CASE_LINE_NUMBER_ID);
      }
    }
    return '';
  }

  //DH - Jira 2946 populate line/subline dropdown lists
  getLineDropdownList(pCaseId: number, pCaseVersionId: number) {
    this.caseRestService.getLineSublineListForCVDto(pCaseId, pCaseVersionId).subscribe(value => {
      this.theCaseLineListArray = [];
      this.theCaseLineListTempArray = [];
      this.theCaseLineListTempArray = value;
      this.theCaseLineListTempArray.forEach((eachRow) => {
        if (eachRow.wm_PARENT_CASE_MASTER_LINE_ID == null || eachRow.wm_PARENT_CASE_MASTER_LINE_ID == undefined ||
          eachRow.wm_PARENT_CASE_MASTER_LINE_ID == 0) {
          // Adding Line
          this.theCaseLineListArray.push(eachRow);
        }
        if (!!eachRow.wm_PARENT_CASE_MASTER_LINE_ID) {
          let caseMasterlineDtoObject = {
            case_ID: eachRow.case_ID,
            case_MASTER_LINE_ID: eachRow.case_MASTER_LINE_ID,
            wm_USER_CASE_LINE_NUMBER_ID: this.getParentLineCMLId(eachRow.wm_PARENT_CASE_ID, eachRow.wm_PARENT_CASE_MASTER_LINE_ID),
            wm_USER_CASE_SUBLINE_TX: eachRow.wm_USER_CASE_SUBLINE_TX,
            wm_PARENT_CASE_ID: eachRow.wm_PARENT_CASE_ID,
            wm_PARENT_CASE_MASTER_LINE_ID: eachRow.wm_PARENT_CASE_MASTER_LINE_ID,
          }
          // Adding Subline
          this.theCaseLineListArray.push(caseMasterlineDtoObject);
        }
      })
      this.theCaseLineListArray.sort(this.GetSortNumberOrder("wm_USER_CASE_LINE_NUMBER_ID"));
    });
  }

  // Enable or disable fields according to toggle.
  private enableOrDisableFields() {

    const disabledState: boolean = !this.isPanelEditable;

    this.dataSourceAttachmentListData.forEach((eachCaseAttachment: attachmentsDto) => {
      if (!eachCaseAttachment.isFieldDisabled) {
        eachCaseAttachment.isFieldDisabled = {};
      }
      eachCaseAttachment.isFieldDisabled['AttachmentDelete'] = (disabledState || eachCaseAttachment.change_ACTION_CD === 'D');

      eachCaseAttachment.isRestateDisabled = (disabledState || eachCaseAttachment.change_ACTION_CD === 'A' ||
        eachCaseAttachment.change_ACTION_CD === 'R' || this.caseLineRelatedInfoData.case_VERSION_TYPE_CD === 'B');
    });

  }


  changeAttachment(i: number) {
    if (this.dataSourceAttachmentListData[i].status !== DsamsConstants.ENT_NEW.toString()) {
      this.dataSourceAttachmentListData[i].status = DsamsConstants.ENT_CHANGED.toString();
    }
  }
  setLineSublineChangedAttachment(pEvent: any, pIndex: any) {
    this.setChangedLine(pIndex);
    this.dataSourceAttachmentListData[this.varExpandedRecordID].caseLineAttachmentRelatedAttachmentIdList[pIndex].theCaseLine = pEvent.value;

    this.theAssoLineArrayForLookup.forEach((eachRow) => {
      if (eachRow.caseMasterLineId === pEvent.value.case_MASTER_LINE_ID) {
        let sublineString: string = '';
        if (pEvent.value.wm_USER_CASE_SUBLINE_TX !== null) {
          sublineString = pEvent.value.wm_USER_CASE_SUBLINE_TX;
        }
        let lineSublineValue: string = pEvent.value.wm_USER_CASE_LINE_NUMBER_ID + sublineString;
        // Set the line info ***
        this.dataLineAssociationsListData[pIndex].lineSubline = lineSublineValue;
        this.dataLineAssociationsListData[pIndex].lineStatus = eachRow.lineStatus;
        this.dataLineAssociationsListData[pIndex].masl = eachRow.masl;
        this.dataLineAssociationsListData[pIndex].quantity = eachRow.quantity;
        this.dataLineAssociationsListData[pIndex].unitOfIssue = eachRow.unitOfIssue;

        this.dataSourceAttachmentListData[this.varExpandedRecordID].caseLineAttachmentRelatedAttachmentIdList[pIndex].theCaseLine.military_ARTICLE_SERVICE_CD = eachRow.masl;
        this.dataSourceAttachmentListData[this.varExpandedRecordID].caseLineAttachmentRelatedAttachmentIdList[pIndex].theCaseLine.case_LINE_ITEM_QY = eachRow.quantity;
        this.dataSourceAttachmentListData[this.varExpandedRecordID].caseLineAttachmentRelatedAttachmentIdList[pIndex].theCaseLine.change_ACTION_CD = eachRow.lineStatus;
        this.dataSourceAttachmentListData[this.varExpandedRecordID].caseLineAttachmentRelatedAttachmentIdList[pIndex].theCaseLine.issue_UNIT_CD = eachRow.unitOfIssue;
      }
    });
    this.dataLineAssociationsTable = new MatTableDataSource(this.dataLineAssociationsListData);
  }

  getDataForLineDetails() {
    this.caseRestService.getCaseLineListFromServer(this.caseRelatedInfoData.case_ID, this.caseVersionIdNumber)
      .subscribe(
        data => {
          if (!!data) {
            data.caseLineList.forEach((eachRow) => {
              const attachmentLineDtoObject: theAssoLineArray = {
                iconImg: "arrow_drop_down",
                lineSubline: eachRow.wm_USER_CASE_LINE_NUMBER_ID + eachRow.wm_USER_CASE_SUBLINE_TX,
                lineStatus: eachRow.change_ACTION_CD,
                quantity: eachRow.case_LINE_ITEM_QY,
                masl: eachRow.military_ARTICLE_SERVICE_CD,
                unitOfIssue: eachRow.issue_UNIT_CD,
                caseMasterLineId: eachRow.case_MASTER_LINE_ID
              }
              this.theAssoLineArrayForLookup.push(attachmentLineDtoObject);
            });
          }
        })
  }

  //on Dragging row to the new position in the list
  onDragRow(draggedRow: any, rowIndex: any) {
    this.previousDragRowIndex = rowIndex;

  }

  dragResetDates(draggedRow: any, rowIndex: any) {
    this.dataSourceAttachmentListData.forEach((eachRow, arrayindex) => {
      this.dates.removeAt(arrayindex);
      this.dates.insert(arrayindex, new FormControl(DateValidator.dateToString(<Date>CaseUtils.toDate(eachRow.attachment_LAST_UPDATED_DT))));
    })
    let counter = this.dates.length;

    while (counter > this.dataSourceAttachmentListData.length) {
      this.dates.removeAt(counter);
      counter--;
    }
  }


  // Check whether attachment can be renumbered
  isRowValidForRenumber(dropRowIndex: number, previousDropRowIndex: number): boolean {
    if (this.dataSourceAttachmentTable.data[dropRowIndex].change_ACTION_CD != 'A' ||
      this.dataSourceAttachmentTable.data[previousDropRowIndex].change_ACTION_CD != 'A') {
      MessageMgr.swalFire({
        text: 'Cannot move attachment not in added status or place in the new location.',
        icon: 'error',
        width: 300,
        showCancelButton: false,
        confirmButtonColor: '#3085d6',
        confirmButtonText: 'Ok'
      });
      return false;
    }
    return true;
  }

  // On Dropping row to the new postion in the list
  onDropRow(event: CdkDragDrop<string[]>) {
    let currentIndex = event.currentIndex;
    if (currentIndex !== this.previousDragRowIndex && this.isRowValidForRenumber(currentIndex, this.previousDragRowIndex)) {
      moveItemInArray(this.dataSourceAttachmentTable.data, this.previousDragRowIndex, currentIndex);
      this.dataSourceAttachmentTable._updateChangeSubscription();
      this.changeDetectorRef.detectChanges();
      this.isAttachmentBeingMoved = true;
      this.setChanged(this.previousDragRowIndex);
      this.dataSourceAttachmentListData[currentIndex].isDataChanged = true;
      this.dataSourceAttachmentListData[this.previousDragRowIndex] = this.dataSourceAttachmentTable.data[this.previousDragRowIndex];
      this.dataSourceAttachmentListData[currentIndex] = this.dataSourceAttachmentTable.data[currentIndex];
    }
  }

  orderChanges() {
    let orderChanges = 0;
    this.dataSourceAttachmentListData.forEach((eachRow, index) => {
      if ((index + 1) != this.dataSourceAttachmentListData[index].case_ATTACHMENT_NUMBER_ID) {
        orderChanges++;
      }
      if (this.dataSourceAttachmentListData[index].status == DsamsConstants.ENT_DELETED.toString()) {
        orderChanges++;
      }
    })
    return orderChanges;
  }

  saveSetStatus() {
    let counter = 1;
    this.dataSourceAttachmentListData.forEach((eachRow, index) => {
      if (this.dataSourceAttachmentListData[index].status != DsamsConstants.ENT_DELETED.toString()) {
        if (this.dataSourceAttachmentListData[index].case_ATTACHMENT_NUMBER_ID != counter) {
          this.dataSourceAttachmentListData[index].case_ATTACHMENT_NUMBER_ID = counter;
          if (this.dataSourceAttachmentListData[index].status == DsamsConstants.ENT_UNCHANGED.toString()) {
            this.dataSourceAttachmentListData[index].status = DsamsConstants.ENT_CHANGED.toString();
          }
        }
        counter++;
      }
    })
  }

  checkSave() {
    if (CaseCommonValidator.isEqual(this.theCustomerTypeCode, LineUtils.CUSTOMER_TYPE_PS)) {
      MessageMgr.swalFire({
        text: 'This is a 36(b) Congressional Notification document!!! Please ensure that no references are made to classified information!!! Do you want to continue with Save?',
        icon: 'question',
        width: 550,
        showCancelButton: true,
        cancelButtonText: 'No',
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes',
      }).then((result) => {
        if (result.isConfirmed) {
          this.performSaveOperation();
        }

      })
    }
    else {
      this.performSaveOperation();
    }
  }
}
