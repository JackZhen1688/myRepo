import { Component, OnInit } from '@angular/core';
import { Subscription, BehaviorSubject } from 'rxjs';
import { caseConstants } from 'src/app/dsams/case/case-dashboard/case-dashboard.component';
import { CaseUIService } from '../services/case-ui-service';
import { DsamsConstants } from '../../dsams.constants';
import { DsamsMethodsService } from '../../services/dsams-methods.service';
import { FormGroup } from '@angular/forms';
import { IEditResponseType } from '../model/edit-response-type';
import { EntityStatus } from '../../enums/entity-status.enum';
import { DsamsUserMessageService } from '../../services/dsams-user-message.service';
import { ActivatedRoute } from '@angular/router';
import { attachmentsDto } from './model/dto/case-attachments-dto';
import { CaseUtils } from '../utils/case-utils';
import { CaseLineRelatedInfoType } from '../model/case-line-related-info-type';
import { CaseRelatedInfoType } from '../model/case-related-info-type';
import { LinkCaseDataClass } from '../model/link-case-data';
import { DsamsShareService } from '../../services/dsams-share.service';
import { CsuCompNameHashTable } from '../../utilitis/csu-component-hashtable';
import { DsamsRestfulService } from '../../services/dsams-restful.service';
import { tap } from 'rxjs/operators';

@Component({
  selector: 'app-attachments-dashboard',
  templateUrl: './attachments-dashboard.component.html',
  styleUrls: ['./attachments-dashboard.component.css']
})
export class AttachmentsDashboardComponent implements OnInit {
  /* Private attributes */
  private static ATTACHMENTS_EDITOR: string = DsamsConstants.ATTACHMENTS_EDITOR;

  /* Top button attributes */
  expandBgBtnColor = caseConstants.initalButtonBgColor;
  summaryBgBtnColor = caseConstants.highlightedBtnColor;
  requirementBgBtnColor = caseConstants.initalButtonBgColor;
  attachmentBgBtnColor = caseConstants.initalButtonBgColor;
  outlineBtnColor = caseConstants.initalButtonBgColor;
  newCRBtnColor = caseConstants.goldButtonColor;
  newCRBtnFontColor = caseConstants.initalOkButtonFontColor;
  boldSummaryBtnFont = "";
  boldRequirementBtnFont = "";
  boldAttachmentBtnFont = "";
  /* Panel States to facilitate button actions above the accordian */
  expandPanelBtnBehavior: string = caseConstants.expandAll;
  panelSummaryOpenState: boolean = false;
  panelRequirementsOpenState: boolean = false;
  panelAttachmentsOpenState: boolean = false;

  /* Local variables */
  isLoading: BehaviorSubject<boolean> = new BehaviorSubject(false);
  isEditMode: boolean = false;
  isNewAttachments: boolean = false;
  isValidAttachment: boolean = true;

  // Form for new popup for attachment form
  attachmentsForm: FormGroup;

  aAttachmentsDTO: attachmentsDto;

  private caseUIServiceSubscription: Subscription = null;
  private editSubscription: Subscription = null;
  private _caseUIServiceSubscription: Subscription = null;
  private caseLineRelatedInfoData: CaseLineRelatedInfoType;
  aCaseUserId: string = "";
  aUserCaseId: any;
  aCaseId: any;
  aCaseVersionId: any;
  aCaseVersionNumId: any;
  aCaseVersionTypeCd: any;
  aCaseVersionTypeDesc: any;
  aCustomerOrgId: any;
  caseRelatedInfoData: CaseRelatedInfoType;
  readonly PAGE_CASE_ATTACHMENTS: string = DsamsConstants.PAGE_CASE_ATTACHMENTS;
  //DSAMS-5461 DH 05/02/22
  theCSUId: string;
  isEditRightAccessGranted: boolean = false;

  /* Main Logic */
  constructor(private caseUIService: CaseUIService,
    private dataSharingService: DsamsShareService,
    private activatedRoute: ActivatedRoute,
    private dsamsRestfulService: DsamsRestfulService,
    public dsamsDialogMsgService: DsamsMethodsService,
    private CSUHashTable: CsuCompNameHashTable,
    protected messageService: DsamsUserMessageService) {
  }

  //breakout logic per sonarqube
  getCSUCode(){
    let aCsuId = this.CSUHashTable.getCSUId(this.activatedRoute.routeConfig.component.name);
    this.theCSUId = aCsuId ? aCsuId : CsuCompNameHashTable.CSU_CD_WP010;  
  }

  ngOnInit() {
    //DSAMS-5461 DH 05/22
    this.getCSUCode();
    this.getEditableAccess();

    this.dataSharingService.csuname.next(this.theCSUId);
    this.getLinkCaseDataOnInit();
    this.caseUIService.setPageNavigation(DsamsConstants.PAGE_CASE_ATTACHMENTS);
    //Header text
    this._caseUIServiceSubscription = this.caseUIService.getCaseRelatedInfoValues().subscribe((value) => {
      this.caseRelatedInfoData = value;
      if (!!this.caseRelatedInfoData) {
        if (this.caseRelatedInfoData.case_ID != null) {
          this.aCaseId = this.caseRelatedInfoData.case_ID;
        } else {
          this.aCaseId = this.caseRelatedInfoData.working_CASE_ID;
        }
        this.aCaseVersionId = this.caseRelatedInfoData.working_CASE_VERSION_ID;
        this.aCustomerOrgId = this.caseRelatedInfoData.customer_ORGANIZATION_ID;
      }
    });
    this._caseUIServiceSubscription = this.caseUIService.getCaseLineRelatedInfoValues().subscribe((value) => {
      this.caseLineRelatedInfoData = value;
      if (!!this.caseLineRelatedInfoData) {
        this.aUserCaseId = this.caseLineRelatedInfoData.user_CASE_ID;
        if (this.caseLineRelatedInfoData.case_VERSION_STATUS_CD === 'D') {
          this.caseUIService.setIsAttachmentStatus(true);
        }
        else {
          this.caseUIService.setIsAttachmentStatus(false);
        }
        if (!CaseUtils.isBlankStr(this.caseLineRelatedInfoData.case_VERSION_NUMBER_ID))
          this.aCaseUserId = '(' + this.caseLineRelatedInfoData.user_CASE_ID + ' '
            + this.caseLineRelatedInfoData.case_VERSION_TYPE_CD +
            this.caseLineRelatedInfoData.case_VERSION_NUMBER_ID + ')';
        else {
          this.aCaseUserId = '(' + this.caseLineRelatedInfoData.user_CASE_ID + ' '
            + this.caseLineRelatedInfoData.case_VERSION_TYPE_CD + ')';
        }

      }
    });
    this.aCaseVersionNumId = 0;
    this.aCaseVersionTypeCd = "";
    this.aCaseVersionTypeDesc = "";

    //reset all button statuses
    this.resetAllButtonColors();

    //set up shortcut menu list

    //Show option menu
    this.caseUIService.setIsOptionsMenuHidden(false);
    this.caseUIService.setIsShortcutsMenuHidden(false);

    // Set Toggle initially to false.
    this.caseUIService.caseEditService.next({
      ID: AttachmentsDashboardComponent.ATTACHMENTS_EDITOR,
      editToggle: false,
    });
    this.subscribeToEdit();

    //Initialize Attachment DTO to avoid undefined error on initial loading of web page
    this.initializeAttachmentsDTO();
    //Todo - need?
    //this.caseUIService.setAttachmentsDTO(this.aAttachmentsDTO);

    // Reset new flag
    //Todo - need?
    //this.caseUIService.isNewAttachments.next(false);
  }
   
  //begin DSAMS-5461 DH 05/02/22
  getEditableAccess(): void {
     var aQueryCriteria: string = encodeURIComponent(this.theCSUId+ "#" + CaseUtils.getServiceDatabaseId());
    this.dsamsRestfulService.getEditableAccess(aQueryCriteria)
    .pipe(tap(result => console.log("result=" + result, "queryCriteria=" + decodeURIComponent(aQueryCriteria))))
    .subscribe(result => {
      if (result == 1) this.isEditRightAccessGranted = true;
      else {
        this.isEditRightAccessGranted = false;
        this.caseUIService.setIsOptionsMenuHidden(true);
      }
    });
  }
  //end DSAMS-5461 DH 05/02/22

  //breakout logic per sonarqube
  getLinkCaseDataOnInit() {
    if (!!this.activatedRoute.snapshot.queryParamMap.get(LinkCaseDataClass.theLinkCaseData)) {
      this.dataSharingService.breadcrumbForNewPage.next(LinkCaseDataClass.theLinkCaseData);
      this.getLinkCaseDataForNewPage();
    }
  }

  initializeAttachmentsDTO() {
    this.aAttachmentsDTO = {
      iconImg: 'arrow_drop_down',
      case_ATTACHMENT_ID: 0,
      //attachment_CASE_VERSION_ID: 0,
      //attachment_CASE_ID: 0,
      case_ATTACHMENT_NUMBER_ID: 1,
      case_ATTACHMENT_OFFICIAL_TITLE: '',
      case_ATTACHMENT_TX: '',
      attachment_LAST_UPDATED_DT: '',
      status: EntityStatus.ENT_UNCHANGED.toString(),
      versionTypeData: [],
      isAtchNoDisabled: true
    }
  }

  // Destroy any non-HTTP subscriptions.
  ngOnDestroy(): void {

    if (this.caseUIServiceSubscription) {
      this.caseUIServiceSubscription.unsubscribe();
      this.caseUIServiceSubscription = null;
    }
    if (this._caseUIServiceSubscription) {
      this._caseUIServiceSubscription.unsubscribe();
      this._caseUIServiceSubscription = null;
    }
    if (this.editSubscription) {
      this.editSubscription.unsubscribe();
      this.editSubscription = null;
    }

  }

  /* --------------------------------------------------------------------------
 This function sets the text decription of the Expand/Collapse button 
 respectively to their panel open or close status 
 ----------------------------------------------------------------------------- */
  changeExpandCollapseBtnAction() {
    if (this.expandPanelBtnBehavior === caseConstants.collapseAll) {
      this.expandPanelBtnBehavior = caseConstants.expandAll;
      this.panelRequirementsOpenState = false;
      this.panelSummaryOpenState = false;
      this.panelAttachmentsOpenState = false;
      this.resetAllButtonColors();
    } else {
      this.expandPanelBtnBehavior = caseConstants.collapseAll;
      this.panelRequirementsOpenState = true;
      this.panelSummaryOpenState = true;
      this.panelAttachmentsOpenState = true;
      this.highlightAllButtonColors();
    }
  }

  /* --------------------------------------------------------------------------
     This function resets the background color of all panel buttons to the 
     initial color
     ----------------------------------------------------------------------------- */
  resetAllButtonColors() {
    this.summaryBgBtnColor = caseConstants.initalButtonBgColor;
    this.requirementBgBtnColor = caseConstants.initalButtonBgColor;
    this.attachmentBgBtnColor = caseConstants.initalButtonBgColor;
    this.boldSummaryBtnFont = "";
    this.boldRequirementBtnFont = "";
    this.boldAttachmentBtnFont = "";
  }

  /* --------------------------------------------------------------------------
    This function resets the background color of all panel buttons to the 
    active color
    ----------------------------------------------------------------------------- */
  highlightAllButtonColors() {
    this.summaryBgBtnColor = caseConstants.highlightedBtnColor;
    this.requirementBgBtnColor = caseConstants.highlightedBtnColor;
    this.attachmentBgBtnColor = caseConstants.highlightedBtnColor;
    this.boldAttachmentBtnFont = caseConstants.fontBold;
    this.boldRequirementBtnFont = caseConstants.fontBold;
    this.boldSummaryBtnFont = caseConstants.fontBold;
  }

  /* --------------------------------------------------------------------------
  This function changes the background color of the panel buttons 
  ----------------------------------------------------------------------------- */
  setButtonColorPanel(event: Event) {
    let elementId: string = (event.currentTarget as Element).id;
    switch (elementId) {
      case "AttachmentsPanelBtn":
        {
          if (this.attachmentBgBtnColor === caseConstants.initalButtonBgColor) {
            this.attachmentBgBtnColor = caseConstants.highlightedBtnColor;
            this.outlineBtnColor = caseConstants.outlineClickBtnColor;
            this.boldAttachmentBtnFont = caseConstants.fontBold;
          }
          else {
            this.attachmentBgBtnColor = caseConstants.initalButtonBgColor;
            this.outlineBtnColor = caseConstants.outlineUnClickBtnColor;
            this.boldAttachmentBtnFont = "";
          }
          break;
        }
    }
  }

  /**
  * Subscribe to edit mode so we can toggle components on and off (currently only the save button.)
  */
  subscribeToEdit() {
    if (!this.editSubscription) {
      this.editSubscription = this.caseUIService.caseEditService.subscribe((pEditResult: IEditResponseType) => {
        if (!!pEditResult && pEditResult.ID === AttachmentsDashboardComponent.ATTACHMENTS_EDITOR) {
          this.isEditMode = pEditResult.editToggle;
        }
      });
    }
  }

  //Jira DSAMS-5346 DH 04/22
  getLinkCaseDataForNewPage() {
    let linkCaseData = LinkCaseDataClass.getTheLinkCaseData(this.activatedRoute);
    if (!!linkCaseData) {
      sessionStorage.setItem(DsamsConstants.SESSION_SDB_ID, linkCaseData.serviceDbId);
      this.caseRelatedInfoData = {
        case_ID: linkCaseData.case_ID,
        working_CASE_VERSION_ID: linkCaseData.case_VERSION_ID,
        case_VERSION_ID: linkCaseData.case_VERSION_ID.toString(),
        customer_ORGANIZATION_ID: linkCaseData.customer_ORGANIZATION_ID,
        case_MASTER_STATUS_CD: linkCaseData.case_MASTER_STATUS_CD,
        wm_CASE_VERSION_STATUS_CD: linkCaseData.wm_CASE_VERSION_TYPE_CD,
        case_USAGE_INDICATOR_CD: linkCaseData.case_USAGE_INDICATOR_CD,
      }
      this.caseLineRelatedInfoData = {
        case_ID: linkCaseData.case_ID,
        case_VERSION_STATUS_CD: linkCaseData.case_VERSION_STATUS_CD,
        case_VERSION_TYPE_CD: linkCaseData.case_VERSION_TYPE_CD,
        security_ASSISTANCE_PROGRAM_CD: linkCaseData.security_ASSISTANCE_PROGRAM_CD,
        user_CASE_ID: linkCaseData.user_CASE_ID,
        case_VERSION_NUMBER_ID: linkCaseData.case_VERSION_NUMBER_ID,
      }
      //emit updated case/case line info data 
      this.caseUIService.setCaseLineRelatedInfoValues(this.caseLineRelatedInfoData);
      this.caseUIService.setCaseRelatedInfoValues(this.caseRelatedInfoData);
    }
  }
  ngAfterViewInit() {
    this.caseUIService.submitBreadcrumbTitleChangeRequest("Attachment List");
  }
}
