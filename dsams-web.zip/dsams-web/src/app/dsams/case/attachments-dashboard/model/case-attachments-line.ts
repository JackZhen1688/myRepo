import * as internal from "assert";
import { ifaceCaseLineEntity } from '../../model/case-line-model';

export interface attachmentsLineModel {
    entityName?: string;
    status?: string;
    isDataChanged?: boolean;

    iconImg?: string;
    lineSubline?: string;
    lineStatus?: string; 
    masl?: string;
    quantity?: string; 
    unitOfIssue?: string;
    change_ACTION_CD?:string;

    related_CASE_ID?:number;
    case_ID?:number;
    working_CASE_ID?:number;
    related_CASE_VERSION_ID?:string;
    working_CASE_VERSION_ID?:string;
    related_CASE_ATTACHMENT_ID?:number;
    case_MASTER_LINE_ID?:number;

    theCaseLine?: ifaceCaseLineEntity;
    CASE_LINE_DATA?: ifaceCaseLineEntity;
    lockSessionId?: string;
}