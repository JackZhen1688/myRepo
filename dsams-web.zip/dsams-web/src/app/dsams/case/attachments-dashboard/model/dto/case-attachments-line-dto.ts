import { attachmentsLineModel } from "../case-attachments-line";

export interface attachmentsLineDto extends attachmentsLineModel {
    
}
