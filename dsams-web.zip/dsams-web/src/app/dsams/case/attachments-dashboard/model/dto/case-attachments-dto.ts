import { attachmentsModel } from "../case-attachments";
import { IVersionType } from "../version-type";
import { FieldDisabledMap } from "src/app/dsams/case/model/field-disabled-map";

export interface attachmentsDto extends attachmentsModel {
    versionTypeData?: IVersionType[];
    isFieldDisabled?: FieldDisabledMap;
    isRestateDisabled?: boolean,
    isAtchNoDisabled?: boolean,
    isAtchTypeDisabled?: boolean,
    isAtchTextDisabled?: boolean,
    isAtchPageDisabled?: boolean
}
