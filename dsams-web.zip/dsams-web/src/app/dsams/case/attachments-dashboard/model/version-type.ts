export interface IVersionType {
    caseVersionTypeCd?: string,
    caseVersionNumberId?: number,
    caseAttachmentTx?: string

}