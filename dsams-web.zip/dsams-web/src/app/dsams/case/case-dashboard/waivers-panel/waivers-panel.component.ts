/* This case waivers class contains the business logic and functions 
  for the Case Waivers panel.
  Author: David Huynh 
  Date:   03/02/2020 
*/

import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { DateAdapter, MAT_DATE_FORMATS } from '@angular/material';
import { MatTableDataSource } from '@angular/material/table';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { CaseRestfulService } from '../../services/case-restful.service';
import { Subscription } from 'rxjs';
import { CaseUIService } from '../../services/case-ui-service';
import { DsamsConstants } from 'src/app/dsams/dsams.constants';
import { CaseUtils } from '../../utils/case-utils';
import { ReferenceDataType } from '../../model/reference-data-type';
import { PanelExpansionProperties } from '../../model/panel-expansion-properties';
import { MdePopoverTrigger } from '@material-extended/mde';
import { AppDateAdapter, APP_DATE_FORMATS } from '../../utils/app-date-adapter';
import { ICaseVersion } from '../../model/dto/icase-version';
import { ICaseVersionWaiver } from '../../model/dto/case-version-waiver';
import { FieldDisabledMap } from '../../model/field-disabled-map';
import { SaveResultsType } from '../../validation/save-results-type';
import { Validators } from '@angular/forms';
import { NamedFormControl } from '../../validation/named-form-control';
import { DateValidator } from '../../validation/date-validator';
import { CaseWaiversValidator } from '../../validation/case-waivers-validator';
import { IEditResponseType } from '../../model/edit-response-type';
import { CaseSaveInfo } from '../../model/case-save-info';

declare function focusItem(pItem: string): any;

export class waiverConstants {
  static readonly iconImageArrowUp = "arrow_drop_up";
  static readonly iconImageArrowDown = "arrow_drop_down";
}

export interface theWaiverArrayType {
  iconImg: string;
  waiver_TYPE_ID: string;
  ipc_NUMBER_ID: string;
  status: number;
  case_WAIVER_PERCENT_RT: any;
  case_WAIVER_PERCENT_RT_shadow: number;  // Needed to keep the decimal from getting dropped.
  case_VERSION_WAIVER_EFFECT_DT: Date;
  case_VERSION_WAIVER_EXPIRAT_DT: Date;
  case_VERSION_WAIVER_EXPIRAT_DT_shadow: string;  // Stores string value to check for invalid date.
  case_VERSION_WAIVER_EFFECT_DT_orig: Date;
  case_VERSION_WAIVER_EXPIRAT_DT_orig: Date;
  copy_WAIVER_IN: boolean;
  case_WAIVER_JUSTIFICATION_TX: string;
  rowNum: number;
  case_ID: number;
  case_VERSION_ID: number;
  case_VERSION_WAIVER_ID: number,
  br_IPC_DISABLED: boolean;
  br_IPC_REQUIRED: boolean;
  br_WAIVER_EFFECT_DT_DISABLED: boolean;
  br_WAIVER_EXPIRAT_DT_DISABLED: boolean;
  br_WAIVER_EFFECT_DT_REQUIRED: boolean;
  effDateFormControl: NamedFormControl;
  expDateFormControl: NamedFormControl;
}

@Component({
  selector: 'app-waivers-panel',
  templateUrl: './waivers-panel.component.html',
  styleUrls: ['./waivers-panel.component.css',
    '../common-CSS.component.css'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0', minHeight: '0', display: 'none' })),
      state('expanded', style({ height: '*' })),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
  providers: [
    { provide: DateAdapter, useClass: AppDateAdapter },
    { provide: MAT_DATE_FORMATS, useValue: APP_DATE_FORMATS }
  ]
})


export class WaiversPanelComponent implements OnInit, OnDestroy {
  aWaiverArrayType: theWaiverArrayType[] = [];
  private _caseUIServiceSubscription: Subscription;
  dataSourceWaivers = new MatTableDataSource(this.aWaiverArrayType);
  private _reloadData: boolean = true;
  private _reloadReferenceData: boolean = true;
  aWaiverRowIndex: number = 1;
  private _pnlExpansionProperties: PanelExpansionProperties;
  private _saveSubscription: Subscription = null;
  private _dataSubscription: Subscription;
  private _caseVersionData: ICaseVersion;
  private fieldDisabledMap: FieldDisabledMap = {};
  private _editSubscription: Subscription = null;
  private _saveCompleteSubscription: Subscription = null;
  private _newModeInfoSubscription: Subscription = null;
  private _panelCollapedSubscription: Subscription = null;
  private _casePanelStatusQuerySubscription: Subscription = null;
  refWaiverTypeList: Array<ReferenceDataType> = [];
  refIPCList: Array<ReferenceDataType> = [];
  private _isGotInfoFromCIPanel: boolean = false;
  private _currentToggle:boolean = false;
  private _alreadyToggledOn: boolean = false;
  private _skipSavePanel:boolean = false;
  private _somethingChanged:boolean = false;

  // Form controls
  FIELD_REQUIRED_MSG: string = DsamsConstants.FIELD_REQUIRED_MSG;
  EFF_DATE_STR: string = "Effective Date";
  EXP_DATE_STR: string = "Expiration Date";

  // Deleted waivers list.
  deltedWaiversList:Array<any>;

  @ViewChild(MdePopoverTrigger, { static: true }) trigger: MdePopoverTrigger;
  popBooleanValue: boolean;

  popOverTrigger() {
    this.trigger.togglePopover();
  }

  getFreshWaiverObject(): theWaiverArrayType {
    return {
      iconImg: "arrow_drop_down",
      status: DsamsConstants.ENT_NEW,
      waiver_TYPE_ID: "",
      ipc_NUMBER_ID: "",
      copy_WAIVER_IN: false,
      case_WAIVER_PERCENT_RT: "",
      case_WAIVER_PERCENT_RT_shadow: 0,
      case_VERSION_WAIVER_EFFECT_DT: null,
      case_VERSION_WAIVER_EXPIRAT_DT: null,
      case_VERSION_WAIVER_EXPIRAT_DT_shadow: "",
      case_VERSION_WAIVER_EFFECT_DT_orig: null,
      case_VERSION_WAIVER_EXPIRAT_DT_orig: null,
      case_WAIVER_JUSTIFICATION_TX: "",
      rowNum: 0,
      case_ID: 0,
      case_VERSION_ID: 0,
      case_VERSION_WAIVER_ID: 0,
      br_IPC_DISABLED: false,
      br_IPC_REQUIRED: false,
      br_WAIVER_EFFECT_DT_DISABLED: false,
      br_WAIVER_EXPIRAT_DT_DISABLED: false,
      br_WAIVER_EFFECT_DT_REQUIRED: false,
      effDateFormControl: new NamedFormControl(this.EFF_DATE_STR, '', [DateValidator.validateRegularDate]),
      expDateFormControl: new NamedFormControl(this.EXP_DATE_STR, '', [DateValidator.validateRegularDate])
    };
  }


  columnsToDisplayWaivers = ['Waiver', 'IPC', 'PercentRate', 'EffectiveDate', 'ExpirationDate', 'CopyWaiver', 'DeleteRow'];
  expandedElement: null;

  constructor(private caseRestService: CaseRestfulService,
    private caseUIService: CaseUIService) {
  }

  ngOnInit() {
    // Only fetch data when the panel is opened.
    this._caseUIServiceSubscription = this.caseUIService.panelExpanded.subscribe(
      {
        next: (pnlExpansionProperties: PanelExpansionProperties) => {
          if (pnlExpansionProperties.panelName === DsamsConstants.CASE_PANEL_WAIVERS ||
            pnlExpansionProperties.panelName === DsamsConstants.CASE_PANEL_ALL) {
            this._pnlExpansionProperties = pnlExpansionProperties;
            this.fetchReferenceData();
            this.subscribeToDataService();
            this.subscribeToValidateOrSaveRequest();
            this.subscribeToEdit();
            if (this._pnlExpansionProperties.isNewMode) {
              this._currentToggle = true;
              this.enableOrDisableEverything(this._currentToggle);
            }
            this.subscribeToSaveComplete();
            this.subscribeToNewModeInfo();
            this.subscribeToPanelCollapsed();
            this.subscribeToCasePanelStatusQuery();
            this._skipSavePanel = false;            
          }
        }
      });
  }


  ngOnDestroy() {
    this._caseUIServiceSubscription.unsubscribe();
    if (!!this._dataSubscription) {
      this._dataSubscription.unsubscribe();
      this._dataSubscription = null;
    }
    if (!!this._saveSubscription) {
      this._saveSubscription.unsubscribe();
      this._saveSubscription = null;
    }
    if (!!this._editSubscription) {
      this._editSubscription.unsubscribe();
      this._editSubscription = null;
    }
    if (!!this._saveCompleteSubscription) {
      this._saveCompleteSubscription.unsubscribe();
      this._saveCompleteSubscription = null;
    }
    if (!!this._newModeInfoSubscription) {
      this._newModeInfoSubscription.unsubscribe();
      this._newModeInfoSubscription = null; 
    }
    if (!!this._panelCollapedSubscription) {
      this._panelCollapedSubscription.unsubscribe();
      this._panelCollapedSubscription = null;
    }
    if (!!this._casePanelStatusQuerySubscription) {
      this._casePanelStatusQuerySubscription.unsubscribe();
      this._casePanelStatusQuerySubscription = null;
    }      
  }

  
  // Subscribe to panel collapsing
  subscribeToPanelCollapsed() {
    if (!this._panelCollapedSubscription) {
      this._panelCollapedSubscription = this.caseUIService.panelCollapsed.subscribe((panelName: string) => {
        if (panelName === DsamsConstants.CASE_PANEL_WAIVERS || panelName === DsamsConstants.CASE_PANEL_ALL) 
        {
           this._skipSavePanel = true;
        }
      });
    }
  }


  // Subscribe to request for panel status.
  subscribeToCasePanelStatusQuery() {
    if (!this._casePanelStatusQuerySubscription) {
      this._casePanelStatusQuerySubscription = this.caseUIService.getPanelCaseVersionStatusQuerySubscription().subscribe(() => {   
        let wvFormArray: Array<any> = this.dataSourceWaivers.data;
        if (!!wvFormArray) {
          for (let i = 0; i < wvFormArray.length; i++) {
            if (DateValidator.dateToString(wvFormArray[i].case_VERSION_WAIVER_EFFECT_DT) !== DateValidator.dateToString(wvFormArray[i].case_VERSION_WAIVER_EFFECT_DT_orig) ||
                DateValidator.dateToString(wvFormArray[i].case_VERSION_WAIVER_EXPIRAT_DT) !== DateValidator.dateToString(wvFormArray[i].case_VERSION_WAIVER_EXPIRAT_DT_orig)) 
            {
              this.setChanged(wvFormArray[i]);
            }
          }
        }    
        let currStatus:number = this._somethingChanged?DsamsConstants.ENT_CHANGED:DsamsConstants.ENT_UNCHANGED;
        currStatus = (this._pnlExpansionProperties.isNewMode && !!this.dataSourceWaivers.data && this.dataSourceWaivers.data.length > 0)?DsamsConstants.ENT_NEW:currStatus;
        this.caseUIService.panelCaseVersionStatusResponseSubscriptionNext(DsamsConstants.CASE_PANEL_WAIVERS,
                                                                          currStatus,
                                                                          this._pnlExpansionProperties.caseRequestParams.caseId,
                                                                          this._pnlExpansionProperties.caseRequestParams.caseVersionId);
      });
    }
  }  


  /* Toggle the enabledness and disabledness of the fields based on what the user selects in waiver dropdown. */
  toggleWaiverFieldProperties(pNewWaiverId: string, pElement: any) {
    pElement.waiver_TYPE_ID = pNewWaiverId;
    const waiverType1: boolean = (pElement.waiver_TYPE_ID === "1");
    pElement.br_IPC_DISABLED = !waiverType1;
    pElement.br_IPC_REQUIRED = waiverType1;
    pElement.br_WAIVER_EFFECT_DT_DISABLED = waiverType1;
    pElement.br_WAIVER_EXPIRAT_DT_DISABLED = waiverType1;
    pElement.br_WAIVER_EFFECT_DT_REQUIRED = !waiverType1;

    // Need to save off the previous effective date because it gets blanked out with the form control change.
    let holdEffDt: Date = null;
    if (!!pElement["case_VERSION_WAIVER_EFFECT_DT"] && pElement["case_VERSION_WAIVER_EFFECT_DT"] !== "") {
      holdEffDt = new Date(pElement["case_VERSION_WAIVER_EFFECT_DT"]);
    }
    pElement.effDateFormControl = pElement.br_WAIVER_EFFECT_DT_REQUIRED ? new NamedFormControl(this.EFF_DATE_STR, '', [Validators.required, DateValidator.validateRegularDate]) :
      new NamedFormControl(this.EFF_DATE_STR, '', [DateValidator.validateRegularDate]);
    if (!!holdEffDt) {
      pElement["case_VERSION_WAIVER_EFFECT_DT"] = holdEffDt;
    }

    if (waiverType1 ||
      pElement.waiver_TYPE_ID === "2" ||
      pElement.waiver_TYPE_ID === "3" ||
      pElement.waiver_TYPE_ID === "15" ||
      pElement.waiver_TYPE_ID === "TLA") {
      pElement.copy_WAIVER_IN = true;
    }
  }

  // Set the waiver status to changed if it's unchanged.
  setChanged(pElement:any) {
    if (pElement.status == DsamsConstants.ENT_UNCHANGED) {
      pElement.status = DsamsConstants.ENT_CHANGED;
    }    
    this._somethingChanged = true;
    this.caseUIService.theComponentSaveState[CaseUIService.SAVE_CASE_DETAILS_STATE].isDataChanged = true;    
  }

  setChangedJustificationTx(pElement:any, pTxt:string) {
    this.setChanged(pElement);
    pElement.case_WAIVER_JUSTIFICATION_TX = pTxt;
  }

  // This makes sure the underlaying object gets populated with what the user checked.
  // This is needed because working with checkboxes can be tricky.
  clickCheckboxWaiver(pEvent: any, pRowElement: any) {
    const rowN: number = this.dataSourceWaivers.data.indexOf(pRowElement);
    this.dataSourceWaivers.data[rowN].copy_WAIVER_IN = pEvent.checked;
    this.setChanged(pRowElement);
  }

  /* This procedure is used to add a new row to the case waiver list. */
  addNewWaiverItem() {
    this.aWaiverRowIndex++;
    let newWaiverObject: theWaiverArrayType = this.getFreshWaiverObject();
    newWaiverObject.rowNum = this.aWaiverRowIndex;
    newWaiverObject.status = DsamsConstants.ENT_NEW;
    this.dataSourceWaivers.data.push({ ...newWaiverObject });
    this.dataSourceWaivers = new MatTableDataSource(this.dataSourceWaivers.data);
    this.dataSourceWaivers._updateChangeSubscription();
    this._somethingChanged = true;
    this.caseUIService.theComponentSaveState[CaseUIService.SAVE_CASE_DETAILS_STATE].isDataChanged = true;
    focusItem("ddlWAIVER_TYPE_ID" + +this.aWaiverRowIndex);
  }

  /* This procedure checks the returned result value from the 
     popover Yes/No dialog window. */
  yesButtonOnClick(isDeleteConfirmed: any, rowElement: any) {
    if (isDeleteConfirmed)
      this.delWaiverItem(rowElement);
   }

  /* This procedure is used to remove the row from the case waiver list. */
  delWaiverItem(rowElement: any) {
    this.deltedWaiversList.push(rowElement);
    this.dataSourceWaivers.data.splice(this.dataSourceWaivers.data.indexOf(rowElement), 1);
    this.dataSourceWaivers = new MatTableDataSource(this.dataSourceWaivers.data);
    this._somethingChanged = true;
    this.caseUIService.theComponentSaveState[CaseUIService.SAVE_CASE_DETAILS_STATE].isDataChanged = true;
  }

  // Change percent rate
  // Need to save it to the shadow percent rate because otherwise the decimal gets dropped (because of format mask).
  changePctRate(rowElement: any) {
    const rawRate: number = +(<HTMLInputElement>document.getElementById('case_WAIVER_PERCENT_RT' + rowElement["rowNum"])).value;
    rowElement["case_WAIVER_PERCENT_RT_shadow"] = rawRate;
  }


  // Change Pct Rate
  changeExpDate(rowElement: any) {
    const newExpDate: string = (<HTMLInputElement>document.getElementById('case_VERSION_WAIVER_EXPIRAT_DT' + rowElement["rowNum"])).value;
    rowElement["case_VERSION_WAIVER_EXPIRAT_DT_shadow"] = newExpDate;
  }


  /* This function is used to return the string dattype of
     the icon image string. */
  getIconImage(object: theWaiverArrayType) {
    return (object.iconImg);
  }


  fieldDisabled(pFieldName: string): boolean {
    // console.log("Fld=" + pFieldName + " isdisabled=" + CaseUtils.isFieldDisabled(this.fieldDisabledMap, DsamsConstants.CASE_PANEL_WAIVERS, pFieldName));
    return CaseUtils.isFieldDisabled(this.fieldDisabledMap, DsamsConstants.CASE_PANEL_WAIVERS, pFieldName);
  }


  // Date validator for effective date.  
  performCheckForEffDate(pIndex: number): string {
    const effDateElem = <HTMLInputElement>document.getElementById('case_VERSION_WAIVER_EFFECT_DT' + +pIndex);
    if (!effDateElem) {
      return DsamsConstants.NO_ERROR;
    }
    let effDateStr: string = effDateElem.value;
    // Using the control to get the message does not work.
    if (!DateValidator.isItADate(effDateStr)) {
      return "Date is invalid.";
    }
    return "Field is required.";  // Only other error it could be.    
  }


  // Date validator for expiration date.
  performCheckForExpDate(pIndex: number): string {
    const expDateElem = <HTMLInputElement>document.getElementById('case_VERSION_WAIVER_EXPIRAT_DT' + +pIndex);
    if (!expDateElem) {
      return DsamsConstants.NO_ERROR;
    }
    const expDateStr: string = expDateElem.value;
    if (!DateValidator.isItADate(expDateStr)) {
      return "Date is invalid.";
    }
    return DsamsConstants.NO_ERROR;  // Nothing else it could be.
  }


  /* This procedure changes the up or down arrow icon based on the 
     user selection. */
  changeIconImages(rowElement: any) {
    let rowN: number = this.dataSourceWaivers.data.indexOf(rowElement);
    var str: string = ((this.dataSourceWaivers.data[rowN]).iconImg);
    this.expandedElement === rowElement ? this.expandedElement = null : this.expandedElement = rowElement;
    if (!!this.expandedElement) {
      focusItem("txtCASE_WAIVER_JUSTIFICATION_TX" + +this.aWaiverRowIndex);
    }
    if (str == waiverConstants.iconImageArrowDown) {
      (this.dataSourceWaivers.data[rowN]).iconImg = waiverConstants.iconImageArrowUp;
    }
    else {
      (this.dataSourceWaivers.data[rowN]).iconImg = waiverConstants.iconImageArrowDown;
    }
  }

  isBasicOrModOrAmendCase(): boolean {
    return CaseUtils.isBasicOrModOrAmendCase(this._caseVersionData.case_VERSION_TYPE_CD.toUpperCase());
  }

  isImpCaseVersionStatus(): boolean {
    return CaseUtils.isImpCaseVersionStatus(this._caseVersionData.case_VERSION_TYPE_CD.toUpperCase());
  }

  // Subscribe to edit toggle event
  subscribeToEdit() {
    if (!this._editSubscription) {
      this._editSubscription = this.caseUIService
        .caseEditService
        .subscribe((pResponse: IEditResponseType) => {
            if (
                (pResponse && (pResponse.ID === DsamsConstants.CASE_VERSION_EDITOR || pResponse.ID === DsamsConstants.PAGE_CASE_DETAIL) && this.isBasicOrModOrAmendCase()) || 
                (this.isImpCaseVersionStatus() && this.caseUIService.milestoneAddService.getValue() === "UPDTCASE")
              ) 
            {
              this.enableOrDisableEverything(pResponse.editToggle);
              this._currentToggle = pResponse.editToggle; 
              if (this._currentToggle) {
                this._alreadyToggledOn = true;
              }
            }
          },
          err => {
            CaseUtils.ReporError("Error in waivers panel responding to edit toggle");
          }
        );
    }
  }


  // Enable or Disable everything on the panel.
  enableOrDisableEverything(pEnable: boolean) {
    let l_isEnabled: boolean = this._pnlExpansionProperties.isNewMode ? true : pEnable;
    this.fieldDisabledMap[DsamsConstants.CASE_PANEL_WAIVERS] = !l_isEnabled;
    if (l_isEnabled) {
      this.initializePanelFields();
    }
  }


  // Set fields to enabled and disabled according to business rules.
  initializePanelFields() {
    // No special rules for individual fields on waivers panel.
  }


  // ************************************** REST API Calls ********************************************

  fetchReferenceData() {
    if (this._reloadReferenceData) {
      // Reference: Waiver Type
      this.caseRestService
        .getReferenceData(DsamsConstants.REF_WAIVER_TYPE, "", 0, true)
        .subscribe(
          data => {
            this.refWaiverTypeList = data;
          },
          err => {
            CaseUtils.ReportHTTPError(err, "Error fetching reference for " + DsamsConstants.REF_WAIVER_TYPE);
          }
        );

      // Reference: IPC Number
      this.caseRestService
        .getReferenceData(DsamsConstants.REF_INDIRECT_PRICING_COMPONENT, "", 0, true)
        .subscribe(
          data => {
            this.refIPCList = data;
          },
          err => {
            CaseUtils.ReportHTTPError(err, "Error fetching reference for " + DsamsConstants.REF_INDIRECT_PRICING_COMPONENT);
          }
        );
      this._reloadReferenceData = false;
    }
  }

  /**
   * Subscribe to validate or save.
   */
  subscribeToDataService() {
    if (!this._dataSubscription) {
      this._dataSubscription = this.caseUIService.caseDetailData.subscribe(
        {
          next: (caseDetailData: ICaseVersion) => {
            if (caseDetailData) {
              this._caseVersionData = caseDetailData;
              CaseUtils.populateCaseRequestParamsType(this._pnlExpansionProperties.caseRequestParams, this._caseVersionData);
              const waiverList: Array<ICaseVersionWaiver> = this._caseVersionData.caseVersionWaiverCaseIdList;
              this.dataSourceWaivers.data = [];
              this.deltedWaiversList = [];
              this.enableOrDisableEverything(this._currentToggle);
              for (var i = 0; i < waiverList.length; i++) {
                const pctRateStr = waiverList[i].case_WAIVER_PERCENT_RT === -1 ? "" : +(waiverList[i].case_WAIVER_PERCENT_RT * 100);                
                this.dataSourceWaivers.data[i] =
                {
                  iconImg: "arrow_drop_down",
                  status: DsamsConstants.ENT_UNCHANGED,
                  waiver_TYPE_ID: CaseUtils.nullFix(waiverList[i].waiver_TYPE_ID),
                  ipc_NUMBER_ID: CaseUtils.nullFix(waiverList[i].ipc_NUMBER_ID),
                  copy_WAIVER_IN: waiverList[i].copy_WAIVER_IN,
                  case_WAIVER_PERCENT_RT: pctRateStr,
                  case_WAIVER_PERCENT_RT_shadow: pctRateStr === "" ? 0 : +pctRateStr,
                  case_VERSION_WAIVER_EFFECT_DT: CaseUtils.numberToDate(waiverList[i].case_VERSION_WAIVER_EFFECT_DT),
                  case_VERSION_WAIVER_EXPIRAT_DT: CaseUtils.numberToDate(waiverList[i].case_VERSION_WAIVER_EXPIRAT_DT),
                  case_VERSION_WAIVER_EXPIRAT_DT_shadow: DateValidator.dateToString(CaseUtils.numberToDate(waiverList[i].case_VERSION_WAIVER_EXPIRAT_DT)),
                  case_VERSION_WAIVER_EFFECT_DT_orig: CaseUtils.numberToDate(waiverList[i].case_VERSION_WAIVER_EFFECT_DT),
                  case_VERSION_WAIVER_EXPIRAT_DT_orig: CaseUtils.numberToDate(waiverList[i].case_VERSION_WAIVER_EXPIRAT_DT),
                  case_WAIVER_JUSTIFICATION_TX: waiverList[i].case_WAIVER_JUSTIFICATION_TX,
                  rowNum: i + 1,
                  case_ID: waiverList[i].case_ID,
                  case_VERSION_ID: waiverList[i].case_VERSION_ID,
                  case_VERSION_WAIVER_ID: waiverList[i].case_VERSION_WAIVER_ID,
                  br_IPC_DISABLED: (<boolean>CaseUtils.getBusinessRuleMapValue(waiverList[i].businessRuleMap, "IPC_DISABLED", false)),
                  br_IPC_REQUIRED: (<boolean>CaseUtils.getBusinessRuleMapValue(waiverList[i].businessRuleMap, "IPC_REQUIRED", false)),
                  br_WAIVER_EFFECT_DT_DISABLED: (<boolean>CaseUtils.getBusinessRuleMapValue(waiverList[i].businessRuleMap, "WAIVER_EFFECT_DT_DISABLED", false)),
                  br_WAIVER_EXPIRAT_DT_DISABLED: (<boolean>CaseUtils.getBusinessRuleMapValue(waiverList[i].businessRuleMap, "WAIVER_EXPIRAT_DT_DISABLED", false)),
                  br_WAIVER_EFFECT_DT_REQUIRED: (<boolean>CaseUtils.getBusinessRuleMapValue(waiverList[i].businessRuleMap, "WAIVER_EFFECT_DT_REQUIRED", false)),
                  effDateFormControl: (<boolean>CaseUtils.getBusinessRuleMapValue(waiverList[i].businessRuleMap, "WAIVER_EFFECT_DT_REQUIRED", false)) ? new NamedFormControl(this.EFF_DATE_STR, '', [Validators.required, DateValidator.validateRegularDate]) : new NamedFormControl(this.EFF_DATE_STR, '', [DateValidator.validateRegularDate]),
                  expDateFormControl: new NamedFormControl(this.EXP_DATE_STR, '', [DateValidator.validateRegularDate]),
                }
              }
              this.aWaiverRowIndex = waiverList.length;
              this.dataSourceWaivers = new MatTableDataSource(this.dataSourceWaivers.data);
              this._isGotInfoFromCIPanel = false;          
            }
          }
        }
      );
    }
  }

  // ******************************** Validations ******************************************

  // Subcsribe to validate or save request.
  subscribeToValidateOrSaveRequest() {
    if (!this._saveSubscription) {
      this._saveSubscription = this.caseUIService.saveRequest.subscribe((pSkipValidation:boolean) => {
        if (!this._skipSavePanel) {
          let svResults: SaveResultsType = this.savePanel(pSkipValidation);
          this.caseUIService.saveReturnRequest.next(svResults);
        }
      });
    }
  }

  // Do a validate/save (just a validate for now)
  savePanel(pSkipValidation:boolean): SaveResultsType {
    let valResults: SaveResultsType = new SaveResultsType();
    valResults.currentPanel = DsamsConstants.CASE_PANEL_WAIVERS;
    if (!pSkipValidation) {
      valResults = CaseWaiversValidator.validateCustomerRequestPanel
                                                (this.dataSourceWaivers.data,
                                                this._pnlExpansionProperties);      
    }
    let svResults: SaveResultsType = new SaveResultsType();
    svResults.currentPanel = valResults.currentPanel;
    svResults.messageList = valResults.messageList;

  if (svResults.isValidationSuccessful()) {
    const currCaseId:number = this._pnlExpansionProperties.caseRequestParams.caseId;
    const currCaseVersionId:number = this._pnlExpansionProperties.caseRequestParams.caseVersionId;
    let cvEntity:ICaseVersion = {status:DsamsConstants.ENT_UNCHANGED};
    let wvArray: Array<ICaseVersionWaiver> = [];
    let somethingChanged:boolean = false;
    //
    // Waivers (changed and new)
    //
    let wvFormArray: Array<any> = this.dataSourceWaivers.data;
    if (!!wvFormArray) {
      for (let i = 0; i < wvFormArray.length; i++) {
        // Check CVW dates against original.
        if (DateValidator.dateToString(wvFormArray[i].case_VERSION_WAIVER_EFFECT_DT) !== DateValidator.dateToString(wvFormArray[i].case_VERSION_WAIVER_EFFECT_DT_orig)) {
          this.setChanged(wvFormArray[i]);
          wvFormArray[i].case_VERSION_WAIVER_EFFECT_DT_orig = wvFormArray[i].case_VERSION_WAIVER_EFFECT_DT;
        }
        if (DateValidator.dateToString(wvFormArray[i].case_VERSION_WAIVER_EXPIRAT_DT) !== DateValidator.dateToString(wvFormArray[i].case_VERSION_WAIVER_EXPIRAT_DT_orig)) {
          this.setChanged(wvFormArray[i]);
          wvFormArray[i].case_VERSION_WAIVER_EXPIRAT_DT_orig = wvFormArray[i].case_VERSION_WAIVER_EXPIRAT_DT;
        }
        const currStatus: number = wvFormArray[i]["status"];
        if (currStatus != DsamsConstants.ENT_UNCHANGED) {
          somethingChanged = true;
        }
        if (wvFormArray[i].case_WAIVER_PERCENT_RT == null || wvFormArray[i].case_WAIVER_PERCENT_RT.toString() === "")
        {
          // Set to -1 so we know to set to null on back-end;
          wvFormArray[i].case_WAIVER_PERCENT_RT = -1.0;
        }
        let wvEntity:ICaseVersionWaiver = 
          {              
            entityName: "CASE_VERSION_WAIVER",
            status: currStatus,
            case_VERSION_WAIVER_EFFECT_DT: wvFormArray[i].case_VERSION_WAIVER_EFFECT_DT,
            case_VERSION_WAIVER_EXPIRAT_DT: wvFormArray[i].case_VERSION_WAIVER_EXPIRAT_DT,
            case_WAIVER_PERCENT_RT: wvFormArray[i].case_WAIVER_PERCENT_RT,
            case_ID: currCaseId,
            case_VERSION_ID: currCaseVersionId,
            case_VERSION_WAIVER_ID: wvFormArray[i].case_VERSION_WAIVER_ID,
            case_WAIVER_JUSTIFICATION_TX: wvFormArray[i].case_WAIVER_JUSTIFICATION_TX,
            copy_WAIVER_IN: wvFormArray[i].copy_WAIVER_IN,
            ipc_NUMBER_ID: wvFormArray[i].ipc_NUMBER_ID,
            waiver_TYPE_ID: wvFormArray[i].waiver_TYPE_ID
          };     
        wvArray.push(wvEntity);
      }
    }
    //
    // Waivers (deleted)
    //
    wvFormArray = this.deltedWaiversList;
    if (!!wvFormArray) {
      for (let i = 0; i < wvFormArray.length; i++) {
        somethingChanged = true;
        let wvEntity:ICaseVersionWaiver = 
          {              
            entityName: "CASE_VERSION_WAIVER",
            status: DsamsConstants.ENT_DELETED,
            case_VERSION_WAIVER_EFFECT_DT: wvFormArray[i].case_VERSION_WAIVER_EFFECT_DT,
            case_VERSION_WAIVER_EXPIRAT_DT: wvFormArray[i].case_VERSION_WAIVER_EXPIRAT_DT,
            case_WAIVER_PERCENT_RT: wvFormArray[i].case_WAIVER_PERCENT_RT,
            case_ID: currCaseId,
            case_VERSION_ID: currCaseVersionId,
            case_VERSION_WAIVER_ID: wvFormArray[i].case_VERSION_WAIVER_ID,
            case_WAIVER_JUSTIFICATION_TX: wvFormArray[i].case_WAIVER_JUSTIFICATION_TX,
            copy_WAIVER_IN: wvFormArray[i].copy_WAIVER_IN,
            ipc_NUMBER_ID: wvFormArray[i].ipc_NUMBER_ID,
            waiver_TYPE_ID: wvFormArray[i].waiver_TYPE_ID
          };     
        wvArray.push(wvEntity);
      }
    }
    cvEntity.caseVersionWaiverCaseIdList = wvArray;
    if (somethingChanged) {
      cvEntity.status = this._pnlExpansionProperties.isNewMode?DsamsConstants.ENT_NEW:DsamsConstants.ENT_CHANGED;
    }
    svResults.caseVersionPanelData = cvEntity;
    this._isGotInfoFromCIPanel = false;
   }
    return svResults;
  }

  /**
   * Post save actions like setting status to unchanged and setting keys.
   */
   subscribeToSaveComplete() {
      if (!this._saveCompleteSubscription) {
        this._saveCompleteSubscription = this.caseUIService.saveCaseVersionComplete.subscribe((pReturnCaseVersion:ICaseVersion) => { 
          if (!!pReturnCaseVersion) {
            this.caseUIService.theComponentSaveState[CaseUIService.SAVE_CASE_DETAILS_STATE].isDataChanged = false;
            this.caseUIService.theComponentSaveState[CaseUIService.SAVE_CASE_DETAILS_STATE].isSaveConfirmed.next(false);        
            if (this._isGotInfoFromCIPanel) {
              this._isGotInfoFromCIPanel = false;
            }               
            this.deltedWaiversList = [];
            const updatedWaiverList: Array<ICaseVersionWaiver> = !pReturnCaseVersion.caseVersionWaiverCaseIdList?[]:pReturnCaseVersion.caseVersionWaiverCaseIdList.filter(elem => elem.status != DsamsConstants.ENT_DELETED);
            if (!!this.dataSourceWaivers.data) {
              this.dataSourceWaivers.data = this.dataSourceWaivers.data.filter(elem => elem.status != DsamsConstants.ENT_DELETED);
              this.aWaiverRowIndex = this.dataSourceWaivers.data.length;
              for (let i = 0; i < this.aWaiverRowIndex; i++) {
                let updPctRate:string = !updatedWaiverList[i].case_WAIVER_PERCENT_RT?"":updatedWaiverList[i].case_WAIVER_PERCENT_RT.toString();                 
                if (updPctRate === "-1") {
                  updPctRate = null;
                }
                else if (updatedWaiverList[i].status != DsamsConstants.ENT_UNCHANGED) {
                  updPctRate = (+updPctRate * 100).toString();                  
                }
                this.dataSourceWaivers.data[i] = Object.assign (this.dataSourceWaivers.data[i],
                                                                { 
                                                                  rowNum: (i + 1), 
                                                                  status: DsamsConstants.ENT_UNCHANGED,
                                                                  case_VERSION_WAIVER_ID: updatedWaiverList[i].case_VERSION_WAIVER_ID,
                                                                  case_WAIVER_PERCENT_RT: !updPctRate?null:+updPctRate
                                                                });
              }
            }
            else {
              this.aWaiverRowIndex = 0;
            }
            this._pnlExpansionProperties.caseRequestParams.caseId = pReturnCaseVersion.case_ID;
            this._pnlExpansionProperties.caseRequestParams.caseVersionId = pReturnCaseVersion.case_VERSION_ID;          
            this._pnlExpansionProperties.isNewMode = false;
            this._somethingChanged = false;
            this.enableOrDisableEverything(this._currentToggle);
          }
        });
      }
   }

  // Subscribe to new mode info coming from CI panel.
  subscribeToNewModeInfo() {
    if (!this._newModeInfoSubscription) {
      this._newModeInfoSubscription = this.caseUIService.newModeInfo.subscribe((pCSI: CaseSaveInfo) => {    
          this._pnlExpansionProperties.caseRequestParams.caseId = pCSI.case_ID;
          this._pnlExpansionProperties.caseRequestParams.caseVersionId = pCSI.case_VERSION_ID;
          this._pnlExpansionProperties.isNewMode = pCSI.isNewMode;
          this._somethingChanged = false;
          if (!this._alreadyToggledOn) {          
            this._currentToggle = pCSI.isEditable;
            this.enableOrDisableEverything(this._currentToggle); 
          }              
          this._isGotInfoFromCIPanel = false;
      });
    }    
  }   
}