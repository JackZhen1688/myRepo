/* 
 This component is used for handling the business logic
 for displaying the generic Yes/No confirmation dialog window.
 Author: David Huynh
 Date:   05/01/2020 
*/
import { Component, OnInit, EventEmitter, Output } from '@angular/core';
import { CaseUIService } from './../../services/case-ui-service';

@Component({
  selector: 'app-case-buttons',
  templateUrl: './case-buttons.component.html',
  styleUrls: ['./case-buttons.component.css',
  '../common-CSS.component.css']
})


export class CaseButtonsComponent implements OnInit {
  constructor(private popoverData:CaseUIService) { }
  @Output() sendDeleteConfirm = new EventEmitter<boolean>();
  
  ngOnInit() {  
  }

  yesButtonOnClick() {
    this.popoverData.setPopoverBooleanValue(true)
    this.sendDeleteConfirm.emit(true);
  }

  noButtonOnClick() {
    this.sendDeleteConfirm.emit(false);
    this.popoverData.setPopoverBooleanValue(false)
   }

}
