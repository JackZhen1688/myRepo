/* This class is used to handle all business logic for 
   the Case Information panel.
   Date:   03/28/2020 
*/

import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { Subscription } from 'rxjs';
import { MatTableDataSource } from '@angular/material/table';
import { MatDialog, MatSelectChange, DateAdapter, MAT_DATE_FORMATS } from '@angular/material';
import { CaseRestfulService } from '../../services/case-restful.service';
import { DsamsConstants } from 'src/app/dsams/dsams.constants';
import { CaseUIService, CommonReferenceData } from '../../services/case-ui-service';
import { CaseUtils } from '../../utils/case-utils';
import { DsamsMethodsService } from './../../../../dsams/services/dsams-methods.service';
import { ReferenceDataType } from '../../model/reference-data-type';
import { PanelExpansionProperties } from '../../model/panel-expansion-properties';
import { MdePopoverTrigger } from '@material-extended/mde';
import { FieldDisabledMap } from '../../model/field-disabled-map';
import { SaveResultsType } from '../../validation/save-results-type';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { DateValidator } from '../../validation/date-validator';
import { CaseInfoValidator } from '../../validation/case-info-validator';
import { NamedFormControl } from '../../validation/named-form-control';
import { AppDateAdapter, APP_DATE_FORMATS } from '../../utils/app-date-adapter';
import { ICaseMaster } from '../../model/dto/icase-master';
import { ICaseMasterServiceType } from '../../model/dto/case-master-service-type';
import { ICaseVersion } from '../../model/dto/icase-version';
import { ICaseVersionMilestone } from '../../model/dto/case-version-milestone';
import { ICasePersonnelRole } from '../../model/dto/case-personnel-role';
import { ICaseSaleTerm } from '../../model/dto/case-sale-term';
import { IPerson } from '../../model/dto/person';
import { PopPersonComponent } from '../../../utilitis/popups/pop-person/pop-person.component';
import { PopCaseActivityComponent } from '../../../utilitis/popups/pop-case-activity/pop-case-activity.component';
import { MessageMgr } from '../../validation/message-mgr';
import { IEditResponseType } from '../../model/edit-response-type';
import { IActivity } from '../../model/dto/activity';
import { CaseSaveInfo } from '../../model/case-save-info';
import { CaseAmendModChangeInfo } from '../../model/case-amend-mod-change-info';
import { CurrencyPipe } from '@angular/common';
import { DsamsShareService } from '../../../services/dsams-share.service';

declare function focusItem(pItem: string): any;

export interface CustomerServiceDataType {
  customer_SERVICE_TYPE_ID: string,
  service_TYPE_DESCRIPTION_TX: string,
  procuringAgencyIn: boolean,
  isDisabled: boolean
}

@Component({
  selector: 'app-case-information-panel',
  templateUrl: './case-information-panel.component.html',
  styleUrls: ['./case-information-panel.component.css',
    '../case-dashboard.component.css',
    '../common-CSS.component.css'],
  providers: [
    { provide: DateAdapter, useClass: AppDateAdapter },
    { provide: MAT_DATE_FORMATS, useValue: APP_DATE_FORMATS }
  ]
})

export class CaseInformationPanelComponent implements OnInit, OnDestroy {
  public caseInfoData: any = {};
  private _caseUIServiceSubscription: Subscription;
  public legacyData: ICaseVersion = {};
  private _reloadData: boolean = true;
  private _reloadReferenceData: boolean = true;
  private _initialLoad: boolean = true;
  private _saveSubscription: Subscription;
  private _dataSubscription: Subscription;
  private _milestoneAddubscription: Subscription;
  private _popupPersonSubscription: Subscription = null;
  private _globalPersonRowElement: any = null;   // Stores the element of the person while popup is open.
  private _editSubscription: Subscription = null;
  private _newSubscription: Subscription = null;
  private _popupActivityDocIndSubscription: Subscription = null;
  private _popupActivityPreActSubscription: Subscription = null;
  private _documentIndicatorErrorCd: string = DsamsConstants.NO_ERROR;
  private _preparingActivityErrorCd: string = DsamsConstants.NO_ERROR;
  private _documentIndicatorPopulatedFromPopup: boolean = false;
  private _preparingActivityPopulatedFromPopup: boolean = false;
  private _saveCompleteSubscription: Subscription = null;
  private _amendModChangeSubscription: Subscription = null;
  private _countryChangeSubscription: Subscription = null;
  private _casePanelStatusQuerySubscription: Subscription = null;
  private _currentToggle:boolean = false;  
  private _fieldDocInitiatorSubscription: Subscription = null;

  isDocInitiatorEnabled: boolean = false;
  aCustomerServiceType: CustomerServiceDataType[];
  dataSourceCustomerService = new MatTableDataSource();
  columnsToDisplayCustomerService = ['ServiceName', 'ProcuringAgency', 'DeleteRow'];

  dataSourceManagerRole = new MatTableDataSource();
  columnsToDisplayManagerRole = ['ManagerName', 'ManagerRole', 'DeleteRow'];
  aManagerRoleObject = { editableCol: 'true', ManagerName: "", ManagerRole: "" };
  // Hardcode the values for now
  serviceMilName = [
    { AOD: 'A', naming: 'Marine Corps' },
    { AOD: 'B', naming: 'Army' },
    { AOD: 'C', naming: 'Navy' },
    { AOD: 'D', naming: 'Coast Guard' },
    { AOD: 'Z', naming: 'Air Force' },
  ];

  columnsToDisplayAssociation = ['DocType', 'Case', 'SAProg',
    'LastDoc', 'Status', 'StatusDate', 'TotalCaseValue',
    'RationaleforSelection', 'DeleteRow'];

  // Row Indexes
  aSaleTermRowIndex: number = 1;
  aManagerRoleRowIndex: number = 1;
  aCustomerServiceRowIndex: number = 1;

  // Reference Lists
  refAODList: Array<ReferenceDataType> = [];
  refCaseCategoryList: Array<ReferenceDataType> = [];
  refCustomerServiceList: Array<ReferenceDataType> = [];
  refFiscalYearList: Array<ReferenceDataType> = [];
  refManagementRoleList: Array<ReferenceDataType> = [];
  refPublicLawList: Array<ReferenceDataType> = [];
  refSaleTermList: Array<ReferenceDataType> = [];
  private _pnlExpansionProperties: PanelExpansionProperties;
  caseVersionData: ICaseVersion;

  nullFormControl = new FormControl('');
  caseNicknameFormControl = new FormControl('', [Validators.required]);
  oedFormControl = new NamedFormControl('OED Date', '', [DateValidator.validateDateGESysdate]);
  aodDateFormControl = new NamedFormControl('AOD Date', '', [Validators.required, DateValidator.validateRegularDate]);
  FIELD_REQUIRED_MSG: string = DsamsConstants.FIELD_REQUIRED_MSG;
  isCaseNicknmDisabled: boolean = false;
  isAODGroupRequired: boolean = false;
  isCaseCategoryDisabled: boolean = false;

  ENTITY_CASE_MASTER: string = "CASE_MASTER";
  ENTITY_CASE_VERSION: string = "CASE_VERSION";
  ENTITY_CASE_MASTER_SERVICE_TYPE: string = "CASE_MASTER_SERVICE_TYPE";
  ENTITY_CASE_PERSONNEL_ROLE: string = "CASE_PERSONNEL_ROLE";
  ENTITY_CASE_SALE_TERM: string = "CASE_SALE_TERM";

  columnsToDisplaySaleTerm = ['Description', 'Authority', 'AuthorityFY', 'Amount', 'DeleteRow'];
  dataSourceSaleTerm = new MatTableDataSource();
  dialog: MatDialog;
  userSelection: number;

  // Form for new popup for activity
  caseActivityForm: FormGroup;
  popupStatus:number=0;

  constructor(private caseRestService: CaseRestfulService,
    private dsamsShareService: DsamsShareService,
    private caseUIService: CaseUIService,
    private currencyPipe: CurrencyPipe,
    public dsamsDialogMsgService: DsamsMethodsService) { }

  @ViewChild(MdePopoverTrigger, { static: true }) trigger: MdePopoverTrigger;

  // Tootips that are repeated.
  tttCaseNicknameNm = "Enter the Case Nickname, which is a textual name for a case. This is used primarily by the Air Force, but which is available for optional use on all cases.";

  // This will be used to indicate dynamically which fields are disabled.
  private fieldDisabledMap: FieldDisabledMap = {};

  // begin review-16 06/03/2022 DB
   get isBenefittingCountry() {
    if (!!this.caseInfoData && this.caseInfoData['customer_TYPE_CD'] == 'BE'
    ) {
      return true;
    } else {
      return false;
    }
  }

  get isBenefittingCountryAndHasBP(): boolean {
    return this.isBenefittingCountry && this.caseInfoData['building_PARTNER_CAPACITY_IN'];
  }
  // end  review-16 06/03/2022 DB


  fieldDisabled(pFieldName: string): boolean {
    // Special Case for Document Initiator Field (DSAMS-1507)
    if (pFieldName === "case_INITIATOR_ACTIVITY_ID") {
      return !(this.caseUIService.optionSelectedUCDI.getValue());
    }
    // Special Case for procuring agency when user selects change customer information option (DSAMS-1585)
    else if (pFieldName === "refCustomerServiceList_procuringAgencyIn"
      && !(this.fieldDisabledMap["refCustomerServiceList_procuringAgencyIn"])
      && this.caseUIService.optionSelectedUCCI.getValue()) {
      return false;
    }
    else if (pFieldName === "refCustomerServiceList" && !(this.fieldDisabledMap["refCustomerServiceList"]) && this.caseUIService.optionSelectedUCMP.getValue()) {
      return false;
    }
    else if (pFieldName === "refCustomerServiceList_ddlSERVICE_TYPE_DESCRIPTION_TX" && !(this.fieldDisabledMap["refCustomerServiceList_ddlSERVICE_TYPE_DESCRIPTION_TX"]) && this.caseUIService.optionSelectedUCMP.getValue()) {
      return false;
    }    
    else if (pFieldName === "refCustomerServiceList_procuringAgencyIn" && !(this.fieldDisabledMap["refCustomerServiceList_procuringAgencyIn"]) && this.caseUIService.optionSelectedUCMP.getValue()) {
      return false;
    }
    else if (pFieldName === "activity_ID" && !(this.fieldDisabledMap["activity_ID"]) && this.caseUIService.optionSelectedUCMP.getValue()) {
      return false;
    }
    else if (pFieldName === "caseManagerList" && !(this.fieldDisabledMap["caseManagerList"]) && this.caseUIService.optionSelectedUCMP.getValue()) {
      return false;
    }
    else if (pFieldName === "caseManagerList_txtPersonNm" && !(this.fieldDisabledMap["caseManagerList_txtPersonNm"]) && this.caseUIService.optionSelectedUCMP.getValue()) {
      return false;
    }
    else if (pFieldName === "caseManagerList_ddlMANAGEMENT_ROLE_TITLE_NM" && !(this.fieldDisabledMap["caseManagerList_ddlMANAGEMENT_ROLE_TITLE_NM"]) && this.caseUIService.optionSelectedUCMP.getValue()) {
      return false;
    }
    else if (pFieldName === "offer_EXPIRATION_DT" && !(this.fieldDisabledMap["offer_EXPIRATION_DT"]) && this.caseUIService.optionSelectedUCMP.getValue()) {
      return false;
    }
    else if (pFieldName === "case_NICKNAME_NM" && !(this.fieldDisabledMap["case_NICKNAME_NM"]) && this.caseUIService.optionSelectedUCMP.getValue()) {
      return false;
    }
    else if (pFieldName === "procuringAgencyIn" && !(this.fieldDisabledMap["procuringAgencyIn"]) && this.caseUIService.optionSelectedUCMP.getValue()) {
      return false;
    }
    else {
      return CaseUtils.isFieldDisabled(this.fieldDisabledMap, DsamsConstants.CASE_PANEL_INFO, pFieldName);
    }
  }

  //breakout logic per Sonarqube
  refreshCaseInfoData(){
    if (this._pnlExpansionProperties.isNewMode) {
      this.initializeCaseInformationPanel();
      this.caseUIService.theComponentSaveState[CaseUIService.SAVE_CASE_DETAILS_STATE].isDataChanged = true;
    }
  }

  ngOnInit() {
    this.dsamsShareService.csuname.next('WP001');
    // Added the subscription assignment so it can be unsubscribed in onDestory.
    // Only fetch data when the panel is opened.
    this._caseUIServiceSubscription = this.caseUIService.panelExpanded.subscribe(
      {
        next: (pnlExpansionProperties: PanelExpansionProperties) => {
           if (pnlExpansionProperties.panelName === DsamsConstants.CASE_PANEL_INFO) {
             this._pnlExpansionProperties = pnlExpansionProperties;
             this.caseUIService.theComponentSaveState[CaseUIService.SAVE_CASE_DETAILS_STATE].isDataChanged = false;
             this.refreshCaseInfoData();
            if (this._pnlExpansionProperties.isResetPanels) {
              this._initialLoad = true;
              this._reloadData = true;
              this._reloadReferenceData = true;
            }
            this.getAllReferenceDataCaseInfo();
            this.subscribeToDataService();
            this.subscribeToUCMPOption(); //Update Manager
            if (this._pnlExpansionProperties.isNewMode && this._initialLoad) {
              this._initialLoad = false;
              // Set to true (new mode). This is necessary if we're coming from the search screen.
              this._pnlExpansionProperties.isNewMode = true; 
              this.caseUIService.caseNewService.next(
                {
                  ID: DsamsConstants.CASE_VERSION_EDITOR,
                  editToggle: true
                }
              );
              this.caseUIService.flipToEnabledService.next(DsamsConstants.CASE_VERSION_EDITOR);           
            }
          }
        }
      });

    // Subscribe to save or validate request.
    this.subscribeToValidateOrSaveRequest();

    // Subscribe to person popup.
    this.subscribeToPopupPerson();

    // Subscribe to edit
    this.subscribeToEdit();

    // Subscribe to amendment/mod and country changing
    this.subscribeToAmendModChange();
    this.subscribeToCountryChange();

    // Subscribe to Case Panel Status
    this.subscribeToCasePanelStatusQuery();

    // Subscribe to Document Indicator Activity Popup.
    this.subscribeToPopupActivityDocInd();

    // Subscribe to Preparing Activity Popup.
    this.subscribeToPopupActivityPreAct();

    // Subscribe to case ui service for case initiator
    if (!this._fieldDocInitiatorSubscription) {
      this._fieldDocInitiatorSubscription = this.caseUIService.getFieldDocInitatorDisabled().subscribe((value) => {
        if (this.caseUIService.optionSelectedUCDI.getValue()) {
          this.fieldDisabledMap["case_INITIATOR_ACTIVITY_ID"] = false;
        }
      });
    }

    // Subscribe to case ui service for procuring agency 
    // for change customer information option
    this.caseUIService.getFieldProcuringAgencyDisabled().subscribe((value) => {
      // Set field disabled to value
      if (this.caseUIService.optionSelectedUCCI.getValue()) {
        this.fieldDisabledMap["refCustomerServiceList_procuringAgencyIn"] = value;
      }
    });

    // Reset flags.
    this._documentIndicatorPopulatedFromPopup = false;
    this._preparingActivityPopulatedFromPopup = false;
  }


  // Make sure panel expansion subscription is cleaned up.
  ngOnDestroy() {
    this.dsamsShareService.csuname.next(null);
    this._caseUIServiceSubscription.unsubscribe();
    if (!!this._saveSubscription) {
      this._saveSubscription.unsubscribe();
      this._saveSubscription = null;
    }
    if (this._dataSubscription) {
      this._dataSubscription.unsubscribe();
      this._dataSubscription = null;
    }
    if (!!this._popupPersonSubscription) {
      this._popupPersonSubscription.unsubscribe();
    }
    if (!!this._editSubscription) {
      this._editSubscription.unsubscribe();
      this._editSubscription = null;
    }
    if (!!this._newSubscription) {
      this._newSubscription.unsubscribe();
      this._newSubscription = null;
    }
    if (!!this._milestoneAddubscription) {
      this._milestoneAddubscription.unsubscribe();
      this._milestoneAddubscription = null;
    }
    if (!!this._saveCompleteSubscription) {
      this._saveCompleteSubscription.unsubscribe();
      this._saveCompleteSubscription = null;
    }
    if (!!this._amendModChangeSubscription) {
      this._amendModChangeSubscription.unsubscribe();
      this._amendModChangeSubscription = null;
    }
    if (!!this._countryChangeSubscription) {
      this._countryChangeSubscription.unsubscribe();
      this._countryChangeSubscription = null;
    }    
    if (!!this._casePanelStatusQuerySubscription) {
      this._casePanelStatusQuerySubscription.unsubscribe();
      this._casePanelStatusQuerySubscription = null;
    }
    if (!!this._fieldDocInitiatorSubscription) {
      this._fieldDocInitiatorSubscription.unsubscribe();
      this._fieldDocInitiatorSubscription = null;
    }
  }

  // Subscribe to case ui service for optionSelectedUCMP Update Manager
  subscribeToUCMPOption() {
    this.caseUIService.optionSelectedUCMP.subscribe((value) => {
      // Set fields to
      if (value) {
        this.fieldDisabledMap['refCustomerServiceList'] = false;
        this.fieldDisabledMap['refCustomerServiceList_ddlSERVICE_TYPE_DESCRIPTION_TX'] = false;
        this.fieldDisabledMap["refCustomerServiceList_procuringAgencyIn"] = true;
        this.fieldDisabledMap["procuringAgencyIn"] = false;
        this.fieldDisabledMap["activity_ID"] = false;
        this.fieldDisabledMap["caseManagerList"] = false;
        this.fieldDisabledMap["caseManagerList_txtPersonNm"] = false;
        this.fieldDisabledMap["caseManagerList_ddlMANAGEMENT_ROLE_TITLE_NM"] = false;
        this.fieldDisabledMap["offer_EXPIRATION_DT"] = true;
        this.fieldDisabledMap["case_NICKNAME_NM"] = false;
      }
    });
  }

  // Subscribe to edit toggle event
  subscribeToEdit() {
    if (!this._editSubscription) {
      this._editSubscription = this.caseUIService
        .caseEditService
        .subscribe((pResponse: IEditResponseType) => {
          if (pResponse && (pResponse.ID === DsamsConstants.CASE_VERSION_EDITOR || pResponse.ID === DsamsConstants.PAGE_CASE_DETAIL)) {
            this.enableOrDisableEverything(pResponse.editToggle);
            this._currentToggle = pResponse.editToggle; 
          }
        },
          err => {
            CaseUtils.ReporError("Error in case-info panel responding to edit toggle");
          }
        );
    }
    if (!this._newSubscription) {
      this._newSubscription = this.caseUIService
        .caseNewService
        .subscribe((pResponse: IEditResponseType) => {
          if (pResponse && (pResponse.ID === DsamsConstants.CASE_VERSION_EDITOR || pResponse.ID === DsamsConstants.PAGE_CASE_DETAIL)) {
            this.enableOrDisableEverything(pResponse.editToggle);
            this._currentToggle = pResponse.editToggle;
          }
        },
          err => {
            CaseUtils.ReporError("Error in case-info panel responding to new toggle");
          }
        );
    }
  }

  // Subscribe to Amend/Mod changed.
  subscribeToAmendModChange() {
    if (!this._amendModChangeSubscription) {
      this._amendModChangeSubscription = this.caseUIService.caseAmendModChange.subscribe((camChangeInfo:CaseAmendModChangeInfo) => {
        this.caseInfoData['case_VERSION_TYPE_CD'] = camChangeInfo.typeCd;
        this.caseInfoData['case_VERSION_NUMBER_ID'] = camChangeInfo.verNumId;
        this.setChangedCV();
      });
    }
  }

    // Subscribe to Amend/Mod changed.
  subscribeToCountryChange() {
    if (!this._countryChangeSubscription) {
        this._countryChangeSubscription = this.caseUIService.countryChange.subscribe((custOrgId:string) => 
        {
          this.caseVersionData.customer_ORGANIZATION_ID = custOrgId;
          this.caseVersionData.theCaseId.customer_ORGANIZATION_ID = custOrgId;
          this._pnlExpansionProperties.caseRequestParams.customerOrganizationId = custOrgId;
          this.caseVersionData.theCaseId.user_CASE_ID = CaseUtils.formatUserCaseIdForChangeCountry(this.caseVersionData.theCaseId.user_CASE_ID, custOrgId)
                                                                 .replace(/-/g, "");
          this.setChangedCM();
        });
    }
  }

  // Subscribe to Case Panel Status
  subscribeToCasePanelStatusQuery() {
    if (!this._casePanelStatusQuerySubscription) {
      this._casePanelStatusQuerySubscription = this.caseUIService.getPanelCaseVersionStatusQuerySubscription().subscribe(() => {
        if (this.caseInfoData['current_AOD_DT'] !== this.caseInfoData['old_CURRENT_AOD_DT'] ||
            this.caseInfoData['offer_EXPIRATION_DT'] !== this.caseInfoData['old_OFFER_EXPIRATION_DT']) 
        {
          this.setChangedCV();
        } 
        this.caseUIService.panelCaseVersionStatusResponseSubscriptionNext(DsamsConstants.CASE_PANEL_INFO, 
                                                                          this.caseInfoData[DsamsConstants.PROP_CASE_VERSION_STATUS],
                                                                          this._pnlExpansionProperties.caseRequestParams.caseId,
                                                                          this._pnlExpansionProperties.caseRequestParams.caseVersionId);
      });
    }
  }

  // Set changed flag for case version
  setChangedCV() {
    this.caseInfoData[DsamsConstants.PROP_CASE_VERSION_STATUS] = this._pnlExpansionProperties.isNewMode ? DsamsConstants.ENT_NEW : DsamsConstants.ENT_CHANGED;
    //since this method is being invoked for all kind of instances, add a check for status change before setting value
    if (this.caseInfoData[DsamsConstants.PROP_CASE_VERSION_STATUS] == DsamsConstants.ENT_UNCHANGED){
        this.caseUIService.theComponentSaveState[CaseUIService.SAVE_CASE_DETAILS_STATE].isDataChanged = false;  
    }
    else
       this.caseUIService.theComponentSaveState[CaseUIService.SAVE_CASE_DETAILS_STATE].isDataChanged = true;
  }

  setChangedPopup() {
    this.popupStatus = this._pnlExpansionProperties.isNewMode ? DsamsConstants.ENT_NEW : DsamsConstants.ENT_CHANGED;
    this.caseUIService.theComponentSaveState[CaseUIService.SAVE_CASE_DETAILS_STATE].isDataChanged = true;
   }
   
  // Set changed flag for case master
  setChangedCM() {
    this.caseInfoData[DsamsConstants.PROP_CASE_MASTER_STATUS] = (this._pnlExpansionProperties.isNewMode && this._pnlExpansionProperties.caseRequestParams.caseVersionTypeCd === "B") ? DsamsConstants.ENT_NEW : DsamsConstants.ENT_CHANGED;
    this.setChangedCV();
  }

  // Set the changed flag for case_master_service_type
  setChangedCMST(pEntity: any) {
    if (pEntity.status == DsamsConstants.ENT_UNCHANGED) {
      pEntity.status = DsamsConstants.ENT_CHANGED;
    }
    this.setChangedCM();
  }

  // Set the changed flag for management role list
  setChangedCPR(pEntity: any) {
    if (pEntity.status == DsamsConstants.ENT_UNCHANGED) {
      pEntity.status = DsamsConstants.ENT_CHANGED;
    }
    this.setChangedCM();
  }

  setChangedCST(pEntity: any) {
    if (pEntity.status == DsamsConstants.ENT_UNCHANGED) {
      pEntity.status = DsamsConstants.ENT_CHANGED;
    }
    this.setChangedCV();
  }


  // Enable or Disable everything on the panel.
  enableOrDisableEverything(pEnable: boolean) {
    let l_isEnabled: boolean = this._pnlExpansionProperties.isNewMode ? true : pEnable;
    this.fieldDisabledMap[DsamsConstants.CASE_PANEL_INFO] = !l_isEnabled;
    if (l_isEnabled && !!this.caseVersionData) {
      this.initializePanelFields();
    }
    if (!!this.caseVersionData) {
      const brMap: Object = this.caseVersionData.businessRuleMap;
      this.isCaseNicknmDisabled = this.fieldDisabled('case_NICKNAME_NM');
      this.isAODGroupRequired = <boolean>CaseUtils.getBusinessRuleMapValue(brMap, "AOD_GROUP_REQUIRED", false);
      this.isCaseCategoryDisabled = <boolean>CaseUtils.getBusinessRuleMapValue(brMap, "CASE_CATEGORY_DISABLED", false);
    }
    // Set to disabled if Edit is not on
    if (!pEnable) {
      this.caseUIService.setFieldDocInitatorDisabled(true);
    }
    this.caseUIService.canSave.next(l_isEnabled);
  }


  // This is where the field disabled logic goes on a per field or whole form basis.    
  initializePanelFields() {
    const brMap: Object = this.caseVersionData.businessRuleMap;
    this.fieldDisabledMap["case_CATEGORY_CD"] = <boolean>CaseUtils.getBusinessRuleMapValue(brMap, "CASE_CATEGORY_DISABLED", false);

    // For benefitting countries, nickname is required.
    if (<boolean>CaseUtils.getBusinessRuleMapValue(brMap, "CASE_NICKNAME_REQUIRED", false)) {
      this.caseNicknameFormControl = new FormControl('', [Validators.required]);
    }
    else {
      this.caseNicknameFormControl = new FormControl('');
    }

    this.fieldDisabledMap["current_AOD_DT"] = <boolean>CaseUtils.getBusinessRuleMapValue(brMap, "CURRENT_AOD_DISABLED", false);
    this.fieldDisabledMap["refCustomerServiceList_procuringAgencyIn"] = <boolean>CaseUtils.getBusinessRuleMapValue(brMap, "PROCURING_AGENCY_DISABLED", false);

    // Set the disabled button according to if the whole case-detail panel is disabled.
    const canSave: boolean = !(this.fieldDisabledMap[DsamsConstants.CASE_PANEL_ALL]);
    this.caseUIService.canSave.next(canSave);
  }

  //not used 
  initializeCaseInformationPanel(){
    this.caseInfoData=[{}];
    this.initializeArraysForNewMode();
  }

  initializeSaleTermArray() {
    let currCaseSaleTermList: Array<any> = <Array<any>>(this.caseInfoData["caseSaleTermList"]);
    let currCaseSaleTermItem: any;
    this.aSaleTermRowIndex = currCaseSaleTermList.length;
    this.caseInfoData["caseSaleTermDeletedList"] = [];
    for (let i = 0; i < this.aSaleTermRowIndex; i++) {
      let fyDisabled: boolean = false;
      fyDisabled = <boolean>CaseUtils.getBusinessRuleMapValue(currCaseSaleTermList[i]["businessRuleMap"], "FISCAL_YEAR_DISABLED", false);
      const theStatus = this._pnlExpansionProperties.isNewMode?DsamsConstants.ENT_NEW:DsamsConstants.ENT_UNCHANGED;
      currCaseSaleTermItem = Object.assign(currCaseSaleTermList[i],
        {
          rowNum: (i + 1),
          is_FISCAL_YEAR_EDITABLE: !fyDisabled,
          status: theStatus,
          old_SALE_TERM_ID: currCaseSaleTermList[i].sale_TERM_ID,
          case_SALE_TERM_AM: this.currencyPipe.transform(CaseUtils.unformatCurrency(currCaseSaleTermList[i].case_SALE_TERM_AM), 'USD')
        }
      );
      currCaseSaleTermList[i] = currCaseSaleTermItem;
    }
    this.dataSourceSaleTerm = new MatTableDataSource(currCaseSaleTermList);
  }


  addNewSaleTerm() {
    this.aSaleTermRowIndex++;

    if (!(this.caseInfoData["caseSaleTermList"])) {
      this.caseInfoData["caseSaleTermList"] = [];
    }

    (<Array<any>>this.caseInfoData["caseSaleTermList"]).push(
      {
        rowNum: this.aSaleTermRowIndex,
        status: DsamsConstants.ENT_NEW,
        case_SALE_TERM_SEQ_CD: 0,
        case_SALE_TERM_AM: null,
        sale_TERM_TITLE_NM: "",
        sale_TERM_APPLICABLE_LAW_NM: null,
        sale_TERM_ID: "",
        fiscal_YEAR_ID: 0,
        is_FISCAL_YEAR_EDITABLE: false
      }
    );
    this.dataSourceSaleTerm = new MatTableDataSource(this.caseInfoData["caseSaleTermList"]);
    this.dataSourceSaleTerm._updateChangeSubscription();
    this.setChangedCV();
    focusItem("ddlSALE_TERM_TITLE_NM" + +this.aSaleTermRowIndex);
  }

  delSaleTermRow(rowElement: any) {
    if (!(this.caseInfoData["caseSaleTermDeletedList"])) {
      this.caseInfoData["caseSaleTermDeletedList"] = [];
    }
    (<Array<any>>this.caseInfoData["caseSaleTermDeletedList"]).push(rowElement);
    (<Array<any>>this.caseInfoData["caseSaleTermList"]).splice(this.dataSourceSaleTerm.data.indexOf(rowElement), 1);
    this.dataSourceSaleTerm = new MatTableDataSource(this.caseInfoData["caseSaleTermList"]);
    this.setChangedCV();
    this.doPublicLawChange();
  }


  doSaleTermChanged(keyField: string, pElement: any) {
    pElement.sale_TERM_ID = keyField;
    if (this.isBenefittingCountryAndHasBP || keyField === "Q" || keyField === "F") {
      pElement['is_FISCAL_YEAR_EDITABLE'] = true;
    }
    else {
      pElement['is_FISCAL_YEAR_EDITABLE'] = false;
      pElement['fiscal_YEAR_ID'] = 0;
    }
  }

  // ******************* Error Messages **********************

  performDateCheckForOED(): string {
    this.setChangedCV();
    return DateValidator.DateErrorMessage(this.oedFormControl);
  }

  performDateCheckForAOD(): string {
    this.setChangedCV();
    return DateValidator.DateErrorMessage(this.aodDateFormControl);
  }

  // ********************** Customer Service Table ******************************

  /* This procedure initalizes the Customer Service table with default data for now */
  initializeCustomerServiceArray() {
    let currCustomerServiceList: Array<any> = <Array<any>>(this.caseInfoData["caseMasterServiceTypeList"]);
    let currCustomerServiceItem: any;
    this.aCustomerServiceRowIndex = currCustomerServiceList.length;
    this.caseInfoData["caseMasterServiceTypeDeletedList"] = [];
    for (let i = 0; i < this.aCustomerServiceRowIndex; i++) {
      let procuringAgencyInVal: boolean = false;
      procuringAgencyInVal = <boolean>CaseUtils.getBusinessRuleMapValue(currCustomerServiceList[i]["businessRuleMap"], "PROCURING_AGENCY", false);
      currCustomerServiceItem = Object.assign(currCustomerServiceList[i],
        {
          rowNum: (i + 1),
          procuringAgencyIn: procuringAgencyInVal,
          status: DsamsConstants.ENT_UNCHANGED,
          old_CUSTOMER_SERVICE_TYPE_ID: currCustomerServiceList[i].customer_SERVICE_TYPE_ID
        });
      currCustomerServiceList[i] = currCustomerServiceItem;
    }
    this.dataSourceCustomerService = new MatTableDataSource(currCustomerServiceList);
    this.resetProcuringAgencyObject();
  }

  /* This procedure is used to add a new row to the Customer Service table. It also
     iterates through the exsiting  Customer Service list to either enable or disable the 
     Agency checkbox. */
  addCustomerServiceItem(): void {

    this.aCustomerServiceRowIndex++;

    if (!(this.caseInfoData["caseMasterServiceTypeList"])) {
      this.caseInfoData["caseMasterServiceTypeList"] = [];
    }

    (<Array<any>>this.caseInfoData["caseMasterServiceTypeList"]).push(
      {
        rowNum: this.aCustomerServiceRowIndex,
        service_TYPE_DESCRIPTION_TX: "",
        procuringAgencyIn: false,
        customer_SERVICE_TYPE_ID: "",
        status: DsamsConstants.ENT_NEW,
        case_ID: 0
      }
    );
    this.dataSourceCustomerService = new MatTableDataSource(this.caseInfoData["caseMasterServiceTypeList"]);
    this.resetProcuringAgencyObject();
    focusItem("ddlSERVICE_TYPE_DESCRIPTION_TX" + +this.aCustomerServiceRowIndex);
    this.setChangedCM();
    this.dataSourceCustomerService._updateChangeSubscription();
  }

  /* This procedure checks the returned result value from the 
      popover Yes/No dialog window. */
  yesButtonCustomerOnClick(isDeleteConfirmed: any, rowElement: any) {
    if (isDeleteConfirmed)
      this.delCustomerServiceItem(rowElement);
  }
  /* This procedure checks the returned result value from the 
     popover Yes/No dialog window. */
  yesButtonManagerOnClick(isDeleteConfirmed: any, rowElement: any) {
    if (isDeleteConfirmed)
      this.delManagerRoleItem(rowElement);
  }
  /* This procedure checks the returned result value from the 
       popover Yes/No dialog window. */
  yesButtonSaleOnClick(isDeleteConfirmed: any, rowElement: any) {
    if (isDeleteConfirmed)
      this.delSaleTermRow(rowElement);
  }

  /* This procedure is used to remove the selected row from the Customer Service table. 
    It also iterates through the exsiting Customer Service list to either enable or disable 
    the Procuring Agency checkbox. */
  delCustomerServiceItem(rowElement: any) {
    // Add to the deleted list.
    if (!(this.caseInfoData["caseMasterServiceTypeDeletedList"])) {
      this.caseInfoData["caseMasterServiceTypeDeletedList"] = [];
    }
    (<Array<any>>this.caseInfoData["caseMasterServiceTypeDeletedList"]).push(rowElement);
    (<Array<any>>this.caseInfoData["caseMasterServiceTypeList"]).splice(this.dataSourceCustomerService.data.indexOf(rowElement), 1);
    this.dataSourceCustomerService = new MatTableDataSource(this.caseInfoData["caseMasterServiceTypeList"]);
    this.setChangedCM();
    this.resetProcuringAgencyObject();
    this.dataSourceCustomerService._updateChangeSubscription();
  }

  // ********************** Manager/Role Array ******************************
  // Manager and Roles array
  initializeArraysForNewMode() {
    if (!(this.caseInfoData["casePersonnelRoleList"])) {
      this.caseInfoData["casePersonnelRoleList"] = [];
    }
    (<Array<any>>this.caseInfoData["casePersonnelRoleList"]).push(
      {
        rowNum: this.aManagerRoleRowIndex,
        editableCol: false,
        management_ROLE_ID: "CASEMGR",
        management_ROLE_TITLE_NM: "Case Manager",
        case_ID: 0,
        personNm: "",
        user_ID: 0
      }
    );
    (<Array<any>>this.caseInfoData["casePersonnelRoleList"]).push(
      {
        rowNum: this.aManagerRoleRowIndex,
        editableCol: false,
        management_ROLE_ID: "FINMGR",
        management_ROLE_TITLE_NM: "Financial Manager",
        case_ID: 0,
        personNm: "",
        user_ID: 0
      }
    );
    this.dataSourceManagerRole = new MatTableDataSource(this.caseInfoData["casePersonnelRoleList"]);

    const currCustomerServiceList: Array<any> = [];
    this.dataSourceCustomerService = new MatTableDataSource(currCustomerServiceList);

    const currCaseSaleTermList: Array<any> = [];
    this.dataSourceSaleTerm = new MatTableDataSource(currCaseSaleTermList);
  }


  initializeManagerRoleArray() {
    let currManagerRoleList: Array<any> = <Array<any>>(this.caseInfoData["casePersonnelRoleList"]);
    let currManagerRoleItem: any;
    this.aManagerRoleRowIndex = currManagerRoleList.length;
    this.caseInfoData["casePersonnelRoleDeletedList"] = [];
    for (let i = 0; i < this.aManagerRoleRowIndex; i++) {
      currManagerRoleItem = Object.assign(currManagerRoleList[i],
        {
          status: (this._pnlExpansionProperties.isNewMode && this._pnlExpansionProperties.caseRequestParams.caseVersionTypeCd === "B") ? DsamsConstants.ENT_NEW : DsamsConstants.ENT_UNCHANGED,
          editableCol: !((currManagerRoleList[i]["management_ROLE_ID"] === "CASEMGR") ||
            (currManagerRoleList[i]["management_ROLE_ID"] === "FINMGR")),
          management_ROLE_TITLE_NM: !currManagerRoleList[i].theManagementRoleId ? "" : currManagerRoleList[i].theManagementRoleId.management_ROLE_TITLE_NM,
          personNm: (!currManagerRoleList[i].theUserId) ? "" : CaseUtils.getBusinessRuleMapValue(currManagerRoleList[i].theUserId.businessRuleMap, "PERSON_DISPLAY_NM", ""),
          old_MANAGEMENT_ROLE_ID: currManagerRoleList[i]["management_ROLE_ID"],
          old_USER_ID: currManagerRoleList[i]["user_ID"]
        }
      );
      currManagerRoleList[i] = currManagerRoleItem;
    }
    this.dataSourceManagerRole = new MatTableDataSource(currManagerRoleList);
  }


  addManagerRoleItem(): void {
    this.aManagerRoleRowIndex++;

    if (!(this.caseInfoData["casePersonnelRoleList"])) {
      this.caseInfoData["casePersonnelRoleList"] = [];
    }

    (<Array<any>>this.caseInfoData["casePersonnelRoleList"]).push(
      {
        rowNum: this.aManagerRoleRowIndex,
        editableCol: true,
        status: DsamsConstants.ENT_NEW,
        management_ROLE_ID: "",
        management_ROLE_TITLE_NM: "",
        case_ID: 0,
        personNm: "",
        user_ID: 0
      }
    );
    this.dataSourceManagerRole = new MatTableDataSource(this.caseInfoData["casePersonnelRoleList"]);
    this.setChangedCM();
    focusItem("txtPersonNm" + +this.aManagerRoleRowIndex);
  }


  delManagerRoleItem(rowElement: any): void {
    // Add to the deleted list.
    if (!(this.caseInfoData["casePersonnelRoleDeletedList"])) {
      this.caseInfoData["casePersonnelRoleDeletedList"] = [];
    }
    (<Array<any>>this.caseInfoData["casePersonnelRoleDeletedList"]).push(rowElement);
    (<Array<any>>this.caseInfoData["casePersonnelRoleList"]).splice(this.dataSourceManagerRole.data.indexOf(rowElement), 1);
    this.dataSourceManagerRole = new MatTableDataSource(this.caseInfoData["casePersonnelRoleList"]);
    this.setChangedCM();
    this.dataSourceManagerRole._updateChangeSubscription();
  }

  /* This function returns the CustomerServiceDataType object*/
  getObjectType(object: any): CustomerServiceDataType {
    return (object as CustomerServiceDataType);
  }

  // Set the case category title nm based on the user dropdown selected value.
  setCATEGORY_TITLE_NM(selectionEvent: MatSelectChange) {
    const selectedRDT: ReferenceDataType = CaseUtils.fetchRefereneDataTypeByValue(this.refCaseCategoryList, selectionEvent.value);
    this.caseInfoData['case_CATEGORY_TITLE_NM'] = selectedRDT.field_1;
  }


  /* This function searches for a procuring agency value that
     has been set. It returns the row index found. */
  isProcuringAgencyFound(): number {
    var result: number = -1;
    this.dataSourceCustomerService.data.forEach((_item, index) => {
      const isAgencyFound: boolean = (this.getObjectType(this.dataSourceCustomerService.data[index])).procuringAgencyIn
      if (isAgencyFound === true) {
        return (result = index);
      }
    })
    return result;
  }

  /* This procedure checks and refreshes the procuring agency value to ensure
     that only 1 agency can be checked and enabled. */
  resetProcuringAgencyObject() {
    let agencyFound: number = this.isProcuringAgencyFound();
    if (agencyFound >= 0) {
      this.dataSourceCustomerService.data.forEach((_item, index) => {
        if (agencyFound != index) {
          this.getObjectType(this.dataSourceCustomerService.data[index]).procuringAgencyIn = false;
          this.getObjectType(this.dataSourceCustomerService.data[index]).isDisabled = true;
        }
      })
    }
    else {
      this.dataSourceCustomerService.data.forEach((_item, index) => {
        this.getObjectType(this.dataSourceCustomerService.data[index]).procuringAgencyIn = false;
        this.getObjectType(this.dataSourceCustomerService.data[index]).isDisabled = false;
      })
    }
  }

  /* This procedure checks the procuring agency value to ensure
     that only 1 agency can be checked and enabled. */
  isAgencyChecked(rowElement: any) {
    let rowN: number = this.dataSourceCustomerService.data.indexOf(rowElement);
    let customerObject: CustomerServiceDataType = this.getObjectType(this.dataSourceCustomerService.data[rowN]);
    customerObject.procuringAgencyIn = customerObject.procuringAgencyIn ? false : true;
    let isAgencyChecked: boolean = customerObject.procuringAgencyIn;

    if (isAgencyChecked) {
      for (var i = 0; i < this.dataSourceCustomerService.data.length; i++) {
        if (i != rowN) {
          this.getObjectType(this.dataSourceCustomerService.data[i]).procuringAgencyIn = false;
          this.getObjectType(this.dataSourceCustomerService.data[i]).isDisabled = true;
        }
      }
    }
    else {
      for (var index = 0; index < this.dataSourceCustomerService.data.length; index++) {
        if (index != rowN) {
          this.getObjectType(this.dataSourceCustomerService.data[index]).isDisabled = false;
        }
      }
    }
    this.dataSourceCustomerService._updateChangeSubscription();
  }


  /**
   * Send out a notification when a public law changes so that the S1 description knowns to enable and disable.
   */
  public doPublicLawChange(): void {
    let plList: Array<string> = [];
    // Add a dummy PL so we know it came from here.
    if (this.caseInfoData["caseSaleTermList"]) {
      for (let cstItem of this.caseInfoData["caseSaleTermList"]) {
        plList.push(cstItem.public_LAW_ID);
      }
    }
    this.caseUIService.sizbacService.next(plList);
  }

  // ********************** Popups ******************************

  // Person Popup
  popupPerson(pElement: any) {
    let tmpFormGroup: FormGroup;
    let pType: string = "0";
    let pTitle: string = "Person Search";

    if (pElement.management_ROLE_ID === "CASEMGR") {
      pTitle = pTitle + " - Case Manager";
      pType = "1";
    }
    else if (pElement.management_ROLE_ID === "FINMGR") {
      pTitle = pTitle + " - Finance Manager";
      pType = "2";
    }

    this._globalPersonRowElement = pElement;
    this.dsamsDialogMsgService.openSearchDialogCase(DsamsConstants.PERSON_POPUP_WIDTH,
      DsamsConstants.PERSON_POPUP_HEIGHT,
      pType,
      PopPersonComponent,
      tmpFormGroup,
      pTitle);
  }


  // Subscribe to the DSAMS service for person textfield for popup selection.
  subscribeToPopupPerson() {
    if (this._popupPersonSubscription == null) {
      this._popupPersonSubscription = this.dsamsDialogMsgService
        .selectedPersonFromPopupValue
        .subscribe((selectedVal: IPerson) => {
          if (!!selectedVal && !!this._globalPersonRowElement) {
            this._globalPersonRowElement.user_ID = selectedVal.user_ID;
            this._globalPersonRowElement.personNm = CaseUtils.getBusinessRuleMapValue(selectedVal.businessRuleMap, "PERSON_DISPLAY_NM", "");
            this._globalPersonRowElement.status = (this._pnlExpansionProperties.isNewMode && this._pnlExpansionProperties.caseRequestParams.caseVersionTypeCd === "B") ? DsamsConstants.ENT_NEW : DsamsConstants.ENT_CHANGED;
            this.setChangedCM();
          }
          this._globalPersonRowElement = null;
        },
          err => {
            CaseUtils.ReporError("Error in dsamsMethodsService.popupPerson in case info");
            this._globalPersonRowElement = null;
          }
        );
    }
  }

  // Do backspace or delete on person.
  doBackspaceMR(pElement: any) {
    if (!this.fieldDisabled('caseManagerList_txtPersonNm')) {
      pElement.user_ID = 0;
      pElement.personNm = "";
    }
  }

  docIndActivityKeyPress() {
    this._documentIndicatorPopulatedFromPopup = false;
  }

  preparingActivityKeyPress() {
    this._preparingActivityPopulatedFromPopup = false;
  }

  // Activity Popup for Document Indicator
  popupCaseActivityDocInd(pElement: any): void {
    let diaWidth: string = "60%";
    let diaHeight: string = "68%";
    let passingData: string = "Document_Indicator";
    let pTitle: string = "Activity Search";

    this.dsamsDialogMsgService.openSearchDialogCase(diaWidth, diaHeight, passingData, PopCaseActivityComponent, this.caseActivityForm, pTitle);
  }

  // Subscribe to the DSAMS service for activity textfield 
  // (Document Indicator) for popup selection.
  subscribeToPopupActivityDocInd() {
    if (this._popupActivityDocIndSubscription == null) {
      this._popupActivityDocIndSubscription = this.dsamsDialogMsgService
        .selectedActivityDocIndFromPopupValue
        .subscribe(value => {
          if (!!value) {
            this.caseInfoData['case_INITIATOR_ACTIVITY_ID'] = value;
            this._documentIndicatorPopulatedFromPopup = true;
            this._documentIndicatorErrorCd = DsamsConstants.NO_ERROR;
            this.setChangedCV();
            this.caseUIService.canSave.next(true);
          }
        },
          err => {
            CaseUtils.ReporError("Error in dsamsMethodsService.popupActivity");
          }
        );
    }
  }

  // Activity Popup for Preparing Activity
  popupCaseActivityPreAct(pElement: any): void {
    let diaWidth: string = "60%";
    let diaHeight: string = "68%";
    let passingData: string = "Preparing_Activity";
    let pTitle: string = "Activity Search";

    this.dsamsDialogMsgService.openSearchDialogCase(diaWidth, diaHeight, passingData, PopCaseActivityComponent, this.caseActivityForm, pTitle);
  }

  // Subscribe to the DSAMS service for activity textfield 
  // (Preparing Activity) for popup selection
  subscribeToPopupActivityPreAct() {
    if (this._popupActivityPreActSubscription == null) {
      this._popupActivityPreActSubscription = this.dsamsDialogMsgService
        .selectedActivityPreActFromPopupValue
        .subscribe(value => {
          if (!!value) {
            this.caseInfoData['activity_ID'] = value;
            this._preparingActivityPopulatedFromPopup = true;
            this._preparingActivityErrorCd = DsamsConstants.NO_ERROR;
            this.setChangedCV();
            this.setChangedPopup();
            this.caseUIService.canSave.next(true);
          }
        },
          err => {
            CaseUtils.ReporError("Error in dsamsMethodsService.popupActivity");
          }
        );
    }
  }

  // Validate the Document Indicator activity.
  validateDocIndActivity() {
    if (this.fieldDisabled('case_INITIATOR_ACTIVITY_ID') || this._documentIndicatorPopulatedFromPopup == true || !this.caseInfoData['case_INITIATOR_ACTIVITY_ID'] || this.caseInfoData['case_INITIATOR_ACTIVITY_ID'] === "") {
      this._documentIndicatorErrorCd = DsamsConstants.NO_ERROR;
      this.caseUIService.canSave.next(true);
      return;
    }
    this.caseUIService.canSave.next(false);
    const activityId: string = CaseUtils.parseOutID(this.caseInfoData['case_INITIATOR_ACTIVITY_ID']).toUpperCase();
    // Call the database to make sure it's valid.    
    let filter: string = activityId + "@@@#" + sessionStorage.getItem('serviceDBid');
    filter = encodeURIComponent(filter);
    let isValid: boolean = false;
    this.caseRestService
      .getActivityByFilter(filter)
      .subscribe(data => {
        let fetchedActivity: IActivity = null;
        if (!!data) {
          // Loop thru the fetched activities until we find one of the same length as what the user entered.
          for (let i = 0; i < data.length; i++) {
            if (CaseUtils.parseOutID(data[i].activity_ID).length === activityId.length) {
              fetchedActivity = data[i];
            }
          }
        }
        if (!!fetchedActivity) {
          this.caseInfoData['case_INITIATOR_ACTIVITY_ID'] = fetchedActivity.activity_ID + " - " + fetchedActivity.activity_NM;
          this._documentIndicatorErrorCd = DsamsConstants.NO_ERROR;
          this.setChangedCV();
          this.caseUIService.canSave.next(true);
        }
        else {
          this._documentIndicatorErrorCd = "E051";
          this.caseInfoData['case_INITIATOR_ACTIVITY_ID'] = activityId;
        }
      },
        err => {
          CaseUtils.ReportHTTPError(err, "Validating Document Indicator Activity ID");
          this.caseUIService.canSave.next(true);
        }
      );
  }


  // Get the field style property depending on if there's an error or not.
  getFieldStyleProperty(pElement: any, pElementName: string, isAppearanceNotStyle: boolean): string | object {
    const ERROR_APPEARANCE: string = DsamsConstants.ERROR_APPEARANCE;
    const REGULAR_APPEARANCE: string = DsamsConstants.REGULAR_APPEARANCE;
    const ERROR_STYLE_1 = { "border": "2px solid red", "padding-top": "5px", "padding-bottom": "5px", "border-radius": "4px", "margin-top": "-8px", "vertical-align": "top" };
    const ERROR_STYLE_2 = { "border": "2px solid red", "padding-top": "5px", "padding-bottom": "5px", "border-radius": "4px", "margin-top": "-23px", "vertical-align": "top" };
    let isError: boolean = false;
    let styleStr: object = {};
    if (pElementName === "activity_ID") {
      isError = this.hasPreparingActivityError();
      styleStr = ERROR_STYLE_1;
    }
    else if (pElementName === "case_INITIATOR_ACTIVITY_ID") {
      isError = this.hasDocInitiatorActivityError();
      styleStr = ERROR_STYLE_2;
    }
    if (isAppearanceNotStyle) {
      return isError ? ERROR_APPEARANCE : REGULAR_APPEARANCE;
    }
    else {
      return isError ? styleStr : {};
    }
  }


  // Does the Preparing Activity ID have an error?
  hasPreparingActivityError(): boolean {
    return (!(this.fieldDisabled('activity_ID')) && this._preparingActivityErrorCd !== DsamsConstants.NO_ERROR);
  }


  // Does doc initiator activity ID have errors?
  hasDocInitiatorActivityError(): boolean {
    return (!(this.fieldDisabled('case_INITIATOR_ACTIVITY_ID')) && this._documentIndicatorErrorCd !== DsamsConstants.NO_ERROR);
  }


  // Show the Preparing Activity Error Message
  showPreparingActivityErrorMessage() {
    if (this.hasPreparingActivityError()) {
      return MessageMgr.getMesssage(this._preparingActivityErrorCd).messageText;
    }
    else {
      return DsamsConstants.NO_ERROR;
    }
  }

  // Show the Preparing Activity Error Message
  showDocInitiatorErrorMessage() {
    if (this.hasDocInitiatorActivityError()) {
      return MessageMgr.getMesssage(this._documentIndicatorErrorCd).messageText;
    }
    else {
      return DsamsConstants.NO_ERROR;
    }
  }


  // Validate the Preparing activity.
  validatePreActActivity() {
    if (this.fieldDisabled('activity_ID') || this._preparingActivityPopulatedFromPopup == true || !this.caseInfoData['activity_ID'] || this.caseInfoData['activity_ID'] === "") {
      this._preparingActivityErrorCd = DsamsConstants.NO_ERROR;
      this.caseUIService.canSave.next(true);
      return;
    }
    this.caseUIService.canSave.next(false);
    const activityId: string = CaseUtils.parseOutID(this.caseInfoData['activity_ID']).toUpperCase();
    // Call the database to make sure it's valid.    
    let filter: string = activityId + "@@@#" + sessionStorage.getItem('serviceDBid');
    filter = encodeURIComponent(filter);
    let isValid: boolean = false;
    this.caseRestService
      .getActivityByFilter(filter)
      .subscribe(data => {
        let fetchedActivity: IActivity = null;
        if (!!data) {
          // Loop thru the fetched activities until we find one of the same length as what the user entered.
          for (let i = 0; i < data.length; i++) {
            if (CaseUtils.parseOutID(data[i].activity_ID).length === activityId.length) {
              fetchedActivity = data[i];
            }
          }
        }
        if (!!fetchedActivity) {
          this.caseInfoData['activity_ID'] = fetchedActivity.activity_ID + " - " + fetchedActivity.activity_NM;
          this._preparingActivityErrorCd = DsamsConstants.NO_ERROR;
          this.caseUIService.canSave.next(true);
        }
        else {
          this._preparingActivityErrorCd = "E051";
          this.caseInfoData['activity_ID'] = activityId;
        }
      },
        err => {
          CaseUtils.ReportHTTPError(err, "Validating Preparing Activity ID");
          this.caseUIService.canSave.next(true);
        }
      );
  }

  // *************************** Add a milestone ******************************

  addMilestone(pMilestoneId: string) {
    if (!this.caseVersionData.caseVersionMilestoneList) {
      this.caseVersionData.caseVersionMilestoneList = [];
    }
    const newMilestone:ICaseVersionMilestone = CaseUtils.addCaseVersionMilestone(this._pnlExpansionProperties.caseRequestParams.caseId,
                                                                                 this._pnlExpansionProperties.caseRequestParams.caseVersionId,
                                                                                 this._pnlExpansionProperties.caseRequestParams.customerRequestId,
                                                                                 pMilestoneId,
                                                                                 "",
                                                                                 "",
                                                                                 0);
    this.caseVersionData.caseVersionMilestoneList.push(newMilestone);
    this.setChangedCV();
  }


  // *************************** REST Services ********************************
  //begin DSAMS-5754 07/22 DH
  constructRefListObject(): CommonReferenceData {
    // *** Reference: AOD ***
    // New mode:
    const isMod: boolean = (this._pnlExpansionProperties.caseRequestParams.caseVersionTypeCd === "M");
    let ruleSetNum: number = 0;
    if (this._pnlExpansionProperties.isNewMode) {
      ruleSetNum = (isMod ? 1 : 2);
    }
    else {
      ruleSetNum = (isMod ? 3 : 4);
    }

    return (
      {
        refName: [DsamsConstants.REF_AOD_GROUP, DsamsConstants.REF_CASE_CATEGORY,
        DsamsConstants.REF_CUSTOMER_SERVICE_TYPE, DsamsConstants.REF_FISCAL_YEAR,
        DsamsConstants.REF_MANAGEMENT_ROLE, DsamsConstants.REF_PUBLIC_LAW,
        DsamsConstants.REF_SALE_TERM],
        defaultValue: ["", "", "", "", "", "", ""],
        sortFieldNum: [0, 0, 0, 0, 0, 0, 0],
        allowNull: [true, true, true, true, true, true, true],
        showInactive: [false, false, false, false, false, false, false],
        extraInfo: [this._pnlExpansionProperties.caseRequestParams.customerOrganizationId,
        this._pnlExpansionProperties.caseRequestParams.securityAssistanceProgramCd,
          null, null, null, null, null],
        ruleSet: [ruleSetNum, 1, 1, 1, 1, 1, 1]
      });
  }

  getAllReferenceDataCaseInfo() {
    if (this.refAODList == null || this.refAODList.length == 0) {
      let theRefListParam = this.constructRefListObject();
      this.caseRestService.getAllCaseDetailsRefData(theRefListParam.refName,
        theRefListParam.defaultValue,
        theRefListParam.sortFieldNum,
        theRefListParam.allowNull,
        theRefListParam.showInactive,
        theRefListParam.extraInfo,
        theRefListParam.ruleSet)
        .subscribe(
          data => {
            let index = 0;
            this.refAODList = data[index++];
            this.refCaseCategoryList = data[index++];
            this.refCustomerServiceList = data[index++];
            this.refFiscalYearList = data[index++];
            this.refManagementRoleList = data[index++];
            this.refPublicLawList = data[index++];
            this.refSaleTermList = data[index];
          },
          err => {
             CaseUtils.ReportHTTPError(err, "Error fetching reference data for Case Information");
          }
        );
    }
  }
  //end DSAMS-5754 07/22 DH

  enableUpdImplCase(pVersionStatus: string) {
    this.caseUIService.setIsUpdImplCaseEnabled(
      CaseUtils.isOptionEnabledForUpdImplCaseShortcut(pVersionStatus));
  }

  enablePenInk(pVersionStatus: string) {
    this.caseUIService.setIsPenInkEnabled(
      CaseUtils.isOptionEnabledForPenInkShortcut(pVersionStatus));
  }

  enableMildep(pVersionStatus: string, pCaseVersionType: string) {
    this.caseUIService.setIsMildepEnabled(
      CaseUtils.isOptionEnabledForMildepShortcut(pVersionStatus, pCaseVersionType));
  }

  enableDsca(pVersionStatus: string) {
    this.caseUIService.setIsDscaEnabled(
      CaseUtils.isOptionEnabledForDscaShortcut(pVersionStatus));
  }

  enableCaseInProposed(pVersionStatus: string) {
    this.caseUIService.setIsCaseInProposedEnabled(
      CaseUtils.isOptionEnabledForCaseInProposedShortcut(pVersionStatus));
  }

  enableCaseInReview(pVersionStatus: string) {
    this.caseUIService.setIsCaseInReviewEnabled(
      CaseUtils.isOptionEnabledForCaseInReviewShortcut(pVersionStatus));
  }

  enableMgr(pVersionStatus: string, pCaseVersionType: string) {
    this.caseUIService.setIsMgrEnabled(
      CaseUtils.isOptionEnabledForMgrShortcut(pVersionStatus, pCaseVersionType));
  }

  //Enable option Document Initiator
  enableDocumentInitiator(pCaseVersionType: string,
    pVersionStatus: string, pCaseMasterStatus: string) {
    this.caseUIService.setIsDocInitiatorEnabled(
      CaseUtils.isOptionEnabledForDocInitShortcut(pCaseVersionType, pVersionStatus, pCaseMasterStatus));
  }

  //Enable option Amend/Mod Number
  enableAmendMod(pVersionStatus: string, pCaseVersionType: string) {
    this.caseUIService.setIsAmendModEnabled(
      CaseUtils.isOptionEnabledForAmendModShortcut(pVersionStatus, pCaseVersionType));
  }

  //Enable option Customer Information
  enableCustomerInformation(pVersionStatus: string, pCaseVersionType: string) {
    this.caseUIService.setIsCustomerInformationEnabled(
      CaseUtils.isOptionEnabledForCustomerInformationShortcut(pVersionStatus, pCaseVersionType));
  }

  //Enable option Country
  enableCountry(pVersionStatus: string, pCaseVersionType: string) {
    this.caseUIService.setIsCountryEnabled(
      CaseUtils.isOptionEnabledForCountryShortcut(pVersionStatus, pCaseVersionType,
        this.caseVersionData));
  }

  //Enable option Congressional Notification
  enableCongressionalNotification(pVersionStatus: string) {
    this.caseUIService.setIsCongressionalNotificationEnabled(
      CaseUtils.isOptionEnabledForCongressionalNotificationShortcut(pVersionStatus));
  }

  //Enable option S1 Description
  enableS1Description(pVersionStatus: string) {
    this.caseUIService.setIsS1DescriptionEnabled(
      CaseUtils.isOptionEnabledForS1DescriptionShortcut(pVersionStatus, this.caseVersionData));
  }

  //Enable option Special Billing Agreement
  enableSpecialBillingAgreement(pVersionStatus: string) {
    this.caseUIService.setIsSpecialBillingAgreementEnabled(
      CaseUtils.isOptionEnabledForSpecialBillingAgreementShortcut(pVersionStatus));
  }

  //Enable option Requisition Forcast Indicator
  // Fixed Option - Card 5184
  enableRequisitionForcastIndicator(pCaseVersionStatus: string, pCaseVersionType: string) {
    this.caseUIService.setIsRequisitionForcastIndicatorEnabled(
      CaseUtils.isOptionEnabledForRequisitionForcastIndicatorShortcut(pCaseVersionStatus, pCaseVersionType));
  }

  //Enable option Reserve Case Identifier
  enableReserveCaseIdentifier(pCaseVersionType: string) {
    this.caseUIService.setIsReserveCaseIdentifierEnabled(
      CaseUtils.isOptionEnabledForReserveCaseIdentifierShortcut(this.caseVersionData, pCaseVersionType));
  }

    //Enable option Reserve Case Identifier
  enableValidateCase(pVersionStatus:string, pCaseMasterStatus:string) {
    this.caseUIService.setIsValidateCaseEnabled(CaseUtils.isOptionEnabledForValidateCaseShortcut(pVersionStatus, pCaseMasterStatus));
  }

  // **************************************************************************
  // ************* Subscribe to the data subscription service *****************
  // **************************************************************************

  // Add the subscription for case info panel
  // for getting the data from the dashboard.
  subscribeToDataService() {
    if (this._reloadData) {
      this.caseUIService.canSave.next(false);
      if (!this._dataSubscription) {
        this._dataSubscription = this.caseUIService.caseDetailData.subscribe(
          {
            next: (caseDetailData: ICaseVersion) => {
              if (caseDetailData) {
                this.caseVersionData = caseDetailData;
                // Determine if the case in the URL bar is not found.
                // Uncomment this when we use search params in the URL bar.
                /*
                if (!this._pnlExpansionProperties.isNewMode && this.caseVersionData.status == DsamsConstants.ENT_NEW) {
                  const errMsg = 'Case Version not found for Case ID:' + this._pnlExpansionProperties.caseRequestParams.caseId + ", Case Version ID:" + this._pnlExpansionProperties.caseRequestParams.caseVersionId + ".";
                  swal.fire({
                              title: 'Case Version not found.',
                              html: errMsg,
                              icon: 'error',
                              showConfirmButton: true,
                              width: 400,
                              focusConfirm: true,
                              confirmButtonText: 'OK'
                            });
                }
                */
                CaseUtils.populateCaseRequestParamsType(this._pnlExpansionProperties.caseRequestParams, this.caseVersionData);
                this.caseInfoData['case_NICKNAME_NM'] = this.caseVersionData.theCaseId.case_NICKNAME_NM;
                if (!this.caseVersionData.theCaseInitiatorActivityId ||
                  !this.caseVersionData.theCaseInitiatorActivityId.activity_ID ||
                  this.caseVersionData.theCaseInitiatorActivityId.activity_ID === "") {
                  this.caseInfoData['case_INITIATOR_ACTIVITY_ID'] = "";
                }
                else {
                  this.caseInfoData['case_INITIATOR_ACTIVITY_ID'] = this.caseVersionData.theCaseInitiatorActivityId.activity_ID + " - " + this.caseVersionData.theCaseInitiatorActivityId.activity_NM;
                }
                this.caseInfoData['aod_GROUP_CD'] = CaseUtils.nullFix(this.caseVersionData.aod_GROUP_CD);
                this.caseInfoData['current_AOD_DT'] = CaseUtils.numberToDate(this.caseVersionData.current_AOD_DT);
                this.caseInfoData['case_CATEGORY_CD'] = CaseUtils.nullFix(this.caseVersionData.theCaseId.case_CATEGORY_CD);
                this.caseInfoData['document_INITIALIZATION_DT'] = CaseUtils.numberToDate(this.caseVersionData.document_INITIALIZATION_DT);
                this.caseInfoData['offer_EXPIRATION_DT'] = CaseUtils.numberToDate(this.caseVersionData.offer_EXPIRATION_DT);
                this.caseInfoData['old_CURRENT_AOD_DT'] = this.caseInfoData['current_AOD_DT'];
                this.caseInfoData['old_OFFER_EXPIRATION_DT'] = this.caseInfoData['offer_EXPIRATION_DT'];
                if (!this.caseVersionData.theCaseId ||
                  !this.caseVersionData.theCaseId.activity_ID ||
                  this.caseVersionData.theCaseId.activity_ID === "") {
                  this.caseInfoData['activity_ID'] = "";
                }
                else {
                  this.caseInfoData['activity_ID'] = this.caseVersionData.theCaseId.activity_ID + " - " + this.caseVersionData.theCaseId.theActivityId.activity_NM;
                }
                this.caseInfoData['customer_TYPE_CD'] = (!this.caseVersionData.theCaseId.theCustomerOrganizationId ? "" : this.caseVersionData.theCaseId.theCustomerOrganizationId.customer_TYPE_CD);
                this.caseInfoData['building_PARTNER_CAPACITY_IN'] = (!this.caseVersionData.theCaseId.theCustomerOrganizationId ? "" : this.caseVersionData.theCaseId.theCustomerOrganizationId.building_PARTNER_CAPACITY_IN);
                this.caseInfoData['case_VERSION_TYPE_CD'] = this.caseVersionData.case_VERSION_TYPE_CD;
                this.caseInfoData['case_VERSION_STATUS_CD'] = this.caseVersionData.case_VERSION_STATUS_CD;
                this.caseInfoData['case_VERSION_NUMBER_ID'] = this.caseVersionData.case_VERSION_NUMBER_ID;

                // Now for the sub-arrays.
                this.caseInfoData["caseMasterServiceTypeList"] = !this.caseVersionData.theCaseId.caseMasterServiceTypeList?[]:this.caseVersionData.theCaseId.caseMasterServiceTypeList;
                this.caseInfoData["casePersonnelRoleList"] = !this.caseVersionData.theCaseId.casePersonnelRoleList?[]:this.caseVersionData.theCaseId.casePersonnelRoleList;
                this.caseInfoData["caseSaleTermList"] = !this.caseVersionData.caseSaleTermList?[]:this.caseVersionData.caseSaleTermList;
                const defaultStatus: number = this._pnlExpansionProperties.isNewMode ? DsamsConstants.ENT_NEW : DsamsConstants.ENT_UNCHANGED;
                this.caseInfoData[DsamsConstants.PROP_CASE_MASTER_STATUS] = defaultStatus;
                this.caseInfoData[DsamsConstants.PROP_CASE_VERSION_STATUS] = defaultStatus;
                this._pnlExpansionProperties.caseRequestParams.caseId = this.caseVersionData.case_ID;
                this._pnlExpansionProperties.caseRequestParams.caseVersionId = this.caseVersionData.case_VERSION_ID;

                this.enableDocumentInitiator(this.caseVersionData.case_VERSION_TYPE_CD,
                  this.caseVersionData.case_VERSION_STATUS_CD,
                  this.caseVersionData.theCaseId.case_MASTER_STATUS_CD);
                this.enableAmendMod(this.caseVersionData.case_VERSION_STATUS_CD, this.caseVersionData.case_VERSION_TYPE_CD);
                this.enableCustomerInformation(this.caseVersionData.case_VERSION_STATUS_CD, this.caseVersionData.case_VERSION_TYPE_CD);
                this.enableCountry(this.caseVersionData.case_VERSION_STATUS_CD, this.caseVersionData.case_VERSION_TYPE_CD);
                this.enableCongressionalNotification(this.caseVersionData.case_VERSION_STATUS_CD);
                this.enableS1Description(this.caseVersionData.case_VERSION_STATUS_CD);
                this.enableCaseInProposed(this.caseVersionData.case_VERSION_STATUS_CD);
                this.enableCaseInReview(this.caseVersionData.case_VERSION_STATUS_CD);
                this.enableDsca(this.caseVersionData.case_VERSION_STATUS_CD);
                this.enableMgr(this.caseVersionData.case_VERSION_STATUS_CD, this.caseVersionData.case_VERSION_TYPE_CD);
                this.enableMildep(this.caseVersionData.case_VERSION_STATUS_CD, this.caseVersionData.case_VERSION_TYPE_CD);
                this.enablePenInk(this.caseVersionData.case_VERSION_STATUS_CD);
                this.enableUpdImplCase(this.caseVersionData.case_VERSION_TYPE_CD);
                this.enableSpecialBillingAgreement(this.caseVersionData.case_VERSION_STATUS_CD);
                this.enableRequisitionForcastIndicator(this.caseVersionData.case_VERSION_STATUS_CD, this.caseVersionData.case_VERSION_TYPE_CD);
                this.enableReserveCaseIdentifier(this.caseVersionData.case_VERSION_TYPE_CD);
                this.enableValidateCase(this.caseVersionData.case_VERSION_TYPE_CD, this.caseVersionData.theCaseId.case_MASTER_STATUS_CD);
                this.enableOrDisableEverything(this._currentToggle);
                this.caseUIService.setcheckMarkSBLInd(this.caseVersionData.sbl_IN);
                this.initializeCustomerServiceArray();
                this.initializeManagerRoleArray(); 
                this.initializeSaleTermArray();
                const csi:CaseSaveInfo = {case_ID: this.caseVersionData.case_ID,
                                          case_VERSION_ID: this.caseVersionData.case_VERSION_ID,
                                          isNewMode: (this.caseInfoData[DsamsConstants.PROP_CASE_VERSION_STATUS] == 1),                                
                                          isNewCaseMaster: (this.caseInfoData[DsamsConstants.PROP_CASE_MASTER_STATUS] == 1),
                                          isEditable: this._pnlExpansionProperties.isNewMode
                                        };
                this.caseUIService.newModeInfo.next(csi);
              }
              this.caseUIService.canSave.next(true);
            }
          }
        );

        if (!this._milestoneAddubscription) {
          this._milestoneAddubscription = this.caseUIService
            .milestoneAddService
            .subscribe((milestoneId: string) => {
              if (!!milestoneId && milestoneId !== "") {
                this.addMilestone(milestoneId);
              }
            });
          }

        this._reloadData = false;
      }
    }
  }

  // ************** Post to the middle-tier *******************

  // Subcsribe to validate or save request.
  subscribeToValidateOrSaveRequest() {
    if (!this._saveSubscription) {
      this._saveSubscription = this.caseUIService.saveRequest.subscribe((pSkipValidation: boolean) => {
        if (this.popupStatus !== 0){
          this.caseInfoData[DsamsConstants.PROP_CASE_MASTER_STATUS]=this.popupStatus;
         }
        let svResults: SaveResultsType = this.savePanel(pSkipValidation);
        this.caseUIService.saveReturnRequest.next(svResults);
      });
    }
  }

  // Do a save request to the middle tier.
  savePanel(pSkipValidation: boolean): SaveResultsType {
    let valResults = new SaveResultsType;
    valResults.currentPanel = DsamsConstants.CASE_PANEL_INFO;
    if (!pSkipValidation) {
      valResults = CaseInfoValidator.validateCaseInfoPanel(this.caseInfoData,
        this._pnlExpansionProperties,
        [this.oedFormControl],
        this.isCaseCategoryDisabled);
    }

    let svResults: SaveResultsType = new SaveResultsType();
    svResults.currentPanel = valResults.currentPanel;
    svResults.messageList = valResults.messageList;
    const valSuccess: boolean = svResults.isValidationSuccessful();

    if (valSuccess || pSkipValidation) {
      // Do save the new way - assemble the contents of the panel into the ICaseVersion data type.
      //
      // Case Master and Case Version
      //
      const currCaseId: number = this._pnlExpansionProperties.caseRequestParams.caseId;
      const currCaseVersionId: number = this._pnlExpansionProperties.caseRequestParams.caseVersionId;

      // Setup initial values for case version.
      let cvEntity: ICaseVersion = Object.assign(
        this.caseVersionData,
        {
          entityName: this.ENTITY_CASE_VERSION,
          status: this.caseInfoData[DsamsConstants.PROP_CASE_VERSION_STATUS],
          case_ID: currCaseId,
          case_VERSION_ID: currCaseVersionId,
          aod_GROUP_CD: this.caseInfoData["aod_GROUP_CD"],
          case_INITIATOR_ACTIVITY_ID: CaseUtils.parseOutID(this.caseInfoData['case_INITIATOR_ACTIVITY_ID']),
          current_AOD_DT: this.caseInfoData['current_AOD_DT'],
          offer_EXPIRATION_DT: this.caseInfoData['offer_EXPIRATION_DT'],
          document_INITIALIZATION_DT: this.caseInfoData['document_INITIALIZATION_DT'],
          case_VERSION_TYPE_CD: this.caseInfoData['case_VERSION_TYPE_CD'],
          case_VERSION_STATUS_CD: this.caseInfoData['case_VERSION_STATUS_CD'],
          case_VERSION_NUMBER_ID: this.caseInfoData['case_VERSION_NUMBER_ID'],
          customer_ORGANIZATION_ID: this._pnlExpansionProperties.caseRequestParams.customerOrganizationId
        });

      if (this.caseInfoData['current_AOD_DT'] !== this.caseInfoData['old_CURRENT_AOD_DT'] ||
          this.caseInfoData['offer_EXPIRATION_DT'] !== this.caseInfoData['old_OFFER_EXPIRATION_DT']) 
      {
        cvEntity.status = this._pnlExpansionProperties.isNewMode ? DsamsConstants.ENT_NEW : DsamsConstants.ENT_CHANGED;
      }

      // Setup initial values for case master.
      let cmEntity: ICaseMaster = Object.assign(
        this.caseVersionData.theCaseId,
        {
          entityName: this.ENTITY_CASE_MASTER,
          status: this.caseInfoData[DsamsConstants.PROP_CASE_MASTER_STATUS],
          case_ID: currCaseId,
          case_NICKNAME_NM: this.caseInfoData["case_NICKNAME_NM"],
          offer_EXPIRATION_DT: this.caseInfoData['offer_EXPIRATION_DT'],
          document_INITIALIZATION_DT: this.caseInfoData['document_INITIALIZATION_DT'],
          case_CATEGORY_CD: this.caseInfoData["case_CATEGORY_CD"],
          activity_ID: CaseUtils.parseOutID(this.caseInfoData["activity_ID"]),
          user_CASE_ID: this._pnlExpansionProperties.caseHeaderData["user_CASE_ID"].replace(/-/g, ""),
          customer_ORGANIZATION_ID: this._pnlExpansionProperties.caseRequestParams.customerOrganizationId,
          implementing_AGENCY_ID: this._pnlExpansionProperties.caseRequestParams.implementingAgencyId,
          security_ASSISTANCE_PROGRAM_CD: this._pnlExpansionProperties.caseRequestParams.securityAssistanceProgramCd,
          case_DESIGNATOR_CD: this._pnlExpansionProperties.caseHeaderData["user_CASE_ID"].replace(/-/g, "").substring(3, 6)
        });
        //
      // Customer Service Array (current items)
      // 
      let cmstArray: Array<ICaseMasterServiceType> = [];
      let cmstFormArray: any = this.caseInfoData["caseMasterServiceTypeList"];
      if (!!cmstFormArray) {
        for (let i = 0; i < cmstFormArray.length; i++) {
          let cmstEntity: ICaseMasterServiceType;
          const procuringAgencyIn: string = cmstFormArray[i]["procuringAgencyIn"] ? "P" : "";
          if (cmstFormArray[i]["status"] == DsamsConstants.ENT_CHANGED &&
            cmstFormArray[i]["customer_SERVICE_TYPE_ID"] !== cmstFormArray[i]["old_CUSTOMER_SERVICE_TYPE_ID"]) {
            // Delete and re-insert record.            
            cmstEntity =
            {
              entityName: this.ENTITY_CASE_MASTER_SERVICE_TYPE,
              status: DsamsConstants.ENT_DELETED,
              case_ID: currCaseId,
              customer_SERVICE_TYPE_ID: cmstFormArray[i]["old_CUSTOMER_SERVICE_TYPE_ID"],
              customer_SERVICE_ROLE_CD: procuringAgencyIn
            };
            cmstArray.push(cmstEntity);
            cmstEntity =
            {
              entityName: this.ENTITY_CASE_MASTER_SERVICE_TYPE,
              status: DsamsConstants.ENT_NEW,
              case_ID: currCaseId,
              customer_SERVICE_TYPE_ID: cmstFormArray[i]["customer_SERVICE_TYPE_ID"],
              customer_SERVICE_ROLE_CD: procuringAgencyIn
            };
            cmstArray.push(cmstEntity);
          }
          else {
            cmstEntity =
            {
              entityName: this.ENTITY_CASE_MASTER_SERVICE_TYPE,
              status: cmstFormArray[i]["status"],
              case_ID: currCaseId,
              customer_SERVICE_TYPE_ID: cmstFormArray[i]["customer_SERVICE_TYPE_ID"],
              customer_SERVICE_ROLE_CD: procuringAgencyIn
            };
            cmstArray.push(cmstEntity);
          }
        }
      }
      //
      // Customer Service Array (deleted items)
      // 
      cmstFormArray = this.caseInfoData["caseMasterServiceTypeDeletedList"];
      if (!!cmstFormArray) {
        for (let i = 0; i < cmstFormArray.length; i++) {
          let cmstEntity: ICaseMasterServiceType =
          {
            entityName: this.ENTITY_CASE_MASTER_SERVICE_TYPE,
            status: DsamsConstants.ENT_DELETED,
            case_ID: currCaseId,
            customer_SERVICE_TYPE_ID: cmstFormArray[i]["customer_SERVICE_TYPE_ID"],
            customer_SERVICE_ROLE_CD: cmstFormArray[i]["procuringAgencyIn"] ? "P" : ""
          };
          cmstArray.push(cmstEntity);
        }
      }
      cmEntity.caseMasterServiceTypeList = cmstArray;
      //
      // Manager Role Array (regular)
      // 
      let cprArray: Array<ICasePersonnelRole> = [];
      let cprFormArray: Array<ICasePersonnelRole> = this.caseInfoData["casePersonnelRoleList"];
      if (!!cprFormArray) {
        for (let i = 0; i < cprFormArray.length; i++) {
          if (cprFormArray[i]["status"] == DsamsConstants.ENT_NEW || cprFormArray[i]["status"] == DsamsConstants.ENT_CHANGED) {
            // Do an add and remove for changed recs.            
            let cprEntity: ICasePersonnelRole =
            {
              entityName: this.ENTITY_CASE_PERSONNEL_ROLE,
              status: DsamsConstants.ENT_NEW,
              case_ID: currCaseId,
              management_ROLE_ID: cprFormArray[i]["management_ROLE_ID"],
              user_ID: cprFormArray[i]["user_ID"]
            };
            cprArray.push(cprEntity);
            if (
              (!!cprFormArray[i]["old_MANAGEMENT_ROLE_ID"] && cprFormArray[i]["old_MANAGEMENT_ROLE_ID"] !== cprFormArray[i]["management_ROLE_ID"]) ||
              (!!cprFormArray[i]["old_USER_ID"] && cprFormArray[i]["old_USER_ID"] !== cprFormArray[i]["user_ID"])
            ) {
              let cprDelEntity: ICasePersonnelRole =
              {
                entityName: this.ENTITY_CASE_PERSONNEL_ROLE,
                status: DsamsConstants.ENT_DELETED,
                case_ID: currCaseId,
                management_ROLE_ID: cprFormArray[i]["old_MANAGEMENT_ROLE_ID"],
                user_ID: cprFormArray[i]["old_USER_ID"]
              };
              cprArray.push(cprDelEntity);
            }
          }
          else {
            let cprEntity: ICasePersonnelRole =
            {
              entityName: this.ENTITY_CASE_PERSONNEL_ROLE,
              status: DsamsConstants.ENT_UNCHANGED,
              case_ID: currCaseId,
              management_ROLE_ID: cprFormArray[i]["management_ROLE_ID"],
              user_ID: cprFormArray[i]["user_ID"]
            };
            cprArray.push(cprEntity);
          }
        }
      }
      //
      // Manager Role Array (deleted)
      // 
      cprFormArray = this.caseInfoData["casePersonnelRoleDeletedList"];
      if (!!cprFormArray) {
        for (let i = 0; i < cprFormArray.length; i++) {
          let cprEntity: ICasePersonnelRole =
          {
            entityName: this.ENTITY_CASE_PERSONNEL_ROLE,
            status: DsamsConstants.ENT_DELETED,
            case_ID: currCaseId,
            management_ROLE_ID: cprFormArray[i]["management_ROLE_ID"],
            user_ID: cprFormArray[i]["user_ID"]
          };
          cprArray.push(cprEntity);
        }
      }
      cmEntity.casePersonnelRoleList = cprArray;
      //
      // Term of Sale Array (regular)
      //       
      let cstArray: Array<ICaseSaleTerm> = [];
      let cstFormArray: Array<ICaseSaleTerm> = this.caseInfoData["caseSaleTermList"];
      if (!!cstFormArray) {
        for (let i = 0; i < cstFormArray.length; i++) {
          // If there was a change in the Case_sale_term then we create a new and delete, otherwise just regular update.
          if (cstFormArray[i]["status"] == DsamsConstants.ENT_CHANGED &&
            !!cstFormArray[i]["old_SALE_TERM_ID"] &&
            cstFormArray[i]["old_SALE_TERM_ID"] !== cstFormArray[i]["sale_TERM_ID"]) {
            let cstEntity: ICaseSaleTerm =
            {
              entityName: this.ENTITY_CASE_SALE_TERM,
              status: DsamsConstants.ENT_NEW,
              case_ID: currCaseId,
              case_SALE_TERM_AM: CaseUtils.unformatCurrency(cstFormArray[i]["case_SALE_TERM_AM"]),
              case_SALE_TERM_SEQ_CD: cstFormArray[i]["case_SALE_TERM_SEQ_CD"],
              case_VERSION_ID: currCaseVersionId,
              fiscal_YEAR_ID: cstFormArray[i]["fiscal_YEAR_ID"],
              public_LAW_ID: cstFormArray[i]["public_LAW_ID"],
              sale_TERM_ID: cstFormArray[i]["sale_TERM_ID"]
            };
            cstArray.push(cstEntity);
            cstEntity = {
              entityName: this.ENTITY_CASE_SALE_TERM,
              status: DsamsConstants.ENT_DELETED,
              case_ID: currCaseId,
              case_SALE_TERM_AM: CaseUtils.unformatCurrency(cstFormArray[i]["case_SALE_TERM_AM"]),
              case_SALE_TERM_SEQ_CD: cstFormArray[i]["case_SALE_TERM_SEQ_CD"],
              case_VERSION_ID: currCaseVersionId,
              fiscal_YEAR_ID: cstFormArray[i]["fiscal_YEAR_ID"],
              public_LAW_ID: cstFormArray[i]["public_LAW_ID"],
              sale_TERM_ID: cstFormArray[i]["old_SALE_TERM_ID"]
            };
            cstArray.push(cstEntity);
          }
          else {
            // Regular update or insert.
            let cstEntity: ICaseSaleTerm =
            {
              entityName: this.ENTITY_CASE_SALE_TERM,
              status: cstFormArray[i]["status"],
              case_ID: currCaseId,
              case_SALE_TERM_AM: CaseUtils.unformatCurrency(cstFormArray[i]["case_SALE_TERM_AM"]),
              case_SALE_TERM_SEQ_CD: cstFormArray[i]["case_SALE_TERM_SEQ_CD"],
              case_VERSION_ID: currCaseVersionId,
              fiscal_YEAR_ID: cstFormArray[i]["fiscal_YEAR_ID"],
              public_LAW_ID: cstFormArray[i]["public_LAW_ID"],
              sale_TERM_ID: cstFormArray[i]["sale_TERM_ID"]
            };
            cstArray.push(cstEntity);
          }
        }
      }
      //
      // Term of Sale Array (deleted)
      //    
      cstFormArray = this.caseInfoData["caseSaleTermDeletedList"];
      if (!!cstFormArray) {
        for (let i = 0; i < cstFormArray.length; i++) {
          let cstEntity: ICaseSaleTerm =
          {
            entityName: this.ENTITY_CASE_SALE_TERM,
            status: DsamsConstants.ENT_DELETED,
            case_ID: currCaseId,
            case_SALE_TERM_AM: cstFormArray[i]["case_SALE_TERM_AM"],
            case_SALE_TERM_SEQ_CD: cstFormArray[i]["case_SALE_TERM_SEQ_CD"],
            case_VERSION_ID: currCaseVersionId,
            fiscal_YEAR_ID: cstFormArray[i]["fiscal_YEAR_ID"],
            public_LAW_ID: cstFormArray[i]["public_LAW_ID"],
            sale_TERM_ID: cstFormArray[i]["sale_TERM_ID"]
          };
          cstArray.push(cstEntity);
        }
      }
      cvEntity.caseSaleTermList = cstArray;
      //
      // Apply case version to case ID.
      //
      cvEntity.theCaseId = cmEntity;
      //
      // Apply the Case Version Milestone list, but only those that are newly added.
      //
      cvEntity.caseVersionMilestoneList = !this.caseVersionData.caseVersionMilestoneList ? [] : this.caseVersionData.caseVersionMilestoneList.filter(cvmItem => cvmItem.status == DsamsConstants.ENT_NEW);
      // 
      svResults.caseVersionPanelData = cvEntity;      
      this.subscribeToSaveComplete();
    }
    return svResults;
  }

  // Subscribe to Save Complete
  // and reset everything when save is complete and successful.
  subscribeToSaveComplete() {
    if (!this._saveCompleteSubscription) {
      this._saveCompleteSubscription = this.caseUIService.saveCaseVersionComplete.subscribe((pReturnCaseVersion: ICaseVersion) => {
        if (!!pReturnCaseVersion) {
          this.caseUIService.theComponentSaveState[CaseUIService.SAVE_CASE_DETAILS_STATE].isDataChanged = false;
          this.caseUIService.theComponentSaveState[CaseUIService.SAVE_CASE_DETAILS_STATE].isSaveConfirmed.next(false);      
          this.caseInfoData['old_CURRENT_AOD_DT'] = this.caseInfoData['current_AOD_DT'];
          this.caseInfoData['old_OFFER_EXPIRATION_DT'] = this.caseInfoData['offer_EXPIRATION_DT'];
          this.caseVersionData.caseVersionMilestoneList = [];
          this.caseInfoData["caseMasterServiceTypeDeletedList"] = [];
          this.caseInfoData["caseMasterServiceTypeList"] = !pReturnCaseVersion.theCaseId.caseMasterServiceTypeList ? [] : pReturnCaseVersion.theCaseId.caseMasterServiceTypeList.filter(elem => elem.status != DsamsConstants.ENT_DELETED);
          if (!!this.caseInfoData["caseMasterServiceTypeList"]) {
            this.aCustomerServiceRowIndex = this.caseInfoData["caseMasterServiceTypeList"].length;
            for (let i = 0; i < this.aCustomerServiceRowIndex; i++) {
              this.caseInfoData["caseMasterServiceTypeList"][i] = Object.assign(this.caseInfoData["caseMasterServiceTypeList"][i],
                {
                  rowNum: (i + 1),
                  status: DsamsConstants.ENT_UNCHANGED,
                  procuringAgencyIn: this.caseInfoData["caseMasterServiceTypeList"][i].customer_SERVICE_ROLE_CD === "P",
                  old_CUSTOMER_SERVICE_TYPE_ID: this.caseInfoData["caseMasterServiceTypeList"][i].customer_SERVICE_TYPE_ID
                });
            }
          }
          else {
            this.aCustomerServiceRowIndex = 0;
          }
          this.resetProcuringAgencyObject();
          this.caseInfoData["casePersonnelRoleList"] = pReturnCaseVersion.theCaseId.casePersonnelRoleList.filter(elem => elem.status != DsamsConstants.ENT_DELETED);
          this.caseInfoData["casePersonnelRoleDeletedList"] = [];
          if (!!this.caseInfoData["casePersonnelRoleList"]) {
            this.aManagerRoleRowIndex = this.caseInfoData["casePersonnelRoleList"].length;
            for (let i = 0; i < this.aManagerRoleRowIndex; i++) {
              this.caseInfoData["casePersonnelRoleList"][i] = Object.assign(this.caseInfoData["casePersonnelRoleList"][i],
                {
                  status: DsamsConstants.ENT_UNCHANGED,
                  old_MANAGEMENT_ROLE_ID: this.caseInfoData["casePersonnelRoleList"][i]["management_ROLE_ID"],
                  old_USER_ID: this.caseInfoData["casePersonnelRoleList"][i]["user_ID"]
                });
            }
          }
          else {
            this.aManagerRoleRowIndex = 0;
          }
          this.caseInfoData["caseSaleTermList"] = pReturnCaseVersion.caseSaleTermList.filter(elem => elem.status != DsamsConstants.ENT_DELETED);
          this.caseInfoData["caseSaleTermDeletedList"] = [];
          if (!!this.caseInfoData["caseSaleTermList"]) {
            this.aSaleTermRowIndex = this.caseInfoData["caseSaleTermList"].length;
            for (let i = 0; i < this.aSaleTermRowIndex; i++) {
              this.caseInfoData["caseSaleTermList"][i] = Object.assign(this.caseInfoData["caseSaleTermList"][i],
                {
                  rowNum: (i + 1),
                  status: DsamsConstants.ENT_UNCHANGED,
                  old_SALE_TERM_ID: this.caseInfoData["caseSaleTermList"][i].sale_TERM_ID
                });
            }
          }
          else {
            this.aSaleTermRowIndex = 0;
          }
          if (!!this.caseVersionData.caseVersionMilestoneList) {
            for (let i = 0; i < this.caseVersionData.caseVersionMilestoneList.length; i++) {
              if (this.caseVersionData.caseVersionMilestoneList[i].status != DsamsConstants.ENT_DELETED) {
                this.caseVersionData.caseVersionMilestoneList[i].status = DsamsConstants.ENT_UNCHANGED;
              }
              if (!!this.caseVersionData.caseVersionMilestoneList[i].caseMilestoneRevisionList) {
                for (let j = 0; j < this.caseVersionData.caseVersionMilestoneList[i].caseMilestoneRevisionList.length; j++) {
                  if (this.caseVersionData.caseVersionMilestoneList[i].caseMilestoneRevisionList[j].status != DsamsConstants.ENT_DELETED) {
                    this.caseVersionData.caseVersionMilestoneList[i].caseMilestoneRevisionList[j].status = DsamsConstants.ENT_UNCHANGED;
                  }
                }
              }
            }
          }

          this._pnlExpansionProperties.isNewMode = false;
          this.popupStatus=0;
          this._pnlExpansionProperties.caseRequestParams.caseId = pReturnCaseVersion.case_ID;
          this._pnlExpansionProperties.caseRequestParams.caseVersionId = pReturnCaseVersion.case_VERSION_ID;
          this.caseInfoData[DsamsConstants.PROP_CASE_VERSION_STATUS] = DsamsConstants.ENT_UNCHANGED;
          this.caseInfoData[DsamsConstants.PROP_CASE_MASTER_STATUS] = DsamsConstants.ENT_UNCHANGED;  
          this.caseInfoData["case_ID"] = pReturnCaseVersion.case_ID;
          this.caseInfoData["case_VERSION_ID"] = pReturnCaseVersion.case_VERSION_ID; 
          this.enableOrDisableEverything(this._currentToggle);   
          const csi:CaseSaveInfo = {case_ID: pReturnCaseVersion.case_ID,
                                    case_VERSION_ID: pReturnCaseVersion.case_VERSION_ID,
                                    isNewMode: this._pnlExpansionProperties.isNewMode,                                    
                                    isNewCaseMaster: (this._pnlExpansionProperties.isNewMode && pReturnCaseVersion.case_VERSION_TYPE_CD === "B"),
                                    isEditable: this._currentToggle
                                  };
          this.caseUIService.newModeInfo.next(csi); 
        }
      });
    }
  }

}  // End of class