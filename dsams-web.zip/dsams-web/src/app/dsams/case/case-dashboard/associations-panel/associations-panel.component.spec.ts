import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AssociationsPanelComponent } from './associations-panel.component';

describe('AssociationsPanelComponent', () => {
  let component: AssociationsPanelComponent;
  let fixture: ComponentFixture<AssociationsPanelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AssociationsPanelComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssociationsPanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
