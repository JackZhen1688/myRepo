/* 
  Author: David Huynh 
  Date:   21/28/2020 
*/

import { Component, OnInit, OnDestroy, ViewChild, ElementRef } from '@angular/core';
import { CaseRestfulService } from '../../services/case-restful.service';
import { CaseUIService } from '../../services/case-ui-service';
import { Subscription } from 'rxjs';
import { DsamsConstants } from 'src/app/dsams/dsams.constants';
import { ReferenceDataType } from '../../model/reference-data-type';
import { CaseUtils } from '../../utils/case-utils';
import { PanelExpansionProperties } from '../../model/panel-expansion-properties';
import { FieldDisabledMap } from '../../model/field-disabled-map';
import { SaveResultsType } from '../../validation/save-results-type';
import { MessageMgr } from '../../validation/message-mgr';
import { CaseCustomerRequestValidator } from '../../validation/case-customer-request-validator';
import { ICaseVersion } from '../../model/dto/icase-version';
import { ICustomerRequest } from '../../model/dto/customer-request';
import { DsamsMethodsService } from 'src/app/dsams/services/dsams-methods.service';
import { FormGroup } from '@angular/forms';
import { PopCustomerRequestComponent } from 'src/app/dsams/utilitis/popups/pop-customer-request/pop-customer-request.component';
import { IEditResponseType } from '../../model/edit-response-type';
import { CaseSaveInfo } from '../../model/case-save-info';


@Component({
  selector: 'app-customer-request-panel',
  templateUrl: './customer-request-panel.component.html',
  styleUrls: ['./customer-request-panel.component.css',
              '../case-dashboard.component.css',
              '../common-CSS.component.css']
})
export class CustomerRequestPanelComponent implements OnInit, OnDestroy {
  @ViewChild('custRequestForm', {static:true})
  private _customerRequestForm: ElementRef;
  public caseCustomerRequestData: any = {};
  private _caseUIServiceSubscription:Subscription;
  private _reloadData:boolean = true;
  private _reloadReferenceData: boolean = true;
  private _pnlExpansionProperties: PanelExpansionProperties;
  private fieldDisabledMap: FieldDisabledMap = {};
  private customerRequestIdMessageCd:string = DsamsConstants.NO_ERROR;
  private _saveSubscription: Subscription = null;
  private _dataSubscription: Subscription;
  private _popupCRSubscription: Subscription = null;
  private _editSubscription: Subscription = null;
  private _saveCompleteSubscription: Subscription = null;
  private _newModeInfoSubscription: Subscription = null;
  private _panelCollapedSubscription: Subscription = null;
  private _casePanelStatusQuerySubscription: Subscription = null;
  private _isGotInfoFromCIPanel: boolean = false;
  private _currentToggle:boolean = false;
  private _alreadyToggledOn: boolean = false;
  private _skipSavePanel:boolean = false;
  caseVersionData: ICaseVersion;
  popupStatus:number=0;

  // Reference Lists
  refSecurityClassificationList: Array<ReferenceDataType> = [];

  constructor(private caseRestService: CaseRestfulService,
              private caseUIService: CaseUIService,
              public dsamsDialogMsgService: DsamsMethodsService) { }

  ngOnInit() { 
    // Only fetch data when the panel is opened.
    this._caseUIServiceSubscription = this.caseUIService.panelExpanded.subscribe(
        {
        next:(pnlExpansionProperties:PanelExpansionProperties) => {
          if (pnlExpansionProperties.panelName === DsamsConstants.CASE_PANEL_CUSTOMER_REQUEST || 
              pnlExpansionProperties.panelName === DsamsConstants.CASE_PANEL_ALL) 
          {
              this._pnlExpansionProperties = pnlExpansionProperties;
              if (this._pnlExpansionProperties.isResetPanels) {
                this._reloadData = true;
              }
              if (this._reloadData) {
                this.fetchReferenceData();
                this.subscribeToDataService();

                // Subscribe to save or validate request.
                this.subscribeToValidateOrSaveRequest();

                // Subscribe to case panel check.
                this.subscribeToCasePanelStatusQuery();

                // Subscribe to edit
                this.subscribeToEdit();
              }
              // Make sure everything is enabled for new mode.
              if (this._pnlExpansionProperties.isNewMode) {
                this._currentToggle = true;
                this.enableOrDisableEverything(this._currentToggle);
              }
              this.subscribeToSaveComplete();
              this.subscribeToNewModeInfo();
              this.subscribeToPanelCollapsed();
              this._skipSavePanel = false;
          }
        }
      });
  }

  // Subscribe to panel collapsing
  subscribeToPanelCollapsed() {
    if (!this._panelCollapedSubscription) {
      this._panelCollapedSubscription = this.caseUIService.panelCollapsed.subscribe((panelName: string) => {
        if (panelName === DsamsConstants.CASE_PANEL_CUSTOMER_REQUEST || panelName === DsamsConstants.CASE_PANEL_ALL) 
        {
           this._skipSavePanel = true;
        }
      });
    }
  }


  getCaseCustomerRequestData():any {
    return this.caseCustomerRequestData;
  }


  getCustomerRequestForm():ElementRef {
    return this._customerRequestForm;
  }


  hasCustomerRequestError():boolean {    
    return (!(this.fieldDisabled('customer_REQUEST_ID')) && this.customerRequestIdMessageCd !== DsamsConstants.NO_ERROR);
  }


  showCustomerRequestErrorMessage():string {
    if (this.hasCustomerRequestError) {
      return MessageMgr.getMesssage(this.customerRequestIdMessageCd).messageText;
    }
    else {
      return DsamsConstants.NO_ERROR;
    }
  }


  fieldDisabled(pFieldName: string): boolean {
    return CaseUtils.isFieldDisabled(this.fieldDisabledMap, DsamsConstants.CASE_PANEL_CUSTOMER_REQUEST, pFieldName);
  }


  // Make sure panel expansion subscription is cleaned up.
  ngOnDestroy() {
    this._caseUIServiceSubscription.unsubscribe();
    if (!!this._saveSubscription) {
      this._saveSubscription.unsubscribe();
      this._saveSubscription = null;
    }
    if (!!this._dataSubscription) {
      this._dataSubscription.unsubscribe();
    }
    if (!!this._popupCRSubscription) {
      this._popupCRSubscription.unsubscribe();
    }
    if (!!this._editSubscription) {
      this._editSubscription.unsubscribe();
      this._editSubscription = null;
    }
    if (!!this._saveCompleteSubscription) {
      this._saveCompleteSubscription.unsubscribe();
      this._saveCompleteSubscription = null;
    }
    if (!!this._newModeInfoSubscription) {
      this._newModeInfoSubscription.unsubscribe();
      this._newModeInfoSubscription = null;
    }
    if (!!this._panelCollapedSubscription) {
      this._panelCollapedSubscription.unsubscribe();
      this._panelCollapedSubscription = null;
    }
    if (!!this._casePanelStatusQuerySubscription) {
      this._casePanelStatusQuerySubscription.unsubscribe();
      this._casePanelStatusQuerySubscription = null;
    }
  } 

  // Flag the field as changed so we can update the record upon save.
  setChanged() {
    this.caseCustomerRequestData[DsamsConstants.PROP_CASE_VERSION_STATUS] = this._pnlExpansionProperties.isNewMode?DsamsConstants.ENT_NEW:DsamsConstants.ENT_CHANGED;
    if (this.caseCustomerRequestData[DsamsConstants.PROP_CASE_VERSION_STATUS] == DsamsConstants.ENT_UNCHANGED) {
      this.caseUIService.theComponentSaveState[CaseUIService.SAVE_CASE_DETAILS_STATE].isDataChanged = false;
    }
    else
      this.caseUIService.theComponentSaveState[CaseUIService.SAVE_CASE_DETAILS_STATE].isDataChanged = true;
  }

  setChangedPopup() {
    this.popupStatus= this._pnlExpansionProperties.isNewMode?DsamsConstants.ENT_NEW:DsamsConstants.ENT_CHANGED;
    if (this.caseCustomerRequestData[DsamsConstants.PROP_CASE_VERSION_STATUS] == DsamsConstants.ENT_UNCHANGED) {
      this.caseUIService.theComponentSaveState[CaseUIService.SAVE_CASE_DETAILS_STATE].isDataChanged = false;
    }
    else
      this.caseUIService.theComponentSaveState[CaseUIService.SAVE_CASE_DETAILS_STATE].isDataChanged = true;   
  }

  getFieldStyleProperty(pElementName:string, isAppearanceNotStyle:boolean):string|object {
    const ERROR_APPEARANCE:string = DsamsConstants.ERROR_APPEARANCE;
    const REGULAR_APPEARANCE:string = DsamsConstants.REGULAR_APPEARANCE;
    const ERROR_STYLE_1 = {"border":"2px solid red", "padding-top":"3%", "padding-bottom":"3%", "border-radius":"4px", "vertical-align":"top", "margin-top":"-20px"};
    let isError:boolean = false;    
    let styleStr:object = {};
    if (pElementName === "customer_REQUEST_ID") {
      isError = this.hasCustomerRequestError();
      styleStr = ERROR_STYLE_1;
    }
    if (isAppearanceNotStyle) {
      return isError?ERROR_APPEARANCE:REGULAR_APPEARANCE;
    }
    else {
      return isError?styleStr:{};
    }    
  }


  checkCustomerRequestId() {
    const custReqId:string = this.caseCustomerRequestData['customer_REQUEST_ID'];
    const custOrgId:string = this._pnlExpansionProperties.caseRequestParams.customerOrganizationId;
    let checkDB:boolean = true;

    // Disable save while we check on the Cust Req ID.
    this.caseUIService.canSave.next(false);

    if (custReqId == null || custReqId === "") 
    {
      this.customerRequestIdMessageCd = "E011"
      checkDB = false;
    }

    if (isNaN(+custReqId)) {
      this.customerRequestIdMessageCd = "E012";
      checkDB = false;
    }

    if (!checkDB) {
      this.caseUIService.canSave.next(true);
      return;
    }    

    // Validate Customer Request ID.
    this.caseRestService
        .getCustomerRequest(+custReqId, custOrgId)
        .subscribe(custReq => 
            {
               const custReqData:ICustomerRequest = <ICustomerRequest>custReq;
               if (custReqData.customer_REQUEST_ID  == 0) {
                   this.customerRequestIdMessageCd = "E013";                
               }
               else {
                  this.customerRequestIdMessageCd = DsamsConstants.NO_ERROR; 
                  this.caseCustomerRequestData['customer_REQUEST_ID'] = custReqData.customer_REQUEST_ID;
                  this.caseCustomerRequestData['security_CD'] = custReqData.security_CD;
                  this.caseCustomerRequestData['security_CD_CR'] = custReqData.security_CD;
                  this.caseCustomerRequestData['request_STATUS_TITLE_NM'] = custReqData.theCustomerRequestStatusCd.request_STATUS_TITLE_NM;
                  this.caseCustomerRequestData['customer_REQUEST_ACTION_TX'] = custReqData.customer_REQUEST_ACTION_TX;
                  this.caseCustomerRequestData['customer_REQUEST_END_ITEM_TX'] = custReqData.customer_REQUEST_END_ITEM_TX;
              } 
              this.caseUIService.canSave.next(true);
            },
          err => 
            {
              CaseUtils.ReportHTTPError(err, "Unable to check Customer Request ID.");
              this.caseUIService.canSave.next(true);
            }            
        );
  }


  checkCustomerRequestIdJustBeforeSave() {
    const custReqId:string = this.caseCustomerRequestData['customer_REQUEST_ID'];
    const custOrgId:string = this._pnlExpansionProperties.caseRequestParams.customerOrganizationId;
    let checkDB:boolean = true;
    // Disable save while we check on the Cust Req ID.
    this.caseUIService.canSave.next(false);

    if (custReqId == null || custReqId === "") 
    {
      this.customerRequestIdMessageCd = "E011"
      checkDB = false;
    }

    if (isNaN(+custReqId)) {
      this.customerRequestIdMessageCd = "E012";
      checkDB = false;
    }

    if (!checkDB) {
      this.caseUIService.canSave.next(true);
      return;
    }
    
    // Validate Customer Request ID.
    this.caseRestService
        .getCustomerRequest(+custReqId, custOrgId)
        .subscribe(custReq => 
            {
               const custReqData:ICustomerRequest = <ICustomerRequest>custReq;
               if (custReqData.customer_REQUEST_ID  == 0) {
                  this.customerRequestIdMessageCd = "E013";
               }
               else {
                this.customerRequestIdMessageCd = DsamsConstants.NO_ERROR;              
              }              
              this.caseUIService.canSave.next(true);
            },
            err => 
            {
              CaseUtils.ReportHTTPError(err, "Unable to check Customer Request ID.");
              this.caseUIService.canSave.next(true);
            }
        );    
  }

  fetchReferenceData() {
    if (this._reloadReferenceData) {
      // Reference: Security Classification
      this.caseRestService
          .getReferenceData(DsamsConstants.REF_SECURITY_CLASSIFICATION, "", 0, true)
          .subscribe (
            data => {
              this.refSecurityClassificationList = data;
            },
            err => {
              CaseUtils.ReportHTTPError(err, "Error fetching reference for " + DsamsConstants.REF_SECURITY_CLASSIFICATION);
            }          
      );
      this._reloadReferenceData = false;
    }
  }

  // Subscribe to edit toggle event
  subscribeToEdit() {
    if (!this._editSubscription) {
      this._editSubscription = this.caseUIService
                                   .caseEditService
                                   .subscribe((pResponse:IEditResponseType) =>
        {
          if (pResponse && (pResponse.ID === DsamsConstants.CASE_VERSION_EDITOR || pResponse.ID === DsamsConstants.PAGE_CASE_DETAIL)) {
            this.enableOrDisableEverything(pResponse.editToggle);
            this._currentToggle = pResponse.editToggle;
            if (this._currentToggle) {
              this._alreadyToggledOn = true;
            }
          }
        },
        err => {
          CaseUtils.ReporError("Error in customer-request responding to edit toggle");
        }       
      );
    }
  }

  // Enable or Disable everything on the panel.
  enableOrDisableEverything(pEnable:boolean) {
    let l_isEnabled:boolean = this._pnlExpansionProperties.isNewMode?true:pEnable;
    this.fieldDisabledMap[DsamsConstants.CASE_PANEL_CUSTOMER_REQUEST] = !l_isEnabled;
    if (l_isEnabled) {
      this.initializePanelFields();
    }
  }


  initializePanelFields() {
    this.fieldDisabledMap['customer_REQUEST_ID'] = (<boolean>CaseUtils.getBusinessRuleMapValue(this.caseVersionData.businessRuleMap, "CUSTOMER_REQUEST_DISABLED", false));
    this.fieldDisabledMap['customer_REQUEST_ACTION_TX'] = (<boolean>CaseUtils.getBusinessRuleMapValue(this.caseVersionData.businessRuleMap, "CUSTOMER_REQUEST_ACTION_DISABLED", false));
    this.fieldDisabledMap['customer_REQUEST_END_ITEM_TX'] = (<boolean>CaseUtils.getBusinessRuleMapValue(this.caseVersionData.businessRuleMap, "CUSTOMER_REQUEST_END_ITEM_DISABLED", false));
  }


   // Add the subscription for this panel
   // for getting the data from the dashboard.
    subscribeToDataService() {
      if (this._reloadData) {
        this._dataSubscription = this.caseUIService.caseDetailData.subscribe(
          {
            next: (caseDetailData: ICaseVersion) => {
              if (caseDetailData) {
                this.caseVersionData = caseDetailData;
                CaseUtils.populateCaseRequestParamsType(this._pnlExpansionProperties.caseRequestParams, this.caseVersionData);
                this.caseCustomerRequestData['customer_REQUEST_ID'] = this.caseVersionData.customer_REQUEST_ID;
                this.caseCustomerRequestData['security_CD'] = this.caseVersionData.security_CD;
                this.caseCustomerRequestData['security_CD_CR'] = this.caseVersionData.theCustomerRequestId.security_CD;
                if (!(this.caseCustomerRequestData['security_CD']) || this.caseCustomerRequestData['security_CD'] === "") {
                  this.caseCustomerRequestData['security_CD'] = this.caseCustomerRequestData['security_CD_CR'];
                }
                this.caseCustomerRequestData['request_STATUS_TITLE_NM'] = this.caseVersionData.theCustomerRequestId.theCustomerRequestStatusCd.request_STATUS_TITLE_NM;
                this.caseCustomerRequestData['customer_REQUEST_ACTION_TX'] = this.caseVersionData.theCustomerRequestId.customer_REQUEST_ACTION_TX;
                this.caseCustomerRequestData['customer_REQUEST_END_ITEM_TX'] = this.caseVersionData.theCustomerRequestId.customer_REQUEST_END_ITEM_TX;
                this.enableOrDisableEverything(this._currentToggle);
                // Don't show 0 but instead blank for cust request ID if there is none.
                if (this.caseCustomerRequestData['customer_REQUEST_ID'] === 0)
                {                   
                  this.caseCustomerRequestData['customer_REQUEST_ID'] = String(this.caseCustomerRequestData['customer_REQUEST_ID']);
                  this.caseCustomerRequestData['customer_REQUEST_ID'] = "";                    
                }
                this.customerRequestIdMessageCd = "";     
                this.caseCustomerRequestData[DsamsConstants.PROP_CASE_VERSION_STATUS] = this._pnlExpansionProperties.isNewMode?DsamsConstants.ENT_NEW:DsamsConstants.ENT_UNCHANGED;
                this._pnlExpansionProperties.caseRequestParams.caseId = this.caseVersionData.case_ID;        
                this._pnlExpansionProperties.caseRequestParams.caseVersionId = this.caseVersionData.case_VERSION_ID;                      
              }
            }
          }
        );
        this._reloadData = false;
      }
    }

    /** ********************************* Popups ****************************************** */
    // Person Customer Request
    popupCR() {
      let tmpFormGroup: FormGroup;
      let pTitle:string = "Customer Request Search";
      this.dsamsDialogMsgService.openSearchDialogCase(DsamsConstants.PERSON_POPUP_WIDTH, 
                                                      DsamsConstants.PERSON_POPUP_HEIGHT, 
                                                      this._pnlExpansionProperties.caseRequestParams.customerOrganizationId, 
                                                      PopCustomerRequestComponent, 
                                                      tmpFormGroup, 
                                                      pTitle);
      this.subscribeToPopupCR();                                                      
    }

    /**
     * Subscribe to popup 
     */
    subscribeToPopupCR() {
      if (!this._popupCRSubscription) {
        this._popupCRSubscription = this.dsamsDialogMsgService
                                        .selectedCRFromPopupValue    
                                        .subscribe((selectedVal:ICustomerRequest) => 
          {
            if (!!selectedVal) {
              this.caseCustomerRequestData['customer_REQUEST_ID'] = selectedVal.customer_REQUEST_ID;
              this.setChanged();
              this.setChangedPopup();
              this.checkCustomerRequestId();       
            }
          },
          err => {
            CaseUtils.ReporError("Error in dsamsMethodsService.popupCustomerRequest in case info");
          }
        );
      }
    }    


  // Subscribe to Case Panel Status
  subscribeToCasePanelStatusQuery() {
    if (!this._casePanelStatusQuerySubscription) {
      this._casePanelStatusQuerySubscription = this.caseUIService.getPanelCaseVersionStatusQuerySubscription().subscribe(() => {
        this.caseUIService.panelCaseVersionStatusResponseSubscriptionNext(DsamsConstants.CASE_PANEL_CUSTOMER_REQUEST,
                                                                          this.caseCustomerRequestData[DsamsConstants.PROP_CASE_VERSION_STATUS],
                                                                          this._pnlExpansionProperties.caseRequestParams.caseId,
                                                                          this._pnlExpansionProperties.caseRequestParams.caseVersionId);
      });
    }
  }    

  // ************************** Validate/Save *****************************

  // Subcsribe to validate or save request.
  subscribeToValidateOrSaveRequest() {
    if (this._saveSubscription == null) {
      this._saveSubscription = this.caseUIService.saveRequest.subscribe((pSkipValidation:boolean) => {
        if (this.popupStatus !== 0){
          this.caseCustomerRequestData[DsamsConstants.PROP_CASE_VERSION_STATUS]=this.popupStatus;
         }
        if (!this._skipSavePanel) {
          let svResults: SaveResultsType = this.savePanel(pSkipValidation);
          this.caseUIService.saveReturnRequest.next(svResults);
        }
      });
    }
  }

    // Do a validate/save request to the middle tier.
    savePanel(pSkipValidation:boolean): SaveResultsType {
      let valResults = new SaveResultsType;
      valResults.currentPanel = DsamsConstants.CASE_PANEL_CUSTOMER_REQUEST;
      if (!pSkipValidation) {
        this.checkCustomerRequestIdJustBeforeSave();
        valResults = CaseCustomerRequestValidator.validateCustomerRequestPanel
                                                    (this.caseCustomerRequestData, 
                                                    this._pnlExpansionProperties, 
                                                    [this.customerRequestIdMessageCd]);
      }
  
      let svResults: SaveResultsType = new SaveResultsType();
      svResults.currentPanel = valResults.currentPanel;
      svResults.messageList = valResults.messageList;

      if (svResults.isValidationSuccessful()) {
       // Assemble the Json object for passing to the dashboard and then to the back-end.
        let cvEntity:ICaseVersion = { 
          status: this.caseCustomerRequestData[DsamsConstants.PROP_CASE_VERSION_STATUS],
          customer_REQUEST_ID: this.caseCustomerRequestData['customer_REQUEST_ID'],
          security_CD: this.caseCustomerRequestData['security_CD']
        };  
        svResults.caseVersionPanelData = cvEntity;
        this._isGotInfoFromCIPanel = false;
      }
      return svResults;  
  }

  // Post-save activities
  subscribeToSaveComplete() {
    if (!this._saveCompleteSubscription) {
      this._saveCompleteSubscription = this.caseUIService.saveCaseVersionComplete.subscribe((pReturnCaseVersion: ICaseVersion) => {
        if (!!pReturnCaseVersion) {
          this.caseUIService.theComponentSaveState[CaseUIService.SAVE_CASE_DETAILS_STATE].isDataChanged = false;
          this.caseUIService.theComponentSaveState[CaseUIService.SAVE_CASE_DETAILS_STATE].isSaveConfirmed.next(false);      
          if (this._isGotInfoFromCIPanel) {
            this._isGotInfoFromCIPanel = false;
          }          
          this.caseCustomerRequestData[DsamsConstants.PROP_CASE_VERSION_STATUS] = DsamsConstants.ENT_UNCHANGED;
          this._pnlExpansionProperties.caseRequestParams.caseId = pReturnCaseVersion.case_ID;
          this._pnlExpansionProperties.caseRequestParams.caseVersionId = pReturnCaseVersion.case_VERSION_ID;
          this._pnlExpansionProperties.isNewMode = false;
          this.popupStatus=0;
          this.enableOrDisableEverything(this._currentToggle);
        }
      });
    }
  }

  // Subscribe to new mode info coming from CI panel.
  subscribeToNewModeInfo() {
    if (!this._newModeInfoSubscription) {
      this._newModeInfoSubscription = this.caseUIService.newModeInfo.subscribe((pCSI: CaseSaveInfo) => {
        this.caseCustomerRequestData[DsamsConstants.PROP_CASE_VERSION_STATUS] = pCSI.isNewMode?DsamsConstants.ENT_NEW:DsamsConstants.ENT_UNCHANGED;
        this._pnlExpansionProperties.caseRequestParams.caseId = pCSI.case_ID;
        this._pnlExpansionProperties.caseRequestParams.caseVersionId = pCSI.case_VERSION_ID;
        this._pnlExpansionProperties.isNewMode = pCSI.isNewMode;
        this._isGotInfoFromCIPanel = false;
        if (!this._alreadyToggledOn) {
          this._currentToggle = pCSI.isEditable;
          this.enableOrDisableEverything(this._currentToggle); 
        }        
      });
    }    
  }
}