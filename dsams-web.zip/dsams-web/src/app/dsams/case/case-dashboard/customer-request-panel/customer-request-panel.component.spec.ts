import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerRequestPanelComponent } from './customer-request-panel.component';

describe('CustomerRequestPanelComponent', () => {
  let component: CustomerRequestPanelComponent;
  let fixture: ComponentFixture<CustomerRequestPanelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CustomerRequestPanelComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerRequestPanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
