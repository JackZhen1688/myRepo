import { Component, EventEmitter, Inject, Output } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ReferenceDataType } from '../../model/reference-data-type';
import swal from 'sweetalert2';
import { CaseUIService } from '../../services/case-ui-service';

@Component({
    selector: 'app-case-country',
    templateUrl: './case-country.component.html',
    styleUrls: ['./case-country.component.css']
})

export class CaseCountryComponent {
    nameFormControl: FormControl = new FormControl();
    countryCodesData: Array<ReferenceDataType> = [];
    selected: string;
    //@Output() newCountry: EventEmitter<string> = new EventEmitter();
    countryList: Array<ReferenceDataType> = [];
    countryListSorted: Array<ReferenceDataType> = [];

    constructor(public dialogRef: MatDialogRef<CaseCountryComponent>,
                @Inject(MAT_DIALOG_DATA) public data: { countryCodes: Array<ReferenceDataType>,
                                                        countryCode: string },
                private caseUIService: CaseUIService) { }

    ngOnInit() {

        //Take out null elements from the array.
        for (let i = 0; i < this.data.countryCodes.length; i++) {
            if (this.data.countryCodes[i].field_2 == "") {
                this.data.countryCodes.splice(0, 1);
            }
        };

        this.countryList = this.data.countryCodes;
        this.countryList.sort((a, b) => a.field_2.localeCompare(b.field_2));

        //Select the first element in the array, as selected
        this.selected = this.countryList[0].field_2;
    }

    onNoclick(): void {
        this.dialogRef.close();
    }

    XcloseDialog(): void {
        this.dialogRef.close();
    }

    completeDialog(): void {
        this.dialogRef.close();
    }

    cancelDialog(): void {
        this.dialogRef.close();
    }

    saveDialog(): void {
        if (this.selected.substr(0,2) == this.data.countryCode){
            this.showExistsDialog();
        } else {
        this.savedDialog();
        this.dialogRef.close();
        }
    }

    showExistsDialog() {
        swal.fire({
            title: this.selected + " The country code entered combined with the IA and case designator already" +
            " exist on the database.  The country code change was not accomplished.",
            icon: 'warning',
            showCancelButton: false,
            cancelButtonText: 'No',
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'OK'
        });
    }

    savedDialog() {
        swal.fire({
            title: this.selected + " Country is Valid, Click SAVE Button to Finish",
            icon: 'success',
            showCancelButton: false,
            cancelButtonText: 'No',
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'OK'
        });
        this.caseUIService.countryChange.next(this.selected.substr(0,2));
    }
}