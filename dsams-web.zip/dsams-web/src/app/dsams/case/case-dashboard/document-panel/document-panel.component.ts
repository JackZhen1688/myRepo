/* 
  Author: David Huynh 
  Date:   01/28/2020 
*/
import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { Subscription } from 'rxjs';
import { CaseRestfulService } from '../../services/case-restful.service';
import { CaseUIService } from '../../services/case-ui-service';
import { DsamsConstants } from 'src/app/dsams/dsams.constants';
import { CaseUtils } from '../../utils/case-utils';
import { ReferenceDataType } from '../../model/reference-data-type';
import { PanelExpansionProperties } from '../../model/panel-expansion-properties';
import { MdePopoverTrigger } from '@material-extended/mde';
import { DateAdapter, MAT_DATE_FORMATS } from '@angular/material';
import { AppDateAdapter, APP_DATE_FORMATS } from '../../utils/app-date-adapter';
import { SaveResultsType } from '../../validation/save-results-type';
import { FieldDisabledMap } from '../../model/field-disabled-map';
import { CaseDocumentRequirementsValidator } from '../../validation/case-document-requirements-validator';
import { ICaseMaster } from '../../model/dto/icase-master';
import { ICaseVersion } from '../../model/dto/icase-version';
import { ICaseVersionNotification } from '../../model/dto/case-version-notification';
import { IEditResponseType } from '../../model/edit-response-type';
import { MessageMgr } from '../../validation/message-mgr';
import { CaseCommonValidator } from '../../validation/case-common-validator';
import { CaseSaveInfo } from '../../model/case-save-info';


declare function focusItem(pItem: string): any;

@Component({
  selector: 'app-document-panel',
  templateUrl: './document-panel.component.html',
  styleUrls: ['./document-panel.component.css',
    '../case-dashboard.component.css',
    '../common-CSS.component.css'],
  providers: [
    { provide: DateAdapter, useClass: AppDateAdapter },
    { provide: MAT_DATE_FORMATS, useValue: APP_DATE_FORMATS }
  ]
})
export class DocumentPanelComponent implements OnInit, OnDestroy {
  public caseDocumentRequirementsData: any = {};
  private _caseUIServiceSubscription: Subscription;
  private _reloadReferenceData: boolean = true;
  private _pnlExpansionProperties: PanelExpansionProperties;
  private _saveSubscription: Subscription = null;
  private fieldDisabledMap: FieldDisabledMap = {};
  private _dataSubscription: Subscription;
  private _editSubscription: Subscription = null;
  private _milestoneAddubscription: Subscription = null;
  private _saveCompleteSubscription: Subscription = null;
  private _newModeInfoSubscription: Subscription = null;
  private _panelCollapedSubscription: Subscription = null;
  private _casePanelStatusQuerySubscription: Subscription = null;
  private _isGotInfoFromCIPanel: boolean = false;
  private _currentToggle: boolean = false;
  private _alreadyToggledOn: boolean = false;
  private _skipSavePanel: boolean = false;
  caseVersionData: ICaseVersion;

  dataSourceConTransmittal = new MatTableDataSource();
  aConTransmittalArray = [];
  aCongressionalObject = { TransmittalNumber: "AUTH " };
  columnsToDisplayConTransmittal = ['TransmittalNumber', 'DeleteRow'];
  aCongressRowIndex: number = 0;
  refAprropFundsTypeList: Array<ReferenceDataType> = [];

  @ViewChild(MdePopoverTrigger, { static: true }) trigger: MdePopoverTrigger;

  constructor(private caseRestService: CaseRestfulService,
    private caseUIService: CaseUIService) { }

  ngOnInit() {

    // Only fetch data when the panel is opened.
    this._caseUIServiceSubscription = this.caseUIService.panelExpanded.subscribe(
      {
        next: (pnlExpansionProperties: PanelExpansionProperties) => {
          if (pnlExpansionProperties.panelName === DsamsConstants.CASE_PANEL_DOCUMENT_REQUIREMENTS ||
            pnlExpansionProperties.panelName === DsamsConstants.CASE_PANEL_ALL) {
            this._pnlExpansionProperties = pnlExpansionProperties;
            this.fetchReferenceData();
            this.subscribeToDataService();
            this.subscribeToValidateOrSaveRequest();
            // Subscribe to edit
            this.subscribeToEdit();
            // Subscribe to case ui service for optionSelectedUCDU Option for DSCA Update
            this.subscribeToUCDUOption();
            this.subscribeToUCAIOption();
            if (this._pnlExpansionProperties.isNewMode) {
              this._currentToggle = true;
              this.enableOrDisableEverything(this._currentToggle);
            }
            this.subscribeToSaveComplete();
            this.subscribeToNewModeInfo();
            this.subscribeToPanelCollapsed();
            this.subscribeToCasePanelStatusQuery();
            this._skipSavePanel = false;
          }
        }
      });
  }

  // Make sure panel expansion subscription is cleaned up.
  ngOnDestroy() {
    this._caseUIServiceSubscription.unsubscribe();
    if (this._saveSubscription != null) {
      this._saveSubscription.unsubscribe();
      this._saveSubscription = null;
    }
    if (this._dataSubscription) {
      this._dataSubscription.unsubscribe();
      this._dataSubscription = null;
    }
    if (!!this._editSubscription) {
      this._editSubscription.unsubscribe();
      this._editSubscription = null;
    }
    if (!!this._milestoneAddubscription) {
      this._milestoneAddubscription.unsubscribe();
      this._milestoneAddubscription = null
    }
    if (!!this._saveCompleteSubscription) {
      this._saveCompleteSubscription.unsubscribe();
      this._saveCompleteSubscription = null;
    }
    if (!!this._newModeInfoSubscription) {
      this._newModeInfoSubscription.unsubscribe();
      this._newModeInfoSubscription = null;
    }
    if (!!this._panelCollapedSubscription) {
      this._panelCollapedSubscription.unsubscribe();
      this._panelCollapedSubscription = null;
    }    
    if (!!this._casePanelStatusQuerySubscription) {
      this._casePanelStatusQuerySubscription.unsubscribe();
      this._casePanelStatusQuerySubscription = null;
    }    
  }

  // Subscribe to panel collapsing
  subscribeToPanelCollapsed() {
    if (!this._panelCollapedSubscription) {
      this._panelCollapedSubscription = this.caseUIService.panelCollapsed.subscribe((panelName: string) => {
        if (panelName === DsamsConstants.CASE_PANEL_DOCUMENT_REQUIREMENTS || panelName === DsamsConstants.CASE_PANEL_ALL) 
        {
           this._skipSavePanel = true;
        }
      });
    }
  }


  subscribeToCasePanelStatusQuery() {
    if (!this._casePanelStatusQuerySubscription) {
      this._casePanelStatusQuerySubscription = this.caseUIService.getPanelCaseVersionStatusQuerySubscription().subscribe(() => {
        this.caseUIService.panelCaseVersionStatusResponseSubscriptionNext(DsamsConstants.CASE_PANEL_DOCUMENT_REQUIREMENTS,
                                                                          this.caseDocumentRequirementsData[DsamsConstants.PROP_CASE_VERSION_STATUS],
                                                                          this._pnlExpansionProperties.caseRequestParams.caseId,
                                                                          this._pnlExpansionProperties.caseRequestParams.caseVersionId);
      });
    }
  }    


  fieldDisabled(pFieldName: string): boolean {
    // Special Case for DSCA Update (DSAMS-1587)
    if (pFieldName === "state_DEPARTMENT_APPROVAL_IN" &&
      !(this.fieldDisabledMap["state_DEPARTMENT_APPROVAL_IN"]) &&
      this.caseUIService.optionSelectedUCDU.getValue()) {
      // Do nothing
    }
    else if (pFieldName === "congress_TRANSMIT_ID" &&
      !(this.fieldDisabledMap["congress_TRANSMIT_ID"]) &&
      this.caseUIService.optionSelectedUCDU.getValue()) {
      // Do nothing
    }
    else if (pFieldName === "pcs_PERSONNEL_IN" &&
      !(this.fieldDisabledMap["pcs_PERSONNEL_IN"]) &&
      this.caseUIService.optionSelectedUCDU.getValue()) {
      // Do nothing
    }
    else if (pFieldName === "urgent_REQUEST_IN" &&
      !(this.fieldDisabledMap["urgent_REQUEST_IN"]) &&
      this.caseUIService.optionSelectedUCDU.getValue()) {
      // Do nothing
    }
    else if (pFieldName === "dsa_APPROVAL_IN" &&
      !(this.fieldDisabledMap["dsa_APPROVAL_IN"]) &&
      this.caseUIService.optionSelectedUCDU.getValue()) {
      // Do nothing
    }
    else if (pFieldName === "requisition_FORECAST_IN" &&
    !(this.fieldDisabledMap["requisition_FORECAST_IN"]) &&
    this.caseUIService.optionSelectedUCAI.getValue()) {
    // Do nothing
  }
    else {
      return CaseUtils.isFieldDisabled(this.fieldDisabledMap, DsamsConstants.CASE_PANEL_DOCUMENT_REQUIREMENTS, pFieldName);
    }
  }

  isBenefittingCountry(): boolean {
    return (this.caseVersionData != null && this.caseVersionData.theCaseId.theCustomerOrganizationId.customer_TYPE_CD == 'BE');
  }

  // Make sure the array is populated.
  isCongressionalNotificationListPopulated(): boolean {
    return !!(this.caseDocumentRequirementsData["congressionalNotificationList"]) || this._pnlExpansionProperties.isNewMode;
  }

  // *************  Congressional Transmittal table
  initializeConTransmittalArray() {
    let currCongressionalNotificationList: Array<ICaseVersionNotification> = <Array<ICaseVersionNotification>>(this.caseDocumentRequirementsData["congressionalNotificationList"]);
    let currCongressionalNotificationItem: any;
    this.caseDocumentRequirementsData["congressionalNotificationDeletedList"] = [];
    this.aCongressRowIndex = !currCongressionalNotificationList ? 0 : currCongressionalNotificationList.length;
    for (let i = 0; i < this.aCongressRowIndex; i++) {
      currCongressionalNotificationItem = currCongressionalNotificationList[i];
      currCongressionalNotificationItem = Object.assign({ rowNum: (i + 1), errorMsg: "" }, currCongressionalNotificationItem);
      currCongressionalNotificationItem["customer_CN_ID"] = currCongressionalNotificationList[i].customer_CN_ID;
      currCongressionalNotificationItem["old_CUSTOMER_CN_ID"] = currCongressionalNotificationList[i].customer_CN_ID;
      currCongressionalNotificationItem["cong_NOTIFICATION_NUMBER_CD"] = currCongressionalNotificationList[i].theCustomerCnId.cong_NOTIFICATION_NUMBER_CD;
      currCongressionalNotificationItem["status"] = DsamsConstants.ENT_UNCHANGED;
      currCongressionalNotificationList[i] = currCongressionalNotificationItem;
    }
    this.dataSourceConTransmittal = new MatTableDataSource(currCongressionalNotificationList);
  }

  addNewConTransmittalItem() {
    this.aCongressRowIndex = this.aCongressRowIndex + 1;

    if (!(this.caseDocumentRequirementsData["congressionalNotificationList"])) {
      this.caseDocumentRequirementsData["congressionalNotificationList"] = [];
    }

    (<Array<any>>this.caseDocumentRequirementsData["congressionalNotificationList"]).push(
      {
        rowNum: this.aCongressRowIndex,
        status: DsamsConstants.ENT_NEW,
        errorMsg: "",
        customer_CN_ID: 0,
        cong_NOTIFICATION_NUMBER_CD: ""
      }
    );
    this.dataSourceConTransmittal = new MatTableDataSource(this.caseDocumentRequirementsData["congressionalNotificationList"]);
    this.dataSourceConTransmittal._updateChangeSubscription();
    focusItem("CN" + +this.aCongressRowIndex);
    this.setChangedCV();
  }

  /* This procedure checks the returned result value from the 
      popover Yes/No dialog window. */
  yesButtonOnClick(isDeleteConfirmed: any, rowElement: any) {
    if (isDeleteConfirmed)
      this.delConTransmittalItem(rowElement);
  }

  delConTransmittalItem(rowElement: any) {
    // Do not allow the delete if it's the last row and we have a CSTANOT milestone.
    if ((<Array<any>>this.caseDocumentRequirementsData["congressionalNotificationList"]).length == 1 &&
        this.caseDocumentRequirementsData["has_CSTANOT_MILESTONE"] &&
        this.caseDocumentRequirementsData["orig_NUM_CVN"] > 0)
    {
       MessageMgr.displaySinglePopupError("E064");
       return;
    }

    if (!(this.caseDocumentRequirementsData["congressionalNotificationDeletedList"])) {
      this.caseDocumentRequirementsData["congressionalNotificationDeletedList"] = [];
    }
    (<Array<any>>this.caseDocumentRequirementsData["congressionalNotificationDeletedList"]).push(rowElement);
    (<Array<any>>this.caseDocumentRequirementsData["congressionalNotificationList"]).splice(this.dataSourceConTransmittal.data.indexOf(rowElement), 1);    
    this.dataSourceConTransmittal = new MatTableDataSource(this.caseDocumentRequirementsData["congressionalNotificationList"]);
    this.setChangedCV();
    this.determineIfUserCanSave(true);
    if (this.caseDocumentRequirementsData["congressionalNotificationList"].length === 0) {
      this.updateCNList();
    }
  }


  getCaseDocumentRequirementsData(): any {
    return this.caseDocumentRequirementsData;
  }


  // Subscribe to edit toggle event
  subscribeToEdit() {
    if (!this._editSubscription) {
      this._editSubscription = this.caseUIService
        .caseEditService
        .subscribe((pResponse: IEditResponseType) => {
          if (pResponse && (pResponse.ID === DsamsConstants.CASE_VERSION_EDITOR || pResponse.ID === DsamsConstants.PAGE_CASE_DETAIL)) {
            this.enableOrDisableEverything(pResponse.editToggle);
            this._currentToggle = pResponse.editToggle;
            if (this._currentToggle) {
              this._alreadyToggledOn = true;
            }
          }
        },
          err => {
            CaseUtils.ReporError("Error in customer-request responding to edit toggle");
          }
        );
    }

    // Subscribe to milestone service. 
    // Id Update Case in Review, disable the CN fields.
    if (!this._milestoneAddubscription) {
      this._milestoneAddubscription = this.caseUIService
        .milestoneAddService
        .subscribe((milestoneId: string) => {
          if (!!milestoneId) {
            const isCWDREDIT: boolean = (milestoneId === "CWDREDIT");
            this.fieldDisabledMap["congressional_NOTIFICATION_IN"] = isCWDREDIT;
          }
        });
    }
  }


  // Enable or Disable everything on the panel.
  enableOrDisableEverything(pEnable: boolean) {
    let l_isEnabled: boolean = this._pnlExpansionProperties.isNewMode ? true : pEnable;
    this.fieldDisabledMap[DsamsConstants.CASE_PANEL_DOCUMENT_REQUIREMENTS] = !l_isEnabled;
    if (l_isEnabled) {
      this.initializePanelFields();
    }
  }

  // Flag the field as changed so we can update the record upon save.
  setChangedCV() {
    this.caseDocumentRequirementsData[DsamsConstants.PROP_CASE_VERSION_STATUS] = this._pnlExpansionProperties.isNewMode ? DsamsConstants.ENT_NEW : DsamsConstants.ENT_CHANGED;
    if (this.caseDocumentRequirementsData[DsamsConstants.PROP_CASE_VERSION_STATUS] == DsamsConstants.ENT_UNCHANGED) {
      this.caseUIService.theComponentSaveState[CaseUIService.SAVE_CASE_DETAILS_STATE].isDataChanged = false;
    }
    else
      this.caseUIService.theComponentSaveState[CaseUIService.SAVE_CASE_DETAILS_STATE].isDataChanged = true;     
  }

  setChangedCM() {
    this.caseDocumentRequirementsData[DsamsConstants.PROP_CASE_MASTER_STATUS] = this._pnlExpansionProperties.isNewMode ? DsamsConstants.ENT_NEW : DsamsConstants.ENT_CHANGED;
    if (this.caseDocumentRequirementsData[DsamsConstants.PROP_CASE_VERSION_STATUS] == DsamsConstants.ENT_UNCHANGED) {
      this.caseUIService.theComponentSaveState[CaseUIService.SAVE_CASE_DETAILS_STATE].isDataChanged = false;
    }
    else
      this.caseUIService.theComponentSaveState[CaseUIService.SAVE_CASE_DETAILS_STATE].isDataChanged = true;        
  }

  // Flag the field as changed for CVN.
  setChangedCVN(pElement: any) {
    if (pElement.status == DsamsConstants.ENT_UNCHANGED) {
      pElement.status = DsamsConstants.ENT_CHANGED;
    }
    this.setChangedCV();
  }

  // Determine if the CN has an error
  hasCNError(pElement: any): boolean {
    return pElement.errorMsg !== DsamsConstants.NO_ERROR;
  }


  getFieldStyleProperty(pElement: any, isAppearanceNotStyle: boolean): string | object {
    const ERROR_APPEARANCE: string = DsamsConstants.ERROR_APPEARANCE;
    const REGULAR_APPEARANCE: string = DsamsConstants.REGULAR_APPEARANCE;
    const ERROR_STYLE_1 = { "border": "1px solid red", "height": "30px", "border-radius": "4px", "margin-top": "-20px", "margin-bottom": "-7px" };
    let isError: boolean = pElement.errorMsg !== DsamsConstants.NO_ERROR;
    let styleStr: object = ERROR_STYLE_1;
    if (isAppearanceNotStyle) {
      return isError ? ERROR_APPEARANCE : REGULAR_APPEARANCE;
    }
    else {
      return isError ? styleStr : {};
    }
  }


  determineIfUserCanSave(pRevalidate: boolean) {
    // Determine if the user can save based on CN.
    const fullCNList: any = this.caseDocumentRequirementsData["congressionalNotificationList"];

    // Do a quickie re-validating that doesn't go against the datbase.
    if (pRevalidate) {
      for (let cnItem of fullCNList) {
        this.validateCN(cnItem, cnItem.rowNum);
      }
    }

    const areThereErrors: boolean = (!!fullCNList) &&
      (fullCNList.filter(cnItem => cnItem.errorMsg !== "").length > 0);
    this.caseUIService.canSave.next(!areThereErrors);
  }
  

  // Update CN List to show comma separated list of values.
  private updateCNList() {
    let cnStr:string = "";
    let rowNum:number = 0;
    if (!!this.caseDocumentRequirementsData["congressionalNotificationList"]) {
      this.caseDocumentRequirementsData["congressionalNotificationList"].forEach(eachCN => {
      if (eachCN.errorMsg.length === 0) {
        if (++rowNum > 1) {
          cnStr = cnStr + ", ";
        }        
        cnStr = cnStr + eachCN.cong_NOTIFICATION_NUMBER_CD.substring(0, 2) + "-" + eachCN.cong_NOTIFICATION_NUMBER_CD.substring(2, 4);
        }
      });
    }
    this.caseDocumentRequirementsData['congress_TRANSMIT_ID'] = cnStr;
  }


  // Date validator for effective date.  
  validateCN(pElement: any, pRowNum: number) {
    const cnElem = <HTMLInputElement>document.getElementById('CN' + +pRowNum);
    if (!cnElem) {
      return DsamsConstants.NO_ERROR;
    }
    const cnElemStr: string = cnElem.value;
    // Call the database to find out if the CN is valid.
    pElement.errorMsg = DsamsConstants.NO_ERROR;
    this.caseUIService.canSave.next(false);    
    if (cnElemStr === "") {
      pElement.errorMsg = "Field is required.";
    }
    else if (cnElemStr.length < 5) {
      pElement.errorMsg = "Field must four characters long.";
    }
    else {
      // Check if it's a duplicate.
      let cnList: any = this.caseDocumentRequirementsData['congressionalNotificationList'].slice();
      CaseCommonValidator.addUniqueId(cnList);
      let hasDup: boolean = false;
      for (let cnItem of cnList) {
        for (let cnItem2 of cnList) {
          if (cnItem[DsamsConstants.UNIQUE_ID_FIELD] !== cnItem2[DsamsConstants.UNIQUE_ID_FIELD] &&
            CaseCommonValidator.isEqual(cnItem["cong_NOTIFICATION_NUMBER_CD"], cnItem2["cong_NOTIFICATION_NUMBER_CD"])) {
            hasDup = true;
          }
        }
      }
      if (hasDup) {
        pElement.errorMsg = "CN ID is a duplicate.";
      }
    }
    if (pElement.errorMsg !== DsamsConstants.NO_ERROR) {
      this.updateCNList();
      return;
    }
    // CN has passed so far. Now let's call the database to check validity.
    this.caseRestService
      .checkCongNotifCd(this._pnlExpansionProperties.caseRequestParams.customerOrganizationId,
        this._pnlExpansionProperties.caseRequestParams.caseId,
        this._pnlExpansionProperties.caseRequestParams.caseVersionId,
        cnElemStr)
      .subscribe(errorMsgArr => {
        if (!!errorMsgArr) {
          if (errorMsgArr.messages.length > 0 && errorMsgArr.messages[0] !== "") {
            pElement.errorMsg = MessageMgr.getMesssage(errorMsgArr.messages[0]).messageText;
          }
          else {
            pElement["customer_CN_ID"] = errorMsgArr.keyValue;
            pElement.errorMsg = DsamsConstants.NO_ERROR;
          }
        }
        this.determineIfUserCanSave(false);
        this.updateCNList();
      },
        err => {
          CaseUtils.ReportHTTPError(err, "Unable to check Congressional Transmittal Number.");
          pElement.errorMsg = DsamsConstants.NO_ERROR;
          this.determineIfUserCanSave(false);
        }
      );
  }


  // Set the enabledness of the field on this panel according to business rules.
  initializePanelFields() {
    const brMap: any = this.caseVersionData["businessRuleMap"];
    this.fieldDisabledMap["congressional_NOTIFICATION_IN"] = (<boolean>CaseUtils.getBusinessRuleMapValue(brMap, "CONGRESSIONAL_NOTIFICATION_DISABLED", false));
    this.fieldDisabledMap["acas_ELIGIBLE_IN"] = (<boolean>CaseUtils.getBusinessRuleMapValue(brMap, "ACAS_ELIGIBLE_DISABLED", false));
    this.fieldDisabledMap["dsa_APPROVAL_IN"] = (<boolean>CaseUtils.getBusinessRuleMapValue(brMap, "DSA_APPROVAL_DISABLED", false));
    this.fieldDisabledMap["requisition_FORECAST_IN"] = (<boolean>CaseUtils.getBusinessRuleMapValue(brMap, "REQUISITION_FORECAST_DISABLED", false));
    const isFundCdAreaDisabled: boolean = (<boolean>CaseUtils.getBusinessRuleMapValue(brMap, "APPROPRIATED_FUNDS_DISABLED", false));
    this.fieldDisabledMap["appropriated_FUNDS_CD"] = isFundCdAreaDisabled;
    this.fieldDisabledMap["special_PGM_FUNDING_IN"] = isFundCdAreaDisabled;
    this.caseDocumentRequirementsData["mtds_PRICED"] = (<boolean>CaseUtils.getBusinessRuleMapValue(brMap, "MTDS_PRICED", false));
    this.caseDocumentRequirementsData["has_CSTANOT_MILESTONE"] = (<boolean>CaseUtils.getBusinessRuleMapValue(brMap, "HAS_CSTANOT_MILESTONE", false));
    this.caseDocumentRequirementsData["orig_NUM_CVN"] = !this.caseVersionData.caseVersionNotificationList?0:this.caseVersionData.caseVersionNotificationList.length;
    // this.fieldDisabledMap["appr_FUNDS_EFFECTIVE_DT"] = isFundCdAreaDisabled;
    // this.fieldDisabledMap["appr_FUNDS_EXPIRED_DT"] = isFundCdAreaDisabled;
    // this.fieldDisabledMap["appr_FUNDS_CLOSED_DT"] = isFundCdAreaDisabled;
    // // The date fields below are always disabled.
    this.fieldDisabledMap["appr_FUNDS_EFFECTIVE_DT"] = true;
    this.fieldDisabledMap["appr_FUNDS_EXPIRED_DT"] = true;
    this.fieldDisabledMap["appr_FUNDS_CLOSED_DT"] = true;
    // Legal Required is also disabled, only updated when change of status is done on milestone window.
    this.fieldDisabledMap["legal_APPROVAL_REQUIRED_IN"] = true;
  }


  fetchReferenceData() {
    if (this._reloadReferenceData) {
      // *** Reference: Appr Funds Type ***
      this.caseRestService
        .getReferenceData(DsamsConstants.REF_APPROPRIATED_FUNDS_TYPE, "", 0, true)
        .subscribe(
          data => {
            this.refAprropFundsTypeList = data;
          },
          err => {
            CaseUtils.ReportHTTPError(err, "Error fetching reference for " + DsamsConstants.REF_APPROPRIATED_FUNDS_TYPE);
          }
        );
      this._reloadReferenceData = false;
    }
  }


  // Add the subscription for this panel for getting the data from the dashboard.
  subscribeToDataService() {
    if (!this._dataSubscription) {
      this._dataSubscription = this.caseUIService.caseDetailData.subscribe(
        {
          next: (caseDetailData: ICaseVersion) => {
            if (caseDetailData) {
              this.caseVersionData = caseDetailData;
              CaseUtils.populateCaseRequestParamsType(this._pnlExpansionProperties.caseRequestParams, this.caseVersionData);              
              this.caseDocumentRequirementsData['congressional_NOTIFICATION_IN'] = this.caseVersionData.congressional_NOTIFICATION_IN;
              this.caseDocumentRequirementsData['state_DEPARTMENT_APPROVAL_IN'] = this.caseVersionData.state_DEPARTMENT_APPROVAL_IN;
              this.caseDocumentRequirementsData['manpower_TRAVEL_DATA_CD'] = this.caseVersionData.manpower_TRAVEL_DATA_CD;
              this.caseDocumentRequirementsData['congress_TRANSMIT_ID'] = this.caseVersionData.congress_TRANSMIT_ID;
              this.caseDocumentRequirementsData['congressionalNotificationList'] = this.caseVersionData.caseVersionNotificationList;
              this.caseDocumentRequirementsData['pcs_PERSONNEL_IN'] = this.caseVersionData.pcs_PERSONNEL_IN;
              this.caseDocumentRequirementsData['acas_ELIGIBLE_IN'] = this.caseVersionData.acas_ELIGIBLE_IN;
              this.caseDocumentRequirementsData['urgent_REQUEST_IN'] = this.caseVersionData.urgent_REQUEST_IN;
              this.caseDocumentRequirementsData['legal_APPROVAL_REQUIRED_IN'] = this.caseVersionData.legal_APPROVAL_REQUIRED_IN;
              this.caseDocumentRequirementsData['dsa_APPROVAL_IN'] = this.caseVersionData.dsa_APPROVAL_IN;
              this.caseDocumentRequirementsData['requisition_FORECAST_IN'] = this.caseVersionData.requisition_FORECAST_IN;
              this.caseDocumentRequirementsData['appropriated_FUNDS_CD'] = CaseUtils.nullFix(this.caseVersionData.theCaseId.appropriated_FUNDS_CD);
              this.caseDocumentRequirementsData['special_PGM_FUNDING_IN'] = this.caseVersionData.theCaseId.special_PGM_FUNDING_IN;
              this.caseDocumentRequirementsData['appr_FUNDS_EFFECTIVE_DT'] = CaseUtils.numberToDate(this.caseVersionData.theCaseId.appr_FUNDS_EFFECTIVE_DT);
              this.caseDocumentRequirementsData['appr_FUNDS_EXPIRED_DT'] = CaseUtils.numberToDate(this.caseVersionData.theCaseId.appr_FUNDS_EXPIRED_DT);
              this.caseDocumentRequirementsData['appr_FUNDS_CLOSED_DT'] = CaseUtils.numberToDate(this.caseVersionData.theCaseId.appr_FUNDS_CLOSED_DT);
              this._pnlExpansionProperties.caseRequestParams.caseId = this.caseVersionData.case_ID;
              const defaultStatus: number = this._pnlExpansionProperties.isNewMode ? DsamsConstants.ENT_NEW : DsamsConstants.ENT_UNCHANGED;
              this.caseDocumentRequirementsData[DsamsConstants.PROP_CASE_MASTER_STATUS] = defaultStatus;
              this.caseDocumentRequirementsData[DsamsConstants.PROP_CASE_VERSION_STATUS] = defaultStatus;
              this.enableOrDisableEverything(this._currentToggle);
              this.initializeConTransmittalArray();
              this._isGotInfoFromCIPanel = false;
            }
          }
        }
      );
    }
  }

  subscribeToUCAIOption() {
    this.caseUIService.optionSelectedUCAI.subscribe((value) => {
      if(value) {
        this.fieldDisabledMap['requisition_FORECAST_IN'] = false;
      }
    });
  }

  // Subscribe to case ui service for optionSelectedUCDU Option for DSCA Update
  subscribeToUCDUOption() {
    this.caseUIService.optionSelectedUCDU.subscribe((value) => {
      // Set select checkboxes to enabled
      if (value) {
        this.fieldDisabledMap["state_DEPARTMENT_APPROVAL_IN"] = false;
        this.fieldDisabledMap["congress_TRANSMIT_ID"] = false;
        this.fieldDisabledMap["pcs_PERSONNEL_IN"] = false;
        this.fieldDisabledMap["urgent_REQUEST_IN"] = false;
        this.fieldDisabledMap["dsa_APPROVAL_IN"] = false;
      }
    });
  }

  // ************************** Validate/Save *****************************

  // Subcsribe to validate or save request.
  subscribeToValidateOrSaveRequest() {
    if (this._saveSubscription == null) {
      this._saveSubscription = this.caseUIService.saveRequest.subscribe((pSkipValidation: boolean) => {
        if (!this._skipSavePanel) {
          let svResults: SaveResultsType = this.savePanel(pSkipValidation);
          this.caseUIService.saveReturnRequest.next(svResults);
        }
      });
    }
  }

  // Do a validate/save request to the middle tier.
  savePanel(pSkipValidation: boolean): SaveResultsType {
    let valResults: SaveResultsType = new SaveResultsType();
    valResults.currentPanel = DsamsConstants.CASE_PANEL_DOCUMENT_REQUIREMENTS;
    if (!!pSkipValidation) {
      valResults = CaseDocumentRequirementsValidator.validateDocumentRequirementsPanel
        (this.caseDocumentRequirementsData,
          this._pnlExpansionProperties,
          []);
    }

    let svResults: SaveResultsType = new SaveResultsType();
    svResults.currentPanel = valResults.currentPanel;
    svResults.messageList = valResults.messageList;

    // Put the contents into a ICaseVersion that can be combined into a main ICaseVersion and sent to the back-end.
    if (svResults.isValidationSuccessful()) {
      let cvEntity: ICaseVersion = { status: this.caseDocumentRequirementsData[DsamsConstants.PROP_CASE_VERSION_STATUS] };
      let cmEntity: ICaseMaster = { status: this.caseDocumentRequirementsData[DsamsConstants.PROP_CASE_MASTER_STATUS] };
      const currCaseId: number = this._pnlExpansionProperties.caseRequestParams.caseId;
      const currCaseVersionId: number = this._pnlExpansionProperties.caseRequestParams.caseVersionId;
      cvEntity.congressional_NOTIFICATION_IN = this.caseDocumentRequirementsData['congressional_NOTIFICATION_IN'];
      cvEntity.state_DEPARTMENT_APPROVAL_IN = this.caseDocumentRequirementsData['state_DEPARTMENT_APPROVAL_IN'];
      cvEntity.manpower_TRAVEL_DATA_CD = this.caseDocumentRequirementsData['manpower_TRAVEL_DATA_CD'];
      // cvEntity.sbl_IN = this.caseDocumentRequirementsData['sbl_IN'];
      cvEntity.pcs_PERSONNEL_IN = this.caseDocumentRequirementsData['pcs_PERSONNEL_IN'];
      cvEntity.acas_ELIGIBLE_IN = this.caseDocumentRequirementsData['acas_ELIGIBLE_IN'];
      cvEntity.urgent_REQUEST_IN = this.caseDocumentRequirementsData['urgent_REQUEST_IN'];
      cvEntity.legal_APPROVAL_REQUIRED_IN = this.caseDocumentRequirementsData['legal_APPROVAL_REQUIRED_IN'];
      cvEntity.dsa_APPROVAL_IN = this.caseDocumentRequirementsData['dsa_APPROVAL_IN'];
      cvEntity.requisition_FORECAST_IN = this.caseDocumentRequirementsData['requisition_FORECAST_IN'];
      cvEntity.congress_TRANSMIT_ID = this.caseDocumentRequirementsData['congress_TRANSMIT_ID'];
      // Case Master fields
      cmEntity.appropriated_FUNDS_CD = this.caseDocumentRequirementsData['appropriated_FUNDS_CD'];
      cmEntity.special_PGM_FUNDING_IN = this.caseDocumentRequirementsData['special_PGM_FUNDING_IN'];
      cmEntity.appr_FUNDS_EFFECTIVE_DT = this.caseDocumentRequirementsData['appr_FUNDS_EFFECTIVE_DT'];
      cmEntity.appr_FUNDS_EXPIRED_DT = this.caseDocumentRequirementsData['appr_FUNDS_EXPIRED_DT'];
      cmEntity.appr_FUNDS_CLOSED_DT = this.caseDocumentRequirementsData['appr_FUNDS_CLOSED_DT'];
      // Assign case_master to case_version.
      cvEntity.theCaseId = cmEntity;
      //
      // Case Version Notification List (current items)
      // 
      let cvnArray: Array<ICaseVersionNotification> = [];
      let cvnFormArray: any = this.caseDocumentRequirementsData["congressionalNotificationList"];
      if (!!cvnFormArray) {
        for (let i = 0; i < cvnFormArray.length; i++) {
          // Delete and then re-add Case Versions
          let cvnEntity: ICaseVersionNotification = null;
          let currStatus:number = cvnFormArray[i]["status"];
          if (currStatus == DsamsConstants.ENT_CHANGED) {
            cvnEntity = {
              entityName: "CASE_VERSION_NOTIFICATION",
              status: DsamsConstants.ENT_DELETED,
              case_ID: currCaseId,
              case_VERSION_ID: currCaseVersionId,
              customer_CN_ID: cvnFormArray[i]["old_CUSTOMER_CN_ID"]
            };
            cvnArray.push(cvnEntity);
          }

          cvnEntity =
          {
            entityName: "CASE_VERSION_NOTIFICATION",
            status: (currStatus == DsamsConstants.ENT_CHANGED || currStatus == DsamsConstants.ENT_NEW)?DsamsConstants.ENT_NEW:DsamsConstants.ENT_UNCHANGED,
            case_ID: currCaseId,
            case_VERSION_ID: currCaseVersionId,
            customer_CN_ID: cvnFormArray[i]["customer_CN_ID"],
            theCustomerCnId: {
                                entityName: "CUSTOMER_CN",
                                status: DsamsConstants.ENT_UNCHANGED,
                                customer_CN_ID: cvnFormArray[i]["customer_CN_ID"],  
                                cong_NOTIFICATION_NUMBER_CD: cvnFormArray[i]["cong_NOTIFICATION_NUMBER_CD"],
                                cong_nOTIFICATION_END_DT: null,
                                cong_NOTIFICATION_START_DT: null,
                                cong_NOTIFICATION_COMMENT_TX: "",
                                cong_NOTIFICATION_DESC_TX: "",
                                cong_NOTIFICATION_TYPE_CD: "",
                                customer_ORGANIZATION_ID: "",
                                implementing_AGENCY_ID: "",
                                implementing_AGENCY_NM: "",
                                inactive_IN: false,
                                parent_CN_ID: 0,
                                prenotification_IN: false 
                            }
          };
          cvnArray.push(cvnEntity);
        }
      }
      //
      // Case Version Notification List (deleted items)
      // 
      cvnFormArray = this.caseDocumentRequirementsData["congressionalNotificationDeletedList"];
      if (!!cvnFormArray) {
        for (let i = 0; i < cvnFormArray.length; i++) {
          let cvnEntity: ICaseVersionNotification =
          {
            entityName: "CASE_VERSION_NOTIFICATION",
            status: DsamsConstants.ENT_DELETED,
            case_ID: currCaseId,
            case_VERSION_ID: currCaseVersionId,
            customer_CN_ID: cvnFormArray[i]["customer_CN_ID"]
          };
          cvnArray.push(cvnEntity);
        }
      }
      cvEntity.caseVersionNotificationList = cvnArray;
      svResults.caseVersionPanelData = cvEntity;
      this._isGotInfoFromCIPanel = false;
    }
    return svResults;
  }

  // Reset everything when save is complete.
  subscribeToSaveComplete() {
    if (!this._saveCompleteSubscription) {
      this._saveCompleteSubscription = this.caseUIService.saveCaseVersionComplete.subscribe((pReturnCaseVersion: ICaseVersion) => {
        if (!!pReturnCaseVersion) {
          this.caseUIService.theComponentSaveState[CaseUIService.SAVE_CASE_DETAILS_STATE].isDataChanged = false;
          this.caseUIService.theComponentSaveState[CaseUIService.SAVE_CASE_DETAILS_STATE].isSaveConfirmed.next(false);      
          if (this._isGotInfoFromCIPanel) {
            this._isGotInfoFromCIPanel = false;
          }
          const unch: number = DsamsConstants.ENT_UNCHANGED;
          this.caseDocumentRequirementsData[DsamsConstants.PROP_CASE_VERSION_STATUS] = unch;
          this.caseDocumentRequirementsData[DsamsConstants.PROP_CASE_MASTER_STATUS] = unch;
          this.caseDocumentRequirementsData["congressionalNotificationDeletedList"] = [];
          this.caseDocumentRequirementsData["congressionalNotificationList"] = pReturnCaseVersion.caseVersionNotificationList.filter(elem => elem.status != DsamsConstants.ENT_DELETED);
          if (!!this.caseDocumentRequirementsData["congressionalNotificationList"]) {
            this.aCongressRowIndex = this.caseDocumentRequirementsData["congressionalNotificationList"].length;
            for (let i = 0; i < this.aCongressRowIndex; i++) {
              this.caseDocumentRequirementsData["congressionalNotificationList"][i] = Object.assign(this.caseDocumentRequirementsData["congressionalNotificationList"][i],
                {
                  rowNum: (i + 1),
                  status: unch,
                  errorMsg: DsamsConstants.NO_ERROR,
                  old_CUSTOMER_CN_ID: null,
                  customer_CN_ID: this.caseDocumentRequirementsData["congressionalNotificationList"][i]["customer_CN_ID"],
                  cong_NOTIFICATION_NUMBER_CD: this.caseDocumentRequirementsData["congressionalNotificationList"][i].theCustomerCnId.cong_NOTIFICATION_NUMBER_CD
                });
            }
          }
          else {
            this.aCongressRowIndex = 0;
          }
          this.caseDocumentRequirementsData["orig_NUM_CVN"] = !pReturnCaseVersion.caseVersionNotificationList?0:pReturnCaseVersion.caseVersionNotificationList.length;          
          this.dataSourceConTransmittal = new MatTableDataSource(this.caseDocumentRequirementsData["congressionalNotificationList"]);          
          this._pnlExpansionProperties.caseRequestParams.caseId = pReturnCaseVersion.case_ID;
          this._pnlExpansionProperties.caseRequestParams.caseVersionId = pReturnCaseVersion.case_VERSION_ID;
          this._pnlExpansionProperties.isNewMode = false;
          this.enableOrDisableEverything(this._currentToggle);
        }
      });
    }
  }

  // Subscribe to new mode info coming from CI panel.
  subscribeToNewModeInfo() {
    if (!this._newModeInfoSubscription) {
      this._newModeInfoSubscription = this.caseUIService.newModeInfo.subscribe((pCSI: CaseSaveInfo) => {
        this._pnlExpansionProperties.caseRequestParams.caseId = pCSI.case_ID;
        this._pnlExpansionProperties.caseRequestParams.caseVersionId = pCSI.case_VERSION_ID;
        this._pnlExpansionProperties.isNewMode = pCSI.isNewMode;
        if (!this._alreadyToggledOn) {
          this._currentToggle = pCSI.isEditable;
          this.enableOrDisableEverything(this._currentToggle);
        }
        this._isGotInfoFromCIPanel = false;
      });
    }
  }
}