/* 
  This Case Detail View is developed as a prototype Web page to 
  demonstrate the Angular form control/functional behaviors. 
  This web page contains a total of 8 expansion panels with 
  pre-populated data for demo purposes.

*/

import { Component, OnInit, ViewChild, Injectable, OnDestroy, Injector, ElementRef } from '@angular/core';
import { CaseRestfulService } from '../services/case-restful.service';
import { CaseUIService, CommonReferenceData } from '../services/case-ui-service';
import { DsamsConstants } from '../../dsams.constants';
import { CustomerRequestPanelComponent } from './customer-request-panel/customer-request-panel.component';
import { CaseInformationPanelComponent } from './case-information-panel/case-information-panel.component';
import { DescriptionsPanelComponent } from './descriptions-panel/descriptions-panel.component';
import { DocumentPanelComponent } from './document-panel/document-panel.component';
import { SignatoriesPanelComponent } from './signatories-panel/signatories-panel.component';
import { WaiversPanelComponent } from './waivers-panel/waivers-panel.component';
import { AssociationsPanelComponent } from './associations-panel/associations-panel.component';
import { ReferenceDataType } from '../model/reference-data-type';
import { CaseUtils } from '../utils/case-utils';
import { PanelExpansionProperties } from '../model/panel-expansion-properties';
import { DsamsMethodsService } from './../../../dsams/services/dsams-methods.service';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { CaseQueryParamsType } from '../model/search-params/case-query-params-type';
import { CaseRequestParamsType } from '../model/search-params/case-request-params-type';
import { Subscription, BehaviorSubject, of } from 'rxjs';
import { CaseCommonValidator } from '../validation/case-common-validator';
import { SaveResultsType } from '../validation/save-results-type';
import { DsamsShareService } from '../../services/dsams-share.service';
import { MessageMgr } from '../validation/message-mgr';
import { ifaceCaseLineData, ifaceCaseLineSubsetArray, ifaceCaseMasterLineSubset } from '../model/case-line-model';
import { ICaseVersion } from '../model/dto/icase-version';
import { ICustomerRequest } from '../model/dto/customer-request';
import { IUsedUserCase } from '../model/dto/used-user-case';
import { PopCaseActivityComponent } from '../../utilitis/popups/pop-case-activity/pop-case-activity.component';
import { PopPersonComponent } from '../../utilitis/popups/pop-person/pop-person.component';
import { PopCaseAssociationComponent } from '../../utilitis/popups/pop-case-association/pop-case-association.component';
import { IPerson } from '../model/dto/person';
import { MatPaginator } from '@angular/material';
import { PopCustomerRequestComponent } from '../../utilitis/popups/pop-customer-request/pop-customer-request.component';
import { ISelectOptions } from 'src/app/dsams/interfaces/i-select-options';
import { ICaseMaster } from '../model/dto/icase-master';
import { Router, ActivatedRoute } from '@angular/router';
import { CaseRelatedInfoType } from '../model/case-related-info-type';
import { CaseLineRelatedInfoType } from '../model/case-line-related-info-type';
import { LineSublineRefComponent } from '../line-dashboard/line-reference.component';
import { LineUtils } from '../line-dashboard/line-utils';
import { CaseAmendModChangeInfo } from '../model/case-amend-mod-change-info';
import { CasePanelStatusType } from '../model/case-panel-status-type';
import { ErrorParameter } from '../../entities/specialEntities/error-parameter.model';
import { DsamsUserMessageService } from '../../services/dsams-user-message.service';
import { ISearchPageEvent } from '../../utilitis/search-page-event';
import { AuthUtils } from 'src/app/auth-utils';
import { concatMap, tap, take } from 'rxjs/operators';
import { IEditResponseType } from '../model/edit-response-type';
import { CsuCompNameHashTable } from '../../utilitis/csu-component-hashtable';
import { LinkCaseDataIface, LinkCaseDataClass } from '../model/link-case-data'
// event begin DSAMS-5694 09/22 DB;
import { MilestoneCommentComponent } from './../dialogs/milestone-comment/milestone-comment.component';
import { MatDialog } from '@angular/material';
import { DsamsRestfulService } from './../../../dsams/services/dsams-restful.service';
// event end DSAMS-5694 09/22 DB

export class caseConstants {
  static readonly highlightedBtnColor = "lightblue";
  static readonly collapseAll = 'Collapse All';
  static readonly expandAll = 'Expand All';
  static readonly initalButtonBgColor = "#d7dbdd";
  static readonly outlineClickBtnColor = "navy";
  static readonly outlineUnClickBtnColor = caseConstants.initalButtonBgColor;
  static readonly fontBold = "bold";
  static readonly initialCancelColor = "white";
  static readonly initialSaveButtonColor = "#0174DF";
  static readonly initialSaveButtonFontColor = "white";
  static readonly initialCancelButtonColor = "blue";
  static readonly initialResetColor = "white";
  static readonly initialResetButtonColor = "blue";
  static readonly initalOkButtonColor = "blue";
  static readonly initalOkButtonFontColor = "white";
  static readonly goldButtonColor = "goldenrod";
  static readonly searchCaseEnabledColor = "black";
  static readonly searchCaseDisabledColor = "lightgrey";
  static readonly searchCaseEnabledStatus = "true";
  static readonly searchCaseDisabledStatus = "false";
  static readonly searchCaseEnableMouse = "enablePointerEvents";
  static readonly searchCaseDisabledMouse = "disablePointerEvents";
  static readonly REFERENCE_ERROR_HEADER_STR = "Fetching Reference for ";
}

@Injectable({
  providedIn: 'root'
})

@Component({
  selector: 'app-dashboard',
  templateUrl: './case-dashboard.component.html',
  styleUrls: ['./case-dashboard.component.css', './common-CSS.component.css']
})

export class CaseDashboardComponent implements OnInit, OnDestroy {

 // event begin DSAMS-5694 09/22 DB
  milestoneId: string = "";
  milestoneUsage: string = "";
  public static MILESTONE_PENINK = 'PENINK';
  public static MILESTONE_CASE_IN_REVIEW = 'CWDREDIT';
  public static MILESTONE_CASE_IN_PROPOSED = 'CWDPEDIT';
  private static USER_ID: string = "userId";
  private static USER_ACTIVITY_ID : string = "userActivityId";
 // event end DSAMS-5694 09/22 DB

  //For testing line list purpose only - will remove
  showTestLineList: boolean = false;

  //Paginator variables passed to case-search.component.ts
  pageLength: number = 25;
  recordLength: number = DsamsConstants.DEFAULT_MAX_RECORDS;
  pageCount: number = 0;
  pageOptions: number[] = [25, 50, 75, 100];

  //mat-paginator tag variables
  pageSize: number = 25;
  length: number = 100;
  pageIndex: number = 0;
  pageSizeOptions: number[] = [25, 50, 75, 100];

  counter_c: number = 0;
  //New case variables
  txtDoc: string = 'C';
  txtSAProgram: string = 'FMS';
  txtCustReq: string = '';
  txtCustReqForCD: string = '';
  txtCountry: string = '';
  txtIA: string = '';
  txtCaseDesignator: string = '';
  txtVersion: string = '';
  txtVersionTypeCd: string = '';
  sidebarArrow: any = "keyboard_arrow_right";
  searchbarArrow: any = "keyboard_arrow_right";
  private _editSubscription: Subscription = null;
  newValidationArray: any = {};
  repopulateData: boolean = false;
  // Form for new popup for activity
  caseActivityForm: FormGroup;

  // Used for form reset for Case Search,
  // There might be a better way of performing reset.
  txtSearchSAProgram: string = '';
  txtSearchSAProgram2: string = '';
  txtEnterCase: string = '                -             -             '
  txtSearchDocType: string = '';
  txtSearchDocType2: string = '';
  txtSearchCountry: string = '';
  txtSearchIA: string = '';
  txtSearchCaseDesignator: string = '';
  txtSearchCaseStatus: string = '';
  txtSearchVersionStatus: string = '';
  txtSearchPrepareActivity: string = '';
  txtSearchNickname: string = '';
  txtSearchCaseManager: string = '';
  txtSearchDocNumber: string = '';
  txtUserCaseIdSearch: string = '';
  caseFormControl = new FormControl('', [Validators.required, Validators.minLength(6),
  Validators.pattern(/^[A-z0-9]*$/)]);
  caseDesignatorFormControl = new FormControl('', [Validators.required, Validators.minLength(3),
  Validators.pattern(/^[A-z]*$/)]);
  private _cumulativeSaveResultsType: SaveResultsType;
  private _skipValidation: boolean = false;

  // References to child panels

  // Storage fields for the header display.
  txtSAProgramForHeader: string = this.txtSAProgram;
  txtVersionForHeader: string = this.txtVersion;
  txtCountryForHeader: string = this.txtCountry;
  txtIAForHeader: string = this.txtIA;
  txtDocForHeader: string = 'Case';
  txtSearchCaseDesignatorForHeader: string = this.txtSearchCaseDesignator;
  private _currentToggle: boolean = false;
  // Case Info Panel
  @ViewChild(CaseInformationPanelComponent, { static: true })
  private caseInformationPanelComponent: CaseInformationPanelComponent;
  @ViewChild(CustomerRequestPanelComponent, { static: true })
  private customerRequestPanelComponent: CustomerRequestPanelComponent;
  @ViewChild(DescriptionsPanelComponent, { static: true })
  private descriptionsPanelComponent: DescriptionsPanelComponent;
  @ViewChild(DocumentPanelComponent, { static: true })
  private documentPanelComponent: DocumentPanelComponent;
  @ViewChild(SignatoriesPanelComponent, { static: true })
  private signatoriesPanelComponent: SignatoriesPanelComponent;
  @ViewChild(WaiversPanelComponent, { static: true })
  private waiversPanelComponent: WaiversPanelComponent;
  @ViewChild(AssociationsPanelComponent, { static: true })
  private associationsPanelComponent: AssociationsPanelComponent;
  @ViewChild(MatPaginator, { static: true }) private paginator: MatPaginator;

  /* Panel States to facilitate button actions above the accordian */
  panelOpenState1: boolean = true;
  panelOpenState2: boolean = false;
  panelOpenState3: boolean = false;
  panelOpenState4: boolean = false;
  panelOpenState5: boolean = false;
  panelOpenState6: boolean = false;
  panelOpenState7: boolean = false;
  panelOpenState8: boolean = false;
  expandPanelBtnBehavior: string = caseConstants.expandAll;
  caseInfoBgBtnColor = caseConstants.highlightedBtnColor;
  customerBgBtnColor = caseConstants.initalButtonBgColor;
  documentBgBtnColor = caseConstants.initalButtonBgColor;
  descriptionBgBtnColor = caseConstants.initalButtonBgColor;
  signatoriesBgBtnColor = caseConstants.initalButtonBgColor;
  associationBgBtnColor = caseConstants.initalButtonBgColor;
  waiversBgBtnColor = caseConstants.initalButtonBgColor;
  modfundBgBtnColor = caseConstants.initalButtonBgColor;
  outlineBtnColor = caseConstants.initalButtonBgColor;
  boldCaseBtnFont = caseConstants.fontBold;
  boldCustBtnFont = "";
  boldDocBtnFont = "";
  boldDescBtnFont = "";
  boldWaiverBtnFont = "";
  boldModfundBtnFont = "";
  boldAssocBtnFont = "";
  boldSignatoryBtnFont = "";
  saveButtonColor = caseConstants.initialSaveButtonColor;
  saveButtonFontColor = caseConstants.initialSaveButtonFontColor;
  cancelButtonColor = caseConstants.initialCancelButtonColor;
  okButtonColor = caseConstants.initialSaveButtonColor;
  okButtonFontColor = caseConstants.initialSaveButtonFontColor;
  resetButtonColor = caseConstants.initialCancelButtonColor;
  caseNewOkButtonColor = caseConstants.initalOkButtonColor;
  caseNewOkButtonFontColor = caseConstants.initialSaveButtonFontColor;
  caseNewResetButtonColor = caseConstants.initialCancelButtonColor;
  caseSearchOkButtonColor = caseConstants.initalOkButtonColor;
  caseSearchOkButtonFontColor = caseConstants.initialSaveButtonFontColor;
  caseSearchResetButtonColor = caseConstants.initialCancelButtonColor;
  caseDetailResetButtonColor = caseConstants.initialCancelButtonColor;
  caseDetailCancelButtonColor = caseConstants.initialCancelButtonColor;
  showNewCase: boolean = false;
  showSearchCase: boolean = false;
  showCaseDetails: boolean = false;
  showCaseDetailsLines: boolean = false;
  showCaseDetailsNewLine: boolean = false;
  showCaseDetailsNewLineCreate: boolean = false;
  showCaseDetailsNewSublineCreate: boolean = false;
  showCaseDetailsLineOpen: boolean = false;
  showCaseDetailsSublineOpen: boolean = false;
  displayPanels: boolean = false;
  displaySearch: boolean = false;
  displayUnderscontruction: boolean = false;
  searchEnterCaseFontColor = caseConstants.searchCaseEnabledColor;
  SearchOtherCriteriaFontColor = caseConstants.searchCaseDisabledColor;
  searchEnterCaseFieldStatus = caseConstants.searchCaseDisabledStatus;
  SearchOtherCriteriaFieldStatus = caseConstants.searchCaseEnabledStatus;
  searchEnterCaseMouseStatus = caseConstants.searchCaseEnableMouse;
  SearchOtherCriteriaMouseStatus = caseConstants.searchCaseDisabledMouse;
  // Styles for new/search items
  classForPopoutTextNew: string = "col-sm-3 popout-field-text";
  classForPopoutFieldsNew: string = "col-sm-7 popout-field";
  classForPopoutTextSearch: string = "col-sm-3 popout-field-text";
  classForPopoutFieldSearch: string = "col-sm-7 popout-field {{SearchOtherCriteriaMouseStatus}}";
  classForPopoutFieldsError: string = "col-sm-7 error-message";
  widthPctForNewFields: number = 95;
  widthPctForSearchFields: number = 95;

  zIndexPriority = 999;
  newCaseResetState: boolean = false;
  dtlCaseResetState: boolean = false;
  caseSearchFlag = true;
  newOkButtonDisabled: boolean = false;
  caseDesignatorCdAlreadyTaken: boolean = false;
  customerRequestInvalid: boolean = false;
  basicCaseNotExists: boolean = false;

  anotherVersionOfCaseInDevelopmentExists: boolean = false; // Jira Card DSAMS-5426 AKP 05/2022

  // Indicates if the close menu request got processed, so we know to set the size of the side-nav panels accordingly.
  requestCloseMenuProcessed: boolean = false;

  // Reference Lists
  refActivityList: Array<ReferenceDataType> = [];
  refSAProgramList: Array<ReferenceDataType> = [];
  refDocumentTypeListNew: Array<ReferenceDataType> = [];
  refDocumentTypeListExisting: Array<ReferenceDataType> = [];
  refCustomerOrganizationList: Array<ReferenceDataType> = [];
  refImplementingAgencyList: Array<ReferenceDataType> = [];
  refCaseMasterStatusList: Array<ReferenceDataType> = [];
  refCaseVersionStatusList: Array<ReferenceDataType> = [];
  refCaseVersionTypeList: Array<ReferenceDataType> = [];
  refCaseVersionTypeListFull: Array<ReferenceDataType> = [];
  refCaseVersionTypeListBasic: Array<ReferenceDataType> = [];
  refCaseVersionTypeListAMR: Array<ReferenceDataType> = [];
  refCaseManagerList: Array<ReferenceDataType> = [];
  refDocNumberList: Array<ReferenceDataType> = [];
  showDropdownLists = true;

  // Error Levels for each panel.
  public MsgTypeNull: number = MessageMgr.MSG_TYPE_NULL;
  public MsgTypeNone: number = MessageMgr.MSG_TYPE_NONE;
  public MsgTypeInfo: number = MessageMgr.MSG_TYPE_INFO;
  public MsgTypeWarning: number = MessageMgr.MSG_TYPE_WARNING;
  public MsgTypeError: number = MessageMgr.MSG_TYPE_ERROR;
  public errorLevelCaseInfo: number = this.MsgTypeNull;
  public errorLevelCustReq: number = this.MsgTypeNull;
  public errorLevelDocReq: number = this.MsgTypeNull;
  public errorLevelDesc: number = this.MsgTypeNull;
  public errorLevelSignatories: number = this.MsgTypeNull;
  public errorLevelAssociations: number = this.MsgTypeNull;
  public errorLevelWaivers: number = this.MsgTypeNull;
  public errorLevelModfunding: number = this.MsgTypeNull;
  caseValidationLevel: number = MessageMgr.MSG_TYPE_NONE;
  readonly PAGE_CASE_DETAIL: string = DsamsConstants.PAGE_CASE_DETAIL;

  // Contains the case header fields pulled from the middle-tier.
  caseHeaderData: any = {};
  CaseId: number = 0;
  CaseVersionId: number = 0;
  // for toggle card save
  private _alreadyToggledOn: boolean = false;
  // Case Search fields
  caseSearchData: CaseQueryParamsType;
  oldCaseSearchData: CaseQueryParamsType;

  // Can user save case detail.
  canSaveCaseDetail: boolean = false;

  // Subsriptions
  private saveOnEditToggleSubscription: Subscription = null;
  private _canSaveSubscription: Subscription = null;
  private _SRRSubscription: Subscription = null;
  private _backToCaseSearchSubscription: Subscription = null;
  private _caseDetailDataSubscriptionNew: Subscription = null;
  private _validateCaseSubscription: Subscription = null;
  private _panelCaseVersionStatusResponseSubscription: Subscription = null;
  showSpinner: BehaviorSubject<boolean> = new BehaviorSubject(false); 
  private thesubIsCusRequestSaved: Subscription = null;
  private _saveInViewModeSubscription: Subscription = null;  // Jira Card DSAMS-5689 06/2022 AKP
  // Constant denoting each of the panels.
  public caseInfoPanelStr = DsamsConstants.CASE_PANEL_INFO;
  public caseCustRequestPanelStr = DsamsConstants.CASE_PANEL_CUSTOMER_REQUEST;
  public caseDocReqPanelStr = DsamsConstants.CASE_PANEL_DOCUMENT_REQUIREMENTS;
  public caseDescPanelStr = DsamsConstants.CASE_PANEL_DESCRIPTIONS;
  public caseSignatoriesPanelStr = DsamsConstants.CASE_PANEL_SIGNATORIES;
  public caseAssocPanelStr = DsamsConstants.CASE_PANEL_ASSOCIATIONS;
  public caseWaiversPanelStr = DsamsConstants.CASE_PANEL_WAIVERS;
  public caseModFundingPanelStr = DsamsConstants.CASE_PANEL_MODFUNDING;
  private _panelExpansionProperties: PanelExpansionProperties;

  // Variables for DSAMS Share Service
  private _caseEnterSubscription: Subscription = null;
  private _caseSearchSubscription: Subscription = null;
  private _caseDetailsSubscription: Subscription = null;
  private _caseDetailsBCSubscription: Subscription = null;
  private _backToCaseDetailSubscription: Subscription = null;
  private _backToSearchDetailsSubscription: Subscription = null;
  private _caseSelectionSubscription: Subscription = null;
  private _caseDetailSelectedSubscription: Subscription = null;
  private _popupActivitySubscription: Subscription = null;
  private _popupPersonSubscription: Subscription = null;
  private _popupCRSubscription: Subscription = null;
  private _popupCaseDetailSubscription: Subscription = null;
  private _popupICaseMasterSubscription: Subscription = null;
  private _skipValidationSubscription: Subscription = null;
  private _amendModChangeSubscription: Subscription = null;
  private _countryChangeSubscription: Subscription = null;
  private _queryParamsSubscription: Subscription = null;
  private _caseSearchPaginateSubscription: Subscription = null;

  caseEnter: boolean = false;
  caseSearch: boolean = false;
  caseDetails: boolean = false;
  caseSelection: string = "";

  //local variables
  private _skipValidationCheck: boolean = false;

  // Variables for Lines on Case Details Menu Selection
  showSubmenuCase: boolean = false;
  caseRelatedInfoData: CaseRelatedInfoType;
  caseLineRelatedInfoData: CaseLineRelatedInfoType;
  thecaseLineRelatedInfoList: CaseLineRelatedInfoType[];
  showCaseLineMenu: boolean = false;
  lineFormCtl: FormControl = new FormControl();
  subLineFormCtl: FormControl = new FormControl();
  subLineSubFormCtl: FormControl = new FormControl();
  theCaseMasterLineList: ifaceCaseLineSubsetArray[];
  theCaseMasterSublineList: ifaceCaseLineSubsetArray[];
  theCaseMasterLineParentList: ifaceCaseLineSubsetArray[];
  theCaseMasterLineChildList: ifaceCaseMasterLineSubset[];
  caseLineInfoData: ifaceCaseLineData;
  showLineSpinner: boolean = true;

  //
  private searchResult: any = {};

  // Variables for Case Details Nav Panel
  txtSearchCaseDetailsCase: string = '';
  txtSearchCaseDetailsCaseNumber: number = null;
  caseDetailCaseForm: FormGroup;
  caseVersionFormControl: FormControl = new FormControl();

  dropdownCaseVersions: ISelectOptions[] = [];
  caseVersionTypeCd: string;
  caseVersionNumberId: number;
  caseDetailsBC: boolean = false;
  backToSearch: boolean = false;
  hideModFund: boolean = false;
  isNewAmendOrMod: boolean = false;
  private messageService: DsamsUserMessageService;
  private dataSharingService: DsamsShareService;
  private dsamsMethodsService: DsamsMethodsService;
  private dsamsRestService: DsamsRestfulService;
  private dialog: MatDialog;
  //DSAMS-5461 DH 05/22
  theCSUId: string;
  isEditRightAccessGranted: boolean = false;

  linkCaseDataObject: LinkCaseDataIface;
  linkCaseData: any;
  //for card nb
  aCaseRelatedInfoType: CaseRelatedInfoType;
  aCaseLineRelatedInfoType: CaseLineRelatedInfoType;
  CSUHashTable: CsuCompNameHashTable;
  panelOpenState:boolean[]=new Array();
  beforeSaveStr:string='BEFORE_SAVE';
  afterSaveStr:string='AFTER_SAVE';

  // ********** Main Body ***********
  constructor(private injector: Injector,
    private caseRestService: CaseRestfulService,
    private lineShareService: LineSublineRefComponent,
    private router: Router,
    private getLineSublineRefData: LineSublineRefComponent,
    private caseUIService: CaseUIService,
    private routeInfo: ActivatedRoute) {
    this.messageService = injector.get<DsamsUserMessageService>(DsamsUserMessageService);
    this.dataSharingService = injector.get<DsamsShareService>(DsamsShareService);
    this.dsamsMethodsService = injector.get<DsamsMethodsService>(DsamsMethodsService);
    this.dsamsRestService = injector.get< DsamsRestfulService>(DsamsRestfulService);
    this.CSUHashTable = injector.get<CsuCompNameHashTable>(CsuCompNameHashTable);
    this.dialog = injector.get< MatDialog>(MatDialog);
   
  }

  setPageSizeOptions(setPageSizeOptionsInput: string) {
    if (setPageSizeOptionsInput) {
      this.pageSizeOptions = setPageSizeOptionsInput.replace("[", "").replace("]", "").split(',').map(str => +str);
    }
  }

  // Do a POST when the user clicks OK on the search screen.
  submitSearch() {
    // Set some fields on the search params before sending.
    this.caseSearchData.user_ID = +sessionStorage.getItem('userId');

    // Set the activity search to the substring of what's in the text field.
    // (If there's a dash in it (meaning they picked from the popup))
    // Otherwise, search based on what the user manually entered.
    if (this.txtSearchPrepareActivity !== "") {
      const dashIndex: number = this.txtSearchPrepareActivity.indexOf("-");
      if (dashIndex >= 0) {
        this.caseSearchData.activity_ID = this.txtSearchPrepareActivity.substring(0, dashIndex - 1);
      }
      else {
        this.caseSearchData.activity_ID = this.txtSearchPrepareActivity;
      }
    }
    else {
      // Nothing in field.
      this.caseSearchData.activity_ID = "";
    }

    // Show progress spinner on case search screen.
    this.caseUIService.showSearchSpinner.next(true);

    this.caseRestService
      .postCaseSearch(this.caseSearchData)
      .subscribe(
        data => {
          // If more than max records returned, show informational message, and chop off last row.
          if (data.length > DsamsConstants.DEFAULT_MAX_RECORDS) {
            data.splice(DsamsConstants.DEFAULT_MAX_RECORDS, 1);
            MessageMgr.displaySinglePopupInfo("I102");
          }
          this.caseRestService.caseSearchReplaySubject.next(data);
          this.searchResult = data;
          this.length = data.length;
          this.recordLength = data.length;
        },
        err => {
          this.caseUIService.showSearchSpinner.next(false);
          CaseUtils.ReportHTTPError(err, "submitSearch");
        }
      );
    //}
  }

  subscribeToPaginateEvent() {
    if (!this._caseSearchPaginateSubscription) {
      this._caseSearchPaginateSubscription = this.caseUIService.caseSearchPaginate.subscribe((event: ISearchPageEvent) => {
        this.setPageSizeOptions(event.pageSizeOptions);
        this.pageLength = event.pageEvent.pageSize;
        this.pageOptions = this.pageSizeOptions;
        this.recordLength = event.pageEvent.length;
        this.pageCount = event.pageEvent.pageIndex;
        this.pageSize = event.pageEvent.pageSize;
        this.pageIndex = event.pageEvent.pageIndex;
        this.length = event.pageEvent.length;
        // this.caseRestService.caseSearchReplaySubject.next(this.searchResult);  // This slows down the search results.
      });
    }
  }

   // event begin DSAMS-5694 09/22 DB
  // Subscribe to case ui service for option Update Case In Review
  subscribeToOptionCaseInReview() {
    this.caseUIService.optionSelectedUCIR.subscribe((value) => {
      if (value) {
        this.milestoneId = CaseDashboardComponent.MILESTONE_CASE_IN_REVIEW;
        this.milestoneUsage = "";
      }
    });
  }
 

  // Subscribe to case ui service for option Update Case In Proposed
  subscribeToOptionCaseInProposed() {
    this.caseUIService.optionSelectedUCIP.subscribe((value) => {
      if (value) {
        this.milestoneId = CaseDashboardComponent.MILESTONE_CASE_IN_PROPOSED;
        this.milestoneUsage = "";
      }
    });
   
  }

  // Subscribe to case ui service for option Pen and Ink
  subscribeToOptionCasePenInk() {
    this.caseUIService.optionSelectedUCPI.subscribe((value) => {
      if (value) {
        this.milestoneId = CaseDashboardComponent.MILESTONE_PENINK;
        this.milestoneUsage = "";
      }
    });
  }

 // event end DSAMS-5694 09/22 DB


  initializeValidationArray() {
    this.newValidationArray["txtCountry"] = false;
    this.newValidationArray["txtSAProgram"] = false;
    this.newValidationArray["txtDoc"] = false;
    this.newValidationArray["txtIA"] = false;
    this.newValidationArray["txtVersion"] = false;
  }


  initializePanelExpansionProperties() {
    this._panelExpansionProperties = {
      panelName: DsamsConstants.CASE_PANEL_INFO,
      isNewMode: true,
      isResetPanels: true,
      caseHeaderData: this.caseHeaderData,
      caseRequestParams: {
        customerOrganizationId: "",
        caseId: 0,
        caseVersionId: 0,
        caseVersionTypeCd: "",
        securityAssistanceProgramCd: "",
        implementingAgencyId: "",
        customerRequestId: null,
        isEditable: true
      }
    };
  }

  // The real ngOnInit
  ngOnInit() {
    this.showSpinner = new BehaviorSubject(false);
    //begin DSAMS-5461 DH 05/02/22
    let aCsuId = this.CSUHashTable.getCSUId(this.routeInfo.routeConfig.component.name);
    this.theCSUId = aCsuId ? aCsuId : CsuCompNameHashTable.CSU_CD_WP001;
    //end DSAMS-5461 DH 05/02/22
    this.caseUIService.theComponentSaveState[CaseUIService.SAVE_CASE_DETAILS_STATE] = {
      isSaveConfirmed: new BehaviorSubject<boolean>(false), isDataChanged: false
    };
    this.dataSharingService.csuname.next(null);
    this.dataSharingService.csuname.next(this.theCSUId);
    this.getEditAccessRight();
    this.processLinkCaseData();
    //Subcribe to save on Edit toggle
    this.subscribeToSaveOnEditToggle();

    this.ngOnInitPrc();
    // Subscribe to data request.
    this.subscribeToDataRequest();

    this.subscribeBackToSearchSummary();

    // Subscribe to can-save request.
    //  this.subscribeToCanSave();
    this.subscribeToEdit();
    // Subscribe to back-to-case-sarch
    this.subscribeToBackToCaseSearch();

    // Reset Search
    this.searchEnterCaseSelect();

    // Subscribe to Case Enter.
    this.subscribeToCaseEnter();

    // Subscribe to Case Search.
    this.subscribeToCaseSearch();

    // Subscribe to Case Details.
    this.subscribeToCaseDetails();

    // Subscribe to Case Selection.
    this.subscribeToCaseSelection();

    // Subscribe to Activity Popup.
    this.subscribeToPopupActivity();

    // Subscribe to Case Details Case Popup.
    this.subscribeToPopupCase();

    // Subscribe to Case Details Case Selection.
    this.subscribeToICaseMasterSelection();

    // Subscribe to skip validation.
    this.subscribeToSkipValidation();

    // Subscribe to change amend/mod number.
    this.subscribeToAmendModChange();

    // Subscribe to country change.
    this.subscribeToCountryChange();

    // Subscribe to Case Validation
    this.subscribeToValidateCase();

    this.subscribeToCaseDetailBC();

    // Subscribe to Query Params.
    this.subscribeToQueryParams();

    // Subcribe to pageinate event.
    this.subscribeToPaginateEvent();

    // Reset option counter when going to new case (DSAMS-1902)
    this.caseUIService.optionSelectCounter.next(0);

    this.caseUIService.setIsOptionsMenuHidden(false);   // Make options menu visible.
    this.caseUIService.setIsShortcutsMenuHidden(false);
    this.caseUIService.setPageNavigation(DsamsConstants.PAGE_CASE_DETAIL);

    this.subscribeToSaveInViewModeWhenOptionsMenuSelected(); // Jira Card DSAMS-5689 06/2022 AKP

    // event begin DSAMS-5694 09/22 DB
 this.subscribeToOptionCaseInReview();
 this.subscribeToOptionCaseInProposed();
    this.subscribeToOptionCasePenInk();
    this.setUserActivityId();
// event end DSAMS-5694 09/22 DB
  }

  //begin DSAMS-5461 DH 05/22
  getEditAccessRight(): void {
    this.lineShareService.getEditAccessRight(this.theCSUId)
      .pipe(take(1))
      .subscribe(result => {
        if (result == 1) this.isEditRightAccessGranted = true;
        else {
          this.isEditRightAccessGranted = false;
          this.caseUIService.setIsOptionsMenuHidden(true);
        }
      });
  }
  //end DSAMS-5461 DH 05/22

  //Jira DSAMS-5346 DH 04/22
  processLinkCaseData() {
    if (!!this.routeInfo.snapshot.queryParamMap.get(LinkCaseDataClass.linkServiceDbId)) {
      this.showSpinner.next(true);
      //set inital DB in case of asynchronous issue with query params subscription
      sessionStorage.setItem(DsamsConstants.SESSION_SDB_ID,
        this.routeInfo.snapshot.queryParamMap.get(LinkCaseDataClass.linkServiceDbId));
      this.caseRelatedInfoData = {
        case_ID: parseInt(this.routeInfo.snapshot.queryParamMap.get(LinkCaseDataClass.linkCaseID)),
        case_VERSION_ID: this.routeInfo.snapshot.queryParamMap.get(LinkCaseDataClass.linkCaseVersionId),
        working_CASE_VERSION_ID: parseInt(this.routeInfo.snapshot.queryParamMap.get(LinkCaseDataClass.linkCaseVersionId)),
      }
      this.caseLineRelatedInfoData = {
        case_VERSION_TYPE_CD: this.routeInfo.snapshot.queryParamMap.get(LinkCaseDataClass.linkCaseVersionTypeCd),
        user_CASE_ID: this.routeInfo.snapshot.queryParamMap.get(LinkCaseDataClass.linkUserCaseId),
        customer_REQUEST_ID: 0,
      }
      //emitting updated case info data 
      this.caseUIService.setCaseLineRelatedInfoValues(this.caseLineRelatedInfoData);
      this.caseUIService.setCaseRelatedInfoValues(this.caseRelatedInfoData);
    }
  }

  ngOnInitPrc() {
    this._skipValidation = false;

    // Initialize the Panel Expansion Properties.
    this.initializePanelExpansionProperties();

    // Get user info.
    this.getCaseUserInfo();

    // Get reference data (common)
    this.getAllReferenceDataCommon();

    this.resetFieldsValidation();

    // Reset case search fields.
    this.resetCaseSearchArray();

    // Reset Error Icons
    this.resetErrorIcons();

    //set up validation araray
    this.initializeValidationArray();
  }


  ngAfterViewInit() {
    // Load the data for panels initially expanded.
    this.notifyPanelsInitiallyExpanded();
  }

  // Popuplate the caseSearchData based on the query params.
  private populateCaseSearchDataFromQueryParam(csqp: string): boolean {
    let result: boolean = true;
    let tmpCSD: CaseQueryParamsType;
    // Catch any execptions caused by a missing entry in the tilde separated list.
    try {
      const parsedArray: Array<string> = csqp.split("~");
      tmpCSD.case_USAGE_INDICATOR_CD1 = parsedArray[0];
      tmpCSD.security_ASSISTANCE_PROGRAM_CD1 = parsedArray[1];
      tmpCSD.user_CASE_ID = parsedArray[2];
      const blankStr: string = "";
      const sbCaseId: boolean = (tmpCSD.user_CASE_ID !== blankStr);
      tmpCSD.searchByUserCaseId = sbCaseId;
      tmpCSD.case_USAGE_INDICATOR_CD2 = sbCaseId ? blankStr : parsedArray[3];
      tmpCSD.security_ASSISTANCE_PROGRAM_CD1 = sbCaseId ? blankStr : parsedArray[4];
      tmpCSD.customer_ORGANIZATION_ID = sbCaseId ? blankStr : parsedArray[5];
      tmpCSD.implementing_AGENCY_ID = sbCaseId ? blankStr : parsedArray[6];
      tmpCSD.case_DESIGNATOR = sbCaseId ? blankStr : parsedArray[7];
      tmpCSD.case_MASTER_STATUS_CD = sbCaseId ? blankStr : parsedArray[8];
      tmpCSD.case_VERSION_STATUS_CD = sbCaseId ? blankStr : parsedArray[9];
      tmpCSD.activity_ID = sbCaseId ? blankStr : parsedArray[10];
      tmpCSD.case_NICKNAME_NM = sbCaseId ? blankStr : parsedArray[11];
      tmpCSD.case_MANAGER_ID = sbCaseId ? 0 : +parsedArray[12];
      tmpCSD.case_MANAGER_USERNAME = sbCaseId ? blankStr : parsedArray[13];
      tmpCSD.user_ID = sbCaseId ? 0 : +parsedArray[14];
      tmpCSD.case_VERSION_NUMBER_ID = sbCaseId ? blankStr : parsedArray[15];
      tmpCSD.resultFormatParams.showAllRows = false;
      tmpCSD.resultFormatParams.minRow = 1;
      tmpCSD.resultFormatParams.maxRow = DsamsConstants.DEFAULT_MAX_RECORDS;
      tmpCSD.resultFormatParams.sortColumns = ["user_case_id"];
      tmpCSD.searchByCasePopup = false;
      this.caseSearchData = tmpCSD;

    }
    catch (e) {
      // Missing entry or malformed, so return false.
      result = false;
    }
    return result;
  }

  // Subscribe to query parameters.
  subscribeToQueryParams() {
    if (!this._queryParamsSubscription) {
      this._queryParamsSubscription = this.routeInfo.queryParams.subscribe((routeParams) => {
        let invalidParams: boolean = false;
        let populateSearch: boolean = false;
        let populateCaseDetail: boolean = false;
        if (!!routeParams && !!routeParams.serviceDbId) {
          if (routeParams.serviceDbId === "A" || routeParams.serviceDbId === "F" || routeParams.serviceDbId === "N") {
            if (!!routeParams.csqp) {
              if (this.populateCaseSearchDataFromQueryParam(routeParams.csqp)) {
                populateSearch = true;
              }
              else {
                invalidParams = true;
              }
            }
            else {
              // By caseId/CVID
              if (!!routeParams.caseId && !!routeParams.caseVersionId) {
                if ((parseInt(routeParams.caseId)).toString() == routeParams.caseId && (parseInt(routeParams.caseVersionId)).toString() == routeParams.caseVersionId) {
                  populateCaseDetail = true;
                }
                else {
                  invalidParams = true;
                }
              }
            }
          }
          else {   // Missing or invalid service DB ID
            invalidParams = true;
          }
          // Perform an action depending on what parameters are provided.
          if (invalidParams) {
            MessageMgr.displaySinglePopupError("E101");
          }
          else if (populateSearch) {
            console.log("Populating search!!");
          }
          else if (populateCaseDetail) {
            sessionStorage.setItem(DsamsConstants.SESSION_SDB_ID, routeParams.serviceDbId);
            const caseRequestParms: CaseRequestParamsType = {
              caseId: routeParams.caseId,
              caseVersionId: routeParams.caseVersionId,
              customerOrganizationId: "",
              caseVersionTypeCd: "",
              securityAssistanceProgramCd: "",
              implementingAgencyId: "",
              customerRequestId: 0,
              isEditable: false
            };
            this.notifyCaseDetailScreen(caseRequestParms);
            this.caseUIService.flipToDisabledService.next(DsamsConstants.CASE_VERSION_EDITOR);
            this.caseUIService.submitBreadcrumbTitleChangeRequest("Case Search Summary");
            this.caseUIService.submitBreadcrumbTitleChangeRequest("Case Detail");
            this.displaySearch = false;
          }
        }
      });
    }
  }


  // Destroy any non-HTTP subscriptions.
  ngOnDestroy(): void {
    this.caseUIService.theComponentSaveState[CaseUIService.SAVE_CASE_DETAILS_STATE].isDataChanged = false;
    this.caseUIService.theComponentSaveState[CaseUIService.SAVE_CASE_DETAILS_STATE].isSaveConfirmed = null;
    if (this._canSaveSubscription) {
      this._canSaveSubscription.unsubscribe();
      this._canSaveSubscription = null;
    }
    if (this._SRRSubscription) {
      this._SRRSubscription.unsubscribe();
      this._SRRSubscription = null;
    }
    if (this._caseEnterSubscription) {
      this._caseEnterSubscription.unsubscribe();
      this._caseEnterSubscription = null;
    }
    if (this._caseSearchSubscription) {
      this._caseSearchSubscription.unsubscribe();
      this._caseSearchSubscription = null;
    }
    if (this._caseDetailsSubscription) {
      this._caseDetailsSubscription.unsubscribe();
      this._caseDetailsSubscription = null;
    }
    if (this._caseDetailDataSubscriptionNew) {
      this._caseDetailDataSubscriptionNew.unsubscribe();
      this._caseDetailDataSubscriptionNew = null;
    }
    if (!!this._validateCaseSubscription) {
      this._validateCaseSubscription.unsubscribe();
      this._validateCaseSubscription = null;
    }
    if (!!this._panelCaseVersionStatusResponseSubscription) {
      this._panelCaseVersionStatusResponseSubscription.unsubscribe();
      this._panelCaseVersionStatusResponseSubscription = null;
    }
    if (this._skipValidationSubscription) {
      this._skipValidationSubscription.unsubscribe();
      this._skipValidationSubscription = null;
    }
    if (this._amendModChangeSubscription) {
      this._amendModChangeSubscription.unsubscribe();
      this._amendModChangeSubscription = null;
    }
    if (this._countryChangeSubscription) {
      this._countryChangeSubscription.unsubscribe();
      this._countryChangeSubscription = null;
    }
    if (this._queryParamsSubscription) {
      this._queryParamsSubscription.unsubscribe();
      this._queryParamsSubscription = null;
    }
    if (this._caseSearchPaginateSubscription) {
      this._caseSearchPaginateSubscription.unsubscribe();
      this._caseSearchPaginateSubscription = null;
    }
    if (!!this.saveOnEditToggleSubscription) {
      this.saveOnEditToggleSubscription.unsubscribe();
      this.saveOnEditToggleSubscription = null;
    }
    this.destroySubscriptions();
  }

  //added missing subscriptions 
  private destroySubscriptions() {
    if (this._editSubscription) {
      this._editSubscription.unsubscribe();
      this._editSubscription = null;
    }
    if (this._backToCaseDetailSubscription) {
      this._backToCaseDetailSubscription.unsubscribe();
      this._backToCaseDetailSubscription = null;
    }
    if (this._caseDetailsBCSubscription) {
      this._caseDetailsBCSubscription.unsubscribe();
      this._caseDetailsBCSubscription = null;
    }
    if (this._backToSearchDetailsSubscription) {
      this._backToSearchDetailsSubscription.unsubscribe();
      this._backToSearchDetailsSubscription = null;
    }
    // begin Jira Card DSAMS-5689 06/2022 AKP
    if (this._saveInViewModeSubscription) {
      this._saveInViewModeSubscription.unsubscribe();
      this._saveInViewModeSubscription = null;
    }
    // end Jira Card DSAMS-5689 06/2022 AKP
    if (this._backToCaseSearchSubscription) {
      this._backToCaseSearchSubscription.unsubscribe();
      this._backToCaseSearchSubscription = null;
    }
    if (this._caseDetailSelectedSubscription) {
      this._caseDetailSelectedSubscription.unsubscribe();
      this._caseDetailSelectedSubscription = null;
    }
    if (this._popupPersonSubscription) {
      this._popupPersonSubscription.unsubscribe();
      this._popupPersonSubscription = null;
    }
    if (this._popupCRSubscription) {
      this._popupCRSubscription.unsubscribe();
      this._popupCRSubscription = null;
    }
    if (this._popupICaseMasterSubscription) {
      this._popupICaseMasterSubscription.unsubscribe();
      this._popupICaseMasterSubscription = null;
    }
    if (this.showSpinner) {
      this.showSpinner.unsubscribe();
      this.showSpinner = null;
    }
  }

  /**
   * Assign template fields from the model.   
   */
  private setHeaderFieldsFromData(pCaseDetailData: ICaseVersion) {
    this.caseHeaderData["case_STATUS_TITLE_NM"] = pCaseDetailData.theCaseId.theCaseMasterStatusCd.case_STATUS_TITLE_NM;
    if (!!pCaseDetailData.theCaseId.security_ASSISTANCE_PROGRAM_CD) {
      this.caseHeaderData["security_ASSISTANCE_PROGRAM_CD"] = pCaseDetailData.theCaseId.security_ASSISTANCE_PROGRAM_CD;
    }
    this.caseHeaderData["user_CASE_ID"] = pCaseDetailData.theCaseId.user_CASE_ID;
    this.caseHeaderData["case_VERSION_TYPE_NM"] = pCaseDetailData.theCaseVersionTypeCd.case_VERSION_TYPE_NM;
    this.caseHeaderData["case_VERSION_TYPE_CD"] = pCaseDetailData.theCaseVersionTypeCd.case_VERSION_TYPE_CD;
    this.caseHeaderData["version_STATUS_TITLE_NM"] = pCaseDetailData.theCaseVersionStatusCd.version_STATUS_TITLE_NM;
    this.caseHeaderData["case_STATUS_TITLE_NM"] = pCaseDetailData.theCaseId.theCaseMasterStatusCd.case_STATUS_TITLE_NM;
    if (pCaseDetailData.case_VERSION_NUMBER_ID === 0) {
      this.caseHeaderData["case_VERSION_NUMBER_ID"] = "";
    }
    else {
      this.caseHeaderData["case_VERSION_NUMBER_ID"] = pCaseDetailData.case_VERSION_NUMBER_ID;
    }
    this.caseHeaderData["customer_ORGANIZATION_ID"] = pCaseDetailData.theCaseId.customer_ORGANIZATION_ID;
    this.caseUIService.setCaseCustReqId(pCaseDetailData.customer_REQUEST_ID);
    if (this.caseVersionTypeCd !== 'M') {
      this.hideModFund = true;
    } else {
      this.hideModFund = false;

    }
  }

  /**
   * Propogate the events - one to each panel.
   */
  private propagateCaseDetailDataToAllPanels(pCaseDetailData: ICaseVersion) {
    // Repeat next-ing once for each panel.
    // for (let i = 0; i < 6; i++) {
    // Or not - only need to submit subscription once.
    this.caseUIService.caseDetailData.next(pCaseDetailData);
    if (!!pCaseDetailData) {
      this.getAndSetCaseLineRelatedData(pCaseDetailData);
    }
    // }
  }

  getAndSetCaseLineRelatedData(caseDetailData: ICaseVersion) {
    //dsams-5370 - populate case line info 
    this.caseUIService.getCaseLineRelatedInfoValues().pipe(take(1)).subscribe(caseLineInfoData => {
      //make sure to reuse caseLineRelatedInfoData object before re-emiting it
      this.caseLineRelatedInfoData = caseLineInfoData;
      if (!!this.caseLineRelatedInfoData)
        this.caseLineRelatedInfoData.case_VERSION_STATUS_CD = caseDetailData.case_VERSION_STATUS_CD;
      else {
        this.caseLineRelatedInfoData = {
          case_VERSION_ID: caseDetailData.case_VERSION_ID,
          case_VERSION_NUMBER_ID: caseDetailData.case_VERSION_NUMBER_ID,
          case_VERSION_TYPE_CD: caseDetailData.case_VERSION_TYPE_CD,
          case_VERSION_STATUS_CD: caseDetailData.case_VERSION_STATUS_CD,
        }
      }
      //emitting CaseLineRelatedInfoValues data
      this.caseUIService.setCaseLineRelatedInfoValues(this.caseLineRelatedInfoData);

    });
  }

  /**
   * This method will get the case detail data from legacy.   
   */
  getCaseDetailFromLegacy(pCaseRequestParams: CaseRequestParamsType) {
    this.showSpinner.next(true);
    this.caseRestService
      .getCaseDetailLegacy(pCaseRequestParams.caseId, pCaseRequestParams.caseVersionId).pipe(take(1))
      .subscribe(
        data => {
          if (data) {
            const caseDetailData: ICaseVersion = data;
            // Propogate out the event, one to each panel.
            this.propagateCaseDetailDataToAllPanels(caseDetailData);
            this.caseVersionTypeCd = data.case_VERSION_TYPE_CD;
            this.caseVersionNumberId = data.case_VERSION_NUMBER_ID;
            this.setHeaderFieldsFromData(caseDetailData);
            if (this.isNewAmendOrMod) {
              setTimeout(() => {
                this.caseUIService.caseEditService.next({ ID: DsamsConstants.CASE_VERSION_EDITOR, editToggle: true });
              }, 0);
              //done resetting it
              this.isNewAmendOrMod = false;
            }
            else {
              if (!this.repopulateData) {
                setTimeout(() => {
                  this.caseUIService.caseEditService.next({ ID: DsamsConstants.CASE_VERSION_EDITOR, editToggle: false });
                }, 0);
              }
              this.repopulateData = false;
              this.showSpinner.next(false);
            }
          }
        },
        err => {
          CaseUtils.ReportHTTPError(err, "Loading Case Info Legacy");
          this.showSpinner.next(false);
        }
      );
  }

  /**
   * This method will get the case detail data from legacy for new mode.
   */
  getCaseDetailFromLegacyNew() {
    const newCaseParams: any = {
      "userId": sessionStorage.getItem('userId'),
      "caseUsageIndicatorCd": this.txtDoc,
      "customerOrganizationId": this.txtCountryForHeader,
      "userCaseId": this.txtCountryForHeader + this.txtIAForHeader + this.txtSearchCaseDesignatorForHeader,
      "caseVersionTypeCd": this.txtVersionTypeCd,
      "customerRequestId": +this.txtCustReqForCD,
      "caseMasterStatusCd": "P",
      "caseVersionStatusCd": "D"
    }
    this.showSpinner.next(true);
    //DH - for reverse case identifier option
    let aReserveCaseIdData: IUsedUserCase =
    {
      case_DESIGNATOR_CD: this.txtSearchCaseDesignatorForHeader,
      customer_ORGANIZATION_ID: this.txtCountryForHeader,
      implementing_AGENCY_ID: this.txtIAForHeader,
      pseudo_IN: false,
    }
    this.caseRestService
      .getUsedUserCase(aReserveCaseIdData.case_DESIGNATOR_CD,
        aReserveCaseIdData.implementing_AGENCY_ID,
        aReserveCaseIdData.customer_ORGANIZATION_ID)
      .subscribe((uuc: IUsedUserCase) => {
        aReserveCaseIdData.pseudo_IN = uuc.pseudo_IN;
      });
    this.caseUIService.setReserveCaseIdentifierData(aReserveCaseIdData);
    this.takeDownSpinner();
    this._caseDetailDataSubscriptionNew =
      this.caseRestService
        .getCaseDetailLegacyNew(newCaseParams)
        .subscribe(
          data => {
            if (data) {
              const caseDetailData: ICaseVersion = data;
              this.propagateCaseDetailDataToAllPanels(caseDetailData);
              this.setHeaderFieldsFromData(caseDetailData);
              this.caseUIService.theComponentSaveState[CaseUIService.SAVE_CASE_DETAILS_STATE].isDataChanged = true;
            }
            this.showSpinner.next(false);
          },
          err => {
            this.showSpinner.next(false);
            CaseUtils.ReportHTTPError(err, "Loading Case Info Legacy New");
          }
        );
  }



  /* --------------------------------------------------------------------------
  This function will notify the panel to expand with a case version and case version ID.
  ----------------------------------------------------------------------------- */
  notifyCaseDetailScreen(pCaseRequestParams: CaseRequestParamsType) {
    this.showNewCase = false;
    this.showSearchCase = false;
    this.showCaseDetails = false;
    this.displaySearch = false;
    this.ngOnInitPrc();
    this.displayUnderscontruction = false;
    this.displayPanels = true;
    this._panelExpansionProperties = {
      panelName: DsamsConstants.CASE_PANEL_INFO,
      isNewMode: false,
      isResetPanels: true,
      caseHeaderData: this.caseHeaderData,
      caseRequestParams: pCaseRequestParams
    }
    this.panelOpenState1 = true;
    this.panelOpenState2 = false;
    this.panelOpenState3 = false;
    this.panelOpenState4 = false;
    this.panelOpenState5 = false;
    this.panelOpenState6 = false;
    this.panelOpenState7 = false;
    this.panelOpenState8 = false;

    this.caseUIService.setPanelExpanded(this._panelExpansionProperties);
    this.CaseId = pCaseRequestParams.caseId;
    this.CaseVersionId = pCaseRequestParams.caseVersionId;
    this.getCaseDetailFromLegacy(pCaseRequestParams);
  }

  /* --------------------------------------------------------------------------
  This function will emit the event to notify the other panels that they are
  expanded so the panel can peform post-expand actions (such as fetch from database).
  ----------------------------------------------------------------------------- */
  notifyPanel(pPanelName: string, pExpanded: boolean, pResetPanels: boolean) {
    if (pExpanded) {
      this._panelExpansionProperties.panelName = pPanelName;
      this._panelExpansionProperties.isResetPanels = pResetPanels;
      if (this._panelExpansionProperties.isNewMode) {
        this._panelExpansionProperties.caseRequestParams.customerOrganizationId = this.txtCountryForHeader;
        this._panelExpansionProperties.caseRequestParams.caseVersionTypeCd = this.txtVersionTypeCd;
        this.txtSAProgramForHeader = this.txtSAProgram;
        this._panelExpansionProperties.caseRequestParams.securityAssistanceProgramCd = this.txtSAProgramForHeader;
        this._panelExpansionProperties.caseRequestParams.implementingAgencyId = this.txtIAForHeader;
        this._panelExpansionProperties.caseRequestParams.customerRequestId = +this.txtCustReqForCD;
        // Set the header info to what the user entered (since we won't have it from the database by then).
        this.caseHeaderData["security_ASSISTANCE_PROGRAM_CD"] = this.txtSAProgramForHeader;
        this.caseHeaderData["user_CASE_ID"] = CaseUtils.formatUserCaseId(this.txtCountryForHeader + this.txtIAForHeader + this.txtSearchCaseDesignatorForHeader);
        this.caseHeaderData["case_USAGE_INDICATOR_CD"] = this.txtDocForHeader;
        this._panelExpansionProperties.caseHeaderData = this.caseHeaderData;
      }
      this.caseUIService.setPanelExpanded(this._panelExpansionProperties);
    }
    else {
      // Collapsed
      // Notify panel that is collapsed so that it knows not to validate.
      this.caseUIService.panelCollapsed.next(pPanelName);
    }
  }

  /* --------------------------------------------------------------------------
  This function will notify all the panels that start out expended to load from 
  the database/JSON.
  ----------------------------------------------------------------------------- */
  notifyPanelsInitiallyExpanded() {
    //console.log("Inside notifyPanelsInitiallyExpanded");
    this.notifyPanel(DsamsConstants.CASE_PANEL_INFO, this.panelOpenState1, true);
    this.notifyPanel(DsamsConstants.CASE_PANEL_CUSTOMER_REQUEST, this.panelOpenState2, true);
    this.notifyPanel(DsamsConstants.CASE_PANEL_DOCUMENT_REQUIREMENTS, this.panelOpenState3, true);
    this.notifyPanel(DsamsConstants.CASE_PANEL_DESCRIPTIONS, this.panelOpenState4, true);
    this.notifyPanel(DsamsConstants.CASE_PANEL_SIGNATORIES, this.panelOpenState5, true);
    this.notifyPanel(DsamsConstants.CASE_PANEL_ASSOCIATIONS, this.panelOpenState6, true);
    this.notifyPanel(DsamsConstants.CASE_PANEL_WAIVERS, this.panelOpenState7, true);
    this.notifyPanel(DsamsConstants.CASE_PANEL_MODFUNDING, this.panelOpenState8, true);

    // Initially set the buttons to their default state.
    this.setButtonColorAccordingToWhatsOpenOrClosed("", true);

    //console.log("Exiting notifyPanelsInitiallyExpanded");
  }

  /* --------------------------------------------------------------------------
    This procedure clears all the values on the Case Search side bar for the
     New case
  ----------------------------------------------------------------------------- */
  newResetButtonClick() {
    this.txtDoc = 'C';
    this.txtCustReq = '';
    this.txtCustReqForCD = '';
    this.txtCountry = '';
    this.txtIA = '';
    this.txtCaseDesignator = '';
    this.txtVersion = '';
    this.txtSAProgram = 'FMS';
    // this.displayPanels = false;
    this.displaySearch = false;
    this.txtSearchNickname = '';
    this.txtSearchCaseDesignator = '';
    this.txtSearchDocNumber = '';
    this.newCaseResetState = true;
    this.txtSearchCaseManager = '';
    this.refCaseVersionTypeList = this.refCaseVersionTypeListFull;
    this.resetCaseSearchArray();
  }

  searchResetButtonClick() {
    this.txtSearchSAProgram = '';
    this.txtEnterCase = '                -             -             '
    this.txtSearchDocType = '';
    this.txtSearchSAProgram2 = '';
    this.txtSearchDocType2 = '';
    this.txtSearchCountry = '';
    this.txtSearchIA = '';
    this.txtSearchCaseDesignator = '';
    this.txtSearchCaseStatus = '';
    this.txtSearchVersionStatus = '';
    this.txtSearchPrepareActivity = '';
    this.txtSearchNickname = '';
    this.txtSearchCaseManager = '';
    this.txtSearchDocNumber = '';
    this.displaySearch = false;
    this.txtCaseDesignator = '';
  }

  resetAllDisplayStates(ExcludeExpansionPanel: boolean) {
    this.showNewCase = false;
    this.showSearchCase = false;
    this.showCaseDetails = false;
    this.resetFieldsValidation();
    this.displaySearch = false;

    if (ExcludeExpansionPanel)
      this.displayPanels = false;
    //for now
    this.txtDoc = 'C';
    this.txtCustReq = '';
    this.txtCountry = '';
    this.txtIA = '';
    this.txtCaseDesignator = '';
    this.txtVersion = '';
    this.txtSAProgram = 'FMS';
    this.txtSearchNickname = '';
    this.txtSearchCaseDesignator = '';
    this.txtSearchDocNumber = '';
    this.txtSearchCaseManager = '';
    this.newCaseResetState = true;
    this.resetCaseSearchArray();
  }

  performCaseMandatoryFieldVal() {
    if (this.caseFormControl.hasError('required')) {
      return 'This is a required entry';
    }
    else if ((this.caseFormControl.hasError('pattern')) ||
      (this.caseFormControl.hasError('minlength'))) {
      return 'Invalid entry';
    }
  }

  performCaseDesignatorMandatoryFieldVal(): string {
    if (this.caseDesignatorFormControl.hasError('required')) {
      return 'Field is required.';
    }
    else if ((this.caseDesignatorFormControl.hasError('pattern')) ||
      (this.caseDesignatorFormControl.hasError('minlength'))) {
      return 'Invalid entry';
    }
  }

  processSAProgramChange() {
    this.txtSAProgramForHeader = this.txtSAProgram;
  }

  processCustReqChange() {
    this.txtCustReqForCD = this.txtCustReq;
    this.checkCustomerRequest();
  }

  processVersionChange() {
    this.txtVersionForHeader = this.txtVersion;
    this.checkCaseDesignator();
  }

  clearCountry() {
    this.txtCountry = "";
    this.processCountryChange();
  }

  processCountryChange() {
    this.txtCountryForHeader = this.txtCountry;
    this.checkCaseDesignator();
    this.checkCustomerRequest();
  }

  processIAChange() {
    this.txtIAForHeader = this.txtIA;
    this.checkCaseDesignator();
  }

  processDocChange() {
    this.txtDocForHeader = this.txtDoc;
  }

  processCaseDesignatorChange() {
    this.txtSearchCaseDesignatorForHeader = this.txtCaseDesignator;
    this.checkCaseDesignator();
  }

  //begin DSAMS-5435 05/22 DB
  processCaseDesignatorBlur($event) {
    if (!!this.txtCountry && this.txtCountry.length == 2 && !!this.txtIA && this.txtIA.length == 1) {
      let value: string = $event.target.value;
      if (!!value && value.length > 0 && value.length < 3) {
        if (value.substring(0, 1) != "K") {
          this.subscribeToGetNextCaseDesginator(value);

        } else {
          let msg = "All 3 positions of the case designator must be manually entered for CLSSA (1st position of case designator is K) cases.";
          MessageMgr.displayInfo(msg);

        }
      }

    }
  }

  subscribeToGetNextCaseDesginator(value: string) {
    this.caseRestService.getNextCaseDesignator(value, this.txtCountry, this.txtDoc, this.txtIA).subscribe(
      result => {
        if (!!result) {
          this.caseDesignatorFormControl.setValue(result.nextCd);
          this.txtCaseDesignator = result.nextCd;
          this.txtSearchCaseDesignatorForHeader = result.nextCd;
          this.checkCaseDesignator();
        }
      });
  }

  // end DSAMS-5435 05/22 DB


  setNewDefaultDislayValues() {
    this.txtDoc = 'C';
    this.txtSAProgram = 'FMS';
    this.txtCustReq = '';
    this.txtCountry = '';
    this.txtIA = '';
    this.txtVersion = '';
    this.txtSearchNickname = '';
    this.txtCaseDesignator = '';
    this.txtSearchCaseDesignator = '';
    this.txtSearchDocNumber = '';
    this.newCaseResetState = true;
    this.txtSearchCaseManager = '';
    this.resetCaseSearchArray();
  }

  /* This procedure is used to validate for mandatory feidls */
  checkMandatoryFields(): string {
    var txtMessage: string = '';

    if (this.txtSAProgram === '' || this.txtSAProgram === null) {
      txtMessage = txtMessage.concat('SA Program');
      this.newValidationArray['txtSAProgram'] = true
    }
    else this.newValidationArray['txtSAProgram'] = false
    if (this.txtDoc === '' || this.txtDoc === null) {
      if (txtMessage == '')
        txtMessage = txtMessage.concat('DOC Type');
      else txtMessage = txtMessage.concat(', DOC Type');
      this.newValidationArray['txtDoc'] = true
    }
    else this.newValidationArray['txtDoc'] = false
    if (this.txtCountry === '' || this.txtCountry === null) {
      if (txtMessage == '')
        txtMessage = txtMessage.concat('Country');
      else txtMessage = txtMessage.concat(', Country');
      this.newValidationArray['txtCountry'] = true
    }
    else this.newValidationArray['txtCountry'] = false
    if (this.txtIA === '' || this.txtIA === null) {
      if (txtMessage == '')
        txtMessage = txtMessage.concat('IA');
      else txtMessage = txtMessage.concat(', IA');
      this.newValidationArray['txtIA'] = true
    }
    else this.newValidationArray['txtIA'] = false
    if (this.txtCaseDesignator === '')
      if (txtMessage == '')
        txtMessage = txtMessage.concat('Case Designator');
      else txtMessage = txtMessage.concat(', Case Designator');
    this.caseDesignatorFormControl.markAsTouched();
    if (this.txtVersion === '' || this.txtVersion === null) {
      if (txtMessage == '')
        txtMessage = txtMessage.concat('Version');
      else txtMessage = txtMessage.concat(', Version');
      this.newValidationArray['txtVersion'] = true
    }
    else this.newValidationArray['txtVersion'] = false
    return txtMessage;
  }


  // Check Customer Request Validity
  checkCustomerRequest() {
    if (this.txtCustReq == null || this.txtCountry == null || this.txtCustReq === "" || this.txtCountry === "") {
      this.customerRequestInvalid = false;
      return;
    }

    if (isNaN(+this.txtCustReq)) {
      this.customerRequestInvalid = true;
      return;
    }

    // First, disable the New OK button while the database call is being made.
    this.newOkButtonDisabled = true;

    // Call the database to check the customer request ID.
    this.caseRestService
      .getCustomerRequest(+this.txtCustReq, this.txtCountry)
      .subscribe(custReq => {
        const custReqData: ICustomerRequest = <ICustomerRequest>custReq;
        this.customerRequestInvalid = (custReqData.customer_REQUEST_ID <= 0);
        this.newOkButtonDisabled = false;
      },
        err => {
          CaseUtils.ReportHTTPError(err, "Unable to check Customer Request ID.");
          this.newOkButtonDisabled = false;
        }
      );
  }


  checkCaseDesignator() {
    if (this.txtIA == null ||
      this.txtCaseDesignator == null ||
      this.txtCountry == null ||
      this.txtIA === "" ||
      this.txtCountry === "" ||
      this.txtCaseDesignator === "" ||
      this.txtCaseDesignator.length < 3) {
      this.caseDesignatorCdAlreadyTaken = false;
      this.basicCaseNotExists = false;
      this.anotherVersionOfCaseInDevelopmentExists = false; // Jira Card DSAMS-5426 AKP 05/2022
      return;
    }

    // First, disable the New OK button while the database call is being made.
    this.newOkButtonDisabled = true;

    this.caseRestService
      .getUsedUserCase(this.txtCaseDesignator, this.txtIA, this.txtCountry)
      .subscribe((uuc: IUsedUserCase) => {
        // Flip txtVersion to null if the list changes.
        // const prevLength = this.refCaseVersionTypeList.length;
        this.refCaseVersionTypeList = (uuc.status == 0) ? this.refCaseVersionTypeListAMR : this.refCaseVersionTypeListBasic;
        //if (prevLength != this.refCaseVersionTypeList.length) {
        //  this.txtVersion = "";
        // }
        this.newOkButtonDisabled = false;
      },
        err => {
          CaseUtils.ReportHTTPError(err, "Unable to check Case Designator.");
          this.newOkButtonDisabled = false;
        }
      );

    // Check again in case the user tries to trick it by changing a field and clicking OK real fast.
    if (this.txtVersion.substring(0, 1) === "B") {
      // If checking AMR, basic case error does not apply.
      this.basicCaseNotExists = false;
      this.anotherVersionOfCaseInDevelopmentExists = false; // Jira Card DSAMS-5426 AKP 05/2022

      // Call the database to make sure the case desginator cd is not already taken.
      this.caseRestService
        .getUsedUserCase(this.txtCaseDesignator, this.txtIA, this.txtCountry)
        .subscribe((uuc: IUsedUserCase) => {
          this.caseDesignatorCdAlreadyTaken = (uuc.status == 0);  // Means existing record (unchanged)
          this.newOkButtonDisabled = false;
        },
          err => {
            CaseUtils.ReportHTTPError(err, "Unable to check Case Designator.");
            this.newOkButtonDisabled = false;
          }
        );
    }
    else if (this.txtVersion !== "") {   // A/M/R
      this.caseDesignatorCdAlreadyTaken = false;
      // Call the database to make sure the basic case exists.
      this.caseRestService
        .hasBasicCase(this.txtCaseDesignator, this.txtIA, this.txtCountry)
        .subscribe((hasBC: boolean) => {
          this.basicCaseNotExists = !hasBC;
          this.newOkButtonDisabled = false;

          // begin Jira Card DSAMS-5426 AKP 05/2022
          // Call the database and display message if another version of case is in development status.          
          if (!this.basicCaseNotExists) {
            this.caseRestService
              .isAnotherVersionOfCaseInDevelopmentStatus(this.txtCaseDesignator, this.txtIA, this.txtCountry)
              .subscribe((inDev: boolean) => {
                this.anotherVersionOfCaseInDevelopmentExists = inDev;
                this.newOkButtonDisabled = false; // OK button should be enabled so user can continue.
              },
                err => {
                  CaseUtils.ReportHTTPError(err, "Unable to check for development status of case version.");
                  this.newOkButtonDisabled = false;
                }
              );
          }
          else {
            this.newOkButtonDisabled = true;  // OK button should be disabled for basic case error.
          }
          // end Jira Card DSAMS-5426 AKP 05/2022

        },
          err => {
            CaseUtils.ReportHTTPError(err, "Unable to check for basic case.");
            this.newOkButtonDisabled = false;
          }
        );
    }
  }


  /* --------------------------------------------------------------------------
    This procedure shows or hides the main Case Detail panel 
  ----------------------------------------------------------------------------- */
  newOkPanelButtonClick() {
    var errorMsg: string = this.checkMandatoryFields();
    if (this._skipValidationCheck) errorMsg = ''

    // Check if case designator is valid;
    if (errorMsg == '' &&
      !this.caseDesignatorCdAlreadyTaken &&
      !this.customerRequestInvalid &&
      !this.basicCaseNotExists) {
      //Jira DSAMS-5341 DH 04/22 - set up common attributes for new case
      this.prepareCommonAttributesForNewCase();

      //Jira DSAMS-5282 DH 03/22  - make call to create new case version document
      if (CaseUtils.isAmendCaseVersion(this.txtVersionTypeCd) ||
        CaseUtils.isModCaseVersion(this.txtVersionTypeCd)  ||  CaseUtils.isRevisionCaseVersion(this.txtVersionTypeCd)) {
        this.showSpinner.next(true);
        this.caseUIService.theComponentSaveState[CaseUIService.SAVE_CASE_DETAILS_STATE].isDataChanged = true;
        this.createNewCaseVersionDocument();
      }
      else {
        this.getCaseDetailFromLegacyNew();
        // Blank out case ID fields.
        this.CaseId = 0;
        this.CaseVersionId = 0;
      }
    }
  }

  //begin Jira DSAMS-5341 DH 04/22 - set up common attributes for new case
  prepareCommonAttributesForNewCase() {
    this.setCaseNewOkButtonColor();
    this.showNewCase = false;
    this.showSearchCase = false;
    this.showCaseDetails = false;
    this.displaySearch = false;
    this.ngOnInitPrc();
    this.setNewDefaultDislayValues();
    this.displayPanels = true;
    // Get the case header information.
    this.initializeCaseHeaderData();
    // Collapse all but the first panel for new cases.
    this.panelOpenState1 = true;
    this.panelOpenState2 = false;
    this.panelOpenState3 = false;
    this.panelOpenState4 = false;
    this.panelOpenState5 = false;
    this.panelOpenState6 = false;
    this.panelOpenState7 = false;
    this.panelOpenState8 = false;

    // Set to true (new mode)
    this.caseUIService.caseNewService.next(
      {
        ID: DsamsConstants.CASE_VERSION_EDITOR,
        editToggle: true
      }
    );
    // Set New Case variable to false
    this.dataSharingService.caseEnter.next(false);
    // Set Case Search variable to false
    this.dataSharingService.caseSearch.next(false);
    // Set Case Details variable to false
    this.dataSharingService.caseDetails.next(false);
    // This is needed for now to hide the New Case or Case Search panel after clicking Ok on New Menu
    this.showNewCase = false;
    this.showSearchCase = false;
    this.showCaseDetails = false;
    // Request Close Menu
    this.dataSharingService.caseSelection.next(DsamsConstants.REQUEST_CLOSE_MENU);
    // Set case breadcrumb 
    this.caseUIService.breadcrumbTitleChangeRequest.next("Enter New Case");
    this.canSaveCaseDetail = true;
    this.notifyPanelsInitiallyExpanded();
  }

  //populate new Amend/Mod data
  getCaseDetailsDataForNewAmendOrMod(pCaseDetailData: ICaseVersion) {
    const caseRequestParamsType: CaseRequestParamsType = {
      caseId: pCaseDetailData.case_ID,
      caseVersionId: pCaseDetailData.case_VERSION_ID,
      securityAssistanceProgramCd: this.txtSAProgram,
      customerOrganizationId: '',
      caseVersionTypeCd: pCaseDetailData.case_VERSION_TYPE_CD,
      implementingAgencyId: '',
      customerRequestId: 0,
    }
    //clear detail search values
    this.resetCaseDetailPanel();
    this.resetFormValues();
    this.caseRelatedInfoData = {
      case_ID: pCaseDetailData.case_ID,
      working_CASE_VERSION_ID: pCaseDetailData.case_VERSION_ID,
    }
    this.caseLineRelatedInfoData = {
      case_ID: pCaseDetailData.case_ID,
      case_VERSION_TYPE_CD: pCaseDetailData.case_VERSION_TYPE_CD,
      user_CASE_ID: CaseUtils.formatUserCaseId(this.txtCountryForHeader + this.txtIAForHeader + this.txtSearchCaseDesignatorForHeader),
      customer_REQUEST_ID: 0,
    }
    //emitting updated case info data 
    this.caseUIService.setCaseRelatedInfoValues(this.caseRelatedInfoData);
    this.caseUIService.setCaseLineRelatedInfoValues(this.caseLineRelatedInfoData);
    // Notify the subscribers of case detail selection.
    this.isNewAmendOrMod = true;
    this.caseUIService.caseDetailSelected.next(caseRequestParamsType);
    this.canSaveCaseDetail = true;
  }
  //end Jira DSAMS-5341 DH 04/22

  intervalForSpinner: any;
  takeDownSpinner() {
    this.intervalForSpinner = setInterval(() => {
      this.showSpinner.next(false);
      clearInterval(this.intervalForSpinner);
    }, 30000);
  }

  //begin Jira DSAMS-5282 DH 03/22  - make call to create new case version document
  //Handle sequential http request subscriptions
  setNewCaseVersionDoc(pCaseId: number) {
    var aCaseDetailData: ICaseVersion = {};
    aCaseDetailData.case_ID = pCaseId;
    aCaseDetailData.customer_REQUEST_ID = CaseUtils.isNumeric(this.txtCustReqForCD) ? parseInt(this.txtCustReqForCD) : 0;
    aCaseDetailData.case_VERSION_TYPE_CD = this.txtVersionTypeCd;
    this.showSpinner.next(true);
    this.caseRestService.createNewCaseVersionDoc(aCaseDetailData).pipe(
      tap(result => { console.log('aCaseDetailData', result); }))
      .subscribe(
        result => {
          aCaseDetailData = result;
          if (!!aCaseDetailData.messageList && aCaseDetailData.messageList.length > 0) {
            this.messageService.displayMessageListTc("Create Case Version", aCaseDetailData.messageList)
              .pipe(take(1)).subscribe();
          }
          else this.getCaseDetailsDataForNewAmendOrMod(aCaseDetailData);
          this.takeDownSpinner();
        },
        err => {
          this.showSpinner.next(false);
          CaseUtils.ReportHTTPError(err, "creating new case version document.");
        }
      );
    this.takeDownSpinner();
    return of(aCaseDetailData);
  }

  //Make call to legacy function to generate new case version document
  createNewCaseVersionDocument() {
    //this.caseRestService.getCaseId(this.txtCountryForHeader + this.txtIAForHeader + this.txtSearchCaseDesignatorForHeader)
    this.caseRestService.getCaseIdForUserCaseId(this.txtCountryForHeader + this.txtIAForHeader + this.txtSearchCaseDesignatorForHeader,
      this.txtSAProgram, this.txtDoc, this.txtVersionTypeCd)
      .pipe(concatMap((aCaseId) => {
        return (this.setNewCaseVersionDoc(aCaseId))
      }))
      .subscribe(
        () => { console.log() },
        err => {
          console.log(err);
          this.showSpinner.next(false);
          CaseUtils.ReportHTTPError(err, "getting case id.");
        });
  }
  //end Jira DSAMS-5282 DH 03/22 

  searchOKPanelButtonClick() {
    // Correctly set parameters
    if (!this.caseSearchFlag) {
      this.caseSearchData.security_ASSISTANCE_PROGRAM_CD1 = "";
      this.caseSearchData.case_USAGE_INDICATOR_CD1 = "";
    }

    this.showSearchCase = false;
    this.showNewCase = false;
    this.showCaseDetails = false;
    this.displayPanels = false;
    this.displayUnderscontruction = false;
    this.displaySearch = true;

    //Show search Parameters in the console
    //console.log(this.caseSearchData);

    this.saveCaseSearchArray();

    this.submitSearch();

    // this.pageLength = 25;
    // this.pageCount = 0;
    // this.pageOptions = [25,50,75,100];
    // this.pageSizeOptions = [25,50,75,100];
    // this.pageSize = 25;
    // this.pageIndex = 0;

    // console.log(
    //           "this.pageSize = " + this.pageSize +
    //           " this.pageCount = " + this.pageIndex +
    //           " this.length = " + this.length +
    //           " this.pageSizeOptions = " + this.pageSizeOptions +
    //           " this.pageLength: " + this.pageLength +
    //           " this.pageCount: " + this.pageCount +
    //           " this.recordLength: " + this.recordLength +
    //           " this.pageOptions: " + this.pageOptions
    //         );

    this.ngOnInitPrc();
    this.ngAfterViewInit();

    this.initializeCaseHeaderData();

    // Set Case Search variable to false
    this.dataSharingService.caseSearch.next(false);
    this.dataSharingService.backToSearchSummary.next(false);

    // Set Case Enter variable to false
    this.dataSharingService.caseEnter.next(false);

    // This is needed for now to hide the Case Search or
    // Case Enter panel after clicking Ok on New Menu
    this.showSearchCase = false;
    this.showNewCase = false;
    this.showCaseDetails = false;

    // Request Close Menu
    this.dataSharingService.caseSelection.next(DsamsConstants.REQUEST_CLOSE_MENU);


  }

  /**
   * If the user clicks backsapce on the case manager.
   * Clear out the field.
   */
  doBackspaceCM() {
    this.txtSearchCaseManager = "";
    this.caseSearchData.case_MANAGER_ID = 0;
  }

  resetCaseDesignatorControlOnClick() {
    //if (this.performCaseDesignatorMandatoryFieldVal() != undefined) {
    this.caseDesignatorFormControl.reset();
    this.caseDesignatorFormControl.setValidators([Validators.required, Validators.minLength(3),
    Validators.pattern(/^[A-z0-9]*$/)]);
    this.caseDesignatorFormControl.updateValueAndValidity();
    //}
  }

  resetCaseControlOnClick() {
    this.caseFormControl.reset();
    this.caseFormControl.setValidators([Validators.required, Validators.minLength(6),
    Validators.pattern(/^[A-z0-9]*$/)]);
    this.caseFormControl.updateValueAndValidity();
  }

  resetFieldsValidation() {
    this.resetCaseDesignatorControlOnClick();
    this.resetCaseControlOnClick();
    //reset  validation araray
    this.initializeValidationArray();
    this.caseDesignatorCdAlreadyTaken = false;
    this.basicCaseNotExists = false;
    this.anotherVersionOfCaseInDevelopmentExists = false; // Jira Card DSAMS-5426 AKP 05/2022
    this.customerRequestInvalid = false;
    //Reset option flags
    this.caseUIService.resetOptionFlags(DsamsConstants.PAGE_CASE_DETAIL);
  }


  // Set the style of the searcn/new slide drawers according to if the popout menu was closed.
  getNewCaseDrawerStyle(): string {
    return (this.requestCloseMenuProcessed ? "col-sm-6 col-xl-4" : "col-sm-12 col-md-10 col-lg-6 col-xl-5") + " sideNewDrawer z-depth-1";
  }

  getSearchCaseDrawerStyle(): string {
    return (this.requestCloseMenuProcessed ? "col-sm-6 col-xl-4" : "col-sm-12 col-md-10 col-lg-6 col-xl-5") + " sideSearchDrawer z-depth-1";
  }


  /* --------------------------------------------------------------------------
  This function sets the text decription of the Expand/Collapse button 
  respectively to their panel open or close status 
  ----------------------------------------------------------------------------- */
  changeExpandCollapseBtnAction() {
    if (this.expandPanelBtnBehavior === caseConstants.collapseAll) {
      this.expandPanelBtnBehavior = caseConstants.expandAll;
      this.panelOpenState1 = false;
      this.panelOpenState2 = false;
      this.panelOpenState3 = false;
      this.panelOpenState4 = false;
      this.panelOpenState5 = false;
      this.panelOpenState6 = false;
      this.panelOpenState7 = false;
      this.panelOpenState8 = false;
      this.notifyPanel(DsamsConstants.CASE_PANEL_ALL, false, false);
      this.resetAllButtonColors();
    } else {
      this.notifyPanel(DsamsConstants.CASE_PANEL_ALL, true, false);
      this.expandPanelBtnBehavior = caseConstants.collapseAll;
      this.panelOpenState1 = true;
      this.panelOpenState2 = true;
      this.panelOpenState3 = true;
      this.panelOpenState4 = true;
      this.panelOpenState5 = true;
      this.panelOpenState6 = true;
      this.panelOpenState7 = true;
      this.panelOpenState8 = true;
      this.highlightAllButtonColors();
    }
  }

  /* --------------------------------------------------------------------------
   This function changes the text decription of the Expand/Collapse button 
   respectively to their panels when either all panels are in the open or close status 
   ----------------------------------------------------------------------------- */
  verifyAllExpandBtnStates() {
    if (this.panelOpenState1 === false &&
      this.panelOpenState2 === false &&
      this.panelOpenState3 === false &&
      this.panelOpenState4 === false &&
      this.panelOpenState5 === false &&
      this.panelOpenState6 === false &&
      this.panelOpenState7 === false &&
      this.panelOpenState8 === false) {
      this.expandPanelBtnBehavior = caseConstants.expandAll;
    } else {
      if (this.panelOpenState1 === true &&
        this.panelOpenState2 === true &&
        this.panelOpenState3 === true &&
        this.panelOpenState4 === true &&
        this.panelOpenState5 === true &&
        this.panelOpenState6 === true &&
        this.panelOpenState7 === true &&
        this.panelOpenState8 === true) {
        this.expandPanelBtnBehavior = caseConstants.collapseAll;
      }
    }
  }

  /* --------------------------------------------------------------------------
   This function toggles the button colors according to what's open and closed.
   ----------------------------------------------------------------------------- */
  private setButtonColorAccordingToWhatsOpenOrClosed(pElementId: string, pDefaultEverything: boolean) {
    if (pDefaultEverything) {
      this.caseInfoBgBtnColor = caseConstants.highlightedBtnColor;
      this.outlineBtnColor = caseConstants.outlineClickBtnColor;
      this.boldCaseBtnFont = caseConstants.fontBold;
      this.customerBgBtnColor = caseConstants.initalButtonBgColor;
      this.outlineBtnColor = caseConstants.outlineUnClickBtnColor;
      this.boldCustBtnFont = "";
      this.documentBgBtnColor = caseConstants.initalButtonBgColor;
      this.outlineBtnColor = caseConstants.outlineUnClickBtnColor;
      this.boldDocBtnFont = "";
      this.descriptionBgBtnColor = caseConstants.initalButtonBgColor;
      this.outlineBtnColor = caseConstants.outlineUnClickBtnColor;
      this.boldDescBtnFont = "";
      this.signatoriesBgBtnColor = caseConstants.initalButtonBgColor;
      this.outlineBtnColor = caseConstants.outlineUnClickBtnColor;
      this.boldSignatoryBtnFont = "";
      this.associationBgBtnColor = caseConstants.initalButtonBgColor;
      this.outlineBtnColor = caseConstants.outlineUnClickBtnColor;
      this.boldAssocBtnFont = "";
      this.waiversBgBtnColor = caseConstants.initalButtonBgColor;
      this.outlineBtnColor = caseConstants.outlineUnClickBtnColor;
      this.boldWaiverBtnFont = "";
      this.modfundBgBtnColor = caseConstants.initalButtonBgColor;
      this.outlineBtnColor = caseConstants.outlineUnClickBtnColor;
      this.boldModfundBtnFont = "";
    }
    else {
      // Find out the panel expanded by the last digits and mod it by 8.
      let elementId: string = pElementId;
      const lastDashPos = elementId.lastIndexOf("-");
      if (lastDashPos != -1) {
        const panelNum: number = +elementId.substring(lastDashPos + 1);
        switch (panelNum % 8) {
          case 1: elementId = "caseInfoPanel"; break;
          case 2: elementId = "custRequestPanel"; break;
          case 3: elementId = "documentPanel"; break;
          case 4: elementId = "descriptionPanel"; break;
          case 5: elementId = "signatoriesPanel"; break;
          case 6: elementId = "associationPanel"; break;
          case 7: elementId = "waiversPanel"; break;
          default: elementId = "";
        }

      }

      switch (elementId) {
        case "caseInfoPanel":
        case "mat-expansion-panel-header-1": {
          if (this.caseInfoBgBtnColor === caseConstants.initalButtonBgColor) {
            this.caseInfoBgBtnColor = caseConstants.highlightedBtnColor;
            this.outlineBtnColor = caseConstants.outlineClickBtnColor;
            this.boldCaseBtnFont = caseConstants.fontBold;
          }
          else {
            this.caseInfoBgBtnColor = caseConstants.initalButtonBgColor;
            this.outlineBtnColor = caseConstants.outlineUnClickBtnColor;
            this.boldCaseBtnFont = "";
          }
          break;
        }
        case "custRequestPanel":
        case "mat-expansion-panel-header-2": {
          if (this.customerBgBtnColor === caseConstants.initalButtonBgColor) {
            this.customerBgBtnColor = caseConstants.highlightedBtnColor;
            this.outlineBtnColor = caseConstants.outlineClickBtnColor;
            this.boldCustBtnFont = caseConstants.fontBold;
          }
          else {
            this.customerBgBtnColor = caseConstants.initalButtonBgColor;
            this.outlineBtnColor = caseConstants.outlineUnClickBtnColor;
            this.boldCustBtnFont = "";
          }
          break;
        }
        case "documentPanel":
        case "mat-expansion-panel-header-3": {
          if (this.documentBgBtnColor === caseConstants.initalButtonBgColor) {
            this.documentBgBtnColor = caseConstants.highlightedBtnColor;
            this.outlineBtnColor = caseConstants.outlineClickBtnColor;
            this.boldDocBtnFont = caseConstants.fontBold;
          } else {
            this.documentBgBtnColor = caseConstants.initalButtonBgColor;
            this.outlineBtnColor = caseConstants.outlineUnClickBtnColor;
            this.boldDocBtnFont = "";
          }
          break;
        }
        case "descriptionPanel":
        case "mat-expansion-panel-header-4": {
          if (this.descriptionBgBtnColor === caseConstants.initalButtonBgColor) {
            this.descriptionBgBtnColor = caseConstants.highlightedBtnColor;
            this.outlineBtnColor = caseConstants.outlineClickBtnColor;
            this.boldDescBtnFont = caseConstants.fontBold;
          } else {
            this.descriptionBgBtnColor = caseConstants.initalButtonBgColor;
            this.outlineBtnColor = caseConstants.outlineUnClickBtnColor;
            this.boldDescBtnFont = "";
          }
          break;
        }
        case "signatoriesPanel":
        case "mat-expansion-panel-header-5": {
          if (this.signatoriesBgBtnColor === caseConstants.initalButtonBgColor) {
            this.signatoriesBgBtnColor = caseConstants.highlightedBtnColor;
            this.boldSignatoryBtnFont = caseConstants.fontBold;
            this.outlineBtnColor = caseConstants.outlineClickBtnColor;
          } else {
            this.signatoriesBgBtnColor = caseConstants.initalButtonBgColor;
            this.outlineBtnColor = caseConstants.outlineUnClickBtnColor;
            this.boldSignatoryBtnFont = "";
          }
          break;
        }
        case "associationPanel":
        case "mat-expansion-panel-header-6": {
          if (this.associationBgBtnColor === caseConstants.initalButtonBgColor) {
            this.associationBgBtnColor = caseConstants.highlightedBtnColor;
            this.outlineBtnColor = caseConstants.outlineClickBtnColor;
            this.boldAssocBtnFont = caseConstants.fontBold;
          } else {
            this.associationBgBtnColor = caseConstants.initalButtonBgColor;
            this.outlineBtnColor = caseConstants.outlineUnClickBtnColor;
            this.boldAssocBtnFont = "";
          }
          break;
        }
        case "waiversPanel":
        case "mat-expansion-panel-header-7": {
          if (this.waiversBgBtnColor === caseConstants.initalButtonBgColor) {
            this.waiversBgBtnColor = caseConstants.highlightedBtnColor;
            this.outlineBtnColor = caseConstants.outlineClickBtnColor;
            this.boldWaiverBtnFont = caseConstants.fontBold;
          } else {
            this.waiversBgBtnColor = caseConstants.initalButtonBgColor;
            this.outlineBtnColor = caseConstants.outlineUnClickBtnColor;
            this.boldWaiverBtnFont = "";
          }
          break;
        }
        case "modfundPanel":
        case "mat-expansion-panel-header-8": {
          if (this.modfundBgBtnColor === caseConstants.initalButtonBgColor) {
            this.modfundBgBtnColor = caseConstants.highlightedBtnColor;
            this.outlineBtnColor = caseConstants.outlineClickBtnColor;
            this.boldModfundBtnFont = caseConstants.fontBold;
          } else {
            this.modfundBgBtnColor = caseConstants.initalButtonBgColor;
            this.outlineBtnColor = caseConstants.outlineUnClickBtnColor;
            this.boldModfundBtnFont = "";
          }
          break;
        }
      }
    }
  }


  /* --------------------------------------------------------------------------
   This function changes the background color of the panel buttons 
   ----------------------------------------------------------------------------- */
  setButtonColorPanel(event: Event) {
    this.verifyAllExpandBtnStates();
    let elementId: string = (event.currentTarget as Element).id;
    this.setButtonColorAccordingToWhatsOpenOrClosed(elementId, false);
    AuthUtils.refreshULA();    // Keep the session going.
  }

  /* --------------------------------------------------------------------------
     This function resets the background color of all panel buttons to the 
     initial color
     ----------------------------------------------------------------------------- */
  resetAllButtonColors() {
    this.caseInfoBgBtnColor = caseConstants.initalButtonBgColor;
    this.customerBgBtnColor = caseConstants.initalButtonBgColor;
    this.waiversBgBtnColor = caseConstants.initalButtonBgColor;
    this.modfundBgBtnColor = caseConstants.initalButtonBgColor;
    this.associationBgBtnColor = caseConstants.initalButtonBgColor;
    this.signatoriesBgBtnColor = caseConstants.initalButtonBgColor;
    this.descriptionBgBtnColor = caseConstants.initalButtonBgColor;
    this.documentBgBtnColor = caseConstants.initalButtonBgColor;
    this.boldDocBtnFont = "";
    this.boldDescBtnFont = "";
    this.boldWaiverBtnFont = "";
    this.boldModfundBtnFont = "";
    this.boldAssocBtnFont = "";
    this.boldSignatoryBtnFont = "";
    this.boldCaseBtnFont = "";
    this.boldCustBtnFont = "";
  }
  /* --------------------------------------------------------------------------
     This function resets the background color of all panel buttons to the 
     active color
     ----------------------------------------------------------------------------- */
  highlightAllButtonColors() {
    this.caseInfoBgBtnColor = caseConstants.highlightedBtnColor;
    this.customerBgBtnColor = caseConstants.highlightedBtnColor;
    this.waiversBgBtnColor = caseConstants.highlightedBtnColor;
    this.modfundBgBtnColor = caseConstants.highlightedBtnColor;
    this.associationBgBtnColor = caseConstants.highlightedBtnColor;
    this.signatoriesBgBtnColor = caseConstants.highlightedBtnColor;
    this.descriptionBgBtnColor = caseConstants.highlightedBtnColor;
    this.documentBgBtnColor = caseConstants.highlightedBtnColor;
    this.boldDocBtnFont = caseConstants.fontBold;
    this.boldDescBtnFont = caseConstants.fontBold;
    this.boldWaiverBtnFont = caseConstants.fontBold;
    this.boldModfundBtnFont = caseConstants.fontBold;
    this.boldAssocBtnFont = caseConstants.fontBold;
    this.boldSignatoryBtnFont = caseConstants.fontBold;
    this.boldCaseBtnFont = caseConstants.fontBold;
    this.boldCustBtnFont = caseConstants.fontBold;
  }

  scrollPanelIntoView(HTMLElment: Element) {
    HTMLElment.scrollIntoView({ behavior: "smooth" });
  }

  // ******************* Reset Case Search Object ********************

  resetCaseSearchArray() {
    // Default CaseSearchData
    this.caseSearchData = {
      searchByUserCaseId: this.caseSearchFlag,
      searchByCasePopup: false,
      security_ASSISTANCE_PROGRAM_CD1: "FMS",
      user_CASE_ID: "",
      security_ASSISTANCE_PROGRAM_CD2: "FMS",
      case_USAGE_INDICATOR_CD1: "C",
      case_USAGE_INDICATOR_CD2: "C",
      customer_ORGANIZATION_ID: "",
      implementing_AGENCY_ID: "",
      case_DESIGNATOR: "",
      case_MASTER_STATUS_CD: "",
      case_VERSION_STATUS_CD: "",
      case_VERSION_TYPE_CD: "",
      activity_ID: "",
      case_NICKNAME_NM: "",
      case_MANAGER_ID: 0,
      case_MANAGER_USERNAME: "",
      case_VERSION_NUMBER_ID: "",
      user_ID: 0,
      resultFormatParams: {
        showAllRows: true,
        minRow: 1,
        maxRow: DsamsConstants.DEFAULT_MAX_RECORDS,
        sortColumns: ["user_case_id"]
      }
    };
  }

  saveCaseSearchArray() {
    this.oldCaseSearchData = {
      searchByUserCaseId: this.caseSearchFlag,
      searchByCasePopup: false,
      security_ASSISTANCE_PROGRAM_CD1: this.caseSearchData.security_ASSISTANCE_PROGRAM_CD1,
      user_CASE_ID: this.caseSearchData.user_CASE_ID,
      security_ASSISTANCE_PROGRAM_CD2: this.caseSearchData.security_ASSISTANCE_PROGRAM_CD2,
      case_USAGE_INDICATOR_CD1: this.caseSearchData.case_USAGE_INDICATOR_CD1,
      case_USAGE_INDICATOR_CD2: this.caseSearchData.case_USAGE_INDICATOR_CD2,
      customer_ORGANIZATION_ID: this.caseSearchData.customer_ORGANIZATION_ID,
      implementing_AGENCY_ID: this.caseSearchData.implementing_AGENCY_ID,
      case_DESIGNATOR: this.caseSearchData.case_DESIGNATOR,
      case_MASTER_STATUS_CD: this.caseSearchData.case_MASTER_STATUS_CD,
      case_VERSION_STATUS_CD: this.caseSearchData.case_VERSION_STATUS_CD,
      case_VERSION_TYPE_CD: this.caseSearchData.case_VERSION_TYPE_CD,
      activity_ID: this.caseSearchData.activity_ID,
      case_NICKNAME_NM: this.caseSearchData.case_NICKNAME_NM,
      case_MANAGER_ID: this.caseSearchData.case_MANAGER_ID,
      case_MANAGER_USERNAME: this.caseSearchData.case_MANAGER_USERNAME,
      case_VERSION_NUMBER_ID: this.caseSearchData.case_VERSION_NUMBER_ID,
      user_ID: this.caseSearchData.user_ID,
      resultFormatParams: {
        showAllRows: false,
        minRow: this.caseSearchData.resultFormatParams.minRow,
        maxRow: this.caseSearchData.resultFormatParams.maxRow,
        sortColumns: ["user_case_id"]
      }
    }
  }

  // ************************ Reset Error Icons **************************

  private resetErrorIcons() {
    const resetToLvl: number = this.MsgTypeNull;
    this.errorLevelCaseInfo = resetToLvl;
    this.errorLevelCustReq = resetToLvl;
    this.errorLevelDocReq = resetToLvl;
    this.errorLevelDesc = resetToLvl;
    this.errorLevelSignatories = resetToLvl;
    this.errorLevelAssociations = resetToLvl;
    this.errorLevelWaivers = resetToLvl;
    this.errorLevelModfunding = resetToLvl;
  }

  /**
  * Blank out the case header fields when the user clicks new or search.
  */
  initializeCaseHeaderData() {
    this.caseHeaderData["case_STATUS_TITLE_NM"] = "";
    this.caseHeaderData["case_VERSION_TYPE_NM"] = "";
    this.caseHeaderData["version_STATUS_TITLE_NM"] = "";
    this.caseHeaderData["document_INITIALIZATION_DT"] = "";
    this.caseHeaderData["security_ASSISTANCE_PROGRAM_CD"] = "";
    this.caseHeaderData["case_USAGE_INDICATOR_CD"] = "";
    this.caseHeaderData["case_VERSION_NUMBER_ID"] = "";
    this.caseHeaderData["user_CASE_ID"] = "";
  }

  // *********************************************************************
  // ******************* REST service calls ****************************** 
  // *********************************************************************

  // ********** Get user info (again) for case because we need to store the user_id for case queries ***********

  getCaseUserInfo() {
    this.caseRestService
      .getCaseUserInfo()
      .subscribe(
        data => {
          sessionStorage.setItem('userId', data.userProfile.userId);
        },
        err => {
          CaseUtils.ReportHTTPError(err, "Getting CaseUserInfo");
        }
      )
  }

  //begin DSAMS-5754 07/22 DH
  constructRefCommonListObject(): CommonReferenceData {
    return (
      {
        refName: [DsamsConstants.REF_SECURITY_ASSISTANCE_PROGRAM, DsamsConstants.REF_CASE_USAGE_INDICATOR,
        DsamsConstants.REF_CUSTOMER_ORGANIZATION,
        DsamsConstants.REF_CASE_VERSION_TYPE, DsamsConstants.REF_CASE_VERSION_STATUS,
        DsamsConstants.REF_IMPLEMENTING_AGENCY,
        DsamsConstants.REF_CASE_MASTER_STATUS, DsamsConstants.REF_CASE_USAGE_INDICATOR],
        defaultValue: [DsamsConstants.DEFAULT_SECURITY_ASSISTANCE_PROGRAM,
        DsamsConstants.DEFAULT_CASE_USAGE_INDICATOR,
          "", "", "", "", "",
        DsamsConstants.DEFAULT_CASE_USAGE_INDICATOR],
        sortFieldNum: [0, 0, 0, 0, 0, 0, 0, 0, 0],
        allowNull: [false, false, true, false, true, true, true, false],
        showInactive: [false, false, false, false, false, false, false, false],
        extraInfo: [null, null, null, null, null, null, null, null],
        ruleSet: [1, 1, 1, 1, 1, 1, 1, 2]
      });
  }

  setupRefCaseVersionTypeList() {
    // Apply to basic and AMR version of this list.
    this.refCaseVersionTypeListBasic = [];
    this.refCaseVersionTypeListAMR = [];
    this.refCaseVersionTypeListFull = [];
    for (let i = 0; i < this.refCaseVersionTypeList.length; i++) {
      this.refCaseVersionTypeListFull.push(this.refCaseVersionTypeList[i]);
      if (i == 0) {
        this.refCaseVersionTypeListBasic.push(this.refCaseVersionTypeList[i]);
      }
      else {
        this.refCaseVersionTypeListAMR.push(this.refCaseVersionTypeList[i]);
      }
    }
  }

  getAllReferenceDataCommon() {
    let theRefListParam = this.constructRefCommonListObject();
    if (this.refSAProgramList == null || this.refSAProgramList.length == 0) {
      this.caseRestService.getAllCaseDetailsRefData(theRefListParam.refName,
        theRefListParam.defaultValue,
        theRefListParam.sortFieldNum,
        theRefListParam.allowNull,
        theRefListParam.showInactive,
        theRefListParam.extraInfo,
        theRefListParam.ruleSet)
        .subscribe(
          data => {
            let index = 0;
            this.refSAProgramList = data[index++];
            this.refDocumentTypeListNew = data[index++];
            this.refCustomerOrganizationList = data[index++];
            this.refCaseVersionTypeList = data[index++];
            this.refCaseVersionStatusList = data[index++];
            this.refImplementingAgencyList = data[index++];
            this.refCaseMasterStatusList = data[index++];
            this.refDocumentTypeListExisting = data[index];
            this.setupRefCaseVersionTypeList();
            CaseUtils.theRefCustomerOrganizationList = this.refCustomerOrganizationList;
            CaseUtils.theRefCaseUsageIndList = this.refDocumentTypeListNew;
            //Jira card 5975 - SA program does not show GRANT, LEASE, or MAP  
            this.refSAProgramList = this.refSAProgramList.filter(includeValue=> includeValue.key_FIELD == "FMS" );
          },
          err => {
            this.showSpinner.next(false);
            CaseUtils.ReportHTTPError(err, caseConstants.REFERENCE_ERROR_HEADER_STR + "for Case Details");
          }
        );
    }
  }
  //end DSAMS-5754 07/22 DH

  // Subscribe to the Case Search Params type and open panels/populate data when its next-d.
  subscribeToDataRequest() {
    if (!this._caseDetailSelectedSubscription) {
      this._caseDetailSelectedSubscription =
        this.caseUIService
          .caseDetailSelected
          .subscribe(requestData => {
            if (!!requestData) {
              const caseRequestParms: CaseRequestParamsType = requestData;
              this.notifyCaseDetailScreen(caseRequestParms);
              this.displaySearch = false;
              this.caseUIService.theComponentSaveState[CaseUIService.SAVE_CASE_DETAILS_STATE] = {
                isSaveConfirmed: new BehaviorSubject<boolean>(false), isDataChanged: false,
              };
              this.subscribeToSaveOnEditToggle();
            }
          },
            _err => {
              this.showSpinner.next(false);
              CaseUtils.ReporError("Error in CaseUIService.CaseDetailSelected on Dashboard");
            }
          );
    }
  }

  // begin Jira Card DSAMS-5689 06/2022 AKP
  // subscribe to Save-InViewMode-when-optionMenu-selected subscription to enable/disable save button    
  subscribeToSaveInViewModeWhenOptionsMenuSelected() {

    if (!this._saveInViewModeSubscription) {
      this._saveInViewModeSubscription = this.caseUIService
        .saveInViewModeWhenOptionsMenuSelected
        .subscribe(canISaveInView => {
          setTimeout(() => {

            console.log("canISaveInView==" + canISaveInView);

            if (canISaveInView) {
              this.saveButtonColor = caseConstants.initialSaveButtonColor;
              this.canSaveCaseDetail = true;

              console.log("-->canSaveCaseDetail1==" + this.canSaveCaseDetail);
            }
            else {
              if (!this._panelExpansionProperties.isNewMode) {
                this.saveButtonColor = "grey";
                this.canSaveCaseDetail = false;

                console.log("-->this._panelExpansionProperties.isNewMode==" + this._panelExpansionProperties.isNewMode);
              }
            }
          }, 0);
        },
          _err => {
            CaseUtils.ReporError("Error in caseUIService.saveInViewMode on Dashboard");
          }
        );
    }
  }
  // end Jira Card DSAMS-5689 06/2022 AKP

  // Subscribe to the can-save subsciption for enabling/disabling save.
  subscribeToCanSave() {
    if (!this._canSaveSubscription) {
      this._canSaveSubscription = this.caseUIService
        .canSave
        .subscribe(canISave => {
          setTimeout(() => {

            canISave = this.canSaveCaseDetail;
            if (canISave) {
              this.saveButtonColor = caseConstants.initialSaveButtonColor;

            }
            else {
              this.saveButtonColor = "grey";

            }
          }, 0);
        },
          _err => {
            CaseUtils.ReporError("Error in caseUIService.canSave on Dashboard");
          }
        );
    }
  }


  /**
   * Subscribe back to case search to ensure that case search re-appears and detail link works.
   */
  subscribeToBackToCaseSearch() {
    if (this._backToCaseSearchSubscription == null) {
      this._backToCaseSearchSubscription = this.caseUIService.getbackToCaseSearchSummaryValue().subscribe((value) => {
        if (value) {
          this.backToSearch = true;
          if (this.caseDetailsBC === false) {
            this.displaySearch = true;
            this.displayPanels = false;
            this.caseUIService.submitBreadcrumbTitleChangeRequest("ICase Search Summary");
          } else {
            this.displaySearch = false;
            this.displayPanels = false;
          }

        }
      },
        err => {
          CaseUtils.ReporError("Error in caseUIService.getbackToCaseSearchSummaryValue on Dashboard");
        });
    }
  }


  // Case Module Functions
  onSelectCaseEnterClose() {
    // User selected Case Enter Close(X)
    this.caseEnter = false;
    this.dataSharingService.caseEnter.next(false);
    //console.log("*** User selected Case Enter Close ***");
    //console.log("CaseEnter (Header) set to: " + this.caseEnter);
    this.dataSharingService.caseSelection.next(DsamsConstants.REQUEST_CLOSE_MENU);
  }

  onSelectCaseSearchClose() {
    // User selected Case Search Close(X)
    this.caseSearch = false;
    this.dataSharingService.caseSearch.next(false);
    this.dataSharingService.backToSearchSummary.next(false);
    //console.log("*** User selected Case Search Close ***");
    //console.log("CaseSearch (Header) set to: " + this.caseSearch);
    this.dataSharingService.caseSelection.next(DsamsConstants.REQUEST_CLOSE_MENU);
  }

  onSelectCaseDetailsClose() {
    // User selected Case Details Close(X)
    this.caseDetails = false;
    this.dataSharingService.caseDetails.next(false);
    //console.log("*** User selected Case Details Close ***");
    //console.log("CaseDetails (Header) set to: " + this.caseDetails);
    this.dataSharingService.caseSelection.next(DsamsConstants.REQUEST_CLOSE_MENU);
    this.txtSearchCaseDetailsCase = '';
    this.dropdownCaseVersions = [{ value: '', viewValue: '' }];
  }

  // Subscrive to the case enter subsciption.
  subscribeToCaseEnter() {
    if (this._caseEnterSubscription == null) {
      this._caseEnterSubscription = this.dataSharingService
        .caseEnter
        .subscribe(caseEnter => {
          this.caseEnter = caseEnter;
          //console.log("CaseEnter New Subscription (Case Dashboard) set to: " + caseEnter);
          if (this.caseEnter === true) {
            this.showNewCase = true;
            this.showSearchCase = false;
            this.showCaseDetails = false;
            this.showCaseDetailsLines = false;
            this.caseNewOkButtonColor = caseConstants.initalOkButtonColor;
            this.caseNewOkButtonFontColor = caseConstants.initialSaveButtonFontColor;
            // Set the text-entry fields (non-dropdowns) to their initial value.
            this.txtCaseDesignator = '';
            this.caseDesignatorFormControl.markAsUntouched();
            this.txtCustReq = '';
            this.txtCustReqForCD = '';
            this.customerRequestInvalid = false;
            this.txtSearchCaseManager = '';
            //console.log("CaseEnter condition on init : this.showNewCase" + this.showNewCase);
          }
        },
          err => {
            CaseUtils.ReporError("Error in dataSharingService.caseEnter on Dashboard");
          }
        );
    }
  }

  // Subscrive to the case search subsciption.
  subscribeToCaseSearch() {
    if (this._caseSearchSubscription == null) {
      this._caseSearchSubscription = this.dataSharingService
        .caseSearch
        .subscribe(caseSearch => {
          this.caseSearch = caseSearch;

          this.searchEnterCaseSelect();
          if (this.caseSearch === true) {
            this.caseUIService.submitBreadcrumbTitleChangeRequest("ICase Search Summary");
            this.showSearchCase = true;
            this.showNewCase = false;
            this.showCaseDetails = false;
            this.showCaseDetailsLines = false;
            this.displaySearch = false;
            this.displayPanels = false;
            this.caseSearchOkButtonColor = caseConstants.initalOkButtonColor;
            this.caseSearchOkButtonFontColor = caseConstants.initialSaveButtonFontColor;
            this.txtEnterCase = '';
            this.caseFormControl.markAsUntouched();
            this.txtSearchCaseDesignator = '';
            this.txtSearchNickname = '';
            this.txtSearchPrepareActivity = '';
            this.txtSearchDocNumber = '';
            this.txtSearchCaseManager = '';
            //  console.log("caseSearch condition on init : this.showSearchCase" + this.showSearchCase);
          }
        },
          err => {
            CaseUtils.ReporError("Error in dataSharingService.caseSearch on Dashboard");
          }
        );
    }
  }

  // Subscrive to the case search subsciption.
  subscribeToCaseDetails() {
    if (this._caseDetailsSubscription == null) {
      this._caseDetailsSubscription = this.dataSharingService
        .caseDetails
        .subscribe(caseDetails => {
          this.caseDetails = caseDetails;
          //this.searchEnterCaseSelect(); 
          //console.log("caseDetails New Subscription (Case Dashboard) set to: " + caseDetails);
          if (this.caseDetails === true) {
            this.showCaseDetails = true;
            this.showNewCase = false;
            this.showSearchCase = false;
            this.displaySearch = false;
            this.displayPanels = false;
            this.caseUIService.submitBreadcrumbTitleChangeRequest("Case Detail Search");
          }
        },
          err => {
            CaseUtils.ReporError("Error in dataSharingService.caseSearch on Dashboard");
          }
        );
    }
  }


  // Subscribe to the case selection subsciption.
  subscribeToCaseSelection() {
    if (this._caseSelectionSubscription == null) {
      this._caseSelectionSubscription = this.dataSharingService
        .caseSelection
        .subscribe(caseSelection => {
          this.caseSelection = caseSelection;
          if (caseSelection === DsamsConstants.REQUEST_CLOSE_MENU) {
            this.requestCloseMenuProcessed = true;
          }
          // console.log("CaseSelection New Subscription (Case Dashboard) set to: " + caseSelection);
        },
          err => {
            CaseUtils.ReporError("Error in dataSharingService.caseSelection on Dashboard");
          }
        );
    }
  }

  // Subscribe to the DSAMS service for activity textfield for popup selection.
  subscribeToPopupActivity() {
    if (this._popupActivitySubscription == null) {
      this._popupActivitySubscription = this.dsamsMethodsService
        .selectedActivityFromPopupValue
        .subscribe(value => {
          this.txtSearchPrepareActivity = value;
        },
          err => {
            CaseUtils.ReporError("Error in dsamsMethodsService.popupActivity");
          }
        );
    }
  }

  // Subscribe to the DSAMS service for person textfield for popup selection.
  subscribeToPopupPerson() {
    if (this._popupPersonSubscription == null) {
      this._popupPersonSubscription = this.dsamsMethodsService
        .selectedPersonFromPopupValue
        .subscribe((selectedVal: IPerson) => {
          if (!!selectedVal) {
            this.txtSearchCaseManager = selectedVal.person_NICKNAME_NM + " - " + selectedVal.person_LAST_NM + ", " + selectedVal.person_FIRST_NM;
            this.caseSearchData.case_MANAGER_ID = selectedVal.user_ID;
          }
        },
          err => {
            CaseUtils.ReporError("Error in dsamsMethodsService.popupPerson");
          }
        );
    }
  }

  // Subscribe to the DSAMS service for customer request  textfield for popup selection.
  subscribeToPopupCR() {
    if (this._popupCRSubscription == null) {
      this._popupCRSubscription = this.dsamsMethodsService
        .selectedCRFromPopupValue
        .subscribe((selectedVal: ICustomerRequest) => {
          if (!!selectedVal) {
            this.txtCustReq = selectedVal.customer_REQUEST_ID.toString();
            this.txtCustReqForCD = this.txtCustReq;
            this.txtCountry = selectedVal.customer_ORGANIZATION_ID;
            this.processCountryChange();
          }
        },
          err => {
            CaseUtils.ReporError("Error in dsamsMethodsService.popupPerson");
          }
        );
    }
  }

  // Subscribe to Save on Edit Toggle
  subscribeToSaveOnEditToggle() {
    if (!!this.saveOnEditToggleSubscription) {
      this.saveOnEditToggleSubscription.unsubscribe();
      this.saveOnEditToggleSubscription = null;
    }
    this.saveOnEditToggleSubscription = this.caseUIService.theComponentSaveState[CaseUIService.SAVE_CASE_DETAILS_STATE].isSaveConfirmed
      .subscribe(isSaveConfirmed => {
        if (isSaveConfirmed) {
          this.setSaveButtonColor(null);
        }
      });
  }

  /* When the user clicks the save button, the button color will change.  
      It will toggle back to the original after a second click. */
 // event begin DSAMS-5694 09/22 DB
 receivedPanelCI: boolean;
 receivedPanelCR: boolean;
 receivedPanelDR: boolean;
 receivedPanelDC: boolean;
 receivedPanelSG: boolean;
 receivedPanelAC: boolean;
 receivedPanelWV: boolean;
 receivedPanelMF: boolean;
 readyToShowMessages: boolean;
 doAppend: boolean;
 msgQueue: Array<any> = [];
 // end DSAMS-5694
  setSaveButtonColor(event: Event) {
   
 
      // Keep the button color as the initial one - no flipping back and forth.
      this.saveButtonColor = caseConstants.initialSaveButtonColor;
      this.saveButtonFontColor = caseConstants.initialSaveButtonFontColor;
  
      /* Set cancel button to original state */
      this.cancelButtonColor = caseConstants.initialCancelButtonColor;
  
      this.setPanelStateForSave(this.beforeSaveStr);
  
      this._cumulativeSaveResultsType = new SaveResultsType();
     // begin DSAMS-5694 09/22 DB
this.receivedPanelCI = false;
this.receivedPanelCR = false;
this.receivedPanelDR = false;
this.receivedPanelDC = false;
this.receivedPanelSG = false;
this.receivedPanelAC = false;
this.receivedPanelWV = false;
this.receivedPanelMF = false;
  this.readyToShowMessages = true;
this.msgQueue= [];
// end DSAMS-5694
      this.caseUIService.canSave.next(false);
  
      // Reset Option Flags
      this.caseUIService.resetOptionFlags(DsamsConstants.PAGE_CASE_DETAIL);
      // Set Flag counter back to zero
      this.caseUIService.optionSelectCounter.next(0);
  
      if (!!this._SRRSubscription) {
        this._SRRSubscription.unsubscribe();
        this._SRRSubscription = null;
      }
      
      if (!this._SRRSubscription) {
        this._SRRSubscription =
          this.caseUIService
            .saveReturnRequest
          .subscribe((returnResult: SaveResultsType) => {
 
              let doAppend: boolean = false;
  
              // Determine if we'vethis.received all the SRT-s we need to show the message on the UI.
              if (returnResult.currentPanel === DsamsConstants.CASE_PANEL_INFO) {
               this.receivedPanelCI = true;
                doAppend = true;
              }
              if (this.panelOpenState2 && returnResult.currentPanel === DsamsConstants.CASE_PANEL_CUSTOMER_REQUEST) {
               this.receivedPanelCR = true;
                doAppend = true;
              }
              if (this.panelOpenState3 && returnResult.currentPanel === DsamsConstants.CASE_PANEL_DOCUMENT_REQUIREMENTS) {
               this.receivedPanelDR = true;
                doAppend = true;
              }
              if (this.panelOpenState4 && returnResult.currentPanel === DsamsConstants.CASE_PANEL_DESCRIPTIONS) {
               this.receivedPanelDC = true;
                doAppend = true;
              }
              if (this.panelOpenState5 && returnResult.currentPanel === DsamsConstants.CASE_PANEL_SIGNATORIES) {
               this.receivedPanelSG = true;
                doAppend = true;
              }
              if (this.panelOpenState6 && returnResult.currentPanel === DsamsConstants.CASE_PANEL_ASSOCIATIONS) {
               this.receivedPanelAC = true;
                doAppend = true;
              }
              if (this.panelOpenState7 && returnResult.currentPanel === DsamsConstants.CASE_PANEL_WAIVERS) {
               this.receivedPanelWV = true;
                doAppend = true;
              }
              if (this.panelOpenState8 && returnResult.currentPanel === DsamsConstants.CASE_PANEL_MODFUNDING) {
                this.receivedPanelMF = true;
                 doAppend = true;
               }
   
               // For each SRT (SaveResultsType) that comes in for each panel, append that to the cumulative list.
               if (doAppend) {
                 this._cumulativeSaveResultsType.appendSRT(returnResult);
               }
   
              this.readyToShowMessages = true;
   
               // Set this to false if any of the panels that are not open are notthis.received.
               if (!this.receivedPanelCI) {
                this.readyToShowMessages = false;
               }
               if (this.panelOpenState2 && !this.receivedPanelCR) {
                this.readyToShowMessages = false;
               }
               if (this.panelOpenState3 && !this.receivedPanelDR) {
                this.readyToShowMessages = false;
               }
               if (this.panelOpenState4 && !this.receivedPanelDC) {
                this.readyToShowMessages = false;
               }
               if (this.panelOpenState5 && !this.receivedPanelSG) {
                this.readyToShowMessages = false;
               }
               if (this.panelOpenState6 && !this.receivedPanelAC) {
                this.readyToShowMessages = false;
               }
               if (this.panelOpenState7 && !this.receivedPanelWV) {
                this.readyToShowMessages = false;
               }
               if (this.panelOpenState8 && !this.receivedPanelMF) {
                this.readyToShowMessages = false;
               }
   
               // Make sure we've accumulated all the necessary validations before we show the message.
               if (this.readyToShowMessages) {
                 this.msgQueue = [];
                 // Show the validatation popup message.
                 MessageMgr.appendMsgToQueue(this.msgQueue, CaseCommonValidator.ShowValidationMessage(this._cumulativeSaveResultsType));
                 // Set the error levels for the button icons at the top of the dashboard.
                 this.errorLevelCaseInfo = this._cumulativeSaveResultsType.validationLevel(DsamsConstants.CASE_PANEL_INFO);
                 this.errorLevelCustReq = this.panelOpenState2 ? this._cumulativeSaveResultsType.validationLevel(DsamsConstants.CASE_PANEL_CUSTOMER_REQUEST) : MessageMgr.MSG_TYPE_NULL;
                 this.errorLevelDocReq = this.panelOpenState3 ? this._cumulativeSaveResultsType.validationLevel(DsamsConstants.CASE_PANEL_DOCUMENT_REQUIREMENTS) : MessageMgr.MSG_TYPE_NULL;
                 this.errorLevelDesc = this.panelOpenState4 ? this._cumulativeSaveResultsType.validationLevel(DsamsConstants.CASE_PANEL_DESCRIPTIONS) : MessageMgr.MSG_TYPE_NULL;
                 this.errorLevelSignatories = this.panelOpenState5 ? this._cumulativeSaveResultsType.validationLevel(DsamsConstants.CASE_PANEL_SIGNATORIES) : MessageMgr.MSG_TYPE_NULL;
                 this.errorLevelAssociations = this.panelOpenState6 ? this._cumulativeSaveResultsType.validationLevel(DsamsConstants.CASE_PANEL_ASSOCIATIONS) : MessageMgr.MSG_TYPE_NULL;
                 this.errorLevelWaivers = this.panelOpenState7 ? this._cumulativeSaveResultsType.validationLevel(DsamsConstants.CASE_PANEL_WAIVERS) : MessageMgr.MSG_TYPE_NULL;
                 this.errorLevelModfunding = this.panelOpenState8 ? this._cumulativeSaveResultsType.validationLevel(DsamsConstants.CASE_PANEL_MODFUNDING) : MessageMgr.MSG_TYPE_NULL;
   
                 if (!!this._cumulativeSaveResultsType.caseVersionPanelData && this._cumulativeSaveResultsType.isValidationSuccessful()) {
                   // Show "no-changes" message if nothing was changed.
                   if (this._cumulativeSaveResultsType.caseVersionPanelData.status == DsamsConstants.ENT_UNCHANGED) {
                     this._cumulativeSaveResultsType = new SaveResultsType();
                     this.receivedPanelCI = false;
                     this.receivedPanelCR = false;
                     this.receivedPanelDR = false;
                     this.receivedPanelDC = false;
                     this.receivedPanelSG = false;
                     this.receivedPanelAC = false;
                     this.receivedPanelWV = false;
                     this.receivedPanelMF = false;
                     this.readyToShowMessages = false;
                     this.caseUIService.canSave.next(true);
                     MessageMgr.appendMsgToQueue(this.msgQueue, MessageMgr.displayInfoForQueue("No changes to save."));
                     MessageMgr.showMessageQueue(this.msgQueue);
                   }
                   else {
                     this.caseUIService.milestoneAddService.pipe(take(1)).subscribe((value) => {
                       if (value == "PENINK" || value == "CWDREDIT" || value == "CWDPEDIT") {
                         this.saveMilestone();
                       } else {
                         this.saveChangedCaseData();
                       } 
                     });
                    
                   }  
                 }
                 else {
                   if (!this._cumulativeSaveResultsType.isValidationSuccessful()) {
                     MessageMgr.showMessageQueue(this.msgQueue);
                     this.postFailedDataValidation();
                   }
                   this._cumulativeSaveResultsType = new SaveResultsType();
                   this.caseUIService.canSave.next(true);
                  this.receivedPanelCI = false;
                  this.receivedPanelCR = false;
                  this.receivedPanelDR = false;
                  this.receivedPanelDC = false;
                  this.receivedPanelSG = false;
                  this.receivedPanelAC = false;
                  this.receivedPanelWV = false;
                  this.receivedPanelMF = false;
                  this.readyToShowMessages = false;
                 }
               }
             }
             );
       }
    
     // Kick off the save request.
     this.caseUIService.saveRequest.next(this._skipValidation);
 
     // begin Jira Card DSAMS-5689 06/2022 AKP
     // After save is complete, SAVE button should stays enabled when in Edit mode (existing functionality) and 
     // disabled if it's in view mode as user has selected the Options menu to update fields and updated fields are disabled after the save
     // so no reason for save button to be enabled.
     this.caseUIService.saveInViewModeWhenOptionsMenuSelected.next(this._currentToggle);
      // end Jira Card DSAMS-5689 06/2022 AKP
      this.setPanelStateForSave(this.afterSaveStr);
   }
  
  saveChangedCaseData() {
    // begin DSAMS-5694 09/22 DB saveChangedCaseData
    // Make sure that if we don't have a basic case, that the status for case_master is not ent_new.
    if (this._cumulativeSaveResultsType.caseVersionPanelData.theCaseId.status == DsamsConstants.ENT_NEW &&
      this._cumulativeSaveResultsType.caseVersionPanelData.case_VERSION_TYPE_CD !== "B") {
      this._cumulativeSaveResultsType.caseVersionPanelData.theCaseId.status = DsamsConstants.ENT_CHANGED;
    }

    // Console log the contents of the Case Info Panel we will send off to the back-end.
    // console.log("Case Version Data JSON Object:");
    console.log(this._cumulativeSaveResultsType.caseVersionPanelData);

    // Send results off to the back-end to be saved.
    this.caseRestService
      .saveCaseDetail(this._cumulativeSaveResultsType.caseVersionPanelData)
      .subscribe((pReturnCaseVersion: ICaseVersion) => {
        this.isNewAmendOrMod = false;
        this._cumulativeSaveResultsType = new SaveResultsType();
        this.receivedPanelCI = false;
        this.receivedPanelCR = false;
        this.receivedPanelDR = false;
        this.receivedPanelDC = false;
        this.receivedPanelSG = false;
        this.receivedPanelAC = false;
        this.receivedPanelWV = false;
        this.receivedPanelMF = false;
        MessageMgr.appendMsgToQueue(this.msgQueue, MessageMgr.displaySuccessForQueue("Case Detail saved."));
        MessageMgr.showMessageQueue(this.msgQueue);
        if (this.CaseId === 0) {
          this.postSaveForNewCase(pReturnCaseVersion);
        }
        this.postSaveDataForEditToggle();
      
        // Separate service for edit toggle because that's a subject, not behaviorsubject.
        this.caseUIService.saveCaseVersionCompleteForEditToggle.next(pReturnCaseVersion);
        this.caseUIService.canSave.next(true);
        this.readyToShowMessages = false;
        this.caseUIService.saveCaseVersionComplete.next(pReturnCaseVersion);


      },
        err => {
          this._cumulativeSaveResultsType = new SaveResultsType();
          this.receivedPanelCI = false;
          this.receivedPanelCR = false;
          this.receivedPanelDR = false;
          this.receivedPanelDC = false;
          this.receivedPanelSG = false;
          this.receivedPanelAC = false;
          this.receivedPanelWV = false;
          this.receivedPanelMF = false;
          this.readyToShowMessages = false;
          CaseUtils.ReportHTTPError(err, "Case Update");
          this.caseUIService.canSave.next(true);
          this.postFailedDataValidation();
        }
      );
  }


   // event begin DSAMS-5694 09/22 DB
saveMilestone() {
  this.caseUIService.milestoneAddService.pipe(take(1)).subscribe((value) => {
    if (value === "PENINK") {
      this.openMilestoneCommentDialog("PENINK");
    } else if (value === "CWDREDIT") {
      this.openMilestoneCommentDialog("CWDREDIT");
    } else if (value === "CWDPEDIT") {
      this.openMilestoneCommentDialog("CWDPEDIT")
    }
  });
}

/* Open the Pen & Ink Milestone Comment Dialog */
openMilestoneCommentDialog(pMilestoneId: string): any {
  const dialogRef = this.dialog.open(MilestoneCommentComponent, {
    width: '50em',
    height: '30em',
    data: {
      caseId: this.CaseId,
      versionId:this.CaseVersionId,
      milestoneId: pMilestoneId
       // begin DSAMS-5933 09/22 DB
       , activityId:  sessionStorage.getItem(CaseDashboardComponent.USER_ACTIVITY_ID),
       userId: sessionStorage.getItem(CaseDashboardComponent.USER_ID)
       // end DSAMS-5933 09/22 DB
    }
  });
  dialogRef.afterClosed().subscribe((data) => {
    if (data === "Ok") {
      this.caseUIService.isMilestoneCommentNull.subscribe((value) => {
        if (!value) {
          this.caseUIService.setNotifyToSetDefaultOption(true);
          this.caseUIService.flipToDisabledService.next(DsamsConstants.CASE_VERSION_EDITOR);
          const editResponse: IEditResponseType = {
            ID: DsamsConstants.CASE_VERSION_EDITOR,
            editToggle: false
          };
          this.caseUIService.caseEditService.next(editResponse);
          this.caseUIService.optionSelectCounter.next(0);
        }
        this.saveChangedCaseData();
      });
    }
  });
}

setUserActivityId() {
  let actId : string = sessionStorage.getItem(CaseDashboardComponent.USER_ACTIVITY_ID);
  if (actId === null  || actId.length < 2) {
     this.dsamsRestService.getUserInfo()
    .subscribe(
      data => { 
        if (data.userProfile.activityId != null) {
          sessionStorage.setItem(CaseDashboardComponent.USER_ACTIVITY_ID,data.userProfile.activityId);;
        } else {
          sessionStorage.Item(CaseDashboardComponent.USER_ACTIVITY_ID, "");
        }

      })
  }
 
}
// event end DSAMS-5694 09/22 DB

  postSaveDataForEditToggle() {
    if (this.caseUIService.theComponentSaveState[CaseUIService.SAVE_CASE_DETAILS_STATE].isSaveConfirmed.getValue()) {
      this.caseUIService.theComponentSaveState[CaseUIService.SAVE_CASE_DETAILS_STATE].isDataChanged = false;
      this.caseUIService.theComponentSaveState[CaseUIService.SAVE_CASE_DETAILS_STATE].isSaveConfirmed.next(false);
      const turnToggleOff: IEditResponseType = { ID: DsamsConstants.CASE_VERSION_EDITOR, editToggle: false };
      this.caseUIService.caseEditService.next(turnToggleOff);
      this.caseUIService.caseEditServiceRegSub.next(turnToggleOff);
    }
  }

  postFailedDataValidation() {
    this.caseUIService.flipToEnabledService.next(DsamsConstants.CASE_VERSION_EDITOR);
  }

  /**
  * Perform a case validation.
  */
  subscribeToValidateCase() {
    if (!this._validateCaseSubscription) {
      this._validateCaseSubscription = this.caseUIService.validateCaseSubscription.subscribe(() => {
        let receivedPanelCI: boolean = false;
        let receivedPanelCR: boolean = false;
        let receivedPanelDR: boolean = false;
        let receivedPanelDC: boolean = false;
        let receivedPanelSG: boolean = false;
        let receivedPanelAC: boolean = false;
        let receivedPanelWV: boolean = false;
        let receivedPanelMF: boolean = false;
        let panelQuorum: boolean = false;
        let caseDetailStatus: number = DsamsConstants.ENT_UNCHANGED;
        let caseId: number = 0;
        let caseVersionId: number = 0;
        // Gather the change statuses of all the panels.
        // Then do the actual case validateion.
        if (!this._panelCaseVersionStatusResponseSubscription) {
          // Wait for responses.
          this._panelCaseVersionStatusResponseSubscription = this.caseUIService
            .getPanelCaseVersionStatusResponseSubscription()
            .subscribe((pCPST: CasePanelStatusType) => {
              if (!pCPST) { return; }
              // console.log("Case Panel Status:");
              // console.log(pCPST);
              // console.log("PnlOpenStates:" + this.panelOpenState1 + " " +  this.panelOpenState2 + " " +  this.panelOpenState3 + " " +  this.panelOpenState4 + " " +  this.panelOpenState5 + " " +  this.panelOpenState6 + " " +  this.panelOpenState7);
              receivedPanelCI = receivedPanelCI || (pCPST.panelName === DsamsConstants.CASE_PANEL_INFO);
              receivedPanelCR = receivedPanelCR || (pCPST.panelName === DsamsConstants.CASE_PANEL_CUSTOMER_REQUEST) || !this.panelOpenState2;
              receivedPanelDR = receivedPanelDR || (pCPST.panelName === DsamsConstants.CASE_PANEL_DOCUMENT_REQUIREMENTS) || !this.panelOpenState3;
              receivedPanelDC = receivedPanelDC || (pCPST.panelName === DsamsConstants.CASE_PANEL_DESCRIPTIONS) || !this.panelOpenState4;
              receivedPanelSG = receivedPanelSG || (pCPST.panelName === DsamsConstants.CASE_PANEL_SIGNATORIES) || !this.panelOpenState5;
              receivedPanelAC = receivedPanelAC || (pCPST.panelName === DsamsConstants.CASE_PANEL_ASSOCIATIONS) || !this.panelOpenState6;
              receivedPanelWV = receivedPanelWV || (pCPST.panelName === DsamsConstants.CASE_PANEL_WAIVERS) || !this.panelOpenState7;
              receivedPanelMF = receivedPanelMF || (pCPST.panelName === DsamsConstants.CASE_PANEL_MODFUNDING) || !this.panelOpenState8;

              // If we receive info from a panel, but it's closed, ignore the status of that panel.
              let setStatus: boolean = true;
              if (
                (pCPST.panelName === DsamsConstants.CASE_PANEL_CUSTOMER_REQUEST && !this.panelOpenState2) ||
                (pCPST.panelName === DsamsConstants.CASE_PANEL_DOCUMENT_REQUIREMENTS && !this.panelOpenState3) ||
                (pCPST.panelName === DsamsConstants.CASE_PANEL_DESCRIPTIONS && !this.panelOpenState4) ||
                (pCPST.panelName === DsamsConstants.CASE_PANEL_SIGNATORIES && !this.panelOpenState5) ||
                (pCPST.panelName === DsamsConstants.CASE_PANEL_ASSOCIATIONS && !this.panelOpenState6) ||
                (pCPST.panelName === DsamsConstants.CASE_PANEL_WAIVERS && !this.panelOpenState7) ||
                (pCPST.panelName === DsamsConstants.CASE_PANEL_MODFUNDING && !this.panelOpenState8)
              ) {
                setStatus = false;
              }

              if (setStatus) {
                // Changed status first
                caseDetailStatus = (caseDetailStatus == DsamsConstants.ENT_UNCHANGED && pCPST.status == DsamsConstants.ENT_CHANGED) ? pCPST.status : caseDetailStatus;
                // New status next (takes priority)
                caseDetailStatus = (caseDetailStatus != DsamsConstants.ENT_NEW && pCPST.status == DsamsConstants.ENT_NEW) ? pCPST.status : caseDetailStatus;
                // Get the case and case version IDs.
                caseId = (pCPST.caseId > 0) ? pCPST.caseId : caseId;
                caseVersionId = (pCPST.caseVersionId > 0) ? pCPST.caseVersionId : caseVersionId;
              }
              panelQuorum = receivedPanelCI && receivedPanelCR && receivedPanelDR && receivedPanelDC && receivedPanelSG && receivedPanelAC && receivedPanelWV && receivedPanelMF;
              // console.log("Panels:" + receivedPanelCI + " " + receivedPanelCR + " " + receivedPanelDR + " " + receivedPanelDC + " " + receivedPanelSG + " " + receivedPanelAC + " " + receivedPanelWV);
              // console.log("SetStatus=" + setStatus);
              // console.log("quorum=" + panelQuorum);
              // console.log("CaseIDs: " + pCPST.caseId + "/" + pCPST.caseVersionId); 
              if (panelQuorum) {
                // We have a quorum of all the panel info received, so check save status.                
                if (caseDetailStatus == DsamsConstants.ENT_NEW) {
                  MessageMgr.displaySinglePopupError("E201");
                }
                else if (caseDetailStatus == DsamsConstants.ENT_CHANGED) {
                  MessageMgr.swalFire({
                    title: "Case not saved.",
                    icon: 'info',
                    showCancelButton: true,
                    cancelButtonText: 'No',
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#3085d6',
                    confirmButtonText: 'Yes',
                    html: MessageMgr.getMesssage("E202").messageText
                  }).then((result) => {
                    if (result.value) {
                      this.validateCase(caseId, caseVersionId);
                    }
                  });
                }
                else {   // Unchanged - proceed with validation.
                  if (caseDetailStatus == DsamsConstants.ENT_UNCHANGED) {
                    this.validateCase(caseId, caseVersionId);
                  }
                }
                caseDetailStatus = DsamsConstants.ENT_UNCHANGED;
              }
            }
            );
        }
        this.caseUIService.panelCaseVersionStatusQuerySubscriptionNext();
      });
    }
  }

  /* Validate Case */
  private validateCase(pCaseId: number, pCaseVersionId: number) {
    this.showSpinner.next(true);
    this.caseRestService
      .validateCase(pCaseId, pCaseVersionId)
      .subscribe((pMessageList: Array<ErrorParameter>) => {
        // console.log("Message List:");
        // console.log(pMessageList);              
        this.showSpinner.next(false);
        if (pMessageList.length == 0) {
          MessageMgr.displaySuccess("No validation messages.");
        }
        else {
          let cvType: string = this.caseHeaderData["case_VERSION_TYPE_NM"].substring(0, 1);
          if (cvType === "C") {
            cvType = "I";
          }
          let title: string = "DSAMS: Validate Case: " + this.caseHeaderData["user_CASE_ID"] + " " + cvType + this.caseHeaderData["case_VERSION_NUMBER_ID"];
          this.messageService.displayMessageListTc(title, pMessageList).subscribe(() => '');
        }
        this.caseValidationLevel = SaveResultsType.caseValidationLevel(pMessageList);
      },
        err => {
          CaseUtils.ReportHTTPError(err, "Error validating case");
          this.showSpinner.next(false);
        }
      );
  }


  /* When the user clicks the cancel button, the button color will change.  
    It will also change the save button back to the original color.  
    It will toggle back to the original color after a second click. */
  setCancelButtonColor(event: Event) {

    MessageMgr.swalFire({
      title: 'Are you sure you want to cancel?',
      icon: 'warning',
      showCancelButton: true,
      //  customClass:{popup:'swal2-modal'},
      cancelButtonText: 'No',
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes',
    }).then((result) => {
      if (result.value) {
        this.resetAllDisplayStates(true);
        //this.sidenavState = true;
        // Reset Option Flags
        this.caseUIService.resetOptionFlags(DsamsConstants.PAGE_CASE_DETAIL);
        // Set Flag counter back to zero
        this.caseUIService.optionSelectCounter.next(0);
        if (this.cancelButtonColor === caseConstants.initialCancelButtonColor) {
          this.cancelButtonColor = "red";
        }
        else {
          this.cancelButtonColor = caseConstants.initialCancelButtonColor;
        }
        /* Set save button to original state */
        this.saveButtonColor = caseConstants.initialSaveButtonColor;
        this.saveButtonFontColor = caseConstants.initialSaveButtonFontColor;
        //this.sidenavState = false;
        window.location.reload();
      }
    })

  }

  /* When the user clicks the case new ok button, the button color will change.  It will toggle back to the original after a second click. */
  setCaseNewOkButtonColor() {
    if (this.caseNewOkButtonColor === caseConstants.initalOkButtonColor) {
      this.caseNewOkButtonColor = "lightblue";
      this.caseNewOkButtonFontColor = "black";
    }
    else {
      this.caseNewOkButtonColor = caseConstants.initalOkButtonColor;
      this.caseNewOkButtonFontColor = caseConstants.initialSaveButtonFontColor;
    }
  }

  /* When the user clicks the case new reset button, the button color will change.  It will also change the save button back to the original color.  It will toggle back to the original after a second click. */
  setCaseNewResetButtonColor(event: Event) {
    if (this.caseNewResetButtonColor === caseConstants.initialCancelButtonColor) {
      this.caseNewResetButtonColor = "red";
    }
    else {
      this.caseNewResetButtonColor = caseConstants.initialCancelButtonColor;
    }
    /* Set save button to original state */
    this.caseNewOkButtonColor = caseConstants.initalOkButtonColor;
    this.caseNewOkButtonFontColor = caseConstants.initialSaveButtonFontColor;
    this.newCaseResetState = true;
    this.resetFieldsValidation();
    this.setNewDefaultDislayValues();
  }

  /* When the user clicks the case search ok button, the button color will change.  It will toggle back to the original after a second click. */
  setSearchOkButtonColor(event: Event) {
    if (this.caseSearchOkButtonColor === caseConstants.initalOkButtonColor) {
      this.caseSearchOkButtonColor = "lightblue";
      this.caseSearchOkButtonFontColor = "black";
    }
    else {
      this.caseSearchOkButtonColor = caseConstants.initalOkButtonColor;
      this.caseSearchOkButtonFontColor = caseConstants.initialSaveButtonFontColor;
    }
  }

  /* When the user clicks the case search reset button, the button color will change.  It will also change the save button back to the original color.  It will toggle back to the original after a second click. */
  setSearchResetButtonColor(event: Event) {
    if (this.caseSearchResetButtonColor === caseConstants.initialCancelButtonColor) {
      this.caseSearchResetButtonColor = "red";
    }
    else {
      this.caseSearchResetButtonColor = caseConstants.initialCancelButtonColor;
    }
    /* Set save button to original state */
    this.caseSearchOkButtonColor = caseConstants.initalOkButtonColor;
    this.caseSearchOkButtonFontColor = caseConstants.initialSaveButtonFontColor;
    this.newCaseResetState = true;
    this.resetCaseSearchArray();
    this.resetFieldsValidation();
  }

  searchEnterCaseSelect() {
    this.searchEnterCaseFontColor = caseConstants.searchCaseEnabledColor;
    this.SearchOtherCriteriaFontColor = caseConstants.searchCaseDisabledColor;
    this.searchEnterCaseFieldStatus = caseConstants.searchCaseDisabledStatus;
    this.SearchOtherCriteriaFieldStatus = caseConstants.searchCaseEnabledStatus;
    this.searchEnterCaseMouseStatus = caseConstants.searchCaseEnableMouse;
    this.SearchOtherCriteriaMouseStatus = caseConstants.searchCaseDisabledMouse;
    this.caseFormControl.enable();
    this.caseSearchFlag = true;
    this.caseSearchData.searchByUserCaseId = this.caseSearchFlag;
    this.newCaseResetState = true;
    this.txtSearchDocNumber = "";
    this.txtSearchCaseDesignator = "";
    this.doBackspaceCM();
  }

  searchOtherCriteriaSelect() {
    this.resetFieldsValidation();
    this.caseFormControl.disable();
    this.searchEnterCaseFontColor = caseConstants.searchCaseDisabledColor;
    this.SearchOtherCriteriaFontColor = caseConstants.searchCaseEnabledColor;
    this.searchEnterCaseFieldStatus = caseConstants.searchCaseEnabledStatus;
    this.SearchOtherCriteriaFieldStatus = caseConstants.searchCaseDisabledStatus;
    this.searchEnterCaseMouseStatus = caseConstants.searchCaseDisabledMouse;
    this.SearchOtherCriteriaMouseStatus = caseConstants.searchCaseEnableMouse;
    this.caseSearchFlag = false;
    this.caseSearchData.searchByUserCaseId = this.caseSearchFlag;
  }

  // Activity Popup
  popupCaseActivity(elementName: string): void {
    let diaWidth: string = "60%";
    let diaHeight: string = "68%";
    let passingData: string = "";

    // Pass in elementName - Associated or Related
    this.dsamsMethodsService.openSearchDialogCase(diaWidth, diaHeight, passingData, PopCaseActivityComponent, this.caseActivityForm, elementName);
    //this.casePopupSessionStorage = sessionStorage.getItem('caseAssoPopupValue');
  }

  // Person Popup
  popupPerson() {
    const passingData: string = "0";   // All active people
    this.dsamsMethodsService.openSearchDialogCase(DsamsConstants.PERSON_POPUP_WIDTH,
      DsamsConstants.PERSON_POPUP_HEIGHT,
      passingData,
      PopPersonComponent,
      this.caseActivityForm,
      "Person Search");
    this.subscribeToPopupPerson();
  }

  // Person Customer Request
  popupCR() {
    const passingData: string = this.txtCountry;
    this.dsamsMethodsService.openSearchDialogCase(DsamsConstants.CUST_REQ_POPUP_WIDTH,
      DsamsConstants.CUST_REQ_POPUP_HEIGHT,
      passingData,
      PopCustomerRequestComponent,
      this.caseActivityForm,
      "Customer Request Search");
    this.subscribeToPopupCR();
  }

  // Case Popup
  popupCaseDetailCase(elementName: string): void {
    let diaWidth: string = "70%";
    let diaHeight: string = "70%";
    let passingData: string = "";

    this.dsamsMethodsService.openSearchDialogCase(diaWidth, diaHeight, passingData, PopCaseAssociationComponent, this.caseDetailCaseForm, elementName);
  }

  // Subscribe to the DSAMS service for case details case textfield for popup selection.
  subscribeToPopupCase() {
    if (this._popupCaseDetailSubscription == null) {
      this._popupCaseDetailSubscription = this.dsamsMethodsService
        .selectedCaseStringFromPopupValue
        .subscribe(value => {
          this.txtSearchCaseDetailsCase = value;
          //console.log("value is: " + value);
        },
          err => {
            CaseUtils.ReporError("Error in dsamsMethodsService.popupCaseDetailCase");
          }
        );
    }
  }

  // Subscribe to the DSAMS service for ICaseMaster for popup selection.
  subscribeToICaseMasterSelection() {
    if (this._popupICaseMasterSubscription == null) {
      this._popupICaseMasterSubscription = this.dsamsMethodsService
        .selectedICaseMasterFromPopupValue
        .subscribe((selectedVal: ICaseMaster) => {
          this.thecaseLineRelatedInfoList = [];

          for (var j = 0; j < selectedVal.caseVersionList.length; j++) {
            //prepare data for case line tabs
            this.caseRelatedInfoData = {
              working_CASE_ID: selectedVal.case_ID,
              case_MASTER_STATUS_CD: selectedVal.case_MASTER_STATUS_CD,
            }
            // Null check for Offer Expiration Date to prevent null exception
            let offerExpirationDate = "";
            if (selectedVal.caseVersionList[j].offer_EXPIRATION_DT != null) {
              offerExpirationDate = selectedVal.caseVersionList[j].offer_EXPIRATION_DT.toString();
            }

            this.caseLineRelatedInfoData = {
              case_VERSION_TYPE_CD: selectedVal.caseVersionList[j].case_VERSION_TYPE_CD,
              case_VERSION_STATUS_CD: selectedVal.caseVersionList[j].case_VERSION_STATUS_CD,
              case_VERSION_NUMBER_ID: selectedVal.caseVersionList[j].case_VERSION_NUMBER_ID,
              case_VERSION_ID: selectedVal.caseVersionList[j].case_VERSION_ID,
              wm_OFFER_EXPIRATION_DT: offerExpirationDate,
              implementing_AGENCY_ID: selectedVal.implementing_AGENCY_ID,
              security_ASSISTANCE_PROGRAM_CD: selectedVal.security_ASSISTANCE_PROGRAM_CD,
              customer_REQUEST_ID: selectedVal.caseVersionList[j].customer_REQUEST_ID
            }
            this.thecaseLineRelatedInfoList.push(this.caseLineRelatedInfoData);
            // here
            // console.log("caseVersionList for Case " + selectedVal.case_ID + 
            // " and case_VERSION_TYPE_CD: " + selectedVal.caseVersionList[j].case_VERSION_TYPE_CD + 
            // " and case_VERSION_STATUS_CD: " + selectedVal.caseVersionList[j].case_VERSION_STATUS_CD + 
            // " is " + selectedVal.caseVersionList[j].case_VERSION_NUMBER_ID);
            //this.dropdownCaseVersions[j] = {value: selectedVal.caseVersionList[j].case_VERSION_NUMBER_ID.toString(), viewValue: selectedVal.caseVersionList[j].case_VERSION_STATUS_CD};

            // Initializing dropdown element
            this.dropdownCaseVersions[j] = { value: 'A', viewValue: 'A' };
            this.dropdownCaseVersions[j].value = selectedVal.caseVersionList[j].case_VERSION_ID.toString();
            if (selectedVal.caseVersionList[j].case_VERSION_TYPE_CD === "B" || selectedVal.caseVersionList[j].case_VERSION_TYPE_CD === "I") {
              this.dropdownCaseVersions[j].viewValue = selectedVal.caseVersionList[j].case_VERSION_TYPE_CD;
            }
            else {
              this.dropdownCaseVersions[j].viewValue = selectedVal.caseVersionList[j].case_VERSION_TYPE_CD + " " + selectedVal.caseVersionList[j].case_VERSION_NUMBER_ID;
            }
          }
        },
          err => {
            CaseUtils.ReporError("Error in dsamsMethodsService.popupICaseMaster in case details");
          }
        );
    }
  }

  // Subscribe to skip validation
  subscribeToSkipValidation() {
    if (!this._skipValidationSubscription) {
      this._skipValidationSubscription = this.caseUIService.skipValidation.subscribe((skipVal: boolean) => {
        this._skipValidation = skipVal;
      });
    }
  }

  // Subsribe to amend/mod change (so it will change on the header)
  // Subscribe to Amend/Mod changed.
  subscribeToAmendModChange() {
    if (!this._amendModChangeSubscription) {
      this._amendModChangeSubscription = this.caseUIService.caseAmendModChange.subscribe((camChangeInfo: CaseAmendModChangeInfo) => {
        this.caseHeaderData["case_VERSION_TYPE_NM"] = camChangeInfo.typeCd === "A" ? "Amendment" : "Modification";
        this.caseHeaderData["case_VERSION_NUMBER_ID"] = camChangeInfo.verNumId;
        //DSAMS-5690 ZW 07/2022
        this.caseRestService.getCaseAmendModNumberChange(camChangeInfo.caseId, camChangeInfo.versionId, camChangeInfo.typeCd, camChangeInfo.verNumId)
        .subscribe(
          data =>{
            console.log("data is ", data);
            if (data === 'M30') {
              MessageMgr.swalFire({
                title: "Modifications cannot have AOD Group C assigned, Modification updated to AOD Group B",
                icon: 'success',
                showCancelButton: false,
                confirmButtonColor: '#3085d6',
                confirmButtonText: 'OK'
              });
            }

            const caseRequestParamsType: CaseRequestParamsType = {
              caseId: camChangeInfo.caseId,
              caseVersionId: camChangeInfo.versionId,
            };
            this.caseUIService.caseDetailSelected.next(caseRequestParamsType);
  
          }
        );
      });
    }
  }

  // Subsribe to country change (so it will change on the header)
  subscribeToCountryChange() {
    if (!this._countryChangeSubscription) {
      this._countryChangeSubscription = this.caseUIService.countryChange.subscribe((updCountry: string) => {
        this.txtCountryForHeader = updCountry;
        this.caseHeaderData["user_CASE_ID"] = CaseUtils.formatUserCaseIdForChangeCountry(this.caseHeaderData["user_CASE_ID"], updCountry);
        this.caseHeaderData["customer_ORGANIZATION_ID"] = updCountry;
      });
    }
  }

  // **************** Reset the Case Detail panel ************************
  resetCaseDetailPanel() {
    this.txtDoc = 'C';
    this.txtSAProgram = 'FMS';
    this.txtSearchCaseDetailsCase = '';
    this.dropdownCaseVersions = [{ value: '', viewValue: '' }];
    this.showSubmenuCase = false;
    this.onClickCaseLineCancelButton();
    this.isNewAmendOrMod = false;
  }

  resetFormValues() {
    this.lineFormCtl.reset();
    this.subLineFormCtl.reset();
    this.subLineSubFormCtl.reset();
    this.caseVersionFormControl.reset();
  }

  // For Case Details Cancel buttons
  onClickCaseDetailsCancelButton() {
    this.resetCaseDetailPanel();
    this.showSubmenuCase = false;
    this.onClickCaseLineCancelButton();
  }

  // For Case Line Cancel buttons
  onClickCaseLineCancelButton() {
    /* Comment out for now
    this.theCaseMasterLineList = [];
    this.theCaseMasterSublineList = [];
    this.txtSearchCaseDetailsCase = '';
    this.resetFormValues();
    */
  }

  // Open case line detail tab for line menu selection for Case Design selection
  openCaseSublineDetailTab(pLineVal: any, pSublineVal: any) {
    //getting the data for line detail tab
    this.getCaseLineData(false);
  }

  // Open case line detail tab for line menu selection for Case Design selection
  openCaseLineDetailTab(pVal: any) {
    var lineNumber: string;
    if (this.lineFormCtl)
      lineNumber = this.lineFormCtl.value
    else {
      if (pVal.value !== null && pVal.value !== undefined)
        lineNumber = pVal.value;
    }

    if (lineNumber !== null && lineNumber !== undefined) {
      for (let i = 0; i < this.theCaseMasterLineList.length; i++) {
        //searching for a matching line to get the case master line id PK
        if (!!this.theCaseMasterLineList[i].theCaseMasterLineId) {
          if (this.theCaseMasterLineList[i].theCaseMasterLineId.user_CASE_LINE_NUMBER_ID == lineNumber) {
            this.caseRelatedInfoData.case_MASTER_LINE_ID = this.theCaseMasterLineList[i].case_MASTER_LINE_ID;
            i = this.theCaseMasterLineList.length + 999;
          }
        }
      }
      //getting the data for line detail tab
      this.getCaseLineData(true);
    }
  }

  getParentLineCMLId(pParentCaseId: any, pParentCaseMasterLineId: any): string {
    //set up parent line for subline
    for (let i = 0; i < this.theCaseMasterLineParentList.length; i++) {
      if (this.theCaseMasterLineParentList[i].case_ID == pParentCaseId &&
        this.theCaseMasterLineParentList[i].case_MASTER_LINE_ID == pParentCaseMasterLineId) {
        return (CaseUtils.formatLineNumber(this.theCaseMasterLineParentList[i].wm_USER_CASE_LINE_NUMBER_ID));
      }
    }
    return '';
  }

  //get a case line/subline entity data
  getCaseLineData(pNavigateToLine: boolean) {
    //get only 1 case line using legacy interface
    this.caseRestService.getCaseLineFromServer(
      this.caseRelatedInfoData.working_CASE_ID,
      this.caseRelatedInfoData.case_MASTER_LINE_ID,
      this.caseRelatedInfoData.working_CASE_VERSION_ID).subscribe((value) => {
        if (!!value.caseLineList && !!value.caseLineList[0]) {
          this.caseLineInfoData = { ...value.caseLineList[0] };
          this.caseLineInfoData.offer_EXPIRATION_DT = this.caseLineRelatedInfoData.wm_OFFER_EXPIRATION_DT;
          this.caseLineInfoData.implementing_AGENCY_ID = this.caseLineRelatedInfoData.implementing_AGENCY_ID;
          this.caseLineInfoData.case_USAGE_INDICATOR_CD = this.txtDoc;
          //set up virtual line number for line
          if (value.caseLineList[0].wm_USER_CASE_SUBLINE_TX == null)
            this.caseLineInfoData.LINESUBLINESEQVIR = CaseUtils.formatLineNumber(value.caseLineList[0].wm_USER_CASE_LINE_NUMBER_ID);
          else this.caseLineInfoData.LINESUBLINESEQVIR = this.getParentLineCMLId(value.caseLineList[0].wm_PARENT_CASE_ID,
            value.caseLineList[0].wm_PARENT_CASE_MASTER_LINE_ID);

          //send up the selected case line entity to be used by the Line/subline tab component
          this.caseLineRelatedInfoData.user_CASE_ID = CaseUtils.formatUserCaseId(this.txtSearchCaseDetailsCase);
          LineUtils.getFormattedMDEValue(this.caseLineInfoData);
          LineUtils.resetReferenceTitleValues(this.caseLineInfoData);
          this.caseUIService.setCaseLineRelatedInfoValues(this.caseLineRelatedInfoData);
          this.caseUIService.setCaseLineInfoValues(this.caseLineInfoData);
          this.getLineSublineRefData.populateReferenceDataForCaseLine();
          this.onClickCaseLineCancelButton();

          // Request Close Menu
          this.dataSharingService.caseSelection.next(DsamsConstants.REQUEST_CLOSE_MENU);
          //clear detail search values
          this.resetCaseDetailPanel();
          this.resetFormValues();
          //Jump to applicable line/subline tab
          if (pNavigateToLine) this.router.navigate(['/case/line-dashboard', '1', 'Line']);
          else this.router.navigate(['/case/line-dashboard', '1', 'Subline']);
        }
        else {
          MessageMgr.swalFire({
            text: 'Case Line is not found',
            icon: 'error',
            showConfirmButton: false,
            width: 400,
            focusConfirm: true,
            confirmButtonText: 'OK'
          })
        }
      });
  }

  //search for the case line related object that maches the selected version on the dropdown
  getCaseLineRelatedObject(pCaseVersionId: number): CaseLineRelatedInfoType {
    var anObject: CaseLineRelatedInfoType = null;
    for (var j = 0; j < this.thecaseLineRelatedInfoList.length; j++) {
      if (this.thecaseLineRelatedInfoList[j].case_VERSION_ID == pCaseVersionId) {
        anObject = this.thecaseLineRelatedInfoList[j];
        break;
      }
    }
    return anObject;
  }

  onSelectionChange(pColumName: any, pValue: any) {
    if (pColumName === "txtVersion") {
      this.caseLineRelatedInfoData = this.getCaseLineRelatedObject(pValue);
    }
    // switch (pColumName) {
    //   case "txtVersion": {
    //     this.caseLineRelatedInfoData = this.getCaseLineRelatedObject(pValue);
    //     break;
    //   }
    //   default: '';
    // }
  }

  onClickParentLineMenu(pLineNum: any) {
    for (var Index = 0; Index <= this.theCaseMasterLineList.length - 1; Index++) {
      if (this.theCaseMasterLineList[Index].wm_USER_CASE_LINE_NUMBER_ID == pLineNum.value) {
        //assign the parent line id to window mapping attribute
        this.theCaseMasterLineList[Index].wm_USER_CASE_LINE_NUMBER_ID =
          this.theCaseMasterLineList[Index].theCaseMasterLineId.user_CASE_LINE_NUMBER_ID;
        this.getCaseMasterLineChildList(this.theCaseMasterLineList[Index].theCMLChildList);
        break;
      }
    }
  }

  onClickChildSublineMenu(pSublineNum: any) {
    for (var Index = 0; Index <= this.theCaseMasterLineChildList.length - 1; Index++) {
      if (this.theCaseMasterLineChildList[Index].user_CASE_SUBLINE_TX == pSublineNum.value) {
        // console.log('child===', this.theCaseMasterLineChildList[Index])
        this.caseRelatedInfoData.case_MASTER_LINE_ID = this.theCaseMasterLineChildList[Index].case_MASTER_LINE_ID;
        break;
      }
    }
  }

  //All required data must be populated prior to this call
  getCaseMasterLineChildList(pChildList: ifaceCaseMasterLineSubset[]) {
    this.theCaseMasterLineChildList = [];
    pChildList.forEach(data => {
      this.theCaseMasterLineChildList.push(data)
    })
  }

  //set up subline dropdown list
  populateSublineDropdownList() {
    // var tempList: ifaceCaseLineSubsetArray[] = [];
    this.theCaseMasterLineParentList = [];
    var parentCMLId: number = 0;
    //build the new parent list
    for (var parentIndex = 0; parentIndex <= this.theCaseMasterLineList.length - 1; parentIndex++) {
      for (var x = 0; x <= this.theCaseMasterSublineList.length - 1; x++) {
        if (this.theCaseMasterLineList[parentIndex].case_MASTER_LINE_ID ==
          this.theCaseMasterSublineList[x].theCaseMasterLineId.parent_CASE_MASTER_LINE_ID &&
          parentCMLId !== this.theCaseMasterLineList[parentIndex].case_MASTER_LINE_ID) {
          //set to avoid getting the parent CML again
          parentCMLId = this.theCaseMasterLineList[parentIndex].case_MASTER_LINE_ID;
          //assign the parent line id to window mapping attribute
          this.theCaseMasterLineList[parentIndex].wm_USER_CASE_LINE_NUMBER_ID =
            this.theCaseMasterLineList[parentIndex].theCaseMasterLineId.user_CASE_LINE_NUMBER_ID;
          this.theCaseMasterLineParentList.push(this.theCaseMasterLineList[parentIndex]);
          break;
        }
      }
    }
    //build the subline list
    for (var j = 0; j <= this.theCaseMasterLineParentList.length - 1; j++) {
      for (var y = 0; y <= this.theCaseMasterSublineList.length - 1; y++) {
        if (this.theCaseMasterLineParentList[j].case_MASTER_LINE_ID ==
          this.theCaseMasterSublineList[y].theCaseMasterLineId.parent_CASE_MASTER_LINE_ID) {
          if (this.theCaseMasterLineParentList[j].theCMLChildList == null) this.theCaseMasterLineParentList[j].theCMLChildList = [];
          this.theCaseMasterLineParentList[j].theCMLChildList.push(this.theCaseMasterSublineList[y].theCaseMasterLineId);
        }
      }
    }
    //set default display value for subline
    if (this.theCaseMasterLineParentList[0]) {
      this.subLineFormCtl.setValue(this.theCaseMasterLineParentList[0].wm_USER_CASE_LINE_NUMBER_ID);
      if (this.theCaseMasterLineParentList[0].theCMLChildList[0]) {
        this.getCaseMasterLineChildList(this.theCaseMasterLineParentList[0].theCMLChildList);
        this.subLineSubFormCtl.setValue(this.theCaseMasterLineChildList[0].user_CASE_SUBLINE_TX);
        this.caseRelatedInfoData.case_MASTER_LINE_ID = this.theCaseMasterLineParentList[0].theCMLChildList[0].case_MASTER_LINE_ID;
      }
    }
  }

  //set up line dropdown list
  populateCaseLineDropDown(pSubline: boolean) {
    this.caseRelatedInfoData.working_CASE_VERSION_ID = this.caseVersionFormControl.value;
    this.caseRelatedInfoData.case_USAGE_INDICATOR_CD = this.txtDoc;
    this.caseLineRelatedInfoData.user_CASE_ID = this.txtSearchCaseDetailsCase;
    this.caseRestService.getSubsetCaseLineList(this.caseRelatedInfoData.working_CASE_ID,
      this.caseRelatedInfoData.working_CASE_VERSION_ID).subscribe(
        data => {
          this.theCaseMasterLineList = [];
          this.theCaseMasterSublineList = [];
          //perform sort
          data.sort((object1, object2) =>
            object1.theCaseMasterLineId.user_CASE_LINE_NUMBER_ID - object2.theCaseMasterLineId.user_CASE_LINE_NUMBER_ID);
          for (var i = 0; i <= data.length - 1; i++) {
            if (!!data[i].theCaseMasterLineId.user_CASE_SUBLINE_TX)
              this.theCaseMasterSublineList.push(data[i]);
            else {
              this.theCaseMasterLineList.push(data[i]);
            }
          }
          //setting up the subline dropdown list
          if (pSubline) {
            this.populateSublineDropdownList();
          }

          //set the default display values for subline dropdown fields
          if (this.theCaseMasterLineList && !!this.theCaseMasterLineList[0]) {
            this.lineFormCtl.setValue(this.theCaseMasterLineList[0].theCaseMasterLineId.user_CASE_LINE_NUMBER_ID);
          }
        },
        error => {
          console.log('Error getting the case line list data')
        }
      )
  }

  onExpandLinesLink(pSubline: boolean) {
    if (this.areAllRequiredFieldsEntered()) {
      if (this.showSubmenuCase) {
        //Jira DSAMS-5269
        this.getLineSublineRefData.populateReferenceDataForCaseLine();
        this.populateCaseLineDropDown(pSubline);
      }
    }
    else {
      if (this.showSubmenuCase) {
        MessageMgr.swalFire({
          html: 'All required fields must be entered.',
          icon: 'error',
          showConfirmButton: true,
          width: 400,
          focusConfirm: true,
          confirmButtonText: 'OK'
        })
        this.showSubmenuCase = false;
      }
    }
  }

  //Enable links to to other pages when all data are available
  areAllRequiredFieldsEntered() {
    if (!CaseUtils.isBlankStr(this.txtSAProgram) &&
      !CaseUtils.isBlankStr(this.txtDoc) &&
      !CaseUtils.isBlankStr(this.txtSearchCaseDetailsCase) &&
      !CaseUtils.isBlankStr(this.caseVersionFormControl.value))
      return true;
    return false;
  }

  //jump to the case detail page
  getUnformattedCaseId(): string {
    var searchHyphenChar: string[] = ['-'];
    if (searchHyphenChar.includes(this.txtSearchCaseDetailsCase, 0)) {
      let aCaseId: string = this.txtSearchCaseDetailsCase.substr(0, 2) +
        this.txtSearchCaseDetailsCase.substr(3, 1) +
        this.txtSearchCaseDetailsCase.substr(5, 3);
      return aCaseId;
    }
    return this.txtSearchCaseDetailsCase;

  }

  openCaseDetail() {
    console.log('i am in opencasedeatil');
    if (this.areAllRequiredFieldsEntered()) {
      // console.log(this.txtSearchCaseDetailsCase);
      if (!!this.txtSearchCaseDetailsCase) {
        //hit the server only when the user enters the user case manually
        if (this.caseRelatedInfoData.working_CASE_ID > 0) {
          console.log('i am in inside ifcaserel');
          const caseRequestParamsType: CaseRequestParamsType = {
            caseId: this.caseRelatedInfoData.working_CASE_ID,
            caseVersionId: this.caseVersionFormControl.value,
            securityAssistanceProgramCd: this.txtSAProgram,
            customerOrganizationId: '',
            caseVersionTypeCd: '',
            implementingAgencyId: '',
            customerRequestId: 0,
          }
          this.caseRelatedInfoData.case_ID = this.caseRelatedInfoData.working_CASE_ID;
          this.caseRelatedInfoData.case_USAGE_INDICATOR_CD = this.txtDoc;
          this.caseRelatedInfoData.case_VERSION_ID = this.caseVersionFormControl.value;
          this.caseRelatedInfoData.implementing_AGENCY_ID = '';
          this.caseRelatedInfoData.working_CASE_VERSION_ID = this.caseVersionFormControl.value;
          this.dataSharingService.caseSelection.next(DsamsConstants.REQUEST_CLOSE_MENU);
          //clear detail search values
          this.resetCaseDetailPanel();
          this.resetFormValues();
          // Notify the subscribers of case detail selection.
          this.caseUIService.caseDetailSelected.next(caseRequestParamsType);
          this.caseUIService.setCaseRelatedInfoValues(this.caseRelatedInfoData);

        }
        else {
          this.caseRestService.getCaseId(this.getUnformattedCaseId()).subscribe(
            caseId => {
              const caseRequestParamsType: CaseRequestParamsType = {
                caseId: caseId,
                caseVersionId: this.caseVersionFormControl.value,
                securityAssistanceProgramCd: this.txtSAProgram,
                customerOrganizationId: '',
                caseVersionTypeCd: '',
                implementingAgencyId: '',
                customerRequestId: 0,
              }
              // Request Close Menu
              this.dataSharingService.caseSelection.next(DsamsConstants.REQUEST_CLOSE_MENU);
              //clear detail search values
              this.resetCaseDetailPanel();
              this.resetFormValues();
              // Notify the subscribers of case detail selection.
              this.caseUIService.caseDetailSelected.next(caseRequestParamsType);
              this.dataSharingService.backToCaseDetail.next(false);
            })
        }
      }
    }
    else {
      MessageMgr.swalFire({
        html: 'All required fields must be entered.',
        icon: 'error',
        showConfirmButton: true,
        width: 400,
        focusConfirm: true,
        confirmButtonText: 'OK'
      })
    }
  }

  openCaseLineList() {
    //Jira DSAMS-5269
    this.getLineSublineRefData.populateReferenceDataForCaseLine();
    this.caseLineRelatedInfoData.user_CASE_ID = CaseUtils.formatUserCaseId(this.txtSearchCaseDetailsCase);
    this.caseRelatedInfoData.wm_CASE_VERSION_TYPE_CD = this.caseHeaderData["case_VERSION_TYPE_CD"];
    this.caseUIService.setCaseRelatedInfoValues(this.caseRelatedInfoData);
    this.caseUIService.setCaseLineRelatedInfoValues(this.caseLineRelatedInfoData);
    // Request Close Menu
    this.dataSharingService.caseSelection.next(DsamsConstants.REQUEST_CLOSE_MENU);
    //clear detail search values
    this.resetCaseDetailPanel();
    this.resetFormValues();
    this.router.navigate(['/case/line-dashboard', '0', 'Line']);
  }

  onLinkToCaseLineList() {
    if (this.areAllRequiredFieldsEntered()) {
      if (this.caseRelatedInfoData == null) {
        this.caseRelatedInfoData = {
          working_CASE_ID: 0, //325569,
          working_CASE_VERSION_ID: this.caseVersionFormControl.value, //779900,
          case_USAGE_INDICATOR_CD: this.txtDoc
        }
        //hit the server only when the user enters the user case manually
        if (!!this.txtSearchCaseDetailsCase) {
          if (this.caseRelatedInfoData.working_CASE_ID > 0) {
            this.dataSharingService.backToCaseDetail.next(false);
            this.openCaseLineList();
          }
          else {
            this.caseRestService.getCaseId(this.getUnformattedCaseId()).subscribe(
              caseId => {
                this.caseRelatedInfoData.working_CASE_ID = caseId;
                this.openCaseLineList();
              })
          }
        }
      }
      else {
        this.caseRelatedInfoData.working_CASE_VERSION_ID = this.caseVersionFormControl.value;
        this.caseRelatedInfoData.case_USAGE_INDICATOR_CD = this.txtDoc;
        this.openCaseLineList();
      }
    }
    else {
      MessageMgr.swalFire({
        html: 'All required fields must be entered.',
        icon: 'error',
        showConfirmButton: true,
        width: 400,
        focusConfirm: true,
        confirmButtonText: 'OK'
      })
    }
  }

  // Check if case is valid when user enters in case details case number field
  checkIfValidCaseForTextfield(event) {
    // Do a data call to populate drop down
    let caseUserIdValue = CaseUtils.formatUserCaseId(event.target.value);
    this.getCaseFromTextFieldInputFromLegacyNew(caseUserIdValue);
  }

  /**
   * This method will get the case detail data from legacy for populating 
   * the version dropdown after the user enters a valid case number
   */
  getCaseFromTextFieldInputFromLegacyNew(caseUserId) {
    // Reset search parameters
    this.resetCaseSearchArray();

    // Setting the user id for the data call
    this.caseSearchData.user_ID = +sessionStorage.getItem('userId');

    // Setting the case number
    this.caseSearchData.user_CASE_ID = caseUserId;

    // Get data and populate to the data source for dropdown
    this.caseRestService
      .postCaseSearch(this.caseSearchData)
      .subscribe(
        data => {
          for (var i = 0; i < data.length; i++) {
            if (data[i].user_CASE_ID === caseUserId) {
              this.dsamsMethodsService.selectedICaseMasterFromPopupValue.next(data[i]);
            }
          }
        },
        err => {
          CaseUtils.ReportHTTPError(err, "getCaseFromTextFieldInputFromLegacyNew");
        }
      );
  }
  subscribeToCaseDetailBC() {
    if (this._caseDetailsBCSubscription == null) {
      this._caseDetailsBCSubscription = this.dataSharingService
        .caseDetailsBC
        .subscribe(value => {
          this.caseDetailsBC = value;
        });
    }
    if (this.caseDetailsBC) {
      if (this._backToCaseDetailSubscription == null) {
        this._backToCaseDetailSubscription = this.dataSharingService
          .backToCaseDetail
          .subscribe(data => {
            if (data) {
              this.caseUIService.submitBreadcrumbTitleChangeRequest("Case Detail Search");
              this.caseUIService.submitBreadcrumbTitleChangeRequest("Case Detail");
              this.displaySearch = false;
              this.displayPanels = true;
              this.showCaseDetails = false;
            } else {
              this.caseUIService.submitBreadcrumbTitleChangeRequest("Case Detail Search");
              this.displaySearch = false;
              this.displayPanels = false;
            }
            this.caseUIService.flipToDisabledService.next(DsamsConstants.CASE_VERSION_EDITOR);
          });
      }
    } else {
      this.caseUIService.submitBreadcrumbTitleChangeRequest("Case Search Summary");
      this.caseUIService.flipToDisabledService.next(DsamsConstants.CASE_VERSION_EDITOR);
    }
  }
  subscribeBackToSearchSummary() {
    if (this._backToSearchDetailsSubscription == null) {
      this._backToSearchDetailsSubscription = this.dataSharingService
        .backToSearchSummary
        .subscribe(value => {
          if (value) {
            if (this.caseDetailsBC === false) {
              this.displaySearch = true;
              this.displayPanels = false;
              this.caseUIService.submitBreadcrumbTitleChangeRequest("ICase Search Summary");
            } else {
              this.displaySearch = false;
              this.displayPanels = false;
              this.showCaseDetails = true;
              this.caseUIService.submitBreadcrumbTitleChangeRequest("Case Detail Search");
            }
          }
        });
    }
  }

  // Subscribe to Repopulate Line data
  repopulateCaseDetailsData() {
    this.showSpinner.next(true);
    const caseRequestParamsType: CaseRequestParamsType = {
      caseId: this.CaseId,
      caseVersionId: this.CaseVersionId,
    };
    this.repopulateData = true;
    this.caseRestService
      .getCaseDetailLegacy(caseRequestParamsType.caseId, caseRequestParamsType.caseVersionId).pipe(take(1))
      .subscribe(
        data => {
          if (data) {
            const caseDetailData: ICaseVersion = data;
            // Propogate out the event, one to each panel.
            setTimeout(() => {
              this.propagateCaseDetailDataToAllPanels(caseDetailData);
              this.caseVersionTypeCd = data.case_VERSION_TYPE_CD;
              this.caseVersionNumberId = data.case_VERSION_NUMBER_ID;
              this.setHeaderFieldsFromData(caseDetailData);
            }, 100);
            this.repopulateData = false;
            this.showSpinner.next(false);
          }
        },
        err => {
          CaseUtils.ReportHTTPError(err, "Loading Case Info Legacy");
          this.showSpinner.next(false);
        })
  }

  // Subscribe to edit toggle event
  subscribeToEdit() {
    if (!this._editSubscription) {
      this._editSubscription = this.caseUIService
        .caseEditService
        .subscribe((pResponse: IEditResponseType) => {
          if (pResponse && (pResponse.ID === DsamsConstants.CASE_VERSION_EDITOR || pResponse.ID === DsamsConstants.PAGE_CASE_DETAIL)) {
            this.canSaveCaseDetail = false;
            this.subscribeToCanSave();
            this._currentToggle = pResponse.editToggle;
            if (this._currentToggle) {
              this._alreadyToggledOn = true;
              this.canSaveCaseDetail = true;
              this.subscribeToCanSave();
              this.repopulateCaseDetailsData();
            }
          } else {
            this.canSaveCaseDetail = true;
          }
        },
          err => {
            CaseUtils.ReporError("Error in save responding to edit toggle");
          }
        );
    }
  }
  onLinkCaseDataClick(pRow: any) {
    if (this.linkCaseDataObject.case_VERSION_ID == 0) {
      this.linkCaseDataObject.case_VERSION_ID = pRow.case_VERSION_ID;
      this.linkCaseDataObject.case_VERSION_STATUS_CD = pRow.case_VERSION_STATUS_CD;
      this.linkCaseDataObject.case_MASTER_STATUS_CD = pRow.case_MASTER_STATUS_CD;
      this.linkCaseDataObject.security_ASSISTANCE_PROGRAM_CD = pRow.security_ASSISTANCE_PROGRAM_CD;
      this.linkCaseDataObject.case_VERSION_TYPE_CD = pRow.case_VERSION_TYPE_CD;
      this.linkCaseDataObject.case_VERSION_NUMBER_ID = pRow.case_VERSION_NUMBER_ID;
      this.linkCaseDataObject.user_CASE_ID = this.caseSearchData.user_CASE_ID;
      this.linkCaseDataObject.customer_ORGANIZATION_ID = this.caseSearchData.customer_ORGANIZATION_ID;
      this.linkCaseDataObject.wm_CASE_VERSION_TYPE_CD = pRow.case_VERSION_TYPE_CD;
      this.linkCaseDataObject.case_USAGE_INDICATOR_CD = pRow.case_USAGE_INDICATOR_CD;
      this.linkCaseData = LinkCaseDataClass.setTheLinkCaseDataObject(this.linkCaseDataObject);
    }
  }

  //begin DSAMS-5833 DH 07/22
  onClickMilestoneNavigation() {
    if (this.areAllRequiredFieldsEntered()) {
      this.caseLineRelatedInfoData.user_CASE_ID = CaseUtils.formatUserCaseId(this.txtSearchCaseDetailsCase);
      this.caseRelatedInfoData.case_ID = this.caseRelatedInfoData.working_CASE_ID;
      this.caseRelatedInfoData.case_USAGE_INDICATOR_CD = this.txtDoc;
      this.caseRelatedInfoData.case_VERSION_ID = this.caseVersionFormControl.value;
      this.caseRelatedInfoData.working_CASE_VERSION_ID = this.caseVersionFormControl.value;
      this.caseRelatedInfoData.implementing_AGENCY_ID = '';
      this.caseRelatedInfoData.case_MASTER_STATUS_CD = this.txtVersion;
      this.caseUIService.setCaseRelatedInfoValues(this.caseRelatedInfoData);
      this.caseUIService.setCaseLineRelatedInfoValues(this.caseLineRelatedInfoData);
      this.router.navigate(['/case/milestone-dashboard'],
        {
          queryParams: {
            caseId: this.caseRelatedInfoData.case_ID,
            userCaseId: this.caseLineRelatedInfoData.user_CASE_ID,
            caseVersionId: this.caseRelatedInfoData.case_VERSION_ID,
            typeWithNumber: this.txtVersion,
            serviceDbId: CaseUtils.getServiceDatabaseId(),
          }
        });
    }
    else {
      MessageMgr.swalFire({
        html: 'All required fields must be entered.',
        icon: 'error',
        showConfirmButton: true,
        width: 400,
        focusConfirm: true,
        confirmButtonText: 'OK'
      })
    }
  }
  //end DSAMS-5833 DH 07/22

  onClickNoteNavigation() {


    if (this.areAllRequiredFieldsEntered()) {
      this.caseLineRelatedInfoData.user_CASE_ID = CaseUtils.formatUserCaseId(this.txtSearchCaseDetailsCase);
      this.caseRelatedInfoData.case_ID = this.caseRelatedInfoData.working_CASE_ID;
      this.caseRelatedInfoData.case_USAGE_INDICATOR_CD = this.txtDoc;
      this.caseRelatedInfoData.case_VERSION_ID = this.caseVersionFormControl.value;
      this.caseRelatedInfoData.implementing_AGENCY_ID = '';
      this.caseRelatedInfoData.working_CASE_VERSION_ID = this.caseVersionFormControl.value;
      this.caseUIService.setCaseRelatedInfoValues(this.caseRelatedInfoData);
      this.caseUIService.setCaseLineRelatedInfoValues(this.caseLineRelatedInfoData);
      this.caseUIService.noteListNav.next(false);  // Make sure edit toggle starts in the off position.
      // this.caseUIService.caseDetailSelected.next(caseRequestParamsType);
      this.router.navigate(['/case/note-dashboard']);

    } else {
      MessageMgr.swalFire({
        html: 'All required fields must be entered.',
        icon: 'error',
        showConfirmButton: true,
        width: 400,
        focusConfirm: true,
        confirmButtonText: 'OK'
      })
    }

  }

  onClickAttachmentNavigation() {
    if (this.areAllRequiredFieldsEntered()) {
      console.log("test");
      this.caseLineRelatedInfoData.user_CASE_ID = CaseUtils.formatUserCaseId(this.txtSearchCaseDetailsCase);
      this.caseRelatedInfoData.case_ID = this.caseRelatedInfoData.working_CASE_ID;
      this.caseRelatedInfoData.case_USAGE_INDICATOR_CD = this.txtDoc;
      this.caseRelatedInfoData.case_VERSION_ID = this.caseVersionFormControl.value;
      this.caseRelatedInfoData.implementing_AGENCY_ID = '';
      this.caseRelatedInfoData.working_CASE_VERSION_ID = this.caseVersionFormControl.value;
      this.caseRelatedInfoData.case_MASTER_STATUS_CD = this.txtVersion;


      this.caseUIService.setCaseRelatedInfoValues(this.caseRelatedInfoData);
      this.caseUIService.setCaseLineRelatedInfoValues(this.caseLineRelatedInfoData);
      this.caseUIService.noteListNav.next(false);  // Make sure edit toggle starts in the off position.
      this.router.navigate(['/case/attachments-dashboard']);
    } else {
      MessageMgr.swalFire({
        html: 'All required fields must be entered.',
        icon: 'error',
        showConfirmButton: true,
        width: 400,
        focusConfirm: true,
        confirmButtonText: 'OK'
      })
    }

  }
  onClickRemarkNavigation() {
    if (this.areAllRequiredFieldsEntered()) {
      this.caseLineRelatedInfoData.user_CASE_ID = CaseUtils.formatUserCaseId(this.txtSearchCaseDetailsCase);
      this.caseRelatedInfoData.case_ID = this.caseRelatedInfoData.working_CASE_ID;
      this.caseRelatedInfoData.case_USAGE_INDICATOR_CD = this.txtDoc;
      this.caseRelatedInfoData.case_VERSION_ID = this.caseVersionFormControl.value;
      this.caseRelatedInfoData.implementing_AGENCY_ID = '';
      this.caseRelatedInfoData.working_CASE_VERSION_ID = this.caseVersionFormControl.value;
      this.caseRelatedInfoData.case_MASTER_STATUS_CD = this.txtVersion;

      this.caseUIService.setCaseRelatedInfoValues(this.caseRelatedInfoData);
      this.caseUIService.setCaseLineRelatedInfoValues(this.caseLineRelatedInfoData);
      this.caseUIService.noteListNav.next(false);
      this.router.navigate(['/case/remarks-dashboard']);
    } else {
      MessageMgr.swalFire({
        html: 'All required fields must be entered.',
        icon: 'error',
        showConfirmButton: true,
        width: 400,
        focusConfirm: true,
        confirmButtonText: 'OK'
      })
    }
  }
  postSaveForNewCase(pSaveResult: ICaseVersion) {
    this.CaseId = pSaveResult.case_ID;
    this.CaseVersionId = pSaveResult.case_VERSION_ID;
    this.caseHeaderData['case_VERSION_NUMBER_ID'] = pSaveResult.case_VERSION_NUMBER_ID;
    this.caseHeaderData['customer_ORGANIZATION_ID'] = pSaveResult.customer_ORGANIZATION_ID;
    let linkCaseDataObject: LinkCaseDataIface = {
      serviceDbId: CaseUtils.getServiceDatabaseId(),
      case_VERSION_ID: pSaveResult.case_VERSION_ID,
      case_VERSION_STATUS_CD: pSaveResult.case_VERSION_STATUS_CD,
      user_CASE_ID: this.caseHeaderData["user_CASE_ID"],
      case_ID: pSaveResult.case_ID,
      case_USAGE_INDICATOR_CD: this.caseHeaderData["case_USAGE_INDICATOR_CD"]
    }
    localStorage.setItem(LinkCaseDataClass.linkCaseVersionInfoData, LinkCaseDataClass.setTheLinkCaseDataObject(linkCaseDataObject))
    this.caseUIService.theComponentSaveState[CaseUIService.SAVE_CASE_DETAILS_STATE].isDataChanged = false;
  }
  
  setPanelStateForSave(pValue:string){
    if (pValue===this.beforeSaveStr){
      this.panelOpenState[2]=this.panelOpenState2;
      this.panelOpenState[3]=this.panelOpenState3;
      this.panelOpenState[4]=this.panelOpenState4;
      this.panelOpenState[5]=this.panelOpenState5;
      this.panelOpenState[6]=this.panelOpenState6;
      this.panelOpenState[7]=this.panelOpenState7;
      this.panelOpenState[8]=this.panelOpenState8;
      this.panelOpenState2=true;
      this.notifyPanel(this.caseCustRequestPanelStr,this.panelOpenState2,false);
      this.panelOpenState3=true;
      this.notifyPanel(this.caseDocReqPanelStr,this.panelOpenState3,false);
      this.panelOpenState4=true;
      this.notifyPanel(this.caseDescPanelStr,this.panelOpenState4,false);
      this.panelOpenState5=true;
      this.notifyPanel(this.caseSignatoriesPanelStr,this.panelOpenState5,false);
      this.panelOpenState6=true;
      this.notifyPanel(this.caseAssocPanelStr,this.panelOpenState6,false);
      this.panelOpenState7=true;
      this.notifyPanel(this.caseWaiversPanelStr,this.panelOpenState7,false);
   //for mod funding panel needs closed until save is fixed
      this.panelOpenState8=false;
      this.notifyPanel(this.caseModFundingPanelStr,this.panelOpenState8,false);
    }
    if  (pValue===this.afterSaveStr) {
     this.panelOpenState2=this.panelOpenState[2];
     this.notifyPanel(this.caseCustRequestPanelStr,this.panelOpenState2,false);
     this.panelOpenState3=this.panelOpenState[3];
     this.notifyPanel(this.caseDocReqPanelStr,this.panelOpenState3,false);
     this.panelOpenState4=this.panelOpenState[4];
     this.notifyPanel(this.caseDescPanelStr,this.panelOpenState4,false);
     this.panelOpenState5=this.panelOpenState[5];
     this.notifyPanel(this.caseSignatoriesPanelStr,this.panelOpenState5,false);
     this.panelOpenState6=this.panelOpenState[6];
     this.notifyPanel(this.caseAssocPanelStr,this.panelOpenState6,false);
     this.panelOpenState7=this.panelOpenState[7];
     this.notifyPanel(this.caseWaiversPanelStr,this.panelOpenState7,false);
     this.panelOpenState8=this.panelOpenState[8];
     this.notifyPanel(this.caseModFundingPanelStr,this.panelOpenState8,false);
    }
    
  }


 }