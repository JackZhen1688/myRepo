import { Component, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { CaseRestfulService } from '../../services/case-restful.service';
import swal from 'sweetalert2';
import { FormControl } from '@angular/forms';
import { Subscription } from 'rxjs';
import { CaseUIService } from '../../services/case-ui-service';
import { CaseAmendModChangeInfo } from '../../model/case-amend-mod-change-info';

@Component({
  selector: 'app-case-amendmod-number',
  templateUrl: './case-amendmod-number.component.html',
  styleUrls: ['./case-amendmod-number.component.css']
})

export class CaseAmendModNumberComponent {
 
  nameFormControl: FormControl = new FormControl();
  _amendModSubscription: Subscription;

  constructor(private caseRestService: CaseRestfulService,
    public dialogRef: MatDialogRef<CaseAmendModNumberComponent>,
    @Inject(MAT_DIALOG_DATA) public data: { typeCd: string, verNumId: number, caseId: number, versionId: number},
    private caseUIService: CaseUIService) { }

    ngOnDestroy(){
      if (this._amendModSubscription){
        this._amendModSubscription.unsubscribe();
      }
    }

  public getDialogData(): any {
    return this.data;
  }

  onNoclick(): void {
    this.dialogRef.close();
  }

  getCaseAmendModFromLegacy(caseId: number, caseVersionId: number, typeCd: string, verNumId: number): void {
    this._amendModSubscription = this.caseRestService
      .getCaseAmendModLegacy(caseId, caseVersionId, typeCd, verNumId).subscribe((result) => {
        if (result && result.case_ID > 0) {
          this.showExistsDialog();
        }else{
          this.caseUIService.optionSelectedUCAM.next(true);
          this.savedDialog();
          this.XcloseDialog();
        }
      })
    }
      
  XcloseDialog(): void {
    this.dialogRef.close();
   // begin DSAMS-5907 09/22 DB
   this.caseUIService.setNotifyToSetDefaultOption(true);
  // end DSAMS-5907 09/22 DB
  }
  
  completeDialog(): void {
    this.dialogRef.close();
  }

  cancelDialog(): void {
    this.caseUIService.optionSelectedUCAM.next(false);
    this.dialogRef.close();
       // begin DSAMS-5907 09/22 DB
   this.caseUIService.setNotifyToSetDefaultOption(true);
   // end DSAMS-5907 09/22 DB
  }

  saveDialog(): void {
    this.getCaseAmendModFromLegacy(
        this.data.caseId, 
        this.data.versionId, 
        this.data.typeCd, 
        this.data.verNumId);
    }

    showExistsDialog() {
      swal.fire({
        title: this.data.verNumId+" Is not unique. To continue \'New\' processing, enter a different "+
        "value. To continue \'Open\' processing, use the pop option for selection.",
        icon: 'warning',
        showCancelButton: false,
        cancelButtonText: 'No',
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'OK'
      });
    }
  
  savedDialog() {
    swal.fire({
      title: this.data.verNumId+" Case Number is Valid, Click SAVE Button to Finish",
      icon: 'success',
      showCancelButton: false,
      cancelButtonText: 'No',
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'SAVE'
    });
    // Publish the amendment/mod change details.
    const amInfo:CaseAmendModChangeInfo = 
        { typeCd: this.data.typeCd,
          caseId: this.data.caseId,
          verNumId: this.data.verNumId,
          versionId: this.data.versionId
        };
    this.caseUIService.optionSelectedUCAM.next(false);
    this.caseUIService.caseAmendModChange.next(amInfo);
  }
}
