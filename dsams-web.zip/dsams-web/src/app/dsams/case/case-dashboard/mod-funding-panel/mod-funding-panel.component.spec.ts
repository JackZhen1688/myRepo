import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ModFundingPanelComponent } from './mod-funding-panel.component';

describe('ModFundingPanelComponent', () => {
  let component: ModFundingPanelComponent;
  let fixture: ComponentFixture<ModFundingPanelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ModFundingPanelComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ModFundingPanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
