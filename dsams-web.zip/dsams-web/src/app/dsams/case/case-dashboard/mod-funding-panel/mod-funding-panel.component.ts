import { formatCurrency, formatDate } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { MatTableDataSource } from '@angular/material';
import { BehaviorSubject, Subscription } from 'rxjs';
import { DsamsConstants } from 'src/app/dsams/dsams.constants';
import { DsamsMethodsService } from 'src/app/dsams/services/dsams-methods.service';
import { PopCaseAssociationComponent } from 'src/app/dsams/utilitis/popups/pop-case-association/pop-case-association.component';
import { TextAreaComponent } from '../../dialogs/text-area/text-area.component';
import { CaseRelatedInfoType } from '../../model/case-related-info-type';
import { ICaseMaster } from '../../model/dto/icase-master';
import { ICaseVersion } from '../../model/dto/icase-version';
import { IEditResponseType } from '../../model/edit-response-type';
import { PanelExpansionProperties } from '../../model/panel-expansion-properties';
import { CaseRestfulService } from '../../services/case-restful.service';
import { CaseUIService } from '../../services/case-ui-service';
import { CaseUtils } from '../../utils/case-utils';
import { CaseModFundingValidator } from '../../validation/case-modfunding-validator';
import { MessageMgr } from '../../validation/message-mgr';
import { SaveResultsType } from '../../validation/save-results-type';
import { ModFundingDto } from './model/dto/mod-funding-dto';
import { ICaseVersions, ModFundingModel, PrepareModFundingDataForSave } from './model/mod-funding-model';

@Component({
  selector: 'app-mod-funding-panel',
  templateUrl: './mod-funding-panel.component.html',
  styleUrls: ['./mod-funding-panel.component.css']
})
export class ModFundingPanelComponent implements OnInit {
  caseRelatedInfoData: CaseRelatedInfoType;
  private _caseUIServiceSubscription: Subscription = null;
  private _casePanelSubscription: Subscription = null;
  private _modFundingDataSubscription: Subscription = null;
  private _saveSubscription: Subscription = null;
  private _skipSavePanel: boolean = true;
  private _panelCollapedSubscription: Subscription = null;

  isLoading: BehaviorSubject<boolean> = new BehaviorSubject(false);
  dataSourceModFundingData: ModFundingDto[] = [];
  dataSorceModFundingModel: ModFundingModel[] = [];
  dataSourceMFTable = new MatTableDataSource<ModFundingModel>();
  isPanelEditable: boolean = false;
  isPRDisabled: boolean = true;
  prList: any = [
    { key: 'P', value: 'Providing' },
    { key: 'R', value: 'Receiving' }
  ]
  currentPR: string = '';
  implementedCaseValue: string;
  adjustedCaseValue: string = '0';
  versionDocNumList: any = [];
  paramCaseId: number = 0;
  paramCaseVersionId: number = 0;
  private _pnlExpansionProperties: PanelExpansionProperties;
  caseModFundingForm: FormGroup;
  private _editSubscription: Subscription = null;
  private _currentToggle: boolean = false;
  private _alreadyToggledOn: boolean = false;
  private _popupCaseSubscription: Subscription = null;
  rowIndex: number;
  adropdownCaseVersion: ICaseVersions;
  originalRowCount: number = 0;
  origAdjustedCV: number;
  adjustedCaseValueNum: number = 0;
  private _caseVersionDataSubscription: Subscription = null;
  addMFToSave: boolean = false;
  private _caseDetailDataSubscription: Subscription = null;

  constructor(private caseUIService: CaseUIService,
    private caseRestService: CaseRestfulService,
    public dsamsMethodsService: DsamsMethodsService) { }

  ngOnInit() {
    this._casePanelSubscription = this.caseUIService.panelExpanded.subscribe(
      {
        next: (pnlExpansionProperties: PanelExpansionProperties) => {
          if (pnlExpansionProperties.panelName === DsamsConstants.CASE_PANEL_MODFUNDING ||
            pnlExpansionProperties.panelName === DsamsConstants.CASE_PANEL_ALL) {
            this._pnlExpansionProperties = pnlExpansionProperties;
            this._caseUIServiceSubscription = this.caseUIService.getCaseRelatedInfoValues().subscribe((value) => {
              this.caseRelatedInfoData = value;
            });
            this.populateModFundingData();
            this.subscribeToCaseSelection();
            this.subscribeToEdit();
            this.subscribeToPanelCollapsed();
            this.subscribeToValidateOrSaveRequest();
            this._skipSavePanel = true;
            if (this._pnlExpansionProperties.isNewMode) {
              this._currentToggle = true;
              this.enableOrDisableEverything(this._currentToggle);
            }
          }
        }
      });

  }

  ngOnDestroy() {
    if (this._caseUIServiceSubscription) {
      this._caseUIServiceSubscription.unsubscribe();
      this._caseUIServiceSubscription = null;
    }

    if (this._saveSubscription) {
      this._saveSubscription.unsubscribe();
      this._saveSubscription = null;
    }

    if (this._casePanelSubscription) {
      this._casePanelSubscription.unsubscribe();
      this._casePanelSubscription = null;
    }

    if (this._panelCollapedSubscription) {
      this._panelCollapedSubscription.unsubscribe();
      this._panelCollapedSubscription = null;
    }
    if (this._popupCaseSubscription) {
      this._popupCaseSubscription.unsubscribe();
      this._popupCaseSubscription = null;
    }

    if (this._caseVersionDataSubscription) {
      this._caseVersionDataSubscription.unsubscribe();
      this._caseVersionDataSubscription = null;
    }

    if (this._caseDetailDataSubscription) {
      this._caseDetailDataSubscription.unsubscribe();
      this._caseDetailDataSubscription = null;
    }

  }

  //begin Jira DSAMS-5389 04/22 
  // Subcsribe to validate or save request.
  subscribeToValidateOrSaveRequest() {
    if (this._saveSubscription == null) {
      this._saveSubscription = this.caseUIService.saveRequest.subscribe((pSkipValidation: boolean) => {
        if (!this._skipSavePanel) {
          let svResults: SaveResultsType = this.savePanel(pSkipValidation);
          if (this.addMFToSave) {
            this.caseUIService.saveReturnRequest.next(svResults);
          }
        }
      });
    }
  }

  // Subscribe to panel collapsing // not sure if needed
  subscribeToPanelCollapsed() {
    if (!this._panelCollapedSubscription) {
      this._panelCollapedSubscription = this.caseUIService.panelCollapsed.subscribe((panelName: string) => {
        if (panelName === DsamsConstants.CASE_PANEL_MODFUNDING || panelName === DsamsConstants.CASE_PANEL_ALL) {
          this._skipSavePanel = true;
        }
      });
    }
  }

  // Subscribe to save
  savePanel(pSkipValidation: boolean): SaveResultsType {
    let currCaseId: number = 0;
    let currCaseVersionId: number = 0;
    let valResults: SaveResultsType = new SaveResultsType();
    valResults.currentPanel = DsamsConstants.CASE_PANEL_MODFUNDING;
    if (!pSkipValidation) {
      valResults = CaseModFundingValidator.validateModFundingPanel
        (this.dataSourceModFundingData,
          this._pnlExpansionProperties, []);
    }
    let svResults: SaveResultsType = new SaveResultsType();
    svResults.currentPanel = valResults.currentPanel;
    svResults.messageList = valResults.messageList;
    if (svResults.isValidationSuccessful()) {
      const defaultStatus: number = this._pnlExpansionProperties.isNewMode ? DsamsConstants.ENT_NEW : DsamsConstants.ENT_CHANGED;
      if (defaultStatus === DsamsConstants.ENT_CHANGED) {
        currCaseId = this._pnlExpansionProperties.caseRequestParams.caseId;
        currCaseVersionId = this._pnlExpansionProperties.caseRequestParams.caseVersionId;
      }
      let cvEntity: ICaseVersion = { status: defaultStatus };
      if (this.dataSourceModFundingData[0].relatedCaseVersionData.length > 0) {
        cvEntity.case_ID = currCaseId;
        cvEntity.case_VERSION_ID = currCaseVersionId;
        cvEntity.relatedCaseVersionList = new PrepareModFundingDataForSave(this.dataSourceModFundingData[0]).theCREntityList;
        if (cvEntity.relatedCaseVersionList.length > 0) {
          this.addMFToSave = true;
          svResults.caseVersionPanelData = cvEntity;
        }
      }
    }
    return svResults;
  }

  determineIfUserCanSave() {
    this.caseUIService.canSave.next(true);
  }
  //end Jira DSAMS-5389 04/22 

  populateModFundingData() {
    this.paramCaseVersionId = this.getParamCaseVersionId();

    if (!!this.caseRelatedInfoData) {
      this.paramCaseId = (this.caseRelatedInfoData.case_ID !== null) ? this.caseRelatedInfoData.case_ID : 0;
    }
    if (this.paramCaseId === 0 || this.paramCaseVersionId === 0) {
      return;
    }
    this.isLoading.next(true);
    this._modFundingDataSubscription =
      this.caseRestService.getCaseModFundingData(this.paramCaseId, this.paramCaseVersionId)
        .subscribe((values) => {
          if (values !== null) {
            let mfd: any;
            mfd = values;
            this.dataSourceModFundingData.push(mfd);
          }
          if (this.dataSourceModFundingData.length > 0) {
            if (this.dataSourceModFundingData[0].provideOrReceive === 'P') {
              this.currentPR = this.prList[0].key;
            } else {
              this.currentPR = this.prList[1].key;
            }
            this.implementedCaseValue = formatCurrency(Number(this.dataSourceModFundingData[0].implementedCaseValue), 'en', '$');
            this.adjustedCaseValueNum = Number(this.dataSourceModFundingData[0].adjustedCaseValue);
            this.adjustedCaseValue = formatCurrency(Number(this.dataSourceModFundingData[0].adjustedCaseValue), 'en', '$');
            this.origAdjustedCV = Number(this.dataSourceModFundingData[0].adjustedCaseValue);
          } else {
            this.currentPR = this.prList[0].key;
          }
          this.processDataSorceModFundingModel();
          this.dataSourceMFTable = new MatTableDataSource(this.dataSorceModFundingModel);
        },
          err => {
            CaseUtils.ReportHTTPError(err, "Getting Mod Funding Data");
            this.isLoading.next(false);
          });
    this.isLoading.next(false);
  }

  processDataSorceModFundingModel() {
    this.dataSorceModFundingModel = this.dataSourceModFundingData[0].relatedCaseVersionData;
    this.originalRowCount = this.dataSorceModFundingModel.length;
    if (this.dataSorceModFundingModel.length > 0) {
      for (let ii = 0; ii < this.dataSorceModFundingModel.length; ii++) {
        this.dataSorceModFundingModel[ii].status = DsamsConstants.ENT_UNCHANGED;
        let uCaseId = this.dataSorceModFundingModel[ii].user_CASE_ID;
        if (this.dataSorceModFundingModel[ii].case_VERSION_STATUS_DT !== null) {
          this.dataSorceModFundingModel[ii].case_VERSION_STATUS_DT = formatDate(this.dataSorceModFundingModel[ii].case_VERSION_STATUS_DT, 'MM/dd/yyyy', 'en-US');
          this.dataSorceModFundingModel[ii].user_CASE_ID = uCaseId.substring(0, 2) + '-' + uCaseId.substring(2, 3) + '-' + uCaseId.substring(3);
        }
        this.dataSorceModFundingModel[ii].orig_RELATED_AM = Number(this.dataSorceModFundingModel[ii].related_VERSION_FUNDING_AM);
      }
    } else {
      this.currentPR = this.prList[0].key;
    }
  }
  popupCaseSearch(elementName: string, pElement: any): void {
    this.rowIndex = this.dataSorceModFundingModel.indexOf(pElement);
    let diaWidth: string = "70%";
    let diaHeight: string = "70%";
    let passingData: string = "";

    this.dsamsMethodsService.openSearchDialogCase(diaWidth, diaHeight, passingData, PopCaseAssociationComponent, this.caseModFundingForm, elementName);
  }
  addRow() {
    if (this.currentPR === '') {
      MessageMgr.displayErrorMessage("The Parent Case should be either Providing or Receiving funds");
      return;
    }
    const anItemObject: ModFundingModel = {
      entityName: "RELATED_CASE_VERSION",
      status: DsamsConstants.ENT_NEW,
      theGettingCaseVersionId: 0,
      theProvidingCaseVersionId: 0,
      case_VERSION_NUMBER: null,
      user_CASE_ID: null,
      case_VERSION_STATUS_CD: null,
      case_VERSION_STATUS_DT: null,
      case_DESCRIPTION_TX: null,
      getting_CASE_VERSION_ID: 0,
      providing_CASE_ID: 0,
      providing_CASE_VERSION_ID: 0,
      related_VERSION_FUNDING_AM: '',
      getting_CASE_ID: 0,
      new_row: true,
      dropdownCaseVersions: [],
      orig_RELATED_AM: 0,
      delete_visible: true
    };
    this.dataSorceModFundingModel.push(anItemObject);
    this.dataSourceMFTable = new MatTableDataSource(this.dataSorceModFundingModel);
    this.caseUIService.theComponentSaveState[CaseUIService.SAVE_CASE_DETAILS_STATE].isDataChanged = true; 
  }

  displayModFundingColumns = ['user_CASE_ID', 'case_VERSION_NUMBER', 'case_VERSION_STATUS_CD', 'case_VERSION_STATUS_DT', 'case_DESCRIPTION_TX', 'related_VERSION_FUNDING_AM', 'DeleteRow'];
  displayColumnsFooter = ['AddRow'];

  changeVersionNum(pValue: any, pElement: any) {
    let selectedCaseVersion: ICaseVersions[];
    let rowNum = this.dataSorceModFundingModel.indexOf(pElement);
    selectedCaseVersion = this.dataSorceModFundingModel[rowNum].dropdownCaseVersions.filter(dlist => { return dlist.value === pValue.value });
    this.dataSorceModFundingModel[rowNum].case_VERSION_NUMBER = selectedCaseVersion[0].viewValue;
    if (this.checkForDupRow()) {
      MessageMgr.displayErrorMessage("Related Case Id and Version/Doc Number already found");
      return;
    }
    this.dataSorceModFundingModel[rowNum].case_VERSION_STATUS_CD = selectedCaseVersion[0].case_VERSION_STATUS_CD;
    this.dataSorceModFundingModel[rowNum].case_VERSION_STATUS_DT = selectedCaseVersion[0].case_VERSION_STATUS_DT;
    this.dataSorceModFundingModel[rowNum].case_DESCRIPTION_TX = selectedCaseVersion[0].case_DESCRIPTION_TX;
    if (this.currentPR === 'P') {
      this.dataSorceModFundingModel[rowNum].getting_CASE_ID = this.paramCaseId;
      this.dataSorceModFundingModel[rowNum].getting_CASE_VERSION_ID = this.paramCaseVersionId;
      this.dataSorceModFundingModel[rowNum].providing_CASE_ID = selectedCaseVersion[0].case_ID;
      this.dataSorceModFundingModel[rowNum].providing_CASE_VERSION_ID = parseInt(selectedCaseVersion[0].value);
    } else if (this.currentPR === 'R') {
      this.dataSorceModFundingModel[rowNum].getting_CASE_ID = selectedCaseVersion[0].case_ID;
      this.dataSorceModFundingModel[rowNum].getting_CASE_VERSION_ID = parseInt(selectedCaseVersion[0].value);
      this.dataSorceModFundingModel[rowNum].providing_CASE_ID = this.paramCaseId;
      this.dataSorceModFundingModel[rowNum].providing_CASE_VERSION_ID = this.paramCaseVersionId;
    }

    this._caseDetailDataSubscription = this.caseRestService
      .getCaseDetailLegacy(selectedCaseVersion[0].case_ID, parseInt(selectedCaseVersion[0].value))
      .subscribe(
        data => {
          if (data) {
            if (data.case_VERSION_STATUS_DT !== null) {
              this.dataSorceModFundingModel[rowNum].case_VERSION_STATUS_DT = formatDate(data.case_VERSION_STATUS_DT, 'MM/dd/yyyy', 'en-US');
            }
            this.dataSorceModFundingModel[rowNum].case_DESCRIPTION_TX = data.case_VERSION_DESCRIPTION_TX;
          }
        },
        err => {
          CaseUtils.ReportHTTPError(err, "Loading Case Info Legacy");
        }
      );
    this.dataSourceMFTable = new MatTableDataSource(this.dataSorceModFundingModel);

  }

  setPRChanged(pValue: any) {
    switch (pValue) {
      case 'P': {
        this.currentPR = this.prList[0].key;
        this.changeAdjustedValue(this.currentPR);
        break;
      }
      case 'R': {
        this.currentPR = this.prList[1].key;
        this.changeAdjustedValue(this.currentPR);
        break;
      }
    }
    this.dataSourceModFundingData[0].provideOrReceive = pValue;
  }

  setChanged(index: number) {
    let modAdjValue: number = 0;
    let newAdjValue: number = 0;
    const editResp: IEditResponseType = { ID: DsamsConstants.PAGE_CASE_DETAIL, editToggle: true };
    this.caseUIService.hasEditBeenMadeService.next(editResp);
    if (!!this.dataSorceModFundingModel[index]) {
      if (this.dataSorceModFundingModel[index].status == DsamsConstants.ENT_UNCHANGED) {
        this.dataSorceModFundingModel[index].status = DsamsConstants.ENT_CHANGED;
        this.caseUIService.theComponentSaveState[CaseUIService.SAVE_CASE_DETAILS_STATE].isDataChanged = true; 
      }
    }
    modAdjValue = Number(this.dataSorceModFundingModel[index].related_VERSION_FUNDING_AM) -
      this.dataSorceModFundingModel[index].orig_RELATED_AM;
    if (this.currentPR === 'P') {
      newAdjValue = this.adjustedCaseValueNum - modAdjValue;
    } else {
      newAdjValue = this.adjustedCaseValueNum + modAdjValue;
    }
    this.dataSorceModFundingModel[index].orig_RELATED_AM =
      Number(this.dataSorceModFundingModel[index].related_VERSION_FUNDING_AM);
    this.adjustedCaseValueNum = newAdjValue;
    this.adjustedCaseValue = formatCurrency(newAdjValue, 'en', '$');   
  }

  yesButtonOnClick(isDeleteConfirmed: any, rowElement: any) {
    if (isDeleteConfirmed)
      this.deleteItem(rowElement);
  }
  deleteItem(rowElement: any) {
    let rowIndex = this.dataSorceModFundingModel.indexOf(rowElement);
    this.dataSorceModFundingModel.splice(rowIndex, 1);

    this.dataSourceMFTable = new MatTableDataSource(this.dataSorceModFundingModel);
    this.dataSourceMFTable._updateChangeSubscription();
    this.caseUIService.theComponentSaveState[CaseUIService.SAVE_CASE_DETAILS_STATE].isDataChanged = true;
  }

  getParamCaseVersionId(): number {
    let returnId: number = 0;
    if (!!this.caseRelatedInfoData) {
      if (!!this.caseRelatedInfoData.case_VERSION_ID) {
        returnId = parseInt(this.caseRelatedInfoData.case_VERSION_ID);
      }
      if (!!this.caseRelatedInfoData.working_CASE_VERSION_ID && returnId === 0) {
        returnId = this.caseRelatedInfoData.working_CASE_VERSION_ID;
      }
    }
    return returnId;
  }
  subscribeToEdit() {
    if (!this._editSubscription) {
      this._editSubscription = this.caseUIService
        .caseEditService
        .subscribe((pResponse: IEditResponseType) => {
          if (pResponse && (pResponse.ID === DsamsConstants.CASE_VERSION_EDITOR || pResponse.ID === DsamsConstants.PAGE_CASE_DETAIL)) {

            this.enableOrDisableEverything(pResponse.editToggle);
            this.showOrHideDelete(pResponse.editToggle);
            this._currentToggle = pResponse.editToggle;
            if (this._currentToggle) {
              this._alreadyToggledOn = true;
            }
            this.dataSourceMFTable = new MatTableDataSource(this.dataSorceModFundingModel);
          }
        },
          err => {
            CaseUtils.ReporError("Error in mod funding responding to edit toggle");
          }
        );
    }
  }
  enableOrDisableEverything(pEdit: boolean) {
    this.isPanelEditable = pEdit;
    if (pEdit && this.originalRowCount === 0) {
      this.isPRDisabled = false;
    }
    if (!pEdit) {
      this.isPRDisabled = true;
    }
  }

  showOrHideDelete(pEdit: boolean) {
    for (let ii = 0; ii < this.dataSorceModFundingModel.length; ii++) {
      if (this.dataSorceModFundingModel[ii].new_row) {
        this.dataSorceModFundingModel[ii].delete_visible = pEdit;
      }
    }
  }

  subscribeToCaseSelection() {
    if (this._popupCaseSubscription == null) {
      this._popupCaseSubscription = this.dsamsMethodsService
        .selectedMFCaseFromPopup
        .subscribe((selectedVal: ICaseMaster) => {
          if (selectedVal) {
            this.dataSorceModFundingModel[this.rowIndex].user_CASE_ID = selectedVal.user_CASE_ID;
            for (let jj = 0; jj < selectedVal.caseVersionList.length; jj++) {
              if (selectedVal.caseVersionList[jj].case_VERSION_TYPE_CD === 'M' &&
                selectedVal.caseVersionList[jj].case_VERSION_STATUS_CD === 'D') {

                this.adropdownCaseVersion = { value: 'A', viewValue: 'A', case_ID: 0, case_VERSION_STATUS_CD: '', case_VERSION_STATUS_DT: '', case_DESCRIPTION_TX: '' };
                this.adropdownCaseVersion.value = selectedVal.caseVersionList[jj].case_VERSION_ID.toString();
                this.adropdownCaseVersion.viewValue = selectedVal.caseVersionList[jj].case_VERSION_TYPE_CD +
                  selectedVal.caseVersionList[jj].case_VERSION_NUMBER_ID;
                this.adropdownCaseVersion.case_ID = selectedVal.caseVersionList[jj].case_ID;
                this.adropdownCaseVersion.case_VERSION_STATUS_CD = selectedVal.caseVersionList[jj].case_VERSION_STATUS_CD;
                this.adropdownCaseVersion.case_VERSION_STATUS_DT = selectedVal.caseVersionList[jj].case_VERSION_STATUS_DT.toString();
                this.adropdownCaseVersion.case_DESCRIPTION_TX = selectedVal.caseVersionList[jj].case_VERSION_DESCRIPTION_TX;

                this.dataSorceModFundingModel[this.rowIndex].dropdownCaseVersions.push(this.adropdownCaseVersion);
              }
            }
            this.dataSourceMFTable = new MatTableDataSource(this.dataSorceModFundingModel);
          }

        },
          err => {
            CaseUtils.ReporError("Error in dsamsMethodsService.popupICaseMaster in mod funding");
          }
        );
    }
  }
  getRowVNum(pElement: any): ICaseVersions[] {
    let rIndex = this.dataSorceModFundingModel.indexOf(pElement);
    return this.dataSorceModFundingModel[rIndex].dropdownCaseVersions;
  }

  unFormatReleatedAM(elementValue: string | number, i: number): number {
    this.dataSorceModFundingModel[i].related_VERSION_FUNDING_AM = CaseUtils.unformatCurrency(elementValue).toString();
    return CaseUtils.unformatCurrency(elementValue);
  }

  changeAdjustedValue(pValue: string) {
    let totalAdjValue: number = 0;
    for (let i = 0; i < this.dataSorceModFundingModel.length; i++) {
      totalAdjValue += Number(this.dataSorceModFundingModel[i].related_VERSION_FUNDING_AM);
    }
    if (pValue === 'P') {
      totalAdjValue = totalAdjValue * -1;
    }
    this.adjustedCaseValueNum = totalAdjValue;
    this.adjustedCaseValue = formatCurrency(totalAdjValue, 'en', '$');
  }

  checkForDupRow(): boolean {
    let dupFound: boolean = false;
    for (let i = 0; i < this.dataSorceModFundingModel.length; i++) {
      let currUserCaseId: string = this.dataSorceModFundingModel[i].user_CASE_ID;
      let currCaseVersionNum: string = this.dataSorceModFundingModel[i].case_VERSION_NUMBER;
      let filteredData = this.dataSorceModFundingModel.filter(flist => { return flist.user_CASE_ID === currUserCaseId && flist.case_VERSION_NUMBER === currCaseVersionNum });
      if (filteredData.length > 1) {
        dupFound = true;
      }
    }
    return dupFound;
  }
  popupDescText(pElement: any): void {
    let rowNum = this.dataSorceModFundingModel.indexOf(pElement);
    let diaWidth: string = "50%";
    let diaHeight: string = "60%";
    let passingData: string = pElement.case_DESCRIPTION_TX;
    let pTitle: string = "Mod Funding Description";
    this.dsamsMethodsService.openTextAreaIpcDialog(diaWidth, diaHeight, passingData,
      TextAreaComponent, rowNum.toString(), pTitle, true);
  }
}
