import { DsamsConstants } from "src/app/dsams/dsams.constants";
import { ISelectOptions } from "src/app/dsams/interfaces/i-select-options";
import { ICaseVersion } from "../../../model/dto/icase-version";
import { ModFundingDto } from "./dto/mod-funding-dto";

export interface ModFundingModel {
  entityName?: string,
  status?: number,
  theGettingCaseVersionId?: number,
  theProvidingCaseVersionId?: number,
  case_VERSION_NUMBER?: string,
  user_CASE_ID?: string,
  case_VERSION_STATUS_CD?: string,
  case_VERSION_STATUS_DT?: string,
  case_DESCRIPTION_TX?: string,
  getting_CASE_ID?: number,
  getting_CASE_VERSION_ID?: number,
  providing_CASE_ID?: number,
  providing_CASE_VERSION_ID?: number,
  related_VERSION_FUNDING_AM?: string,
   // last_UPDATE_USER_ID ?: string,
  // create_USER_ID ?: string,
  // create_DT ?: string,
  // last_UPDATE_DT ?: string
  new_row?: boolean,
  orig_RELATED_AM?:number,
  delete_visible?:boolean,
  dropdownCaseVersions?: ISelectOptions[];
  
 }

export interface ICaseVersions {
  value: string,
  viewValue: string,
  case_ID?: number,
  case_VERSION_STATUS_CD?: string,
  case_VERSION_STATUS_DT?: string,
  case_DESCRIPTION_TX?: string,
}

/** 
  * Prepare Mod Funding data for save
  * @Author: David Huynh
  * @Date: 04/27/2022
  * @Jira Card: 5389
*/
export class PrepareModFundingDataForSave {
  theCREntityList: ModFundingModel[] = [];
  aCREntity: ModFundingModel = {};
  constructor(pMFDto: ModFundingDto) {
    this.theCREntityList = [];
    this.aCREntity = {};
    pMFDto.relatedCaseVersionData.forEach(eachRCVDto => {
      if (!!eachRCVDto.status && eachRCVDto.status !== DsamsConstants.ENT_UNCHANGED) {
        this.aCREntity = {
          getting_CASE_ID: eachRCVDto.getting_CASE_ID,
          getting_CASE_VERSION_ID: eachRCVDto.getting_CASE_VERSION_ID,
          related_VERSION_FUNDING_AM: eachRCVDto.related_VERSION_FUNDING_AM,
          providing_CASE_ID: eachRCVDto.providing_CASE_ID,
          providing_CASE_VERSION_ID: eachRCVDto.providing_CASE_VERSION_ID,
          status: eachRCVDto.status,
          entityName: eachRCVDto.entityName,
        };
        this.theCREntityList.push(this.aCREntity);
      }
    })
  }
 }
