export interface CanDeactivateComponent {
    canDeactivate(): boolean;
  }
