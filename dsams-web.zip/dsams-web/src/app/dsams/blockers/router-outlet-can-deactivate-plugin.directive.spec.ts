import { RouterOutletCanDeactivatePluginDirective } from './router-outlet-can-deactivate-plugin.directive';

describe('RouterOutletCanDeactivatePluginDirective', () => {
  it('should create an instance', () => {
    const directive = new RouterOutletCanDeactivatePluginDirective();
    expect(directive).toBeTruthy();
  });
});
