import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReleaseTransactionsComponent } from './release-transactions.component';

describe('ReleaseTransactionsComponent', () => {
  let component: ReleaseTransactionsComponent;
  let fixture: ComponentFixture<ReleaseTransactionsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReleaseTransactionsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReleaseTransactionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
