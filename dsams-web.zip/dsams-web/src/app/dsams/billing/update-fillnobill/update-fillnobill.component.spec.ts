import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateFillnobillComponent } from './update-fillnobill.component';

describe('UpdateFillnobillComponent', () => {
  let component: UpdateFillnobillComponent;
  let fixture: ComponentFixture<UpdateFillnobillComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdateFillnobillComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateFillnobillComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
