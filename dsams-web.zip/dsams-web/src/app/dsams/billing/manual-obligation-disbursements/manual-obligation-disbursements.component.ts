import { Component, OnInit, OnDestroy,Injector, ViewChild } from '@angular/core';
import { ViewportScroller } from '@angular/common';
import { FormBuilder, FormControl } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { animate, state, style, transition, trigger } from '@angular/animations';
import {SuffixModd} from 'src/app/dsams/entities/specialEntities/suffix-modd.model';
import {TrnArmyMODDDocEntityData} from 'src/app/dsams/entities/specialEntities/trn-army-modd-doc-entity';
import { EntityStatus } from './../../enums/entity-status.enum';
import { ErrorParameter } from 'src/app/dsams/entities/specialEntities/error-parameter.model';
import { DsamsRestfulService } from './../../services/dsams-restful.service';
import { MessageBtnClicked} from './../../enums/user-message.enum';
import {  MatTable } from '@angular/material/table';
import {  MatDialog } from '@angular/material/dialog';
import { BUDGET_CONTROL } from 'src/app/dsams/entities/models/budget-control.model';
import { BUDGET_COMPONENT } from 'src/app/dsams/entities/models/budget-component.model';
import {TRAINING_TRACK_LINE} from 'src/app/dsams/entities/models/training-track-line.model';
import { ManageArmyBillingCycleBaseComponent,isNumeric } from '../run-new-cycle/manage-army-billing-cycle-base/manage-army-billing-cycle-base.component';
import { ImanageArmyBillingCycle } from './../interfaces/imanage-army-billing-cycle';
import { MatSlideToggle } from '@angular/material/slide-toggle';
import { ValidateCycleResults } from 'src/app/dsams/entities/specialEntities/validate-cycle-results.model';
import { Observable } from 'rxjs';





@Component({
  selector: 'app-manual-obligation-disbursements',
  templateUrl: './manual-obligation-disbursements.component.html',
  styleUrls: ['./manual-obligation-disbursements.component.css',
    './../billing-global.css'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0px', minHeight: '0' })),
      state('expanded', style({ height: '*' })),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})


export class ManualObligationDisbursementsComponent extends ManageArmyBillingCycleBaseComponent
  implements ImanageArmyBillingCycle, OnInit, OnDestroy {

  // WP105 Messages and variables specific to WP104
  m1Msg: string = "%1 cannot be saved because it is currently being processed by %2.";
  m2Msg: string = "%1 must have %2";
  m2aMsg: string = "The Cycle must have at least one Disbursement amount";
  m2bMsg: string = "Each Document included in the Cycle must have at least one Disbursement amount";
  m3Msg: string = "Passed validation. Click 'Proceed' to approve the cycle.";
  m4Msg = "%1 was successfully approved. %2";
  m5Msg: string = "Are you sure you want to delete this cycle? ";
  m6LTMsg: string = "The negative disbursement amount entered cannot exceed the amount previously disbursed ";
  m6GTMsg: string = "The total disbursement amount cannot exceed  cannot exceed amount obligated";
  // m7Msg: string = "The amount exceeds the obligation amount";
  // m8Msg: string = "The  previous amount + new amount ";
 
  WP118_SESSION_LOCK_ID: string = 'WP118_SESSION_LOCK_ID';
  cycleTitle = '';
  cycleUser = '';

  isEditable:boolean = true;

  displayedGfebsCase =
    ['fy', 'obligDocNo', 'wbsApc', 'case', 'line', 'wcn', 'suffix', 'collApc', 'eor', 'obligAm', 'prevDisbAm', 'actionAm', 'command'];

 
  expandedElement: null;
  //selectedCycle = "";
  // dataSourceCase = new MatTableDataSource();
  // dsBcnData = new MatTableDataSource();
  // @ViewChild('bcnTable', { static: false }) bcnTable: MatTable<BUDGET_CONTROL>;

  setViewMode() {
   
 
  
  }

  @ViewChild(MatTable, { static: false }) bcnTable: MatTable<BUDGET_CONTROL>;


  filterCase = new FormControl();
  filterLine = new FormControl();
  filterWcn = new FormControl();
  filterFy = new FormControl();
  filterSuffix = new FormControl();
  filterDocNum = new FormControl();
  private caseFilterValues = { case: '', line: '', wcn: '', suffix: '', fy: '', finStat: '', docNo: '', eor: '', exa: '', paymentType: '' };
 
  constructor(protected injector: Injector, 
              protected route: ActivatedRoute,
              protected dsamsReferenceService: DsamsRestfulService,
              public popUpDialog: MatDialog,
              protected formBuilder: FormBuilder,
              protected viewportScroller: ViewportScroller) 
  {
    super(injector, route, dsamsReferenceService, popUpDialog, formBuilder, viewportScroller);
  }
    

  ngOnInit() {
    console.log('init ManualObligationDisbursementsComponent');
    super.ngOnInit();
    this.dsamsShareService.csuname.next(this.route.snapshot.params['csu']);
    if (this.route.snapshot.params['cycleid'] != '0')
        this.dsamsShareService.breadcrumbForFundingHome.next('billing');
    this.dsBcnData.filterPredicate = this.suffixPostingFilterPredicate();
                                         
  }
  getCSU_CD():string { return "WP118"; }

  constructCyleForm() {
    this.cycleForm = this.formBuilder.group({
      disbursementAmount: this.formBuilder.control(''),
    });
  }

  suffixPostingFilterPredicate() {
    const thisFilterPredicate = function (data: BUDGET_CONTROL, filter: string): boolean {
      //  Case Line WCN Suffix Fy DocNbr FinStatus EXA
      let dataString: String = (data.fiscal_YEAR_ID == null) ? "" : data.fiscal_YEAR_ID;
      // console.log("search string = " + dataString);
      dataString = dataString.concat((data.moddDocNumberCd == null) ? "" : data.moddDocNumberCd);
      // console.log("search string = " + dataString);
      dataString = dataString.concat((data.wbsApcCd == null) ? "" : data.wbsApcCd);
      // console.log("search string = " + dataString);
      if (data.theTrainingTrackLineSeqCd != null) {
        let t1: TRAINING_TRACK_LINE = data.theTrainingTrackLineSeqCd;
        dataString = dataString.concat((t1.userCaseId == null) ? "" : t1.userCaseId);
        dataString = dataString.concat((t1.userCaseLineNumberId == null) ? "" : t1.userCaseLineNumberId);
        dataString = dataString.concat((t1.wcn == null) ? "" : t1.wcn);
        dataString = dataString.concat((t1.wcn_SUFFIX_CD == null) ? "" : t1.wcn_SUFFIX_CD);
        dataString = dataString.trim().toLocaleLowerCase();
     
      }
      console.log("search string = " + dataString);
      return dataString.indexOf(filter) !== -1;
    }
    return thisFilterPredicate;
  }


 
  // ImanageArmyBillingCycle override methods
  setEditMode() {
    console.log('obligation edit');
    let ccid: string = this.getTheCycleControlId();
    let obs = null;
    if (ccid.length > 1) {
      obs = this.getArmyBillingCycleDataWithNewSesionLock(ccid);
    }
    if (obs) {
      obs.subscribe(() => { console.log('subscribe success'); }, () => {
          console.log('subscribe fail');
          // this.intSetViewMode();
      });
  }
}

  @ViewChild('editSlider', { static: false }) editSlider: MatSlideToggle;
  getEditSlider(): MatSlideToggle {
    return this.editSlider;
  }
  // obsolete
  // closeLockSession() {
  //   let lockId = sessionStorage.getItem(this.WP105_SESSION_LOCK_ID);
  //   console.log("close WP105_SESSION_LOCK_ID = " + lockId);
  //   this.closeDbLockSession(this.WP105_SESSION_LOCK_ID);
  // }

  getComponentLockSessionId() {
    let lockId = sessionStorage.getItem(this.WP118_SESSION_LOCK_ID);
    if (lockId == null || lockId.length == 0) {
      lockId = '0';
    }
    console.log("WP105_SESSION_LOCK_ID = " + lockId);
    return lockId;
  }
 
  setComponentLockSessionId(lockId: string) {
    sessionStorage.setItem(this.WP118_SESSION_LOCK_ID, lockId);
  }
  
  
  getArmyBillingCycleIdList(cycleId: string) {
    super.getArmyBillingCycleIdsWithSelect("/armyModdCycle/cycleControlIdList", cycleId);
  }

  getNewArmyBillingCycle() {
    this.setCycleCaseUsageCd();
    this.setCycleTypeId();
    this.reimbursementService.emptyBillingTable();
    this.reimbursementService.addBillingRow();
    super.getNewArmyBillingCycleData("/armyModdCycle/newCycleControl");
   
  }

  getArmyBillingCycle(cycleId: string, lockId: string) {
    // let lockId: string = this.getComponentLockSessionId();
    if (cycleId != null && cycleId.length > 2) {
      super.getArmyBillingCycleData("/armyModdCycle/cycleControl", cycleId, lockId);
  
    } else {
      this.getNewArmyBillingCycle();
    }
  

  }

  saveArmyBillingCycle(): Observable<any> {
    let lockSessionId: string = this.getComponentLockSessionId();
    return super.saveArmyBillingCycleData("/armyModdCycle/saveCycle", lockSessionId);
  }
 
  
  approveArmyBillingCycle() {
    this.showSpinner.next(true);
    this.billingRestService.validateArmyMODDCycle(this.theCC)
      .subscribe(
        data => {
          let results: ValidateCycleResults = data;
        
          if (results.success == 1) {
            this.openProceedDialog("Approve Cycle", this.m3Msg).subscribe(result => {
              let btnClick: MessageBtnClicked = this.messageData.btnClicked;
              if (btnClick == MessageBtnClicked.ProceedClicked) {
                let lockId = this.getComponentLockSessionId();
                super.approveArmyModdBillingCycleData(this.theCC, lockId);
              
              } else
                if (results.messageList.length > 0) {
                  this.displayMessages(results.messageList);
                  this.showSpinner.next(false);
                }
           //   this.showSpinner.next(false);
            }
           
              , err => {
                this.showSpinner.next(false);
                this.handleError("", err);
         
              });
          }
        }
          , err => {
            this.showSpinner.next(false);
            this.handleError("", err);
     
         });
  }


  validateModdCycle() {
    this.showSpinner.next(true);
    this.billingRestService.	validateArmyMODDCycle(this.theCC )
     .subscribe(
       data => {
        this.showSpinner.next(false);
          let results: ValidateCycleResults = data;
         if (results != null && results.messageList.length > 0) {
           this.displayMessages(results.messageList);
         } else
           if (results.success = 1 ) {
             this.displaySnackBarMessage("Cycle " + this.theCC.cycle_CONTROL_ID + " has been validated.", false);
             // this.DisplayInformationMessage("Approve Cycle", "Cycle " + this.theCC.cycle_CONTROL_ID + " has been approved.")
             // .subscribe(result => {

          //  let id: number = 0;
         //  this.router.navigate(['/billing/mangemanual', id.toString()]);
          
             //  });
           } else {
             this.displayErrorMessage("Validate  Cycle", "Validation has failed for Cycle " + this.theCC.cycle_CONTROL_ID)
               .subscribe(result => {
                  console.log("Validate Cycle cancelled, cycle data not saved");
               });
           }
         
       },
       err => {
         this.handleError("", err);
      
       });

}


deleteArmyBillingCycle() {
  let cycleId: string = this.theCC.cycle_CONTROL_ID.toString();
  let cycleTypeId : string = this.theCC.cycle_CONTROL_TYPE_ID.toString();
  super.deleteArmyModdBillingCycleData(cycleId, cycleTypeId);
  
    }  

 
    validateForSaveCycle(): boolean{
      let messageList: ErrorParameter[] = new Array<ErrorParameter>();
  if (this.theCC.budgetControlList != null) {
    this.theCC.budgetControlList.forEach(bcn => {
      if (bcn.status != EntityStatus.ENT_DELETED) {
        if (this.calculateBcnSaveAmount(bcn, messageList) == 0) {
          messageList.push(new ErrorParameter("Error",
            'Amounts', this.getBcnSuffixString(bcn).toString(), this.m2aMsg));
        }
      }
    });
  }
  if (messageList.length == 0) {
    return true;
  }else{
    this.displayUserErrorMessages(messageList)
    return false;
  }
  }
  
  calculateBcnSaveAmount(bcn: BUDGET_CONTROL, messageList: ErrorParameter[]): number {
    let totalBcnAmt: number = 0;
    if (bcn.budgetComponentList != null) {
      bcn.budgetComponentList.forEach(bcx => {
        totalBcnAmt = totalBcnAmt + Number(bcx.wm_PREV_EXTERNAL_REIMB_AM) + Number(bcx.action_AM);
        let errorMsg: string = this.validateDisbursementAmount(bcx.action_AM, bcx.wm_PREV_DISB_AM, bcx.wm_OBLIGATION_AM);
        if (errorMsg.length > 0) {
          let bcxRef: string = this.getBcnSuffixString(bcn) + "/" + bcx.theCollectAccountLineSeqCd.wm_APC_CD;
          messageList.push(new ErrorParameter("Error", 'Amounts', bcxRef, errorMsg));
        }
       
      });
    }

    
  return totalBcnAmt;
  }
  
  validateAmountEntered(event: any, row: BUDGET_COMPONENT) {
    console.log("oldAMount = " + row.action_AM);
    let amtString: string = event.target.value;
    if (isNumeric(amtString)) {
      let actionAm: number = Number(amtString);
      let errorMsg: string = this.validateDisbursementAmount(actionAm, row.wm_PREV_DISB_AM,row.wm_OBLIGATION_AM);
        if (errorMsg.length > 0){
      
        this.displayErrorMessage("Invalid Amount", errorMsg)
        .subscribe(result => {
          console.log(errorMsg);
      
        });
      }
        this.markBcxAmountForUpdate(event, row);
     
    }
    
 }



  validateDisbursementAmount(actionAm: number, prevDisbAm: number, obligAm: number): string {
    console.log("actionAm: " + actionAm + ", prevDisbAm: " + prevDisbAm + ", obligAm: " + obligAm);
    let totalAmount: number = actionAm + prevDisbAm;
    let errorMsg: string = "";
    if (totalAmount < 0) {
      errorMsg = this.m6LTMsg;
    } else if (totalAmount > obligAm) {
      errorMsg = this.m6GTMsg;
    }
    return errorMsg
  }
  

          
  validateForApproveCycle(): boolean {
    return true;  // validation will be peformed in back end before approving
    // let messageList: ErrorParameter[] = new Array<ErrorParameter>();
    // if (this.theCC.budgetControlList != null) {
    //   this.theCC.budgetControlList.forEach(bcn => {
    //     if (bcn.status != EntityStatus.ENT_DELETED) {
    //       this.validateBcnDovNumbers(bcn, messageList);
    //     }
    //   });
    //   if (messageList.length == 0) {
    //     console.log("validateForApproveCycle() true");
    //     return true;
    //   } else {
    //     console.log("validateForApproveCycle() false ");
    //     this.displayUserErrorMessages(messageList)
    //     return false;
    //   }
    // }
 
}


  
  setNoCycleSelected() {
    console.log("setNoCycleSelected()");
  this.isDisabledApprovebutton = true;
  this.isDisabledDeletebutton = true;
  this.isDisabledSavebutton = true;
  this.isDisabledGenDOVbutton = true;
  }
  
setCycleDataLoaded() {
    // this.setBudgetControlsFcArray(this.theCC.budgetControlList);
  if (this.theCC.cycle_CONTROL_ID != this.lastCycleLoaded ) {
    this.isDisabledApprovebutton = true;
      this.isDisabledDeletebutton = true;
      this.isDisabledSavebutton = true;
      this.isDisabledGenDOVbutton = true;
    this.cycleUser = this.theCC.create_USER_ID + "  " + this.theCC.createUserName;
    this.setService(this.theCC.case_USAGE_INDICATOR_CD);
    console.log("theCC.cycle_TITLE_NM = " + this.theCC.cycle_TITLE_NM);
    this.lastCycleLoaded = this.theCC.cycle_CONTROL_ID;
    this.isEditMode = false;
    this.closeLockSession();
  }
  this.cycleUser = this.theCC.create_USER_ID + "  " + this.theCC.createUserName;
    this.setService(this.theCC.case_USAGE_INDICATOR_CD);
    console.log("theCC.cycle_TITLE_NM = " + this.theCC.cycle_TITLE_NM);
  }
  
setNewCycleSelected() {
    this.setCycleCaseUsageCd();
    this.isDisabledDeletebutton = true;
    this.isDisabledGenDOVbutton = true;
    this.isDisabledApprovebutton = true;
  this.isDisabledSavebutton = false;
  this.cycleUser = this.theCC.create_USER_ID + "  " + this.theCC.createUserName;
    
  }

  setCycleSaved() {
    this.isDisabledGenDOVbutton = false;
    this.isDisabledApprovebutton = false;
  }
  setCycleDeleted() {
    this.calculateTotals();
    this.isEditMode = false;
    this.setViewMode();
  }

setGetCycleDataFailed(){} 

setModdPopupSelectRestrictions() {
    this.moddPopupData.selections = [];
    this.moddPopupData.isMultiSelect = true;
  
    this.moddPopupData.programTypeSelections = [];
    this.moddPopupData.selectionsUrl = "/armyModdCycle/suffixModdData/";
  }   


  setTLaPopupSelectRestrictions() {

  }

addModdSelections(selectionList: SuffixModd[]) {
   
  for (var i = 0; i < selectionList.length; i++) {
    this.newSuffixesLoaded = false;
    this.newSuffixesLoading = true;
    let suffix: SuffixModd = selectionList[i];
    
    
    this.getNewSuffixBcns(suffix);
    
  }
  this.moddPopupData.selections.length = 0;
    
}

 

calculateTotals() {
  this.cycleTotalAmount = 0.0;
  let addLog: string = '';
  if (this.theCC.budgetControlList != null) {
    for (var bcnIx in this.theCC.budgetControlList) {
      let bcn: BUDGET_CONTROL = this.theCC.budgetControlList[bcnIx];
        for (var bcdIx in bcn.budgetComponentList) {
        let bcd: BUDGET_COMPONENT = bcn.budgetComponentList[bcdIx];
         this.setNullValuesToZero(bcd);
        
         this.cycleTotalAmount = this.cycleTotalAmount + Number(bcd.action_AM);
       
      }
    
    }
  }

  }
  
  // end of ImanageArmyBillingCycle overrides

  
   /*----------------------------------
    Validation: checkAmountZero()
   -----------------------------------*/
   ltZeroRowNum: number;
   ltZeroSubRowNum: number;
   checkLtZeroFlag(row: number, subrow: number) {
      if (row == this.ltZeroRowNum && subrow == this.ltZeroSubRowNum){
          return true;
      } else
          return false;
   }
   checkLtZero(event: any, item: BUDGET_COMPONENT, row: number, subrow: number) {
      if ((parseInt(event.target.value)+item.wm_PREV_DISB_AM) < 0) {
          this.ltZeroRowNum = row;
         this.ltZeroSubRowNum = subrow;
     } else {
         this.ltZeroRowNum = -1;
         this.ltZeroSubRowNum = -1;
     }
   }
   
 
   /*----------------------------------
     Validation: checkAmountGtfundAmZero()
    -----------------------------------*/
    gtFundedAmRowNum: number;
    gtFundedAmSubRowNum: number;
    checkGtFundedAmFlag(row: number, subrow: number) {
       if (row == this.gtFundedAmRowNum && subrow == this.gtFundedAmSubRowNum){
           return true;
       } else
           return false;
    }
    checkGtFundedAm(event: any, item: BUDGET_COMPONENT, row: number, subrow: number) {
      let totalAmt: number = Number(event.target.value) + Number(item.wm_PREV_DISB_AM);
      if (totalAmt >  Number(item.wm_OBLIGATION_AM)) {
          console.log("true")
          this.gtFundedAmRowNum = row;
          this.gtFundedAmSubRowNum = subrow;
      } else {
          this.gtFundedAmRowNum = -1;
          this.gtFundedAmSubRowNum = -1;
      }
    }
    
  // caseFilterPredicate() {
  //   const thisFilterPredicate = function (data: GfebsSuffixCase, filter:string) :boolean {
  //     let searchString = JSON.parse(filter);
  //     return data.case.toString().trim().toLowerCase().indexOf(searchString.case.toLowerCase()) !== -1 &&
  //     data.wcn.toString().trim().toLowerCase().indexOf(searchString.wcn.toLowerCase()) !== -1 &&
  //     data.docNo.toString().trim().toLowerCase().indexOf(searchString.docNo.toLowerCase()) !== -1 &&
  //     data.line.toString().trim().toLowerCase().indexOf(searchString.line.toLowerCase()) !== -1 &&
  //     data.fy.toString().trim().toLowerCase().indexOf(searchString.fy.toLowerCase()) !== -1 ;

  //   } 
  //   return thisFilterPredicate;
  // }

  getNewSuffixBcns(suffix:SuffixModd) {
    let suffixKey: string = this.getSuffixModdUserDisplayKey(suffix);
    if (this.checkForDuplicateBcn(suffixKey)) {
      return;
    }
  
    let cycleId: string = "";
    let cycleControlTypeId = "";
    //console.log(JSON.stringify(suffix));
    if (this.theCC.cycle_CONTROL_ID != null) {
      cycleId = this.theCC.cycle_CONTROL_ID.toString();
    }
    if (this.theCC.cycle_CONTROL_TYPE_ID != null) {
      cycleControlTypeId = this.theCC.cycle_CONTROL_TYPE_ID.toString();
    }
    
    this.billingRestService.getArmyMODDData(suffix,cycleId, cycleControlTypeId)
    .subscribe(
      data => {
        console.log(" approveCycle()  results");
        let results : TrnArmyMODDDocEntityData  =  data;
        if (results.messageList != null && results.messageList.length > 0) {
          this.displayMessages(results.messageList);
        } else {
          this.addNewBcns(results.budgetControlList, suffix);
          }
        }
    ,
        err => {
          this.handleError("getNewSuffixBcns()", err);
      });
  }

  checkForDuplicateBcn(userKey :  string): boolean {
    let duplicate: boolean = false
    if (this.theCC.budgetControlList != null && this.theCC.budgetControlList.length > 0) {
      this.theCC.budgetControlList.forEach(bcn => {
        let bcnKey: string = this.getBcnSuffixModdKey(bcn);
        if (bcnKey == userKey) {
          return true;
        }
          });
      }

    return duplicate;
    
  }
  
  delCustomerServiceItem(e: any) {
  console.log('*** del');
}

  onSubmit() { }

  ngOnDestroy() {
    super.ngOnDestroy();
    this.dsamsShareService.csuname.next(null);
   
    }


}
