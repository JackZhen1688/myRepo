import { TtlSuffix } from 'src/app/dsams/entities/specialEntities/ttl-suffix.model';
import { TttsAllLevel } from '../../entities/specialEntities/ttts-all-level.model';
import { SuffixModd } from '../../entities/specialEntities/suffix-modd.model';
import { MatSlideToggle } from '@angular/material/slide-toggle';

export interface ImanageArmyBillingCycle {
  /* HTML event handlers  implemented in  Base component

  // cycle selection 
    (selectionChange)="onSelectCycle($event.value);"  class="down-arrow" >

  //   button clicks
   Add billing row        (click)="addBillingSuffixRow($event)" or  "addBillingTlaRow($event)"
   Delete budgetControl   (click)="deleteBudgetControl($event, element, i);"
   Delete cycle           (click)="deleteCycle();"
   Save Cycle             (click)="saveCycle();"
   Approve Cycle          (click)="approveCycle();

   // change/blur/validation events

   theCC.cycle_TITLE_NM
   (change)="markCycleControlForUpdate($event)"
   
   BCX.action_am
  (change)="markBcxAmountForUpdate($event,item);checkLtZero($event,item, r, i) ; checkGtFundedAm($event,item, r, i);" 
 (blur)="transformAmount($event);" 
 

 */
    setEditMode();
    
  setViewMode();
  
  getComponentLockSessionId(): string;
 
  setComponentLockSessionId(lockId: string);
  
  closeLockSession();

  getEditSlider(): MatSlideToggle;

    getArmyBillingCycleIdList(cycleId: string);

    getNewArmyBillingCycle();

    getArmyBillingCycle(cycleId : string,lockId : string);

    saveArmyBillingCycle();
  
    approveArmyBillingCycle();

    deleteArmyBillingCycle();
 
    validateForSaveCycle(): boolean;
    
    validateForApproveCycle(): boolean;

    setNoCycleSelected(); 

    setCycleDataLoaded();

  setNewCycleSelected();
  
  setCycleSaved();
  
  setCycleDeleted();

  setGetCycleDataFailed();
  
  setTLaPopupSelectRestrictions();

  setSuffixPopupSelectRestrictions();

  setModdPopupSelectRestrictions();
  
  
  addModdSelections(selectionList: SuffixModd[]);
    
    
  addSuffixSelections(selectionList: TtlSuffix[]);
  
  addTlaSelections(selectionList: TttsAllLevel[]);
    
    calculateTotals(); 

   

    

   
   
}
