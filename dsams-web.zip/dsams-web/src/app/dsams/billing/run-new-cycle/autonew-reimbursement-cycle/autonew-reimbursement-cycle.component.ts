import { Component, OnInit, HostListener, HostBinding } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { FormBuilder, FormGroup, FormArray, Validators} from '@angular/forms';
import { BillingRestfulService } from './../../services/billing-restful.service';
import { DsamsMethodsService } from './../../../services/dsams-methods.service';
import { DsamsConstants } from './../../../dsams.constants';
import { DiaModalCountryComponent } from './../../../utilitis/dialogs/dia-modal-country/dia-modal-country.component'
import { DiaModalGrantCaseComponent } from './../../../utilitis/dialogs/dia-modal-grant-case/dia-modal-grant-case.component'
import { DiaModalLineComponent } from './../../../utilitis/dialogs/dia-modal-line/dia-modal-line.component'
import { DiaModalWcnComponent } from './../../../utilitis/dialogs/dia-modal-wcn/dia-modal-wcn.component'
import { DiaModalSuffixComponent } from './../../../utilitis/dialogs/dia-modal-suffix/dia-modal-suffix.component'
import { DiaModalExaComponent } from './../../../utilitis/dialogs/dia-modal-exa/dia-modal-exa.component'

export interface Program {
  program_type_title_nm: string;
  program_type_id:string;
}

export interface FiscalYears {
  fiscalYearId: string;
}

@Component({
  selector: 'app-autonew-reimbursement-cycle',
  templateUrl: './autonew-reimbursement-cycle.component.html',
  styleUrls: ['./autonew-reimbursement-cycle.component.css']
})
export class AutonewReimbursementCycleComponent implements OnInit {

  serviceId: string;

  durationInSeconds = 5;
  custOrganizationIds: string[] = [];
  caseIds: number[] = [];
  caseMasterLineIds: number[] = [];
  traningTrackSeqCds: number[] = [];           
  
  programs: Program[];
  fiscalYears: FiscalYears[];

  autonewReimbCycleForm: FormGroup;

  constructor(private formBuilder: FormBuilder,  
              public dsamsMethodsService: DsamsMethodsService,
              private _snackBar: MatSnackBar,
              private billingRestService: BillingRestfulService ) { }

  ngOnInit()
  {
    this.serviceId = sessionStorage.getItem('serviceDBid');
    console.log("Autonew Service Id=="+sessionStorage.getItem('serviceDBid'))
    this.constructAutonewReimbCycleForm();
    this.getProgramsData();
    this.getFiscalYearsData('6');

  }

  constructAutonewReimbCycleForm() 
  {
    this.autonewReimbCycleForm = this.formBuilder.group({
      txtJobName: this.formBuilder.control(''),
      sltPrograms: this.formBuilder.control([], [Validators.required]),
      sltFiscalYear: this.formBuilder.control([]),
      rbnService: this.formBuilder.control(this.serviceId),
      rbnRunBy: this.formBuilder.control('case'),

      runByCaseRows: this.initRunByCaseRows(),
      runByEXARows: this.initRunByEXARows(),

      serviceId: this.formBuilder.control(this.serviceId),

    });
  }

  initRunByCaseRows() 
  {
    var formArray = this.formBuilder.array([]);
        formArray.push(this.formBuilder.group({
          txtCountry: ['', [Validators.minLength(2)]],
          txtCase: ['', [Validators.minLength(6)]],
          txtLine: [''],
          txtWCN:  ['', [Validators.minLength(4)]],
          txtSuffix: [''],
        }));

    return formArray;
  }

  initRunByEXARows() 
  {
    var formArray = this.formBuilder.array([]);
        formArray.push(this.formBuilder.group({
          txtEXA: [''],
        }));

    return formArray;
  }

  get rbnService() {
    return this.autonewReimbCycleForm.get('rbnService');
  } 

  get txtCountry() {
    return this.autonewReimbCycleForm.get('txtCountry');
  }
  get txtCase() {
    return this.autonewReimbCycleForm.get('txtCase');
  }
  get txtLine() {
    return this.autonewReimbCycleForm.get('txtLine');
  }  
  get txtWCN() {
    return this.autonewReimbCycleForm.get('txtWCN');
  }  
  get txtSuffix() {
    return this.autonewReimbCycleForm.get('txtSuffix');
  }  


  getProgramsData() {
    this.billingRestService.getProgramsData()
    .subscribe(
      data => { 
        this.programs = data;
      },
      err => {
        console.log("Error occured: getProgramsData()")
      }
    );
  }

  getFiscalYearsData(numYear: string) {
    this.billingRestService.getFiscalYearsData(encodeURIComponent(numYear+"#"+this.serviceId))
    .subscribe(
      data => { 
        this.fiscalYears = JSON.parse(data);
      },
      err => {
        console.log("Error occured: getFiscalYearsData()")
      }
    );
  }

/*------------------------
  Backend Validations
  ------------------------*/
  onBlurCountry(event: any, index: number) {
    if (event.target.value.length >= 1){
        let custOrgId = event.target.value;
        if (this.serviceId !='')
            custOrgId = event.target.value+"#"+this.serviceId;
        this.billingRestService.getCustOrgId(encodeURIComponent(custOrgId))
        .subscribe(
            data => { 
              this.custOrganizationIds[index] = data;
              if (data == "") {
                  this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, DsamsConstants.COUNTRY_NOT_EXIST);
                  this.caseRows.controls[index].get('txtCountry').setValue("");
              }
            },
            err => {
              console.log("Error occured: getCustOrgId()")
              this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, JSON.stringify(err.message))
           }
        );
    }
  }

  onBlurCase(event: any, index: number) {
    if (event.target.value.length >= 1) {
      if (this.autonewReimbCycleForm.get("sltPrograms").value.length === 0) {
          this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, DsamsConstants.PROGRAM_MUST_SELECT)
          event.target.value = "";
      } else {
          if (event.target.value.length >= 1){
            let userCaseId = event.target.value.replace(/-/gi,"");
            if (this.serviceId !='')
                userCaseId = event.target.value.replace(/-/gi,"")+"#"+this.serviceId;
            if (this.caseRows.controls[index].get('txtCountry').value === "" || this.caseRows.controls[index].get('txtCountry').value == null)    
                this.custOrganizationIds[index] = null;
            this.billingRestService.getCaseIdByOrgId(this.rbnService.value, this.autonewReimbCycleForm.get("sltPrograms").value, this.custOrganizationIds[index], encodeURIComponent(userCaseId))
            .subscribe(
              data => { 
                this.caseIds[index] = data;
                if (data == 0) {
                    this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, DsamsConstants.CASE_NOT_EXIST)
                    this.caseRows.controls[index].get('txtCase').setValue("");
                }
              },
              err => {
                console.log("Error occured: getCaseIdByOrgId() onBlur")
                this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, JSON.stringify(err.message))
              }
            );
          }
      }
    }
  }

  onBlurLine(event: any, index: number) {
    if (event.target.value.length >= 1) {
      if (this.caseRows.controls[index].get('txtCase').value ==="" || this.caseRows.controls[index].get('txtCase').value == null)
          this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, DsamsConstants.CASE_MUST_SELECT)
      else {
          if (event.target.value.length >= 1) {
            let strLine:string = this.dsamsMethodsService.padZeroLeft(event.target.value, '0', 3);
            this.caseRows.controls[index].get('txtLine').setValue(strLine);
            let lineNum = event.target.value;
            if (this.serviceId !='')
                lineNum = event.target.value+"#"+this.serviceId;
            this.billingRestService.getCaseMasterLineId(this.caseIds[index] , encodeURIComponent(lineNum))
            .subscribe(
              data => { 
                this.caseMasterLineIds[index] = data;
                if (data == 0) {
                    this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, DsamsConstants.LINE_NOT_EXIST)
                    this.caseRows.controls[index].get('txtLine').setValue("");
                }
              },
              err => {
                console.log("Error occured: getCaseMasterLineId()")
                this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, JSON.stringify(err.message))
              }
            );
          } 
      }
    }
  }

  onBlurWCN(event: any, index: number) {
    if (event.target.value.length >= 1) {
      if ((this.caseRows.controls[index].get('txtCase').value ==="" || this.caseRows.controls[index].get('txtCase').value == null) && 
          (this.caseRows.controls[index].get('txtLine').value ==="" || this.caseRows.controls[index].get('txtLine').value == null ))
          this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, DsamsConstants.CASE_LINE_MUST_SELECT)
      else if (this.caseRows.controls[index].get('txtCase').value === "" || this.caseRows.controls[index].get('txtCase').value == null) 
          this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, DsamsConstants.CASE_MUST_SELECT)
      else if (this.caseRows.controls[index].get('txtLine').value === "" || this.caseRows.controls[index].get('txtLine').value == null) 
          this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, DsamsConstants.LINE_MUST_SELECT)
      else {
        if (event.target.value.length >= 1){
            let wcn = event.target.value;
            if (this.serviceId !='')
                wcn = event.target.value+"#"+this.serviceId;
            this.billingRestService.getTrainingTrackSeqCd(this.caseIds[index], this.caseMasterLineIds[index], encodeURIComponent(wcn))
            .subscribe(
              data => { 
                this.traningTrackSeqCds[index] = data;
                if (data == 0) {
                    this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, DsamsConstants.WCN_NOT_EXIST)
                    this.caseRows.controls[index].get('txtWCN').setValue("");
                }
              },
              err => {
                console.log("Error occured: getTrainingTrackSeqCd()")
                this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, JSON.stringify(err.message))
              }
            );
        }  
      }
    }
  }

  onBlurSuffix(event: any, index: number) {
    if (event.target.value.length >= 1) {
      if ((this.caseRows.controls[index].get('txtCase').value === "" || this.caseRows.controls[index].get('txtCase').value == null) && 
          (this.caseRows.controls[index].get('txtLine').value === "" || this.caseRows.controls[index].get('txtLine').value == null) && 
          (this.caseRows.controls[index].get('txtWCN').value === "" || this.caseRows.controls[index].get('txtWCN').value == null))
          this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, DsamsConstants.CASE_LINE_WCN_MUST_SELECT)
      else if (this.caseRows.controls[index].get('txtCase').value === "" || this.caseRows.controls[index].get('txtCase').value == null) 
          this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, DsamsConstants.CASE_MUST_SELECT)
      else if (this.caseRows.controls[index].get('txtLine').value === "" || this.caseRows.controls[index].get('txtLine').value == null) 
          this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, DsamsConstants.LINE_MUST_SELECT)
      else if (this.caseRows.controls[index].get('txtWCN').value === "" || this.caseRows.controls[index].get('txtWCN').value == null) 
          this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, DsamsConstants.WCN_MUST_SELECT)
      else {
          if (event.target.value.length >= 1){
            let suffix = event.target.value;
            if (this.serviceId !='')
                suffix = event.target.value+"#"+this.serviceId;
            this.billingRestService.getTrainingTrackLineSeqCd(this.caseIds[index], this.caseMasterLineIds[index], this.traningTrackSeqCds[index], encodeURIComponent(suffix))
            .subscribe(
              data => { 
                if (data == 0) {
                    this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, DsamsConstants.SUFFIX_NOT_EXIST)
                    this.caseRows.controls[index].get('txtSuffix').setValue("");
                }
              },
              err => {
                console.log("Error occured: getTrainingTrackLineSeqCd()")
                this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, JSON.stringify(err.message))
              }
            );
          }
      }
    }
  }

  onBlurEXA(event: any, index: number) {
    if (event.target.value.length >= 1){  
        let exa = event.target.value;
        if (this.serviceId !='')
            exa = event.target.value+"#"+this.serviceId;
        this.billingRestService.getTrainingActivitydId(encodeURIComponent(exa))
        .subscribe(
            data => { 
              if (data == "") {
                  this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, DsamsConstants.EXA_NOT_EXIST)
                  this.exaRows.controls[index].get('txtEXA').setValue("");
              }
            },
            err => {
              console.log("Error occured: getTrainingActivitydId")
              this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, JSON.stringify(err.message))
            }
        );
    }
  }

/*------------------------
  Adding Run by Case Rows
  ------------------------*/
  get caseRows() {
    return this.autonewReimbCycleForm.get('runByCaseRows') as FormArray
  }

  addRunByCaseRows() {
    const runByCaseRow = this.formBuilder.group({ 
      txtCountry: [],
      txtCase: [],
      txtLine: [],
      txtWCN:  [],
      txtSuffix: [],
    })
    this.caseRows.push(runByCaseRow);
  }

  delRunByCaseRows(i: any) {
    this.caseRows.removeAt(i);
  }

/*------------------------
  Adding Run by EXA Rows
  ------------------------*/
  get exaRows() {
    return this.autonewReimbCycleForm.get('runByEXARows') as FormArray
  }

  addRunByEXARows() {
    const runByEXARow = this.formBuilder.group({ 
      txtEXA: [],
    })
    this.exaRows.push(runByEXARow);
  }

  delRunByEXARows(i: any) {
    this.exaRows.removeAt(i);
  }  

 /*-------------------------------
   DialogBox for Search Country
  -------------------------------*/
  dialogSearchCountry(elementIndex: number, lementName:string): void 
  {
      let diaWidth:string    = "500px";
      let diaHeight:string   = "500px";
      let passingData:string = "";
      this.dsamsMethodsService.openSearchDialogFrmAry(diaWidth, diaHeight, passingData, DiaModalCountryComponent, this.caseRows, elementIndex, lementName);
  }

  /*-------------------------------
   DialogBox for Search Case
  -------------------------------*/
  dialogSearchCase(elementIndex: number, elementName:string): void 
  {
    if (this.autonewReimbCycleForm.get("sltPrograms").value.length === 0) {
        this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, DsamsConstants.PROGRAM_MUST_SELECT)
    } else {
        if (this.custOrganizationIds[elementIndex] === undefined) {
            if (this.caseRows.controls[elementIndex].get('txtCountry').value === "") {
                let diaWidth:string    = "750px";
                let diaHeight:string   = "650px";
                let passingData:string = this.autonewReimbCycleForm.get("sltPrograms").value+"@null";
                this.dsamsMethodsService.openSearchDialogFrmAry(diaWidth, diaHeight, passingData, DiaModalGrantCaseComponent, this.caseRows, elementIndex, elementName);
            } else {
                if (this.caseRows.controls[elementIndex].get('txtCountry').value === undefined) {
                    let diaWidth:string    = "750px";
                    let diaHeight:string   = "650px";
                    let passingData:string = this.autonewReimbCycleForm.get("sltPrograms").value+"@null";
                    this.dsamsMethodsService.openSearchDialogFrmAry(diaWidth, diaHeight, passingData, DiaModalGrantCaseComponent, this.caseRows, elementIndex, elementName);
                } else {
                    if (this.caseRows.controls[elementIndex].get('txtCountry').value == null) {
                        let diaWidth:string    = "750px";
                        let diaHeight:string   = "650px";
                        let passingData:string = this.autonewReimbCycleForm.get("sltPrograms").value+"@null";
                        this.dsamsMethodsService.openSearchDialogFrmAry(diaWidth, diaHeight, passingData, DiaModalGrantCaseComponent, this.caseRows, elementIndex, elementName);
                    } else {
                        let country = this.caseRows.controls[elementIndex].get('txtCountry').value
                        if (this.serviceId !='')
                            country = this.caseRows.controls[elementIndex].get('txtCountry').value+"#"+this.serviceId;
                        this.billingRestService.getCustOrgId(encodeURIComponent(country))
                        .subscribe(
                          data => { 
                            this.custOrganizationIds[elementIndex] = data;
                            if (data == "") {
                                this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, DsamsConstants.COUNTRY_NOT_EXIST);
                                this.caseRows.controls[elementIndex].get('txtCountry').setValue("");
                            } else {
                              let diaWidth:string    = "750px";
                              let diaHeight:string   = "650px";
                              let passingData:string = this.autonewReimbCycleForm.get("sltPrograms").value+"@"+this.custOrganizationIds[elementIndex];
                              this.dsamsMethodsService.openSearchDialogFrmAry(diaWidth, diaHeight, passingData, DiaModalGrantCaseComponent, this.caseRows, elementIndex, elementName);
                            }
                          },
                          err => {
                            console.log("Error occured: dialogSearchCase:getCustOrgId()")
                            this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, JSON.stringify(err.message))
                          }
                        );
                    }
               }
            }
        } else {
            let diaWidth:string    = "750px";
            let diaHeight:string   = "650px";
            let passingData:string = "";
            if (this.caseRows.controls[elementIndex].get('txtCountry').value === "")
                passingData = this.autonewReimbCycleForm.get("sltPrograms").value+"@null";
            else
                passingData = this.autonewReimbCycleForm.get("sltPrograms").value+"@"+this.caseRows.controls[elementIndex].get('txtCountry').value;
            this.dsamsMethodsService.openSearchDialogFrmAry(diaWidth, diaHeight, passingData, DiaModalGrantCaseComponent, this.caseRows, elementIndex, elementName);
        }
    }
  }

 /*-------------------------------
   DialogBox for Search Line
  -------------------------------*/
  dialogSearchLine(elementIndex: number, elementName:string): void 
  {
    if (this.caseRows.controls[elementIndex].get('txtCase').value === "" || this.caseRows.controls[elementIndex].get('txtCase').value == null)
        this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, DsamsConstants.CASE_MUST_SELECT)
    else {
        let tcase = this.caseRows.controls[elementIndex].get('txtCase').value
        if (this.serviceId !='')
            tcase = this.caseRows.controls[elementIndex].get('txtCase').value+"#"+this.serviceId;
        if (this.caseRows.controls[elementIndex].get('txtCountry').value === "")    
            this.custOrganizationIds[elementIndex] = null;
        this.billingRestService.getCaseIdByOrgId(this.rbnService.value, this.autonewReimbCycleForm.get("sltPrograms").value, this.custOrganizationIds[elementIndex], encodeURIComponent(tcase))    
        .subscribe(
            data => { 
              this.caseIds[elementIndex] = data;
              if (data == 0) 
                  this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, DsamsConstants.CASE_NOT_EXIST)
              else {    
                  let diaWidth:string    = "400px";
                  let diaHeight:string   = "500px";
                  let passingData:number = this.caseIds[elementIndex];
                  this.dsamsMethodsService.openSearchDialogFrmAry(diaWidth, diaHeight, passingData, DiaModalLineComponent, this.caseRows, elementIndex, elementName);
              }
            },
            err => {
                console.log("Error occured: dialogSearchLine():getCaseIdByOrgId()")
                this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, JSON.stringify(err.message))
            }
        );
    }
  }
  /*-------------------------------
   DialogBox for Search Wcn
  -------------------------------*/
  dialogSearchWcn(elementIndex: number, elementName:string): void 
  {
    if ((this.caseRows.controls[elementIndex].get('txtCase').value ==="" || this.caseRows.controls[elementIndex].get('txtCase').value == null) && 
        (this.caseRows.controls[elementIndex].get('txtLine').value ==="" || this.caseRows.controls[elementIndex].get('txtLine').value == null))
        this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, DsamsConstants.CASE_LINE_MUST_SELECT)
    else if (this.caseRows.controls[elementIndex].get('txtCase').value === "" || this.caseRows.controls[elementIndex].get('txtCase').value == null) 
        this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, DsamsConstants.CASE_MUST_SELECT)
    else if (this.caseRows.controls[elementIndex].get('txtLine').value === "" || this.caseRows.controls[elementIndex].get('txtLine').value == null) 
        this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, DsamsConstants.LINE_MUST_SELECT)
    else {
        let line = this.caseRows.controls[elementIndex].get('txtLine').value
        if (this.serviceId !='')
            line = this.caseRows.controls[elementIndex].get('txtLine').value+"#"+this.serviceId;
        this.billingRestService.getCaseMasterLineId(this.caseIds[elementIndex], encodeURIComponent(line))
        .subscribe(
          data => { 
            this.caseMasterLineIds[elementIndex] = data;
            if (data == 0) 
                this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, DsamsConstants.LINE_NOT_EXIST)
            else {
                let diaWidth:string  = "400px";
                let diaHeight:string = "500px";
                let passingData:any  = this.caseIds[elementIndex]+"@"+this.caseMasterLineIds[elementIndex];
                this.dsamsMethodsService.openSearchDialogFrmAry(diaWidth, diaHeight, passingData, DiaModalWcnComponent, this.caseRows, elementIndex, elementName);
            }
          },
          err => {
            console.log("Error occured: dialogSearchWcn():getCaseMasterLineId()")
            this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, JSON.stringify(err.message))
          }
        );
    }
  }
 /*-------------------------------
   DialogBox for Search Suffix
  -------------------------------*/
  dialogSearchSuffix(elementIndex: number, elementName:string): void 
  {
    if ((this.caseRows.controls[elementIndex].get('txtCase').value ==="" || this.caseRows.controls[elementIndex].get('txtCase').value == null) && 
        (this.caseRows.controls[elementIndex].get('txtLine').value ==="" || this.caseRows.controls[elementIndex].get('txtLine').value == null) && 
        (this.caseRows.controls[elementIndex].get('txtWCN').value ==="" || this.caseRows.controls[elementIndex].get('txtWCN').value == null))
        this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, DsamsConstants.COUNTRY_CASE_LINE_WCN_MUST_SELECT)
    else if (this.caseRows.controls[elementIndex].get('txtCase').value === "" || this.caseRows.controls[elementIndex].get('txtCase').value == null) 
        this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, DsamsConstants.CASE_MUST_SELECT)
    else if (this.caseRows.controls[elementIndex].get('txtLine').value === "" || this.caseRows.controls[elementIndex].get('txtLine').value == null) 
        this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, DsamsConstants.LINE_MUST_SELECT)
    else if (this.caseRows.controls[elementIndex].get('txtWCN').value === "" || this.caseRows.controls[elementIndex].get('txtWCN').value == null) 
        this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, DsamsConstants.WCN_MUST_SELECT)
    else {
        let wcn = this.caseRows.controls[elementIndex].get('txtWCN').value
        if (this.serviceId !='')
            wcn = this.caseRows.controls[elementIndex].get('txtWCN').value+"#"+this.serviceId;
        this.billingRestService.getTrainingTrackSeqCd(this.caseIds[elementIndex], this.caseMasterLineIds[elementIndex], encodeURIComponent(wcn))
        .subscribe(
          data => { 
            this.traningTrackSeqCds[elementIndex] = data;
            if (data == 0) 
                this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, DsamsConstants.WCN_NOT_EXIST)
            else {    
                let diaWidth:string    = "500px";
                let diaHeight:string   = "500px";
                let passingData: any   = this.caseIds[elementIndex]+"@"+this.caseMasterLineIds[elementIndex]+"@"+this.traningTrackSeqCds[elementIndex];
                this.dsamsMethodsService.openSearchDialogFrmAry(diaWidth, diaHeight, passingData, DiaModalSuffixComponent, this.caseRows, elementIndex, elementName);
            }
          },
          err => {
            console.log("Error occured: dialogSearchSuffix():getCaseMasterLineId()")
            this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, JSON.stringify(err.message))
          }
        );
    }
  }  
  
 /*-------------------------------
   DialogBox for Search Suffix
  -------------------------------*/
  dialogSearchEXA(elementIndex: number, elementName:string): void 
  {
    let diaWidth:string    = "600px";
    let diaHeight:string   = "500px";
    let passingData:string = "";
    this.dsamsMethodsService.openSearchDialogFrmAry(diaWidth, diaHeight, passingData, DiaModalExaComponent, this.exaRows, elementIndex, elementName);
  }  


  /*------------------------
  ActiveForm Submit
  ------------------------*/  
  postBilling(formValue: any) {
    this.billingRestService.postBilling(formValue)
    .subscribe(
      data  => {
         if (data) {
              this._snackBar.open("Auto reimbursement data has been saved successfully!", 'close',  {
              duration: this.durationInSeconds * 1000,
              panelClass: ['mat-toolbar', 'mat-primary'] // 'mat-accent' or 'mat-warn'
            });
         } else {
              this._snackBar.open("Auto reimbursement data saved failure!", 'close',  {
              duration: this.durationInSeconds * 1000,
              panelClass: ['mat-toolbar', 'mat-warn'] // 'mat-accent' or 'mat-warn'
            });
         }
         console.log("POST Request is successful ", data);
      },
      err  => {
        console.log("Error occured: postBilling()")
        this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, JSON.stringify(err.message))
      }
    );  
  }

  revert() {
    this.autonewReimbCycleForm.reset();    
    this.autonewReimbCycleForm.patchValue({
      'rbnService': this.serviceId,
      'rbnRunBy': 'case',
   }); 
  }

  onSubmit() {
    
    //stop here if form is invalid
    //if (this.autonewReimbCycleForm.invalid) 
    //    return;
    //console.log("Form Value: "+JSON.stringify(this.autonewReimbCycleForm.value)); 
    this.postBilling(this.autonewReimbCycleForm.value);
      
  }

}
