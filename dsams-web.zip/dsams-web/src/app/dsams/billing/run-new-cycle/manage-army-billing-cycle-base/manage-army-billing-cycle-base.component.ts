import { Component, OnInit, Injector, OnDestroy } from '@angular/core';
import { ViewportScroller } from '@angular/common';
import { ActivatedRoute,Router } from '@angular/router';
import { Subscription, throwError, BehaviorSubject, Observable  } from 'rxjs';
import { MatTableDataSource } from '@angular/material/table';
import { MatSlideToggle } from '@angular/material/slide-toggle';
import {  MatDialogConfig, MatDialog } from '@angular/material/dialog';
import {  CurrencyPipe} from '@angular/common';
import { DsamsMethodsService } from './../../../../dsams/services/dsams-methods.service';
import { BillingRestfulService } from '../../services/billing-restful.service';
import { ReimbursementService } from '../../services/manage-manual-reimbursement.service';
import {CYCLE_CONTROL} from 'src/app/dsams/entities/models/cycle-control.model';
import {BUDGET_CONTROL} from 'src/app/dsams/entities/models/budget-control.model';
import {BUDGET_COMPONENT} from 'src/app/dsams/entities/models/budget-component.model';
import {TRAINING_TRACK_LINE} from 'src/app/dsams/entities/models/training-track-line.model';
import { ApproveCycleResults } from 'src/app/dsams/entities/specialEntities/approve-cycle-results.model';
import {SavedCycleResults} from 'src/app/dsams/entities/specialEntities/saved-cycle-results.model';
import { TtlSuffix } from 'src/app/dsams/entities/specialEntities/ttl-suffix.model';
import { PopSuffixAllLevelsComponent, SuffixAllLevelPopupData } from './../../../utilitis/popups/pop-suffix-all-levels/pop-suffix-all-levels.component';
import {TttsAllLevel} from 'src/app/dsams/entities/specialEntities/ttts-all-level.model';
import { PopTttsAllLevelsComponent, TttsAllLevelPopupData } from './../../../utilitis/popups/pop-ttts-all-levels/pop-ttts-all-levels.component';
import { PopSuffixModdComponent, SuffixMODDPopupData } from './../../../utilitis/popups/pop-suffix-modd/pop-suffix-modd.component';
import {SuffixModd} from 'src/app/dsams/entities/specialEntities/suffix-modd.model';
import { ISelectOptions } from 'src/app/dsams/interfaces/i-select-options';
import { ErrorParameter } from 'src/app/dsams/entities/specialEntities/error-parameter.model';
import { MessageBtnClicked, MessageBtnConfig } from './../../../enums/user-message.enum';
import { ImessageData } from './../../../interfaces/imessage-data';
import { EntityStatus } from './../../../enums/entity-status.enum';
import { DsamsUserMessageService } from './../../../services/dsams-user-message.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ImanageArmyBillingCycle } from './../../interfaces/imanage-army-billing-cycle';
import { TRNG_TRK_TLA_SUMMARY } from 'src/app/dsams/entities/models/trng-trk-tla-summary.model';
import { TRAINING_TRACK } from 'src/app/dsams/entities/models/training-track.model';
import { CASE_MASTER_LINE } from 'src/app/dsams/entities/models/case-master-line.model';
import { CASE_MASTER } from 'src/app/dsams/entities/models/case-master.model';
import {IdsamsEntityComponent} from 'src/app/dsams/interfaces/idsams-entity-component'
import { CanDeactivateComponent } from 'src/app/dsams/blockers/can-deactivate-component';
import { CanDeactiveNotiticationService } from 'src/app/dsams/blockers/can-deactive-notitication.service';
import { DsamsShareService } from './../../../services/dsams-share.service'; 

import { DsamsRestfulService } from './../../../services/dsams-restful.service';
import { FormBuilder } from '@angular/forms';
import { EditSliderComponent } from 'src/app/dsams/utilitis/edit-slider-component/edit-slider-component';


export function forceCast<T>(input: any): T {
  // @ts-ignore <-- forces TS compiler to compile this as-is
   return input;
}

export function delay(ms: number) {
  return new Promise( resolve => setTimeout(resolve, ms) );
}
 
export function isNumeric(val: any): boolean {
  return !(val instanceof Array) && (val - parseFloat(val) + 1) >= 0;
}



@Component({
  selector: 'app-manage-army-billing-cycle-base',
  templateUrl: './manage-army-billing-cycle-base.component.html',
  styleUrls: ['./manage-army-billing-cycle-base.component.css',
    './../../billing-global.css'],
})
export class ManageArmyBillingCycleBaseComponent extends EditSliderComponent implements ImanageArmyBillingCycle, IdsamsEntityComponent, CanDeactivateComponent,
  OnInit, OnDestroy {
  CYCLE_NOT_SAVED: string = "You have unsaved changed. Would you like to save the cycle changes or continue without saving? ";
  SAVE_CHANGES_BEFORE_EXIT: string = "You have unsaved changed. Would you like to save the cycle changes now ? ";
  destroyInProgress: boolean = false;
 
  public cycleTotalAmount: number;
  public cycleUnsavedAmount: number;
  public serviceId: string;
  public durationInSeconds = 5;
  public messageData: ImessageData;
  public selectNewCycle: boolean;
  public selections: any[];
  public suffixPopupData: SuffixAllLevelPopupData;
  public tttsPopupData: TttsAllLevelPopupData;
  public moddPopupData: SuffixMODDPopupData;
  public validCaseUsageIndicators: ISelectOptions[];
  public theServiceId: string;
  public theCycleTypeId: string;
  public theCycleControlId: string;
  public theParmCycleId: string;
  public selectCycleAllowed: boolean = false;
  public theCC: CYCLE_CONTROL = new CYCLE_CONTROL();
  public theNewBcns: Array<BUDGET_CONTROL>;
  public isDisabledApprovebutton: boolean;
  public isDisabledDeletebutton: boolean;
  public isDisabledSavebutton: boolean;
  public isDisabledGenDOVbutton: boolean;
  public isDisabledEditSlider: boolean
  
  public SESSION_LOCK_ID: string = 'SESSION_LOCK_ID';
  
  
  public services: ISelectOptions[] = [
    { value: 'A', viewValue: 'Army' },
    { value: 'N', viewValue: 'Navy' },
    { value: 'F', viewValue: 'Air Force' }
  ];
  public cycles: ISelectOptions[];
  
  public basicCaseUsageCds: ISelectOptions[];
  
 
  
  public newCycle: string;
  // @Input() selectedCycle: string = '';
  public selectedCycleId: string = '';
  public selectedCycle: ISelectOptions = { viewValue: "", value: "" };
  public cycleIsSel: boolean = false;
  public isCreateNewCycle = false;
 
  public selectedService = 'A';
  public selectedServiceName = 'Army';
  
  public statusMessage = '';
  
  public sessionClosing: boolean = false;
  public sessionClosed: boolean = true;
  public showSpinner: BehaviorSubject<boolean> = new BehaviorSubject(false);
  public cycleDataLoading: boolean = false;
  public cycleUsageLoading: boolean = false;
  public newSuffixesLoading: boolean = false;
  public newTttsLoading: boolean = false;
  public cycleListLoaded: boolean = false;
  public cycleDataLoaded: boolean = false;
  public lastCycleLoaded: number = -1;
  public cycleUsageLoaded: boolean = false;
  public newSuffixesLoaded: boolean = false;
  public newTttsLoaded: boolean = false;
  public dsBcnData = new MatTableDataSource();
  public bcnFilter: string;

  
  // any service not needed in child classes may be injected directly into the base
  // https://stackoverflow.com/questions/56748951/angular-inject-service-into-base-class-but-not-in-sub-class-and-use-the-parent-s
   messageService: DsamsUserMessageService; 
  
   router: Router;
   currencyPipe: CurrencyPipe;
   dsamsMethodsService: DsamsMethodsService; 
   dsamsShareService: DsamsShareService;
   billingRestService: BillingRestfulService;
   reimbursementService: ReimbursementService;
   _snackBar: MatSnackBar;
   canDeactivateService: CanDeactiveNotiticationService;
  constructor(protected injector: Injector, 
              protected route: ActivatedRoute,
              protected dsamsReferenceService: DsamsRestfulService,
              public popUpDialog: MatDialog,
              protected formBuilder: FormBuilder,
              protected viewportScroller: ViewportScroller) 
  {
    super(route, dsamsReferenceService, popUpDialog, formBuilder);
    this.messageService = injector.get<DsamsUserMessageService>(DsamsUserMessageService);
    this.router = injector.get<Router>(Router);
    this.dsamsMethodsService = injector.get<DsamsMethodsService>(DsamsMethodsService);
    this.dsamsShareService = injector.get<DsamsShareService>(DsamsShareService);
    this.billingRestService = injector.get<BillingRestfulService>(BillingRestfulService);
    this.reimbursementService = injector.get<ReimbursementService>(ReimbursementService);
    this._snackBar = injector.get<MatSnackBar>(MatSnackBar);
    this.canDeactivateService = injector.get<CanDeactiveNotiticationService>(CanDeactiveNotiticationService);
  }
  
  parmSubscription: Subscription;
  myRouterSub: Subscription;
  ngOnInit() {
    console.log('init ManageArmyBillingCycleBaseComponent');
    super.ngOnInit();
    this.setComponentLockSessionId("");
     this.resetCycleSelection();
     this.isDisabledEditSlider = true;

   
    this.parmSubscription = this.route.paramMap
      .subscribe(params => {
        this.resetCycleSelection();
        this.theParmCycleId = params.get("cycleid");
        if (this.theParmCycleId != null && this.theParmCycleId.length > 2 && this.theParmCycleId != 'newCycle') {
          this.selectedCycle = { viewValue: this.theParmCycleId, value: this.theParmCycleId };
          this.onSelectCycle(this.selectedCycle);
        }
        else {
          // this.selectedCycle = "";
          this.cycleIsSel = false;
          this.isCreateNewCycle = false;
          this.onSelectCycle(null);
       
       

        }
        this.initAfterParams();
     
      });
  }
  initAfterParams() {
    if (this.selectedCycle != null && this.selectedCycle.value.length > 1) {
      this.selectedCycle = { value: this.selectedCycle.value, viewValue: this.selectedCycle.value };
      // this.cycles = [{ value: this.selectedCycle, viewValue: this.selectedCycle }]
      this.cycleIsSel = true;
      //  this.getDov(this.selectedCycle);
      //   this.billingRestService.getDOVNumbers()
      // .subscribe( data => {
      //   this.reimbursementService.setDovs(data);
     
      // });
  
    }
    //if (this.selectedCycle == null || this.selectedCycle.length < 2 || this.selectedCycle == "newCycle") {
    else {
       this.serviceId = 'A';
      this.selectedService = 'A'
      this.selectedServiceName = "Army"

      this.setCycleCaseUsageCd();
      this.setCycleTypeId();

     
      this.cycleIsSel = false;
    }
  
    
    
    if (this.selectedCycle == null || this.selectedCycle.value.length == 0) {
      this.cycleIsSel = false;
    }
    else {
      this.cycleIsSel = true;
    }
    
  }
  
  
  getDbId(): string {
    return sessionStorage.getItem('serviceDBid');
  }
 
  isLoading(): boolean {
    if (this.showSpinner) {
      return true;
    } else {
      return false;
    }
   }
  //     // ||
  //     // this.cycleDataLoading ||
  //     // this.cycleUsageLoading ||
  //     // this.newSuffixesLoading ||
  //     // this.newTttsLoading
     
      
  // ;
  // }
  
  
 getEditSlider(): MatSlideToggle {
  throw new Error("Abstract method not implemented");
  }


  finishViewChange() {
    console.log("finishViewChange()");
     this.statusMessage = "Data loaded";
    this.closeLockSession();    
    this.disableButtons();
    let selCycle = null;
    if (this.getTheCycleControlId().length > 2) {
      selCycle = this.selectedCycle;
    }
   // if (this.getTheCycleControlId().length > 2) {
      this.resetCycleSelection();//.resetAfterCloseSession();
  //  }
      this.onSelectCycle(selCycle);
  }
  
  resetEditMode() {
    this.isEditMode =true;
    if (this.getEditSlider().checked == false){
      this.getEditSlider().toggle(); // = true;
     // this.getEditSlider().toggle();
    }
  
  
  }

  resetViewMode() {
    this.isEditMode =  false;
    if (this.getEditSlider().checked == true){
      this.getEditSlider().toggle(); // = true;
     // this.getEditSlider().toggle();
    }
  
  
  }



  setEditMode() {
    throw new Error("Abstract method not implemented");
  }



  setViewMode() {
    throw new Error("Abstract method not implemented");
  }
  

  getTheCycleControlId(): string {
    let ccid: string = "";
    if (this.theCC != null && this.theCC.cycle_CONTROL_ID != null) {
      ccid = this.theCC.cycle_CONTROL_ID.toString();
    }
    return ccid;
  }
  getComponentLockSessionId(): string {
    throw new Error("Abstract method not implemented");
  
  }
 
  setComponentLockSessionId(lockId: string) {
    throw new Error("Abstract method not implemented");
  }
 

 setNewLockSessionId() {

    
    this.billingRestService.openLockSession()
      .subscribe(
        data => {
          this.setComponentLockSessionId("");
          this.setComponentLockSessionId(data);
          this.theCC.lmLockSessionId = Number(this.getComponentLockSessionId());
  
        },
        err => {
          
             this.handleError("getManualBillingCycleData()", err);
        
        });
    
  }

  
 
 
 

  resetCycleSelection() {
    console.log('resetCycleSelection()')
     this.closeLockSession();
    this.setComponentLockSessionId("");
    this.statusMessage = "";
    this.selectCycleAllowed = true;
    this.selectedService = "A";
    this.selectedServiceName = "Army";
    this.cycleIsSel = false;
    this.isCreateNewCycle = false;
    this.cycles = [];
    this.theCC = new CYCLE_CONTROL();
    this.theCC.status = 1;  // ENT_NEW
    this.theCC.lmLockSessionId = 0;
     
    this.theCC.budgetControlList = new Array<BUDGET_CONTROL>();
    this.cycleListLoaded = false;
    this.cycleDataLoaded = false;
    this.cycleUsageLoaded = false;
    this.newSuffixesLoaded = false;
    this.newTttsLoaded = false;
    this.dsBcnData.data = [];
    this.dsBcnData.data = this.theCC.budgetControlList;
    this.dsBcnData.filter = "";
    this.bcnFilter = "";
    this.getBasicCaseUsageCdList();
    this.getArmyBillingCycleIdList("");
   
    this.selectedCycle = { viewValue: "", value: "" };
   
  }

  compareCycles(o1, o2): boolean {
    const iso1 = forceCast<ISelectOptions>(o1);
    const iso2 = forceCast<ISelectOptions>(o2);
    if (iso1 === null) return (iso2 === null);
    if (iso2 === null) return (iso1 === null);
    return iso1.value === iso2.value;
  }
  
 
 
  sortSelOptionArrayByValue(options: ISelectOptions[], desc: boolean) {
    options.sort((a, b) => 0 - (a.value > b.value ? -1 : 1));
    if (desc) {
      options.reverse();
    }
   
  }

  getSuffixUserDisplayKey(sfx: TtlSuffix) {
    return sfx.caseId + "/" + sfx.lineNumber + "/" + sfx.wcn + "/" + sfx.suffixCode +
      "(" + sfx.case_ID + "," + sfx.case_MASTER_LINE_ID + "," + sfx.training_TRACK_SEQ_CD + ","
       + sfx.training_TRACK_LINE_SEQ_CD + ")";
  }

  

  getSuffixModdUserDisplayKey(sfx: SuffixModd) {
    let userKey: String = "";
    userKey = userKey.concat(sfx.fiscalYearId + "/");
    userKey = userKey.concat(sfx.obligDocument + "/");
    userKey = userKey.concat(sfx.wbsApc + "/");
    userKey = userKey.concat(sfx.caseId + "/" + sfx.lineNumber + "/" + sfx.wcn + "/" + sfx.suffixCode); 
   return userKey.toString();
  }

  
  
  getTttsUserDisplayKey(sfx: TttsAllLevel) {
    return sfx.caseId + "/" + sfx.lineNumber + "/" + sfx.wcn + "/" + sfx.suffixCode +
      "(" + sfx.case_ID + "," + sfx.case_MASTER_LINE_ID + "," + sfx.training_TRACK_SEQ_CD + "," + sfx.trng_TRK_TLA_SUMMARY_SEQ_CD + ")";
  }

  canDeactivate() {
    return true;
  //  return !(this.hasCycleChanged());
  }
  hasCycleChanged(): boolean {
    
    if (this.statusMessage == "Unsaved data") {
     
      return true;
    }
   
    else {
      
      return false;
    }
  }

  onSelectCycle(selCycle: ISelectOptions): void {
    if (this.hasCycleChanged()) {
      //   this.openSaveConfirmationDialog(selCycle)
     
      // } else {
      //   this.finishSelectCycle(selCycle);
      if (this.confirmMessage("","Warning, there are unsaved changes. If you continue the changes will be lost.")) {
        this.finishSelectCycle(selCycle);
      } else {
        this.resetEditMode();
      }
    } else {
      this.finishSelectCycle(selCycle);
    }
    
  }

  openExitConfirmationDialog(): void {
    this.messageData = this.messageService.yesNoMsgData();
    this.messageData.title = 'Cycle Change';
    this.messageData.message = this.SAVE_CHANGES_BEFORE_EXIT;
    this.messageData.msgBtnConfig = MessageBtnConfig.YesNo;
    this.messageService.showMessage(this.messageData)
      .subscribe(result => {
       
        if (this.messageData.btnClicked == MessageBtnClicked.YesClicked) {
          
          this.saveCycle();
        } else {
          this.finishNgDestroy();
        }
     
      
      });
  }

  openViewModeConfirmationDialog(selCycle: ISelectOptions): void {
    this.messageData = this.messageService.confirmationMsgData();
    this.messageData.title = 'Cycle Change';
    this.messageData.message = this.CYCLE_NOT_SAVED;
    this.messageData.msgBtnConfig = MessageBtnConfig.SaveContinueCancel;
    this.messageService.showMessage(this.messageData)
      .subscribe(result => {
        let btnClick: MessageBtnClicked = this.messageData.btnClicked;
       
        if (btnClick == MessageBtnClicked.SaveClicked) {
          this.saveCycle();
        } else if (btnClick == MessageBtnClicked.ContinueClicked) {
          this.closeLockSession();
          this.theCC.cycle_CONTROL_ID = -1;
          this.statusMessage = "Data loaded";
         this.intSetViewMode();
          this.onSelectCycle(selCycle);
        } else if (btnClick == MessageBtnClicked.CancelClicked) {
          this.isEditMode = true;
        }
      
      });
  }

  openSaveConfirmationDialog(selCycle: ISelectOptions): void {
    this.messageData = this.messageService.confirmationMsgData();
    this.messageData.title = 'Cycle Change';
    this.messageData.message = this.CYCLE_NOT_SAVED;
    this.messageData.msgBtnConfig = MessageBtnConfig.SaveContinueCancel;
    this.messageService.showMessage(this.messageData)
      .subscribe(result => {
        let btnClick: MessageBtnClicked = this.messageData.btnClicked;
       
        if (btnClick == MessageBtnClicked.SaveClicked) {
          console.log('Save was clicked');
          this.saveCycle();
          this.finishSelectCycle(selCycle);
        } else if (btnClick == MessageBtnClicked.ContinueClicked) {
          this.finishSelectCycle(selCycle);
        } else if (btnClick == MessageBtnClicked.CancelClicked) {
          console.log('cancel was clicked');
          if (this.isCreateNewCycle) {
            this.selectedCycle = this.cycles[0];
          } else {
            let ccid: string = this.theCC.cycle_CONTROL_ID.toString();
            this.selectedCycle = { viewValue: ccid, value: ccid };
          }
        }
      
      });
  }

  finishSelectCycle(selCycle: ISelectOptions): void {
    if (this.isCreateNewCycle) {
      return;
    }
    this.bcnFilter = "";
    this.dsBcnData.filter = "";
    if (selCycle == null) {
      this.isDisabledEditSlider = true;
      this.selectedCycle = selCycle;
          this.isCreateNewCycle = false;
          this.cycleIsSel = false;
      this.setNoCycleSelected();
      return;
    } else {
      this.isDisabledEditSlider = false;
      console.log("onSelectCycle(" + selCycle.viewValue + ")");
    }
    if (this.selectedCycle.value === ' ') {
      this.setCreateNewCycle();
    } else if (this.theCC.cycle_CONTROL_ID == null || this.theCC.cycle_CONTROL_ID.toString() != selCycle.value) {
      this.setCycleSelected(selCycle);
    }
  }

  setNoCycleSelected() {
    throw new Error("Abstract method not implemented");
  }

  setNewCycleSelected() {
    throw new Error("Abstract method not implemented");
  }
  setCycleDataLoaded() {
    throw new Error("Abstract method not implemented");
  }

  setCycleSaved() {
    throw new Error("Abstract method not implemented");
  }
  setCycleDeleted() {
    throw new Error("Abstract method not implemented");
  }
  setCreateNewCycle() {
    this.getNewArmyBillingCycle();
    
  }

  disableButtons() {
    this.isDisabledApprovebutton = true;
  this.isDisabledDeletebutton = true;
  this.isDisabledSavebutton = true;
  this.isDisabledGenDOVbutton = true;
  }

  enableButtons() {
    this.isDisabledApprovebutton = false;
  this.isDisabledDeletebutton = false;
  this.isDisabledSavebutton = false;
  this.isDisabledGenDOVbutton = false;
  }

  getNewArmyBillingCycle() {
    throw new Error("Abstract method not implemented");
  }

  getNewArmyBillingCycleData(apiUrl: string) {
    this.billingRestService.getNewArmyBillingCycle(apiUrl)
      .subscribe(
        data => {
          this.theCC = data;
          this.theCC.budgetControlList = new Array<BUDGET_CONTROL>();
          this.refreshBcnList();
          this.calculateTotals();
          this.cycleDataLoaded = true;
          this.isEditMode = true;
          this.getEditSlider().checked = true;
          this.selectedCycle = this.cycles[0];
          this.isCreateNewCycle = true;
          this.cycleIsSel = true;
          this.statusMessage = "";
         // this.setNewLockSessionId();
          this.setNewCycleSelected();
  
        },
        err => {
           console.log("Error occured: getNewArmyBillingCycleData()");
           this.handleError("Error occured: getNewArmyBillingCycleData()",err);
        
        });
 
  }
 
  setCycleSelected(selCycle: ISelectOptions) {
    if (selCycle != null) {
      console.log("setCycleSelected(" + selCycle.viewValue + ")");
      this.selectedCycle = selCycle;
      // if (this.cycleIsSel = (this.selectedCycle !== '')) {
      this.cycleIsSel = true;
      this.reimbursementService.emptyBillingTable();
      this.getArmyBillingCycle(this.selectedCycle.value,this.getComponentLockSessionId());
    
    }
    
  }

  

  addBillingModdRow(event: Event) {
    this.selections = [];
    this.moddPopupData = new SuffixAllLevelPopupData
    this.setModdPopupSelectRestrictions();
    this.openSelectMOddSuffix(this.moddPopupData);
   
  }
  
  addBillingSuffixRow(event: Event) {
    this.selections = [];
    this.suffixPopupData = new SuffixAllLevelPopupData
    this.setSuffixPopupSelectRestrictions();
    this.openSelectSuffix(this.suffixPopupData);
   
  }
  
  addBillingTlaRow(event: Event) {
    this.selections = [];
    this.tttsPopupData = new TttsAllLevelPopupData
    this.setTLaPopupSelectRestrictions();
    this.openSelectTtts(this.tttsPopupData);
   
  }
  
  openSelectSuffix(popupData: SuffixAllLevelPopupData) {
    this.selections = [];
    this.newSuffixesLoaded = false;
    let diaWidth: string = "950px";
    let diaHeight: string = "700px";
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = diaWidth;
    dialogConfig.height = diaHeight;
    dialogConfig.data = popupData;
   
    
    const dialogRef = this.popUpDialog.open(PopSuffixAllLevelsComponent, dialogConfig
    );

    
   
    dialogRef.afterClosed().subscribe(result => {
      console.log("after close suffix popup selections count = " + this.suffixPopupData.selections.length)
      if (this.suffixPopupData.selections != null && this.suffixPopupData.selections.length > 0) {
        this.addSuffixSelections(this.suffixPopupData.selections);
      }
  
    });
    
  }
  
  openSelectMOddSuffix(popupData: SuffixMODDPopupData) {
    this.selections = [];
    let diaWidth: string = "1000px";
    let diaHeight: string = "700px";
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = diaWidth;
    dialogConfig.height = diaHeight;
    dialogConfig.data = popupData;
    const dialogRef = this.popUpDialog.open(PopSuffixModdComponent, dialogConfig);
    dialogRef.afterClosed().subscribe(result => {
        if (this.moddPopupData.selections != null && this.moddPopupData.selections.length > 0) {
          this.addModdSelections(this.moddPopupData.selections);
        }
    
     
    });

  }
  
  openSelectTtts(popupData: TttsAllLevelPopupData) {
    this.selections = [];
    this.newTttsLoaded = false;
    let diaWidth: string = "950px";
    let diaHeight: string = "700px";
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = diaWidth;
    dialogConfig.height = diaHeight;
    dialogConfig.data = popupData;
   
    
    const dialogRef = this.popUpDialog.open(PopTttsAllLevelsComponent, dialogConfig
    );

    
   
    dialogRef.afterClosed().subscribe(result => {
     
      if (this.tttsPopupData.selections != null && this.tttsPopupData.selections.length > 0) {
        this.addTlaSelections(this.tttsPopupData.selections);
      }
  
    });
    
  }
  

  addSuffixSelections(selections: TtlSuffix[]) {
    
    throw new Error("Abstract method not implemented");
  }

  addTlaSelections(selectionList: TttsAllLevel[]) {
    throw new Error("Abstract method not implemented");
  }

  addModdSelections(selections: SuffixModd[]) {
    
    throw new Error("Abstract method not implemented");
  }
   

 
    
 

  addNewBcns(bcnList: any, sfx: any) {
    if (this.theCC.budgetControlList == null) {
      this.theCC.budgetControlList = [];
    }
    if (bcnList != null && bcnList.length > 0) {
      
      for (var bcnIx in bcnList) {
        let bcn: BUDGET_CONTROL = bcnList[bcnIx];
        if (bcn.budgetComponentList != null && bcn.budgetComponentList.length > 0){
          this.theCC.budgetControlList.push(bcn);
        this.statusMessage = "Unsaved data";
      }
       
      }
      this.calculateTotals();
      this.refreshBcnList();
    } else {
      let msg: string = "";
      if (sfx instanceof TtlSuffix) {
        msg = this.getSuffixUserDisplayKey(sfx) + " is not eligible for this cycle type.";
      }
      if (sfx instanceof TttsAllLevel) {
        msg = this.getTttsUserDisplayKey(sfx) + " is not eligible for this cycle type.";
      }
      if (sfx instanceof SuffixModd) {
        msg = this.getSuffixModdUserDisplayKey(sfx) + " is not eligible for this cycle type.";
      }
      this.displayErrorMessage("Add Suffix", msg)
        .subscribe(result => {
          console.log(msg);
   
        });
    }
   
  }
    

  deletedBudgetControls: BUDGET_CONTROL[] = [];

  deleteBudgetControl(event: Event, row: BUDGET_CONTROL, idx: number) {
    if (row.status !== EntityStatus.ENT_NEW) {
      row.status = EntityStatus.ENT_DELETED;
      this.deletedBudgetControls.push(row);
    }
    let deleteRow: number = this.theCC.budgetControlList.indexOf(row);
    this.theCC.budgetControlList.splice(deleteRow, 1);
    this.calculateTotals();
    this.refreshBcnList();
    this.statusMessage = "Unsaved data";
  }

  applyBcnFilter(filterValue: string) {
    //  this.dsBcnData.filterPredicate =  (data: any, filter: string) => { return true };
    this.dsBcnData.filter = filterValue.trim().toLocaleLowerCase();
  }
  
  markBcnForUpdate(event: Event, row: BUDGET_CONTROL) {
    if (row.status != EntityStatus.ENT_NEW) {
      row.status = EntityStatus.ENT_CHANGED
    }
    this.calculateTotals();
    this.statusMessage = "Unsaved data";
  }
  markCycleControlForUpdate(event: Event) {
    console.log("markCycleControlForUpdate title = " + this.theCC.cycle_TITLE_NM);
    if (this.theCC.status != EntityStatus.ENT_NEW) {
      this.theCC.status = EntityStatus.ENT_CHANGED
    }
    this.statusMessage = "Unsaved data"
  }

  markBcxAmountForUpdate(event: any, row: BUDGET_COMPONENT) {
    //console.log(" markBcxAmountForUpdate")
    let amtString: string = event.target.value.replace("$","").replaceAll(",","");
    if (isNumeric(amtString)) {
      let actionAmt: number = Number(amtString);
      if (actionAmt !== Number(row.action_AM)) {
        row.action_AM = actionAmt;
        this.markBcxUpdated(row);
        this.calculateTotals();
       
      }
    }
   
  }

  
  markBcxDovUpdated(event: any, row: BUDGET_COMPONENT) {
    let newValue: string = event.target.value;
    //  if (newValue != row.post_DISBURSEMENT_VOUCHER_CD) {
    row.post_DISBURSEMENT_VOUCHER_CD = newValue;
     
    this.markBcxUpdated(row);
    //  }
  }
  markBcxUpdated(row: BUDGET_COMPONENT) {
    if (row.status != EntityStatus.ENT_NEW) {
      row.status = EntityStatus.ENT_CHANGED
    }
    this.statusMessage = "Unsaved data";
  }


  
  transformAmount(event: any) {
    let amtString: string = event.target.value;
    amtString = amtString.replace('$', '');
    amtString = amtString.replace(',', '');
    if (amtString.indexOf('-') != -1) {
      amtString = '-' + amtString.replace('-', '');
    }
    console.log("event.target.value before :" + event.target.value);
    event.target.value =
      this.currencyPipe.transform(amtString, 'USD').replace('USD', '$');
    // event.target.value = this.currencyPipe.transform((event.target.value).replace('$',''), '$');
    console.log("event.target.value after transform  = " + event.target.value)
  }
  
  setSuffixPopupSelectRestrictions() {
    throw new Error("Abstract method not implemented");

  }
  
  setTLaPopupSelectRestrictions() {
    throw new Error("Abstract method not implemented");

  }
  setModdPopupSelectRestrictions() {
    throw new Error("Abstract method not implemented");
      
  
  }
 
  getSelectDocType() {
    let docType: string;
    let caseusagecd: ISelectOptions
    console.log("selected service name = " + this.selectedServiceName);
    console.log("selected servicecode  = " + this.selectedService);
    if (this.selectedServiceName == "Air Force") {
      docType = "Z";
    
    } else if (this.selectedServiceName == "Navy") {
      docType = "Y";
    } else {
      docType = "C";
    }
    console.log("length of validCaseUsageList = ", + this.validCaseUsageIndicators.length);
    for (var vcu of this.validCaseUsageIndicators) {
      console.log("value = " + vcu.value +
        ", view value = " + vcu.viewValue);
      if (vcu.value == docType) {
        caseusagecd = vcu;
        
      }
     
    }
    return caseusagecd;
  }
 
  onServiceSelection(selService: string) {
    this.selectedService = selService;
    this.setSelectedServiceName(selService);
    //  if (!this.isCreateNewCycle && !this.cycleIsSel){
    //    this.getManualOpenBillingCycleIds();
    //  }
  }

  
  calculateTotals() {
    throw new Error("Abstract method not implemented");
    
  
  }

  setNullValuesToZero(bcd: BUDGET_COMPONENT) {
    if (bcd.wm_FUNDED_AM == null) {
      bcd.wm_FUNDED_AM = 0.0;
    }
    if (bcd.wm_PREV_BILLED_AM == null) {
      bcd.wm_PREV_BILLED_AM = 0.0;
    }
    if (bcd.wm_PAID_AM == null) {
      bcd.wm_PAID_AM = 0.0;
    }
    if (bcd.wm_PREV_REIMB_BILLED_AM == null) {
      bcd.wm_PREV_REIMB_BILLED_AM = 0.0;
    }
    if (bcd.wm_PREV_REIMBURSEMENT_PAID_AM == null) {
      bcd.wm_PREV_REIMBURSEMENT_PAID_AM = 0.0;
    }
    if (bcd.wm_PREV_REIMB_BILLED_AM == null) {
      bcd.wm_PREV_REIMB_BILLED_AM = 0.0;
    }
    if (bcd.action_AM == null) {
      bcd.action_AM = bcd.wm_PREV_BILLED_AM;
    }
  }
  
  
 
   closeLockSession() {
     let lmSessionId: string = this.getComponentLockSessionId();
    if (lmSessionId.length == 0) {
      throw new Error("Abstract method not implemented");
     }
     console.log("(lmSessionId ==" +lmSessionId )
     if (lmSessionId == '0') {
       ;
      return;
    }
    this.setComponentLockSessionId("");
    this.billingRestService.closeLockSession(lmSessionId.toString())
      .subscribe(
        data => {
         
          this.sessionClosed = true;
          this.sessionClosing = false;
       
          // this.resetAfterCloseSession();
        },
        err => {
        
         // console.log("Error occured: closeLockSessionId()");
         this.handleError("", err);
       
          // this.resetAfterCloseSession();
        });
  
}
  

   
  

  setGetCycleDataFailed() {
    throw new Error("Abstract method not implemented");
    
  }
  getArmyBillingCycle(cycleId: string,lockId : string) {
    throw new Error("Abstract method not implemented");
  }
  
  

  getArmyBillingCycleData(apiUrl : string, cycleId: string,lockId : string) {
    this.selectCycleAllowed = false;
    console.log("  getArmyBillingCycleData(" + apiUrl + "," + cycleId + ")");
    console.log("  getTheCycleControlId() = " + this.getTheCycleControlId());
    if (cycleId != null && cycleId.length > 1) {
      if (this.getTheCycleControlId() != cycleId) {
        this.closeLockSession();
        this.isEditMode = false;
        this.disableButtons();
        this.setViewMode();
      } else {
        this.isEditMode = true;
        this.enableButtons();
      }

    //  this.closeLockSession();
   this.showSpinner.next(true);
      this.lastCycleLoaded = Number(cycleId);
    this.billingRestService.getArmyBillingCycleControl(apiUrl,cycleId,lockId)
    .subscribe(
      data => { 
        this.showSpinner.next(false);
        //this.theCC = new CYCLE_CONTROL().deserialize(data);
       this.theCC = data;
         if (this.theCC.cycle_TITLE_NM == null) {
            this.theCC.cycle_TITLE_NM = "";
          }
          this.calculateTotals();
          this.refreshBcnList();
          this.statusMessage = "Data loaded";
          this.cycleDataLoaded = true;
      
          this.setCycleDataLoaded();
      
       
      },
       err => {
       // console.log("Error occured: GetM()");
         this.handleError("", err);
       this.isEditMode = false;
       this.intSetViewMode();
      //  this.finishViewChange();
         
      });
    }
    else {
      this.getNewArmyBillingCycle();
     }

  }
  
  getArmyBillingCycleDataWithNewSesionLock(cycleId: string) : Observable<any> {
    this.setComponentLockSessionId("");
    let obs = this.billingRestService.openLockSession();
    obs.subscribe(
        data => {
          let lockId: string = data;
          this.setComponentLockSessionId(lockId);
          this.getArmyBillingCycle(cycleId,lockId);
  
        },
        err => {
          this.intSetViewMode();
           this.handleError("", err);
      });
    return obs;
    
}

  deleteCycle() {
    this.deleteArmyBillingCycle();
   
  }

  deleteArmyBillingCycle() {
    throw new Error("Abstract method not implemented");

  }
  
    
  deleteArmyBillingCycleData(apiUrl : string , cycleId : string) {
    this.theCC.status = EntityStatus.ENT_DELETED;
    if (this.theCC.budgetControlList != null) {
      this.theCC.budgetControlList.forEach(bcn => {
        bcn.status = EntityStatus.ENT_DELETED;
        if (bcn.budgetComponentList != null) {
          bcn.budgetComponentList.forEach(bcx => {
            bcx.status = EntityStatus.ENT_DELETED;
          });
        }
        if (bcn.budgetControlStatusList != null) {
          bcn.budgetControlStatusList.forEach(bcs => {
            bcs.status = EntityStatus.ENT_DELETED;
          });
        }
      });
    }
    this.billingRestService.deleteArmyBillingCycle(apiUrl,cycleId)
    .subscribe(
      data => {
        let success: boolean = data;
        if (success == true) {
          console.log("cycle control was deleted.");
          this.displaySnackBarMessage("Cycle " + cycleId + " has been deleted.", false);
          this.resetCycleSelection();
          this.isEditMode = false;
          this.disableButtons();
        //  let id: number = 0;
        //  this.router.navigate(['/billing/mangemanual', id.toString()]);
          this.getArmyBillingCycleIdList("");
        } else {
          console.log("delete Cycle Control returned status = false.");
          this.displaySnackBarMessage("Cycle " + cycleId + " has not been deleted.", true);
        }
      },
      err => {
        this.handleError("", err);
      
      });
  }
 
  deleteArmyModdBillingCycleData(cycleId : string, cycleTypeId : string) {
    this.theCC.status = EntityStatus.ENT_DELETED;
    if (this.theCC.budgetControlList != null) {
      this.theCC.budgetControlList.forEach(bcn => {
        bcn.status = EntityStatus.ENT_DELETED;
        if (bcn.budgetComponentList != null) {
          bcn.budgetComponentList.forEach(bcx => {
            bcx.status = EntityStatus.ENT_DELETED;
          });
        }
        if (bcn.budgetControlStatusList != null) {
          bcn.budgetControlStatusList.forEach(bcs => {
            bcs.status = EntityStatus.ENT_DELETED;
          });
        }
      });
    }
    this.billingRestService.deleteArmyMODDCycle(cycleId,cycleTypeId)
    .subscribe(
      data => {
        let success: boolean = data;
        if (success == true) {
          console.log("cycle control was deleted.");
          this.displaySnackBarMessage("Cycle " + cycleId + " has been deleted.", false);
          this.resetCycleSelection();
          this.isEditMode = false;
          this.disableButtons();
        //  let id: number = 0;
        //  this.router.navigate(['/billing/mangemanual', id.toString()]);
          this.getArmyBillingCycleIdList("");
        } else {
          console.log("delete Cycle Control returned status = false.");
          this.displaySnackBarMessage("Cycle " + cycleId + " has not been deleted.", true);
        }
      },
      err => {
        this.handleError("", err);
      
      });
  }

  saveCycle() {
    if (this.validateData()) this.saveData();
  }

  validateData(): boolean {
    this.calculateTotals();
   
    return this.validateForSaveCycle();
  }

  saveData(): Observable<any> {
    return this.saveArmyBillingCycle();
  }

  saveArmyBillingCycle(): Observable<any> {
    throw new Error("Abstract method not implemented");
  }
  protected saveArmyBillingCycleData(apiUrl: string, lockSessionId: string): Observable<any> {
    let ccIdBefore: string  ="0";
    if (this.theCC.cycle_CONTROL_ID != null && this.theCC.cycle_CONTROL_ID.toString().length > 1) {
      ccIdBefore = this.theCC.cycle_CONTROL_ID.toString();
    }
    if (this.deletedBudgetControls.length > 0) {
      this.deletedBudgetControls.forEach(bcn => {
        this.theCC.budgetControlList.push(bcn);
        
      });
    }
    console.log("saveArmyBillingCycleData ccIdBefore save = " + ccIdBefore + ", title = " + this.theCC.cycle_TITLE_NM);
   this.showSpinner.next(true);
   let obs =  this.billingRestService.saveArmyBillingCycle(apiUrl,this.theCC,lockSessionId);
    obs.subscribe(
      data => {
        this.showSpinner.next(false);
        console.log(" saveCycle results");
        let results: SavedCycleResults = data;
        
        if ( results.theSavedCycleControlId != null) {
          if (results.messageList != null && results.messageList.length > 0) {
            this.displayMessages(results.messageList);
            console.log(" saveCycle messages should have been displayed");
          }
          console.log('Save cycle success');
          this.theCC = results.theSavedCycleControlId;
          this.refreshBcnList();
          this.calculateTotals();
        
        let ccId: string = results.theSavedCycleControlId.cycle_CONTROL_ID.toString();
          if (this.destroyInProgress == false) {
            this.statusMessage = "Cycle saved";
           
            if (ccIdBefore == '0') {
              let newCycle: ISelectOptions = { viewValue: ccId, value: ccId };
              this.cycles.push(newCycle);
              this.getArmyBillingCycleDataWithNewSesionLock(ccId)
            } else {
              this.getArmyBillingCycleIdList(ccId);
            }
           
          }
         
          this.displaySnackBarMessage("Cycle " + ccId + " has been saved.", false);
          if (this.destroyInProgress) {
            this.finishNgDestroy();
          } else {
            if (ccId != ccIdBefore) {
              console.log("if (ccId != ccIdBefore");
             // this.getArmyBillingCycleDataWithNewSesionLock(ccId);
              this.closeLockSession();
            }
            console.log("ccId after = " + ccId + ", title = " + this.theCC.cycle_TITLE_NM);
            if (ccIdBefore == '0'){
              this.getArmyBillingCycleIdList(ccId);
            }
           // }
          }
         
         
         // this.displaySnackBarMessage("Save cycle has failed.", true);
          if (this.destroyInProgress) {
            this.finishNgDestroy();
          }
        }

     
      },
      err => {
        this.handleError("",  err);
        if (this.destroyInProgress) {
          this.finishNgDestroy();
        }
      
      });
      return obs;
}  


  approveCycle() {
   if (this.hasCycleChanged()) {
      this.displayErrorMessage("Approve Cycle", "Please save the cycle before cycle approval")
        .subscribe(result => {
       });
      return;
    } else if (this.validateForApproveCycle() == true) {
      this.approveArmyBillingCycle();
    }
  } 

  approveArmyBillingCycle() {
    throw new Error("Abstract method not implemented");
  }
  approveArmyBillingCycleData(apiUrl: string, cycleId: string, lockSessionId: string) {
   this.showSpinner.next(true);
       this.billingRestService.approveArmyBillingCycle(apiUrl, this.theCC.cycle_CONTROL_ID.toString(),
        lockSessionId)
        .subscribe(
          data => {
            this.showSpinner.next(false);
            console.log(" approveCycle()  results");
            let results: ApproveCycleResults = data;
            if (results.messageList != null && results.messageList.length > 0) {
              this.displayMessages(results.messageList);
            } else
              if (results.success) {
                this.displaySnackBarMessage("Cycle " + this.theCC.cycle_CONTROL_ID + " has been approved.", false);
                // this.DisplayInformationMessage("Approve Cycle", "Cycle " + this.theCC.cycle_CONTROL_ID + " has been approved.")
                // .subscribe(result => {
  
                console.log('Approve cycle complete');
               // let id: number = 0;
               // this.router.navigate(['/billing/mangemanual', id.toString()]);
               this.resetCycleSelection();
               this.isEditMode = false;
                this.disableButtons();
                this.getArmyBillingCycleIdList("");
             //  let id: number = 0;
            //  this.router.navigate(['/billing/mangemanual', id.toString()]);
             
                //  });
              } else {
                this.displayErrorMessage("Approve Cycle", "Approve has failed for Cycle " + this.theCC.cycle_CONTROL_ID)
                  .subscribe(result => {
                     console.log("Approve Cycle cancelled, cycle data not saved");
                  });
              }
            
          },
          err => {
            this.handleError("", err);
         
          });

  }

  
  approveArmyModdBillingCycleData(cycleData: any, lockSessionId: string) {
   this.showSpinner.next(true);
    this.billingRestService.approveArmyMODDCycle(cycleData,lockSessionId)
     .subscribe(
       data => {
         console.log(" approveCycle()  results");
         let results: ApproveCycleResults = data;
         if (results.messageList != null && results.messageList.length > 0) {
           this.displayMessages(results.messageList);
         } else
           if (results.success == 1) {
             this.displaySnackBarMessage("Cycle " + this.theCC.cycle_CONTROL_ID + " has been approved.", false);
             // this.DisplayInformationMessage("Approve Cycle", "Cycle " + this.theCC.cycle_CONTROL_ID + " has been approved.")
             // .subscribe(result => {

             console.log('Approve cycle complete');
            // let id: number = 0;
            // this.router.navigate(['/billing/mangemanual', id.toString()]);
            this.resetCycleSelection();
             this.resetViewMode();
             this.disableButtons();
             this.getArmyBillingCycleIdList("");
          //  let id: number = 0;
         //  this.router.navigate(['/billing/mangemanual', id.toString()]);
         this.showSpinner.next(false);
             //  });
           } else {
            this.showSpinner.next(false);
             this.displayErrorMessage("Approve Cycle", "Approve has failed for Cycle " + this.theCC.cycle_CONTROL_ID)
               .subscribe(result => {
    
                 console.log("Approve Cycle cancelled, cycle data not saved");
               });
           }
         
       },
       err => {
        this.showSpinner.next(false);
         this.handleError("", err);
      
       });

}
  approveArmyBillingCycleTypeData(apiUrl : string,cycleId : string, cycleTypeId : string, lockSessionId : string) {
      this.billingRestService.approveArmyBillingCycleType(apiUrl, cycleId,cycleTypeId,
       lockSessionId)
        .subscribe(
          data => {
            console.log(" approveCycle()  results");
            let results: ApproveCycleResults = data;
            if (results.messageList != null && results.messageList.length > 0) {
              this.displayMessages(results.messageList);
            } else
              if (results.success) {
                this.displaySnackBarMessage("Cycle " + this.theCC.cycle_CONTROL_ID + " has been approved.", false);
                // this.DisplayInformationMessage("Approve Cycle", "Cycle " + this.theCC.cycle_CONTROL_ID + " has been approved.")
                // .subscribe(result => {
  
                console.log('Approve cycle complete');
               // let id: number = 0;
               // this.router.navigate(['/billing/mangemanual', id.toString()]);
               this.resetCycleSelection();
               this.isEditMode = false;
                this.disableButtons();
                this.getArmyBillingCycleIdList("");
             
                //  });
              } else {
                this.displayErrorMessage("Approve Cycle", "Approve has failed for Cycle " + this.theCC.cycle_CONTROL_ID)
                  .subscribe(result => {
                     console.log("Approve Cycle cancelled, cycle data not saved");
                  });
              }
            
          },
          err => {
            this.handleError("",  err);
         
          });
   
  }

  displayMessages(messageList : ErrorParameter[]){
    messageList.forEach(element => {
      console.log(element.messageText);
      
    });
    this.displayUserErrorMessages(messageList);
  }
  

  setService(caseUsageCd: string) {
    console.log("setService(" +caseUsageCd + ")" )
    if (caseUsageCd== null){
      this.selectedServiceName = "Army";
      this.selectedService = "A";
    } else if (caseUsageCd== "Y"){
      this.selectedServiceName = "Navy";
      this.selectedService = "N";
    } else if (caseUsageCd== "Z"){
      this.selectedServiceName = "Air Force";
      this.selectedService = "F";
    }
  }

  setSelectedServiceName(service : string){
    if (service == "A") {
      this.selectedServiceName = "Army";
     
    } else if (service == "N") {
      this.selectedServiceName = "Navy";
   } else if (service == "F") {
      this.selectedServiceName = "Air Force";
     
    }
  }

  
  setCycleTypeId() {
  
}

  setCycleCaseUsageCd(){
    if (this.selectedService == "Army"){
      this.theCC.case_USAGE_INDICATOR_CD = null;
    } else if (this.selectedService == "Air Force"){
      this.theCC.case_USAGE_INDICATOR_CD = "Z"
    
    } else if (this.selectedService == "Navy"){
      this.theCC.case_USAGE_INDICATOR_CD = "Y";
    } else {
      this.theCC.case_USAGE_INDICATOR_CD = null; 
    }
    // console.log("set cycle usage to " +  this.theCC.case_USAGE_INDICATOR_CD );
  }
 
refreshBcnList() {
//  this.calculateTotals();
  if (this.theCC.budgetControlList != null && this.theCC.budgetControlList.length > 1) {
    console.log("before sort), " + this.theCC.budgetControlList.length + " budget controls retrieved" )
    this.theCC.budgetControlList = this.theCC.budgetControlList.sort(this.compareBCN);
  }
    this.dsBcnData.data = this.theCC.budgetControlList;
  console.log("refreshBcnList(), " + this.theCC.budgetControlList.length + " budget controls retrieved")
  this.logBcnSuffixList(this.theCC.budgetControlList);
  // this.bcnTable.renderRows();

  }
  compareBCN(bcn1: BUDGET_CONTROL, bcn2: BUDGET_CONTROL) {
    let key1: string = "";
    let key2: string = "";
    
    if (bcn1.theTrainingTrackLineSeqCd != null) {
      let ttl1: TRAINING_TRACK_LINE = bcn1.theTrainingTrackLineSeqCd;
      key1 = ttl1.userCaseId + ttl1.userCaseLineNumberId + ttl1.wcn + ttl1.wcn_SUFFIX_CD;
      console.log(key1 + " Fin Status type = " + ttl1.tl_FINANCIAL_STATUS_TYPE_ID);
      if (bcn2.theTrainingTrackLineSeqCd != null) {
        let ttl2: TRAINING_TRACK_LINE = bcn2.theTrainingTrackLineSeqCd;
        key2 = ttl2.userCaseId + ttl2.userCaseLineNumberId + ttl2.wcn + ttl2.wcn_SUFFIX_CD;
        console.log(key2 + " Fin Status type = " + ttl2.tl_FINANCIAL_STATUS_TYPE_ID);
      }
    }
    else if (bcn1.theTrngTrkTlaSummarySeqCd != null) {
      let t1: TRNG_TRK_TLA_SUMMARY = bcn1.theTrngTrkTlaSummarySeqCd;
      key1 =   t1.userCaseId + t1.userCaseLineNumberId + t1.wcn + t1.external_FINANCIAL_CD;
      if (bcn2.theTrngTrkTlaSummarySeqCd != null) {
        let t2: TRNG_TRK_TLA_SUMMARY = bcn2.theTrngTrkTlaSummarySeqCd;
        key2 =   t2.userCaseId + t2.userCaseLineNumberId + t2.wcn + t2.external_FINANCIAL_CD;
    }
     
    }
      if (key1 > key2) {
        return 1;
    }

      if (key1 < key2) {
        return -1;
    }

    return 0;
  }
  getTTLKey(ttl: TRAINING_TRACK_LINE): string{
    console.log(ttl.userCaseId + ttl.userCaseLineNumberId + ttl.wcn + ttl.wcn_SUFFIX_CD);
    let ttlKey: string = ttl.userCaseId + ttl.userCaseLineNumberId + ttl.wcn + ttl.wcn_SUFFIX_CD;
    console.log("ttlKey " + ttlKey);
    return ttlKey;
  
  }
  
  getTTTSKey(ttts: TRNG_TRK_TLA_SUMMARY): string{
    let tt: TRAINING_TRACK = ttts.theTrainingTrackSeqCd;
    let cml: CASE_MASTER_LINE = tt.TheCaseMasterLineId;
    let cm: CASE_MASTER = cml.theCaseId; 
    let key: string = cm.user_CASE_ID + cml.user_CASE_LINE_NUMBER_ID + tt.worksheet_CONTROL_NUMBER_CD  + ttts.external_FINANCIAL_CD;
    console.log("tttsKey = "  + key);
    return key;
  
 }
  compareSelOption(val1: ISelectOptions, val2: ISelectOptions) {
   
    if (val1.value > val2.value) {
        return 1;
    }

      if (val1.value <val2.value) {
        return -1;
    }

    return 0;
  }
    
  
  
   
  
  validateForSaveCycle(): boolean {
    throw new Error("Abstract method not implemented");
  
  }
  
  logBcnSuffixList(list: BUDGET_CONTROL[]) {
    list.forEach(bcn => {
      console.log(this.getBcnSuffixString(bcn));
    });
  }

  getBcnSuffixString(bcn: BUDGET_CONTROL): string {
    let suffix: string = "";
    if (bcn.theTrainingTrackLineSeqCd != null) {
      let t1: TRAINING_TRACK_LINE = bcn.theTrainingTrackLineSeqCd;
     suffix = t1.userCaseId + '/' + t1.userCaseLineNumberId + '/' + t1.wcn + '/'  + t1.wcn_SUFFIX_CD + '/' ;
	 suffix = suffix + ((t1.tl_FINANCIAL_STATUS_TYPE_ID != null) ? t1.tl_FINANCIAL_STATUS_TYPE_ID  : 'null');
   
      
    }
    else if (bcn.theTrngTrkTlaSummarySeqCd != null) {
      let t1: TRNG_TRK_TLA_SUMMARY = bcn.theTrngTrkTlaSummarySeqCd;
     suffix = t1.userCaseId + '/' + t1.userCaseLineNumberId + '/' + t1.wcn + '/'  + t1.external_FINANCIAL_CD + '/' ;
	 suffix = suffix + ((t1.tl_FINANCIAL_STATUS_TYPE_ID != null) ? t1.tl_FINANCIAL_STATUS_TYPE_ID  : 'null')
    } else {
      suffix = "Suffix Id: " + bcn.case_ID + "." + bcn.case_MASTER_LINE_ID + "." + bcn.training_TRACK_SEQ_CD;
       
    }
    return suffix;
  }

  getBcnSuffixModdKey(bcn: BUDGET_CONTROL): string {
    let userKey: String = (bcn.fiscal_YEAR_ID == null) ? "" : bcn.fiscal_YEAR_ID;
    userKey = userKey.concat((bcn.moddDocNumberCd == null) ? "" : bcn.moddDocNumberCd);
    userKey = userKey.concat((bcn.wbsApcCd == null) ? "" : bcn.wbsApcCd); 
    if (bcn.theTrainingTrackLineSeqCd != null) {
      let t1: TRAINING_TRACK_LINE = bcn.theTrainingTrackLineSeqCd;
      userKey = userKey.concat((t1.userCaseId == null) ? "" : t1.userCaseId);
      userKey  = userKey.concat(( t1.userCaseLineNumberId == null) ? "" : t1.userCaseLineNumberId);
      userKey  = userKey.concat(( t1.wcn == null) ? "" : t1.wcn);
      userKey  = userKey.concat(( t1.wcn_SUFFIX_CD == null) ? "" : t1.wcn_SUFFIX_CD);
    }
    
    return userKey.toString();
  }

 

  getBcnTlaString(bcn: BUDGET_CONTROL): string {
    let suffix: string = "";
    if (bcn.theTrngTrkTlaSummarySeqCd != null) {
      suffix = bcn.theTrngTrkTlaSummarySeqCd.userCaseId + "/" +
        bcn.theTrngTrkTlaSummarySeqCd.userCaseLineNumberId + "/" +
        bcn.theTrngTrkTlaSummarySeqCd.wcn + "/" +
        bcn.theTrngTrkTlaSummarySeqCd.external_FINANCIAL_CD;
      
    } else {
      suffix = "Ttts Id: " + bcn.case_ID + "." + bcn.case_MASTER_LINE_ID + "." + bcn.training_TRACK_SEQ_CD
        + "." + bcn.trng_TRK_TLA_SUMMARY_SEQ_CD;
    }
    return suffix;
  }
  

  displayUserErrorMessages(messageList : ErrorParameter[]) {
   // console.log("DisplayUserErrorMessag(" + title + "," + message + ")");
    let ccidStr = (this.theCC != null && this.theCC.cycle_CONTROL_ID != null) ? this.theCC.cycle_CONTROL_ID : "";

    let title: string = 'DSAMS Messages for Cycle Id ' +ccidStr;
     this.messageService.displayMessageList(title,messageList).subscribe(result => {
     
      console.log('MessageList hasa been displayed');
     
      
     });

    

  }

  alertMessage(title: string, message: string) {
    // console.log("DisplayUserErrorMessag(" + title + "," + message + ")");
    // this.messageData = this.messageService.informationMsgData();
    //  this.messageData.title = title;
    //  this.messageData.message = message;
    //  return this.messageService.showMessage(this.messageData);
    this.messageService.alertMessage(title, message);
 
  }

  confirmMessage(title: string, message: string)  {
    // console.log("DisplayUserErrorMessag(" + title + "," + message + ")");
    // this.messageData = this.messageService.informationMsgData();
    //  this.messageData.title = title;
    //  this.messageData.message = message;
    //  return this.messageService.showMessage(this.messageData);
    return this.messageService.confirmMessage(title, message);
    // if (this.messageService.confirmMessage(title, message)) {
    //   return true;
    // } else {
    //   return false;
    // }
    
 
  }

  displaySnackBarMessage(message: string, isError: boolean) {
    let matMessageType: string = isError ? 'mat-warn' : 'mat-primary';
      this._snackBar.open(message, 'close',  {
      duration: this.durationInSeconds * 1000,
      panelClass: ['mat-toolbar', matMessageType]  
    });
 
  }

  openConfirmationDialog(title : string,message : string) {
    this.messageData = this.messageService.confirmationMsgData();
    this.messageData.title = title;
    this.messageData.message = message;
    return this.messageService.showMessage(this.messageData)
   

  }

  openProceedDialog(title : string,message : string) {
    this.messageData = this.messageService.proceedMsgData();
    this.messageData.title = title;
    this.messageData.message = message;
    return this.messageService.showMessage(this.messageData)
   

  }
  
  displayInformationMessage(title: string, message: string) {
    // console.log("DisplayUserErrorMessag(" + title + "," + message + ")");
    // this.messageData = this.messageService.informationMsgData();
    //  this.messageData.title = title;
    //  this.messageData.message = message;
    //  return this.messageService.showMessage(this.messageData);
    this.messageService.confirmMessage(title, message);
 
  }
  
  displayErrorMessage(title: string, message: string) {
    // console.log("DisplayUserErrorMessag(" + title + "," + message + ")");
    this.messageData = this.messageService.errorMsgData();
     this.messageData.title = title;
    this.messageData.message = message;
    this.messageData.pxHeight = 200;
     return this.messageService.showMessage(this.messageData);
     
 
  }
   
  displayErrorMessageWithDetails(title: string, message: string,details: string) {
    // console.log("DisplayUserErrorMessag(" + title + "," + message + ")");
    this.messageData = this.messageService.errorMsgData();
     this.messageData.title = title;
    this.messageData.message = message;
    this.messageData.hasDetails = true;
    this.messageData.details = details;
       if (details !== null && details.length > 0) {
      this.messageData.hasDetails = true;
      this.messageData.pxHeight = 500;
    } else {
      this.messageData.hasDetails = false;
      this.messageData.pxHeight = 200;
    }
     return this.messageService.showMessage(this.messageData);
     
 
   }
//
 

  
  
  


 
  validateForApproveCycle(): boolean {
    throw new Error("Abstract method not implemented");
   
  }
  
  
 
  
  getArmyBillingCycleIdList(cycleId : string) {
    throw new Error("Abstract method not implemented");
  }

  getArmyBillingCycleIdsWithSelect(apiUrl : string,selCycleId : string) {
    console.log("Start getArmyBillingCycleIdswithSelect(" + apiUrl + ",)" +selCycleId );
    //this.cycles = [];
   
    this.cycleListLoaded = false;
   this.showSpinner.next(true);
     this.billingRestService.getArmyBillingCycleIdList(apiUrl)
    .subscribe(
      data => {
        console.log("getArmyBillingCycleIdList complete");
        this.cycles = data;
        this.showSpinner.next(false);
        if (this.isAllowedToEnableSlider) {
          this.cycles.unshift({
            value: " ",
            viewValue: "Create new cycle"
          });
        }
        this.cycles.sort(this.compareSelOption);
        console.log("this.cycles.length" + this.cycles.length)
        if (selCycleId.length > 1) {
          this.selectedCycle = { viewValue: selCycleId, value: selCycleId };
          this.getArmyBillingCycle(selCycleId, this.getComponentLockSessionId());
          this.isCreateNewCycle = false;
          this.cycleIsSel = true;
          this.setCycleDataLoaded();
          
       }
       },
      err => {
        this.handleError("", err);
      });
  }
 
  
  getBasicCaseUsageCdList() {
    if (this.cycleUsageLoaded == false) {
      this.cycleUsageLoading = true;
      this.billingRestService.getBasicCaseUsageIndicators()
        .subscribe(
          data => {
            this.validCaseUsageIndicators = data;
            // for ( var vcu of  this.validCaseUsageIndicators) {
            //   console.log("value = " + vcu.value + 
            //   ", view value = " + vcu.viewValue );
          
            // }
            this.cycleUsageLoaded = true;
            this.cycleUsageLoading = false;
       
            // console.log("load getBasicCaseUsageIndicators() complete")
          },
          err => {
            this.handleError("", err);
          });
    }
  }
  
  handleError(apiUrl: string, error: any) {
    
    let errorMsgTitle: string = "";
    let errorMsg: string = "";
    let details: string = "";
    let errorCode: string = "";
    if (error.error == null) {
      errorMsgTitle = error.name;
      errorMsg = error.message;
      details = null;
      errorCode = (typeof error.status !== 'undefined') ? error.status : 0;
      errorMsg = "Status Code " + errorCode + ", " + errorMsg;
    } else if (error.error instanceof ErrorEvent) {
      errorMsg = 'An error event occurred: ' + error.error.message;
      errorMsgTitle = "Local Error"
    
    } else {

      if (error.error != null && typeof error.error.lockConflict !== 'undefined' && error.error.lockConflict != null) {
        if (error.error.lockConflict) {
          errorMsgTitle = "Lock Conflict;"
          errorMsg = error.error.message;
        
        } else {
          if (error.error.exceptionType !== 'undefined') {
            errorMsg = error.error.exceptionType +
              ' - "' + error.error.message + '"';
            details = errorMsg + "\n" + error.error.stackTrace;
          }
        }
      }
    }
    this.displayErrorMessageWithDetails(errorMsgTitle, errorMsg,details)
    .subscribe(result => {
      return throwError(error);
  });
  
  }

  ngOnDestroy() {
    this.destroyInProgress = true;
    this.finishNgDestroy();
    // if (this.hasCycleChanged()) {
    //   this.openExitConfirmationDialog();
    // } else {
    //   this.finishNgDestroy();
    // }
  
  } 
  private finishNgDestroy() {
    this.destroyInProgress = false;
    this.closeLockSession();
    if (this.parmSubscription != null) {
      this.parmSubscription.unsubscribe();
    }
  }
   
  
}
 

 


