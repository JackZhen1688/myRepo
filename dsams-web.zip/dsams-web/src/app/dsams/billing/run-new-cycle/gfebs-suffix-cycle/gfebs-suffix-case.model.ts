export class GfebsSuffixCase {
    case: string;
    line: number;
    wcn:  number;
    suffix: string;
    fy:   number;
    finStat: string;
    docNo: string;
    eor:  string;
    exa:  string;
    paymentType: string;
  }