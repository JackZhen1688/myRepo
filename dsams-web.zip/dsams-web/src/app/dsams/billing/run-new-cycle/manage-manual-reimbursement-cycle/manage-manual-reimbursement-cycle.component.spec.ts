import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MangeManualReimbursementCycleComponent } from './manage-manual-reimbursement-cycle.component';

describe('MangeManualReimbursementCycleComponent', () => {
  let component: MangeManualReimbursementCycleComponent;
  let fixture: ComponentFixture<MangeManualReimbursementCycleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MangeManualReimbursementCycleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MangeManualReimbursementCycleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
