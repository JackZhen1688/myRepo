export class CasePayment {
    idx: number;
    idx2: number;
    tfo: string;
    funded: number;
    paid:  number;
    billed:   number;
    posted: number;
    billAm: number;
    isUpdate: boolean;
    isNew: boolean;
    isDelete: boolean;

    constructor(obj?: any) {
      if (obj) {
        if (obj.idx ) {
          this.idx = obj.idx;
        }
        else {
          this.idx = -1;
        }
        if (obj.idx2 ) {
          this.idx2 = obj.idx2;
        }
        else {
          this.idx2 = -1;
        }
        if (obj.tfo ) {
          this.tfo = obj.tfo;
        }
        else {
          this.tfo = '';
        }
        if (obj.funded ) {
          this.funded = obj.funded;
        }
        else {
          this.funded = 0;
        }
        if (obj.paid ) {
          this.paid = obj.paid;
        }
        else {
          this.paid = 0;
        }
        if (obj.billed ) {
          this.billed = obj.billed;
        }
        else {
          this.billed = 0;
        }
        if (obj.posted ) {
          this.posted = obj.posted;
        }
        else {
          this.posted = 0;
        }
        if (obj.billAm ) {
          this.billAm = obj.billAm;
        }
        else {
          this.billAm = 0;
        }
        if (obj.isUpdate ) {
          this.isUpdate = obj.isUpdate;
        }
        else {
          this.isUpdate = false;
        }
        if (obj.isNew ) {
          this.isNew = obj.isNew;
        }
        else {
          this.isNew = false;
        }
        if (obj.isDelete ) {
          this.isDelete = obj.isDelete;
        }
        else {
          this.isDelete = false;
        }
      }
      else {
        this.idx           = -1;
        this.idx2          = -1;
        this.tfo           = '';
        this.funded        = 0;
        this.paid          = 0;
        this.billed        = 0;
        this.posted        = 0;
        this.billAm        = 0;
        this.isUpdate      = false;
        this.isNew         = false;
        this.isDelete      = false;
      }
    }
  }