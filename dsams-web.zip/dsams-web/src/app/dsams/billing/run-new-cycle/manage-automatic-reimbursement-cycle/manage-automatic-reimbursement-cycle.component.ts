import { Component, OnInit, Injector } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { MatSnackBar } from '@angular/material/snack-bar';
import { CommonModule, CurrencyPipe} from '@angular/common';
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { MatDialogRef, MatDialogConfig, MatDialog, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatTableDataSource } from '@angular/material/table';
import { TreeviewItem, TreeviewConfig } from 'ngx-treeview';
import { MatSlideToggleChange } from '@angular/material/slide-toggle';
//import { CdkDragDrop, moveItemInArray, transferArrayItem } from '@angular/cdk/drag-drop';
import { DsamsConstants } from './../../../dsams.constants'
import { DsamsRestfulService } from '../../../services/dsams-restful.service'
import { DsamsMethodsService } from './../../../services/dsams-methods.service';
import { BillingRestfulService } from '../../services/billing-restful.service';
import { DsamsShareService } from './../../../services/dsams-share.service';
import { ReimbursementService } from '../../services/manage-manual-reimbursement.service';
import { DialogMessageYesnoComponent } from './../../../utilitis/dialogs/dialog-message-yesno/dialog-message-yesno.component';
import { BehaviorSubject } from 'rxjs';

@Component({
  selector: 'app-manage-automatic-reimbursement-cycle',
  templateUrl: './manage-automatic-reimbursement-cycle.component.html',
  styleUrls: ['./manage-automatic-reimbursement-cycle.component.css']
})
export class MangeAutomaticReimbursementCycleComponent implements OnInit {

  disSystemEditable: boolean = true;
  serviceId: string;
  cycles: string[];
  dropdownEnabled = true;
  items: TreeviewItem[];
  values: string = '';
  durationInSeconds = 5;
  config = TreeviewConfig.create({
      hasAllCheckBox: true,
      hasFilter: true,
      hasCollapseExpand: true,
      decoupleChildFromParent: false,
      maxHeight: 250
  });
/*
  buttonClasses = [
      'btn-outline-primary',
      'btn-outline-secondary',
      'btn-outline-success',
      'btn-outline-danger',
      'btn-outline-warning',
      'btn-outline-info',
      'btn-outline-light',
      'btn-outline-dark'
  ];
  buttonClass = this.buttonClasses[0];
*/
  /* drag and drop
  todo: string[]; 
  todelete: string[] = [];
  data: any = {}; 
  */
  // begin jiracard DSAMS-5967 10/2022 AKP
  showSpinner: BehaviorSubject<boolean> = new BehaviorSubject(false);  
  // end jiracard DSAMS-5967 10/2022 AKP

  automangeForm: FormGroup;

  displayedColumn: string[] = ['dovnum','empty','datepull'];
  dataSource = new MatTableDataSource();

  dsamsShareService: DsamsShareService;
  billingRestService: BillingRestfulService;
  reimbursementService: ReimbursementService;
  dsamsMethodsService: DsamsMethodsService;
  constructor(private injector : Injector,
              private route: ActivatedRoute, 
              private currencyPipe : CurrencyPipe,
              private formBuilder: FormBuilder, 
              public dialog: MatDialog,
              private _snackBar: MatSnackBar,
              protected dsamsReferenceService: DsamsRestfulService)
{ 
    this.dsamsShareService = injector.get<DsamsShareService>(DsamsShareService);
    this.billingRestService = injector.get<BillingRestfulService>(BillingRestfulService);
    this.reimbursementService = injector.get<ReimbursementService>(ReimbursementService);
    this.dsamsMethodsService = injector.get<DsamsMethodsService>(DsamsMethodsService);
}
 
  ngOnInit() {
    this.dsamsShareService.csuname.next(this.route.snapshot.params['csu']);
    this.serviceId = sessionStorage.getItem('serviceDBid');
    this.contructAutomangeForm();
    this.reimbursementService.setEditingMode(this.edit.value);
    //this.items = this.service.getBooks();
    //this.initializeAutomangeFrom(this.getCycleId());
    this.getCycle("#"+this.serviceId);
    
    console.log('encoded uri is ' +encodeURIComponent(this.getCSU_CD()+"#"+this.serviceId));
    //this.getEditableAccess(encodeURIComponent(this.getCSU_CD()+"#"+this.serviceId));
    this.getEditableAccess(encodeURIComponent("WP102#"+this.serviceId));
    if (this.getCycleId() != ' ') {
        this.onParamPath(this.getCycleId());
        this.automangeForm.patchValue({
          'cycle': this.getCycleId(),
        }); 
    }

  }

  ngOnDestroy() {
    this.dsamsShareService.csuname.next(null);
  }

  getCSU_CD(): string {
    let csuCd: string = "";
    this.route.paramMap
        .subscribe(params => {
            csuCd = params.get("csu");
        });
    return csuCd;
  }

  getEditableAccess(filter: string) {
    this.dsamsReferenceService.getEditableAccess(filter)
        .subscribe(
            data => {
                console.log("==>Editable Access===" + data);
                if (data == 1)
                    this.disSystemEditable = false;
            });
  }

  //Construct new FormGroup (formControlName has to be lower case)
  contructAutomangeForm() {
    this.automangeForm = this.formBuilder.group({
        'edit': this.formBuilder.control(''),
        'cycle': this.formBuilder.control('', [Validators.required]),
        'title': this.formBuilder.control(''),  
        'user': this.formBuilder.control(''),
        'amount': this.formBuilder.control(''),
        'uamount': this.formBuilder.control('$0'),
        'serviceIds': this.formBuilder.control(''),
        'treeValues': this.formBuilder.control(''),
    }); 
  }

  get edit() {
    return this.automangeForm.get('edit');
  }
  get cycle() {
    return this.automangeForm.get('cycle');
  }
  get title() {
    return this.automangeForm.get('title');
  }
  get uamount() {
    return this.automangeForm.get('uamount');
  }
  get serviceIds() {
    return this.automangeForm.get('serviceIds');
  }
  get treeValues() {
    return this.automangeForm.get('treeValues');
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  } 

  getCycleId() {
    return this.route.snapshot.paramMap.get('cycleid');
  }

  /* drog and drap
  drop(event: CdkDragDrop<string[]>) {
    if (event.previousContainer === event.container) {
      moveItemInArray(event.container.data, event.previousIndex, event.currentIndex);
    } else {
      transferArrayItem(event.previousContainer.data,
                        event.container.data,
                        event.previousIndex,
                        event.currentIndex);
    }
  }
  initializeAutomangeFrom(id) {
    this.billingRestService.getAutoMangeDetails(id)
    .subscribe( data => {
      this.todo = data.recordsincycle;  
      this.assingFormFields(data);
    });
  } 
    
  assingFormFields(data){
    this.automangeForm.patchValue({
      'cycle': data.cycleid,
      'title': data.title,
      'user': data.user,
      'amount': data.amount
    }); 
  }*/
 
  onFilterChange(value: string) {
    console.log('filter:', value);
  }

  fillItemData(data: any[]): void { 
    this.items = this.getDataArray(data); 
  }

  getDataArray(data: any[]): any[] { 
    let countryTree: TreeviewItem[] = [];
    for (let i = 0; i < data.length; i++) {
         countryTree.push(new TreeviewItem(data[i]));
    }
    return countryTree;
    //const AUCategory = new TreeviewItem(data[0]); 
    //const BACategory = new TreeviewItem(data[1]); 
    //return [AUCategory, BACategory]; 
  }

  transformAmount(event){
    event.target.value = this.currencyPipe.transform((event.target.value).replace('$',''), '$');
  }

  getCycle(filter: string) {
    this.billingRestService.getCycle(encodeURIComponent(filter))
    .subscribe(
      data => { 
        this.cycles = data;
      },
      err => {
        console.log("Error occured: getCycle()")
      }
    );
  }

  getAutoReimbursCycle(cycleControlId: string) {
    this.billingRestService.getAutoReimbursCycle(encodeURIComponent(cycleControlId+"#"+this.serviceId))
    .subscribe(
      data => { 
        this.automangeForm.patchValue({
          'title': data.title,
          'user': data.name,
          'amount': data.amount==null?"$0":this.currencyPipe.transform(data.amount, '$'),
          'uamount': '$0'
        }); 
      },
      err => {
        console.log("Error occured: getAutoReimbursCycle()")
      }
    );
  }

  getRecordInCycle(cycleControlId: string) {
    this.billingRestService.getRecordInCycle(encodeURIComponent(cycleControlId+"#"+this.serviceId))
    .subscribe(
      data => { 
        this.fillItemData(data);
     },
      err => {
        console.log("Error occured: getRecordInCycle()")
      }
    );
  } 

  getUnSavedAmount(formValue: any) {
    this.billingRestService.getUnSavedAmount(formValue)
    .subscribe(
      data  => {
         this.uamount.setValue(this.currencyPipe.transform(data, '$'));
      },
      err  => {
        console.log("Error occured: getUnSavedAmount()")
      }
    );  
  }

  deleteCycle(cycleControlId: string) {
    this.billingRestService.deleteCycle(cycleControlId)
    .subscribe(
      data => { 
         if (data) {
             this.getCycle("#"+this.serviceId)
             this._snackBar.open("Delete cycle successfully!", 'close',  {
             duration: this.durationInSeconds * 1000,
             panelClass: ['mat-toolbar', 'mat-primary'] // 'mat-accent' or 'mat-warn'
            });
         } else {
             this._snackBar.open("Delete cycle failure!", 'close',  {
             duration: this.durationInSeconds * 1000,
             panelClass: ['mat-toolbar', 'mat-warn'] // 'mat-accent' or 'mat-warn'
            });
         }
         console.log("POST Request is successful ", data);
     },
      err => {
        console.log("Error occured: deleteCycle()")
      }
    );
  }  

  generateDOVNum(cycleControlId: string) {
    this.billingRestService.generateDOVNum(cycleControlId)
    .subscribe(
      data => { 
         if (data) {
             this._snackBar.open("Generate DOV numbver successfully!", 'close',  {
             duration: this.durationInSeconds * 1000,
             panelClass: ['mat-toolbar', 'mat-primary'] // 'mat-accent' or 'mat-warn'
            });
            this.getDov(cycleControlId);
         } else {
             this._snackBar.open("Generate DOV numbver failure!", 'close',  {
             duration: this.durationInSeconds * 1000,
             panelClass: ['mat-toolbar', 'mat-warn'] // 'mat-accent' or 'mat-warn'
            });
         }
         console.log("POST Request is successful ", data);
     },
      err => {
        console.log("Error occured: generateDOVNum()")
      }
    );
  }  

  approveCycle(cycleControlId: string) {
    this.showSpinner.next(true); //jiracard DSAMS-5967 10/2022 AKP
    this.billingRestService.approveCycle(cycleControlId)
    .subscribe(
      data => {
        if (data.success){  //jiracard DSAMS-5967 10/2022 AKP 
          this.showSpinner.next(false); //jiracard DSAMS-5967 10/2022 AKP 

          this.getCycle("#"+this.serviceId);
            this._snackBar.open("Approve cycle successfully!", 'close',  {
            duration: this.durationInSeconds * 1000,
            panelClass: ['mat-toolbar', 'mat-primary'] // 'mat-accent' or 'mat-warn'
          });
          // begin jiracard DSAMS-5967 10/2022 AKP
          this.automangeForm.reset();
          this.items = [];
          this.automangeForm.get('edit').setValue(false);
          // end jiracard DSAMS-5967 10/2022 AKP
        } else {
          // begin jiracard DSAMS-5967 10/2022 AKP  
          this.showSpinner.next(false); 

            if(data.messageType== "DOV_NUM_ERROR"){
              this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, DsamsConstants.DOV_NOT_GENERATED);
            }
            else if (data.messageType== "EA_NUM_ERROR"){
              this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, DsamsConstants.EA_NOT_GENERATED);
            }
            else {
            // end jiracard DSAMS-5967 10/2022 AKP  
              this._snackBar.open("Approve cycle failure!", 'close',  {
                duration: this.durationInSeconds * 1000,
                panelClass: ['mat-toolbar', 'mat-warn'] // 'mat-accent' or 'mat-warn'
              });
            }  
        } //jiracard DSAMS-5967 10/2022 AKP 
     },
      err => {
        this.showSpinner.next(false); //jiracard DSAMS-5967 10/2022 AKP
        console.log("Error occured: approveCycle()")
      }
    );
  } 
 
  saveCycle(formValue: any) {
    this.billingRestService.saveCycle(formValue)
    .subscribe(
      data => { 
         if (data) {
             this.saveDov();
             this.getAutoReimbursCycle(this.cycle.value);
             this.getRecordInCycle(this.cycle.value);
             this.getDov(this.cycle.value);

             this._snackBar.open("Save cycle successfully!", 'close',  {
             duration: this.durationInSeconds * 1000,
             panelClass: ['mat-toolbar', 'mat-primary'] // 'mat-accent' or 'mat-warn'
            });
         } else {
             this._snackBar.open("Save cycle failure!", 'close',  {
             duration: this.durationInSeconds * 1000,
             panelClass: ['mat-toolbar', 'mat-warn'] // 'mat-accent' or 'mat-warn'
            });
         }
         console.log("POST Request is successful ", data);
     },
      err => {
        console.log("Error occured: saveCycle()")
      }
    );
  }


  getDOVNumbers() {
    this.billingRestService.getDOVNumbers()
    .subscribe( data => {
      this.dataSource.data = data; 
    });
  } 

  onToggle(event: MatSlideToggleChange) {
    
    if (event.checked) {
      this.reimbursementService.setEditingMode(this.edit.value);
    }
    else {
      if ((this.values != "") || this.reimbursementService.dovHasChaged()) {
        
        const dialogConfig = new MatDialogConfig();
        dialogConfig.disableClose = true;
        dialogConfig.autoFocus = true;
        dialogConfig.width= "550px"; 
        dialogConfig.data = {message: DsamsConstants.TOGGLE_EDIT_CHANGE, indecator: 'Save'};
        const dialogRef = this.dialog.open(DialogMessageYesnoComponent, dialogConfig);
        dialogRef.afterClosed().subscribe(result => {
          //FR34
          if (result == 0) {   //Cancel
            this.automangeForm.get('edit').setValue(true);
          }
          if (result == 1) {   //Save
            event.source.checked = false;
            event.checked = false;
            if (this.values =='') {
              this.saveDov();
            } else {
              this.saveCycle(this.automangeForm.value);
            }
          }
          if (result == 2) {  //Continue           
           // console.log('unlock recs');
            this.getAutoReimbursCycle(this.cycle.value);
            this.getRecordInCycle(this.cycle.value);
            this.getDov(this.cycle.value);
          }
        });
      }
    }

  }

  onParamPath(cycleControlId: string) {
    this.getAutoReimbursCycle(cycleControlId);
    this.getRecordInCycle(cycleControlId);
    this.getDov(cycleControlId);
  }

  onChange(event) {
    if (this.edit.value) {
        if (this.values == '') {
            this.getAutoReimbursCycle(event.source.value);
            this.getRecordInCycle(event.source.value);
            this.getDov(event.source.value);
        } else {
          const dialogConfig = new MatDialogConfig();
          dialogConfig.disableClose = true;
          dialogConfig.autoFocus = true;
          dialogConfig.width= "550px"; //DsamsConstants.diaWidth;
          dialogConfig.data = {message: DsamsConstants.CYCLE_ID_CHANGE, indecator: 'Save'};

          const dialogRef = this.dialog.open(DialogMessageYesnoComponent, dialogConfig);

          dialogRef.afterClosed().subscribe(result => {
            if (result == 1) 
                this.saveCycle(this.automangeForm.value);
            if (result == 2) {
                this.getAutoReimbursCycle(event.source.value);
                this.getRecordInCycle(event.source.value);
                this.getDov(event.source.value);
            }
          });
        }
    } else {
        this.getAutoReimbursCycle(event.source.value);
        this.getRecordInCycle(event.source.value);
        this.getDov(event.source.value);
    }
  }

  onSelect(event: any) {
    this.values = event;
    if (this.serviceId != null || this.serviceId != '')
        this.serviceIds.setValue(this.serviceId)
    if (this.values == '') {
        this.uamount.setValue("$0");
    } else { 
        this.treeValues.setValue(JSON.stringify(this.values))
        this.getUnSavedAmount(this.automangeForm.value);
    }
    this.values = JSON.stringify(this.values).replace("[","").replace("]","").replace(/"/gi,"").replace(/,/gi,"\n");
  }

  onDelete() {
    this.deleteCycle(encodeURIComponent(this.cycle.value+"#"+this.serviceId));
    this.automangeForm.reset();
    this.items = [];
    this.edit.setValue('true');
    //this.getCycle("#"+this.serviceId)
  }

  onGenerateDov() {
    if (this.values != '') {
        this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, DsamsConstants.CYCLE_MUST_SAVE)
    } else {
        this.generateDOVNum(encodeURIComponent(this.cycle.value+"#"+this.serviceId));
        this.getDov(this.cycle.value);
    }

  }

  onApproveCycle() {

    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width= DsamsConstants.diaWidth;
    dialogConfig.data = {message: DsamsConstants.APPROVE_CYCLE_COMFIRM};

    const dialogRef = this.dialog.open(DialogMessageYesnoComponent, dialogConfig);

    dialogRef.afterClosed().subscribe(result => {
       if (result == 1) {

          this.approveCycle(encodeURIComponent(this.cycle.value+"#"+this.serviceId));            

       } 
    });

  }

  onSaveCycle() {
    if (this.values =='') {
        if ( this.reimbursementService.dovHasChaged()) {
          this.saveDov();
        }
        else {
          this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, DsamsConstants.NO_DELETE_RECORDS)
        }   
    } else {
        this.saveCycle(this.automangeForm.value);
    }
  }

  revert() {
    this.automangeForm.reset();
    this.items = [];
    this.getCycle("#"+this.serviceId)
    this.edit.setValue('true');
  }

  onSubmit() {
    // ...
  }
  
  saveDov() {
    if (this.reimbursementService.dovHasChaged()) {
      this.reimbursementService.saveDOVs(this.serviceId)
      .subscribe(
        data => { 
          if (data) {
              this._snackBar.open("Save DOVs successfully!", 'close',  {
              duration: this.durationInSeconds * 1000,
              panelClass: ['mat-toolbar', 'mat-primary'] // 'mat-accent' or 'mat-warn'
              });
          } else {
              this._snackBar.open("Save DOVs failure!", 'close',  {
              duration: this.durationInSeconds * 1000,
              panelClass: ['mat-toolbar', 'mat-warn'] // 'mat-accent' or 'mat-warn'
              });
          }
      },
        err => {
          console.log("Error occured: MangeAutomaticReimbursementCycleComponent.saveDov()")
        }
      );
    }
  }
  getDov(cycleleControlId: string) {
    this.billingRestService.getRecordEAInformationData(encodeURIComponent(cycleleControlId+"#"+this.serviceId))
    .subscribe( data => {
        this.reimbursementService.setEAInformationData(data);
      },
      err => {
        console.log("Error occured: MangeAutomaticReimbursementCycleComponent.getDov() -" + err);
      }
    );
  }
  
  disableSlider(): boolean {return this.disSystemEditable};

  
}
