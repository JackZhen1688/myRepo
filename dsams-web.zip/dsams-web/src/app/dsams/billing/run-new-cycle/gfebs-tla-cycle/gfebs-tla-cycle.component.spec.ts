import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GfebsTlaCycleComponent } from './gfebs-tla-cycle.component';

describe('GfebsTlaCycleComponent', () => {
  let component: GfebsTlaCycleComponent;
  let fixture: ComponentFixture<GfebsTlaCycleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GfebsTlaCycleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GfebsTlaCycleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
