import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AutonewReimburseCycleComponent } from './autonew-reimburse-cycle.component';

describe('AutonewReimburseCycleComponent', () => {
  let component: AutonewReimburseCycleComponent;
  let fixture: ComponentFixture<AutonewReimburseCycleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AutonewReimburseCycleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AutonewReimburseCycleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
