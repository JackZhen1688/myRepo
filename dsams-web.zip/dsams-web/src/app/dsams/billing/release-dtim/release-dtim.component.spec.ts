import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReleaseDtimComponent } from './release-dtim.component';

describe('ReleaseDtimComponent', () => {
  let component: ReleaseDtimComponent;
  let fixture: ComponentFixture<ReleaseDtimComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReleaseDtimComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReleaseDtimComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
