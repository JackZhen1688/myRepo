import { Component, OnInit, Injector, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { MatSort } from '@angular/material/sort';
import { MatSnackBar } from '@angular/material/snack-bar';
import { SelectionModel } from '@angular/cdk/collections';
import { MatDialogConfig, MatDialog } from '@angular/material/dialog';
import { MatTableDataSource } from '@angular/material';
import { DsamsConstants } from './../../dsams.constants'
import { DsamsMethodsService } from './../../../dsams/services/dsams-methods.service';
import { BillingRestfulService } from './../services/billing-restful.service';
import { DsamsShareService } from '../../services/dsams-share.service';
import { DialogMessageYesnoComponent } from './../../utilitis/dialogs/dialog-message-yesno/dialog-message-yesno.component'

export interface PeriodicElement {
  cycleControlId: string;
  cycleApprovalDt: string;
  userName: string;
  dtimsStatusName: string;
  fillNoBill: string;
}
@Component({
  selector: 'app-release-dtim',
  templateUrl: './release-dtim.component.html',
  styleUrls: ['./release-dtim.component.css']
})
export class ReleaseDtimComponent implements OnInit {

  displayedColumns: string[] = ['cycleControlId','cycleApprovalDt','userName','dtimsStatusName','select']; 
  dataSource = new MatTableDataSource<PeriodicElement>();
  selection = new SelectionModel<PeriodicElement>(true, []);
  recordCount: number = 0;

  @ViewChild(MatSort, {static: true}) sort: MatSort;

  durationInSeconds = 5;
  serviceId: string;
  releaseDtimForm: FormGroup;
  
  selRowCycleControlIds: string[] = [];  

  dsamsShareService: DsamsShareService;
  dsamsMethodsService: DsamsMethodsService;
  constructor(private injector : Injector,
              private router: Router,
              private route: ActivatedRoute,
              public dialog: MatDialog,
              private _snackBar: MatSnackBar,
              private formBuilder: FormBuilder,
              private billingRestService: BillingRestfulService) 
{ 
  this.dsamsShareService = injector.get<DsamsShareService>(DsamsShareService);
  this.dsamsMethodsService = injector.get<DsamsMethodsService>(DsamsMethodsService);
}

  ngOnInit() {
    this.serviceId = sessionStorage.getItem('serviceDBid');
    this.dsamsShareService.csuname.next(this.route.snapshot.params['csu']);
    this.constructReleaseDtimForm();
    this.getReleaseDtims(encodeURIComponent("#"+sessionStorage.getItem('serviceDBid')));

    console.log("serviceId=="+this.serviceId)

    this.dataSource.sort = this.sort;
    this.sort.sort({ id: 'cycleControlId', start: 'asc', disableClear: false });
    
  }
 
  ngOnDestroy() {
    this.dsamsShareService.csuname.next(null);
  }

  constructReleaseDtimForm() {
    this.releaseDtimForm = this.formBuilder.group({
      txtCycleIds: this.formBuilder.control(''),
      serviceId: this.formBuilder.control(''),
    });
  }  

  getReleaseDtims(filter: string) {
    this.billingRestService.getReleaseDtims(filter)
    .subscribe(            
      data => { 
        this.dataSource.data = data; 
        this.recordCount = this.dataSource.filteredData.length;
      },
      err => {
        console.log("Error occured: getReleaseDtims()")
      }
    );
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toUpperCase();
  }  
  
  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return numSelected === numRows;
  }

  masterToggle() {
    let values: string[] = [];
    this.selection.selected.length > 0 ?
    values = this.clearValues() :
    this.dataSource.data.forEach(row => {
        if (row.fillNoBill === '0') {
            this.selection.select(row)
            values.push(row.cycleControlId);
        }
      }
    );   
    this.selRowCycleControlIds = values;    
  }   

  clearValues () {
    this.selection.clear();
    return [];
  }

  checkboxLabel(row?: PeriodicElement): string {
    if (!row) {
        return `${this.isAllSelected() ? 'select' : 'deselect'} all`;
    }
    return `${this.selection.isSelected(row) ? 'deselect' : 'select'} row ${row.cycleControlId + 1}`;
  }

  onCheckboxChange($event) {
    this.selRowCycleControlIds = this.getCheckedValues();
  }

  getCheckedValues() {
    let values: string[] = [];
    this.dataSource.data.forEach(row => { 
        if (this.selection.isSelected(row)) 
            values.push(row.cycleControlId);
      }
    )
    return values;
  }
  
  saveReleaseDtims(formValue: any) {
     let errorMegs: string = "";
     this.billingRestService.saveReleaseDtims(formValue)
     .subscribe(
       data  => {
          if (data.length == 0) {
              this.getReleaseDtims(encodeURIComponent("#"+sessionStorage.getItem('serviceDBid')));
              this.dataSource.sort = this.sort;
              this.sort.sort({ id: 'cycleControlId', start: 'asc', disableClear: false });

              this._snackBar.open("DTIM released successfully!", 'close',  {
              duration: this.durationInSeconds * 1000,
              panelClass: ['mat-toolbar', 'mat-primary'] 
             });
          } else {
              data.forEach(row => {
                errorMegs = errorMegs+"\n"+JSON.stringify(row);
              });  
              this._snackBar.open(errorMegs, 'close',  {
              duration: this.durationInSeconds * 1000,
              panelClass: ['mat-toolbar', 'mat-warn'] 
             });
          }
          console.log("saveReleaseDtims() is successful ", data);
       },
       err  => {
         console.log("Error occured: saveReleaseDtims()")
         this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, JSON.stringify(err.message))
       }
     );  
  }

  onReset(): void {
    this.releaseDtimForm.reset();
    this.selection.clear();
    this.selRowCycleControlIds = [];
  } 

  onClose() {
    if (this.selRowCycleControlIds.length > 0) {
        const dialogConfig = new MatDialogConfig();
        dialogConfig.disableClose = true;
        dialogConfig.autoFocus = true;
        dialogConfig.width= DsamsConstants.diaWidth;
        dialogConfig.data = {message: DsamsConstants.EXIT_WITHOUT_SAVE, indecator: null};

        const dialogRef = this.dialog.open(DialogMessageYesnoComponent, dialogConfig);
        dialogRef.afterClosed().subscribe(result => {
          if (result == 1) 
              this.router.navigateByUrl('');
        });
    } else {
        this.router.navigateByUrl('');
    }
  }

  confirm() {
    if (this.selRowCycleControlIds.length > 0) 
        return false;     
     else 
        return true;
  }

  onSubmit() {
    if (this.selRowCycleControlIds.length > 0) {
        //console.log("cycleIds==="+cycleIds);
        this.releaseDtimForm.get("txtCycleIds").setValue(this.selRowCycleControlIds);
        this.releaseDtimForm.get("serviceId").setValue(this.serviceId);
        this.saveReleaseDtims(this.releaseDtimForm.value);
        this.onReset();
    } else {
        this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, DsamsConstants.ROW_MUST_SELECTED)
    }    
  }


}
