
import { Injectable } from '@angular/core';
import { Observable, Subject, BehaviorSubject } from 'rxjs';
import { map, scan, publishReplay, refCount } from 'rxjs/operators';
import { CasePayment } from '../run-new-cycle/manage-manual-reimbursement-cycle/billing-sub.model';
import { BillingCase, BillingStatus, DovRow } from '../run-new-cycle/manage-manual-reimbursement-cycle/billing.model';
import { JSDocTagName } from '@angular/compiler/src/output/output_ast';
import { CaseUtils } from './../../case/utils/case-utils';
import { DateValidator } from './../../case/validation/date-validator';
import {BUDGET_CONTROL} from 'src/app/dsams/entities/models/budget-control.model';
import { BillingRestfulService } from './billing-restful.service';

interface ICasePayment extends Function {
  (cases: BillingCase[]): BillingCase[];
}


class ARow {
  idx: number;
  case: BillingCase;
}

@Injectable({
    providedIn: 'root'
  })
  

  export class ReimbursementService {
    editingMode: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(true);
    eaInformationData: BehaviorSubject<BUDGET_CONTROL[]> = new BehaviorSubject<BUDGET_CONTROL[]>(null);
    dovs: DovRow[] = [];
    dovDisplay: BehaviorSubject<DovRow[]> = new BehaviorSubject<DovRow[]>(null);
    statusMsg: Subject<BillingStatus> = new Subject<BillingStatus>();
    cases: Observable<BillingCase[]>;
    deleteCases: BillingCase[] = [];
    update: Subject<any> = new Subject<any>();
    create: Subject<BillingCase> = new Subject<BillingCase>();
    modify: Subject<ARow> = new Subject<ARow>();
    reset: Subject<number> = new Subject<number>();
    submod: Subject<CasePayment> = new Subject<CasePayment>();
    delete: Subject<number> = new Subject<number>();
    empty: Subject<any> = new Subject<any>();

    newRow: BillingCase;
    subList: CasePayment[];

    dovTableHasChanged: boolean = false;

    constructor (
              private billingRestService: BillingRestfulService) {
      this.cases = this.update.pipe(scan((cases:BillingCase[], operation: ICasePayment)=> { return operation(cases); },[]),publishReplay(),refCount());
      this.create.pipe(map(function(c: BillingCase): ICasePayment { return (cases: BillingCase[]) => { return cases.concat(c);};})).subscribe(this.update);
      this.modify.pipe(map(function(c: ARow): ICasePayment { return (cases: BillingCase[]) => { cases.splice(c.idx,1,c.case); return cases;};})).subscribe(this.update);
      this.reset.pipe(map(function(i: number): ICasePayment { return (cases: BillingCase[]) => { return cases;};})).subscribe(this.update);
      this.submod.pipe(map(function(c: CasePayment): ICasePayment { return (cases: BillingCase[]) => { cases[c.idx].subList[c.idx2].isUpdate = true; return cases; };})).subscribe(this.update);
      this.delete.pipe(map(function(i: number): ICasePayment { return (cases: BillingCase[]) => { cases.splice(i,1); return cases;};})).subscribe(this.update);
      this.empty.pipe(map(function(a: any): ICasePayment { return (cases: BillingCase[]) => { cases.splice(0,cases.length); return cases;};})).subscribe(this.update);
    }
    modifyBillingRow( e: BillingCase , idx: number):void {
      
      const row = new ARow();
      this.newRow = new BillingCase(e);
      this.newRow.isUpdate = true;
      row.case = this.newRow;
      row.idx = idx;
      this.modify.next(row);
    }
    resetBillingRow(idx: number):void {
      this.reset.next(idx);
    }
    deleteBillingRow(idx: number, e: BillingCase ):void {
      
      this.delete.next(idx);
      if (! e.isNew) {
        this.newRow = new BillingCase(e);
        this.newRow.isDelete = true;
        this.deleteCases = this.deleteCases.concat(this.newRow);
      }
    }
    emptyBillingTable():void {
      this.empty.next('e');
      this.deleteCases.splice(0,this.deleteCases.length);
    }
    getBillingCases(): Observable<BillingCase[]> {
      return this.cases;
    }

    loadBillingRow(idx: number,billingCase: BillingCase) {
      this.newRow = new BillingCase(billingCase);
      this.subList = [];
      var i;
      for (i=0; i< billingCase.subList.length; i++) {
        this.subList[i] = new CasePayment(billingCase.subList[i]);
        this.subList[i].idx = idx;
        this.subList[i].idx2 = i;
      }
      this.newRow.subList = this.subList;
      this.newRow.isNew = false;
      this.newRow.isUpdate = false;
      this.newRow.isDelete = false;

      this.create.next(this.newRow);
    }

    addBillingRow() {
      this.newRow = new BillingCase();
      this.newRow.isNew = true;

      this.create.next(this.newRow);
    }
    
    modifyBillingSubRow( e: CasePayment):void {
      this.submod.next(e);
    }

    getStatusMessage(): Subject<BillingStatus> {
      return this.statusMsg;
    }
    setStatusMessage(msg: BillingStatus): void {
      this.statusMsg.next(msg);
    }

    setEAInformationData (data: BUDGET_CONTROL[]): void {
      this.eaInformationData.next(data);
      this.dovs.splice(0,this.dovs.length);
      for (let i in data) {
        this.dovs[i] = new DovRow();
        this.dovs[i].index = Number(i);
        this.dovs[i].dovnum = data[i].disbursement_VOUCHER_CD;
        this.dovs[i].eaAdvNo = data[i].exp_AUTHORITY_NBR_CD;

        if (data[i].exp_AUTHORITY_PULL_DT == null) {
          this.dovs[i].isNoDate = true;
          this.dovs[i].datepull = '';
        }
        else {
          this.dovs[i].datepull = CaseUtils.numberToDate(data[i].exp_AUTHORITY_PULL_DT);
          
        }
        
        
      }
      this.dovDisplay.next(this.dovs);
      this.dovTableHasChanged = false;
    }
/*
    setDovs(dovs: DovRow[]):void {
      this.dovs.splice(0,this.dovs.length);
      var i;
      for (i=0; i< dovs.length; i++) {
        this.dovs[i] = new DovRow(dovs[i]);
        this.dovs[i].datepull = this.toDate(dovs[i].datepull);
        this.dovs[i].index = i;
        if (dovs[i].datepull == '') {
          this.dovs[i].isNoDate = true;
        }
      }
      this.dovDisplay.next(this.dovs);
    }
    
  */

    getDovs(): DovRow[] {
      return this.dovs;
    }
    
    getDovDisplay(): Subject<DovRow[]> {
      return this.dovDisplay;
    }

    setCurrentDateAsDefault(dateStr: string): boolean {
      var returnFlag = false;
      var i;
      for (i=0; i< this.dovs.length; i++) {
        if ( this.dovs[i].isNoDate ) {
          this.dovs[i].datepull = this.toDate(dateStr);
          this.dovs[i].isNoDate = false;
          this.dovs[i].isUpdate = true;
          returnFlag = true;
        }
      }
      this.dovDisplay.next(this.dovs);
      if (returnFlag) {
        this.dovTableHasChanged = returnFlag;
      }
      return returnFlag;
    }

    modifyDovRow( row: DovRow):void {
      this.dovTableHasChanged = true;
      this.dovs[row.index].eaAdvNo = row.eaAdvNo;
      this.dovs[row.index].dovnum = row.dovnum;

      if (row.datepull == '') {
        this.dovs[row.index].isNoDate = true;
        this.dovs[row.index].datepull = '';
      }
      else {
        this.dovs[row.index].isNoDate = false;
        this.dovs[row.index].datepull = row.datepull;
      }

      this.dovs[row.index].isUpdate = true;
      this.dovDisplay.next(this.dovs);
    }

    toDate(pDateStr:string):Date {
      if (pDateStr !== null) {
          return new Date(pDateStr);
      }
      return null;
    }

    saveDOVs(serviceId: string):  Observable<any> {
      var eaInfo = this.eaInformationData.getValue();

      if (this.dovTableHasChanged) {
      
        for (let i in this.dovs) {
          
          if (this.dovs[i].isUpdate) {
          // eaInfo[i].disbursement_VOUCHER_CD = this.dovs[i].dovnum;
            eaInfo[i].exp_AUTHORITY_NBR_CD = this.dovs[i].eaAdvNo;
            eaInfo[i].status = 4; // Constants.ENT_CHANGED
            if (! this.dovs[i].isNoDate) {
              eaInfo[i].exp_AUTHORITY_PULL_DT = this.dovs[i].datepull.getTime();
            }
          }
          
        }
        return this.billingRestService.postSaveRecordEAInformationData(eaInfo, serviceId);
      }
      return null;
    }

    setEditingMode(flag: boolean) {
      this.editingMode.next(flag);
    }
    getEditingMode(): Subject<boolean> {
      return this.editingMode;
    }

    dovHasChaged(): boolean {
      return this.dovTableHasChanged;
    }
  }