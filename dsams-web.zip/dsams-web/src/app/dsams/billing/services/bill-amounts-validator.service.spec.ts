import { TestBed } from '@angular/core/testing';

import { BillAmountsValidatorService } from './bill-amounts-validator.service';

describe('BillAmGeZeroValidatorService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: BillAmountsValidatorService = TestBed.get(BillAmountsValidatorService);
    expect(service).toBeTruthy();
  });
});
