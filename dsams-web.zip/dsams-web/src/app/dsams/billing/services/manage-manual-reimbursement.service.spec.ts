import { TestBed } from '@angular/core/testing';

import { ReimbursementService } from './manage-manual-reimbursement.service';

describe('DataService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ReimbursementService = TestBed.get(ReimbursementService);
    expect(service).toBeTruthy();
  });
});
