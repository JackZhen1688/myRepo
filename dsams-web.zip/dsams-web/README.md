# DSAMS-Web (DSAMS Web Application Framework)
=============================================
DSAMS Web Applicaation uses the Angular 6 Javascript framework to build up the frontend.
it includes the Bootstrap for mobilizeing. CSS for looking feel. HTML5 for layout.

## dsams-web code setup in Visual Studio Code
   Go to Top menu
   1. File/Open Folder...
      Select the dsams-web which you have cloned from the GITHUB.
   2. Terminal/New Terminal
      Execute the following installation in New Terminal
      a) npm install     
      b) npm install -g @angular/cli
      c) npm install -g typescript
      d) npm install bootstrap --save
      e) npm install --save font-awesome angular-font-awesome
      f) npm install --save @angular/cdk @angular/material @angular/animations hammers
      g) npm install @material-extended/mde    
	  h) npm install --save ngx-mask  
      i) npm install ngx-treeview --save
      j) npm install ng2-charts
      k) npm install chart.js
      l) npm install sweetalert2  (still under review by analysts, once approved will use ngx-sweetalert2 module)
      m) npm install file-saver --save


    This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 8.3.3.

## Development server

    Run `ng serve` for a dev server. Navigate to `http://localhost:4200/dsams-web`. The app will automatically reload if you change any of the source files.

## Code scaffolding

    Run `ng generate component component-name` to generate a new component. You can also use `ng generate directive|pipe|service|class|guard|interface|enum|module`.

## Build

    Run `ng build --base-href=/dsams-web/` to build the project. The build artifacts will be stored in the `dist/` directory. Use the `--prod` flag for a production build.

## Running unit tests

    Run `ng test` to execute the unit tests via [Karma](https://karma-runner.github.io).

## Running end-to-end tests

    Run `ng e2e` to execute the end-to-end tests via [Protractor](http://www.protractortest.org/).

## Further help

    To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI README](https://github.com/angular/angular-cli/blob/master/README.md).

## Check-in Tests

    Check-in Test 2/18/21.