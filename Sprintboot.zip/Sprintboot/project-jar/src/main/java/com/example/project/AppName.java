package com.example.project;

public interface AppName {
	 String getName();
}
