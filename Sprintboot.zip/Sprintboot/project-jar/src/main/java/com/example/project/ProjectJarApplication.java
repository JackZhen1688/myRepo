package com.example.project;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Lazy;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

@SpringBootApplication
@RestController
public class ProjectJarApplication implements CommandLineRunner {

	private static final Logger logger = LoggerFactory.getLogger(ProjectJarApplication.class);
	
	private final AppName appName;

    @Lazy
    public ProjectJarApplication(AppName appName) {
        this.appName = appName;
    }

    @Bean
    public AppName getAppName(@Value("${app.name}") String appName) {

        return () -> appName;
    }
    
    @Autowired
	private JdbcTemplate jdbcTemplate;
	  
	public static void main(String[] args) {
		SpringApplication.run(ProjectJarApplication.class, args);
	}

	@GetMapping(value = "/", produces = "application/json")
	   public String hello() {
	      return "Hello World: Jack";
	}
	
	@Override
    public void run(String... args) throws Exception {
		
        String sql = "select user_id as userId from person where user_id = 5119";
        List<Student> students = jdbcTemplate.query(sql,
                BeanPropertyRowMapper.newInstance(Student.class));
        students.forEach(student -> {logger.info("### =>> Student: {}", student.getUserId());});
        
        logger.info("Application name: {}", appName.getName());

    }
}
