http://localhost:8080/
C:\Users\JZhen\myProjs\project-jar\target>java -jar project-jar-0.0.1-SNAPSHOT.jar  (.war)

1. Add/Modify the following in POM.XML 
    <parent>
		<version>2.7.5</version>
	</parent>
    
   	<properties>
   	    <java.version>1</java.version>
		<maven-jar-plugin.version>3.1.1</maven-jar-plugin.version>
	</properties>
	
	<dependency>
		<groupId>org.springframework.boot</groupId>
		<artifactId>spring-boot-starter-web</artifactId>
	</dependency>
	
2. Database connection is present in application.properties	
   spring.datasource.url=jdbc:oracle:thin:@localhost:1521:xe
   spring.datasource.username=username
   spring.datasource.password=password
   
   
