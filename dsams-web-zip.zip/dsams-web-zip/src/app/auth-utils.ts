/**
 * This class contains the authentication/authorization utilities that will be used throughout DSAMS.
 * 
 * Author: CBanta
 * Date: June 2021
 */

import { DsamsConstants } from "./dsams/dsams.constants";

export class AuthUtils {
    /**
     * Setup a new session by seeting all the proper session vars.
     */
    public static setupNewSession() {        
        sessionStorage.setItem(DsamsConstants.SESSION_INVALID, DsamsConstants.FALSE_STR);
        AuthUtils.refreshULA();
    }

    /**
     * Refresh ULA (User Last Activity)
     */
    public static refreshULA () {
        sessionStorage.setItem(DsamsConstants.SESSION_ULA, (new Date()).toString()); 
    }

    /**
     * "Kills" a session by setting a session var that will prevent the interceptor from running.
     */
    public static killSession() {
        sessionStorage.setItem(DsamsConstants.SESSION_INVALID, DsamsConstants.TRUE_STR);
    }

    /**
     * Determines if a session is valid.
     */
    public static isSessionInvalid(): boolean {
        return !!(sessionStorage.getItem(DsamsConstants.SESSION_INVALID)) && sessionStorage.getItem(DsamsConstants.SESSION_INVALID) === DsamsConstants.TRUE_STR;
    }

    /**
     * Get ULA (user last activity) Date (which includes the time).
     */
    public static getUserLastActivity(): Date {
        return new Date(sessionStorage.getItem(DsamsConstants.SESSION_ULA));
    }

    /**
     * Get number of minutes since user last activity.
     */
    public static getMinutesSinceULA():number {
       return ((new Date()).valueOf() - AuthUtils.getUserLastActivity().valueOf()) / DsamsConstants.MILLIS_PER_MINUTE;
    }
}
