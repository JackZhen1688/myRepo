import { CasePayment } from './billing-sub.model';

export enum BillingStatus {
  blank    = 'blank',
  loaded   = 'loaded',
  unsaved  = 'unsaved',
  saved    = 'saved',
  approved = 'approved',
  generated= 'generated'

}
export class BillingCase {
    case: string;
    line: string;
    wcn:  string;
    suffix: string;
    fy: string;
    finStat: string;
    docNo: string;
    dovNo: string;
    exa:  string;
    subList: CasePayment[];
    isUpdate: boolean;
    isNew: boolean;
    isDelete: boolean;
  

    constructor(obj?: any) {
      if (obj) {
        if (obj.case) {
          this.case = obj.case;
        }
        else {
          this.case = '';
        }
        if (obj.line) {
          this.line = obj.line;
        }
        else {
          this.line = '';
        }
        if (obj.wcn) {
          this.wcn = obj.wcn;
        }
        else {
          this.wcn = '';
        }
        if (obj.suffix) {
          this.suffix = obj.suffix;
        }
        else {
          this.suffix = '';
        }
        if (obj.fy) {
          this.fy = obj.fy;
        }
        else {
          this.fy = '';
        }
        if (obj.finStat) {
          this.finStat = obj.finStat;
        }
        else {
          this.finStat = '';
        }
        if (obj.docNo) {
          this.docNo = obj.docNo;
        }
        else {
          this.docNo = '';
        }
        if (obj.dovNo) {
          this.dovNo = obj.dovNo;
        }
        else {
          this.dovNo = '';
        }
        if (obj.exa) {
          this.exa = obj.exa;
        }
        else {
          this.exa = '';
        }
        if (obj.subList) {
          this.subList = obj.subList;
        }
        else {
          this.subList = [];
        }
        if (obj.isUpdate) {
          this.isUpdate = obj.isUpdate;
        }
        else {
          this.isUpdate = false;
        }
        if (obj.isNew) {
          this.isNew = obj.isNew;
        }
        else {
          this.isNew = false;
        }
        if (obj.isDelete) {
          this.isDelete = obj.isDelete;
        }
        else {
          this.isDelete = false;
        }
      }
      else {
        this.case         = '';
        this.line         = '';
        this.wcn          = '';
        this.suffix       = '';
        this.fy           = '';
        this.finStat      = '';
        this.docNo        = '';
        this.dovNo        = '';
        this.exa          = '';
        this.subList      = [];
        this.isUpdate     = false;
        this.isNew        = false;
        this.isDelete     = false;
      }
    }
  }

  export class DovRow {
    index: number;
    dovnum: string;
    eaAdvNo: string;
    datepull: any;
    isNoDate: boolean;
    isUpdate: boolean;
    constructor(obj?: any) {
      if (obj) {
        if (obj.index) {
          this.index = obj.index;
        }
        else {
          this.index = 0;
        }
        if (obj.dovnum) {
          this.dovnum = obj.dovnum;
        }
        else {
          this.dovnum = '';
        }
        if (obj.eaAdvNo) {
          this.eaAdvNo = obj.eaAdvNo;
        }
        else {
          this.eaAdvNo = '';
        }
        if (obj.datepull) {
          this.datepull = obj.datepull;
        }
        else {
          this.datepull = '';
        }
        if (obj.isNoDate) {
          this.isNoDate = obj.isNoDate;
        }
        else {
          this.isNoDate = false;
        }
        if (obj.isUpdate) {
          this.isUpdate = obj.isUpdate;
        }
        else {
          this.isUpdate = false;
        }

      }
      else {
        this.index        = 0;
        this.dovnum       = '';
        this.eaAdvNo      = '';
        this.datepull     = '';
        this.isNoDate     = false;
        this.isUpdate     = false;
      }
    }
  }

