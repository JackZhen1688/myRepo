import { Component, OnInit, OnDestroy, Injector, ViewChild } from '@angular/core';
import { ViewportScroller } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { FormControl, FormBuilder } from "@angular/forms";
import {  MatDialog } from '@angular/material/dialog';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { BillingCase, BillingStatus } from './billing.model';
import {BUDGET_CONTROL} from 'src/app/dsams/entities/models/budget-control.model';
import {BUDGET_COMPONENT} from 'src/app/dsams/entities/models/budget-component.model';
import {TRAINING_TRACK_LINE} from 'src/app/dsams/entities/models/training-track-line.model';
import {TtlSuffix} from 'src/app/dsams/entities/specialEntities/ttl-suffix.model';
import { ISelectOptions } from 'src/app/dsams/interfaces/i-select-options';
import { ErrorParameter } from 'src/app/dsams/entities/specialEntities/error-parameter.model';
import { EntityStatus } from './../../../enums/entity-status.enum';
import { ManageArmyBillingCycleBaseComponent } from '../manage-army-billing-cycle-base/manage-army-billing-cycle-base.component';
import { ImanageArmyBillingCycle } from './../../interfaces/imanage-army-billing-cycle';
import { MatSlideToggle } from '@angular/material/slide-toggle';
import { DsamsRestfulService } from 'src/app/dsams/services/dsams-restful.service';
import { Observable } from 'rxjs';




@Component({
  selector: 'app-manage-manual-reimbursement-cycle',
  templateUrl: './manage-manual-reimbursement-cycle.component.html',
  styleUrls: ['./manage-manual-reimbursement-cycle.component.css',
    './../../billing-global.css'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0px', minHeight: '0' })),
      state('expanded', style({ height: '*' })),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})
export class MangeManualReimbursementCycleComponent extends ManageArmyBillingCycleBaseComponent
implements ImanageArmyBillingCycle, OnInit, OnDestroy {
  
  // WP103 Messages and variables specific to WP103
   m11Msg : string = "The total billed amount can not be below zero";
  m12Msg : string = "The total billed amount can not exceed the funded amount";
  m13Msg : string = "An amount must be entered against at least one TFO APC for each record or the record must be deleted";
  m14Msg : string = "You must generate DOV numbers before you can approve the cycle";
  m15Msg : string = "You must record EA information before you can approve the cycle";
  m16Msg : string = "You have unsaved changed. Would you like to save the cycle changes or continue without saving? ";
  WP103_SESSION_LOCK_ID: string = 'WP103_SESSION_LOCK_ID';

  totalFundedAmt: number = 0.0;
  totalPreviousBilledAmt: number = 0.0;
  totalBilledAmt: number = 0.0;
  totalPostAmt: number = 0.0;
  isAdjustment = false;
  cycleTitle = '';
  cycleUser = '';
  
  
  displayedColumnCycles = ['case', 'line', 'wcn', 'suffix', 'fy', 'finStat', 'docNo', 'dovNo', 'exa', 'tfo', 'funded', 'paid', 'billed', 'posted', 'billAm', 'errorMegs', 'command'];
  displayedPaymentTypes = ['tfo', 'funded', 'paid', 'billed', 'posted', 'billAm'];

  displayedBcnColumns = ['case', 'line', 'wcn', 'suffix', 'fy', 'finStat', 'docNo', 'dovNo', 'exa'];
  
  displayedBcxColumns = ['tfo', 'funded', 'paid', 'billed', 'posted', 'billAm'];
  displayedEaDataColumns = ['dovNbr', 'EaAdviceNbrd', 'dateEaPulled'];

  
  validLines: any[];
  validCases: any[];
  validWcns: any[];
  validSuffixes: any[];
 
  cycleTotalAmount = 0.0;
  

  private caseFilterValues = { case: '', line: '', wcn: '', suffix: '', fy: '', finStat: '', apc: '', custNo: '', docNo: '', dovNo: '', exa: '' };
  filterCase = new FormControl();
  filterLine = new FormControl();
  filterWcn = new FormControl();
  filterSuffix = new FormControl();
  filterFy = new FormControl();
  
  constructor(protected injector: Injector, 
              protected route: ActivatedRoute,
              protected dsamsReferenceService: DsamsRestfulService,
              public popUpDialog: MatDialog,
              protected formBuilder: FormBuilder,
              protected viewportScroller: ViewportScroller)
  {
    super(injector, route, dsamsReferenceService, popUpDialog, formBuilder, viewportScroller);
  }

  ngOnInit() {
    super.ngOnInit();
    this.dsamsShareService.csuname.next(this.route.snapshot.params['csu']);
    this.constructcycleForm();
    if (this.cycleIsSel) {
      this.getDov(this.theParmCycleId);
    }
    this.reimbursementService.setEditingMode(true);// always editable
    this.dsBcnData.filterPredicate = this.suffixPostingFilterPredicate();
    
  }
  getCSU_CD():string { return "WP103"; }

  suffixPostingFilterPredicate() {
    const thisFilterPredicate = function (data: BUDGET_CONTROL, filter: string): boolean {
    //  Case Line WCN Suffix Fy DocNbr FinStatus EXA
    let dataString : string = "";
    if (data.theTrainingTrackLineSeqCd != null) {
      let t1: TRAINING_TRACK_LINE = data.theTrainingTrackLineSeqCd;
      dataString  = ( t1.userCaseId === null) ? "" : t1.userCaseId;
      dataString  = dataString + (( t1.userCaseLineNumberId === null) ? "" : t1.userCaseLineNumberId);
      dataString  = dataString + (( t1.wcn === null) ? "" : t1.wcn);
      dataString  = dataString + (( t1.wcn_SUFFIX_CD === null) ? "" : t1.wcn_SUFFIX_CD);
      dataString = dataString + ((data.fiscal_YEAR_ID === null) ? "" : data.fiscal_YEAR_ID);
      dataString = dataString + ((t1.tl_FINANCIAL_STATUS_TYPE_ID === null) ? "" : t1.tl_FINANCIAL_STATUS_TYPE_ID);
      dataString  = dataString + (( data.external_DOCUMENT_CD === null) ? "" : data.external_DOCUMENT_CD);
      dataString  = dataString + (( data.disbursement_VOUCHER_CD === null) ? "" : data.disbursement_VOUCHER_CD);
      dataString = dataString + ((data.training_ACTIVITY_ID === null) ? "" : data.training_ACTIVITY_ID);    
      dataString = dataString.trim().toLocaleLowerCase();
    }
      return dataString.indexOf(filter) !== -1;
    }
    return thisFilterPredicate;
  }


 

  @ViewChild('editSlider', { static: false }) editSlider : MatSlideToggle;
 getEditSlider(): MatSlideToggle {
    return this.editSlider;
  }
  
  setEditMode() : Observable<any> {
    let ccid: string = this.getTheCycleControlId();
    let obs = null;
    if (ccid.length > 1) {
      obs = this.getArmyBillingCycleDataWithNewSesionLock(ccid);
    }
    return obs;
    
  }
  
  setViewMode() {
   
  }
    
    
  //   closeLockSession() {
  //     this.closeDbLockSession(this.WP103_SESSION_LOCK_ID);
  // }
  
  getComponentLockSessionId() {
    let lockId = sessionStorage.getItem(this.WP103_SESSION_LOCK_ID);
    if (lockId == null || lockId.length == 0) {
      lockId = '0';
    }
    return lockId;
  }
 
  setComponentLockSessionId(lockId : string) {
      sessionStorage.setItem(this.WP103_SESSION_LOCK_ID,lockId);
  }  
 
  

  constructcycleForm() {
    this.cycleForm = this.formBuilder.group({
      // // BCN fields
      // fctlCase: this.formBuilder.control(''),
      // fctlLine: this.formBuilder.control(''),
      // fctlWcn: this.formBuilder.control(''),
      // fctlSuffix: this.formBuilder.control(''),
      // fctlFy: this.formBuilder.control(''),
      // fctlFinStat: this.formBuilder.control(''),
      // fctlDocNo: this.formBuilder.control(''),
      // fctlDovNo: this.formBuilder.control(''),
      // fctlExa: this.formBuilder.control(''),

      // BCX fields
      fctlTfo: this.formBuilder.control(''), // FR6 bcx.theCollectAccountLineSeqCd.wm_APC_CD
      fctlFundedAm: this.formBuilder.control(''), // bcx.wm_FUNDED_AM
      fctlPrevPaid: this.formBuilder.control(''), // FR7  bcx.wm_PREV_PAID_AM
      fctlPrevBilled: this.formBuilder.control(''),//FR 22 bcx.prev_REIMB_BILLED_AM
      fctlPrevPosted: this.formBuilder.control(''),
      fctlBillAm: this.formBuilder.control('')
    });
  }

  get fctlBillAm() {
    return this.cycleForm.get('fctlBillAm');
  }
  
  get fctlFundedAm() {
    return this.cycleForm.get('fctlFundedAm');
  } 

    get fctlTfo() {
    return this.cycleForm.get('fctlTfo');
  } 

  get fctlPrevPaid() {
    return this.cycleForm.get('fctlPrevPaid');
  }
  get fctlPrevPosted() {
    return this.cycleForm.get('fctlPrevPosted');
  }
 
  get fctlPrevBilled() {
    return this.cycleForm.get('fctlPrevBilled');
  }
 
  setCycleDataLoaded() {
    if (this.theCC.cycle_CONTROL_ID != this.lastCycleLoaded ) {
      this.setService(this.theCC.case_USAGE_INDICATOR_CD);
      this.setAdjustment(this.theCC.cycle_CONTROL_TYPE_ID);
      this.cycleUser = this.theCC.create_USER_ID + "  " + this.theCC.createUserName;
      console.log("theCC.cycle_TITLE_NM = " + this.theCC.cycle_TITLE_NM);
      this.lastCycleLoaded = this.theCC.cycle_CONTROL_ID;
      this.isEditMode = false;
      this.closeLockSession();
    }
    this.setService(this.theCC.case_USAGE_INDICATOR_CD);
    this.setAdjustment(this.theCC.cycle_CONTROL_TYPE_ID);
    this.cycleUser = this.theCC.create_USER_ID + "  " + this.theCC.createUserName;
    console.log("theCC.cycle_TITLE_NM = " + this.theCC.cycle_TITLE_NM);
}

setNoCycleSelected() {
}
  
 
  // 2 - call back- = false;end for a list of Cycles
  getCycleCases() {
    // use selectedCycle for input
   
    this.reimbursementService.setStatusMessage(BillingStatus.loaded);
  }

  changeAdjusment(event) {
    this.isAdjustment = event.checked;
    if (this.isAdjustment) {
      this.theCC.cycle_CONTROL_TYPE_ID = 32;
    } else {
      this.theCC.cycle_CONTROL_TYPE_ID = 30;
    }
  }

  gotoAnchor(anchor: string): void {
    this.viewportScroller.scrollToAnchor(anchor);
  }


  setNewCycleSelected() {
    this.setCycleCaseUsageCd();
    this.setCycleTypeId();
    this.cycleUser = this.theCC.create_USER_ID + "  " + this.theCC.createUserName;
    
  }
 
  setCycleSaved() {
    this.isDisabledGenDOVbutton = false;
    this.isDisabledApprovebutton = false;
  }
  setCycleDeleted() {
    this.calculateTotals();
    this.isEditMode = false;
    this.setViewMode();
  }
  
  // caseFilterPredicate() {
  //   const thisFilterPredicate = function (data: BillingCase, filter: string): boolean {
  //     let searchString = JSON.parse(filter);
  //     return data.case.toString().trim().toLowerCase().indexOf(searchString.case.toLowerCase()) !== -1 &&
  //       data.wcn.toString().trim().toLowerCase().indexOf(searchString.wcn.toLowerCase()) !== -1 &&
  //       data.suffix.toString().trim().toLowerCase().indexOf(searchString.suffix.toLowerCase()) !== -1 &&
  //       data.fy.toString().trim().toLowerCase().indexOf(searchString.fy.toLowerCase()) !== -1 &&
  //       data.line.toString().trim().toLowerCase().indexOf(searchString.line.toLowerCase()) !== -1;

  //   }
  //   return thisFilterPredicate;
  // }
  
  addTlaSelections(tttsAllLevels: any[]) {

  }
  
  noBcnSuffixList: ErrorParameter[] = new Array<ErrorParameter>();
  selectIx: number;
  newSuffixCount: number;
 addSuffixSelections(suffixList: any[]) {
   this.noBcnSuffixList = [];
   this.selectIx = 0;;
   this.newSuffixCount = suffixList.length;
   for (var i = 0; i < suffixList.length; i++) {
      
      this.newSuffixesLoaded = false;
      this.newSuffixesLoading = true;
      let sfx: TtlSuffix = this.suffixPopupData.selections[i];
      sfx.cycleControlTypeId = this.theCC.cycle_CONTROL_TYPE_ID.toString();
      sfx.caseDocType = this.theCC.case_USAGE_INDICATOR_CD;
      if (this.theCC.cycle_CONTROL_ID != null) {
        sfx.cycleControlId = this.theCC.cycle_CONTROL_ID.toString();
      } else { sfx.cycleControlId = ""; }
      this.getNewSuffixBcns(sfx);
      
    }
    this.suffixPopupData.selections.length = 0;
   
      
  }

 

  addNewSuffixBcns(bcnList: any, sfx: any) {
    if (bcnList != null && bcnList.length > 0) {
      console.log("bcnlist contains " + bcnList.length);
      if (this.theCC.budgetControlList == null) {
        this.theCC.budgetControlList = [];
      }
      for (var bcnIx in bcnList) {
        let bcn: BUDGET_CONTROL = bcnList[bcnIx];
        this.theCC.budgetControlList.push(bcn);
        this.statusMessage = "Unsaved data";
      }
      this.calculateTotals();
      this.refreshBcnList();
    } else {
      let ref  = this.geUserCaseLineKey(sfx);
      let msg: string = this.geUserWcnSuffixKey(sfx) + " not eligible for manual reimbursement.";
      this.noBcnSuffixList.push(new ErrorParameter("Error", "Add", ref, msg));
    }

  }

  geUserCaseLineKey(sfx: TtlSuffix) {

    return sfx.caseId + "/" + String(sfx.lineNumber).padStart(3, '0');
  }
  
  geUserWcnSuffixKey(sfx: TtlSuffix) {

    return "'" + sfx.wcn + " " + sfx.suffixCode +  "'";
  }
  
  markRowFy(row: BillingCase, idx: number) {
   
   
  }

  
  markRowSuffix(row: BillingCase, idx: number) {
  
  }
 
  

 
  markRowWcn(row: BillingCase, idx: number) {
    
  }

  

  markRowLine(row: BillingCase, idx: number) {
    
  }
  
  
  markRowCase(row: BillingCase, idx: number) {
      
  }
 

  /*----------------------------------
    Validation: checkAmountZero()
   -----------------------------------*/
  ltZeroRowNum: number;
  ltZeroSubRowNum: number;
  checkLtZeroFlag(row: number, subrow: number) {
     if (row == this.ltZeroRowNum && subrow == this.ltZeroSubRowNum){
         return true;
     } else
         return false;
  }
  checkLtZero(event: any, item: BUDGET_COMPONENT, row: number, subrow: number) {
    console.log("item=="+item.wm_PREV_PAID_AM + "total: "+(parseInt(event.target.value)+item.wm_PREV_PAID_AM))
    if ((parseInt(event.target.value)+item.wm_PREV_PAID_AM) < 0) {
        console.log("true")
        this.ltZeroRowNum = row;
        this.ltZeroSubRowNum = subrow;
    } else {
        this.ltZeroRowNum = -1;
        this.ltZeroSubRowNum = -1;
    }
  }
  

  /*----------------------------------
    Validation: checkAmountGtfundAmZero()
   -----------------------------------*/
   gtFundedAmRowNum: number;
   gtFundedAmSubRowNum: number;
   checkGtFundedAmFlag(row: number, subrow: number) {
      if (row == this.gtFundedAmRowNum && subrow == this.gtFundedAmSubRowNum){
          return true;
      } else
          return false;
   }
   checkGtFundedAm(event: any, item: BUDGET_COMPONENT, row: number, subrow: number) {
     console.log("item=="+item.wm_PREV_PAID_AM + "total: "+(parseInt(event.target.value)+item.wm_PREV_PAID_AM))
     if ((parseInt(event.target.value)+item.wm_PREV_PAID_AM) > item.wm_FUNDED_AM) {
         console.log("true")
         this.gtFundedAmRowNum = row;
         this.gtFundedAmSubRowNum = subrow;
     } else {
         this.gtFundedAmRowNum = -1;
         this.gtFundedAmSubRowNum = -1;
     }
   }
   
 
  
  setSuffixPopupSelectRestrictions() {
    let docType: ISelectOptions = this.getSelectDocType();
    console.log("service is " + this.selectedServiceName);
    console.log("PopupSelectRestrictions doc type = " + docType.viewValue);
    console.log("Doctype = " + docType);
    this.suffixPopupData.selections = [];
    this.suffixPopupData.isMultiSelect = true;
    this.suffixPopupData.caseDocTypeSelections = [docType];
    this.suffixPopupData.programTypeSelections = [];
    this.suffixPopupData.selectionsUrl = "/manualBilling/ttlAllSuffixes";
    console.log("this.suffixPopupData.selectionsUrl =  / infrastructure / tttsAllLevels");

  }

  setTlaPopupSelectRestrictions() {
  }
  
 
 
  

  onCycleTypeChange() {
    
    if (this.isAdjustment) {
      this.theCC.cycle_CONTROL_TYPE_ID = 32;
    } else {
      this.theCC.cycle_CONTROL_TYPE_ID = 30;
    }
  }
 
  
  calculateTotals() {
    this.totalFundedAmt = 0.0;
    this.totalPreviousBilledAmt = 0.0;
    this.totalBilledAmt = 0.0;
    let addLog: string = '';
    if (this.theCC.budgetControlList != null) {
      for (var bcnIx in this.theCC.budgetControlList) {
        let bcn: BUDGET_CONTROL = this.theCC.budgetControlList[bcnIx];
        if (bcn.status != EntityStatus.ENT_DELETED) {
          let bcnTtl: TRAINING_TRACK_LINE = bcn.theTrainingTrackLineSeqCd
          for (var bcdIx in bcn.budgetComponentList) {
            let bcd: BUDGET_COMPONENT = bcn.budgetComponentList[bcdIx];
            this.setNullValuesToZero(bcd);
            bcd.wm_PREV_PAID_AM = Number(bcd.wm_PREV_BILLED_AM) + Number(bcd.wm_PREV_EXTERNAL_REIMB_AM);
            this.totalFundedAmt = this.totalFundedAmt + Number(bcd.wm_FUNDED_AM);
         
            this.totalBilledAmt = this.totalBilledAmt + Number(bcd.action_AM);
         
             
          }
        }
           
           
         
      }
    }
  //  console.log(addLog);
    this.cycleTotalAmount = this.totalBilledAmt;
   
     
  }

  
  
 
  saveArmyBillingCycle(): Observable<any> {
    let lockSessionId = this.getComponentLockSessionId();
    let obs = super.saveArmyBillingCycleData("/manualBilling/saveCycle", lockSessionId);
    this.saveDov();
    return obs;
  }
  
  
  setAdjustment(cycleTypeId : number){
    this.isAdjustment = (cycleTypeId == 32 ? true : false);
  }

  
  setCycleTypeId(){
    this.theCC.cycle_CONTROL_TYPE_ID = (this.isAdjustment ? 32 : 30);
  }

  validateForSaveCycle() : boolean {
    console.log("validateAMountsBeforeSave");
    let messageList: ErrorParameter[] = new Array<ErrorParameter>();
    this.calculateTotals();
   
    let suffixNoTfoAmts : string = '';
    if (this.theCC.budgetControlList != null) {
      this.theCC.budgetControlList.forEach(bcn => {
        if (bcn.status != EntityStatus.ENT_DELETED) {
          if (this.calculateBcnSaveAmount(bcn, messageList) == 0) {
            messageList.push(new ErrorParameter("Error", 'Amounts', this.getBcnSuffixString(bcn), this.m13Msg));
          }
        }
      });
      
    }
    if (messageList.length == 0) {
      return true;
    }else{
      this.displayUserErrorMessages(messageList)
      return false;
    }
   
  
  }
  
  calculateBcnSaveAmount(bcn: BUDGET_CONTROL, messageList: ErrorParameter[]): number {
    let totalBcnAmt: number = 0;
    if (bcn.budgetComponentList != null) {
      bcn.budgetComponentList.forEach(bcx => {
        let bcxRef: string =  bcx.theCollectAccountLineSeqCd.wm_APC_CD;
       // let totalBcxBillAmt: number = Number(bcx.wm_PREV_PAID_AM) + Number(bcx.action_AM);
       let totalBcxBillAmt: number = Number(bcx.wm_PREV_BILLED_AM) + Number(bcx.action_AM);
        totalBcnAmt = totalBcnAmt + totalBcxBillAmt;
        if (totalBcxBillAmt < 0) {
          messageList.push(new ErrorParameter("Error", 'Amounts', bcxRef, this.m11Msg));
        }
        console.log("totalBcxBillAmt = " + totalBcxBillAmt + ", wm_PREV_PAID_AM = " + bcx.wm_PREV_PAID_AM + ", wm_FUNDED_AM" + bcx.wm_FUNDED_AM);
       // if ((totalBcxBillAmt + Number(bcx.wm_PREV_PAID_AM)) > Number(bcx.wm_FUNDED_AM)) {
        if (totalBcxBillAmt  > Number(bcx.wm_FUNDED_AM)) {
          messageList.push(new ErrorParameter("Error", 'Amounts', bcxRef, this.m12Msg));
        }
          
      });
    }
      return totalBcnAmt;
   
   
  }

  calculateBcnApproveAmount(bcn: BUDGET_CONTROL, messageList: ErrorParameter[]): number {
    let totalBcnAmt: number = 0;
    if (bcn.budgetComponentList != null) {
      bcn.budgetComponentList.forEach(bcx => {
        let bcxRef: string =  bcx.theCollectAccountLineSeqCd.wm_APC_CD;
        let totalBcxBillAmt: number = Number(bcx.wm_PREV_BILLED_AM) + Number(bcx.action_AM);
        totalBcnAmt = totalBcnAmt +  + Number(bcx.action_AM);
           
      });
    }
      return totalBcnAmt;
   
   
  }
 
  
  //WC103 call API methods)

  onSaveEaData() {
    // this.DisplayInformationMessage("Save Status", "EA data has been saved")
    // .subscribe(result => {
     
    //   console.log('Save EA dadta complete');
     
      
    //  });
    this.displaySnackBarMessage( 'Save EA dadta complete', false);
  }
  
  getDov(cycleControlId: string) {
    let serviceId = sessionStorage.getItem('serviceDBid');
    if (cycleControlId != null && cycleControlId.length > 1){
    this.billingRestService.getRecordEAInformationData(encodeURIComponent(cycleControlId+"#"+this.getDbId()))
    .subscribe( data => {
        this.reimbursementService.setEAInformationData(data);
      },
      err => {
       // console.log("Error occured: MangeManualReimbursementCycleComponent.getDov() -" + err);
        this.handleError("getRecordEAInformationData(" + cycleControlId + ")", err);
      }
      );
    } else {
      this.reimbursementService.setEAInformationData([]);
    }
  }
  
  saveDov() {
    if (this.reimbursementService.dovHasChaged()) {
      let serviceId = sessionStorage.getItem('serviceDBid');
      this.reimbursementService.saveDOVs(serviceId)
      .subscribe(
        data => { 
          if (data) {
              this._snackBar.open("Save DOVs successfully!", 'close',  {
              duration: this.durationInSeconds * 1000,
              panelClass: ['mat-toolbar', 'mat-primary'] // 'mat-accent' or 'mat-warn'
              });
          } else {
              this._snackBar.open("Save DOVs failure!", 'close',  {
              duration: this.durationInSeconds * 1000,
              panelClass: ['mat-toolbar', 'mat-warn'] // 'mat-accent' or 'mat-warn'
              });
          }
      },
        err => {
          console.log("Error occured: MangeManualReimbursementCycleComponent.saveDov()")
        }
      );
    }
  }

  // WP103 API calls
  
  approveArmyBillingCycle() {
    let lockId : string = this.getComponentLockSessionId().toString();
    let cycleId : string = this.theCC.cycle_CONTROL_ID.toString();
    let cycleTypeId: string = this.theCC.cycle_CONTROL_TYPE_ID.toString();
    super.approveArmyBillingCycleTypeData("/manualBilling/approveCycle", cycleId, cycleTypeId,lockId);
   
  }

  validateForApproveCycle(): boolean {
    console.log("validateForApproveCycle()");
    let messageList: ErrorParameter[] = new Array<ErrorParameter>();
    let dovNotGenerated: boolean = false;
    let eaNotRecorded: boolean = false;
    if (this.theCC.budgetControlList != null) {
      this.theCC.budgetControlList.forEach(bcn => {
        if (bcn.status != EntityStatus.ENT_DELETED) {
          if (this.calculateBcnApproveAmount(bcn, messageList) == 0) {
            messageList.push(new ErrorParameter("Error", 'Amounts', this.getBcnSuffixString(bcn), this.m13Msg));
          }
          if (this.theCC.cycle_CONTROL_TYPE_ID == 30 && bcn.disbursement_VOUCHER_CD == null) {
            dovNotGenerated = true;
          }
          if (this.theCC.cycle_CONTROL_TYPE_ID == 30 && bcn.theTrainingTrackLineSeqCd.cmProgramTypeId != null && 
            bcn.theTrainingTrackLineSeqCd.cmProgramTypeId  == "F" &&
            (bcn.exp_AUTHORITY_NBR_CD == null || bcn.exp_AUTHORITY_PULL_DT == null)) {
             eaNotRecorded = true;
          }
        }
      });

      if (dovNotGenerated ) {
        messageList.push(new ErrorParameter("Error", 'DOV', '', this.m14Msg));
      }
      if (eaNotRecorded ) {
        messageList.push(new ErrorParameter("Error", 'EA', '', this.m15Msg));
      }

      
    }
    if (messageList.length == 0) {
      return true;
    }else{
      this.displayUserErrorMessages(messageList)
      return false;
    }
  }

  generateAssignDovNumber() {
    if (this.hasCycleChanged()) {
      this.displayErrorMessage("Generate DOV", "Please save the cycle before generating DOV numbers" )
             .subscribe(result => {
                console.log("Generate DOV cancelled, cycle data not saved");
             });
       return;
    }
    let ccId: string = this.theCC.cycle_CONTROL_ID.toString();
    this.billingRestService.getManualBillingGenerateDovNumber(this.theCC.cycle_CONTROL_ID)
      .subscribe(
           data => {
              let success: boolean = data;
              if (success == true) {
                this.statusMessage = "DOV numbers generated";
                this.displaySnackBarMessage("DOV numbers have been generated for cycle " + ccId, false);
                this.getDov(ccId);
               } else {
                  this.displaySnackBarMessage("Generate DOV numbers failed for cycle " + ccId, true);
              }
    
          this.getArmyBillingCycle(ccId,this.getComponentLockSessionId())
            },
            err => {
              this.handleError("generateAssignDovNumber(" + ccId + ")",err);
           
            });
     
  }
  
  getNewSuffixBcns(suffix: TtlSuffix) {

    this.billingRestService.getNewBudgetControlList(suffix.cycleControlId, suffix.cycleControlTypeId,
      suffix.case_ID.toString(), suffix.case_MASTER_LINE_ID.toString(),
      suffix.training_TRACK_SEQ_CD.toString(), suffix.training_TRACK_LINE_SEQ_CD.toString())

      .subscribe(
        data => {
          if (data == null) {
            console.log("bcnList data is null");
          } else {
            console.log("new suffix data");
            console.log(data);
            this.addNewSuffixBcns(data, suffix);

            this.newSuffixesLoaded = true;
            this.newSuffixesLoading = false;
          }
          this.selectIx = this.selectIx + 1;
          if (this.selectIx == this.newSuffixCount && this.noBcnSuffixList.length > 0) {
            this.displayUserErrorMessages(this.noBcnSuffixList)

          }

        },
        err => {
          this.handleError("createNewBudgetControls()", err);
        });


  }

  

 getArmyBillingCycleIdList(selCycleId : string) {
   super.getArmyBillingCycleIdsWithSelect("/manualBilling/open/cycleControlIdList", selCycleId);
   
  }

  
  getNewArmyBillingCycle() {
    
    this.setCycleCaseUsageCd();
    this.setCycleTypeId();
    this.reimbursementService.emptyBillingTable();
    this.reimbursementService.addBillingRow();
    
    super.getNewArmyBillingCycleData("/manualBilling/newCycleControl");
    
   
}

  getArmyBillingCycle(cycleId: string, lockId : string) {
   // let lockId: string = this.getComponentLockSessionId().toString();
    if (cycleId != null && cycleId.length > 2) {
      super.getArmyBillingCycleData("/manualBilling/cycleControl", cycleId,lockId);
      
    
    } else {
        this.getNewArmyBillingCycle();
    }
    

}
 
  deleteArmyBillingCycle() {
    let cycleId : string = this.theCC.cycle_CONTROL_ID.toString();
    super.deleteArmyBillingCycleData("/manualBilling/deleteCycle", cycleId);
   
 
  }
  
  ngOnDestroy() {
    console.log("WP103 Destroyed")
    super.ngOnDestroy();
    this.dsamsShareService.csuname.next(null);
    }
  
  onManualSelectCycle(selCycle: ISelectOptions): void {
    super.onSelectCycle(selCycle);
    this.getDov(this.selectedCycle.value);
  }
  
}

