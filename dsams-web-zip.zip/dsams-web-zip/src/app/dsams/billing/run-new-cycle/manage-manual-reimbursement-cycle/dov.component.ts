import { Component, OnInit, Input, OnChanges,SimpleChange } from '@angular/core';
import { ViewportScroller } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { FormControl, FormGroup, Validators } from "@angular/forms";
import { MatTableDataSource } from '@angular/material/table';
import { animate, state, style, transition, trigger } from '@angular/animations';
import * as moment from 'moment';
import { CaseUtils } from '../../../case/utils/case-utils';

import { DsamsConstants } from './../../../dsams.constants'
import { ReimbursementService } from '../../services/manage-manual-reimbursement.service';
import { BillingCase, BillingStatus, DovRow } from './billing.model';
import { CasePayment } from './billing-sub.model';
import { DiaModalFmsCaseComponent } from './../../../utilitis/dialogs/dia-modal-fms-case/dia-modal-fms-case.component'
import { DiaModalLineComponent } from './../../../utilitis/dialogs/dia-modal-line/dia-modal-line.component'
import { DiaModalWcnComponent } from './../../../utilitis/dialogs/dia-modal-wcn/dia-modal-wcn.component'
import { DiaModalSuffixComponent } from './../../../utilitis/dialogs/dia-modal-suffix/dia-modal-suffix.component'
import { DiaModalFiscalYearComponent } from './../../../utilitis/dialogs/dia-modal-fiscal-year/dia-modal-fiscal-year.component'

interface SelectOption {
  value: string;
  viewValue: string;
}
@Component({
  selector: 'dov-table',
  templateUrl: './dov.component.html',
  styleUrls: ['./dov.component.css',
              './../../billing-global.css'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({height: '0px', minHeight: '0'})),
      state('expanded', style({height: '*'})),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})
export class DovComponent implements OnInit {

  edit: boolean = false;
  theCCID: string;

  displayedColumnDovs: string[] = ['dovnum','empty','datepull'];
  dsDov =  new MatTableDataSource();
  currentDate: string;
  serviceId: string;

  constructor(private viewportScroller: ViewportScroller, private route: ActivatedRoute, private reimbursementService: ReimbursementService) { }

  ngOnInit() {
    this.getDOVNumbers();   
    this.serviceId = sessionStorage.getItem('serviceDBid');  
    this.reimbursementService.getEditingMode().subscribe( data => { this.edit = data; });                                   
  }

  @Input()
  setTheCCID(ccid: string) {
    this.theCCID = ccid;
    
  }
  getTheCCID(ccid: string) {
    return this.theCCID; 
  }
  getDOVNumbers() {  
    this.reimbursementService.getDovDisplay().subscribe( data => { this.dsDov.data = data; });
  } 
  
  
  applyFilter(filterValue: string) {
    this.dsDov.filter = filterValue.trim().toLowerCase();
  } 
  

  onUseCurrentDate() {
    this.currentDate = moment(new Date()).format('MM/DD/YYYY');
    if (this.reimbursementService.setCurrentDateAsDefault(this.currentDate)) {
      this.reimbursementService.setStatusMessage(BillingStatus.unsaved);
    }
  }
  
  markDovForUpdate(e:any, row: DovRow, i: number) {
    this.reimbursementService.modifyDovRow(row);
    this.reimbursementService.setStatusMessage(BillingStatus.unsaved);
  }

  setEdit(edit: boolean) {
    this.edit = edit;
  }

  getDateString(date: any): string {
    if ( typeof date === 'string') {
      return date;
    }
    else {
      return CaseUtils.formatDateForComparison(date);
    }
  }

}

