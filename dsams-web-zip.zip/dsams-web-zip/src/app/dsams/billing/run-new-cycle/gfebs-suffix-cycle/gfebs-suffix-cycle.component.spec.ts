import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GfebsSuffixCycleComponent } from './gfebs-suffix-cycle.component';

describe('GfebsSuffixCycleComponent', () => {
  let component: GfebsSuffixCycleComponent;
  let fixture: ComponentFixture<GfebsSuffixCycleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GfebsSuffixCycleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GfebsSuffixCycleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
