import { Component, OnInit, Injector, OnDestroy,ViewChild } from '@angular/core';
import { ViewportScroller} from '@angular/common';
import { FormBuilder, FormGroup, FormControl } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { animate, state, style, transition, trigger } from '@angular/animations';
import {TtlSuffix} from 'src/app/dsams/entities/specialEntities/ttl-suffix.model';
import { ISelectOptions } from 'src/app/dsams/interfaces/i-select-options';
import { EntityStatus } from './../../../enums/entity-status.enum';
import { ErrorParameter } from 'src/app/dsams/entities/specialEntities/error-parameter.model';
import {  MatTable } from '@angular/material/table';
import {  MatDialog } from '@angular/material/dialog';
import { BUDGET_CONTROL } from 'src/app/dsams/entities/models/budget-control.model';
import { BUDGET_COMPONENT } from 'src/app/dsams/entities/models/budget-component.model';
import {TRAINING_TRACK_LINE} from 'src/app/dsams/entities/models/training-track-line.model';
import { ManageArmyBillingCycleBaseComponent,isNumeric } from '../manage-army-billing-cycle-base/manage-army-billing-cycle-base.component';
import { ImanageArmyBillingCycle } from './../../interfaces/imanage-army-billing-cycle';
import { MatSlideToggle } from '@angular/material/slide-toggle';
import { DsamsRestfulService } from 'src/app/dsams/services/dsams-restful.service';
import { Observable } from 'rxjs';


@Component({
  selector: 'app-gfebs-suffix-cycle',
  templateUrl: './gfebs-suffix-cycle.component.html',
  styleUrls: ['./gfebs-suffix-cycle.component.css',
              './../../billing-global.css'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({height: '0px', minHeight: '0'})),
      state('expanded', style({height: '*'})),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})


export class GfebsSuffixCycleComponent extends ManageArmyBillingCycleBaseComponent
  implements ImanageArmyBillingCycle, OnInit, OnDestroy {

   // WP105 Messages and variables specific to WP104
  m2Msg : string = "This case does not exist for this service or is not open or interim-closed";
  m3Msg : string = "This line does not exist for the case or does not containing suffix records";
  m4Msg : string = "This WCN does not exist for the line or does not contain suffix records";
  m5Msg : string = "This record does not exist, is in another cycle, or is not in a funded or billed status";
  m6Msg : string = "This FY is not valid for the record";
  m10Msg: string = "The amount entered plus the previous posted amount is less than zero.";
  m11Msg: string = "The amount entered plus the previous paid amount exceeds the funded amount";
  m13Msg: string = "An amount must be entered against at least one TFO APC for each record or the record must be deleted";
  m14Msg: string = "The amount exceeds the funded amount";
  m15Msg: string = "The amount being reversed exceeds the previous posted amount";
  m16Msg: string = "All APC/Fiscal Year components with a posted amount must have an assigned DOV number";

  WP105_SESSION_LOCK_ID: string = 'WP105_SESSION_LOCK_ID';
  cycleTitle = '';
  cycleUser = '';

  displayedGfebsCase = [ 'case', 'line', 'wcn', 'suffix', 'fy',  'docNo', 'finStat',  'exa', 
                         'tfoApc', 'fundedAm', 'paidAm', 'billedAm', 'postedAm', 'postingAm', 'dovNo','command'];

 
                    //      eachBCD.getWM_FUNDED_AM().setValue(eachBCD.getWM_FUNDED_AM().getValue()+theFUNDED_AM.getValue());
                    //      eachBCD.getWM_PREV_REIMBURSEMENT_PAID_AM().setValue(eachBCD.getWM_PREV_REIMBURSEMENT_PAID_AM().getValue()+thePREV_REIMBURSEMENT_PAID_AM.getValue());
                    //      eachBCD.getWM_BILLED_EXTERNAL_AM().setValue(eachBCD.getWM_BILLED_EXTERNAL_AM().getValue()+theBILLED_EXTERNAL_AM.getValue());
                    //      eachBCD.getWM_PENDING_EXTERNAL_AM().setValue(eachBCD.getWM_PENDING_EXTERNAL_AM().getValue()+thePENDING_EXTERNAL_AM.getValue());
                    //  }
  expandedElement: null;
  //selectedCycle = "";
  // dataSourceCase = new MatTableDataSource();
  // dsBcnData = new MatTableDataSource();
  // @ViewChild('bcnTable', { static: false }) bcnTable: MatTable<BUDGET_CONTROL>;
  postSuffixCycleForm: FormGroup;

  @ViewChild(MatTable, { static: false }) bcnTable: MatTable<BUDGET_CONTROL>;


  filterCase   = new FormControl();
  filterLine   = new FormControl();
  filterWcn     = new FormControl();
  filterFy = new FormControl();
  filterSuffix     = new FormControl();
  filterDocNum = new FormControl();
  private caseFilterValues = { case: '', line: '', wcn: '',  suffix: '', fy: '',  finStat: '', docNo: '', eor: '', exa: '', paymentType: '' };
 
  constructor(protected injector: Injector, 
              protected route: ActivatedRoute,
              protected dsamsReferenceService: DsamsRestfulService,
              public popUpDialog: MatDialog,
              protected formBuilder: FormBuilder,
              protected viewportScroller: ViewportScroller) 
  {
    super(injector, route, dsamsReferenceService, popUpDialog, formBuilder, viewportScroller);
  }
    

  ngOnInit() {
    super.ngOnInit();
    this.dsamsShareService.csuname.next(this.route.snapshot.params['csu']);
    if (this.route.snapshot.params['cycleid'] != '0')
        this.dsamsShareService.breadcrumbForFundingHome.next('billing');
    this.constructPostSuffixCyleForm();
    this.dsBcnData.filterPredicate = this.suffixPostingFilterPredicate();
                                         
  }
  getCSU_CD():string { return "WP105"; }
  
  suffixPostingFilterPredicate() {
    const thisFilterPredicate = function (data: BUDGET_CONTROL, filter: string): boolean {
    //  Case Line WCN Suffix Fy DocNbr FinStatus EXA
    let dataString : string = "";
    if (data.theTrainingTrackLineSeqCd != null) {
      let t1: TRAINING_TRACK_LINE = data.theTrainingTrackLineSeqCd;
      dataString  = ( t1.userCaseId === null) ? "" : t1.userCaseId;
      dataString  = dataString + (( t1.userCaseLineNumberId === null) ? "" : t1.userCaseLineNumberId);
      dataString  = dataString + (( t1.wcn === null) ? "" : t1.wcn);
      dataString  = dataString + (( t1.wcn_SUFFIX_CD === null) ? "" : t1.wcn_SUFFIX_CD);
      dataString = dataString + ((data.fiscal_YEAR_ID === null) ? "" : data.fiscal_YEAR_ID);
      dataString  = dataString + (( data.external_DOCUMENT_CD === null) ? "" : data.external_DOCUMENT_CD);
      dataString  = dataString + (( t1.tl_FINANCIAL_STATUS_TYPE_ID === null) ? "" : t1.tl_FINANCIAL_STATUS_TYPE_ID);
      dataString = dataString + ((data.training_ACTIVITY_ID === null) ? "" : data.training_ACTIVITY_ID);    
      dataString = dataString.trim().toLocaleLowerCase();
    }
      return dataString.indexOf(filter) !== -1;
    }
    return thisFilterPredicate;
  }


 
 
  constructPostSuffixCyleForm() {
    this.postSuffixCycleForm = this.formBuilder.group({
    //  budgetcontrols : this.formBuilder.array([])
    // });
    // this.setEmptyBudgetControlsFcArray();
    tfo: this.formBuilder.control(''), // FR6 bcx.theCollectAccountLineSeqCd.wm_APC_CD
    fundedAm: this.formBuilder.control(''), // bcx.wm_FUNDED_AM
    prevPaid: this.formBuilder.control(''), // FR7  bcx.wm_PREV_PAID_AM
    prevBilled: this.formBuilder.control(''),//FR 22 bcx.prev_REIMB_BILLED_AM
    postedAm : this.formBuilder.control(''),
    postingAm : this.formBuilder.control(''),
    dovNo: this.formBuilder.control('')

  });
     
  }

  // form  control getters

  get tfo() {
    return this.postSuffixCycleForm.get('tfo');
  } 
    
  get fundedAm() {
    return this.postSuffixCycleForm.get('fundedAm');
  } 

  get prevPaid() {
    return this.postSuffixCycleForm.get('prevPaid');
  }
  get prevBilled() {
    return this.postSuffixCycleForm.get('prevBilled');
  }
 
  get postedAm() {
    return this.postSuffixCycleForm.get('postedAm');
  }

  get postingAm() {
    return this.postSuffixCycleForm.get('postingAm');
  }

  get dovNo() {
    return this.postSuffixCycleForm.get('dovNo');
  }


  
  
 // ImanageArmyBillingCycle override methods
 

 @ViewChild('editSlider', { static: false }) editSlider : MatSlideToggle;
 getEditSlider(): MatSlideToggle {
    return this.editSlider;
}
  
  setEditMode() : Observable<any> {
    let ccid: string = this.getTheCycleControlId();
    let obs = null;
    if (ccid.length > 1) {
      obs = this.getArmyBillingCycleDataWithNewSesionLock(ccid);
    }
    return obs;
    
}

  setViewMode() {
   
 
  
  }
 // obsolete
  // closeLockSession() {
  //   let lockId = sessionStorage.getItem(this.WP105_SESSION_LOCK_ID);
  //   console.log("close WP105_SESSION_LOCK_ID = " + lockId);
  //   this.closeDbLockSession(this.WP105_SESSION_LOCK_ID);
  // }

  getComponentLockSessionId() {
    let lockId = sessionStorage.getItem(this.WP105_SESSION_LOCK_ID);
    if (lockId == null || lockId.length == 0) {
      lockId = '0';
    }
    console.log("WP105_SESSION_LOCK_ID = " + lockId);
    return lockId;
  }
 
  setComponentLockSessionId(lockId : string) {
      sessionStorage.setItem(this.WP105_SESSION_LOCK_ID,lockId);
  }  
  
  
getArmyBillingCycleIdList(cycleId: string) {
    super.getArmyBillingCycleIdsWithSelect("/manualPosting/suffixCycleIdList", cycleId);
  }

getNewArmyBillingCycle() {
    this.setCycleCaseUsageCd();
    this.setCycleTypeId();
    this.reimbursementService.emptyBillingTable();
    this.reimbursementService.addBillingRow();
    super.getNewArmyBillingCycleData("/manualPosting/newSuffixCycle");
   
}

getArmyBillingCycle(cycleId: string,lockId : string) {
 // let lockId: string = this.getComponentLockSessionId();
  if (cycleId != null && cycleId.length > 2) {
    super.getArmyBillingCycleData("/manualPosting/suffixCycle", cycleId,lockId);
  
  } else {
      this.getNewArmyBillingCycle();
  }
  

}

saveArmyBillingCycle(): Observable<any> {
  let lockSessionId: string = this.getComponentLockSessionId();
  return super.saveArmyBillingCycleData("/manualPosting/save/suffixCycle", lockSessionId);
   }
 
  
approveArmyBillingCycle() {
    let lockId : string = this.getComponentLockSessionId().toString();
    let cycleId : string = this.theCC.cycle_CONTROL_ID.toString();
     super.approveArmyBillingCycleData("/manualPosting/approve/suffixCycle", cycleId, lockId);
  }

deleteArmyBillingCycle() {
    let cycleId : string = this.theCC.cycle_CONTROL_ID.toString();
    super.deleteArmyBillingCycleData("/manualPosting/delete/suffixCycle", cycleId);
  
    }  

 
  validateForSaveCycle(): boolean{
        let messageList: ErrorParameter[] = new Array<ErrorParameter>();
    if (this.theCC.budgetControlList != null) {
      this.theCC.budgetControlList.forEach(bcn => {
        if (bcn.status != EntityStatus.ENT_DELETED) {
          if (this.calculateBcnSaveAmount(bcn, messageList) == 0) {
            messageList.push(new ErrorParameter("Error",
              'Amounts', this.getBcnSuffixString(bcn).toString(), this.m13Msg));
          }
        }
      });
    }
    if (messageList.length == 0) {
      return true;
    }else{
      this.displayUserErrorMessages(messageList)
      return false;
    }
  }
  
  validateAmountEntered(event: any, row: BUDGET_COMPONENT) {
    console.log("oldAMount = " + row.action_AM);
    let amtString: string = event.target.value;
    if (isNumeric(amtString)) {
      let postingAm: number = Number(amtString);
      let errorMsg: string = this.validatePostedAmount(postingAm, row.wm_PREV_EXTERNAL_REIMB_AM, row.wm_FUNDED_AM);
        if (errorMsg.length > 0){
      
        this.displayErrorMessage("Invalid Amount", errorMsg)
        .subscribe(result => {
          console.log(errorMsg);
      
        });
      }
        this.markBcxAmountForUpdate(event, row);
     
    }
    
 }

calculateBcnSaveAmount(bcn: BUDGET_CONTROL,messageList: ErrorParameter[]): number {
   let totalBcnAmt: number = 0;
  if (bcn.budgetComponentList != null) {
    bcn.budgetComponentList.forEach(bcx =>
    {
      totalBcnAmt = totalBcnAmt + Number(bcx.wm_PREV_EXTERNAL_REIMB_AM) + Number(bcx.action_AM);
      let errorMsg: string = this.validatePostedAmount(bcx.action_AM,bcx.wm_PREV_REIMBURSEMENT_PAID_AM,bcx.wm_FUNDED_AM);
      if (errorMsg.length > 0){
        let bcxRef: string = this.getBcnSuffixString(bcn) + "/" +bcx.theCollectAccountLineSeqCd.wm_APC_CD;
        messageList.push(new ErrorParameter("Error", 'Amounts', bcxRef, errorMsg));
      }
      
    });
  }
 
  return totalBcnAmt;
  } 

  validatePostedAmount(postedAm: number, prevPaidAm : number, fundedAm : number): string {
    let totalAmount: number = postedAm + prevPaidAm;
    let errorMsg: string = "";
    if (totalAmount < 0) {
      errorMsg = this.m15Msg;
    } else if (totalAmount > fundedAm) {
      errorMsg = this.m14Msg;
    }
    return errorMsg
  }

  validateBcnDovNumbers(bcn : BUDGET_CONTROL,messageList: ErrorParameter[])  {
     console.log("validateBcnDovNumbers" );
    let dovNotGenerated: boolean = false;
    if (bcn.budgetComponentList != null) {
       bcn.budgetComponentList.forEach(bcx =>
       {
        console.log(" dov = " + bcx.post_DISBURSEMENT_VOUCHER_CD);
         if (bcx.action_AM != 0 && (bcx.post_DISBURSEMENT_VOUCHER_CD === null || bcx.post_DISBURSEMENT_VOUCHER_CD.length === 0)) {
           let bcxRef: string = this.getBcnSuffixString(bcn) +   "/" + bcx.theCollectAccountLineSeqCd.wm_APC_CD;
          messageList.push(new ErrorParameter("Error", 'DOV', bcxRef, this.m16Msg));
          
    
        }
     
      });
    }
   
    }  
  
          
  validateForApproveCycle(): boolean {
    let messageList: ErrorParameter[] = new Array<ErrorParameter>();
    if (this.theCC.budgetControlList != null) {
      this.theCC.budgetControlList.forEach(bcn => {
        if (bcn.status != EntityStatus.ENT_DELETED) {
          this.validateBcnDovNumbers(bcn, messageList);
        }
      });
      if (messageList.length == 0) {
        console.log("validateForApproveCycle() true");
        return true;
      } else {
        console.log("validateForApproveCycle() false ");
        this.displayUserErrorMessages(messageList)
        return false;
      }
    }
 
}


  
  setNoCycleSelected() {
    console.log("setNoCycleSelected()");
  this.isDisabledApprovebutton = true;
  this.isDisabledDeletebutton = true;
  this.isDisabledSavebutton = true;
  this.isDisabledGenDOVbutton = true;
  }
  
setCycleDataLoaded() {
    // this.setBudgetControlsFcArray(this.theCC.budgetControlList);
  if (this.theCC.cycle_CONTROL_ID != this.lastCycleLoaded ) {
    this.isDisabledApprovebutton = true;
      this.isDisabledDeletebutton = true;
      this.isDisabledSavebutton = true;
      this.isDisabledGenDOVbutton = true;
    this.cycleUser = this.theCC.create_USER_ID + "  " + this.theCC.createUserName;
    this.setService(this.theCC.case_USAGE_INDICATOR_CD);
    console.log("theCC.cycle_TITLE_NM = " + this.theCC.cycle_TITLE_NM);
    this.lastCycleLoaded = this.theCC.cycle_CONTROL_ID;
    this.isEditMode = false;
    this.closeLockSession();
  }
  this.cycleUser = this.theCC.create_USER_ID + "  " + this.theCC.createUserName;
    this.setService(this.theCC.case_USAGE_INDICATOR_CD);
    console.log("theCC.cycle_TITLE_NM = " + this.theCC.cycle_TITLE_NM);
  }
  
setNewCycleSelected() {
    this.setCycleCaseUsageCd();
    this.isDisabledDeletebutton = true;
    this.isDisabledGenDOVbutton = true;
    this.isDisabledApprovebutton = true;
  this.isDisabledSavebutton = false;
  this.cycleUser = this.theCC.create_USER_ID + "  " + this.theCC.createUserName;
    
  }

  setCycleSaved() {
    this.isDisabledGenDOVbutton = false;
    this.isDisabledApprovebutton = false;
  }
  setCycleDeleted() {
    this.calculateTotals();
    this.isEditMode = false;
    this.setViewMode();
  }

setGetCycleDataFailed(){} 

setSuffixPopupSelectRestrictions() {
  let docType: ISelectOptions = this.getSelectDocType();
  console.log("service is " + this.selectedServiceName);
  console.log("PopupSelectRestrictions doc type = " + docType.viewValue);
  console.log("Doctype = " + docType);
  this.suffixPopupData.selections = [];
  this.suffixPopupData.isMultiSelect = true;
  this.suffixPopupData.caseDocTypeSelections = [docType];
  this.suffixPopupData.programTypeSelections = [];
 this.suffixPopupData.selectionsUrl = "/manualPosting/ttlSuffixData";
    

  }
  setTLaPopupSelectRestrictions() {

  }

addSuffixSelections(selectionList: TtlSuffix[]) {
   
  for (var i = 0; i < selectionList.length; i++) {
    this.newSuffixesLoaded = false;
    this.newSuffixesLoading = true;
    let suffix: TtlSuffix = selectionList[i];
    
    suffix.caseDocType = this.theCC.case_USAGE_INDICATOR_CD;
    let suffixKey: string = this.getSuffixUserDisplayKey(suffix);
    if (!(this.checkForDuplicateBcn(suffixKey))) {
      this.getNewSuffixBcns(suffix);
    }
    
  }
  this.suffixPopupData.selections.length = 0;
    
  }
  
  checkForDuplicateBcn(userKey :  string): boolean {
    let duplicate: boolean = false
    if (this.theCC.budgetControlList != null && this.theCC.budgetControlList.length > 0) {
      this.theCC.budgetControlList.forEach(bcn => {
        let bcnKey: string = this.getBcnSuffixString(bcn);
        if (bcnKey == userKey) {
          return true;
        }
          });
      }

    return duplicate;
    
  }

 

calculateTotals() {
  this.cycleTotalAmount = 0.0;
  let addLog: string = '';
  if (this.theCC.budgetControlList != null) {
    for (var bcnIx in this.theCC.budgetControlList) {
      let bcn: BUDGET_CONTROL = this.theCC.budgetControlList[bcnIx];
        for (var bcdIx in bcn.budgetComponentList) {
        let bcd: BUDGET_COMPONENT = bcn.budgetComponentList[bcdIx];
         this.setNullValuesToZero(bcd);
        
         this.cycleTotalAmount = this.cycleTotalAmount +  Number(bcd.wm_PREV_EXTERNAL_REIMB_AM) + Number(bcd.action_AM);
       
      }
    
    }
  }

  }
  
  // end of ImanageArmyBillingCycle overrides

  
   /*----------------------------------
    Validation: checkAmountZero()
   -----------------------------------*/
   ltZeroRowNum: number;
   ltZeroSubRowNum: number;
   checkLtZeroFlag(row: number, subrow: number) {
      if (row == this.ltZeroRowNum && subrow == this.ltZeroSubRowNum){
          return true;
      } else
          return false;
   }
   checkLtZero(event: any, item: BUDGET_COMPONENT, row: number, subrow: number) {
     console.log("item=="+item.wm_PREV_PAID_AM + "total: "+(parseInt(event.target.value)+item.wm_PREV_PAID_AM))
     if ((parseInt(event.target.value)+item.wm_PREV_PAID_AM) < 0) {
         console.log("true")
         this.ltZeroRowNum = row;
         this.ltZeroSubRowNum = subrow;
     } else {
         this.ltZeroRowNum = -1;
         this.ltZeroSubRowNum = -1;
     }
   }
   
 
   /*----------------------------------
     Validation: checkAmountGtfundAmZero()
    -----------------------------------*/
    gtFundedAmRowNum: number;
    gtFundedAmSubRowNum: number;
    checkGtFundedAmFlag(row: number, subrow: number) {
       if (row == this.gtFundedAmRowNum && subrow == this.gtFundedAmSubRowNum){
           return true;
       } else
           return false;
    }
    checkGtFundedAm(event: any, item: BUDGET_COMPONENT, row: number, subrow: number) {
      console.log("item=="+item.wm_PREV_PAID_AM + "total: "+(parseInt(event.target.value)+item.wm_PREV_PAID_AM))
      if ((parseInt(event.target.value)+item.wm_PREV_PAID_AM) > item.wm_FUNDED_AM) {
          console.log("true")
          this.gtFundedAmRowNum = row;
          this.gtFundedAmSubRowNum = subrow;
      } else {
          this.gtFundedAmRowNum = -1;
          this.gtFundedAmSubRowNum = -1;
      }
    }
    
  // caseFilterPredicate() {
  //   const thisFilterPredicate = function (data: GfebsSuffixCase, filter:string) :boolean {
  //     let searchString = JSON.parse(filter);
  //     return data.case.toString().trim().toLowerCase().indexOf(searchString.case.toLowerCase()) !== -1 &&
  //     data.wcn.toString().trim().toLowerCase().indexOf(searchString.wcn.toLowerCase()) !== -1 &&
  //     data.docNo.toString().trim().toLowerCase().indexOf(searchString.docNo.toLowerCase()) !== -1 &&
  //     data.line.toString().trim().toLowerCase().indexOf(searchString.line.toLowerCase()) !== -1 &&
  //     data.fy.toString().trim().toLowerCase().indexOf(searchString.fy.toLowerCase()) !== -1 ;

  //   } 
  //   return thisFilterPredicate;
  // }

  getNewSuffixBcns(suffix: TtlSuffix) {
    console.log("WP105 getNewSuffixBcns()");
    console.log("suffix: " + this.getSuffixUserDisplayKey(suffix));
    //manualPosting/new/suffixBudgetControlList/{serviceDbId}/{cycleId}/{caseId}/{cmlId}/{ttSeqCd}/{ttlSeqCd}
    let cycleId: string = "";
    if (this.theCC.cycle_CONTROL_ID != null) {
      cycleId = this.theCC.cycle_CONTROL_ID.toString();
    }
      this.billingRestService.getNewPostingSuffixBudgetControlList(cycleId,
      suffix.case_ID.toString(), suffix.case_MASTER_LINE_ID.toString(),
      suffix.training_TRACK_SEQ_CD.toString(), suffix.training_TRACK_LINE_SEQ_CD.toString())
      .subscribe(
        data => {
          if (data == null) {
            console.log("bcnList data is null");
          } else {
            console.log("new suffix data");
            console.log(data);
            this.addNewBcns(data, suffix);
            this.newSuffixesLoaded = true;
            this.newSuffixesLoading = false;
          }
    
        },
        err => {
          this.handleError("getNewSuffixBcns()", err);
        });
  }

  delCustomerServiceItem(e: any) {
  console.log('*** del');
}

  onSubmit() { }
  
  ngOnDestroy() {
    super.ngOnDestroy();
    this.dsamsShareService.csuname.next(null);
    this.dsamsShareService.breadcrumbForFundingHome.next(null);
    }


}
