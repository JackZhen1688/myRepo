import { Component, OnInit, OnDestroy, Injector, ViewChild } from '@angular/core';
import { FormBuilder, FormControl } from '@angular/forms';
import { ViewportScroller } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { ISelectOptions } from 'src/app/dsams/interfaces/i-select-options';
import { EntityStatus } from './../../../enums/entity-status.enum';
import { ErrorParameter } from 'src/app/dsams/entities/specialEntities/error-parameter.model';
import {  MatDialog } from '@angular/material/dialog';
import { BUDGET_CONTROL } from 'src/app/dsams/entities/models/budget-control.model';
import { BUDGET_COMPONENT } from 'src/app/dsams/entities/models/budget-component.model';
import {TRNG_TRK_TLA_SUMMARY} from 'src/app/dsams/entities/models/trng-trk-tla-summary.model';
import { ManageArmyBillingCycleBaseComponent,isNumeric } from '../manage-army-billing-cycle-base/manage-army-billing-cycle-base.component';
import { ImanageArmyBillingCycle } from './../../interfaces/imanage-army-billing-cycle';
import { TttsAllLevel } from 'src/app/dsams/entities/specialEntities/ttts-all-level.model';
import { TtlSuffix } from 'src/app/dsams/entities/specialEntities/ttl-suffix.model';
import { MatSlideToggle } from '@angular/material/slide-toggle';
import { DsamsRestfulService } from 'src/app/dsams/services/dsams-restful.service';
import { Observable } from 'rxjs';





@Component({
  selector: 'app-gfebs-tla-cycle',
  templateUrl: './gfebs-tla-cycle.component.html',
  styleUrls: ['./gfebs-tla-cycle.component.css',
              './../../billing-global.css'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({height: '0px', minHeight: '0'})),
      state('expanded', style({height: '*'})),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})

 
export class GfebsTlaCycleComponent extends ManageArmyBillingCycleBaseComponent
  implements ImanageArmyBillingCycle, OnInit, OnDestroy {

   // WP105 Messages and variables specific to WP103
  m2Msg : string = "This case does not exist for this service or is not open or interim-closed";
  m3Msg : string = "This line does not exist for the case or does not containing suffix records";
  m4Msg : string = "This WCN does not exist for the line or does not contain suffix records";
  m5Msg : string = "This record does not exist, is in another cycle, or is not in a funded or billed status";
  m6Msg : string = "This FY is not valid for the record";
  m10Msg: string = "The amount entered plus the previous paid amount is less than zero. Please correct if this is not intended";
  m11Msg: string = "The amount entered plus the previous paid amount exceeds the funded amount";
  m12Msg: string = "An amount must be entered against at least one EOR for each record or the record must be deleted";
  m13Msg: string = "All EOR/Fiscal Year components with a posted amount must have an assigned DOV number";
  m14Msg: string = "You have unsaved changes. Would you like to save your cycle?";
  
  WP104_SESSION_LOCK_ID: string = 'WP104_SESSION_LOCK_ID';
  cycleTitle = '';
  cycleUser = '';

  displayedGfebsCase = [ 'case', 'line', 'wcn', 'suffix', 'fy', 'finStat', 'docNo',  'eor', 'fundedAm', 'prevPaidAm',  'postedAm',  'dovNo', 'command'];  
    
  //  displayedGfebsTlaCase = [ 'case', 'line', 'wcn', 'fy', 'finStat', 'apc', 'docNo', 'eor', 'fundedAm', 'prevPaidAm', 'postedAm', 'dovNo' ];

 
  expandedElement: null;
  //selectedCycle = "";
  // dataSourceCase = new MatTableDataSource();
  // dsBcnData = new MatTableDataSource();
  // @ViewChild('bcnTable', { static: false }) bcnTable: MatTable<BUDGET_CONTROL>;


  filterCase   = new FormControl();
  filterLine   = new FormControl();
  filterWcn     = new FormControl();
  filterFy = new FormControl();
  filterSuffix     = new FormControl();
  filterDocNum = new FormControl();
  private caseFilterValues = { case: '', line: '', wcn: '',  suffix: '', fy: '',  finStat: '', docNo: '', eor: '', exa: '', paymentType: '' };
 
  constructor(protected injector: Injector, 
              protected route: ActivatedRoute,
              protected dsamsReferenceService: DsamsRestfulService,
              public popUpDialog: MatDialog,
              protected formBuilder: FormBuilder,
              protected viewportScroller: ViewportScroller) 
  {
      super(injector, route, dsamsReferenceService, popUpDialog, formBuilder, viewportScroller);
  }
    

  ngOnInit() {
    super.ngOnInit();
    this.dsamsShareService.csuname.next(this.route.snapshot.params['csu']);
    this.constructCyleForm();
    this.dsBcnData.filterPredicate = this.tlaPostingFilterPredicate();
                                         
  }
  getCSU_CD():string { return "WP104"; }

  tlaPostingFilterPredicate() {
    // Case Line WCN Suffix Fy FinStatus DocNbr 
    const thisFilterPredicate = function (data: BUDGET_CONTROL, filter: string): boolean {
      // Case Line WCN Suffix Fy FinStatus DocNbr 
      let dataString : string = "";
    if (data.theTrngTrkTlaSummarySeqCd != null) {
             let t1: TRNG_TRK_TLA_SUMMARY = data.theTrngTrkTlaSummarySeqCd;
            dataString  = ( t1.userCaseId === null) ? "" : t1.userCaseId;
          dataString  = dataString + (( t1.userCaseLineNumberId === null) ? "" : t1.userCaseLineNumberId);
          dataString  = dataString + (( t1.wcn === null) ? "" : t1.wcn);
          dataString  = dataString + (( t1.external_FINANCIAL_CD === null) ? "" : t1.external_FINANCIAL_CD);
          dataString  = dataString + (( data.fiscal_YEAR_ID === null) ? "" :data.fiscal_YEAR_ID);
          dataString  = dataString + (( t1.tl_FINANCIAL_STATUS_TYPE_ID === null) ? "" : t1.tl_FINANCIAL_STATUS_TYPE_ID);
          dataString  = dataString + (( data.external_DOCUMENT_CD === null) ? "" : data.external_DOCUMENT_CD);
         dataString = dataString.trim().toLocaleLowerCase();
      }
      return dataString.indexOf(filter) !== -1;
    }
    return thisFilterPredicate;
  }

 
 
  constructCyleForm() {
    this.cycleForm = this.formBuilder.group({
    //  budgetcontrols : this.formBuilder.array([])
    // });
    // this.setEmptyBudgetControlsFcArray();
    eor: this.formBuilder.control(''), // FR6 bcx.theCollectAccountLineSeqCd.wm_APC_CD
    fundedAm: this.formBuilder.control(''), // bcx.wm_FUNDED_AM
    prevPaid: this.formBuilder.control(''), // FR7  bcx.wm_PREV_PAID_AM
     postedAm : this.formBuilder.control(''),
      dovNo: this.formBuilder.control(''),
      tlaCycleTotalAmount: this.formBuilder.control(''),
      tlaCycleUnsavedAmount: this.formBuilder.control('')

  });
     
  }

  // form  control getters
  get tlaCycleTotalAmount() {
    return this.cycleForm.get('tlaCycleTotalAmount');
  } 

  get tlaCycleUnsavedAmount() {
    return this.cycleForm.get('tlaCycleUnsavedAmount');
  } 
  get eor() {
    return this.cycleForm.get('eor');
  } 
    
  get fundedAm() {
    return this.cycleForm.get('fundedAm');
  } 

  get prevPaid() {
    return this.cycleForm.get('prevPaid');
  }
  
 
  get postedAm() {
    return this.cycleForm.get('postedAm');
  }

  

  get dovNo() {
    return this.cycleForm.get('dovNo');
  }

  public doFilter = (value: string) => {
    this.dsBcnData.filter = value.trim().toLocaleLowerCase();
  }
  
  
 // ImanageArmyBillingCycle override methods
 @ViewChild('editSlider', { static: false }) editSlider : MatSlideToggle;
 getEditSlider(): MatSlideToggle {
    return this.editSlider;
  }
  

 setEditMode() : Observable<any> {
   let ccid: string = this.getTheCycleControlId();
   console.log('setEditModeTla ' + ccid);
   let obs = null;
  if (ccid.length > 1) {
    obs = this.getArmyBillingCycleDataWithNewSesionLock(ccid);
  }
  return obs;
  
}

setViewMode() {
  

  }
  
  
  // closeLockSession() {
  //   this.closeDbLockSession(this.WP104_SESSION_LOCK_ID);
  // }

  getComponentLockSessionId() {
    let lockId = sessionStorage.getItem(this.WP104_SESSION_LOCK_ID);
    if (lockId == null || lockId.length == 0) {
      lockId = '0';
    }
    return lockId;
  }
 
  setComponentLockSessionId(lockId : string) {
      sessionStorage.setItem(this.WP104_SESSION_LOCK_ID,lockId);
  }
  
getArmyBillingCycleIdList(cycleId: string) {
    super.getArmyBillingCycleIdsWithSelect("/manualPosting/tlaCycleIdList", cycleId);
  }

getNewArmyBillingCycle() {
    this.setCycleCaseUsageCd();
    this.setCycleTypeId();
    this.reimbursementService.emptyBillingTable();
    this.reimbursementService.addBillingRow();
    super.getNewArmyBillingCycleData("/manualPosting/newTlaCycle");
   
}

  getArmyBillingCycle(cycleId: string, lockId : string) {
    console.log("getArmyBillingCycle(" + cycleId + ")");
 // let lockId: string = this.getComponentLockSessionId().toString();
  if (cycleId != null && cycleId.length > 2) {
    super.getArmyBillingCycleData("/manualPosting/tlaCycle", cycleId,lockId);
  
  } else {
      this.getNewArmyBillingCycle();
  }
  

}

saveArmyBillingCycle(): Observable<any> {
  let lockSessionId = this.getComponentLockSessionId();
  return super.saveArmyBillingCycleData("/manualPosting/save/tlaCycle", lockSessionId);
   }
 
  
approveArmyBillingCycle() {
    let lockId : string = this.getComponentLockSessionId().toString();
    let cycleId : string = this.theCC.cycle_CONTROL_ID.toString();
    super.approveArmyBillingCycleData("/manualPosting/approve/tlaCycle", cycleId, lockId);
  }

deleteArmyBillingCycle() {
    let cycleId : string = this.theCC.cycle_CONTROL_ID.toString();
    super.deleteArmyBillingCycleData("/manualPosting/delete/tlaCycle", cycleId);
  
    }  

    validateAmountEntered(event: any, row: BUDGET_COMPONENT) {
      this.markBcxAmountForUpdate(event, row);
      let amtString: string = event.target.value;
      if (isNumeric(amtString)) {
        let postingAm: number = Number(amtString);
        let errorMsg: string = this.validatePostedAmount(postingAm, row.wm_PREV_PAID_AM, row.wm_FUNDED_AM);
          if (errorMsg.length > 0){
        
          this.displayErrorMessage("Invalid Amount", errorMsg)
          .subscribe(result => {
            console.log(errorMsg);
        
          });
         
        }
        this.markBcxAmountForUpdate(event, row);
      }
      
   }
  validateForSaveCycle(): boolean{
    console.log("validateForSaveCycle()");
    let messageList: ErrorParameter[] = new Array<ErrorParameter>();
    if (this.theCC.budgetControlList != null) {
      this.theCC.budgetControlList.forEach(bcn => {
        if (bcn.status != EntityStatus.ENT_DELETED) {
          if (this.calculateBcnSaveAmount(bcn,messageList) === 0) {
            messageList.push(new ErrorParameter("Error",
              'Amounts', this.getBcnTlaString(bcn), this.m12Msg));
          }
        }
      });
      
     
    }  
     if (messageList.length == 0) {
      return true;
    }else{
      this.displayUserErrorMessages(messageList)
      return false;
    }
 
   
}
 
validateForApproveCycle(): boolean {
   let messageList: ErrorParameter[] = new Array<ErrorParameter>();
  if (this.theCC.budgetControlList != null) {
    this.theCC.budgetControlList.forEach(bcn => {
      if (bcn.status != EntityStatus.ENT_DELETED) {
        this.validateBcnDovNumbers(bcn, messageList);
      }
    });
  }
   if (messageList.length == 0) {
    return true;
  }else{
    this.displayUserErrorMessages(messageList)
    return false;
  }

}

calculateBcnSaveAmount(bcn: BUDGET_CONTROL,messageList: ErrorParameter[]): number {
  // let totalActionAmt: number = 0;
  let totalBcnAmt: number = 0;
  if (bcn.budgetComponentList != null) {
    bcn.budgetComponentList.forEach(bcx =>
    {
      totalBcnAmt = totalBcnAmt + Number(bcx.wm_PREV_PAID_AM) + Number(bcx.action_AM);
      let errorMsg: string = this.validatePostedAmount(bcx.action_AM,bcx.wm_PREV_PAID_AM,bcx.wm_FUNDED_AM);
      if (errorMsg.length > 0){
        let bcxRef: string = this.getBcnTlaString(bcn) + "/" +bcx.object_CLASS_ID;
        messageList.push(new ErrorParameter("Error", 'Amounts', bcxRef, errorMsg));
      }
      
    });
  }
 
  return totalBcnAmt;
  }

  validatePostedAmount(postedAm: number, prevPaidAm : number, fundedAm : number): string {
    let totalAmount: number = postedAm + prevPaidAm;
    let errorMsg: string = "";
    if (totalAmount < 0) {
      errorMsg = this.m10Msg;
    } else if (totalAmount > fundedAm) {
      errorMsg = this.m11Msg;
    }
    return errorMsg
  }

  validateBcnDovNumbers(bcn : BUDGET_CONTROL,messageList: ErrorParameter[])  {
     console.log("validateBcnDovNumbers" );
     if (bcn.budgetComponentList != null) {
       bcn.budgetComponentList.forEach(bcx =>
       {
        console.log(" dov = " + bcx.post_DISBURSEMENT_VOUCHER_CD);
         if (bcx.action_AM != 0 && (bcx.post_DISBURSEMENT_VOUCHER_CD === null || bcx.post_DISBURSEMENT_VOUCHER_CD.length === 0)) {
           let bcxRef: string = this.getBcnTlaString(bcn) +   "/" + bcx.object_CLASS_ID;
          messageList.push(new ErrorParameter("Error", 'DOV', bcxRef, this.m13Msg));
          
    
        }
         
      });
    }

   
    } 
setNoCycleSelected() {
  this.isDisabledApprovebutton = true;
  this.isDisabledDeletebutton = true;
  this.isDisabledSavebutton = true;
  this.isDisabledGenDOVbutton = true;
  }
  
  setCycleDataLoaded() {
    if (this.theCC.cycle_CONTROL_ID != this.lastCycleLoaded) {
      this.isDisabledApprovebutton = true;
      this.isDisabledDeletebutton = true;
      this.isDisabledSavebutton = true;
      this.isDisabledGenDOVbutton = true;
      this.cycleUser = this.theCC.create_USER_ID + "  " + this.theCC.createUserName;
      this.setService(this.theCC.case_USAGE_INDICATOR_CD);
      console.log("theCC.cycle_TITLE_NM = " + this.theCC.cycle_TITLE_NM);
      this.lastCycleLoaded = this.theCC.cycle_CONTROL_ID;
      this.isEditMode = false;
      this.closeLockSession();
    }
    this.setService(this.theCC.case_USAGE_INDICATOR_CD);
     this.cycleUser = this.theCC.create_USER_ID + "  " + this.theCC.createUserName;
    console.log("theCC.cycle_TITLE_NM = " + this.theCC.cycle_TITLE_NM);
  }
  
setNewCycleSelected() {
    this.setCycleCaseUsageCd();
    this.isDisabledDeletebutton = true;
    this.isDisabledGenDOVbutton = true;
    this.isDisabledApprovebutton = true;
  this.isDisabledSavebutton = false;
  this.cycleUser = this.theCC.create_USER_ID + "  " + this.theCC.createUserName;
    
  }

  setCycleSaved() {
    this.isDisabledGenDOVbutton = false;
    this.isDisabledApprovebutton = false;
  }
  setCycleDeleted() {
    this.calculateTotals();
    this.isEditMode = false;
    this.setViewMode();
  }

setGetCycleDataFailed(){} 

  setSuffixPopupSelectRestrictions() {
  }

setTLaPopupSelectRestrictions() {
  let docType: ISelectOptions = this.getSelectDocType();
  console.log("service is " + this.selectedServiceName);
  console.log("PopupSelectRestrictions doc type = " + docType.viewValue);
  console.log("Doctype = " + docType);
  this.tttsPopupData.selections = [];
  this.tttsPopupData.isMultiSelect = true;
  this.tttsPopupData.caseDocTypeSelections = [docType];
  this.tttsPopupData.programTypeSelections = [];
  this.tttsPopupData.selectionsUrl = "/manualPosting/tlaData";
  //this.tttsPopupData.selectionsUrl = "/infrastructure/tttsAllLevels";
    

}

  addSuffixSelections(selectionList: TtlSuffix[]) {
  }
  
addTlaSelections(selectionList:TttsAllLevel[]) {
   
  for (var i = 0; i < selectionList.length; i++) {
    this.newSuffixesLoaded = false;
    this.newSuffixesLoading = true;
    let ttts : TttsAllLevel = this.tttsPopupData.selections[i];
    
    ttts.caseDocType = this.theCC.case_USAGE_INDICATOR_CD;
    
    this.getNewTlaBcns(ttts);
    
  }
  this.tttsPopupData.selections.length = 0;
    
}


  calculateTotals() {
    console.log("calculateTotals()");
  this.cycleTotalAmount = 0.0;
  this.cycleUnsavedAmount = 0.0;
  let addLog: string = '';
  if (this.theCC.budgetControlList != null) {
    for (var bcnIx in this.theCC.budgetControlList) {
      let bcn: BUDGET_CONTROL = this.theCC.budgetControlList[bcnIx];
        for (var bcdIx in bcn.budgetComponentList) {
        let bcd: BUDGET_COMPONENT = bcn.budgetComponentList[bcdIx];
         this.setNullValuesToZero(bcd);
         
          if (bcd.status == EntityStatus.ENT_UNCHANGED) {
            console.log("unchanged()" + bcdIx +bcd.action_AM );
           this.cycleTotalAmount = this.cycleTotalAmount + Number(bcd.action_AM);
          } else if (bcd.status != EntityStatus.ENT_DELETED) {
            console.log("Changed()" + bcdIx +bcd.action_AM );
          this.cycleUnsavedAmount = this.cycleUnsavedAmount + Number(bcd.action_AM);
         }
       
      }
    
    }
  }
  this.tlaCycleTotalAmount.setValue(this.cycleTotalAmount.toString());
  this.tlaCycleUnsavedAmount.setValue(this.cycleUnsavedAmount.toString());
  }
  
  // end of ImanageArmyBillingCycle overrides

  
   /*----------------------------------
    Validation: checkAmountZero()
   -----------------------------------*/
   ltZeroRowNum: number;
   ltZeroSubRowNum: number;
  checkLtZeroFlag(row: number, subrow: number) {
    // console.log("checkLtZeroFlag(" + row + "," + subrow + ")");
    // throw new Error("Abstract method not implemented");
      // if (row == this.ltZeroRowNum && subrow == this.ltZeroSubRowNum){
      //     return true;
      // } else
      //     return false;
   }
   checkLtZero(event: any, item: BUDGET_COMPONENT, row: number, subrow: number) {
     console.log("item==" + item.wm_PREV_PAID_AM + "total: " + (parseInt(event.target.value) + item.wm_PREV_PAID_AM))
      if ((parseInt(event.target.value)+item.wm_PREV_PAID_AM) < 0) {
         console.log("true")
         this.ltZeroRowNum = row;
         this.ltZeroSubRowNum = subrow;
     } else {
         this.ltZeroRowNum = -1;
         this.ltZeroSubRowNum = -1;
     }
   }
   
 
   /*----------------------------------
     Validation: checkAmountGtfundAmZero()
    -----------------------------------*/
    gtFundedAmRowNum: number;
    gtFundedAmSubRowNum: number;
    checkGtFundedAmFlag(row: number, subrow: number) {
       if (row == this.gtFundedAmRowNum && subrow == this.gtFundedAmSubRowNum){
           return true;
       } else
           return false;
    }
    checkGtFundedAm(event: any, item: BUDGET_COMPONENT, row: number, subrow: number) {
      console.log("item=="+item.wm_PREV_PAID_AM + "total: "+(parseInt(event.target.value)+item.wm_PREV_PAID_AM))
      if ((parseInt(event.target.value)+item.wm_PREV_PAID_AM) > item.wm_FUNDED_AM) {
          console.log("true")
          this.gtFundedAmRowNum = row;
          this.gtFundedAmSubRowNum = subrow;
      } else {
          this.gtFundedAmRowNum = -1;
          this.gtFundedAmSubRowNum = -1;
      }
    }
    
  

  getNewTlaBcns(ttts: TttsAllLevel) {
    console.log("WP105 getNewSuffixBcns()");
    console.log("suffix: " + this.getTttsUserDisplayKey(ttts));
    //manualPosting/new/suffixBudgetControlList/{serviceDbId}/{cycleId}/{caseId}/{cmlId}/{ttSeqCd}/{ttlSeqCd}
    let cycleId: string = "";
    if (this.theCC.cycle_CONTROL_ID != null) {
      cycleId = this.theCC.cycle_CONTROL_ID.toString();
    }
      this.billingRestService.getNewPostingTlaBudgetControlList(cycleId,
      ttts.case_ID.toString(), ttts.case_MASTER_LINE_ID.toString(),
      ttts.training_TRACK_SEQ_CD.toString())
      .subscribe(
        data => {
          if (data == null) {
            console.log("bcnList data is null");
          } else {
            console.log("new suffix data");
            console.log(data);
            this.addNewBcns(data, ttts);
            this.newSuffixesLoaded = true;
            this.newSuffixesLoading = false;
          }
    
        },
        err => {
          this.handleError("getNewSuffixBcns()", err);
        });
  }

  

  onSubmit() { }
  
  ngOnDestroy() {
    super.ngOnDestroy();
    this.dsamsShareService.csuname.next(null);
    }


}
