import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from "@angular/router";
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatDialog, MatDialogConfig} from '@angular/material/dialog';
import { FormBuilder, FormGroup, FormArray, Validators} from '@angular/forms';
import { ISelectOptions } from 'src/app/dsams/interfaces/i-select-options';
import { DsamsShareService } from './../../../services/dsams-share.service';
import { BillingRestfulService } from './../../services/billing-restful.service';
import { DsamsMethodsService } from './../../../services/dsams-methods.service';
import { DsamsConstants } from './../../../dsams.constants';
import { PopCaseAllLevelsComponent} from './../../../utilitis/popups/pop-case-all-levels/pop-case-all-levels.component';
import { PopCountryAllLevelComponent, CountryAllLevelPopupData } from './../../../utilitis/popups/pop-country-all-level/pop-country-all-level.component';
import { PopLineAllLevelsComponent, CaseLineAllLevelPopupData } from './../../../utilitis/popups/pop-line-all-levels/pop-line-all-levels.component';
import { PopWcnAllLevelsComponent, WcnAllLevelPopupData } from './../../../utilitis/popups/pop-wcn-all-levels/pop-wcn-all-levels.component';
import { PopSuffixAllLevelsComponent,  SuffixAllLevelPopupData } from './../../../utilitis/popups/pop-suffix-all-levels/pop-suffix-all-levels.component';
import { PopTrainingActvityRoleComponent, TrainingActivityRolePopupData } from './../../../utilitis/popups/pop-training-actvity-role/pop-training-actvity-role.component';


export interface Program {
  program_type_title_nm: string;
  program_type_id:string;
}

export interface FiscalYears {
  fiscalYearId: string;
}

export interface TypeCd{
    cd:string;
    name:string;
}

@Component({
  selector: 'app-autonew-reimburse-cycle',
  templateUrl: './autonew-reimburse-cycle.component.html',
  styleUrls: ['./autonew-reimburse-cycle.component.css']
})
export class AutonewReimburseCycleComponent implements OnInit {

  jobTypesA: TypeCd[] = [{cd:'0',name:'Billing'}];
  jobTypesN: TypeCd[] = [{cd:'0',name:'Select Type'}, {cd:'2',name:'Online Billing'}, {cd:'3',name:'Auto-Offline Billing'}, {cd:'7',name:'Validate Online Billing'}, {cd:'8',name:'Validate Offline Billing'}];
  jobTypesF: TypeCd[] = [{cd:'0',name:'Select Type'}, {cd:'1',name:'Billing'}, {cd:'4',name:'DEAMS Billing'}, {cd:'5',name:'Year-End Billing'}, {cd:'6',name:'Year-End DEAMS Billing'}, {cd:'9',name:'Validate Billing'}];

  durationInSeconds = 5;
  serviceId: string;

  autonewReimbCycleForm: FormGroup;
  jobTypes: TypeCd[];
  programs: Program[];
  fiscalYears: FiscalYears[];
  countryPopupData: CountryAllLevelPopupData;
  caseLinePopupData: CaseLineAllLevelPopupData;
  wcnPopupData: WcnAllLevelPopupData;
  suffixPopupData: SuffixAllLevelPopupData;
  tarPopupData: TrainingActivityRolePopupData;

  constructor(private formBuilder: FormBuilder, 
              private route: ActivatedRoute,
              private dsamsShareService: DsamsShareService,
              public dsamsMethodsService: DsamsMethodsService,
              private _snackBar: MatSnackBar,
              public dialog: MatDialog,
              private billingRestService: BillingRestfulService ) { }

  ngOnInit()
  {
    this.serviceId = sessionStorage.getItem('serviceDBid');
    console.log("Autonew Service Id=="+sessionStorage.getItem('serviceDBid'))
    this.dsamsShareService.csuname.next(this.route.snapshot.params['csu']);

    this.constructAutonewReimbCycleForm(); 
    //this.patchValueDataInit();
    this.getProgramTypeNames(encodeURIComponent("#"+this.serviceId));
    this.getFiscalYearsData('6');
    if (this.serviceId === 'N')
        this.jobTypes = this.jobTypesN;
    else if (this.serviceId === 'F')
        this.jobTypes = this.jobTypesF;
    else 
        this.jobTypes = this.jobTypesA;

    this.autonewReimbCycleForm.get('txtJobType').setValue("0");

  }

  ngOnDestroy() {
    this.dsamsShareService.csuname.next(null);
  }

  constructAutonewReimbCycleForm() 
  {
    this.autonewReimbCycleForm = this.formBuilder.group({
      txtJobType: this.formBuilder.control([]),
      txtJobName: this.formBuilder.control(''),
      txtDaysOut: this.formBuilder.control('30'),
      txtEdit: this.formBuilder.control(false),
      sltPrograms: this.formBuilder.control([], [Validators.required]),
      sltFiscalYear: this.formBuilder.control([]),
      rbnService: this.formBuilder.control(this.serviceId),
      rbnRunBy: this.formBuilder.control('case'),

      runByCaseRows: this.formBuilder.array([]), 
      runByEXARows: this.formBuilder.array([]),

      serviceId: this.formBuilder.control(this.serviceId),

    });
  }

  patchValueExaRows(data: any[]) {
    data.forEach(item =>{
        const runByExaRow = this.formBuilder.group({ 
          txtEXA: item.activity === undefined ?'':item.activity, 
        })
        this.exaRows.push(runByExaRow);
    });
  }

  patchValueDataRows(data: any[], duplicateRows: any[]) {
    data.forEach(item =>{
      if (duplicateRows.indexOf(item) == -1) {
          const runByCaseRow = this.formBuilder.group({ 
            txtCountry: item.custOrgId === undefined?'':item.custOrgId,
            txtCase: item.caseId === undefined ?'':item.caseId, 
            txtLine: item.lineNumber == undefined ?'':this.dsamsMethodsService.padZeroLeft(item.lineNumber, '0', 3),
            txtWCN:  item.wcn === undefined ?'':item.wcn,
            txtSuffix: item.suffixCode === undefined ?'':item.suffixCode,
          })
          this.caseRows.push(runByCaseRow);
      }
    });
    duplicateRows = [];
  }

  checkDuplicateRow(existRows: FormArray, seleRows: any[], checkFlag: string) { 
    let duplicateRows: string[] = [];
    let removeCases: number[] = [];
    if (existRows.controls.length != 0) {   
      let i: number = 0;
      for(let existRow of existRows.controls) {
          seleRows.forEach(item =>{
            //Chcek Countries
            if (checkFlag === 'country') {
               if (existRow.get('txtCountry').value === item.custOrgId) 
                   duplicateRows.push(item); 
            }
            //Chcek Case
            if (checkFlag === 'case') {
               if (existRow.get('txtCase').value === item.caseId) {
                   duplicateRows.push(item);
               } else {
                  if (item.caseId !=undefined && existRow.get('txtCountry').value === item.caseId.substring(0,2)) 
                      removeCases.push(item.caseId); 
               }
               //Check Country Duplication
               if (existRow.get('txtLine').value === '' && existRow.get('txtWCN').value === '' && existRow.get('txtSuffix').value === '' && existRow.get('txtCase').value === '' && 
                   item.caseId != undefined && existRow.get('txtCountry').value === item.caseId.substring(0,2))
                   removeCases.push(item.caseId.substring(0,2));
            }
            //Chcek Lines
            if (checkFlag === 'line') {
                //Check Line Duplicate
                if (existRow.get('txtCase').value === item.caseId && parseInt(existRow.get('txtLine').value) === parseInt(item.lineNumber)) {
                    duplicateRows.push(item);
                } else {
                    //Check Case Duplicate
                    if (existRow.get('txtLine').value === '' && existRow.get('txtCase').value === item.caseId)
                        removeCases.push(item.caseId);
                }
                //Check Country Duplication
                if (existRow.get('txtLine').value === '' && existRow.get('txtWCN').value === '' && existRow.get('txtSuffix').value === '' && existRow.get('txtCase').value === '' && 
                    item.caseId != undefined && existRow.get('txtCountry').value === item.caseId.substring(0,2))
                    removeCases.push(item.caseId.substring(0,2));
            }
            //Chcek WCNs
            if (checkFlag === 'wcn') {
                //Check WCN Duplicate
                if (existRow.get('txtCase').value === item.caseId && parseInt(existRow.get('txtLine').value) === parseInt(item.lineNumber) && existRow.get('txtWCN').value === item.wcn) {
                    duplicateRows.push(item);
                } else {
                    //Check Line Duplicate
                    if (existRow.get('txtWCN').value === '' && existRow.get('txtSuffix').value === '' && 
                        existRow.get('txtCase').value === item.caseId && parseInt(existRow.get('txtLine').value) === parseInt(item.lineNumber)) 
                          removeCases.push(item.caseId);
                    //Check Case Duplicate
                    if (existRow.get('txtLine').value === '' && existRow.get('txtWCN').value=== '' && existRow.get('txtSuffix').value === '' && 
                        existRow.get('txtCase').value === item.caseId ) 
                          removeCases.push(item.caseId);
                    //Check Country Duplication
                    if (existRow.get('txtLine').value === '' && existRow.get('txtWCN').value === '' && existRow.get('txtSuffix').value === '' && existRow.get('txtCase').value === '' && 
                        item.caseId != undefined && existRow.get('txtCountry').value === item.caseId.substring(0,2))
                          removeCases.push(item.caseId.substring(0,2));
                }
            }
            //Chcek Suffixs
            if (checkFlag === 'suffix') {
                //#1. Check Suffix Duplication
                if (existRow.get('txtCase').value === item.caseId && parseInt(existRow.get('txtLine').value) === parseInt(item.lineNumber) &&
                    existRow.get('txtWCN').value  === item.wcn    && existRow.get('txtSuffix').value === item.suffixCode ) {
                       duplicateRows.push(item);
                } else {
                    //#2. Check WCN Duplication
                    if (existRow.get('txtSuffix').value === '' && 
                        existRow.get('txtCase').value   === item.caseId && parseInt(existRow.get('txtLine').value) === parseInt(item.lineNumber) && existRow.get('txtWCN').value === item.wcn ) 
                          removeCases.push(item.caseId);
                    //#3. CHeck Line Duplication
                    if (existRow.get('txtWCN').value === '' && existRow.get('txtSuffix').value === '' && 
                        existRow.get('txtCase').value === item.caseId && parseInt(existRow.get('txtLine').value) === parseInt(item.lineNumber)) 
                          removeCases.push(item.caseId);
                    //#4. Check Case Duplication
                    if (existRow.get('txtLine').value === '' && existRow.get('txtWCN').value === '' && existRow.get('txtSuffix').value === '' && 
                        existRow.get('txtCase').value === item.caseId ) 
                          removeCases.push(item.caseId);
                    //#5. Check Country Duplication
                    if (existRow.get('txtLine').value === '' && existRow.get('txtWCN').value === '' && existRow.get('txtSuffix').value === '' && existRow.get('txtCase').value === '' && 
                        item.caseId != undefined && existRow.get('txtCountry').value === item.caseId.substring(0,2))
                          removeCases.push(item.caseId.substring(0,2));
                }
            }
          });
          i++;
        }
    }

    //Remove the duplication cases which include Line/WCN/Suffix
    if (removeCases.length > 0) {
        removeCases.forEach(item => { 
          let index: number = 0;
          for(let existRow of existRows.controls) {
             if (existRow.get('txtCase').value === item || existRow.get('txtCountry').value === item) 
                 existRows.removeAt(index);
             index++;
          }
      }); 
    }
  
    //if (duplicateRows.length > 0)
    //    this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, "WARNING: Ignore the duplicate row(s): "+JSON.stringify(duplicateRows));

    console.log("***** duplicateRows=="+JSON.stringify(duplicateRows)+" **** removeRow=="+removeCases);
    return duplicateRows;
  }
 

  get programTypes() {
    return this.autonewReimbCycleForm.get('sltPrograms');
  }

  get edit() {
    return this.autonewReimbCycleForm.get('txtEdit');
  }

  get rbnService() {
    return this.autonewReimbCycleForm.get('rbnService');
  } 

  getProgramTypeNames(filter: string) {
    this.billingRestService.getProgramTypeNames(filter)
    .subscribe(
      data => { 
        this.programs = data;
      },
      err => {
        console.log("Error occured: getProgramTypeNames()")
      }
    );
  }

  getFiscalYearsData(numYear: string) {
    this.billingRestService.getFiscalYearsData(encodeURIComponent(numYear+"#"+this.serviceId))
    .subscribe(
      data => { 
        this.fiscalYears = data;// JSON.parse(data);
      },
      err => {
        console.log("Error occured: getFiscalYearsData()")
      }
    );
  }

  get caseRows() {
    return this.autonewReimbCycleForm.get('runByCaseRows') as FormArray
  }

  delRunByCaseRows(i: any) {
    this.caseRows.removeAt(i);
  }

  get exaRows() {
    return this.autonewReimbCycleForm.get('runByEXARows') as FormArray
  }

  delRunByEXARows(i: any) {
    this.exaRows.removeAt(i);
  }  

  getSelectDocType() {
    let caseUsage: ISelectOptions = { viewValue : "Case", value : "C" };
    let selectedService: string = this.rbnService.value; 
    if (selectedService != this.serviceId) {
      if (selectedService == "A") {
          caseUsage = { viewValue : "Army Cross Service Case", value : "X" };
      } else if (selectedService == "F") {
          caseUsage = { viewValue : "Air Force Cross Service Case", value : "Z" };
      } else {
          caseUsage = { viewValue : "Navy Cross Service Case", value : "Y" };
      }
    }
    
    return caseUsage;
  }

 /*----------------------------
   PopupWin for Search Country
  -----------------------------*/
  addCountries() {

    this.countryPopupData = new CountryAllLevelPopupData;
    this.countryPopupData.selections = [];
    this.countryPopupData.isMultiSelect = true;
    this.countryPopupData.selectionsUrl = "/infrastructure/countryAllLevels/" + this.serviceId; 

    const dialogConfig   = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width  = "950px";
    dialogConfig.height = "600px";
    dialogConfig.data = this.countryPopupData;   
    
    const dialogRef = this.dialog.open(PopCountryAllLevelComponent, dialogConfig );
    dialogRef.afterClosed().subscribe(result => {
      if (this.countryPopupData.selections != null && this.countryPopupData.selections.length > 0) 
          this.patchValueDataRows(result, this.checkDuplicateRow(this.caseRows, result, 'country'));  
    });

    //let result: any[] = [{custOrgId:'2E'}, 
    //                     {custOrgId:'22'}];

  }

 /*----------------------------
   PopupWin for Search Case
  -----------------------------*/
  addCases() {
  
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width  = "1170px";
    dialogConfig.height = "610px";
    dialogConfig.data   = {passingData: "multiple", 
                           passingModule: false,
                           passingDocType: this.getSelectDocType(),
                           passingProTypes: this.programTypes.value};

    const dialogRef = this.dialog.open(PopCaseAllLevelsComponent, dialogConfig);
    dialogRef.afterClosed().subscribe(result => {
       if (result.length != 0 )
          this.patchValueDataRows(result, this.checkDuplicateRow(this.caseRows, result, 'case'));  
    });

   //let result: any[] = [{custOrgId:'22', caseId:'22B17X'}, 
   //                     {custOrgId:'44', caseId:'44B17X'}];

  }
 
 /*----------------------------
   PopupWin for Search CaseLine
  -----------------------------*/
  addLines() {
  
    this.caseLinePopupData = new CaseLineAllLevelPopupData;
    this.caseLinePopupData.selections = [];
    this.caseLinePopupData.isMultiSelect = true;
    let docType: ISelectOptions = this.getSelectDocType();
    this.caseLinePopupData.caseDocTypeSelections = [docType];
    if (this.programTypes != null)
        this.caseLinePopupData.subProgramTypes = this.programTypes.value;
    this.caseLinePopupData.selectionsUrl = "/autoBilling/caseLineAllLevels/" + this.serviceId; 

    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width  = "950px";
    dialogConfig.height = "600px";
    dialogConfig.data = this.caseLinePopupData;   
    
    const dialogRef = this.dialog.open(PopLineAllLevelsComponent, dialogConfig);
    dialogRef.afterClosed().subscribe(result => {
       if (this.caseLinePopupData.selections != null && this.caseLinePopupData.selections.length > 0)
           this.patchValueDataRows(result, this.checkDuplicateRow(this.caseRows, result, 'line'));  
    });   
    

    //let result: any[] = [{custOrgId:'22', caseId:'22B17X', lineNumber:'2'}, 
    //                     {custOrgId:'66', caseId:'66B15Z', lineNumber:'2'}];
 
  }

 /*----------------------------
   PopupWin for Search WCN
  -----------------------------*/
  addWCNs() {

    this.wcnPopupData = new WcnAllLevelPopupData;
    this.wcnPopupData.selections = [];
    this.wcnPopupData.isMultiSelect = true;
    let docType: ISelectOptions = this.getSelectDocType();
    this.wcnPopupData.caseDocTypeSelections = [docType];
    if (this.programTypes != null)
        this.wcnPopupData.subProgramTypes = this.programTypes.value;
    this.wcnPopupData.selectionsUrl = "/autoBilling/wcnAllLevels/" + this.serviceId;

    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width  = "950px";
    dialogConfig.height = "600px";
    dialogConfig.data = this.wcnPopupData;
   
    const dialogRef = this.dialog.open(PopWcnAllLevelsComponent, dialogConfig);
    dialogRef.afterClosed().subscribe(result => {    
        if (this.wcnPopupData.selections != null && this.wcnPopupData.selections.length > 0)
            this.patchValueDataRows(result, this.checkDuplicateRow(this.caseRows, result, 'wcn'));  
    });

    //let result: any[] = [{custOrgId:'22', caseId:'22B17X', lineNumber:'2', wcn:'1001'}, 
    //                     {custOrgId:'88', caseId:'88B11D', lineNumber:'1', wcn:'1001'}];

  }

 /*----------------------------
   PopupWin for Search Suffix
  -----------------------------*/
  addSuffixes() {

     this.suffixPopupData = new SuffixAllLevelPopupData;
     this.suffixPopupData.selections = [];
     this.suffixPopupData.isMultiSelect = true;
     let docType: ISelectOptions = this.getSelectDocType();
     this.suffixPopupData.caseDocTypeSelections = [docType];
     if (this.programTypes != null)
         this.suffixPopupData.subProgramTypes = this.programTypes.value;
     this.suffixPopupData.selectionsUrl = "/autoBilling/ttlAllSuffixes";

     const dialogConfig = new MatDialogConfig();
     dialogConfig.disableClose = true;
     dialogConfig.autoFocus = true;
     dialogConfig.width  = "950px";
     dialogConfig.height = "600px";
     dialogConfig.data = this.suffixPopupData;   
    
     const dialogRef = this.dialog.open(PopSuffixAllLevelsComponent, dialogConfig);
     dialogRef.afterClosed().subscribe(result => {
        if (this.suffixPopupData.selections != null && this.suffixPopupData.selections.length > 0)
            this.patchValueDataRows(result, this.checkDuplicateRow(this.caseRows, result, 'suffix'));  
      });
     
    //let result: any[] = [{custOrgId:'88', caseId:'88B11D', lineNumber:'1', wcn:'1001', suffixCode:'C'},
    //                     {custOrgId:'2E', caseId:'2EB12P', lineNumber:'2', wcn:'2002', suffixCode:'A'}];
      
  }

 /*----------------------------
   PopupWin for Search EXA
  -----------------------------*/
  addExaTarRow() {

    this.tarPopupData = new TrainingActivityRolePopupData()
    this.tarPopupData.selections = [];
    this.tarPopupData.isMultiSelect = true;
    this.tarPopupData.role = "EXA";
    this.tarPopupData.programTypeSelections = [];
    this.tarPopupData.selectionsUrl = "/funding/newest/trainingActivityRoleData";
 
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = "1500px";
    dialogConfig.height = "700px";
    dialogConfig.data = this.tarPopupData;

    const dialogRef = this.dialog.open(PopTrainingActvityRoleComponent, dialogConfig);
    dialogRef.afterClosed().subscribe(result => {
      if (this.tarPopupData.selections != null && this.tarPopupData.selections.length > 0) 
          this.patchValueExaRows(result);
    });      
  }


  /*----------------------
    ActiveForm Submit
    ----------------------*/  
  postBilling(formValue: any) {
    this.billingRestService.postBilling(formValue)
    .subscribe(
      data  => {
         if (data) {
              this._snackBar.open("Auto reimbursement data has been saved successfully!", 'close',  {
              duration: this.durationInSeconds * 1000,
              panelClass: ['mat-toolbar', 'mat-primary']  
            });
         } else {
              this._snackBar.open("Auto reimbursement data saved failure!", 'close',  {
              duration: this.durationInSeconds * 1000,
              panelClass: ['mat-toolbar', 'mat-warn']     
            });
         }
         console.log("POST Request is successful ", data);
      },
      err  => {
        console.log("Error occured: postBilling()")
        this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, JSON.stringify(err.message))
      }
    );  
  }

  onSubmit() {
    if (this.autonewReimbCycleForm.invalid) 
        return;
    //console.log("Form Value: "+JSON.stringify(this.autonewReimbCycleForm.value)); 
    this.postBilling(this.autonewReimbCycleForm.value);
    if (this.autonewReimbCycleForm.get('rbnRunBy').value == 'exa'){
        this.ngOnInit();
        this.autonewReimbCycleForm.get('rbnRunBy').setValue("exa");
    } else {
        this.ngOnInit();
    }
  }


  /*----------------------
    Test Duplicate Data
    ----------------------*/ 
  patchValueDataInit() {
    const runByCaseRow0 = this.formBuilder.group({ 
      txtCountry:'22',txtCase:'',txtLine:'',txtWCN:'',txtSuffix:'',
    })
    this.caseRows.push(runByCaseRow0);
    const runByCaseRow1 = this.formBuilder.group({ 
      txtCountry:'44',txtCase:'44B17X',txtLine:'',txtWCN:'',txtSuffix:'',
    })
    this.caseRows.push(runByCaseRow1);
      const runByCaseRow2 = this.formBuilder.group({ 
      txtCountry:'66',txtCase:'66B15Z',txtLine:'002',txtWCN:'',txtSuffix:'',
    })
    this.caseRows.push(runByCaseRow2);
    const runByCaseRow3 = this.formBuilder.group({ 
      txtCountry:'88',txtCase:'88B11D', txtLine:'001',txtWCN:'1001',txtSuffix:'',
    })
    this.caseRows.push(runByCaseRow3);
    const runByCaseRow4 = this.formBuilder.group({ 
      txtCountry:'2E',txtCase:'2EB12P',txtLine: '002',txtWCN:'2002',txtSuffix:'A',
    })
    this.caseRows.push(runByCaseRow4);
  }  

  emptyFormArray(formArray: FormArray) {
    while (formArray.length !== 0) {
      formArray.removeAt(0)
    } 
  }

}