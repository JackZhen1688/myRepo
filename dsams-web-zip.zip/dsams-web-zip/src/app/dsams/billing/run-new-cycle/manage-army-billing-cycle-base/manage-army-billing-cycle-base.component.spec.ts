import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManageArmyBillingCycleBaseComponent } from './manage-army-billing-cycle-base.component';

describe('ManageArmyBillingCycleBaseComponent', () => {
  let component: ManageArmyBillingCycleBaseComponent;
  let fixture: ComponentFixture<ManageArmyBillingCycleBaseComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManageArmyBillingCycleBaseComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManageArmyBillingCycleBaseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
