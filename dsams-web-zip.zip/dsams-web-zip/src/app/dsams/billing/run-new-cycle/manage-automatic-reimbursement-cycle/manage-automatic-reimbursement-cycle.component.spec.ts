import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MangeAutomaticReimbursementCycleComponent } from './manage-automatic-reimbursement-cycle.component';

describe('MangeAutomaticReimbursementCycleComponent', () => {
  let component: MangeAutomaticReimbursementCycleComponent;
  let fixture: ComponentFixture<MangeAutomaticReimbursementCycleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MangeAutomaticReimbursementCycleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MangeAutomaticReimbursementCycleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
