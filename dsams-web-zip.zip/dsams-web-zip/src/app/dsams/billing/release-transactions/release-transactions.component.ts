import { Component, OnInit, Injector, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { MatSort } from '@angular/material/sort';
import { MatSnackBar } from '@angular/material/snack-bar';
import { SelectionModel } from '@angular/cdk/collections';
import { MatDialogConfig, MatDialog } from '@angular/material/dialog';
import { MatTableDataSource } from '@angular/material';
import { DsamsConstants } from './../../dsams.constants'
import { DsamsMethodsService } from './../../../dsams/services/dsams-methods.service';
import { BillingRestfulService } from './../services/billing-restful.service';
import { DsamsShareService } from '../../services/dsams-share.service';
import { DialogMessageYesnoComponent } from './../../utilitis/dialogs/dialog-message-yesno/dialog-message-yesno.component'

export interface PeriodicElement {
  cycleControlId: string;
  cycleApprovalDt: string;
  userName: string;
  dtimsStatusCd: string;
  relG: string;
  relD: string;
}

@Component({
  selector: 'app-release-transactions',
  templateUrl: './release-transactions.component.html',
  styleUrls: ['./release-transactions.component.css']
})
export class ReleaseTransactionsComponent implements OnInit {

  displayedColumns: string[] = ['cycleControlId','cycleApprovalDt','userName','dtimsStatusCd','select','selectD']; 
  dataSource = new MatTableDataSource<PeriodicElement>();
  selection = new SelectionModel<PeriodicElement>(true, []);
  selectionD = new SelectionModel<PeriodicElement>(true, []);
  recordCount: number=0;

  //@ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  @ViewChild(MatSort, {static: true}) sort: MatSort;

  durationInSeconds = 5;
  serviceId: string;
  releaseTransForm: FormGroup;
  
  selRowCycleControlIds: string[] = [];  
  selRowCycleControlIdsD: string[] = [];  

  dsamsShareService: DsamsShareService;
  dsamsMethodsService: DsamsMethodsService;
  constructor(private injector : Injector,
              private router: Router,
              private route: ActivatedRoute,
              public dialog: MatDialog,
              private _snackBar: MatSnackBar,
              private formBuilder: FormBuilder,
              private billingRestService: BillingRestfulService) { 
                this.dsamsShareService = injector.get<DsamsShareService>(DsamsShareService);
                this.dsamsMethodsService = injector.get<DsamsMethodsService>(DsamsMethodsService);
              }

  ngOnInit() {
    this.serviceId = sessionStorage.getItem('serviceDBid');
    this.dsamsShareService.csuname.next(this.route.snapshot.params['csu']);
    this.constructReleaseTransForm();
    this.getReleaseTransactions(encodeURIComponent("#"+sessionStorage.getItem('serviceDBid')));

    console.log("serviceId=="+this.serviceId)

    //this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
    this.sort.sort({ id: 'cycleControlId', start: 'asc', disableClear: false });
    
  }
  
  ngOnDestroy() {
    this.dsamsShareService.csuname.next(null);
  }

  constructReleaseTransForm() {
    this.releaseTransForm = this.formBuilder.group({
      txtCycleIds: this.formBuilder.control(''),
      txtCycleIdsD: this.formBuilder.control(''),
      serviceId: this.formBuilder.control(''),
    });
  }  

  getReleaseTransactions(filter: string) {
    this.billingRestService.getReleaseTransactions(filter)
    .subscribe(            
      data => { 
        this.dataSource.data = data; 
        this.recordCount = this.dataSource.filteredData.length;
      },
      err => {
        console.log("Error occured: getReleaseTransactions()")
      }
    );
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toUpperCase();
    //if (this.dataSource.paginator) {
    //    this.dataSource.paginator.firstPage();
    //}
  }  
  
  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return numSelected === numRows;
  }
  isAllSelectedD() {
    const numSelectedD = this.selectionD.selected.length;
    const numRowsD = this.dataSource.data.length;
    return numSelectedD === numRowsD;
  }

  masterToggle() {
    let values: string[] = [];
    this.selection.selected.length > 0 ?
    values = this.clearValues() :
    this.dataSource.data.forEach(row => {
        if (row.dtimsStatusCd === 'Sent to DTIM' && row.relG =='1') {
            this.selection.select(row)
            values.push(row.cycleControlId);
        }
      }
    );   
    this.selRowCycleControlIds = values;    
  } 
  masterToggleD() {
    let values: string[] = [];
    this.selectionD.selected.length > 0 ?
    values = this.clearValuesD() :
    this.dataSource.data.forEach(row => {
        if (row.relD === '1') {
            this.selectionD.select(row)
            values.push(row.cycleControlId);
        }
      }
    );   
    this.selRowCycleControlIdsD = values;
  }    

  clearValues () {
    this.selection.clear();
    return [];
  }
  clearValuesD () {
    this.selectionD.clear();
    return [];
  }

  checkboxLabel(row?: PeriodicElement): string {
    if (!row) {
      return `${this.isAllSelected() ? 'select' : 'deselect'} all`;
    }
    return `${this.selection.isSelected(row) ? 'deselect' : 'select'} row ${row.cycleControlId + 1}`;
  }
  checkboxLabelD(row?: PeriodicElement): string {
    if (!row) {
      return `${this.isAllSelectedD() ? 'select' : 'deselect'} all`;
    }
    return `${this.selectionD.isSelected(row) ? 'deselect' : 'select'} row ${row.cycleControlId + 1}`;
  }

  onCheckboxChange($event) {
    this.selRowCycleControlIds = this.getCheckedValues();
  }
  onCheckboxChangeD($event) {
    this.selRowCycleControlIdsD = this.getCheckedValuesD();
  }

  getCheckedValues() {
    let values: string[] = [];
    this.dataSource.data.forEach(row => { 
        if (this.selection.isSelected(row)) 
            values.push(row.cycleControlId);
      }
    )
    return values;
  }
  
  getCheckedValuesD() {
    let values: string[] = [];
    this.dataSource.data.forEach(row => { 
        if (this.selectionD.isSelected(row)) 
            values.push(row.cycleControlId);
      }
    )
    return values;
  }   
 
  saveReleaseTransanctions(formValue: any) {
     this.billingRestService.saveReleaseTransanctions(formValue)
     .subscribe(
       data  => {
          if (data) {
               this.ngOnInit();
               this.sort.sort({ id: 'cycleControlId', start: 'asc', disableClear: false });
               this._snackBar.open("Transaction released successfully!", 'close',  {
               duration: this.durationInSeconds * 1000,
               panelClass: ['mat-toolbar', 'mat-primary'] // 'mat-accent' or 'mat-warn'
             });
          } else {
               this._snackBar.open("Transaction released failure!", 'close',  {
               duration: this.durationInSeconds * 1000,
               panelClass: ['mat-toolbar', 'mat-warn'] // 'mat-accent' or 'mat-warn'
             });
          }
          console.log("saveReleaseTransanctions() is successful ", data);
       },
       err  => {
         console.log("Error occured: saveReleaseTransanctions()")
         this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, JSON.stringify(err.message))
       }
     );  
  }

  onReset(): void {
    this.releaseTransForm.reset();
    this.selection.clear();
    this.selectionD.clear();
    this.selRowCycleControlIds = [];
    this.selRowCycleControlIdsD = [];
  } 

  onClose() {
    let cycleIds: string[] = this.selRowCycleControlIds.concat(this.selRowCycleControlIdsD);
    if (cycleIds.length > 0) {
        const dialogConfig = new MatDialogConfig();
        dialogConfig.disableClose = true;
        dialogConfig.autoFocus = true;
        dialogConfig.width= DsamsConstants.diaWidth;
        dialogConfig.data = {message: DsamsConstants.EXIT_WITHOUT_SAVE, indecator: null};

        const dialogRef = this.dialog.open(DialogMessageYesnoComponent, dialogConfig);
        dialogRef.afterClosed().subscribe(result => {
          if (result == 1) 
              this.router.navigateByUrl('');
        });
    } else {
        this.router.navigateByUrl('');
    }
  }

  confirm() {
    let cycleIds: string[] = this.selRowCycleControlIds.concat(this.selRowCycleControlIdsD);
    if (cycleIds.length > 0) 
        return false;     //!this.releaseTransForm.dirty
     else 
        return true;
  }

  onSubmit() {
    let cycleIds: string[] = this.selRowCycleControlIds.concat(this.selRowCycleControlIdsD);
    if (cycleIds.length > 0) {
        //cycleIds = cycleIds.filter((value, index, array) => 
        //          !array.filter((v, i) => JSON.stringify(value) == JSON.stringify(v) && i < index).length);
        //console.log("cycleIds==="+cycleIds);
        this.releaseTransForm.get("txtCycleIds").setValue(this.selRowCycleControlIds);
        this.releaseTransForm.get("txtCycleIdsD").setValue(this.selRowCycleControlIdsD);
        this.releaseTransForm.get("serviceId").setValue(this.serviceId);
        this.saveReleaseTransanctions(this.releaseTransForm.value);
        this.onReset();
    } else {
        this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, DsamsConstants.ROW_MUST_SELECTED)
    }    
  }

}
