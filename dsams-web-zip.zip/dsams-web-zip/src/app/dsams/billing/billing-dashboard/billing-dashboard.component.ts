import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from "@angular/router";
import { FormGroup, FormBuilder, FormArray, FormControl } from "@angular/forms";
import { MatTableDataSource } from '@angular/material/table';
import { MatSnackBar } from '@angular/material/snack-bar';
import { DsamsConstants } from './../../dsams.constants';
import { DsamsRestfulService } from './../../../dsams/services/dsams-restful.service';
import { BillingRestfulService } from './../services/billing-restful.service';
import { DsamsMethodsService } from './../../services/dsams-methods.service';
import { DsamsShareService } from './../../services/dsams-share.service'
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-billing-dashboard',
  templateUrl: './billing-dashboard.component.html',
  styleUrls: ['./billing-dashboard.component.css',
              './../billing-global.css'
              ],
})
export class BillingDashboardComponent implements OnInit {

  private _serviceDbId: string;
 
  csuCds: string[] = ['WP101','WP102','WP103','WP104','WP105','WP118'];
  disableCsuWP101: boolean = true;
  disableCsuWP102: boolean = true;
  disableCsuWP103: boolean = true;
  disableCsuWP104: boolean = true;
  disableCsuWP105: boolean = true;
  disableCsuWP118: boolean = true;
  cognosUrl: string;
  reportUrl: string;
  jsonReport: any;
  reportUrlMap = new Map<string, string>();
  dashboardForm: FormGroup;

  constructor(private router: Router, 
              private route: ActivatedRoute, 
              private _snackBar: MatSnackBar,
              private formBuilder: FormBuilder, 
              private dsamsShareService: DsamsShareService,
              private dsamsReferenceService: DsamsRestfulService,
              public dsamsMethodsService: DsamsMethodsService,
              private billingRestService: BillingRestfulService) { }

  ngOnInit() {
    this.dsamsShareService.csuname.next('WP100');
    // Setting the service attribute value so proper filter can be added based on where Notification component is called from.
    this.dsamsShareService.notificationCalledFrom = "Billing";

    this._serviceDbId = sessionStorage.getItem('serviceDBid');
    // console.log("sessionStorage Service DB Id =="+sessionStorage.getItem('serviceDBid'));

    this.csuCds.forEach(csu_cd => {
      this.getPageAttrAccess(csu_cd);
    });
 
    if (this._serviceDbId == null){
      // NOTE: Delete this code.
      // As of now forcing it to Army for  time being b/c a popup where user selects ServiceDbId is not being displayed
      // because of 'CORS policy error' (see below). If popup works, I don't think following code will be executed
      // but remains to be tested when popup shows up.
      // Access to XMLHttpRequest at 'https://dsams-sandbox.dev.dsca.mil/dsams-service/getUserInfo' from origin 'http://localhost:4200' has been blocked by CORS policy: No 'Access-Control-Allow-Origin' header is present on the requested resource.
      this._serviceDbId = 'A';      
      console.log("You MUST select a ServiceDBId ... setting it to Army: "+ this._serviceDbId);
    }

    this.constructDashboardForm();
    //this.initializeDashboardForm();

    this.getManageBillingCycles(this._serviceDbId);
    this.getCycleReports();
    this.getRunSavedJobs();
    //Added for RP290/RP290v1
    /*
    console.log("Enviornment: "+environment.envName.toUpperCase());
    if (environment.envName.toUpperCase() === 'UAT' || environment.envName.toUpperCase() === 'QA' || environment.envName.toUpperCase() === 'PROD')
        this.cognosUrl = "https://c10web.csd.disa.mil/ibmcognos";
    else 
        this.cognosUrl = "https://c10web.dev.dsadc.mil/ibmcognos";
    
    console.log("cognosUrl: "+this.cognosUrl);    
    */
    this.cognosUrl = "https://dsamsreports.dsca.mil/ibmcognos";
    
  }
  
  ngOnDestroy() {
    this.dsamsShareService.csuname.next(null);
  }
  
  //====== Form Construction ======//
  constructDashboardForm() {
    this.dashboardForm = this.formBuilder.group({
     'jobname': this.formBuilder.control(''),
     'selectedjobs': new FormArray([]),
    //  'selectedNotes': new FormArray([]),
     });
  }
  initializeDashboardForm() {
    this.dashboardForm.patchValue({
     //'jobname': false
    }); 
  }

  checkAccessLink(rowElement): boolean {
    let disableCsuLink: boolean = true;
    if ((rowElement.cycle_CONTROL_TYPE_ID == '20') || (rowElement.cycle_CONTROL_TYPE_ID == '21') || (rowElement.cycle_CONTROL_TYPE_ID == '22')) {  
         disableCsuLink = this.disableCsuWP102;
    } else if ((rowElement.cycle_CONTROL_TYPE_ID == '30') || (rowElement.cycle_CONTROL_TYPE_ID == '32')) {
         disableCsuLink = this.disableCsuWP103;
    } else if ((rowElement.cycle_CONTROL_TYPE_ID == '56') || (rowElement.cycle_CONTROL_TYPE_ID == '57')) {
         disableCsuLink = this.disableCsuWP105;
    } else if ((rowElement.cycle_CONTROL_TYPE_ID == '58') || (rowElement.cycle_CONTROL_TYPE_ID == '59')) {
         disableCsuLink = this.disableCsuWP104;
    } else if (rowElement.cycle_CONTROL_TYPE_ID == '64') {
         disableCsuLink = this.disableCsuWP118;
    }
    return disableCsuLink;
  }
  
  getPageAttrAccess(csu_cd: string) {
    this.dsamsReferenceService.getPageAttrAccess(csu_cd)
    .subscribe(
      data => { 
        //console.log(csu_cd+"==>PageAttries Access==="+data);
        if (data == 1) 
            this["disableCsu"+csu_cd] = false;
        else 
            this["disableCsu"+csu_cd] = true;

        //console.log("disableCsu"+csu_cd+"===>"+this["disableCsu"+csu_cd])
      },
      err => {
        console.log("Error occured: getPageAttrAccess()", err)
      }
    );   
  }

  //====== Manage Billing Cyclys ======//
  //#1. Define variables
  displayedColumnCycles: string[] = ['cycleid','type', 'title', 'userid','details','reports'];
  dataSourceCycles = new MatTableDataSource();
  
  //-- WP100-FR1
  openProperWebPage(rowElement){
    if ((rowElement.cycle_CONTROL_TYPE_ID == '20') ||
        (rowElement.cycle_CONTROL_TYPE_ID == '21') ||
        (rowElement.cycle_CONTROL_TYPE_ID == '22')) {  
          // open WP101
          this.router.navigate(['/billing/mangeautomatic', rowElement.cycle_CONTROL_ID, 'WP102']);
    }
    else if ((rowElement.cycle_CONTROL_TYPE_ID == '30') || 
     // include manual billing cycle adjustment cycles  08/03/20202 DB
    (rowElement.cycle_CONTROL_TYPE_ID == '32')) {
      // open WP103
      this.router.navigate(['/billing/runnewcycle/mangemanual', rowElement.cycle_CONTROL_ID, 'WP103']);
    }
    else if ((rowElement.cycle_CONTROL_TYPE_ID == '56') ||
      (rowElement.cycle_CONTROL_TYPE_ID == '57')) {
        // open WP103
        this.router.navigate(['/billing/gfebssuffix', rowElement.cycle_CONTROL_ID, 'WP105']);
    }
    else if ((rowElement.cycle_CONTROL_TYPE_ID == '58') ||
      (rowElement.cycle_CONTROL_TYPE_ID == '59')) {
        // open WP104
        this.router.navigate(['/billing/gfebstla', rowElement.cycle_CONTROL_ID, 'WP104']);
    }
    else if (rowElement.cycle_CONTROL_TYPE_ID == '64') {
      // open WP118
      this.router.navigate(['/billing/ManualObligationDisbursements', rowElement.cycle_CONTROL_ID, 'WP118']);
    }
    // console.log("indexOfRowElement: ", this.dataSourceCycles.data.indexOf(rowElement));   
    // console.log("RowElement-cycle_CONTROL_TYPE_ID ", rowElement.cycle_CONTROL_TYPE_ID);    
  }

  //-- WP100-FR3, FR4, FR5, FR6  
  /* Note:
   *  This business rule has not tested yet b/c Cognos reports are not working in cloud as of now.
   */
  openReport(event: any, selReport:any, cycle:number){
    if (event.isUserInput) {
      let selectedReportUrl : string;
      if (selReport.reportName == 'RP290') {
        console.log("RP290 report selected for Cycle#: " + cycle);
        selectedReportUrl = this.reportUrlMap.get(selReport.reportName).replace("pCycleId", String(cycle)).replace("pSortBy", "C");
      } else if (selReport.reportName == 'RP290V1'){                             
        console.log("RP290V1 report selected for Cycle#: " + cycle);
        selectedReportUrl = this.reportUrlMap.get(selReport.reportName).replace("pCycleId", String(cycle));
      } else {
        console.log("Not a valid report selected");
      }

      window.open(this.cognosUrl + selectedReportUrl, '_blank');
    }
  }
 
  //#2. Get data using Rest API (NOT dsams-legacy)t
  getManageBillingCycles(_serviceDbId) {    
    this.billingRestService.getManageBillingCycles(this._serviceDbId)
    .subscribe(
      data => { 
        // console.log("Data in JSON file from DB: ",data);
        this.dataSourceCycles.data = data;  
      },
      err => {
        console.log("Error occured: getManageBillingCycles()")
      }
    );
  }

  //#3. Filter
  applyFilterCycles(filterValue: string) {
    this.dataSourceCycles.filter = filterValue.trim().toLowerCase();
  }  

  //#4 Report Selections
  reports: string[];
  getCycleReports() {
    this.billingRestService.getCycleReports()
    .subscribe(
      data => { 
        this.reports = data;
        this.jsonReport = data;
        this.loadReportUrlMap();
      },
      err => {
        console.log("Error occured: getCycleReports()")
      }
    );
  }

  loadReportUrlMap() {
    let filter : string;
    for (const report of this.jsonReport) {
      filter = encodeURIComponent(report.reportName + "#" + sessionStorage.getItem('serviceDBid'));
      this.dsamsReferenceService.getReportUrl(filter)
      .subscribe(   
        data => {
          if (data) {
            this.reportUrlMap.set(report.reportName, data);
          } 
        },
        err => {
          console.log("Error occured: getReportUrl()", err);
        }
      );
      }
  }


  //====== Run Saved Jobs ======//
  displayedColumnJobs: string[] = ['jobname','userid','caseusage','select'];
  dataSourceJobs = new MatTableDataSource();

  getRunSavedJobs() {
    this.billingRestService.getRunSavedJobs(this._serviceDbId)
    .subscribe(
      data => { 
        this.dataSourceJobs.data = data;   
       },
      err => {
        console.log("Error occured: getRunSavedJobs")
      }
    );
  }

  runSaveJob(element:any) {
    
    this.billingRestService.runSaveJob(this._serviceDbId, element.id)
    .subscribe(
      data  => {
          this._snackBar.open("Job has been run.", 'close',  {
              duration: 5000,
              panelClass: ['mat-toolbar', 'mat-primary'] // 'mat-accent' or 'mat-warn'
          });
      },
      err  => {
        console.log("Error occured: runSaveJob()")
        this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, JSON.stringify(err.message))
      }
    );  
  }

  applyFilterJobs(filterValue: string) {
    this.dataSourceJobs.filter = filterValue.trim().toLowerCase();
  }  

  getSelectedJobs(event, id) {
    this.getCheckedItems(event, id, 'selectedjobs');
  }
  onRunSelectJobs() {
    console.log("Selected Job Names=="+this.dashboardForm.get("selectedjobs").value)
  }

  //====== Notifications ======//
  // displayedColumnNotis: string[] = ['notificationDate','notificationType','notificationView','DeleteRow'];
  
  // dataSourceNotis = new MatTableDataSource();
  
  
  // getNotifications() {
  //   this.billingRestService.getNotifications()
  //   .subscribe(
  //     data => { 
  //       this.dataSourceNotis.data = data;   
  //     },
  //     err => {
  //       console.log("Error occured: getNotifications()")
  //     }
  //   );
  // }
  
  // applyFilterNotis(filterValue: string) {
  //   this.dataSourceNotis.filter = filterValue.trim().toLowerCase();
  // }  

  
  // getSelectedNotes(event, id) {
  //   this.getCheckedItems(event, id, 'selectedNotes');
  // }
  // onDeleteNotifications() {
  //   console.log("Selected Notifications=="+this.dashboardForm.get("selectedNotes").value)
  // }

  // deleteNotificationRow(rowIndex: any) { 
  //   console.log("rowIndex = ", rowIndex);  
  //   this.dataSourceNotis.data.splice(rowIndex, 1);    
  //   this.dataSourceNotis = new MatTableDataSource(this.dataSourceNotis.data);
  // }
 


  //-- Function getCheckedItems() --//
  getCheckedItems(event, id, formaryname){
    const formArray: FormArray = this.dashboardForm.get(formaryname) as FormArray;
    if(event.checked){
       formArray.push(new FormControl(id));
    } else {
       let i: number = 0;
       formArray.controls.forEach((ctrl: FormControl) => {
          if(ctrl.value == id) {
            formArray.removeAt(i);
            return;
          }
        i++;
      });
    }
  }

  public barChartOptions = {
    scaleShowVerticalLines: false,
    responsive: true
  };  public barChartLabels = ['2006', '2007', '2008', '2009', '2010', '2011', '2012'];
  public barChartType = 'bar';
  public barChartLegend = true;  public barChartData = [
    {data: [65, 59, 80, 81, 56, 55, 40], label: 'Series A'},
    {data: [28, 48, 40, 19, 86, 27, 90], label: 'Series B'}
  ];

}
