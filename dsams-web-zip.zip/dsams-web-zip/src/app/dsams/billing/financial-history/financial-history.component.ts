import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from "@angular/router";
import { MatTableDataSource } from '@angular/material/table';
import { FormBuilder, FormGroup } from '@angular/forms';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { DsamsConstants } from './../../dsams.constants';
import { CurrencyPipe } from '@angular/common';
import { DsamsMethodsService } from './../../../dsams/services/dsams-methods.service';
import { DsamsShareService } from '../../services/dsams-share.service';
import { BillingRestfulService } from './../services/billing-restful.service';
import { DiaModalFmsCaseComponent } from './../../utilitis/dialogs/dia-modal-fms-case/dia-modal-fms-case.component';
import { DiaModalLineComponent } from './../../utilitis/dialogs/dia-modal-line/dia-modal-line.component'
import { DiaModalWcnComponent } from './../../utilitis/dialogs/dia-modal-wcn/dia-modal-wcn.component'
import { DiaModalSuffixComponent } from './../../utilitis/dialogs/dia-modal-suffix/dia-modal-suffix.component'
import { DiaModalTlaSuffixComponent } from './../../utilitis/dialogs/dia-modal-tla-suffix/dia-modal-tla-suffix.component'
import { ISelectOptions } from 'src/app/dsams/interfaces/i-select-options';
import { MatDialog, MatDialogConfig} from '@angular/material/dialog';
import { PopSuffixAllLevelsComponent,  SuffixAllLevelPopupData } from './../../utilitis/popups/pop-suffix-all-levels/pop-suffix-all-levels.component';
import { PopTttsAllLevelsComponent, TttsAllLevelPopupData } from './../../utilitis/popups/pop-ttts-all-levels/pop-ttts-all-levels.component';


@Component({
  selector: 'app-financial-history',
  templateUrl: './financial-history.component.html',
  styleUrls: ['./financial-history.component.css'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({height: '0px', minHeight: '0'})),
      state('expanded', style({height: '*'})),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})
export class FinancialHistoryComponent implements OnInit {

  serviceId: string;

  displayCaseMegs: boolean = false;
  displayLineMegs: boolean = false;
  searchLine: boolean = false;
  spinnerDisplay: boolean = false;
  color = "primary";
  mode  = "indeterminate";
  diameter = 60;
  value = 50;

  caseId: number;
  caseMasterLineId: number;
  traningTrackSeqCd: number; 

  financialHistoryForm: FormGroup;

  dsFinancialHistory = new MatTableDataSource();
  displayedColumns: string[] = ['createDt','cycleControlId','cct','statusCd','currentBudgetStatusTypeId','documentNumberCd','fcvDocumentVersionCd','courseAmount','tlaAmount','transactionAmount','runningFundingAmout','runningBillingAmount','img'];
  expandedElement: null;
  displaySubcolumns = ['fiscalYearId','account','amount','blockNumberCd','dovNumber','billNumber','dtimsStatusCd'];  

  tlaFlag: boolean;
  suffixPopupData : SuffixAllLevelPopupData;
  tttsPopupData: TttsAllLevelPopupData;

  constructor(private route: ActivatedRoute,
              private formBuilder: FormBuilder,
              public dialog: MatDialog,
              private currencyPipe : CurrencyPipe,
              public dsamsMethodsService: DsamsMethodsService,
              private dsamsShareService: DsamsShareService,
              private billingRestService: BillingRestfulService) { }

  ngOnInit() {
    this.dsamsShareService.csuname.next(this.route.snapshot.params['csu']);
    this.constructFinancialHistoryForm();
    /*
    this.financialHistoryForm.get("txtFStatus").disable();
    */
    this.serviceId = sessionStorage.getItem('serviceDBid');
    console.log("Financal Service Id=="+sessionStorage.getItem('serviceDBid'))
   
  }
  
  ngOnDestroy() {
    this.dsamsShareService.csuname.next(null);
  }

  constructFinancialHistoryForm() {
    this.financialHistoryForm = this.formBuilder.group({
     'txtCase': this.formBuilder.control(''),
     'txtLine': this.formBuilder.control(''),
     'txtWCN': this.formBuilder.control(''),
     'txtSuffix': this.formBuilder.control(''),
     'txtTlaCase': this.formBuilder.control(''),
     'txtTlaLine': this.formBuilder.control(''),
     'txtTlaWCN': this.formBuilder.control(''),
     'txtTlaSuffix': this.formBuilder.control(''),
     'txtFStatus':this.formBuilder.control(''),
     'txtFundedAm':this.formBuilder.control(''),
     'txtReimbAm':this.formBuilder.control(''),
     'txtDifference':this.formBuilder.control(''),
     'chkFinalBilled':this.formBuilder.control(''),
     'chkFundingAction':this.formBuilder.control(''),
     'chkBillingAction':this.formBuilder.control(''),
     });
  }
  
  get txtCase() {
    return this.financialHistoryForm.get('txtCase');
  } 
  get txtLine() {
    return this.financialHistoryForm.get('txtLine');
  } 
  get txtWCN() {
    return this.financialHistoryForm.get('txtWCN');
  } 

  patchSearchFields(data: any[]) {
    this.financialHistoryForm.patchValue({
      'txtCase': data[0].caseId,
      'txtLine': this.dsamsMethodsService.padZeroLeft(data[0].lineNumber, '0', 3),
      'txtWCN': data[0].wcn,
      'txtSuffix': data[0].suffixCode,
   }); 
  }

  patchTlaSearchFields(data: any[]) {
    this.financialHistoryForm.patchValue({
      'txtTlaCase': data[0].caseId,
      'txtTlaLine': this.dsamsMethodsService.padZeroLeft(data[0].lineNumber, '0', 3),
      'txtTlaWCN': data[0].wcn,
      'txtTlaSuffix': data[0].suffixCode,
   }); 
  }

  getFinancialHistory(filter: string) {
    this.billingRestService.getFinancialHistory(filter)
    .subscribe(
      data => { 
        this.dsFinancialHistory.data = data.historyMainList;  
        this.financialHistoryForm.patchValue({
           'txtFStatus': data.tlFinancialStatusTypeId,
           'txtFundedAm': data.fundedAm==null?"":this.currencyPipe.transform(data.fundedAm, '$'),
           'txtReimbAm': data.reimbursementAm==null?"":this.currencyPipe.transform(data.reimbursementAm, '$'),
           'txtDifference': data.difference==null?"":this.currencyPipe.transform(data.difference, '$'),
           'chkFinalBilled': data.finalBilled,
           'chkFundingAction': data.fundingAction,
           'chkBillingAction': data.billingAction,
        });
        //console.log("data=="+JSON.stringify(data))
        this.spinnerDisplay = false;
      },
      err => {
        console.log("Error occured: getFinancialHistory()")
      }
    );
  }


  applyFilter(filterValue: string) {
    this.dsFinancialHistory.filter = filterValue.trim().toLowerCase();
  }  

  onFilter() {
    this.spinnerDisplay = true;
    let caseId: string;
    let lineNum: string;
    let wcn: string;
    let suffix: string;
    let tlaSuffix: string;

    if (this.tlaFlag) {
        caseId    = this.financialHistoryForm.get("txtTlaCase").value ==''?"":this.financialHistoryForm.get("txtTlaCase").value;
        lineNum   = this.financialHistoryForm.get("txtTlaLine").value ==''?"@":"@"+this.financialHistoryForm.get("txtTlaLine").value;
        wcn       = this.financialHistoryForm.get("txtTlaWCN").value  ==''?"@":"@"+this.financialHistoryForm.get("txtTlaWCN").value;
        suffix    = this.financialHistoryForm.get("txtSuffix").value ==''?"@":"@"+this.financialHistoryForm.get("txtSuffix").value;
        tlaSuffix = this.financialHistoryForm.get("txtTlaSuffix").value==''?"@":"@"+this.financialHistoryForm.get("txtTlaSuffix").value;
    } else {
        caseId    = this.financialHistoryForm.get("txtCase").value ==''?"":this.financialHistoryForm.get("txtCase").value;
        lineNum   = this.financialHistoryForm.get("txtLine").value ==''?"@":"@"+this.financialHistoryForm.get("txtLine").value;
        wcn       = this.financialHistoryForm.get("txtWCN").value  ==''?"@":"@"+this.financialHistoryForm.get("txtWCN").value;
        suffix    = this.financialHistoryForm.get("txtSuffix").value ==''?"@":"@"+this.financialHistoryForm.get("txtSuffix").value;
        tlaSuffix = this.financialHistoryForm.get("txtTlaSuffix").value==''?"@":"@"+this.financialHistoryForm.get("txtTlaSuffix").value;
    }
    var filter = caseId + lineNum + wcn + suffix + tlaSuffix;

    if (this.serviceId !='')
        filter=filter+"#"+this.serviceId;

    //console.log("filter==="+filter+" encoded=="+encodeURIComponent(filter));
    
    this.getFinancialHistory(encodeURIComponent(filter));
  }
  
  revert() {
    this.financialHistoryForm.reset();
    this.dsFinancialHistory.data = null;
  }

  onBlurCase(event: any) {
    if (event.target.value.length == 8){
        let userCaseId = event.target.value.replace(/-/gi,"");
        if (this.serviceId !='') {
            userCaseId = event.target.value.replace(/-/gi,"")+"#"+this.serviceId;
            this.billingRestService.getCaseId(encodeURIComponent(userCaseId))
            .subscribe(
                data => { 
                  this.caseId = data;
                  if (data == 0) {
                      this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, DsamsConstants.CASE_NOT_EXIST)
                      this.financialHistoryForm.get('txtCase').setValue("");
                  }    
                },
                err => {
                  console.log("Error occured: getCaseId() onBlur")
                  this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, JSON.stringify(err.message))
                }
            );
        }
    }
  }

  onBlurLine(event: any) {
    if (this.financialHistoryForm.get('txtCase').value === "" && this.financialHistoryForm.get('txtLine').value != "") {
        this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, DsamsConstants.CASE_MUST_SELECT)
        this.financialHistoryForm.get('txtLine').setValue("");
    } else {
        if (this.financialHistoryForm.get('txtLine').value != "") {
            let strLine:string = this.dsamsMethodsService.padZeroLeft(event.target.value, '0', 3);  //Number format
            this.financialHistoryForm.get('txtLine').setValue(strLine);
            let line = event.target.value;
            if (this.serviceId !='') {
                line = event.target.value+"#"+this.serviceId;
                this.billingRestService.getCaseMasterLineId(this.caseId, encodeURIComponent(line))
                .subscribe(
                  data => { 
                    this.caseMasterLineId = data;
                    if (data == 0) {
                        this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, DsamsConstants.LINE_NOT_EXIST)
                        this.financialHistoryForm.get('txtLine').setValue(""); 
                    }
                  },
                  err => {
                    console.log("Error occured: getCaseMasterLineId()")
                    this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, JSON.stringify(err.message))
                  }
                );
            }
        }
    }
  }

  onBlurWCN(event: any) {
    if ((this.financialHistoryForm.get('txtCase').value ==="" || this.financialHistoryForm.get('txtLine').value ==="") && 
         this.financialHistoryForm.get('txtWCN').value !="") {
        this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, DsamsConstants.CASE_LINE_MUST_SELECT);
        this.financialHistoryForm.get('txtWCN').setValue("");
    } else {
        if (event.target.value.length == 4){
            let wcn = event.target.value;
            if (this.serviceId !='') {
                wcn = event.target.value+"#"+this.serviceId;
                this.billingRestService.getTrainingTrackSeqCd(this.caseId, this.caseMasterLineId, encodeURIComponent(wcn))
                .subscribe(
                  data => { 
                    this.traningTrackSeqCd = data;
                    if (data == 0) {
                        this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, DsamsConstants.WCN_NOT_EXIST)
                        this.financialHistoryForm.get('txtWCN').setValue("");
                    }
                  },
                  err => {
                    console.log("Error occured: getTrainingTrackSeqCd()")
                    this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, JSON.stringify(err.message))
                  }
                );
            }
        } 
    }
  }  

  onBlurSuffix(event: any) {
    if ((this.financialHistoryForm.get('txtCase').value ==="" || this.financialHistoryForm.get('txtLine').value ==="" ||
        this.financialHistoryForm.get('txtWCN').value ==="") && this.financialHistoryForm.get("txtSuffix").value !="")
        this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, DsamsConstants.CASE_LINE_WCN_MUST_SELECT)
    else {
        if (event.target.value.length == 1) {
            this.financialHistoryForm.get("txtTlaSuffix").setValue("");
            let suffix = event.target.value;
            if (this.serviceId !='') {
                suffix = event.target.value+"#"+this.serviceId;
                this.billingRestService.getTrainingTrackLineSeqCd(this.caseId, this.caseMasterLineId, this.traningTrackSeqCd, encodeURIComponent(suffix))
                .subscribe(
                  data => { 
                    if (data == 0) {
                        this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, DsamsConstants.SUFFIX_NOT_EXIST)
                        this.financialHistoryForm.get('txtSuffix').setValue("");
                    }
                  },
                  err => {
                    console.log("Error occured: getTrainingTrackLineSeqCd()")
                    this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, JSON.stringify(err.message))
                  }
                );
            }    
        }
    }
  }  

  onBlurTlaSuffix(event: any): void {
      if ((this.financialHistoryForm.get('txtCase').value ==="" || this.financialHistoryForm.get('txtLine').value ==="" ||
          this.financialHistoryForm.get('txtWCN').value ==="") && this.financialHistoryForm.get('txtTlaSuffix').value !="") {
          this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, DsamsConstants.CASE_LINE_WCN_MUST_SELECT)
          this.financialHistoryForm.get('txtTlaSuffix').setValue("");
      } else {
          if (event.target.value.length == 1){
            let tsuffix = event.target.value;
            if (this.serviceId !='') {
                tsuffix = event.target.value+"#"+this.serviceId;
                this.billingRestService.getExternalFinancialCd(this.caseId, this.caseMasterLineId, this.traningTrackSeqCd, encodeURIComponent(tsuffix))
               .subscribe(
                data => { 
                  if (data == 0) {
                      this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, DsamsConstants.TLA_SUFFIX_NOT_EXIST)
                      this.financialHistoryForm.get('txtTlaSuffix').setValue("");
                  } else {
                      this.financialHistoryForm.get('txtSuffix').setValue("");
                  }
                },
                err => {
                  console.log("Error occured: getExternalFinancialCd()")
                  this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, JSON.stringify(err.message))
                }
              );
            }
          }
      }
  }

  onBlurTtts(event: any): void {
      // TODO: Put something here.
  }


  dialogSearchCase(elementName:string): void 
  {
      let diaWidth:string    = "750px";
      let diaHeight:string   = "650px";
      let passingData:string = "";
      this.dsamsMethodsService.openSearchDialog(diaWidth, diaHeight, passingData, DiaModalFmsCaseComponent, this.financialHistoryForm, elementName);
  }

  dialogSearchLine(elementName:string): void 
  {
    if (this.financialHistoryForm.get('txtCase').value ==="") {
        this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, DsamsConstants.CASE_MUST_SELECT)
    } else {
        if (this.caseId === undefined) {
            let line = this.financialHistoryForm.get('txtCase').value;
            if (this.serviceId !='')
                line = this.financialHistoryForm.get('txtCase').value+"#"+this.serviceId;
            this.billingRestService.getCaseId(encodeURIComponent(line))    
            .subscribe(
              data => { 
                this.caseId = data;
                if (data == 0) 
                    this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, DsamsConstants.CASE_NOT_EXIST)
                else {
                    let diaWidth:string    = "400px";
                    let diaHeight:string   = "500px";
                    let passingData:number = this.caseId;
                    this.dsamsMethodsService.openSearchDialog(diaWidth, diaHeight, passingData, DiaModalLineComponent, this.financialHistoryForm, elementName);
                }    
              },
              err => {
                  console.log("Error occured: dialogSearchLine()->getCaseId()")
                  this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, JSON.stringify(err.message))
                }
            );
        } else {
            let diaWidth:string    = "400px";
            let diaHeight:string   = "500px";
            let passingData:number = this.caseId;
            this.dsamsMethodsService.openSearchDialog(diaWidth, diaHeight, passingData, DiaModalLineComponent, this.financialHistoryForm, elementName);
        }
    }
  }  

  dialogSearchWcn(elementName:string): void 
  {
    if (this.financialHistoryForm.get('txtCase').value ==="" && this.financialHistoryForm.get('txtLine').value ==="")
        this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, DsamsConstants.CASE_LINE_MUST_SELECT)
    else if (this.financialHistoryForm.get('txtCase').value ==="")
        this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, DsamsConstants.CASE_MUST_SELECT)
    else if (this.financialHistoryForm.get('txtLine').value ==="")
        this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, DsamsConstants.LINE_MUST_SELECT)
    else {
         let wcn = this.financialHistoryForm.get('txtLine').value;
         if (this.serviceId !='')
             wcn = this.financialHistoryForm.get('txtLine').value+"#"+this.serviceId;
        this.billingRestService.getCaseMasterLineId(this.caseId, encodeURIComponent(wcn))
        .subscribe(
          data => { 
            this.caseMasterLineId = data;
            if (data == 0) 
                this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, DsamsConstants.LINE_NOT_EXIST)
            else {
                let diaWidth:string  = "400px";
                let diaHeight:string = "500px";
                let passingData:any  = this.caseId+"@"+this.caseMasterLineId;
                this.dsamsMethodsService.openSearchDialog(diaWidth, diaHeight, passingData, DiaModalWcnComponent, this.financialHistoryForm, elementName);
            }
          },
          err => {
            console.log("Error occured: dialogSearchWcn():getCaseMasterLineId()")
            this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, JSON.stringify(err.message))
          }
        );
    }
  }  

  dialogSearchSuffix(elementName:string): void 
  {
    if (this.financialHistoryForm.get('txtCase').value ==="" && this.financialHistoryForm.get('txtLine').value ==="" &&
        this.financialHistoryForm.get('txtWCN').value ==="")
        this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, DsamsConstants.CASE_LINE_WCN_MUST_SELECT)
    else if (this.financialHistoryForm.get('txtCase').value ==="")
        this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, DsamsConstants.CASE_MUST_SELECT)
    else if (this.financialHistoryForm.get('txtLine').value ==="")
        this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, DsamsConstants.LINE_MUST_SELECT)
    else if (this.financialHistoryForm.get('txtWCN').value ==="")
        this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, DsamsConstants.WCN_MUST_SELECT)
    else {
        let suffix = this.financialHistoryForm.get('txtWCN').value;
        if (this.serviceId !='')
            suffix = this.financialHistoryForm.get('txtWCN').value+"#"+this.serviceId;
        this.billingRestService.getTrainingTrackSeqCd(this.caseId, this.caseMasterLineId, encodeURIComponent(suffix))
        .subscribe(
          data => { 
            this.traningTrackSeqCd = data;
            if (data == 0) 
                this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, DsamsConstants.WCN_NOT_EXIST)
            else {
                let diaWidth:string    = "500px";
                let diaHeight:string   = "500px";
                let passingData: any   = this.caseId+"@"+this.caseMasterLineId+"@"+this.traningTrackSeqCd;
                this.financialHistoryForm.get("txtTlaSuffix").setValue("");
                this.dsamsMethodsService.openSearchDialog(diaWidth, diaHeight, passingData, DiaModalSuffixComponent, this.financialHistoryForm, elementName);
            }
          },
          err => {
            console.log("Error occured: dialogSearchSuffix():getCaseMasterLineId()")
            this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, JSON.stringify(err.message))
          }
        );
    }
  }    

  dialogSearchTlaSuffix(elementName:string): void 
  {
    if (this.financialHistoryForm.get('txtCase').value ==="" && this.financialHistoryForm.get('txtLine').value ==="" &&
        this.financialHistoryForm.get('txtWCN').value ==="")
        this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, DsamsConstants.CASE_LINE_WCN_MUST_SELECT)
    else if (this.financialHistoryForm.get('txtCase').value ==="")
        this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, DsamsConstants.CASE_MUST_SELECT)
    else if (this.financialHistoryForm.get('txtLine').value ==="")
        this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, DsamsConstants.LINE_MUST_SELECT)
    else if (this.financialHistoryForm.get('txtWCN').value ==="")
        this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, DsamsConstants.WCN_MUST_SELECT)
    else {
        let tsuffix = this.financialHistoryForm.get('txtWCN').value;
        if (this.serviceId !='')
            tsuffix = this.financialHistoryForm.get('txtWCN').value+"#"+this.serviceId;  
        this.billingRestService.getTrainingTrackSeqCd(this.caseId, this.caseMasterLineId, encodeURIComponent(tsuffix))
        .subscribe(
          data => { 
            this.traningTrackSeqCd = data;
            if (data == 0) 
                this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, DsamsConstants.TLA_SUFFIX_NOT_EXIST)
            else {
                let diaWidth:string    = "500px";
                let diaHeight:string   = "500px";
                let passingData: any   = this.caseId+"@"+this.caseMasterLineId+"@"+this.traningTrackSeqCd;
                this.dsamsMethodsService.openSearchDialog(diaWidth, diaHeight, passingData, DiaModalTlaSuffixComponent, this.financialHistoryForm, elementName);
            }    
          },
          err => {
            console.log("Error occured: dialogSearchSuffix():getCaseMasterLineId()")
            this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, JSON.stringify(err.message))
          }
        );
    }
  }   

  popupTtts() {

    this.tlaFlag = true;
    this.revert();

    this.tttsPopupData = new TttsAllLevelPopupData;
    this.tttsPopupData.selections = [];
    this.tttsPopupData.isMultiSelect = false;
    this.tttsPopupData.caseDocTypeSelections = [ { viewValue : "C - Case", value : "C" } ];
    this.tttsPopupData.programTypeSelections = [];
    this.tttsPopupData.selectionsUrl = "/infrastructure/tttsAllLevels";

    let diaWidth: string = "950px";
    let diaHeight: string = "700px";
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = diaWidth;
    dialogConfig.height = diaHeight;
    dialogConfig.data = this.tttsPopupData;
     
    const dialogRef = this.dialog.open(PopTttsAllLevelsComponent, dialogConfig);
   
    dialogRef.afterClosed().subscribe(result => {
     
      if (this.tttsPopupData.selections != null && this.tttsPopupData.selections.length > 0) {
        //console.log('handle return data ' + JSON.stringify(this.tttsPopupData)) ; 
          this.patchTlaSearchFields(result);
      }
  
    });
    
  }
  
  popupSuffixes() {

     this.tlaFlag = false;
     this.revert();

     this.suffixPopupData = new SuffixAllLevelPopupData;
     this.suffixPopupData.selections = [];
     this.suffixPopupData.isMultiSelect = false;
     this.suffixPopupData.caseDocTypeSelections = this.getSelectDocTypes();
     this.suffixPopupData.selectionsUrl = "/autoBilling/ttlAllSuffixes";

     const dialogConfig = new MatDialogConfig();
     dialogConfig.disableClose = true;
     dialogConfig.autoFocus = true;
     dialogConfig.width  = "950px";
     dialogConfig.height = "600px";
     dialogConfig.data = this.suffixPopupData;   
    
     const dialogRef = this.dialog.open(PopSuffixAllLevelsComponent, dialogConfig);
     dialogRef.afterClosed().subscribe(result => {
        if (this.suffixPopupData.selections != null && this.suffixPopupData.selections.length > 0) {
            //console.log('handle return data ' + JSON.stringify(this.suffixPopupData)) ; 
            this.patchSearchFields(result);
        }
      });
   
  } 
  
  getSelectDocTypes() {
    let cases: ISelectOptions[] = [ { viewValue : "C - Case", value : "C" },
                                    { viewValue : "X - Army Cross Service Case", value : "X" },
                                    { viewValue : "Y - Navy Cross Service Case", value : "Y" },
                                    { viewValue : "Z - Air Force Cross Service Case", value : "Z" } ];
    
    return cases;
  }
  

}

 