import { TestBed } from '@angular/core/testing';

import { BillingRestfulService } from './billing-restful.service';

describe('BillingRestfulService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: BillingRestfulService = TestBed.get(BillingRestfulService);
    expect(service).toBeTruthy();
  });
});
