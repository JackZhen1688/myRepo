import { Injectable } from '@angular/core';
import { FormGroup, ValidatorFn } from '@angular/forms';

@Injectable({
  providedIn: 'root'
})
export class BillAmountsValidatorService {
 
   public billAmLessThanZero(): ValidatorFn {
    return (formGroup: FormGroup) => {
      console.log("billAmLessThanZero()");
         const prevPaidAmControl = formGroup.parent.get('fctlPrevPaid');
        const billAmControl = formGroup.parent.get('fctlBillAm');
        if ( !prevPaidAmControl || !billAmControl) {
          return null;
        }
        console.log("billAm and prevPaid are not null!");
        const prevPaidValue = prevPaidAmControl.value;
      const billAmValue = billAmControl.value;
      if (!billAmValue == null) {
        console.log("billAm is null.");
        return null;
      } 
      if (!billAmValue == null) {
        console.log("billAm is null.");
        return null;
      }
      console.log("billAmLessThanZero() billAm = " + billAmValue);
      console.log("billAmLessThanZero() prevPaidAm = " + prevPaidValue);
      if (!billAmValue == null) {
        console.log("billAm is null.");
        return null;
      }
        if ((Number(prevPaidValue) + Number(billAmValue)) < 0){
          return { billAmLessThanZero : true }; // This is our error!
        } else {
          return null;
        }
      };
    
    
  }
  
  public billAmGreaterThanFundedAm(): ValidatorFn {
    return (formGroup: FormGroup) => {
      const fundedAmControl = formGroup.parent.get('fctlFundedAm');
      const prevPaidAmControl = formGroup.parent.get('fctlPrevPaid');
      const billAmControl = formGroup.parent.get('fctlBillAm');
     
      if (!fundedAmControl || !prevPaidAmControl || !billAmControl) {
        return null;
      }
      const fundedValue = fundedAmControl.value;
      const prevPaidValue = prevPaidAmControl.value;
      const billAmValue = billAmControl.value;
      if (!fundedValue || !prevPaidValue || !billAmValue) {
        return null;
      }
      if ((prevPaidValue + billAmValue) > fundedValue) {
        return { billAmGreaterThanFundedAm: true }; // This is our error!
      }
    }
  };

  }


