import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';

export class DataService {
  
  constructor(private url: string, private http: HttpClient) { }

  private _hostURL: string = environment.apiUrl;

  getAutoCompleteData(): Observable<any>{
    //return this.http.get(this.url+"/data/autocompletedata.json");
    return this.http.get(this._hostURL+"/getAutocompletList");    
  }

  //Billing Dashboard
  getManageBillingCycles(serviceDbId: string): Observable<any>{
    // return this.http.get(this.url+"/data/managebillingcycles.json");
    // console.log("User Service DB Id in data.service.ts =="+ serviceDbId);
    return this.http.get(this._hostURL+"/getManageBillingCycleData/"+serviceDbId);  
       
  }

  getCycleReports(): Observable<any>{
    return this.http.get(this.url+"/data/cyclereports.json");
  }

  getRunSavedJobs(serviceDbId: string): Observable<any>{
    //return this.http.get(this.url+"/data/runsavedjobs.json");
    return this.http.get(this._hostURL+"/getBillingDashboardParameterSet/"+serviceDbId);
  }

  // GET Notifications 
  getNotifications(notificationCalledFrom: string): Observable<any>{    
    // console.log("notificationCalledFrom in data.service.ts =="+ notificationCalledFrom);
    //return this.http.get(this._hostURL+"/getNotificationData/"+notificationCalledFrom); 
    return this.http.get(this.url+"/data/notifications.json");   
  }
   
  // PUT (update/save) by passing NOTIFICATION_REPORT entity
  saveNotification(pBody: any): Observable<any>{  
    const notificationReportEndPoint: string = "/NotificationReport";
    return this.http.put(this._hostURL +  notificationReportEndPoint, pBody);
  }
  
  // DELETE NOTIFICATION_REPORT entity by passing PK (notification_report_id)
  deleteNotificationWithParam(notificationReportId: number): Observable<any>{    
    console.log("data.service.ts -deleteNotificationWithParam()  notificationReportId== "+ notificationReportId);
    return this.http.delete(this._hostURL+"/deleteNotificationReport/"+notificationReportId);   
  }

  getAutoMangeDetails(id): Observable<any>{
    return this.http.get(this.url+"/data/automangedetails.json");
  }

  getTreeInfo(): Observable<any>{
    return this.http.get(this.url+"/data/manageautomatic.json");
  }

  getDOVNumbers(): Observable<any>{
    return this.http.get(this.url+"/data/dovnumbers.json");
  }
  
  postSaveRecordEAInformationData(budgetControl : any[], serviceId: string): Observable<any>{ 
    return this.http.post(this._hostURL+"/saveRecordEAInformationData/"+ serviceId, budgetControl); 
  }
  
  getRecordEAInformationData(cycleControlId: string):  Observable<any>{
    return this.http.get(this._hostURL+"/getRecordEAInformationData/"+cycleControlId);
  }

  getTreeViewData(): Observable<any>{
    return this.http.get(this.url+"/data/treeviewdata.json");
  }

  /*-----------------------
    Autonew Reimbursement 
    1. validation onBlur
   *-----------------------*/
  getProgramsData(): Observable<any>{
    return this.http.get(this.url+"/data/programs.json");
  }

  getProgramTypeNames(filter: string): Observable<any>{
    //return this.http.get(this._hostURL+"/getProgramTypeNames/"+filter);
    return this.http.get(this.url+"/data/programtype.json");
  }
  
  getFiscalYearsData(numYear:string): Observable<any>{
    return this.http.get(this.url+"/data/fiscalyears.json");
    //return this.http.get(this._hostURL+"/getFiscalYears/"+numYear, { responseType: 'text'});
  }

  getCustOrgId(orgId:string): Observable<any>{
    return this.http.get(this._hostURL+"/getCustOrgId/"+orgId, { responseType: 'text'});
  }  

  getCaseId(uCaseId:string): Observable<any>{
    return this.http.get(this._hostURL+"/getCaseId/"+uCaseId, { responseType: 'text'});
  }  

  getCaseIdByOrgId(selSevId:string, prog:string, orgId:string, uCaseId): Observable<any>{
    return this.http.get(this._hostURL+"/getCaseIdByOrgId/"+selSevId+"/"+prog+"/"+orgId+"/"+uCaseId, { responseType: 'text'});
  }  

  getCaseMasterLineId(caseId:number, lineNumId: string): Observable<any>{
    return this.http.get(this._hostURL+"/getCaseMasterLineId/"+caseId+"/"+lineNumId, { responseType: 'text'});
  }  

  getTrainingTrackSeqCd(caseId:number, mLineId:number, wcn:string): Observable<any>{
    return this.http.get(this._hostURL+"/getTrainingTrackSeqCd/"+caseId+"/"+mLineId+"/"+wcn, { responseType: 'text'});
  }  

  getTrainingTrackLineSeqCd(caseId:number, mLineId:number, tSeqCd:number, wsuffixCd:string): Observable<any>{
    return this.http.get(this._hostURL+"/getTrainingTrackLineSeqCd/"+caseId+"/"+mLineId+"/"+tSeqCd+"/"+wsuffixCd, { responseType: 'text'});
  }  

  getExternalFinancialCd(caseId:number, mLineId:number, tSeqCd:number, extFinancialCd:string): Observable<any>{
    return this.http.get(this._hostURL+"/getExternalFinancialCd/"+caseId+"/"+mLineId+"/"+tSeqCd+"/"+extFinancialCd, { responseType: 'text'});
  }

  getTrainingActivitydId(trdActId: string): Observable<any>{
    return this.http.get(this._hostURL+"/getTrainingActivitydId/"+trdActId, { responseType: 'text'});
  }  

  // 2. Popup Modal Information
  //GetCustOrg is in the Global getCustOrganization()
  getCustOrg(filter: string): Observable<any>{
    return this.http.get(this._hostURL+"/getCustOrg/"+filter);
  }

  getCaseWithOrgId(filter: string): Observable<any>{
    //return this.http.get(this.url+"/data/grant-case.json");
    return this.http.get(this._hostURL+"/getCaseWithOrgId/"+filter);
  }

  getCase(filter: string): Observable<any>{
    //return this.http.get(this.url+"/data/fms-case.json");
    return this.http.get(this._hostURL+"/getCase/"+filter);
  }

  getLine(filter: string): Observable<any>{
    //return this.http.get(this.url+"/line.json");
    return this.http.get(this._hostURL+"/getLine/"+filter);
  }
 
  getWcn(filter: string): Observable<any>{
    //return this.http.get(this.url+"/wcn.json");
    return this.http.get(this._hostURL+"/getWcn/"+filter);
  }  

  getSuffix(filter: string): Observable<any>{
    //return this.http.get(this.url+"/data/suffix.json");
    return this.http.get(this._hostURL+"/getSuffix/"+filter);
  }  

  getTlaSuffix(filter: string): Observable<any>{
    //return this.http.get(this.url+"/data/tla-suffix.json");
    return this.http.get(this._hostURL+"/getTlaSuffix/"+filter);
  }  

  getExa(filter: string): Observable<any>{
    //return this.http.get(this.url+"/data/exa.json");
    return this.http.get(this._hostURL+"/getExa/"+filter);
  }  

  postBilling(formData: any): Observable<any>{
    return this.http.post(this._hostURL+"/saveBilling", formData);
  }  

  runSaveJob(serviceDb: string, bpsId: string): Observable<any>{
    return this.http.get(this._hostURL+"/runSaveJob/" + serviceDb + "/" + bpsId);
  }  
  /*-----------------------
    Fiancial History 
   *-----------------------*/
  getFinancialHistory(filter: string): Observable<any>{
    return this.http.get(this.url+"/data/financialhistory.json");
    //return this.http.get(this._hostURL+"/getFinancialHistory/"+filter);
  } 

  getCycle(filter: string):  Observable<any>{
    //return this.http.get(this.url+"/data/financialhistory.json");
    return this.http.get(this._hostURL+"/getCycle/"+filter);
  } 

  getAutoReimbursCycle(cycleControlId: string):  Observable<any>{
    return this.http.get(this._hostURL+"/getAutoReimbursCycle/"+cycleControlId);
  } 

  getRecordInCycle(cycleControlId: string):  Observable<any>{
    //return this.http.get(this.url+"/data/manageautomatic.json");
    return this.http.get(this._hostURL+"/getRecordInCycle/"+cycleControlId);
  } 
    
  getUnSavedAmount(formData: any):  Observable<any>{
     return this.http.post(this._hostURL+"/getUnSavedAmount", formData);
  }
    
  deleteCycle(cycleControlId: string):  Observable<any>{
    return this.http.get(this._hostURL+"/deleteCycle/"+cycleControlId);
  }
  
  generateDOVNum(cycleControlId: string):  Observable<any>{
    return this.http.get(this._hostURL+"/generateDOVNum/"+cycleControlId);
  }

  approveCycle(cycleControlId: string):  Observable<any>{
    return this.http.get(this._hostURL+"/approveCycle/"+cycleControlId);
  }

  saveCycle(formData: any):  Observable<any>{
    return this.http.post(this._hostURL+"/saveCycle", formData);
  }

  validateDOV(cycleControlId: string):  Observable<any>{
    return this.http.get(this._hostURL+"/validateDOVNum/"+cycleControlId);
  }

  validateEA(cycleControlId: string):  Observable<any>{
    return this.http.get(this._hostURL+"/validateEANum/"+cycleControlId);
  }  

  /*-----------------------------------
    Release transactions after billing 
   *----------------------------------*/
  getReleaseTransactions(filter: string): Observable<any>{
    //return this.http.get(this.url+"/data/releasetransactions.json");
    return this.http.get(this._hostURL+"/getReleaseTransactions/"+filter);
  } 

  getReleaseDtims(filter: string): Observable<any>{
    //return this.http.get(this.url+"/data/releasetransactions.json");
    return this.http.get(this._hostURL+"/getReleaseDtims/"+filter);
  } 

  saveReleaseTransanctions(formData: any): Observable<any>{
    return this.http.post(this._hostURL+"/saveReleaseTransanctions", formData);
  } 

  saveReleaseDtims(formData: any): Observable<any>{
    return this.http.post(this._hostURL+"/saveReleaseDtims", formData);
  } 

  getFillNoBillStatus(filter: string): Observable<any>{
    return this.http.get(this._hostURL+"/getFillNoBillStatus/"+filter);
  } 

  saveFillNoBillStatus(formData: any): Observable<any>{
    return this.http.post(this._hostURL+"/saveFillNoBillStatus", formData);
  } 

  /*-----------------------
    Manage Manual Reimbursement 
   *-----------------------*/

  getManualReimbursmentCycleCases(): Observable<any>{
    return this.http.get(this.url+"/data/manageManualReimbursmentCycleCases.json");

  } 

  getManualReimbursmentPaymentLines(): Observable<any>{
    return this.http.get(this.url+"/data/manageManualReimbursmentPaymentLines.json");

  } 

  getCaseByService(service: string): Observable<any>{
    return this.http.get(this.url+"/data/manageManualReimbursementGetCaseByService.json");
  }
  
  /*-----------------------
    GFEBS TLA Posting Cycle
   *-----------------------*/

  getGfebsTLaCycleCases(): Observable<any>{
    return this.http.get(this.url+"/data/gfebsTlaCycleCases.json");

  } 

  /*-----------------------
    GFEBS Suffix Posting Cycle
   *-----------------------*/

  getGfebsSuffixCycleCases(): Observable<any>{
    return this.http.get(this.url+"/data/gfebsSuffixCycleCases.json");

  }

    
// helper methods for adding DBID to the URL
  getDbIdParms(): HttpParams {
    return new HttpParams().append("serviceDbId", this.getDbId());
  }

  // session DbId access and helper methods
  getDbId(): string {
    return sessionStorage.getItem('serviceDBid');
  }
  getDbIdSlash(): string {
    return this.getDbId() + "/";
  }

  getSlashDbIdSlash(): string {
    return"/" + this.getDbId() + "/";
  }

  getSlashDbId(): string {
    return"/" + this.getDbId();
  }
//
  // Commom API's for Army Billing Cycle components
  	deleteArmyBillingCycle(apiUrl : string, cycleId : string) : Observable<any> {
		return this.http.delete(this._hostURL + apiUrl  + this.getSlashDbIdSlash() + cycleId);
    }
    
    getArmyBillingCycle(apiUrl : string, cycleId : string, lockId: string  ) : Observable<any> {
		return this.http.get(this._hostURL + apiUrl  + this.getSlashDbIdSlash() + cycleId + "/" + lockId);
    }	
    
    getNewArmyBillingCycle(apiUrl : string) : Observable<any> {
		return this.http.get(this._hostURL + apiUrl  + this.getSlashDbId() );
    }
    
    approveArmyBillingCycle(apiUrl : string, cycleId : string, lockId: string ) : Observable<any> {
		return this.http.get(this._hostURL + apiUrl +  this.getSlashDbIdSlash() + cycleId + "/" + lockId);
  }
  
  
    
    approveArmyBillingCycleType(apiUrl : string,cycleId: string, cycleTypeId: string, lockSessionId: string): Observable<any> {
  
    return this.http.get(this._hostURL + apiUrl + this.getSlashDbIdSlash() +
      +cycleId + "/" + cycleTypeId + "/" + lockSessionId
    );
  }
    getArmyBillingCycleIdList(apiUrl : string) : Observable<any> {
		return this.http.get(this._hostURL + apiUrl  +  this.getSlashDbId());
    }
           
  getArmyBillingCycleControl(apiUrl : string, cycleControlId: string, lockSessionId : string ): Observable<any>{
      let url: string = this._hostURL + apiUrl
        + this.getSlashDbIdSlash() + cycleControlId + "/" + lockSessionId;
      console.log("getArmyBillingCycleControl(), url =" + url);
      return this.http.get(url);
        
    }
    
  saveArmyBillingCycle(apiUrl : string, cycleData : any, lockSessionId : string): Observable<any>{
    let saveParms: HttpParams = (this.getDbIdParms().append("lockSessionId",  lockSessionId ));
    return this.http.post(this._hostURL + apiUrl, cycleData, { params: saveParms });
    }
    
    getArmyBillingCycleProgramTypes(apiUrl : string) : Observable<any> {
    return this.http.get(this._hostURL + apiUrl );
    }
    
    getArmyBillingCycleDocTypes(apiUrl : string) : Observable<any> {
      return this.http.get(this._hostURL + apiUrl  );
    }
    
   
  closeLockSession(lockSessionId : string): Observable<any>{ 
     return this.http.delete(this._hostURL+"/manualBilling/closeDbLockSession/" + this.getDbIdSlash() +
     lockSessionId )
     ; 
  }

  openLockSession(): Observable<any>{
     return this.http.get(this._hostURL+ "/openLockSession" + this.getSlashDbId() ); 
  } 
  // end of Commom API's for Army Billing Cycle components


  // API's for Army MODD Cycle (WP118)
	getArmyMODDCycleIdList() : Observable<any> {
		return this.http.get(this._hostURL + "/armyModdCycle/cycleControlIdList/"  +  this.getSlashDbId());
  }
	
	getNewArmyMODDCycle() : Observable<any> {
		return this.http.get(this._hostURL + "/armyModdCycle/newCycleControl/"  + this.getSlashDbId() );
  }
	
	getArmyMODDCycle(cycleId : string, lockId: string  ) : Observable<any> {
		return this.http.get(this._hostURL + "/armyModdCycle/cycleControl/"   + this.getSlashDbIdSlash() + cycleId + "/" + lockId);
  }
	
	getArmyMODDData(suffixModd : any,cycleId : string, cycleTypeId : string) : Observable<any> {
    //let parms: HttpParams = (this.getDbIdParms().append("lockSessionId", cycleId));
    let parms: HttpParams = (this.getDbIdParms().append("cycleControlId", cycleId));
    parms = parms.append("cycleControlTypeId",cycleTypeId);
      return this.http.post(this._hostURL +  "/armyModdCycle/moddData", suffixModd, { params: parms });
   
  }
  
	validateArmyMODDCycle(cycleData : any ) : Observable<any> {
	 let parms: HttpParams = this.getDbIdParms();
	 return this.http.post(this._hostURL +  "/armyModdCycle/validateCycle", cycleData, { params: parms });
	}
	
 saveArmyMODDCycle(cycleData : any, lockSessionId : string): Observable<any>{
    let saveParms: HttpParams = (this.getDbIdParms().append("lockSessionId",  lockSessionId ));
    return this.http.post(this._hostURL + "/armyModdCycle/saveCycle", cycleData, { params: saveParms });
    }

 approveArmyMODDCycle(cycleData : any, lockId: string ) : Observable<any> {
	 let parms: HttpParams = (this.getDbIdParms().append("lockSessionId",  lockId ));
	 return this.http.post(this._hostURL +  "/armyModdCycle/approveCycle", cycleData, { params: parms });
	 }

  deleteArmyMODDCycle(cycleId : string, cycleTypeId ) : Observable<any> {
		return this.http.delete(this._hostURL + "/armyModdCycle/deleteCycle"  + this.getSlashDbIdSlash() + cycleId + "/" + cycleTypeId);
  }
		
	getArmySuffixMODDData(suffixModd : any) : Observable<any> {
    let parms: HttpParams = this.getDbIdParms();
     return this.http.post(this._hostURL +  "/armyModdCycle/suffixModdData/", suffixModd, { params: parms });
  }
    
  openArmyMODDLockSession(): Observable<any>{
      return this.http.get(this._hostURL+ "/armyModdCycle/openLockSession"  + this.getSlashDbId() ); 
  }  
   
  closeArmyMODDLockSession(lockSessionId : string): Observable<any>{ 
     return this.http.delete(this._hostURL+ "/armyModdCycle/closeDbLockSession" + this.getSlashDbIdSlash() +
       lockSessionId)
       
     ; 
  }
  // end of  API's for Army MODD Cycle (WP118)


// Start  Manual billing Cycle  API's
  
getUserData(userId : string): Observable<any>{ 
  return this.http.get(this._hostURL+"/manualBilling/userData/" + this.getDbIdSlash() + userId); 
}

getCurrentUserData(): Observable<any>{
   return this.http.get(this._hostURL+"/manualBilling/userData"  + this.getDbIdSlash() );  }

getNewBudgetControlList(ccId : string, ccTypeId : string, caseId : string, cmlId : string,
  ttSeqCd : string, ttlSeqCd : string): Observable<any>{
    if (ccId == null || ccId.length < 3){ ccId = "0";}
  let restUrl : string  = this._hostURL+"/manualBilling/newBudgetControlList"  ;
  restUrl = restUrl +  "/" + this.getDbIdSlash() +  ccId +  "/" + ccTypeId +  "/" + caseId + "/" + cmlId +  "/" + ttSeqCd +  "/" + ttlSeqCd;
  console.log("Data service calling: " + restUrl );
  return this.http.get(restUrl); 
  
}

getCycleLockedMessageList(cycleId : string): Observable<any>{ 
  return this.http.get(this._hostURL+"/manualBilling/cycleLockedMessageList/" + cycleId); 
}


getManualBillingGenerateDovNumber(cycleId : number ): Observable<any>{
  return this.http.get(this._hostURL+"/manualBilling/generateAssignDovNumber/" + this.getDbIdSlash() +
   +cycleId.toString() 
 );
  
}
  
postBasicSuffixAllLevels(filter: any): Observable<any>{
  return this.http.post(this._hostURL + "/basic/getSuffixAllLevels", filter, { params: this.getDbIdParms() });
   
}


getBasicCaseUsageIndicators(): Observable<any>{
  return this.http.get(this._hostURL+ "/basicCaseUsageIndicator/selectList" + this.getSlashDbId());
  }
  


   // Start  Army Suffix Posting Cycle API's
  
    
  
    getNewPostingSuffixBudgetControlList(cycleId : string,  caseId : string, cmlId : string,
      ttSeqCd: string, ttlSeqCd: string): Observable<any> {
        if (cycleId == null || cycleId.length < 3){ cycleId = "0";}
         let restUrl : string  = this._hostURL+"/manualPosting/new/suffixBudgetControlList" ;
        restUrl = restUrl +  "/" + this.getDbIdSlash() +  cycleId +  "/" + caseId + "/" + cmlId +  "/" + ttSeqCd +  "/" + ttlSeqCd;
        return this.http.get(restUrl);
  }
  
  getNewPostingTlaBudgetControlList(cycleId : string,  caseId : string, cmlId : string,
    ttSeqCd: string): Observable<any> {
      if (cycleId == null || cycleId.length < 3){ cycleId = "0";}
       let restUrl : string  = this._hostURL+"/manualPosting/new/tlaBudgetControlList" ;
      restUrl = restUrl +  "/" + this.getDbIdSlash() +  cycleId +  "/" + caseId + "/" + cmlId +  "/" + ttSeqCd ;
      return this.http.get(restUrl);
  }
 
  // end of Army Suffix Posting Cycle API's
  
 
     
  
 
  

private handleError(error: Response) {
  
}

// end of Manal Billing Cycle

}

