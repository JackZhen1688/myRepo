import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManualObligationDisbursementsComponent } from './manual-obligation-disbursements.component';

describe('ManualObligationDisbursementsComponent', () => {
  let component: ManualObligationDisbursementsComponent;
  let fixture: ComponentFixture<ManualObligationDisbursementsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManualObligationDisbursementsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManualObligationDisbursementsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
