
import { Injectable } from '@angular/core';
import { CanDeactivate } from '@angular/router';
import {CanDeactivateComponent} from '../can-deactivate-component';
import {CanDeactiveNotiticationService} from '../can-deactive-notitication.service';


@Injectable({ providedIn: 'root' })
export class CanDeactivateGuard implements CanDeactivate<any>{

  constructor(private canDeactivateService: CanDeactiveNotiticationService) { }

  canDeactivate(component: CanDeactivateComponent) {
    return (typeof component.canDeactivate === 'function' && !component.canDeactivate())
      ? this.canDeactivateService.canDeactivate() : true;
     // confirm("Warning, there are unsaved changes. If you continue the changes will be lost.") : true;
  }

}