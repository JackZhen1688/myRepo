import { Injectable } from '@angular/core';
import { DsamsUserMessageService } from './../services/dsams-user-message.service';

@Injectable({
  providedIn: 'root'
})
export class CanDeactiveNotiticationService {
  constructor(private messageService: DsamsUserMessageService) { }
  canDeactivate() {
    return true;
  
  }
}
