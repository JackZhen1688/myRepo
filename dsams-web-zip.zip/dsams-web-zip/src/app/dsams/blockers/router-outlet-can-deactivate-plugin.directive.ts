import { Directive, HostListener } from '@angular/core';
import {RouterOutlet} from '@angular/router';
import {CanDeactivateComponent} from './can-deactivate-component';
import {CanDeactiveNotiticationService} from './can-deactive-notitication.service';

@Directive({ selector: 'router-outlet' })
export class RouterOutletCanDeactivatePluginDirective {

  @HostListener('window:beforeunload', ['$event'])
  canDeactivate($event: any) {
    console.log("window:beforeunload");
    for (const component of this.components) {
      if(typeof component.canDeactivate === 'function' && !component.canDeactivate()){
        if (!this.canDeactivateService.canDeactivate()) {
          $event.returnValue = true;
          return;
        }
      }
    }
  }

  private components: CanDeactivateComponent[] = [];

  constructor(routerOutlet: RouterOutlet, private canDeactivateService: CanDeactiveNotiticationService) {
    routerOutlet.activateEvents.subscribe( c => this.components.push(c) );
    routerOutlet.deactivateEvents.subscribe( c => {
      const idx = this.components.indexOf(c);
      if (idx > -1) {
        this.components.splice(idx, 1);
      }
    });
  }
}
