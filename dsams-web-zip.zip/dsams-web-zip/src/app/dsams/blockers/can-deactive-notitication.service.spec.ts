import { TestBed } from '@angular/core/testing';

import { CanDeactiveNotiticationService } from './can-deactive-notitication.service';

describe('CanDeactiveNotiticationService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CanDeactiveNotiticationService = TestBed.get(CanDeactiveNotiticationService);
    expect(service).toBeTruthy();
  });
});
