import { formatCurrency } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material';
import { BehaviorSubject, Subscription } from 'rxjs';
import { TextAreaComponent } from '../../case/dialogs/text-area/text-area.component';
import { ICustomerCn } from '../../case/model/dto/customer-cn';
import { CaseRestfulService } from '../../case/services/case-restful.service';
import { CaseUIService } from '../../case/services/case-ui-service';
import { CaseUtils } from '../../case/utils/case-utils';
import { DsamsMethodsService } from '../../services/dsams-methods.service';
import { CongressNotifyCommentsDTO, CongressNotifyLineCommentsDTO } from './model/view-case-comments';
import { IEditResponseType } from '../../case/model/edit-response-type';
import { DsamsConstants } from '../../dsams.constants';
import { FieldDisabledMap } from '../../case/model/field-disabled-map';

@Component({
  selector: 'app-case-comments-panel',
  templateUrl: './case-comments-panel.component.html',
  styleUrls: ['./case-comments-panel.component.css']
})




export class CaseCommentsPanelComponent implements OnInit {
  theMasterCNListData: CongressNotifyCommentsDTO[] = [];
  dataSourceCaseCMTListData: CongressNotifyCommentsDTO[] = [];

  theMasterCNListLineData: CongressNotifyLineCommentsDTO[] = [];
  dataSourceCaseCMTLineListData: CongressNotifyLineCommentsDTO[] = [];

  columnsToDisplayCA = ['Case', 'Version', 'Status', 'Case Value', 'Case Comments'];
  dataSourceCaseCMTListTable = new MatTableDataSource(this.dataSourceCaseCMTListData);
  columnsToDisplayCALine = ['Case', 'Version', 'Status', 'Line', 'MASL', 'Quantity', 'Case Comments'];
  dataSourceCaseCMTLineListTable = new MatTableDataSource(this.dataSourceCaseCMTLineListData);

  caseUIServiceSub: Subscription;
  theCNPopupPk: ICustomerCn;
  isPanelEditable: boolean = false;

  //saveCaseCommentsObject: congressionalNotificationModel;

  // Attributes needed from Popup
  customer_CN_ID_FROM_POPUP: number = 0;

  /**
   * Editability fields
   */

  private _fieldDisabledMap: FieldDisabledMap = {};
  editSubscription: Subscription = null;
  private newCNSubscription: Subscription = null;

  //rePopulate
  private rePopSubscription: Subscription = null;
  private congNumCdSubscription: Subscription = null;
  isCountryDisabled: boolean = true;

  isLoading: BehaviorSubject<boolean> = new BehaviorSubject(false);


  constructor(private caseUIService: CaseUIService,
    private caseRestService: CaseRestfulService,
    public dsamsDialogMsgService: DsamsMethodsService) { }

  //Text Area
  private textAreaSubscription: Subscription = null;

  //Subscription/Observable variables
  private _textIndex: number = -1;

  ngOnDestroy() {
    if (!!this.caseUIServiceSub) {
      this.caseUIServiceSub.unsubscribe();
    }
  }

  ngOnInit() {
    this.theMasterCNListData = [];
    this.dataSourceCaseCMTListData = [];
    this.theMasterCNListLineData = [];
    this.dataSourceCaseCMTLineListData = [];

    this.subscribeToEditService();
    this.subscribeToNewCNService();
    this.caseUIServiceSub = this.caseUIService.getCongNotificationFromPopup().subscribe(value => {
      this.theCNPopupPk = value;
      if (!!this.theCNPopupPk)
        if (!!this.theCNPopupPk.cong_NOTIFICATION_NUMBER_CD) {
          this.populateCongressNotifComments(this.theCNPopupPk.cong_NOTIFICATION_NUMBER_CD);
          this.populateCongressNotifLineComments(this.theCNPopupPk.cong_NOTIFICATION_NUMBER_CD, this.theCNPopupPk.customer_ORGANIZATION_ID)

          // Populate correct customer cn id from popup
          this.customer_CN_ID_FROM_POPUP = this.theCNPopupPk.customer_CN_ID;
        }
    })
    this.subscribeToTextAreaDialog();
    this.subscribeToTextAreaDialogLine();
    this.resetForNewCong();
    

  }

  //get congressional Notif comments from database
  populateCongressNotifComments(pPKValue: string) {
    this.caseRestService.getCongressionalNotifyCaseAmountList(pPKValue).subscribe(value => {
      this.theMasterCNListData = value;
      console.log("**** this.theMasterCNListData", this.theMasterCNListData);
      this.populateDataForCNList();
    },
      err => {
        CaseUtils.ReportHTTPError(err, "Getting Congressional Notify Comments");
      }
    )
    this.dataSourceCaseCMTListTable._updateChangeSubscription();
  }

  //get congressional Notif comments from database
  populateCongressNotifLineComments(pPKValue: string, pCOPkValue: string) {
    this.caseRestService.getCongressionalNotifyCaseQuantityList(pPKValue, pCOPkValue).subscribe(value => {
      this.theMasterCNListLineData = value;
      console.log("**** this.theMasterCNListLineData", this.theMasterCNListLineData);
      this.populateDataForCNLineList();
    },
      err => {
        CaseUtils.ReportHTTPError(err, "Getting Congressional Notify Line Comments");
      }
    )
    this.dataSourceCaseCMTLineListTable._updateChangeSubscription();
  }

  // Text Area Popup 
  popupTextAreaOpen(pElement: any, pIndex: number): void {
    let diaWidth: string = "50%";
    let diaHeight: string = "60%";

    let passingData: string = pElement.caseCnAmCommentTx;
    let pTitle: string = "Comments";
    this._textIndex = pIndex;

    let indexString = '';
    if (!!pIndex) {
      indexString = pIndex.toString();
    }

    this.dsamsDialogMsgService.openTextAreaIpcDialog(diaWidth, diaHeight, passingData, TextAreaComponent, indexString, pTitle, !this.isPanelEditable);

  }

  // Text Area Popup 
  popupTextAreaOpenLine(pElement: any, pIndex: number): void {
    let diaWidth: string = "50%";
    let diaHeight: string = "60%";

    let passingData: string = pElement.case_LINE_CN_MDE_COMMENT_TX;
    let pTitle: string = "Comments";
    this._textIndex = pIndex;

    let indexString = '';
    if (!!pIndex) {
      indexString = pIndex.toString();
    }

    this.dsamsDialogMsgService.openTextAreaIpc2Dialog(diaWidth, diaHeight, passingData, TextAreaComponent, indexString, pTitle, !this.isPanelEditable);
  }

  // Subscribe to Text Area Dialog Comment Save
  subscribeToTextAreaDialog() {
    this.textAreaSubscription = this.dsamsDialogMsgService.textAreaFromIpcDialog.subscribe((textAreaValue: string) => {
      setTimeout(() => {
        if (!!this.dataSourceCaseCMTListData[this._textIndex]) {
          this.dataSourceCaseCMTListData[this._textIndex].caseCnAmCommentTx = textAreaValue;
          this.dataSourceCaseCMTListTable._updateChangeSubscription();
          this.setChanged(this._textIndex);
        }
      }, 0);
    });
  }

  // Subscribe to Text Area Dialog Line Comment Save
  subscribeToTextAreaDialogLine() {
    this.textAreaSubscription = this.dsamsDialogMsgService.textAreaFromIpc2Dialog.subscribe((textAreaValue: string) => {
      setTimeout(() => {
        if (!!this.dataSourceCaseCMTLineListData[this._textIndex]) {
          this.dataSourceCaseCMTLineListData[this._textIndex].case_LINE_CN_MDE_COMMENT_TX = textAreaValue;
          this.dataSourceCaseCMTLineListTable._updateChangeSubscription();
          this.setLineChanged(this._textIndex);
        }
      }, 0);
    });
  }

  //populate data for Case and Case LIne
  populateDataForCNList() {
    this.theMasterCNListData.forEach(eachRow => {
      eachRow.userCaseId = CaseUtils.formatUserCaseId(eachRow.userCaseId);
      eachRow.status = DsamsConstants.ENT_UNCHANGED.toString();
      eachRow.calcCvTotalCaseValueAmStr = formatCurrency(eachRow.calcCvTotalCaseValueAm, 'en', '$', 'USD', '1.0-0');
    })
    this.caseUIService.setCongressionalNotificationCommentsData(this.theMasterCNListData);
    this.dataSourceCaseCMTListData = this.theMasterCNListData;
    this.dataSourceCaseCMTListTable = new MatTableDataSource(this.dataSourceCaseCMTListData);
  }

  //populate data for Case and Case LIne // this list for lines is empty
  populateDataForCNLineList() {
    this.theMasterCNListLineData.forEach(eachRow => {
      eachRow.user_CASE_ID = CaseUtils.formatUserCaseId(eachRow.user_CASE_ID);
      eachRow.status = DsamsConstants.ENT_UNCHANGED.toString();
    })
    this.caseUIService.setCongressionalNotificationLineCommentsData(this.theMasterCNListLineData);
    this.dataSourceCaseCMTLineListData = this.theMasterCNListLineData;
    this.dataSourceCaseCMTLineListTable = new MatTableDataSource(this.dataSourceCaseCMTLineListData);
  }

  private subscribeToEditService() {
    this.editSubscription = this.caseUIService.caseEditService.subscribe((pEditResult: IEditResponseType) => {
      if (!!pEditResult && pEditResult.ID === DsamsConstants.CONGRESSIONAL_NOTIFICATION_EDITOR) {
        this.isPanelEditable = pEditResult.editToggle;
      }
    });
  }

  /**
 * Set the field changed so that the edit toggle is notified.
 */
  setChanged(index: number) {   // not consistent
    if (!!this.dataSourceCaseCMTListData[index]) {
      if (this.dataSourceCaseCMTListData[index].status == DsamsConstants.ENT_UNCHANGED.toString()) {
        this.dataSourceCaseCMTListData[index].status = DsamsConstants.ENT_CHANGED.toString();
      }
    }
    const editResp: IEditResponseType = { ID: DsamsConstants.CONGRESSIONAL_NOTIFICATION_EDITOR, editToggle: true };
    this.caseUIService.hasEditBeenMadeService.next(editResp);
  }

  /**
* Set the field changed so that the edit toggle is notified.
*/
  setLineChanged(index: number) {   // it never goes here.  But not consistently *****
    if (!!this.dataSourceCaseCMTLineListData[index]) {
      if (this.dataSourceCaseCMTLineListData[index].status == DsamsConstants.ENT_UNCHANGED.toString()) {
        this.dataSourceCaseCMTLineListData[index].status = DsamsConstants.ENT_CHANGED.toString();
      }
    }
    const editResp: IEditResponseType = { ID: DsamsConstants.CONGRESSIONAL_NOTIFICATION_EDITOR, editToggle: true };
    this.caseUIService.hasEditBeenMadeService.next(editResp);
  }

  private subscribeToNewCNService() {
    this.newCNSubscription = this.caseUIService.isNewCongNotification.subscribe((value) => {
      if (value) {
        this.isPanelEditable = true;
      }
    });
  }

  resetForNewCong() {
    this.newCNSubscription = this.caseUIService.isNewCongNotification.subscribe((value) => {
      if (value) {
        this.theMasterCNListData = [];
        this.dataSourceCaseCMTListData = [];
        this.dataSourceCaseCMTLineListData = [];
        this.dataSourceCaseCMTListTable = new MatTableDataSource(this.dataSourceCaseCMTListData);
        this.dataSourceCaseCMTLineListTable = new MatTableDataSource(this.dataSourceCaseCMTLineListData);

      }
    });

  }
  
  onCancelPopulateData() {
    this.isLoading.next(true);
    this.rePopSubscription = this.caseUIService.isRepopulateData.subscribe((value) => {
      if (value) {
        this.caseUIServiceSub = this.caseUIService.getCongNotificationFromPopup().subscribe(data => {
          this.theCNPopupPk = data;
          if (data) {
            this.populateCongressNotifComments(this.theCNPopupPk.cong_NOTIFICATION_NUMBER_CD);
            this.populateCongressNotifLineComments(this.theCNPopupPk.cong_NOTIFICATION_NUMBER_CD, this.theCNPopupPk.customer_ORGANIZATION_ID);
            this.caseUIService.setCongressionalNotificationCommentsData(this.dataSourceCaseCMTListData)
            this.caseUIService.setCongressionalNotificationLineCommentsData(this.dataSourceCaseCMTLineListData);
            this.isCountryDisabled = false;
          }
        })
      }
      this.isLoading.next(false);
    });
  }
}