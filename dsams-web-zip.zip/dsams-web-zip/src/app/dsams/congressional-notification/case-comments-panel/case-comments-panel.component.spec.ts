import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CaseCommentsPanelComponent } from './case-comments-panel.component';

describe('CaseCommentsPanelComponent', () => {
  let component: CaseCommentsPanelComponent;
  let fixture: ComponentFixture<CaseCommentsPanelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CaseCommentsPanelComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CaseCommentsPanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
