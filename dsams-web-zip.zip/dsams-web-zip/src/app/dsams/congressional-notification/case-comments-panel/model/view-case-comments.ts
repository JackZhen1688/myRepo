import { DsamsConstants } from "src/app/dsams/dsams.constants";

export interface CongressNotifyCommentsDTO {
    userCaseId?: string,
    caseVersionTypeCd?: string,
    versionStatusTitleNm?: string,
    calcCvTotalCaseValueAmStr?: string,
    calcCvTotalCaseValueAm?: number,
    caseVersionNumberId?: string,
    caseVersionStatusCd?: string,
    caseId?: number,
    caseVersionId?: number,
    CvPrevTotalCaseValueAm?: number,
    CvTotalCaseValueAm?: number,
    totalAmountNotified?: string,
    remainingBalance?: string,
    totalDevCaseValue?: number,
    totalNonDevCaseValue?: number,
    totalDevCaseValueStr?: string,
    totalNonDevCaseValueStr?: string,
    version?: string,
    status?: string,
    caseCnAmCommentTx?: string,
    // primary key attributes
    customerCnId?: number,
    caseCnAmId?: number,
    customerCnAmId?: number,
    implementing_AGENCY_ID?: string,
    service_DB_ID?: string,
}

export interface CongressNotifyLineCommentsDTO {
    user_CASE_ID?: string,
    case_VERSION_TYPE_CD?: string,
    case_VERSION_NUMBER_ID?: number,
    user_CASE_LINE_NUMBER_ID?: number,
    version_STATUS_TITLE_NM?: string,
    case_LINE_MDE_QY?: number,
    user_CASE_SUBLINE_TX?: string,
    military_ARTICLE_SERVICE_CD?: string,
    cong_NOTIFICATION_NUMBER_CD?: string,
    status?: string,

    // primary key attributes
    customer_CN_ID?: number,
    customer_CN_MDE_ID?: number,
    case_LINE_CN_MDE_ID?: number,
    case_ID?: number,
    working_CASE_ID?: number,
    working_CASE_VERSION_ID?: number,
    case_MASTER_LINE_ID?: number,
    implementing_AGENCY_ID?: string,
    service_DB_ID?: string,

    //window mapping attributes
    wm_CASE_LINE_NUMBER_ID?: string,
    wm_CASE_SUBLINE_IND?: boolean,
    case_LINE_CN_MDE_COMMENT_TX?: string,
    version?: string,
    user_CASE_LINE_NUMBER_ID_FORMAT?: string
}

/** 
  * Prepare  Comments data for save
  * @Author: David Huynh
  * @Date: 02/01/2022
  * @Jira Card: 4971
*/
export interface CaseCNAmountModel {
    case_ID?: number,
    case_VERSION_ID?: number,
    case_CN_AM_COMMENT_TX?: string,
    case_CN_AM_ID?: number,
    customer_CN_AM_ID?: number,
    customer_CN_ID?: number,
    case_VERSION_STATUS_CD?: string,
    lockSessionId?: string,
    status?: string,
    implementing_AGENCY_ID?: string,
    service_DB_ID?: string,
}

export class PrepareCaseCNAmountDataForSave {
    theModelEntityList: CaseCNAmountModel[] = [];
    aDTOEntity: CaseCNAmountModel = null;
    constructor(pDTOList: CongressNotifyCommentsDTO[]) {
        this.theModelEntityList = [];
        pDTOList.forEach(eachDto => {
            if (!!eachDto.status && eachDto.status !== DsamsConstants.ENT_UNCHANGED.toString()) {
                this.aDTOEntity = {
                    case_CN_AM_COMMENT_TX: eachDto.caseCnAmCommentTx,
                    case_ID: eachDto.caseId,
                    case_VERSION_ID: eachDto.caseVersionId,
                    case_CN_AM_ID: eachDto.caseCnAmId,
                    customer_CN_ID: eachDto.customerCnId,
                    customer_CN_AM_ID: eachDto.customerCnAmId,
                    case_VERSION_STATUS_CD: eachDto.caseVersionStatusCd,
                    status: eachDto.status,
                    implementing_AGENCY_ID: eachDto.implementing_AGENCY_ID,
                    service_DB_ID: eachDto.service_DB_ID,
                };
                this.theModelEntityList.push(this.aDTOEntity);
            }
        })
    }

}
/** 
  * Prepare Line Comments data for save
  * @Author: David Huynh
  * @Date: 02/01/2022
  * @Jira Card: 4971
*/
export interface CaseLineCNMDEModel {
    customer_CN_ID?: number,
    customer_CN_MDE_ID?: number,
    case_LINE_CN_MDE_ID?: number,
    case_LINE_MDE_QY?: number,
    case_ID?: number,
    working_CASE_ID?: number,
    working_CASE_VERSION_ID?: number,
    case_MASTER_LINE_ID?: number,
    case_LINE_CN_MDE_COMMENT_TX?: string,
    military_ARTICLE_SERVICE_CD?: string,
    lockSessionId?: string,
    status?: string,
    implementing_AGENCY_ID?: string,
    service_DB_ID?: string,
}

export class PrepareCaseLineCNMDEDataForSave {
    theModelEntityList: CaseLineCNMDEModel[] = [];
    aDTOEntity: CaseLineCNMDEModel = null;
    constructor(pDTOList: CongressNotifyLineCommentsDTO[]) {
        this.theModelEntityList = [];
        pDTOList.forEach(eachDto => {
            if (!!eachDto.status && eachDto.status !== DsamsConstants.ENT_UNCHANGED.toString()) {
                this.aDTOEntity = {
                    case_LINE_CN_MDE_COMMENT_TX: eachDto.case_LINE_CN_MDE_COMMENT_TX,
                    customer_CN_ID: eachDto.customer_CN_ID,
                    customer_CN_MDE_ID: eachDto.customer_CN_MDE_ID,
                    case_LINE_CN_MDE_ID: eachDto.case_LINE_CN_MDE_ID,
                    case_LINE_MDE_QY: eachDto.case_LINE_MDE_QY,
                    case_ID: eachDto.case_ID,
                    working_CASE_ID: eachDto.working_CASE_ID,
                    working_CASE_VERSION_ID: eachDto.working_CASE_VERSION_ID,
                    case_MASTER_LINE_ID: eachDto.case_MASTER_LINE_ID,
                    military_ARTICLE_SERVICE_CD: eachDto.military_ARTICLE_SERVICE_CD,
                    status: eachDto.status,
                    implementing_AGENCY_ID: eachDto.implementing_AGENCY_ID,
                    service_DB_ID: eachDto.service_DB_ID,
                };
                this.theModelEntityList.push(this.aDTOEntity);
            }
        })
    }
}

/* This class is used to generate random data set for UI unit testing purposes.
 * Author: David Huynh
 * Date: 12/20/2002
 * Jira Card: 4935 
 * */
export class CongressNotifyPrototype {
    mockNonDevData: CongressNotifyCommentsDTO[];
    mockDevData: CongressNotifyCommentsDTO[];
    //return a random number based on a passing range
    public static getRandomNumber(pRange: number): number {
        var byteArray = new Uint8Array(1);
        window.crypto.getRandomValues(byteArray);
        return Math.floor(byteArray[0] % pRange);
    }

    //return a random letter in within the given string
    public static getRandomAlphaLetter(): string {
        var alphabeticalString: string = '123456789ABCDEFGHKLMNOPQRSTUVWXYZ';
        return alphabeticalString.charAt(CongressNotifyPrototype.getRandomNumber(33));
    }
    //rouding up values to 2 digit decimal
    getRoundUpNumber(): number {
        return (Math.round((CongressNotifyPrototype.getRandomNumber(1000000) + 1 / 100 +
            CongressNotifyPrototype.getRandomNumber(1000) / 100 + Number.EPSILON) * 100));
    }
    constructor(pNonDev: boolean) {
        if (pNonDev) {
            this.mockNonDevData = [{
                userCaseId: CongressNotifyPrototype.getRandomAlphaLetter() + 'TBCA' + CongressNotifyPrototype.getRandomAlphaLetter(),
                caseVersionTypeCd: 'B',
                caseVersionNumberId: (CongressNotifyPrototype.getRandomNumber(25) + 1).toString(),
                caseVersionStatusCd: 'I',
                versionStatusTitleNm: 'Implemented',
                calcCvTotalCaseValueAm: this.getRoundUpNumber(),
            },
            {
                userCaseId: CongressNotifyPrototype.getRandomAlphaLetter() + 'TBCA' + CongressNotifyPrototype.getRandomAlphaLetter(),
                caseVersionTypeCd: 'M',
                caseVersionNumberId: (CongressNotifyPrototype.getRandomNumber(25) + 1).toString(),
                caseVersionStatusCd: 'X',
                versionStatusTitleNm: 'Cancelled',
                calcCvTotalCaseValueAm: this.getRoundUpNumber(),
            },
            {
                userCaseId: CongressNotifyPrototype.getRandomAlphaLetter() + 'SBVA' + CongressNotifyPrototype.getRandomAlphaLetter(),
                caseVersionTypeCd: 'A',
                caseVersionNumberId: (CongressNotifyPrototype.getRandomNumber(25) + 1).toString(),
                caseVersionStatusCd: 'O',
                versionStatusTitleNm: 'Offered',
                calcCvTotalCaseValueAm: this.getRoundUpNumber(),
            },
            {
                userCaseId: CongressNotifyPrototype.getRandomAlphaLetter() + 'LABE' + CongressNotifyPrototype.getRandomAlphaLetter(),
                caseVersionTypeCd: 'M',
                caseVersionNumberId: (CongressNotifyPrototype.getRandomNumber(25) + 1).toString(),
                caseVersionStatusCd: 'W',
                versionStatusTitleNm: 'Writing',
                calcCvTotalCaseValueAm: this.getRoundUpNumber(),
            },
            {
                userCaseId: CongressNotifyPrototype.getRandomAlphaLetter() + CongressNotifyPrototype.getRandomAlphaLetter() + CongressNotifyPrototype.getRandomAlphaLetter() +
                    CongressNotifyPrototype.getRandomAlphaLetter() + CongressNotifyPrototype.getRandomAlphaLetter() + CongressNotifyPrototype.getRandomAlphaLetter(),
                caseVersionTypeCd: 'A',
                caseVersionNumberId: (CongressNotifyPrototype.getRandomNumber(25) + 1).toString(),
                caseVersionStatusCd: 'A',
                versionStatusTitleNm: 'Accepted',
                calcCvTotalCaseValueAm: this.getRoundUpNumber(),
            },
            {
                userCaseId: CongressNotifyPrototype.getRandomAlphaLetter() + 'ATVFA', caseVersionTypeCd: 'B',
                caseVersionNumberId: (CongressNotifyPrototype.getRandomNumber(25) + 1).toString(),
                caseVersionStatusCd: 'R',
                versionStatusTitleNm: 'Review',
                calcCvTotalCaseValueAm: this.getRoundUpNumber(),
            }];
            for (var i = 0; i <= CongressNotifyPrototype.getRandomNumber(7); i++) {
                let numStr: string = (CongressNotifyPrototype.getRandomNumber(25) + 1).toString();
                this.mockNonDevData.push({
                    userCaseId: CongressNotifyPrototype.getRandomAlphaLetter() + CongressNotifyPrototype.getRandomAlphaLetter() + CongressNotifyPrototype.getRandomAlphaLetter() +
                        CongressNotifyPrototype.getRandomAlphaLetter() + CongressNotifyPrototype.getRandomAlphaLetter() + CongressNotifyPrototype.getRandomAlphaLetter(),
                    caseVersionNumberId: numStr ? numStr : '1',
                    caseVersionStatusCd: 'I',
                    caseVersionTypeCd: 'A',
                    versionStatusTitleNm: 'Implemented',
                    calcCvTotalCaseValueAm: this.getRoundUpNumber(),
                })
                this.mockNonDevData.push({
                    userCaseId: CongressNotifyPrototype.getRandomAlphaLetter() + CongressNotifyPrototype.getRandomAlphaLetter() + CongressNotifyPrototype.getRandomAlphaLetter() +
                        CongressNotifyPrototype.getRandomAlphaLetter() + CongressNotifyPrototype.getRandomAlphaLetter() + CongressNotifyPrototype.getRandomAlphaLetter(),
                    caseVersionNumberId: (CongressNotifyPrototype.getRandomNumber(25) + 1).toString(),
                    caseVersionTypeCd: 'M',
                    caseVersionStatusCd: 'R',
                    versionStatusTitleNm: 'Review',
                    calcCvTotalCaseValueAm: this.getRoundUpNumber(),
                })
            }
        }
        else {
            this.mockDevData = [];
            for (var x = 0; x <= CongressNotifyPrototype.getRandomNumber(10); x++) {
                this.mockDevData.push({
                    userCaseId: CongressNotifyPrototype.getRandomAlphaLetter() + CongressNotifyPrototype.getRandomAlphaLetter() + CongressNotifyPrototype.getRandomAlphaLetter() +
                        CongressNotifyPrototype.getRandomAlphaLetter() + CongressNotifyPrototype.getRandomAlphaLetter() + CongressNotifyPrototype.getRandomAlphaLetter(),
                    caseVersionTypeCd: 'B',
                    caseVersionStatusCd: 'D',
                    caseVersionNumberId: (CongressNotifyPrototype.getRandomNumber(25) + 1).toString(),
                    versionStatusTitleNm: 'Development',
                    calcCvTotalCaseValueAm: this.getRoundUpNumber(),
                })
            }
        }
    }
}