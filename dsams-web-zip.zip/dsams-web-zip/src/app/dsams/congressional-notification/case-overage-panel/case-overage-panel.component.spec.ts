import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CaseOveragePanelComponent } from './case-overage-panel.component';

describe('CaseOveragePanelComponent', () => {
  let component: CaseOveragePanelComponent;
  let fixture: ComponentFixture<CaseOveragePanelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CaseOveragePanelComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CaseOveragePanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
