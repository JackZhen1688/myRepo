import { formatCurrency } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material';
import { Subscription } from 'rxjs';
import { ICustomerCn } from '../../case/model/dto/customer-cn';
import { CaseRestfulService } from '../../case/services/case-restful.service';
import { CaseUIService } from '../../case/services/case-ui-service';
import { CaseUtils } from '../../case/utils/case-utils';
import { CongressNotifyAmountDTO } from '../case-amount-panel/model/view-case-amount';
import { CongressNotifyOverageDTO } from './model/view-case-overage';
import { CongNotificationUtils } from '../cong-notification-utils';
import { DsamsConstants } from '../../dsams.constants';
import { IEditResponseType } from '../../case/model/edit-response-type';
import { FieldDisabledMap } from '../../case/model/field-disabled-map';
import { congressionalNotificationModel } from '../cong-notification-dashboard/model/congressional-notification';
import { MessageMgr } from '../../case/validation/message-mgr';
@Component({
  selector: 'app-case-overage-panel',
  templateUrl: './case-overage-panel.component.html',
  styleUrls: ['./case-overage-panel.component.css']
})

export class CaseOveragePanelComponent implements OnInit {
  theMasterCNListData: CongressNotifyOverageDTO[] = [];

  // From amounts page
  dataSourceDevListData: CongressNotifyAmountDTO[] = [];
  theCAEntity: CongressNotifyOverageDTO = {
    totalAmountNotified: '',
    remainingBalance: '',
    totalDevCaseValueStr: '',
  };
  txtTotalCaseValue: string = '';
  columnsToDisplayCA = ['Case', 'Version', 'Status', 'Case Value'];
  totalCaseColumnsFooter = ['PlaceHolder', 'PlaceHolder1', 'Label', 'TotalCaseValue'];
  dataSourceDevListTable = new MatTableDataSource(this.dataSourceDevListData);
  totalNonDevRows: number = 0;
  totalMDEAndNonMDEAmt: number = 0;
  totalAuthorizedAllowed: number = 0;
  remainingBalanceAmt: number = 0;
  remainingAuthAmt: number = 0;
  totalOverageTaken: number = 0;

  caseUIServiceSub: Subscription;
  theCNPopupPk: ICustomerCn;

  //JS PK's
  customer_CN_OVERAGE_ID: number = 0;
  customer_CN_ID: number = 0;
  parent_CN_ID: number = 0;

  // Attributes needed from Popup
  customer_CN_ID_FROM_POPUP: number = 0;

  /* Overages Table */
  dataSourceOverageListData: CongressNotifyOverageDTO[] = [];
  dataSourceOverageListTable = new MatTableDataSource(this.dataSourceOverageListData);
  authOverageColumnsToDisplayItems = ['authNR', 'Amount', 'Reason', 'Person', 'Case', 'Version', 'Status', 'Inactive', 'DeleteRow'];
  authOverageColumnsToDisplayFooter = ['AddRow'];
  saveCaseOveragesObject: congressionalNotificationModel;

  /**
   * Editability fields
   */
  isPanelEditable: boolean = false;
  private _fieldDisabledMap: FieldDisabledMap = {};
  private editSubscription: Subscription = null;
  private newCNSubscription: Subscription = null;

  //rePopulate
  private rePopSubscription: Subscription = null;
  private congNumCdSubscription: Subscription = null;
  isCountryDisabled: boolean = true;

  constructor(private caseUIService: CaseUIService,
    private caseRestService: CaseRestfulService) { }

  ngOnDestroy() {
    if (!!this.caseUIServiceSub) {
      this.caseUIServiceSub.unsubscribe();
    }
    if (!!this.editSubscription) {
      this.editSubscription.unsubscribe();
    }
  }

  ngOnInit() {
    this.subscribeToEditService();
    this.subscribeToNewCNService();
    this.caseUIServiceSub = this.caseUIService.getCongNotificationFromPopup().subscribe(value => {
      this.totalOverageTaken = 0;
      this.theCNPopupPk = value;
      if (!!this.theCNPopupPk) {
        if (!!this.theCNPopupPk.cong_NOTIFICATION_NUMBER_CD) {
          this.remainingBalanceAmt = CongNotificationUtils.getRemainingBalanceAmt();
          this.populateCNOverage(this.theCNPopupPk.cong_NOTIFICATION_NUMBER_CD);
          //move to populateCNOverage
          this.populateCongressNotifAmounts(this.theCNPopupPk.cong_NOTIFICATION_NUMBER_CD);
          this.waitForRemainingBalanceAmt(this.remainingBalanceAmt);
          // Populate correct customer cn id from popup
          this.customer_CN_ID_FROM_POPUP = this.theCNPopupPk.customer_CN_ID;
        }
      }
    })
    this.resetForNewCong();
    }

  //get congressional Notif amounts from database
  populateCongressNotifAmounts(pPKValue: string) {
    this.theMasterCNListData = [];
    this.dataSourceDevListData = [];
    this.dataSourceDevListTable = new MatTableDataSource(this.dataSourceDevListData);
    this.caseRestService.getCongressionalNotifyCaseAmountList(pPKValue).subscribe(value => {
      this.theMasterCNListData = value;
      this.populateDataForCNList();
    },
      err => {
        CaseUtils.ReportHTTPError(err, "Getting Congressional Notify Amounts");
      }
    )
    this.dataSourceDevListTable._updateChangeSubscription();
  }

  //populate data for Non Development or Development cases
  populateDataForCNList() {
    this.theMasterCNListData.forEach(eachRow => {
      eachRow.userCaseId = CaseUtils.formatUserCaseId(eachRow.userCaseId);
      if (eachRow.caseVersionTypeCd == "B") {
        eachRow.caseVersionTypeCd = "Basic"
      }
      else {
        eachRow.caseVersionTypeCd = eachRow.caseVersionTypeCd +
          ((eachRow.caseVersionNumberId == '0') ? '' : eachRow.caseVersionNumberId);
      }
      if (eachRow.caseVersionStatusCd == "D") {
        this.dataSourceDevListData.push(eachRow);
      }
    })
    if (this.dataSourceDevListData.length <= 0) {
      this.dataSourceDevListData = [{
        userCaseId: '', caseVersionTypeCd: '', versionStatusTitleNm: '', calcCvTotalCaseValueAmStr: ''
      }];
    }
    this.dataSourceDevListTable = new MatTableDataSource(this.dataSourceDevListData);
    this.getTotalCaseValueAmount(this.dataSourceDevListTable.data, true);
    this.getAllAmounts();
  }

  //sum total amount of all non-mde and mde amounts
  getAllAmounts() {
    this.caseUIService.getSummaryNotifyPanelData().forEach(eachRow => {
      if (!!eachRow) {
        this.totalMDEAndNonMDEAmt = 0;
        eachRow.forEach(eachNestedRow => {
          this.totalMDEAndNonMDEAmt += eachNestedRow.totalCostAmount;
        })
        this.theCAEntity.totalAmountNotified = formatCurrency(this.totalMDEAndNonMDEAmt, 'en', '$', 'USD', '1.0-0');
        this.totalAuthorizedAllowed = this.totalMDEAndNonMDEAmt / 10;
        this.remainingAuthAmt = this.totalAuthorizedAllowed - this.totalOverageTaken;
        CongNotificationUtils.setRemainingAuthBalanceAmt(this.remainingAuthAmt);
        this.theCAEntity.totalAuthAllowedAmStr = formatCurrency(this.totalAuthorizedAllowed, 'en', '$', 'USD', '1.0-0');
        this.theCAEntity.remainingAuthAmtStr = formatCurrency(this.remainingAuthAmt, 'en', '$', 'USD', '1.0-0');
      }
    })
  }

  //calculate total case amount
  getTotalCaseValueAmount(pList: CongressNotifyOverageDTO[], pDev: boolean) {
    var totalNum: number = 0;
    pList.forEach((eachRow) => {
      if (!CaseUtils.isBlankStr(eachRow.userCaseId)) {
        totalNum = eachRow.calcCvTotalCaseValueAm + totalNum;
        //format the case value
        eachRow.calcCvTotalCaseValueAmStr = formatCurrency(eachRow.calcCvTotalCaseValueAm, 'en', '$', 'USD', '1.0-0');
      }
    })
    if (pDev) {
      this.theCAEntity.totalDevCaseValue = totalNum;
      this.theCAEntity.totalDevCaseValueStr = formatCurrency(totalNum, 'en', '$', 'USD', '1.0-0');
    }
  }

  // Get data for Overage Gird
  populateCNOverage(pPKValue: string) {
    this.dataSourceOverageListData = [];
    this.caseRestService.getCongressionalNotifyCaseOverageList(pPKValue).subscribe(value => {
      this.dataSourceOverageListData = value;
      this.caseUIService.getCongressionalNotificationData().forEach(object => {
        this.saveCaseOveragesObject = object;
        this.saveCaseOveragesObject = { congressNotifyOverageList: [] };
      })
      for (let i = 0; i < this.dataSourceOverageListData.length; i++) {
        this.dataSourceOverageListData[i].status = DsamsConstants.ENT_UNCHANGED.toString();
        this.dataSourceOverageListData[i].congNotificationOverageNum = i + 1;
        this.dataSourceOverageListData[i].cn_OVERAGE_AM_STR =
          formatCurrency(this.dataSourceOverageListData[i].cn_OVERAGE_AM, 'en', '$', 'USD', '1.0-0');
        if (!this.dataSourceOverageListData[i].cust_OVG_INACTIVE_IN) {
          this.totalOverageTaken = this.totalOverageTaken + this.dataSourceOverageListData[i].cn_OVERAGE_AM;
        }
        this.dataSourceOverageListData[i].isFieldDisabled = { ['OverageDelete']: true }
        this.dataSourceOverageListData[i].isFieldDisabled = { ['OverageInactive']: true }
        this.dataSourceOverageListData[i].userCaseId = this.dataSourceOverageListData[i].user_CASE_ID;
      }
      this.saveCaseOveragesObject.congressNotifyOverageList = this.dataSourceOverageListData;
      this.caseUIService.setCongressionalNotificationData(this.saveCaseOveragesObject);
      this.caseUIService.setCongressionalNotificationOveragesData(this.dataSourceOverageListData);
      this.dataSourceOverageListTable = new MatTableDataSource(this.dataSourceOverageListData);
      this.dataSourceOverageListTable._updateChangeSubscription();
    },
      err => {
        CaseUtils.ReportHTTPError(err, "Getting Congressional Notify Overage");
      }
    )
  }

  /* Add Button in the Overage Grid */
  addItem(): void {
    let lastOverageNo: number = 0;
    let attAddIndex: number = 0;
    let congNotificationNumCdString: string = '';
    if (!!this.dataSourceOverageListData) {
      for (let i = 0; i < this.dataSourceOverageListData.length; i++) {
        if (this.dataSourceOverageListData[i].congNotificationOverageNum > lastOverageNo) {
          lastOverageNo = this.dataSourceOverageListData[i].congNotificationOverageNum;
        }
        this.customer_CN_OVERAGE_ID = this.dataSourceOverageListData[i].customer_CN_OVERAGE_ID;
        this.customer_CN_ID = this.dataSourceOverageListData[i].customer_CN_ID;
        this.parent_CN_ID = CongNotificationUtils.getParentCNId();  
      }
      attAddIndex = this.dataSourceOverageListData.length;
    }

    // To fix error on add new on summary panel on new CN
    if (!!this.theCNPopupPk) {
      congNotificationNumCdString = this.theCNPopupPk.cong_NOTIFICATION_NUMBER_CD;
    }

    const anItemObject: CongressNotifyOverageDTO =
    {
      isFieldDisabled: { ['OverageDelete']: false, ['OverageInactive']: false },
      // Specific to Overage Grid
      congNotificationOverageNum: attAddIndex + 1,
      congNotificationNumberCD: congNotificationNumCdString,
      person_FIRST_NM: sessionStorage.getItem('firstNm'),
      person_LAST_NM: sessionStorage.getItem('lastNm'),
      //JS - PK's
      customer_CN_OVERAGE_ID: null,
      parent_CN_ID: this.parent_CN_ID,

      customer_CN_ID: (this.parent_CN_ID === 0 || this.parent_CN_ID === null) ? CongNotificationUtils.getCustomerCNId() : this.parent_CN_ID,
      //these are required fields
      overage_REASON_TX: '',
      overageInactiveBoolean: false,
      status: DsamsConstants.ENT_NEW.toString(),
    };


    // if the list is intially empty
    if (this.dataSourceOverageListData == null) {
      this.dataSourceOverageListData = [];
    }
    this.dataSourceOverageListData.push(anItemObject);
    this.saveCaseOveragesObject.congressNotifyOverageList = this.dataSourceOverageListData;
    this.caseUIService.setCongressionalNotificationData(this.saveCaseOveragesObject);
    this.dataSourceOverageListTable = new MatTableDataSource(this.dataSourceOverageListData);
    //refresh the table
    this.dataSourceOverageListTable._updateChangeSubscription();

    const editResp: IEditResponseType = { ID: DsamsConstants.CONGRESSIONAL_NOTIFICATION_EDITOR, editToggle: true };
    this.caseUIService.hasEditBeenMadeService.next(editResp);
  }

  /* This procedure checks the returned result value from the popover Yes/No dialog window. */
  yesButtonOnClick(isDeleteConfirmed: any, rowElement: any) {
    if (isDeleteConfirmed)
      this.deleteItem(rowElement);
  }

  /* Delete a row from the Overage Grid */
  deleteItem(rowElement: any) {
    let rowIndex = this.dataSourceOverageListData.indexOf(rowElement);
    this.dataSourceOverageListData.splice(rowIndex, 1);

    this.dataSourceOverageListTable = new MatTableDataSource(this.dataSourceOverageListData);
    this.dataSourceOverageListTable._updateChangeSubscription();
  }

  // Need timeout for asynchronous calls
  waitForRemainingBalanceAmt(pRemainingBalanceAmt: number) {
    if (!!pRemainingBalanceAmt) {
      this.remainingBalanceAmt = CongNotificationUtils.getRemainingBalanceAmt();
      this.theCAEntity.remainingBalance = formatCurrency(this.remainingBalanceAmt, 'en', '$', 'USD', '1.0-0');
      CongNotificationUtils.setRemainingBalanceAmt(null);
      this.remainingBalanceAmt = null;
    }
    else {
      this.remainingBalanceAmt = CongNotificationUtils.getRemainingBalanceAmt();
      setTimeout(() => {
        this.waitForRemainingBalanceAmt(this.remainingBalanceAmt);
      }, 1000);
    }
  }

  onCheckboxChange(element: any, event: any) {
    let rowIndex = this.dataSourceOverageListData.indexOf(element);
    this.dataSourceOverageListData[rowIndex].cust_OVG_INACTIVE_IN = element.cust_OVG_INACTIVE_IN;
    this.dataSourceOverageListTable = new MatTableDataSource(this.dataSourceOverageListData);
  }

  /*---------------------------------------------- Edit Toggle --------------------------------------------*/
  // Subscribe to edit service
  private subscribeToEditService() {
    this.editSubscription = this.caseUIService.caseEditService.subscribe((pEditResult: IEditResponseType) => {
      if (!!pEditResult && pEditResult.ID === DsamsConstants.CONGRESSIONAL_NOTIFICATION_EDITOR) {
        this.isPanelEditable = pEditResult.editToggle;
      }
      this.enableOrDisableFields();
    });
  }

  // Determine if a field is disabled.
  isFieldDisabled(pElement: any, pFieldName: string): boolean {
    // Is whole panel disabled?
    // if (!this.isPanelEditable) {
    //   return true;
    // }
    if (!!pElement && pElement.isDisabled) {
      return true;
    }
    return this._fieldDisabledMap[pFieldName];
  }

  // Enable or disable fields according to toggle.
  private enableOrDisableFields() {

    const disabledState: boolean = !this.isPanelEditable;
    // if edit is on, disabledState is false

    this.dataSourceOverageListData.forEach((eachCaseOverage: CongressNotifyOverageDTO) => {
      if (!!eachCaseOverage.isFieldDisabled) {
        eachCaseOverage.isFieldDisabled = {};
      }
      if (disabledState) {
        eachCaseOverage.isFieldDisabled['OverageDelete'] = (disabledState);
        eachCaseOverage.isFieldDisabled['OverageInactive'] = (disabledState);
      }
      else {
        eachCaseOverage.isFieldDisabled['OverageInactive'] = (disabledState);
      }
    });
  }

  /**
 * Set the field changed so that the edit toggle is notified.
 */
  setChanged(index: number) {
    const editResp: IEditResponseType = { ID: DsamsConstants.CONGRESSIONAL_NOTIFICATION_EDITOR, editToggle: true };
    this.caseUIService.hasEditBeenMadeService.next(editResp);
    if (!!this.dataSourceOverageListData[index]) {
      if (this.dataSourceOverageListData[index].status == DsamsConstants.ENT_UNCHANGED.toString()) {
        this.dataSourceOverageListData[index].status = DsamsConstants.ENT_CHANGED.toString();
      }
      // Set the IA and Service DB
      for (let j = 0; j < this.dataSourceDevListData.length; j++) {
        if (this.dataSourceOverageListData[index].case_ID == this.dataSourceDevListData[j].caseId && this.dataSourceOverageListData[index].case_VERSION_ID == this.dataSourceDevListData[j].caseVersionId) {
          console.log("*** match found for index: " + index);
          this.dataSourceOverageListData[index].implementing_AGENCY_ID = this.dataSourceDevListData[j].implementing_AGENCY_ID;
          console.log(" this.dataSourceOverageListData[index].implementing_AGENCY_ID ", this.dataSourceOverageListData[index].implementing_AGENCY_ID);
          this.dataSourceOverageListData[index].service_DB_ID = this.dataSourceDevListData[j].service_DB_ID;
          console.log(" this.dataSourceOverageListData[index].service_DB_ID ", this.dataSourceOverageListData[index].service_DB_ID);
        }
      }
    }
    this.saveCaseOveragesObject.congressNotifyOverageList = this.dataSourceOverageListData;
    this.caseUIService.setCongressionalNotificationData(this.saveCaseOveragesObject);
    this.caseUIService.setCongressionalNotificationOveragesData(this.dataSourceOverageListData);
  }
  private subscribeToNewCNService() {
    this.newCNSubscription = this.caseUIService.isNewCongNotification.subscribe((value) => {
      if (value) {
        this.isPanelEditable = true;
      }
    });
  }
  resetForNewCong() {
    this.newCNSubscription = this.caseUIService.isNewCongNotification.subscribe((value) => {
      if (value) {
        this.dataSourceOverageListData = [];
        this.dataSourceDevListData = [];
        this.dataSourceOverageListTable = new MatTableDataSource(this.dataSourceOverageListData);
        this.dataSourceDevListTable = new MatTableDataSource(this.dataSourceDevListData);
        this.theCAEntity.totalAmountNotified = '';
        this.theCAEntity.remainingBalance = '';
        this.theCAEntity.totalAuthAllowedAmStr = '';
        this.theCAEntity.remainingAuthAmtStr = '';

      }
    });

  }
  clickOnDevRow(element: any, i: any) {
    if (!!this.dataSourceOverageListData) {
      let lastIndex = this.dataSourceOverageListData.length - 1;
      if (this.isPanelEditable && this.dataSourceOverageListData[lastIndex].status == DsamsConstants.ENT_NEW.toString()) {
        let indexOfNew = this.dataSourceOverageListData.length - 1;
        this.dataSourceOverageListData[indexOfNew].case_ID = element.caseId;
        this.dataSourceOverageListData[indexOfNew].case_VERSION_ID = element.caseVersionId;
        this.dataSourceOverageListData[indexOfNew].userCaseId = element.userCaseId;
        this.dataSourceOverageListData[indexOfNew].version = element.caseVersionTypeCd;
        this.dataSourceOverageListData[indexOfNew].implementing_AGENCY_ID = element.implementing_AGENCY_ID;
        this.dataSourceOverageListData[indexOfNew].service_DB_ID = element.service_DB_ID;
      }

    }

  }

   onCancelPopulateData() {
    this.rePopSubscription = this.caseUIService.isRepopulateData.subscribe((value) => {
      if (value) {
        this.caseUIServiceSub = this.caseUIService.getCongNotificationFromPopup().subscribe(data => {
          this.totalOverageTaken = 0;
          this.theCNPopupPk = data;
          if(data) {
          if (!!this.theCNPopupPk) {
            if (!!this.theCNPopupPk.cong_NOTIFICATION_NUMBER_CD) {
              this.remainingBalanceAmt = CongNotificationUtils.getRemainingBalanceAmt();
              this.populateCNOverage(this.theCNPopupPk.cong_NOTIFICATION_NUMBER_CD);
              //move to populateCNOverage
              this.populateCongressNotifAmounts(this.theCNPopupPk.cong_NOTIFICATION_NUMBER_CD);
              this.waitForRemainingBalanceAmt(this.remainingBalanceAmt);
              // Populate correct customer cn id from popup
              this.customer_CN_ID_FROM_POPUP = this.theCNPopupPk.customer_CN_ID;
            }
          }
          this.caseUIService.setCongressionalNotificationOveragesData(this.dataSourceOverageListData);
          this.isCountryDisabled = false;
        }})
      }
    });
  }

  isOverageAmountValid(pElement: any): boolean {
    if (!!this.remainingAuthAmt && this.remainingAuthAmt < parseInt(pElement.cn_OVERAGE_AM_STR)) {
      MessageMgr.displayErrorMessage("Unable to accept this overage amount (" + formatCurrency(pElement.cn_OVERAGE_AM_STR, 'en', '$', 'USD', '1.0-0') 
      + "), it exceeds the remaining authorization balance.");
      return false;
    }
    return true;
  }
}

