import { FieldDisabledMap } from "src/app/dsams/case/model/field-disabled-map";
import { DsamsConstants } from "src/app/dsams/dsams.constants";
import { CongNotificationUtils } from '../../cong-notification-utils';

export interface CongressNotifyOverageDTO {
    userCaseId?: string,
    caseVersionTypeCd?: string,
    version_STATUS_TITLE_NM?: string,
    calcCvTotalCaseValueAmStr?: string,
    calcCvTotalCaseValueAm?: number,
    calc_CV_TOTAL_CASE_VALUE_AM?: number,
    caseVersionNumberId?: string,
    caseVersionStatusCd?: string,
    CvPrevTotalCaseValueAm?: number,
    CvTotalCaseValueAm?: number,
    totalAmountNotified?: string,
    remainingBalance?: string,
    totalDevCaseValue?: number,
    totalDevCaseValueStr?: string,
    totalAuthAllowedAm?: number,
    totalAuthAllowedAmStr?: string,
    remainingAuthAmt?: number,
    remainingAuthAmtStr?: string,

    // Specific to Overage Grid
    congNotificationOverageNum?: number,
    congNotificationNumberCD?: string,
    master_CONG_NOTIF_NUMBER_CD?: string,
    cn_OVERAGE_AM?: number,
    cn_OVERAGE_AM_STR?: string,
    sum_MASTER_CN_OVER_AM?: number,
    sum_MASTER_CN_OVER_AM_STR?: string,
    person_FIRST_NM?: string,
    person_LAST_NM?: string,
    personFullName?: string,
    calcCvTotalCaseValueAmount?: number,
    calcCvTotalCaseValueAmountStr?: string,
    overageInactive?: number,
    cust_OVG_INACTIVE_IN?: boolean,
    overageInactiveBoolean?: boolean,
    overage_REASON_TX?: string,
    ten_PCT_OVERAGE_AM?: number,
    user_CASE_ID?: string,
    version?: string,
    case_VERSION_STATUS_CD?: string,
    //DH -added pk for existing row
    customer_CN_OVERAGE_ID?: number,
    customer_CN_ID?: number,
    parent_CN_ID?: number,
    // Added for Case and Version
    case_ID?: number,
    case_VERSION_ID?: number,
    // Added for service DB
    implementing_AGENCY_ID?: string,
    service_DB_ID?: string,

    // Edit fields
    status?: string,
    isFieldDisabled?: FieldDisabledMap,
}

/** 
  * Prepare Customer CN Overages data for save
  * @Author: David Huynh
  * @Date: 01/27/2022
  * @Jira Card: 4971
*/
export interface CustomerCnOveragesModel {
    cn_OVERAGE_AM?: number,
    cn_OVERAGE_AM_STR?: string,
    customer_CN_OVERAGE_ID?: number,
    overage_REASON_TX?: string,
    inactive_IN?: boolean,
    status?: string;
    lockSessionId?: string,
    customer_CN_ID?: number,
    caseCnOverageList?: CaseCnOveragesModel[],
}

export interface CaseCnOveragesModel {
    customer_CN_OVERAGE_ID?: number,
    customer_CN_ID?: number,
    case_ID?: number,
    case_VERSION_ID?: number,
    inactive_IN?: boolean,
    status?: string;
    lockSessionId?: string,
    // Added for service DB
    implementing_AGENCY_ID?: string,
    service_DB_ID?: string,
}

export class PrepareCustomerCNOveragesDataForSave {
    theModelEntityList: CustomerCnOveragesModel[] = [];
    aDTOEntity: CustomerCnOveragesModel = null;
    aNestedDTOEntity: CaseCnOveragesModel = null;
    constructor(pDTOList: CongressNotifyOverageDTO[]) {
        this.theModelEntityList = [];
        pDTOList.forEach(eachDto => {
            if (!!eachDto.status && eachDto.status !== DsamsConstants.ENT_UNCHANGED.toString()) {
                this.aDTOEntity = {
                    customer_CN_OVERAGE_ID: eachDto.customer_CN_OVERAGE_ID ? eachDto.customer_CN_OVERAGE_ID: null,
                    customer_CN_ID: CongNotificationUtils.getParentCNId() != 0 ? CongNotificationUtils.getParentCNId(): CongNotificationUtils.getCustomerCNId(),
                    cn_OVERAGE_AM: eachDto.cn_OVERAGE_AM_STR ? parseInt(PrepareCustomerCNOveragesDataForSave.removeDollarSign(eachDto.cn_OVERAGE_AM_STR)): 0,
                    inactive_IN: eachDto.cust_OVG_INACTIVE_IN ? eachDto.cust_OVG_INACTIVE_IN: false,
                    overage_REASON_TX: eachDto.overage_REASON_TX ? eachDto.overage_REASON_TX : '',
                    status: eachDto.status,
                    caseCnOverageList:[],
                };
                this.aDTOEntity.caseCnOverageList.push(new PrepareCaseCNOveragesDataForSave(eachDto).theDTOEntity);
                this.theModelEntityList.push(this.aDTOEntity);
            }
        })
    }

    /* This method converts currency to string for calculation */
    public static removeDollarSign(pVal: string): string {
        // Strip off dollar sign
        if (!!pVal)
            return (pVal.replace(/[^0-9.-]+/g, ""));
        else return (pVal);
    }
}

/** 
  * Prepare Case CN Overages data for save
  * @Author: David Huynh
  * @Date: 01/27/2022
  * @Jira Card: 5021
*/
export class PrepareCaseCNOveragesDataForSave {
    theDTOEntity: CaseCnOveragesModel = null;
    constructor(eachDto: CongressNotifyOverageDTO) {
        if (!!eachDto.status && eachDto.status !== DsamsConstants.ENT_UNCHANGED.toString()) {
            this.theDTOEntity = {
                customer_CN_OVERAGE_ID: eachDto.customer_CN_OVERAGE_ID ? eachDto.customer_CN_OVERAGE_ID: null,
                customer_CN_ID: eachDto.customer_CN_ID,
                case_ID: eachDto.case_ID,
                case_VERSION_ID: eachDto.case_VERSION_ID,
                inactive_IN: eachDto.cust_OVG_INACTIVE_IN ? eachDto.cust_OVG_INACTIVE_IN: false,
               status: eachDto.status,
                // Added for service DB
                implementing_AGENCY_ID: eachDto.implementing_AGENCY_ID,
                service_DB_ID: eachDto.service_DB_ID,
            };
        }
    }
}