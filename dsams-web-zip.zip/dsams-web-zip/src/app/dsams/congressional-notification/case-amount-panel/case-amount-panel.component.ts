import { formatCurrency } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material';
import { Subscription } from 'rxjs';
import { ICustomerCn } from '../../case/model/dto/customer-cn';
import { CaseRestfulService } from '../../case/services/case-restful.service';
import { CaseUIService } from '../../case/services/case-ui-service';
import { CaseUtils } from '../../case/utils/case-utils';
import { CongNotificationUtils } from '../cong-notification-utils';
import { CongressNotifyAmountDTO } from './model/view-case-amount';
@Component({
  selector: 'app-case-amount-panel',
  templateUrl: './case-amount-panel.component.html',
  styleUrls: ['./case-amount-panel.component.css']
})

export class CaseAmountPanelComponent implements OnInit {
  theMasterCNListData: CongressNotifyAmountDTO[] = [];
  dataSourceNonDevListData: CongressNotifyAmountDTO[] = [];
  dataSourceDevListData: CongressNotifyAmountDTO[] = [];
  theCAEntity: CongressNotifyAmountDTO = {
    totalAmountNotified: '',
    remainingBalance: '',
    totalDevCaseValueStr: '',
    totalNonDevCaseValueStr: '',
  };
  txtTotalCaseValue: string = '';
  columnsToDisplayCA = ['Case', 'Version', 'Status', 'Case Value'];
  totalCaseColumnsFooter = ['PlaceHolder', 'PlaceHolder1', 'Label', 'TotalCaseValue'];
  dataSourceNonDevListTable = new MatTableDataSource(this.dataSourceNonDevListData);
  dataSourceDevListTable = new MatTableDataSource(this.dataSourceDevListData);
  totalNonDevRows: number = 0;
  totalMDEAndNonMDEAmt: number = 0;
  remainingBalanceAmt: number = 0;

  caseUIServiceSub: Subscription;
  theCNPopupPk: ICustomerCn;
  private newCNSubscription: Subscription = null;

  //rePopulate
  private rePopSubscription: Subscription = null;
  private congNumCdSubscription: Subscription = null;
  isCountryDisabled: boolean = true;

  constructor(private caseUIService: CaseUIService,
    private caseRestService: CaseRestfulService) { }

  ngOnDestroy() {
    if (!!this.caseUIServiceSub) {
      this.caseUIServiceSub.unsubscribe();
    }
  }

  ngOnInit() {
    this.caseUIServiceSub = this.caseUIService.getCongNotificationFromPopup().subscribe(value => {
      this.theCNPopupPk = value;
      if (!!this.theCNPopupPk)
        if (!!this.theCNPopupPk.cong_NOTIFICATION_NUMBER_CD) {
          this.populateCongressNotifAmounts(this.theCNPopupPk.cong_NOTIFICATION_NUMBER_CD);
        }
    })
    this.resetForNewCong();
     }

  initializeAttibuteValues(){
    this.theMasterCNListData = [];
    this.dataSourceDevListData = [];
    this.dataSourceNonDevListData = [];
    this.dataSourceDevListTable = new MatTableDataSource(this.dataSourceDevListData);
    this.dataSourceNonDevListTable = new MatTableDataSource(this.dataSourceNonDevListData);
    this.theCAEntity.totalAmountNotified = '';
    this.theCAEntity.remainingBalance = '';
    this.theCAEntity.totalNonDevCaseValueStr = '';
  }

  //get congressional Notif amounts from database
  populateCongressNotifAmounts(pPKValue: string) {
    this.initializeAttibuteValues();
    this.caseRestService.getCongressionalNotifyCaseAmountList(pPKValue).subscribe(value => {
      this.theMasterCNListData = value;
      this.populateDataForCNList();
    },
      err => {
        CaseUtils.ReportHTTPError(err, "Getting Congressional Notify Amounts");
      }
    )
    this.dataSourceDevListTable._updateChangeSubscription();
  }

  //populate data for Non Development or Development cases
  populateDataForCNList() {
    this.theMasterCNListData.forEach(eachRow => {
      eachRow.userCaseId = CaseUtils.formatUserCaseId(eachRow.userCaseId);
      if (eachRow.caseVersionTypeCd == "B")
        eachRow.caseVersionTypeCd = "Basic"
      else
        eachRow.caseVersionTypeCd = eachRow.caseVersionTypeCd +
          ((eachRow.caseVersionNumberId == '0') ? '' : eachRow.caseVersionNumberId);
      if (eachRow.caseVersionStatusCd == "D")
        this.dataSourceDevListData.push(eachRow);
      else this.dataSourceNonDevListData.push(eachRow);
    })
    //per Analyst request, display at least 1 empty row if it has no data
    if (this.dataSourceNonDevListData.length <= 0) {
      this.dataSourceNonDevListData = [{
        userCaseId: '', caseVersionTypeCd: '', versionStatusTitleNm: '', calcCvTotalCaseValueAmStr: ''
      }];
    }
    if (this.dataSourceDevListData.length <= 0) {
      this.dataSourceDevListData = [{
        userCaseId: '', caseVersionTypeCd: '', versionStatusTitleNm: '', calcCvTotalCaseValueAmStr: ''
      }];
    }
    this.dataSourceNonDevListTable = new MatTableDataSource(this.dataSourceNonDevListData);
    this.getTotalCaseValueAmount(this.dataSourceNonDevListTable.data, false);
    this.dataSourceDevListTable = new MatTableDataSource(this.dataSourceDevListData);
    this.getTotalCaseValueAmount(this.dataSourceDevListTable.data, true);
    this.theCAEntity.totalAmountNotified = formatCurrency(CongNotificationUtils.getTotalMDEAndNonMDEAmt(), 'en', '$', 'USD', '1.0-0');
    this.remainingBalanceAmt = CongNotificationUtils.getTotalMDEAndNonMDEAmt() - this.theCAEntity.totalNonDevCaseValue;
    this.theCAEntity.remainingBalance = formatCurrency(this.remainingBalanceAmt, 'en', '$', 'USD', '1.0-0');
    CongNotificationUtils.setRemainingBalanceAmt(this.remainingBalanceAmt);
  }

  //sum total amount of all non-mde and mde amounts
  getAllAmounts() {
    this.caseUIService.getSummaryNotifyPanelData().forEach(eachRow => {
      if (!!eachRow) {
        this.totalMDEAndNonMDEAmt = 0;
        eachRow.forEach(eachNestedRow => {
          this.totalMDEAndNonMDEAmt += eachNestedRow.totalCostAmount;
        })
        this.remainingBalanceAmt = this.totalMDEAndNonMDEAmt - this.theCAEntity.totalNonDevCaseValue;
        CongNotificationUtils.setTotalMDEAndNonMDEAmt(this.totalMDEAndNonMDEAmt);
        this.theCAEntity.totalAmountNotified = formatCurrency(this.totalMDEAndNonMDEAmt, 'en', '$', 'USD', '1.0-0');
        this.theCAEntity.remainingBalance = formatCurrency(this.remainingBalanceAmt, 'en', '$', 'USD', '1.0-0');
      }
    })
  }

  //calculate total case amount
  getTotalCaseValueAmount(pList: CongressNotifyAmountDTO[], pDev: boolean) {
    var totalNum: number = 0;
    pList.forEach((eachRow) => {
      if (!CaseUtils.isBlankStr(eachRow.userCaseId)) {
        totalNum = eachRow.calcCvTotalCaseValueAm + totalNum;
        //format the case value
        eachRow.calcCvTotalCaseValueAmStr = formatCurrency(eachRow.calcCvTotalCaseValueAm, 'en', '$', 'USD', '1.0-0');
      }
    })
    if (pDev) {
      this.theCAEntity.totalDevCaseValue = totalNum;
      this.theCAEntity.totalDevCaseValueStr = formatCurrency(totalNum, 'en', '$', 'USD', '1.0-0');
    }
    else {
      this.theCAEntity.totalNonDevCaseValue = totalNum;
      this.theCAEntity.totalNonDevCaseValueStr = formatCurrency(totalNum, 'en', '$', 'USD', '1.0-0');
    }
  }

  resetForNewCong() {
    this.newCNSubscription = this.caseUIService.isNewCongNotification.subscribe((value) => {
      if (value) this.initializeAttibuteValues();
    });
  }

  
  onCancelPopulateData() {
    this.rePopSubscription = this.caseUIService.isRepopulateData.subscribe((value) => {
      if (value) {
        this.caseUIServiceSub = this.caseUIService.getCongNotificationFromPopup().subscribe(data => {
          this.theCNPopupPk = data;
          if (data) {
          this.populateCongressNotifAmounts(this.theCNPopupPk.cong_NOTIFICATION_NUMBER_CD);
          this.isCountryDisabled = false;
        }
      })
      }
    });
  }

}

