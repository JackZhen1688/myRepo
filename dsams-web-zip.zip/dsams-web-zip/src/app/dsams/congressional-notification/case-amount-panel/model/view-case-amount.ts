import { DsamsConstants } from "src/app/dsams/dsams.constants";
import { summaryNotifyDto } from "../../summary-notify-panel/model/dto/summary-notify-dto";

export interface CongressNotifyAmountDTO {
    userCaseId?: string,
    caseVersionTypeCd?: string,
    versionStatusTitleNm?: string,
    calcCvTotalCaseValueAmStr?: string,
    calcCvTotalCaseValueAm?: number,
    caseVersionId?: number,
    caseVersionNumberId?: string,
    caseVersionStatusCd?: string,
    caseId?: number,
    CvPrevTotalCaseValueAm?: number,
    CvTotalCaseValueAm?: number,
    totalAmountNotified?: string,
    remainingBalance?: string,
    totalDevCaseValue?: number,
    totalNonDevCaseValue?: number,
    totalDevCaseValueStr?: string,
    totalNonDevCaseValueStr?: string,
    implementing_AGENCY_ID?: string,
    service_DB_ID?: string,
    status?: string;
}

export interface CustomerCnAmountModel {
    customer_CN_AM_ID?: number,
    customer_CN_ID?: number,
    mde_AM?: number,
    non_MDE_AM?:number,
    status?: string;
    lockSessionId?: string,
}

export class PrepareCustomerCNAmountDataForSave {
    theDTOEntity: CustomerCnAmountModel = null;
    constructor(eachDto: summaryNotifyDto) {
        console.log('prepare Customer CN Amount data for save',eachDto )
        if (!!eachDto.status && eachDto.status !== DsamsConstants.ENT_UNCHANGED.toString()) {
            this.theDTOEntity = {
                customer_CN_ID: eachDto.primeCCCustomerCNID, 
                customer_CN_AM_ID:eachDto.primeCUCACustomerCNAMID, 
                mde_AM: parseInt(eachDto.mdeAM),
                non_MDE_AM: parseInt(eachDto.nonMDEAM),
                status: eachDto.status,
             };
        }
    }
}
export interface CaseCnAmountModel {
    case_CN_AM_ID?: number,
    customer_CN_AM_ID?: number,
    customer_CN_ID?: number,
    case_ID?: number,
    case_VERSION_ID?: number,
    case_VERSION_CD?: string,
    case_CN_AM_COMMENT_TX?: string,
    status?: string;
    lockSessionId?: string,
    implementing_AGENCY_ID?: string,
    service_DB_ID?: string,
}
export class PrepareCaseCNAmountDataForSave {
    theDTOEntity: CaseCnAmountModel = null;
    constructor(eachDto: summaryNotifyDto) {
        if (!!eachDto.status && eachDto.status !== DsamsConstants.ENT_UNCHANGED.toString()) {
            this.theDTOEntity = {
                //Need these columns to be populated
                //case_CN_AM_ID: eachDto.,
                //customer_CN_ID: eachDto.,
                //case_VERSION_CD
                //implementing_AGENCY_ID: eachDto.implementing_AGENCY_ID,
                //service_DB_ID: eachDto.service_DB_ID,
                //case_ID: eachDto.,
                //case_VERSION_ID: parseInt(eachDto.caseVersionNumberId),
                status: eachDto.status,
             };
        }
    }
}

//********************************************** */


/* This class is used to generate random data set for UI unit testing purposes.
 * Author: David Huynh
 * Date: 12/20/2002
 * Jira Card: 4935 
 * */
export class CongressNotifyPrototype {
    mockNonDevData: CongressNotifyAmountDTO[];
    mockDevData: CongressNotifyAmountDTO[];
    //return a random number based on a passing range
    public static getRandomNumber(pRange: number): number {
        var byteArray = new Uint8Array(1);
        window.crypto.getRandomValues(byteArray);
        return Math.floor(byteArray[0] % pRange);
    }

    //return a random letter in within the given string
    public static getRandomAlphaLetter(): string {
        var alphabeticalString: string = '123456789ABCDEFGHKLMNOPQRSTUVWXYZ';
        return alphabeticalString.charAt(CongressNotifyPrototype.getRandomNumber(33));
    }
    //rouding up values to 2 digit decimal
    getRoundUpNumber(): number {
        return (Math.round((CongressNotifyPrototype.getRandomNumber(1000000) + 1 / 100 +
            CongressNotifyPrototype.getRandomNumber(1000) / 100 + Number.EPSILON) * 100));
    }
    constructor(pNonDev: boolean) {
        if (pNonDev) {
            this.mockNonDevData = [{
                userCaseId: CongressNotifyPrototype.getRandomAlphaLetter() + 'TBCA' + CongressNotifyPrototype.getRandomAlphaLetter(),
                caseVersionTypeCd: 'B',
                caseVersionNumberId: (CongressNotifyPrototype.getRandomNumber(25) + 1).toString(),
                caseVersionStatusCd: 'I',
                versionStatusTitleNm: 'Implemented',
                calcCvTotalCaseValueAm: this.getRoundUpNumber(),
            },
            {
                userCaseId: CongressNotifyPrototype.getRandomAlphaLetter() + 'TBCA' + CongressNotifyPrototype.getRandomAlphaLetter(),
                caseVersionTypeCd: 'M',
                caseVersionNumberId: (CongressNotifyPrototype.getRandomNumber(25) + 1).toString(),
                caseVersionStatusCd: 'X',
                versionStatusTitleNm: 'Cancelled',
                calcCvTotalCaseValueAm: this.getRoundUpNumber(),
            },
            {
                userCaseId: CongressNotifyPrototype.getRandomAlphaLetter() + 'SBVA' + CongressNotifyPrototype.getRandomAlphaLetter(),
                caseVersionTypeCd: 'A',
                caseVersionNumberId: (CongressNotifyPrototype.getRandomNumber(25) + 1).toString(),
                caseVersionStatusCd: 'O',
                versionStatusTitleNm: 'Offered',
                calcCvTotalCaseValueAm: this.getRoundUpNumber(),
            },
            {
                userCaseId: CongressNotifyPrototype.getRandomAlphaLetter() + 'LABE' + CongressNotifyPrototype.getRandomAlphaLetter(),
                caseVersionTypeCd: 'M',
                caseVersionNumberId: (CongressNotifyPrototype.getRandomNumber(25) + 1).toString(),
                caseVersionStatusCd: 'W',
                versionStatusTitleNm: 'Writing',
                calcCvTotalCaseValueAm: this.getRoundUpNumber(),
            },
            {
                userCaseId: CongressNotifyPrototype.getRandomAlphaLetter() + CongressNotifyPrototype.getRandomAlphaLetter() + CongressNotifyPrototype.getRandomAlphaLetter() +
                    CongressNotifyPrototype.getRandomAlphaLetter() + CongressNotifyPrototype.getRandomAlphaLetter() + CongressNotifyPrototype.getRandomAlphaLetter(),
                caseVersionTypeCd: 'A',
                caseVersionNumberId: (CongressNotifyPrototype.getRandomNumber(25) + 1).toString(),
                caseVersionStatusCd: 'A',
                versionStatusTitleNm: 'Accepted',
                calcCvTotalCaseValueAm: this.getRoundUpNumber(),
            },
            {
                userCaseId: CongressNotifyPrototype.getRandomAlphaLetter() + 'ATVFA', caseVersionTypeCd: 'B',
                caseVersionNumberId: (CongressNotifyPrototype.getRandomNumber(25) + 1).toString(),
                caseVersionStatusCd: 'R',
                versionStatusTitleNm: 'Review',
                calcCvTotalCaseValueAm: this.getRoundUpNumber(),
            }];
            for (var i = 0; i <= CongressNotifyPrototype.getRandomNumber(7); i++) {
                let numStr: string = (CongressNotifyPrototype.getRandomNumber(25) + 1).toString();
                this.mockNonDevData.push({
                    userCaseId: CongressNotifyPrototype.getRandomAlphaLetter() + CongressNotifyPrototype.getRandomAlphaLetter() + CongressNotifyPrototype.getRandomAlphaLetter() +
                        CongressNotifyPrototype.getRandomAlphaLetter() + CongressNotifyPrototype.getRandomAlphaLetter() + CongressNotifyPrototype.getRandomAlphaLetter(),
                    caseVersionNumberId: numStr ? numStr : '1',
                    caseVersionStatusCd: 'I',
                    caseVersionTypeCd: 'A',
                    versionStatusTitleNm: 'Implemented',
                    calcCvTotalCaseValueAm: this.getRoundUpNumber(),
                })
                this.mockNonDevData.push({
                    userCaseId: CongressNotifyPrototype.getRandomAlphaLetter() + CongressNotifyPrototype.getRandomAlphaLetter() + CongressNotifyPrototype.getRandomAlphaLetter() +
                        CongressNotifyPrototype.getRandomAlphaLetter() + CongressNotifyPrototype.getRandomAlphaLetter() + CongressNotifyPrototype.getRandomAlphaLetter(),
                    caseVersionNumberId: (CongressNotifyPrototype.getRandomNumber(25) + 1).toString(),
                    caseVersionTypeCd: 'M',
                    caseVersionStatusCd: 'R',
                    versionStatusTitleNm: 'Review',
                    calcCvTotalCaseValueAm: this.getRoundUpNumber(),
                })
            }
        }
        else {
            this.mockDevData = [];
            for (var x = 0; x <= CongressNotifyPrototype.getRandomNumber(10); x++) {
                this.mockDevData.push({
                    userCaseId: CongressNotifyPrototype.getRandomAlphaLetter() + CongressNotifyPrototype.getRandomAlphaLetter() + CongressNotifyPrototype.getRandomAlphaLetter() +
                        CongressNotifyPrototype.getRandomAlphaLetter() + CongressNotifyPrototype.getRandomAlphaLetter() + CongressNotifyPrototype.getRandomAlphaLetter(),
                    caseVersionTypeCd: 'B',
                    caseVersionStatusCd: 'D',
                    caseVersionNumberId: (CongressNotifyPrototype.getRandomNumber(25) + 1).toString(),
                    versionStatusTitleNm: 'Development',
                    calcCvTotalCaseValueAm: this.getRoundUpNumber(),
                })
            }
        }
    }
}