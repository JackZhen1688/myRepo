import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CaseAmountPanelComponent } from './case-amount-panel.component';

describe('CaseAmountPanelComponent', () => {
  let component: CaseAmountPanelComponent;
  let fixture: ComponentFixture<CaseAmountPanelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CaseAmountPanelComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CaseAmountPanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
