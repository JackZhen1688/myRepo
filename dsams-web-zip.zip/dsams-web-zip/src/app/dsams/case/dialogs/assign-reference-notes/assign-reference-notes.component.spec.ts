import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AssignReferenceNotesComponent } from './assign-reference-notes.component';

describe('AssignReferenceNotesComponent', () => {
  let component: AssignReferenceNotesComponent;
  let fixture: ComponentFixture<AssignReferenceNotesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AssignReferenceNotesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssignReferenceNotesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
