import { HttpErrorResponse } from '@angular/common/http';
import { stringify } from '@angular/compiler/src/util';
import { Component, Inject, OnInit } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';
import { MatDialogClose, MatDialogRef, MatDialogState, MAT_DIALOG_DATA, throwMatDuplicatedDrawerError } from '@angular/material';
import { DsamsConstants } from 'src/app/dsams/dsams.constants';
import { ICaseVersionMilestone } from '../../model/dto/case-version-milestone';
import { IEditResponseType } from '../../model/edit-response-type';
import { CaseRestfulService } from '../../services/case-restful.service';
import { CaseUIService } from '../../services/case-ui-service';
import { CaseUtils } from '../../utils/case-utils';
import { MessageMgr } from '../../validation/message-mgr';

@Component({
    selector: 'app-milestone-comment',
    templateUrl: './milestone-comment.component.html',
    styleUrls: ['./milestone-comment.component.css']
})
export class MilestoneCommentComponent implements OnInit {

    ICaseVersionMilestone = {
        case_MILESTONE_COMMENT_TX: null,
        case_MILESTONE_TITLE_NM: ""
    }

    caseVersionMilestone: ICaseVersionMilestone;
    textAreaFormControl = new FormControl('', [Validators.required]);
    matDialogClosed: MatDialogClose;

    constructor(private caseRestService: CaseRestfulService,
        private dialogRef: MatDialogRef<MilestoneCommentComponent>,
        @Inject(MAT_DIALOG_DATA) public data: { milestoneId: string, caseId: number, versionId: number, milestoneComment: string, activityId: string, userId: number },
        private caseUIService: CaseUIService) { }

    ngOnInit(): void {
        if (this.data.milestoneId == "PENINK")
            this.ICaseVersionMilestone.case_MILESTONE_TITLE_NM = "Update Offer/Pen & Ink Change";
        else if (this.data.milestoneId == "CWDREDIT")
            this.ICaseVersionMilestone.case_MILESTONE_TITLE_NM = "Update Case Version in Review";
        else if (this.data.milestoneId == "CWDPEDIT")
            this.ICaseVersionMilestone.case_MILESTONE_TITLE_NM = "Update Case in Proposed";

        this.textAreaFormControl.setValue(this.ICaseVersionMilestone.case_MILESTONE_COMMENT_TX);
    }

    onNoclick(): void {
        this.dialogRef.close();
    }

    XcloseDialog(): void {
        this.dialogRef.close();
    }

    // completeDialog(): void {
    //     this.dialogRef.close();
    // }

    cancelDialog(): void {
        this.dialogRef.close();
    }

    saveDialog(): void {
        let regexpr = new RegExp("^(\\s)*$", "i");
        let isSpacesOnly = regexpr.test(this.textAreaFormControl.value);
        if (isSpacesOnly){
            this.textAreaFormControl.setValue(null);
        }
        
        if (this.textAreaFormControl.value !== null) {
            this.caseUIService.isMilestoneCommentNull.next(false);
            this.caseVersionMilestone =
                CaseUtils.addCaseVersionMilestone(
                    this.data.caseId,
                    this.data.versionId,
                    0,
                    this.data.milestoneId,
                    this.ICaseVersionMilestone.case_MILESTONE_COMMENT_TX,
                    this.data.activityId,
                    this.data.userId
                );
            this.caseRestService.saveCaseVersionMilestone(this.caseVersionMilestone).subscribe((milestone) => {
                if (milestone) {
                    //MessageMgr.displaySuccessWithTimer(this.data.milestoneId + " milestone added.", 2000);
                    // const editResponse: IEditResponseType = {
                    //     ID: DsamsConstants.CASE_LINE_EDITOR,
                    //     editToggle: true
                    // };
                    // this.caseUIService.caseEditService.next(editResponse);
                    this.dialogRef.close("Ok");
                }
                (err: any) => {
                    CaseUtils.ReportHTTPError(err, "Inserting in to Case Version Milestone");
                    this.dialogRef.close("error");
                }
            });
        } else {
            MessageMgr.displayErrorWithTimer("Milestone " + this.data.milestoneId + " requires comment; save operation failed", 3500);
            this.caseUIService.isMilestoneCommentNull.next(true);
        }
    }
}
