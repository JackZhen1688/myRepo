import { Component, Inject, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { MatDialogRef, MAT_DIALOG_DATA, MatTableDataSource } from '@angular/material';
import { CaseRestfulService } from '../../services/case-restful.service';
import { CaseUIService } from '../../services/case-ui-service';
import { BehaviorSubject } from 'rxjs';
import { Router } from '@angular/router';
import swal from 'sweetalert2';
import { caseLineComponentModel } from 'src/app/dsams/case/model/case-line-component-model';
import { IEditResponseType } from 'src/app/dsams/case/model/edit-response-type';
import { DsamsConstants } from 'src/app/dsams/dsams.constants';
import { CaseLineRelatedInfoType } from 'src/app/dsams/case/model/case-line-related-info-type';
import { caseLineComponentDto } from 'src/app/dsams/case/model/dto/case-line-component-dto';
import { CaseUtils } from 'src/app/dsams/case/utils/case-utils';
import { CASE_LINE_COMP_DEL_TERM } from '../../model/dto/icase-line-pricing';
import { MessageMgr } from '../../validation/message-mgr';

export interface ICaseLinePricing {
    status: number,
    case_ID: number,
    working_CASE_ID: number,
    working_CASE_VERSION_ID: number,
    case_MASTER_LINE_ID: number,
    military_ARTICLE_SERVICE_CD: string,
    case_LINE_ITEM_QY: number,
    price_EFFECTIVE_DT: Date,
    price_EXPIRATION_DT: Date,
    target_TOTAL_LINE_AM: number,
    unit_ABOVE_LINE_COST_AM: number,
    mtds_NARRATIVE_DESCRIPTION_TX: string,
    total_LINE_VALUE_AM: number,   // Maps to Total Line/Subline Value
    totalInWorkAm: number,      // Maps to Total Case Value
    pricing_METHOD_CD: string,
    wm_HasFiscalYearDistribution: boolean,
    caseLineComponentList: Array<caseLineComponentDto>
}

@Component({
    selector: 'app-dtc',
    templateUrl: './dtc.component.html',
    styleUrls: ['./dtc.component.css']
})
export class DTCComponent implements OnInit {

    showSpinner: BehaviorSubject<boolean> = new BehaviorSubject(false);

    aCaseUserId: string = ''
    caseLineRelatedInfoData: CaseLineRelatedInfoType;

    naString: string = 'N/A';
    theCLCData: caseLineComponentModel;

    // DTC object needed for call
    caseLinePricingSummary: ICaseLinePricing;

    caseLineCompDelTermArray: CASE_LINE_COMP_DEL_TERM[] = [];

    dtItemPassed: CASE_LINE_COMP_DEL_TERM;

    isDTCEditable: boolean = false;

    private editSubscription: Subscription = null;

    // Table for DTC
    dataSourceDTCTable = new MatTableDataSource<CASE_LINE_COMP_DEL_TERM>();
    dtcColumnsToDisplay =
        [
        'primaryCategoryCode',
        'deliveryTermCode',
        'deliveryTitle',
        'DeliveryPercent'
        ];
    // Total Percentage
    totalDTCPercentage: string = this.naString;

    dtcDrawerIndex: number;

    constructor(private caseRestService: CaseRestfulService,
        public dialogRef: MatDialogRef<DTCComponent>,
        private router: Router,

        @Inject(MAT_DIALOG_DATA) public data: {caseLinePricingSummaryForPopup: ICaseLinePricing, 
                                               dtcElementForDTCForPopup: any,
                                               caseLineCompDelTermList: Array<CASE_LINE_COMP_DEL_TERM>,
                                               indexForElement: number },
        private caseUIService: CaseUIService) { }

    ngOnInit(): void {
        this.getDataForDTCData();
        this.subscribeToEditService();
    }

    XcloseDialog(): void {
        this.dialogRef.close();
    }

    saveDialog(): void {
        this.sumUpDevliveryPercents();
        let hasError:boolean = false;        
        // Verify that the percents add up to 100%
        if (this.totalDTCPercentage !== "N/A" && this.totalDTCPercentage !== "100") {
            MessageMgr.swalFire({
                title: "DTC Percents must equal 100.",
                icon: 'error',
                showCancelButton: false,
                cancelButtonText: 'No',
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'OK'
            });                
            hasError = true;
        }
        if (!hasError) {
            this.caseUIService.dtcDataChanged.next(this.caseLineCompDelTermArray);
            this.dialogRef.close();
        }
    }

    cancelDialog(): void {
        this.dialogRef.close();
    }


    getDataForDTCData() {
        this.caseLinePricingSummary = this.data.caseLinePricingSummaryForPopup;
        this.dtItemPassed = this.data.dtcElementForDTCForPopup;
        this.showSpinner.next(true);
        // Need to call the database to get the IPC data,
        // because there are fields that you can't get from the regular legacy call.
        this.caseRestService.getCaseLinePCCDTC(
            this.caseLinePricingSummary.case_ID,
            this.caseLinePricingSummary.working_CASE_ID,
            this.caseLinePricingSummary.working_CASE_VERSION_ID,
            this.caseLinePricingSummary.case_MASTER_LINE_ID,
            this.dtItemPassed.case_LINE_COMPONENT_ID).subscribe(
            data => {
                this.caseLineCompDelTermArray = data;
                if (!!this.caseLineCompDelTermArray) {
                    for (let i = 0; i < this.caseLineCompDelTermArray.length; i++) {
                        if (this.caseLineCompDelTermArray[i].status != DsamsConstants.ENT_NEW) {
                            this.caseLineCompDelTermArray[i].status = DsamsConstants.ENT_UNCHANGED;
                        }
                        if (!!this.caseLinePricingSummary.caseLineComponentList && (!this.caseLineCompDelTermArray[i].wm_PRIMARY_CATEGORY_CD || this.caseLineCompDelTermArray[i].wm_PRIMARY_CATEGORY_CD == "")) {
                            this.caseLineCompDelTermArray[i].wm_PRIMARY_CATEGORY_CD = this.caseLinePricingSummary.caseLineComponentList[this.data.indexForElement].primary_CATEGORY_CD;
                        }
                    }
                }
                this.sumUpDevliveryPercents();
                this.dataSourceDTCTable = new MatTableDataSource<CASE_LINE_COMP_DEL_TERM>(this.caseLineCompDelTermArray);
                this.showSpinner.next(false);
            },
            error => {
                CaseUtils.ReportHTTPError(error, "Getting Case Line PCC DTC Data");
                this.showSpinner.next(false);
            }
        );
        
        // Set customer number
        this.getTheUserCaseInfo();
    }

    // Subscribe to edit service
    private subscribeToEditService() {
        this.editSubscription = this.caseUIService.caseEditService.subscribe((pEditResult: IEditResponseType) => {
        if (!!pEditResult && pEditResult.ID === DsamsConstants.CASE_LINE_EDITOR) {
            this.isDTCEditable = pEditResult.editToggle;
        }
        });
    }

    getTheUserCaseInfo() {
        this.caseUIService.getCaseLineRelatedInfoValues().subscribe((value) => {
          this.caseLineRelatedInfoData = value;
          // Concatenate the case user ID with case version type code         
          if (!!this.caseLineRelatedInfoData) {
            //exclude version for basic case
            //if (this.caseLineRelatedInfoData.case_VERSION_TYPE_CD == 'B')
            if (this.caseLineRelatedInfoData.case_VERSION_NUMBER_ID == 0) {
              setTimeout(() => {
                this.aCaseUserId = '(' + this.caseLineRelatedInfoData.user_CASE_ID
                  + ' ' + this.caseLineRelatedInfoData.case_VERSION_TYPE_CD + ')';
              }, 0);
            }
            else {
              setTimeout(() => {
                this.aCaseUserId = '(' + this.caseLineRelatedInfoData.user_CASE_ID
                  + ' ' + this.caseLineRelatedInfoData.case_VERSION_TYPE_CD
                  + ' ' + this.caseLineRelatedInfoData.case_VERSION_NUMBER_ID + ')';
              }, 0);
            }
          }
        });
    }

    onChangeDELIVERY_TERM_RT(pIndex: number) {
        this.sumUpDevliveryPercents();
        this.onChangeCaseLineComponent(pIndex);
    }

    private sumUpDevliveryPercents() {
        let totalPct:number = 0;
        if (!!this.caseLineCompDelTermArray) {
            for (let dtcRow of this.caseLineCompDelTermArray) {
                totalPct = totalPct + +dtcRow.delivery_TERM_RT;
            }
        }
        this.totalDTCPercentage = totalPct.toString();
    }

    onChangeCaseLineComponent(pIndex: number) {
        if (this.caseLineCompDelTermArray[pIndex].status == DsamsConstants.ENT_UNCHANGED) {
            this.caseLineCompDelTermArray[pIndex].status = DsamsConstants.ENT_CHANGED;
        }
    }

    ngOnDestroy() {
        if (!!this.editSubscription) {
          this.editSubscription.unsubscribe();
          this.editSubscription = null;
        }
    }
}