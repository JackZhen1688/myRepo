import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReplaceExpiredVersionComponent } from './replace-expired-version.component';

describe('ReplaceExpiredVersionComponent', () => {
  let component: ReplaceExpiredVersionComponent;
  let fixture: ComponentFixture<ReplaceExpiredVersionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReplaceExpiredVersionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReplaceExpiredVersionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
