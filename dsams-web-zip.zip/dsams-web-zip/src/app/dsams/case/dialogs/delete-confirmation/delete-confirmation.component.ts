import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { CaseUIService } from '../../services/case-ui-service';

@Component({
  selector: 'app-delete-confirmation',
  templateUrl: './delete-confirmation.component.html',
  styleUrls: ['./delete-confirmation.component.css']
})
export class DeleteConfirmationComponent implements OnInit {

  constructor(private popoverData:CaseUIService) { }
  @Output() sendDeleteConfirm = new EventEmitter<boolean>();
  @Input() contentDescription : string ='';
  textDescription: string = 'Delete Row?';

  ngOnInit() { 
     this.textDescription = this.contentDescription;
  }

  yesButtonOnClick() {
    this.popoverData.setPopoverBooleanValue(true)
    this.sendDeleteConfirm.emit(true);
  }

  noButtonOnClick() {
    this.sendDeleteConfirm.emit(false);
    this.popoverData.setPopoverBooleanValue(false)
   }
  }