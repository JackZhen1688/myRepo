import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { SelectionModel } from '@angular/cdk/collections';
import { MatTableDataSource } from '@angular/material';
import { CaseRestfulService } from '../../services/case-restful.service';
import { BehaviorSubject, Subscription } from 'rxjs';
import { CaseUIService } from '../../services/case-ui-service';
import { IEditResponseType } from 'src/app/dsams/case/model/edit-response-type';
import { DsamsConstants } from 'src/app/dsams/dsams.constants';
import { CaseUtils } from '../../utils/case-utils';

export interface AssoLines {
    caseId: number;
    caseMasterLineId: number;
    caseVersionId: number;
    lineNum: string;
    status: string;
    masl: string;
    maslDesc: string;
    stockNum: string;
    quantity: string;
    issue: string;
}

// The row(s) selected (Associated Lines)
export interface ReturnObject {
    caseId: number;
    caseMasterLineId: number;
    caseVersionId: number;
    lineNum: string; // Line Number or Subline Number of Associated Line
    status: string; // Status of Associated Line
    maslNum: string; // MASL Number of Associated Line
    stockNum: string; // Stock Number of Associated Line
    amount: string; // Amount of Associated Line
    assoLines: AssoLines[];
}

@Component({
    selector: 'app-assolines',
    templateUrl: './asso-lines.component.html',
    styleUrls: ['./asso-lines.component.css']
})
export class AssoLinesComponent implements OnInit {

    displayedColumns: string[] = ['select','lineSubline','status','maslNum','stockNum','amount']; 
    dataSourceAssoLines = new MatTableDataSource<AssoLines>();
    dataSourceAssoLinesArray = new Array <AssoLines>();
    dataSourceAssoLinesArrayNoInactive = new Array <AssoLines>();
    selectionAssoLines = new SelectionModel<AssoLines>(true, []);
    recordCount: number=0;
    noDataFoundInd: boolean = false;

    showSpinner: BehaviorSubject<boolean> = new BehaviorSubject(false);

    // The selected item(s)
    selAssoLines: AssoLines[];

    // Return object info
    returnObject: ReturnObject = <ReturnObject>{};

    showFullAssoLinesList: boolean = false;

    private editSubscription: Subscription = null;
    isAssoLinesPanelEditable: boolean = false;

    // Set up initial dataSource
    assoLinesDataList: AssoLines[] = [];

    constructor(private caseRestService: CaseRestfulService,
        public dialogRef: MatDialogRef<AssoLinesComponent>,
        private caseUIService: CaseUIService,
        @Inject(MAT_DIALOG_DATA) public data: {assoLinesData: any, caseLineRelatedInfoData: any}) { }

    ngOnInit(): void { 
        // Set editable to true for now
        this.isAssoLinesPanelEditable = true;
        // TODO: Set up
        //this.subscribeToEditService();

        // Get lines that can be associated
        this.getDataForAssoLineList();
    }

    onCheckboxChange() {
        this.selAssoLines = this.getCheckedValues();
    }

    getCheckedValues() {
        let values: AssoLines[] = [];
        this.dataSourceAssoLines.data.forEach(row => { 
            if (this.selectionAssoLines.isSelected(row)) {
                values.push(row);
            }
          }
        )
        return values;
    }

    onNoclick(): void {
        this.dialogRef.close();
    }

    XcloseDialog(): void {
        this.dialogRef.close();
    }

    completeDialog(): void {
        this.dialogRef.close();
    }

    //Table: highlighter
    selectedRowIndex: string; 
    lineNumId: string;

    highlight(row: any){
        this.selectedRowIndex = row.lineNum;
        this.lineNumId = row.lineNum;
    }

    saveDialog(): void {
        // Return the selected AssoLines
        this.returnObject.assoLines = this.selAssoLines;
        this.dialogRef.close({ data: this.returnObject });
    }

    cancelDialog(): void {
        this.dialogRef.close();
    }

    // Subscribe to edit service
    private subscribeToEditService() {
        this.editSubscription = this.caseUIService.caseEditService.subscribe((pEditResult: IEditResponseType) => {
        if (!!pEditResult && pEditResult.ID === DsamsConstants.CASE_LINE_EDITOR) {
            this.isAssoLinesPanelEditable = pEditResult.editToggle;
        }
        });
    }

    getDataForAssoLineList() {
        // Get dynamic data here
        let aCaseID = this.caseUIService.caseRelatedInfoDetail.value.working_CASE_ID
        let aCaseVersionID = this.caseUIService.caseRelatedInfoDetail.value.working_CASE_VERSION_ID
        let quantity: string;
        this.showSpinner.next(true);
        this.caseRestService.getCaseLineListFromServerForNotes(aCaseID,
            aCaseVersionID)
            .subscribe(
            data => {
                if (!!data) {
                    for (var i = 0; i <= data.length - 1; i++) {
                        quantity = '';
                        if (data[i].case_LINE_ITEM_QY != null && data[i].case_LINE_ITEM_QY != '') {
                            if (data[i].case_LINE_ITEM_QY != '0') {
                                quantity = parseInt(data[i].case_LINE_ITEM_QY).toString();
                            }
                        }
                        this.assoLinesDataList.push
                            ({lineNum: data[i].wm_USER_CASE_LINE_NUMBER_ID, 
                                status: data[i].change_ACTION_CD, 
                                masl: data[i].military_ARTICLE_SERVICE_CD, 
                                maslDesc: data[i].article_DESCRIPTION_TX,
                                stockNum: data[i].national_STOCK_NUMBER_ID, 
                                quantity: quantity,
                                caseId: data[i].case_ID,
                                caseMasterLineId: data[i].case_MASTER_LINE_ID,
                                caseVersionId:data[i].working_CASE_VERSION_ID,
                                issue: data[i].issue_UNIT_CD });
                    }
                }
                this.recordCount = this.assoLinesDataList.length;

                this.dataSourceAssoLines = new MatTableDataSource(this.assoLinesDataList);
                
                this.noDataFoundInd = (this.recordCount == 0);
                this.showSpinner.next(false);
            },
            err => {
              CaseUtils.ReportHTTPError(err, "Fetching Assoicated Lines");
              this.showSpinner.next(false);
            });            
    }
}