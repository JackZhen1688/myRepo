import { Component, Inject, OnInit } from '@angular/core';
import { Subscription, BehaviorSubject } from 'rxjs';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { CaseRestfulService } from '../../services/case-restful.service';
import { CaseUIService } from '../../services/case-ui-service';
import { Router } from '@angular/router';
import swal from 'sweetalert2';
import { ISelectOptions } from 'src/app/dsams/interfaces/i-select-options';
import { caseLineComponentModel } from 'src/app/dsams/case/model/case-line-component-model';
import { IEditResponseType } from 'src/app/dsams/case/model/edit-response-type';
import { DsamsConstants } from 'src/app/dsams/dsams.constants';
import { CaseLineRelatedInfoType } from 'src/app/dsams/case/model/case-line-related-info-type';
import { MessageMgr } from '../../validation/message-mgr';

export interface dropdownArray {
    pCode: string,
    pDesc: string
}

@Component({
    selector: 'app-publications',
    templateUrl: './publications.component.html',
    styleUrls: ['./publications.component.css']
})
export class PublicationsComponent implements OnInit {

    showSpinner: BehaviorSubject<boolean> = new BehaviorSubject(false);

    aCaseUserId: string = ''
    caseLineRelatedInfoData: CaseLineRelatedInfoType;

    naString: string = 'N/A';
    //wm_PRICE_YEAR_NM: string = this.naString;
    theCLCData: any;

    //Static dropdown List
    publicationsCategoryList: ISelectOptions[] = [
        { value: '1', viewValue: 'Technical' },
        { value: '2', viewValue: 'Training' },
        { value: '3', viewValue: 'Administration' },
        { value: '4', viewValue: 'Supply' }
    ];

    isPublicationsEditable: boolean = false;

    publicationsCodeText: string;

    private editSubscription: Subscription = null;

    publicationsPagesText: string;

    constructor(private caseRestService: CaseRestfulService,
        public dialogRef: MatDialogRef<PublicationsComponent>,
        @Inject(MAT_DIALOG_DATA) public data: {publicationElementForPublicationsForPopup: any, indexForElement: number},
        private caseUIService: CaseUIService) { }

    ngOnInit(): void {
        this.getDataForPublicationsData();
        this.subscribeToEditService();
    }

    XcloseDialog(): void {
        this.dialogRef.close();
    }

    saveDialog(): void {
        // Validate the info on the screen for required values.
        let hasError:boolean = false;
        if (!this.theCLCData.publication_CATEGORY_CD || this.theCLCData.publication_CATEGORY_CD === "" || this.theCLCData.publication_CATEGORY_CD === "N/A") {
            MessageMgr.swalFire({
                title: "Publication Category is requried.",
                icon: 'error',
                showCancelButton: false,
                cancelButtonText: 'No',
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'OK'
            });
            hasError = true;
        }
        if (!hasError && (!this.theCLCData.publication_PAGE_AM || this.theCLCData.publication_PAGE_AM == 0)) {
            MessageMgr.swalFire({
                title: "Number of pages must be greater than zero.",
                icon: 'error',
                showCancelButton: false,
                cancelButtonText: 'No',
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'OK'
            });
            hasError = true;
        }
        if (!hasError) {
            this.caseUIService.publicationInfoChosen.next( 
                {publication_CATEGORY_CD: this.theCLCData.publication_CATEGORY_CD,
                publication_PAGE_AM: this.theCLCData.publication_PAGE_AM});
            this.dialogRef.close();
        }
    }

    cancelDialog(): void {
        this.dialogRef.close();
    }

    successDialog() {
        swal.fire({
            title: "Save was Successful",
            icon: 'success',
            showCancelButton: false,
            cancelButtonText: 'No',
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'OK'
        });
    }

    getDataForPublicationsData() { 
        // Get data
        this.theCLCData = this.data.publicationElementForPublicationsForPopup;
        
        // Set the text of Publications Category Code when backend card completed
        for (let i = 0; i < this.publicationsCategoryList.length; i++) {
            if (this.theCLCData.publication_CATEGORY_CD === this.publicationsCategoryList[i].value) {
                this.publicationsCodeText = this.publicationsCategoryList[i].viewValue;
            }
        }

        // Set page amt
        this.publicationsPagesText = this.theCLCData.publication_PAGE_AM.toString();
        
        // Set customer number
        this.getTheUserCaseInfo();
    }

    // Subscribe to edit service
    private subscribeToEditService() {
        this.editSubscription = this.caseUIService.caseEditService.subscribe((pEditResult: IEditResponseType) => {
        if (!!pEditResult && pEditResult.ID === DsamsConstants.CASE_LINE_EDITOR) {
            this.isPublicationsEditable = pEditResult.editToggle;
        }
        });
    }

    onPubSelectionChange(pValue:any) {
        this.theCLCData.publication_CATEGORY_CD = pValue.value;
    }

    getTheUserCaseInfo() {
        this.caseUIService.getCaseLineRelatedInfoValues().subscribe((value) => {
          this.caseLineRelatedInfoData = value;
          // Concatenate the case user ID with case version type code         
          if (!!this.caseLineRelatedInfoData) {
            //exclude version for basic case
            //if (this.caseLineRelatedInfoData.case_VERSION_TYPE_CD == 'B')
            if (this.caseLineRelatedInfoData.case_VERSION_NUMBER_ID == 0) {
              setTimeout(() => {
                this.aCaseUserId = '(' + this.caseLineRelatedInfoData.user_CASE_ID
                  + ' ' + this.caseLineRelatedInfoData.case_VERSION_TYPE_CD + ')';
              }, 0);
            }
            else {
              setTimeout(() => {
                this.aCaseUserId = '(' + this.caseLineRelatedInfoData.user_CASE_ID
                  + ' ' + this.caseLineRelatedInfoData.case_VERSION_TYPE_CD
                  + ' ' + this.caseLineRelatedInfoData.case_VERSION_NUMBER_ID + ')';
              }, 0);
            }
          }
        });
    }

    ngOnDestroy() {
        if (!!this.editSubscription) {
          this.editSubscription.unsubscribe();
          this.editSubscription = null;
        }
    }
}