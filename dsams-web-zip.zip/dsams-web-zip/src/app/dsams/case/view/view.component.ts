/* 
  This Case Detail View is developed as a prototype Web page to 
  demonstrate the Angular form control/functional behaviors. 
  This web page contains a total of 8 expansion panels with 
  pre-populated data for demo purposes.
  Author: David Huynh 
  Date:   02/12/2020 
*/

import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CaseLineRelatedInfoType } from '../model/case-line-related-info-type';
import { CaseRelatedInfoType } from '../model/case-related-info-type';
import { CaseUIService } from '../services/case-ui-service';
@Component({
  selector: 'app-view',
  templateUrl: './view.component.html',
  styleUrls: ['./view.component.css']
})

// "caseMasterServiceTypeList":[{"customer_SERVICE_TYPE_ID":"D","service_TYPE_DESCRIPTION_TX":"Air Force","procuringAgencyIn":true,"case_ID":307452},{
export class ViewComponent implements OnInit {
  caseRelatedInfoData: CaseRelatedInfoType;
  caseLineRelatedInfoData: CaseLineRelatedInfoType;

  // ********** Main Body ***********
  constructor(private caseUIService: CaseUIService,
    private router: Router) { }

  ngOnInit() {
  }

  testCaseId: number = 325470;
  testCaseVersionId: number = 779801;

  testLineListJDBCCall(){
    this.caseRelatedInfoData = {
      working_CASE_ID: this.testCaseId,
      working_CASE_VERSION_ID: this.testCaseVersionId,
      case_USAGE_INDICATOR_CD: 'C',
      testLineList: true,
    }
    this.caseUIService.setCaseRelatedInfoValues(this.caseRelatedInfoData);
    this.router.navigate(['/case/line-dashboard/0/Line']);
  }

  testLineListLegacyCall() {
    this.caseRelatedInfoData = {
      working_CASE_ID: this.testCaseId,
      working_CASE_VERSION_ID: this.testCaseVersionId,
      case_USAGE_INDICATOR_CD: 'C',
      testLineList: false,
    }
    this.caseUIService.setCaseRelatedInfoValues(this.caseRelatedInfoData);
    this.router.navigate(['/case/line-dashboard/0/Line']);
  }

  testLineListATBNAS() {
    this.caseRelatedInfoData = {
      working_CASE_ID: 325611,
      working_CASE_VERSION_ID: 779942,
      case_USAGE_INDICATOR_CD: 'C',
      testLineList: true,
    }
    this.caseUIService.setCaseRelatedInfoValues(this.caseRelatedInfoData);
    this.router.navigate(['/case/line-dashboard/0/Line']);
  }
}