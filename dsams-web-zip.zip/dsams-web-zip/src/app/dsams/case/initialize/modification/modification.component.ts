import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-modification',
  templateUrl: './modification.component.html',
  styleUrls: ['./modification.component.css']
})
export class ModificationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
