
import { Case } from './case';

export class ObjectService {
  public case: Case = new Case();
}