import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProcessFourComponent } from './process-four.component';

describe('ProcessFourComponent', () => {
  let component: ProcessFourComponent;
  let fixture: ComponentFixture<ProcessFourComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProcessFourComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProcessFourComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
