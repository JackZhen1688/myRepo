//import { Employee } from './employee';

export class Case {
    countryCode = '';
    countryName = '';
    implAgencyCode = '';
    implAgencyTitle ='';
    custRequestId = '';
    custRequestRef = '';
    //teamDept:  Department;
    //employees: Employee[];
}