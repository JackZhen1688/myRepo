import { Component, OnInit, Renderer2 } from '@angular/core';
import { Router} from "@angular/router";
import { FormBuilder, FormGroup, FormControl, Validators} from '@angular/forms';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import { CaseRestfulService } from './../../../services/case-restful.service';
import { ObjectService } from '../case-objects/object-service';
import { CustomerRequestComponent } from './../../../dialogs/customer-request/customer-request.component';

export interface Country {
  customer_organization_id: string;
  customer_nickname_nm: string;
  inactive_in: string;
}
export interface ImpAngency {
  implementing_agency_id: string;
  implementing_agency_title_nm: string;
}
export interface CustRequest {
  customer_request_id: string;
  customer_organization_id: string;
  customer_request_reference_tx: string;
  customer_request_date: string;
  customer_activity_id: string;
}


@Component({
  selector: 'app-process-one',
  templateUrl: './process-one.component.html',
  styleUrls: ['./process-one.component.css']
})
export class ProcessOneComponent implements OnInit {

  findDesignator: boolean;

  countries: Country[] = [{"customer_organization_id": "Code","customer_nickname_nm": "Name", "inactive_in":"Inactive"}];
  impAngencys: ImpAngency[] = [{"implementing_agency_id": "Code","implementing_agency_title_nm": "Title"}];
  custRequests: CustRequest[] = [{"customer_request_id": "Id","customer_organization_id": "Co", "customer_request_reference_tx":"Reference", "customer_request_date":"Date","customer_activity_id":"Preparer"}];
 
  countryCtrl = new FormControl();
  implAgencyCtrl = new FormControl();
  caseDesignatorCtrl = new FormControl();
  custRequestCtrl = new FormControl();
 
  filteredCountries: Observable<Country[]>;
  filteredImplAgencys: Observable<ImpAngency[]>;
  filteredCustRequests: Observable<CustRequest[]>;

  processOneForm: FormGroup;

  constructor(private router: Router, private formBuilder: FormBuilder, public dialog: MatDialog, private renderer: Renderer2, private caseRestService: CaseRestfulService, private objectService: ObjectService) { }


  ngOnInit() {
    this.constructProcessOneForm();
    this.processOneForm.get("countryName").disable();
    this.processOneForm.get("implAgencyTitle").disable();
    this.processOneForm.get("custRequestRef").disable();
  }

  ngOnDestroy() {

     this.objectService.case.countryCode = this.processOneForm.get('countryCode').value;
     this.objectService.case.countryName = this.processOneForm.get('countryName').value;
     this.objectService.case.implAgencyCode  = this.processOneForm.get('implAgencyCode').value;
     this.objectService.case.implAgencyTitle = this.processOneForm.get('implAgencyTitle').value;

  }

  /*---------------------------
    Reactive Form Initializing
  ---------------------------*/
  constructProcessOneForm() {
    this.processOneForm = this.formBuilder.group({
      countryCode: this.formBuilder.control('', [Validators.required]),
      countryName: this.formBuilder.control(''),
      implAgencyCode: this.formBuilder.control('', [Validators.required]),
      implAgencyTitle: this.formBuilder.control(''),
      caseDesignator: this.formBuilder.control('', [Validators.required, Validators.minLength(3)]),
      custRequestId: this.formBuilder.control(''),
      custRequestRef: this.formBuilder.control(''),
    });
  }

  get countryCode() {
    return this.processOneForm.get('countryCode');
  } 

  get implAgencyCode() {
    return this.processOneForm.get('implAgencyCode');
  } 

  get caseDesignator() {
    return this.processOneForm.get('caseDesignator');
  } 

  /*---------------------------------
   Customer Organization Autocomplete
   ----------------------------------*/

  private _filterCountries(value: string): Country[] {
    const filterValue = value.toLowerCase();
    return this.countries.filter(country => (country.customer_organization_id.toLowerCase().indexOf(filterValue) === 0 || 
                                             country.customer_nickname_nm.toLowerCase().indexOf(filterValue) === 0));
  }

  onSelectCountry(event: any, sourceCompt: any, targetCompt: any) {
    if (event.isUserInput) {
        if (event.source.value.indexOf(":") >= 0) {
            this.processOneForm.get(sourceCompt).setValue(event.source.value.slice(0, event.source.value.indexOf(":")));
            this.processOneForm.get(targetCompt).setValue(event.source.value.slice(event.source.value.indexOf(":")+1));
        }
    } 
  }

  onBlurCountry(event: any, sourceCompt: any, targetCompt: any) {
    this.processOneForm.get(sourceCompt).reset();
    for(let i=0; i<this.countries.length; i++) {
        if (event.target.value.toUpperCase() == this.countries[i].customer_organization_id) {
            this.processOneForm.get(sourceCompt).setValue(this.countries[i].customer_organization_id.toUpperCase());
            this.processOneForm.get(targetCompt).setValue(this.countries[i].customer_nickname_nm.toUpperCase());
            break;
        } 
    }
  }

  private _filterAngencys(value: string): ImpAngency[] {
    const filterValue = value.toLowerCase();
    return this.impAngencys.filter(angency => (angency.implementing_agency_id.toLowerCase().indexOf(filterValue) === 0 || 
                                               angency.implementing_agency_title_nm.toLowerCase().indexOf(filterValue) === 0));
  }

  onSelectAngency(event: any, sourceCompt: any, targetCompt: any) {
    if (event.isUserInput) {
      if (event.source.value.indexOf(":") >= 0) {
        this.processOneForm.get(sourceCompt).setValue(event.source.value.slice(0, event.source.value.indexOf(":")));
        this.processOneForm.get(targetCompt).setValue(event.source.value.slice(event.source.value.indexOf(":")+1));
      }
    } 
  }

  onBlurImplAngency(event: any, sourceCompt: any, targetCompt: any) {
    this.processOneForm.get(sourceCompt).reset();
    for(let i=0; i<this.impAngencys.length; i++) {
        if (event.target.value.toUpperCase() == this.impAngencys[i].implementing_agency_id) {
            this.processOneForm.get(sourceCompt).setValue(this.impAngencys[i].implementing_agency_id.toUpperCase());
            this.processOneForm.get(targetCompt).setValue(this.impAngencys[i].implementing_agency_title_nm.toUpperCase());
            break;
        } 
    }
  }

   /*-----------------------------
     Customer Reqeust Autocomplete
    ------------------------------*/
  private _filterCustRequest(value: string): CustRequest[] {
    const filterValue = value.toLowerCase();
    return this.custRequests.filter(request => (request.customer_request_id.toLowerCase().indexOf(filterValue) === 0 ||
                                                request.customer_organization_id.toLowerCase().indexOf(filterValue) === 0 ||
                                                request.customer_request_reference_tx.toLowerCase().indexOf(filterValue) === 0));
  }

  onSelectRequest(event: any, sourceCompt: any) {
    if (event.isUserInput) {
        this.processOneForm.get(sourceCompt).setValue(event.source.value);
    } 
  }
  
  onBlurCustRequest(event: any, sourceCompt: any) {
    this.processOneForm.get(sourceCompt).reset();
    for(let i=0; i<this.custRequests.length; i++) {
        if (event.target.value.toUpperCase() == this.custRequests[i].customer_request_id) {
            this.processOneForm.get(sourceCompt).setValue(this.custRequests[i].customer_request_id.toUpperCase());
            break;
        } 
    }
  }


  //Validation
  onKeyup(event: any) {
    if (this.countryCode.value=='') {
        alert("Please entry the country code!");
        this.caseDesignator.setValue('');
        var elemCountryCode = this.renderer.selectRootElement('#countryCode');
        elemCountryCode.focus();
    } else if (this.implAgencyCode.value=='') {
        alert("Please entry the implementing angency code!");
        this.caseDesignator.setValue('');
        var elemImplAgencyCode = this.renderer.selectRootElement('#implAgencyCode');
        elemImplAgencyCode.focus();
    } else {
        this.caseDesignator.setValue(event.target.value.toUpperCase());
    }

    if (!(event.target.value !='' && event.target.value.length==3)) 
    {
        this.findDesignator=false;
    }

  }

  /*-------------------------------
    Dialog Customer Request Box
    -------------------------------*/
  openCustRequestDialog(megs: string): void {

      const dialogCusRequestConfig = new MatDialogConfig();
      dialogCusRequestConfig.disableClose = true;
      dialogCusRequestConfig.autoFocus = true;
      dialogCusRequestConfig.width='700px';
      dialogCusRequestConfig.height='600px'
      dialogCusRequestConfig.data = {message: megs};
  
      const dialogCusRequestRef = this.dialog.open(CustomerRequestComponent,
                                                   dialogCusRequestConfig);
    
      dialogCusRequestRef.afterClosed().subscribe(result => {
        this.processOneForm.get('custRequestId').setValue(result);
      });
  } 

  onSubmit() {
    if (this.processOneForm.invalid || this.findDesignator)
        return;
    console.log("Form Value: "+JSON.stringify(this.processOneForm.value));
    this.router.navigate(['/case/initialize/basic/process-two']);
  }

  onReset() {
    console.log("Form Reset: "+this.processOneForm.reset());
  }

}
