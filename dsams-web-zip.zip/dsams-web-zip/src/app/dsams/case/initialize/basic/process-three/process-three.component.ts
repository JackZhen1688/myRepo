import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-process-three',
  templateUrl: './process-three.component.html',
  styleUrls: ['./process-three.component.css']
})
export class ProcessThreeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
