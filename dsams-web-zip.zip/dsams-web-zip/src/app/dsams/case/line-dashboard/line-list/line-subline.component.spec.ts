import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LineSublineComponent } from './line-subline.component';

describe('LineSublineComponent', () => {
  let component: LineSublineComponent;
  let fixture: ComponentFixture<LineSublineComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LineSublineComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LineSublineComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
