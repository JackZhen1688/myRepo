/* This class is used to handle all business logic for 
   the Line Delivery page.
   Author: Francis Shu 
   Date:   05/13/2020 
*/

import { Component, Injectable, OnInit, ViewChild } from '@angular/core';
import { BehaviorSubject, Subscription } from 'rxjs';
import { MatTableDataSource } from '@angular/material/table';
import { MdePopoverTrigger } from '@material-extended/mde';
import { CaseUIService } from '../../services/case-ui-service';
import { ifaceCaseLineData, ifaceCaseMasterLineEntity } from '../../model/case-line-model';
import {
  ifaceCaseLineOfferReleaseEntity, ifaceCaseLineDeliveryTermEntity,
  ifaceCaseLineDeliveryItemEntity, ifaceCaseLineDeliveryScheduleEntity,
  ifaceOfferReleaseEntity, ifaceDeliveryTermEntity
} from '../../model/case-related-info-type';
import { DsamsConstants } from 'src/app/dsams/dsams.constants';
import { CaseUtils } from '../../utils/case-utils';
import { CaseLineRelatedInfoType } from '../../model/case-line-related-info-type';
import { IEditResponseType } from '../../model/edit-response-type';
import { LineUtils } from '../line-utils';
import { Router } from '@angular/router';
import { CaseRestfulService } from '../../services/case-restful.service';
import { MessageMgr } from '../../validation/message-mgr';
import { DsamsUserMessageService } from 'src/app/dsams/services/dsams-user-message.service';
import { ErrorParameter } from 'src/app/dsams/entities/specialEntities/error-parameter.model';
import { LineSublineRefComponent } from '../line-reference.component';
import { take } from 'rxjs/operators';
import { MilestoneCommentComponent } from '../../dialogs/milestone-comment/milestone-comment.component';
import { MatDialog } from '@angular/material';
import { DsamsMethodsService } from 'src/app/dsams/services/dsams-methods.service';

declare function focusItem(pItem: string): any;
@Injectable({
  providedIn: 'root'
})
@Component({
  selector: 'app-line-delivery',
  templateUrl: './line-delivery.component.html',
  styleUrls: ['./line-delivery.component.css',
    '../common-CSS.component.css']
})
export class LineDeliveryComponent implements OnInit {
  @ViewChild(MdePopoverTrigger, { static: true }) trigger: MdePopoverTrigger;
  private static CHANGE_ACTION_CD_ADDED: string = "A";
  private static CASE_LINE_EDITOR_STR: string = DsamsConstants.CASE_LINE_EDITOR;
  private static USER_ID: string = "userId";
  private static USER_ACTIVITY_ID : string = "userActivityId";

  _editSubscription: Subscription = null;
  private _caseUIServiceSubscription1: Subscription = null;
  private _caseUIServiceSubscription2: Subscription = null;
  private _refreshDataSubscription: Subscription = null;
  private _repopulateDataSubscription: Subscription = null;
  private _nporChangedSubscription: Subscription = null;
  private _nporChanged: boolean = false;
  private _hasNporWarnings: boolean;

  caseLineInfoData: ifaceCaseLineData;
  caseLineInfoDataOrig: ifaceCaseLineData;
  caseLineRelatedInfoData: CaseLineRelatedInfoType;
  isRefreshDataNeeded: boolean = false;
  isLoading: BehaviorSubject<boolean> = new BehaviorSubject(false);

  ActiveBtnColor: any = '#e7eff6';
  ActiveBgColor: any = 'white';
  InactiveBtnColor = 'darkgrey';
  ActiveDeleteBtnColor = 'red'
  isCalendarBtnDisabled: boolean = true;
  calendarBtnColor: any = this.InactiveBtnColor;
  isAddNewOfferBtnDisabled: boolean = false;
  addOfferBtnColor: any = this.InactiveBtnColor;
  isAddNewTermBtnDisabled: boolean = false;
  addTermBtnColor: any = this.InactiveBtnColor;
  addItemBtnColor: any = this.InactiveBtnColor;

  emptyString: string = '';
  // isDataChanged: boolean = false;
  isPPDisabled: boolean = false;
  ppBGColor: any = this.ActiveBgColor;
  isPerformancePeriodChecked: boolean = false;
  isESDisabled: boolean = false;
  isLeadTimeDisabled: boolean = false;
  isInitialLeadTimeDisabled: boolean = false;
  esBGColor: any = this.ActiveBgColor;
  isEstimatedServiceChecked: boolean = false;
  sumOfAllItemQuantities: number = 0;

  aCaseLineOfferReleaseList: ifaceCaseLineOfferReleaseEntity[];
  columnsToDisplayOfferRelease = ['OfferRelease', 'DeleteRow'];

  aCaseLineDeliveryTermList: ifaceCaseLineDeliveryTermEntity[];
  columnsToDisplayDeliveryTerm = ['DeliveryTerm', 'DeleteRow'];

  aCaseLineDeliveryItemList: ifaceCaseLineDeliveryItemEntity[];
  columnsToDisplayItem = ['Item', 'DeleteRow'];
  aCurItemSelectedRow: number;

  columnsToDisplayCalendar = ['Calendar', 'Qtr1', 'Qtr2', 'Qtr3', 'Qtr4', 'DeleteRow'];
  aCaseLineDeliveryScheduleList: ifaceCaseLineDeliveryScheduleEntity[];

  // Row Indexes
  aOfferReleaseRowIndex: number = 0;
  aDeliveryTermRowIndex: number = 0;
  anItemRowIndex: number = 0;
  aCalendarRowIndex: number = 0;

  //Mat tables
  dataSourceOfferRelease: any;
  dataSourceDeliveryTerm: any;
  dataSourceItem: any;
  dataSourceCalendar = new MatTableDataSource();

  //initialize sequence codes
  anOfferSequenceCd: number = 0;
  aDTSequenceCd: number = 0;
  isLineDeliveryDisabled: boolean = true;
  isAddItemDisabled: boolean = true;
  caseVersionStatusDevelopmentType: string = "D";
  isCLDSQ1Editable: boolean = false;
  isCLDSQ2Editable: boolean = false;
  isCLDSQ3Editable: boolean = false;
  isCLDSQ4Editable: boolean = false;

  //DSAMS-5269 DH 03/22 
  public theReferenceDeliveryDataList: ifaceCaseLineData;

  // Warning message to display prior to save.
  // private _warningMsg: any = null;
  private _popupMASLSubscription: Subscription = null;
  isEditToggleOn : boolean = false;
  isCalenderYearDisabled : boolean = true;
  _toggleActionSubscription: Subscription = null;

  constructor(private caseUIService: CaseUIService,
    private caseRestService: CaseRestfulService,
   public getLineSublineRefData: LineSublineRefComponent,
    private router: Router,
    protected messageService: DsamsUserMessageService,
    public dialog: MatDialog,
    private dsamsMethodsService: DsamsMethodsService) { }

  ngOnInit() {
    //DSAMS-5269 DH 03/22   
    this.getDeliveryReferenceData();
    
    this._nporChanged = false;
    this._hasNporWarnings = true;
    this.dataSourceOfferRelease = new MatTableDataSource(this.aCaseLineOfferReleaseList);
    this.dataSourceDeliveryTerm = new MatTableDataSource(this.aCaseLineDeliveryTermList);
    this.dataSourceItem = new MatTableDataSource(this.aCaseLineDeliveryItemList);
    this.dataSourceCalendar = new MatTableDataSource(this.aCaseLineDeliveryScheduleList);
    this.subscribeAll();
    this.subscribeForRefresh();
    this.subscribeForRepopulate();

    if (this.caseLineInfoData == null) {
      this.initializeCaseLineInfo();
    }
    else {
      this.initializeDeliveryDataFields();
     
    }
    //subscribe to Edit toggle
    this.subscribeToEditToggle();
    this.subscribeToPopupMASL();
    this.subscribeToToggleAction();
  }
  // begin DSAMS-5867 08/22  DB
  public initializeDeliveryDataFields() {
    this.intializeArrays();
    this.addOfferBtnColor = this.InactiveBtnColor;
    this.addTermBtnColor = this.InactiveBtnColor;
    if (this.caseLineInfoData.caseLineOfferReleaseList)
      this.initializeOfferReleaseArray(this.caseLineInfoData.caseLineOfferReleaseList);
    if (this.caseLineInfoData.caseLineDeliveryTermList)
      this.initializeDeliveryTermArray(this.caseLineInfoData.caseLineDeliveryTermList);
    if (this.caseLineInfoData.caseLineDeliveryItemList) {
      this.initializeItemArray(this.caseLineInfoData.caseLineDeliveryItemList);
      if (this.caseLineInfoData.caseLineDeliveryItemList) {
        this.setItemHighlightedRow(0);
      }
      //FR26 - set itinial disable/enable value for leadtime
      this.setIntialLeadTime();
    }
    // end DSAMS-5867 08/22 DB
    this.setInitialRadioBtnStatus();
  }
  //begin DSAMS-5269 DH 03/22
  public getDeliveryReferenceData() {
    this.theReferenceDeliveryDataList = this.getLineSublineRefData.getReferenceDataForCaseLine();
    if (!!this.theReferenceDeliveryDataList.offerReleaseList && this.theReferenceDeliveryDataList.offerReleaseList.length == 0) {
      //should not get in here, but do this condition just in case
      setTimeout(() => {
        this.getLineSublineRefData.populateReferenceDataForCaseLine();
        this.theReferenceDeliveryDataList = this.getLineSublineRefData.getReferenceDataForCaseLine();
      }, 2000);
    }
  }
  //end DSAMS-5269 DH 03/22
  //sonarqube cleanup 
  setIntialLeadTime() {
    if (this.caseLineInfoData.case_LINE_AVAILABILITY_LEAD_QY) {
      if (this.caseLineInfoData.change_ACTION_CD.toUpperCase() == LineDeliveryComponent.CHANGE_ACTION_CD_ADDED) {
        this.isInitialLeadTimeDisabled = true;
        this.isLeadTimeDisabled = true;
      }
      else {
        this.isInitialLeadTimeDisabled = false;
        this.isLeadTimeDisabled = false;
      }
    }
    else {
      this.isInitialLeadTimeDisabled = true;
      this.isLeadTimeDisabled = true;
    }
  }

  //sonarqube cleanup 
  intializeArrays() {
    this.dataSourceOfferRelease.data = [];
    this.dataSourceDeliveryTerm.data = [];
    this.dataSourceItem.data = [];
    this.dataSourceCalendar.data = [];
    this.dataSourceOfferRelease.data = [];
    if (!this.caseLineInfoData.caseLineOfferReleaseList) {
      this.caseLineInfoData.caseLineOfferReleaseList = [];
    }
    this.initializeOfferReleaseArray(this.caseLineInfoData.caseLineOfferReleaseList);

    this.dataSourceDeliveryTerm.data = [];
    if (!this.caseLineInfoData.caseLineDeliveryTermList) {
      this.caseLineInfoData.caseLineDeliveryTermList = [];
    }
    this.initializeDeliveryTermArray(this.caseLineInfoData.caseLineDeliveryTermList);

    this.dataSourceItem.data = [];
    if (!this.caseLineInfoData.caseLineDeliveryItemList) {
      this.caseLineInfoData.caseLineDeliveryItemList = [];
    }
    this.initializeItemArray(this.caseLineInfoData.caseLineDeliveryItemList);
  }

  //sonarqube cleanup 
  subscribeForRefresh() {
    if (!this._refreshDataSubscription) {
      this._refreshDataSubscription = this.caseUIService.getResetCaseLineFromRefreshButton().subscribe((value) => {
        if (value) {
          this.caseLineInfoData = value;
          this.addOfferBtnColor = this.InactiveBtnColor;
          this.addTermBtnColor = this.InactiveBtnColor;
          this.intializeArrays();
          this.setItemHighlightedRow(0);
          if (this.caseLineInfoData.case_LINE_AVAILABILITY_LEAD_QY) {
            if (this.caseLineInfoData.change_ACTION_CD.toUpperCase() == LineDeliveryComponent.CHANGE_ACTION_CD_ADDED) {
              this.isInitialLeadTimeDisabled = true;
              this.isLeadTimeDisabled = true;
            }
            else {
              this.isInitialLeadTimeDisabled = false;
              this.isLeadTimeDisabled = false;
            }
          }
          else {
            this.isInitialLeadTimeDisabled = true;
            this.isLeadTimeDisabled = true;
          }
        }
      });
    }
  }

  //do this as part of sonarqube cleanup 
  subscribeAll() {
    if (!this._caseUIServiceSubscription1) {
      this._caseUIServiceSubscription1 = this.caseUIService.getCaseLineRelatedInfoValues().subscribe((value) => {
        this.caseLineRelatedInfoData = value;
      });
    }

    if (!this._caseUIServiceSubscription2) {
      this._caseUIServiceSubscription2 = this.caseUIService.getCaseLineInfoValues().subscribe((value) => {
            this.caseLineInfoData = value;
        this.initializeDeliveryDataFields();
      });
    }

    if (!this._nporChangedSubscription) {
      this._nporChangedSubscription = this.caseUIService.nporChanged.subscribe((pChanged: boolean) => {
        this._nporChanged = pChanged;
      });
    }
  }

  // Subscribe to Repopulate Line data
  subscribeForRepopulate() {
    if (!this._repopulateDataSubscription) {
      this._repopulateDataSubscription = this.caseUIService.getRepopulateCaseLine().subscribe((value) => {
        if (value) {
          this.caseLineInfoData = value;
          this.intializeArrays();
          // To reset delivery schedule
          if (!!this.caseLineInfoData.caseLineDeliveryItemList) {
            this.setItemHighlightedRow(0);
          }
        }
      });
    }
  }

  ngOnDestroy() {
    //clear the  cache for caseLineInfoData
    this.initializeCaseLineInfo();
    //clear out the selected case line entity 
    this.caseUIService.setCaseLineInfoValues(this.caseLineInfoData);
    if (this._caseUIServiceSubscription1) {
      this._caseUIServiceSubscription1.unsubscribe();
      this._caseUIServiceSubscription1 = null;
    }
    if (this._caseUIServiceSubscription2) {
      this._caseUIServiceSubscription2.unsubscribe();
      this._caseUIServiceSubscription2 = null;
    }
    if (this._editSubscription) {
      this._editSubscription.unsubscribe();
      this._editSubscription = null;
    }
    if (this._refreshDataSubscription) {
      this._refreshDataSubscription.unsubscribe();
      this._refreshDataSubscription = null;
    }
    if (this._nporChangedSubscription) {
      this._nporChangedSubscription.unsubscribe();
      this._nporChangedSubscription = null;
    }
    if (this._repopulateDataSubscription) {
      this._repopulateDataSubscription.unsubscribe();
      this._repopulateDataSubscription = null;
    }
    if (this._toggleActionSubscription) {
      this._toggleActionSubscription.unsubscribe();
      this._toggleActionSubscription = null;
    }
  }

  refreshLineDeliveryData() {
    // this._caseUIServiceSubscription = this.caseUIService.getCaseLineInfoValues().subscribe((value) => {
    //   this.caseLineInfoData = value;
    // });
    // if (!!this.dataSourceOfferRelease) this.dataSourceOfferRelease = this.dataSourceOfferRelease.data;
    //console.log('****refreshing line delivery*****',this.caseLineInfoData);
    // if (!!this.caseLineInfoData && this.caseLineInfoData.caseLineOfferReleaseList) {
    //   //console.log(this.caseLineInfoData)
    //   if (this.caseUIService.getNotifyToRefreshLineData()) {
    //     this.dataSourceOfferRelease = new MatTableDataSource(this.aCaseLineOfferReleaseList);
    //     this.initializeOfferReleaseArray(this.caseLineInfoData.caseLineOfferReleaseList);
    //   }
    // }
    //once it's done, reset value
    this.caseUIService.setNotifyToRefreshLineData(false);
  }

  // Subscribe to edit toggle event
  subscribeToEditToggle() {
    if (!this._editSubscription) {
      this._editSubscription = this.caseUIService
        .caseEditService
        .subscribe((pResponse: IEditResponseType) => {
          if (pResponse && (pResponse.ID === LineDeliveryComponent.CASE_LINE_EDITOR_STR || pResponse.ID === DsamsConstants.CASE_LINE_EDITOR || pResponse.ID === DsamsConstants.PAGE_CASE_LINE)) {
            // console.log('line delivery****',pResponse.ID,pResponse.editToggle)
            this.isEditToggleOn = pResponse.editToggle;
            this.isLineDeliveryDisabled = !pResponse.editToggle;
            this.isAddItemDisabled = !pResponse.editToggle;
            this.checkEditAbilityForLineDelivery(pResponse.editToggle);
            this.changeEditFields(pResponse.editToggle);
          } 
        },
          err => {
            CaseUtils.ReporError("in Line List responding to edit toggle");
          }
        );
    }
  }

  
 


  //Enable/Disable input fields
  checkEditAbilityForLineDelivery(pEditToggle: boolean) {
    if (pEditToggle) {
      this.addOfferBtnColor = this.ActiveBtnColor;
      this.addTermBtnColor = this.ActiveBtnColor;
      if (!!this.isCalendarBtnDisabled)
        this.calendarBtnColor = this.ActiveBtnColor;
      this.addItemBtnColor = this.ActiveBtnColor;
      this.setInitialRadioBtnStatus();
    }
    else {
      this.addOfferBtnColor = this.InactiveBtnColor;
      this.addTermBtnColor = this.InactiveBtnColor;
      this.calendarBtnColor = this.InactiveBtnColor;
      this.addItemBtnColor = this.InactiveBtnColor;
      this.isESDisabled = true;
      this.isPPDisabled = true;
      this.caseLineInfoData.isDataChanged = false;
    }
  }

  setESPanelDisable() {
    this.isESDisabled = true;
    this.esBGColor = this.InactiveBtnColor;
    this.isPPDisabled = false;
    this.ppBGColor = this.ActiveBgColor;
    this.isPerformancePeriodChecked = true;
    this.isEstimatedServiceChecked = false;
  }

  setPPPanelDisable() {
    this.isESDisabled = false;
    this.esBGColor = this.ActiveBgColor;
    this.isPPDisabled = true;
    this.ppBGColor = this.InactiveBtnColor;
    this.isPerformancePeriodChecked = false;
    this.isEstimatedServiceChecked = true;
  }

  setInitialRadioBtnStatus() {
    if (LineUtils.isThereValueInPPFields(false, this.caseLineInfoData)) {
      this.setESPanelDisable();
    }
    else if (LineUtils.isThereValueInESFields(false, this.caseLineInfoData)) {
      this.setPPPanelDisable();
    }
  }

  //Since this is a tab window, have to initialize needed attributes 
  //for this tab as such caseLineInfoData inherits an interface class.
  initializeCaseLineInfo() {
    this.caseLineInfoData = {
      //this is for Header section
      wm_USER_CASE_LINE_NUMBER_ID: '',
      wm_USER_CASE_SUBLINE_TX: '',
      wm_CASE_LINE_LOI_IN: false,
      wm_CML_SERVICES_COMPLETE_IN: false,
      wm_EXCLUSION_IN: false,
      wm_CASE_VERSION_STATUS_CD: '',
      change_ACTION_TITLE_NM: '',
      offer_EXPIRATION_DT: '',
      implementing_AGENCY_ID: '',
      LINESUBLINESEQVIR: '',
      case_CUSTOMER_TYPE_CD: '',
      customer_ORGANIZATION_ID: '',
      //this is for Line Detail tab
      case_LINE_ITEM_QY: '', generic_CD: '', military_ARTICLE_SERVICE_CD: '',
      line_PURPOSE_CD: '', line_PURPOSE_TITLE_NM: '', issue_UNIT_CD: '',
      article_DESCRIPTION_TX: '', major_DEFENSE_EQUIPMENT_CD: '', equipment_TYPE_TITLE_NM: '',
      stock_ON_ORDER_COST_AM: '0', stock_ON_HAND_COST_AM: '0', total_ABOVE_LINE_COST_AM: '',
      unit_ABOVE_LINE_COST_AM: '', part_NUMBER_IN: false, other_PART_NUMBER_IN: false,
      acquisition_VALUE_AM: '0', inventory_VALUE_AM: '0', percent_STOCK_RT: '',
      missile_TECH_CNTRL_REGIME_ID: '', mtcr_TITLE_NM: '', mde_SME_CD: '', parent_MDE_SME_CD: '',
      national_STOCK_NUMBER_ID: '', other_NATIONAL_STOCK_NUMBER_ID: '',
      caseLineAssistanceTypeList: [],
      //this is for delivery tab
      case_LINE_PERIOD_START_QY: '', case_LINE_PERIOD_END_QY: '',
      case_LINE_PAY_PERIOD_START_QY: '', case_LINE_PAY_PERIOD_END_QY: '',
      case_LINE_AVAILABILITY_LEAD_QY: '', case_LINE_SHIPMENT_TX: '',
      estimated_DELIVERY_END_DT: '',
      estimated_DELIVERY_DT: '',
      shipment_STATUS_ID: '',
      title_NM: '',
      sumOfAllQuantities: 0,
      caseLineDeliveryItemList: [], caseLineOfferReleaseList: [], caseLineDeliveryTermList: [],
       //private attributes
      isLinePurposeDisabled: false
    }
    LineUtils.theDeletedCLDIListArray = [];
    LineUtils.theDeletedCLDSListArray = [];
    LineUtils.theDeletedCLDTListArray = [];
    LineUtils.theDeletedCLORListArray = [];
  }

  //This function sorts the given list in ascending order for seqence code
  sortCLReferenceList(pData: any) {
    pData.sort((object1, object2) => {
      if (object1.sequence_CD > object2.sequence_CD) {
        return 1;
      }
      if (object1.sequence_CD < object2.sequence_CD) {
        return -1;
      }
      return 0;
    })
  }

  initializeOfferReleaseArray(pCaseLineOfferReleaseList: any) {
    this.aOfferReleaseRowIndex = pCaseLineOfferReleaseList.length;
    this.dataSourceOfferRelease.data = [];
    if (this.caseLineInfoData.status !== DsamsConstants.ENT_NEW.toString() &&
      !!(this.caseLineInfoData.caseLineOfferReleaseList[this.aOfferReleaseRowIndex - 1])) {
      if (this.caseLineInfoData.caseLineOfferReleaseList[this.aOfferReleaseRowIndex - 1].sequence_CD !== null)
        this.anOfferSequenceCd = this.caseLineInfoData.caseLineOfferReleaseList[this.aOfferReleaseRowIndex - 1].sequence_CD;
    }
    for (let i = 0; i < this.aOfferReleaseRowIndex; i++) {
      this.caseLineInfoData.caseLineOfferReleaseList[i].status = DsamsConstants.ENT_UNCHANGED.toString();
      this.caseLineInfoData.caseLineOfferReleaseList[i].isDeleteAllowed = false;
      this.caseLineInfoData.caseLineOfferReleaseList[i].isFieldDisabled = true;
      this.caseLineInfoData.caseLineOfferReleaseList[i].deleteBgColor = this.InactiveBtnColor;
      this.dataSourceOfferRelease.data.push(this.caseLineInfoData.caseLineOfferReleaseList[i]);
    }
    if (!!this.dataSourceOfferRelease.data) {
      this.sortCLReferenceList(this.dataSourceOfferRelease.data);
    }
    this.dataSourceOfferRelease._updateChangeSubscription();
  }

  initializeDeliveryTermArray(pCaseLineDeliveryTermList: any) {
    this.aDeliveryTermRowIndex = pCaseLineDeliveryTermList.length;
    this.dataSourceDeliveryTerm.data = [];
    if (this.caseLineInfoData.status !== DsamsConstants.ENT_NEW.toString() &&
      !!(this.caseLineInfoData.caseLineDeliveryTermList[this.aDeliveryTermRowIndex - 1]))
      this.aDTSequenceCd = this.caseLineInfoData.caseLineDeliveryTermList[this.aDeliveryTermRowIndex - 1].sequence_CD;
    for (let i = 0; i < this.aDeliveryTermRowIndex; i++) {
      this.caseLineInfoData.caseLineDeliveryTermList[i].status = DsamsConstants.ENT_UNCHANGED.toString();
      this.caseLineInfoData.caseLineDeliveryTermList[i].isDeleteAllowed = false;
      this.caseLineInfoData.caseLineDeliveryTermList[i].isFieldDisabled = true;
      this.caseLineInfoData.caseLineDeliveryTermList[i].deleteBgColor = this.InactiveBtnColor;
      this.dataSourceDeliveryTerm.data.push(this.caseLineInfoData.caseLineDeliveryTermList[i]);
    }
    if (!!this.dataSourceDeliveryTerm.data) {
      this.sortCLReferenceList(this.dataSourceDeliveryTerm.data);
    }

    this.dataSourceDeliveryTerm._updateChangeSubscription();
  }

  initializeItemArray(pCaseLineDeliveryItemList: any) {
    this.caseLineInfoData.sumOfAllQuantities = 0;
    this.anItemRowIndex = pCaseLineDeliveryItemList.length;
    this.dataSourceItem.data = [];
    for (let i = 0; i < this.anItemRowIndex; i++) {
      this.caseLineInfoData.caseLineDeliveryItemList[i].status = DsamsConstants.ENT_UNCHANGED.toString();
      this.caseLineInfoData.caseLineDeliveryItemList[i].aCurrentCalendarYear = 0;
      this.dataSourceItem.data.push(this.caseLineInfoData.caseLineDeliveryItemList[i]);
      //set enable or disable delete button
      if (this.caseLineInfoData.caseLineDeliveryItemList[i].caseLineDeliveryScheduleList) {
        if (this.caseLineInfoData.caseLineDeliveryItemList[i].caseLineDeliveryScheduleList.length > 0) {
          this.initializeCalendarArray(i, this.caseLineInfoData.caseLineDeliveryItemList[i].caseLineDeliveryScheduleList, true);
          if (this.caseLineRelatedInfoData.case_VERSION_STATUS_CD.toUpperCase() !== 'D') {
            this.caseLineInfoData.caseLineDeliveryItemList[i].isDeleteAllowed = false;
            this.caseLineInfoData.caseLineDeliveryItemList[i].deleteBgColor = this.InactiveBtnColor;
          }
          this.caseLineInfoData.caseLineDeliveryItemList[i].sumOfAllItemQuantities = this.getTotalItemQuantity(i);
          //get the total item quantity of the first item only
          if (i == 0) this.sumOfAllItemQuantities = this.caseLineInfoData.caseLineDeliveryItemList[i].sumOfAllItemQuantities;
        }
      }
      else {
        this.caseLineInfoData.caseLineDeliveryItemList[i].deleteBgColor = this.ActiveDeleteBtnColor;
        this.caseLineInfoData.caseLineDeliveryItemList[i].isDeleteAllowed = true;
      }
    }
    this.dataSourceItem._updateChangeSubscription();
  }

  setDeleteButtonState(parentIndex: number, pCurrentIndex: number) {
    //set enable or disable delete button
    if (this.caseLineRelatedInfoData.case_VERSION_STATUS_CD.toUpperCase() == 'D') {
      this.caseLineInfoData.caseLineDeliveryItemList[parentIndex].
        caseLineDeliveryScheduleList[pCurrentIndex].isDeleteAllowed = true;
      this.caseLineInfoData.caseLineDeliveryItemList[parentIndex].
        caseLineDeliveryScheduleList[pCurrentIndex].deleteBgColor = this.ActiveDeleteBtnColor;
    }
    else {
      if (!!this.caseLineInfoData.caseLineDeliveryItemList[parentIndex].
        caseLineDeliveryScheduleList[pCurrentIndex]) {
        if (this.caseLineInfoData.caseLineDeliveryItemList[parentIndex].
          caseLineDeliveryScheduleList.length > 0) {
          this.caseLineInfoData.caseLineDeliveryItemList[parentIndex].
            caseLineDeliveryScheduleList[pCurrentIndex].isDeleteAllowed = false;
          this.caseLineInfoData.caseLineDeliveryItemList[parentIndex].
            caseLineDeliveryScheduleList[pCurrentIndex].deleteBgColor = this.InactiveBtnColor;
        }
      }
      else {
        this.caseLineInfoData.caseLineDeliveryItemList[parentIndex].
          caseLineDeliveryScheduleList[pCurrentIndex].deleteBgColor = this.ActiveDeleteBtnColor;
        this.caseLineInfoData.caseLineDeliveryItemList[parentIndex].
          caseLineDeliveryScheduleList[pCurrentIndex].isDeleteAllowed = true;
      }
    }
  }

  //Initialize objects
  initializeCalendarArray(parentIndex: any, pCLDSList: any, pUpdateStatus: boolean) {
    this.aCalendarRowIndex = pCLDSList.length;
    for (let i = 0; i < this.aCalendarRowIndex; i++) {
      if (pUpdateStatus)
        this.caseLineInfoData.caseLineDeliveryItemList[parentIndex].
          caseLineDeliveryScheduleList[i].status = DsamsConstants.ENT_UNCHANGED.toString();
      //FR30-33
      if (this.caseLineInfoData.change_ACTION_CD.toUpperCase() == LineDeliveryComponent.CHANGE_ACTION_CD_ADDED)
        this.caseLineInfoData.caseLineDeliveryItemList[parentIndex].
          caseLineDeliveryScheduleList[i].isFieldModifiable = true;
      else this.caseLineInfoData.caseLineDeliveryItemList[parentIndex].
        caseLineDeliveryScheduleList[i].isFieldModifiable = false;

      //set enable or disable delete button
      this.setDeleteButtonState(parentIndex, i);

      //FR29 store the last Calendar Year in item list
      if (!!this.caseLineInfoData.caseLineDeliveryItemList[parentIndex].aCurrentCalendarYear)
        this.caseLineInfoData.caseLineDeliveryItemList[parentIndex].aCurrentCalendarYear = this.caseLineInfoData.caseLineDeliveryItemList[parentIndex].
          caseLineDeliveryScheduleList[i].calendar_YEAR_ID;

      this.dataSourceCalendar.data.push(this.caseLineInfoData.caseLineDeliveryItemList[parentIndex].
        caseLineDeliveryScheduleList[i]);
    }
  }

  addNewOfferRelease() {
    var anOfferReleaseObject: ifaceOfferReleaseEntity = { offer_RELEASE_ID: '', offer_RELEASE_TITLE_NM: '' };
    var aCLOfferReleaseObject: ifaceCaseLineOfferReleaseEntity =
    {
      offer_RELEASE_ID: '', status: DsamsConstants.ENT_NEW.toString(), sequence_CD: ++this.anOfferSequenceCd,
      theOfferReleaseId: anOfferReleaseObject, isDeleteAllowed: true,
      isFieldDisabled: false,
      //fcFieldRequired: new FormControl('', [Validators.required]),
    }
    // for new entity
    if (this.caseLineInfoData.caseLineOfferReleaseList == null) {
      this.caseLineInfoData.caseLineOfferReleaseList = []
      this.aOfferReleaseRowIndex = 0;
    }
    this.caseLineInfoData.caseLineOfferReleaseList.push(aCLOfferReleaseObject);
    this.dataSourceOfferRelease.data.push(aCLOfferReleaseObject);
    this.dataSourceOfferRelease = new MatTableDataSource(this.dataSourceOfferRelease.data);
    this.dataSourceOfferRelease._updateChangeSubscription();
    this.aOfferReleaseRowIndex++
    this.caseLineInfoData.isDataChanged = true;
    this.setChangedSaveState();
  }

  addNewDeliveryTerm() {
    var aDeliverTermObject: ifaceDeliveryTermEntity = { delivery_TERM_ID: '', delivery_TERM_TITLE_NM: '' };
    var aCLDeliverTermObject: ifaceCaseLineDeliveryTermEntity =
    {
      delivery_TERM_ID: '', status: DsamsConstants.ENT_NEW.toString(), sequence_CD: ++this.aDTSequenceCd,
      theDeliveryTermId: aDeliverTermObject, isDeleteAllowed: true,
      isFieldDisabled: false,
      //fcFieldRequired: new FormControl('', [Validators.required]),
    }
    // for new entity
    if (this.caseLineInfoData.caseLineDeliveryTermList == null) {
      this.caseLineInfoData.caseLineDeliveryTermList = []
    }
    this.caseLineInfoData.caseLineDeliveryTermList.push(aCLDeliverTermObject);
    this.dataSourceDeliveryTerm.data.push(aCLDeliverTermObject);
    this.dataSourceDeliveryTerm = new MatTableDataSource(this.dataSourceDeliveryTerm.data);
    this.dataSourceDeliveryTerm._updateChangeSubscription();
    this.caseLineInfoData.isDataChanged = true;
    this.setChangedSaveState();
  }

  addNewItem() {
    var aCLDeliverItemObject: ifaceCaseLineDeliveryItemEntity =
    {
      item_CD: '',
      status: DsamsConstants.ENT_NEW.toString(),
      caseLineDeliveryScheduleList: [], isDeleteAllowed: true,
      //fcFieldRequired: new FormControl('', [Validators.required]),
    }
    // for new entity
    if (this.caseLineInfoData.caseLineDeliveryItemList == null) {
      this.caseLineInfoData.caseLineDeliveryItemList = []
    }
    this.caseLineInfoData.caseLineDeliveryItemList.push(aCLDeliverItemObject);
    this.dataSourceItem.data.push(aCLDeliverItemObject);
    this.dataSourceItem = new MatTableDataSource(this.dataSourceItem.data);
    this.dataSourceItem._updateChangeSubscription();
    this.caseLineInfoData.isDataChanged = true;
    this.setChangedSaveState();
  }

  //FR29
  /* this method adds the passing number of days to the selected date */
  getDefaultCalendarYear(pDateStr: string): number {
    let realDateObj = new Date(pDateStr);
    realDateObj.setDate(realDateObj.getDate() + 4);
    return realDateObj.getFullYear();
  }

  getQuarterOfYear(pDateStr: string, pCurrentYear: number): number {
    if (pDateStr == '') return 0;
    let realDateObj = new Date(pDateStr);
    let month = realDateObj.getMonth();
    var quarter: number = 0;
    if (this.getDefaultCalendarYear(pDateStr) == pCurrentYear) {
      if (month < 4)
        quarter = 1;
      else if (month < 7)
        quarter = 2;
      else if (month < 10)
        quarter = 3;
      else if (month < 13)
        quarter = 4;
    }
    return quarter;
  }

  //Do this as part of sonarqube cleanup
  resetCalendarRow(curDeliveryIndex: number) {
    if (this.caseLineInfoData.caseLineDeliveryItemList[curDeliveryIndex].caseLineDeliveryScheduleList == null) {
      this.caseLineInfoData.caseLineDeliveryItemList[curDeliveryIndex].caseLineDeliveryScheduleList = []
      this.aCalendarRowIndex = 0;
    }
  }

  setDefaultOfferExpirationDate(curDeliveryIndex: number) {
    if (this.caseLineInfoData.caseLineDeliveryItemList[curDeliveryIndex].aCurrentCalendarYear == null ||
      this.caseLineInfoData.caseLineDeliveryItemList[curDeliveryIndex].aCurrentCalendarYear == 0)
      this.caseLineInfoData.caseLineDeliveryItemList[curDeliveryIndex].aCurrentCalendarYear =
        this.caseLineInfoData.offer_EXPIRATION_DT ? this.getDefaultCalendarYear(this.caseLineInfoData.offer_EXPIRATION_DT) : 0;
    else this.caseLineInfoData.caseLineDeliveryItemList[curDeliveryIndex].aCurrentCalendarYear++;

  }

  addNewCalendar() {
    var aCLDeliverScheduleObject: ifaceCaseLineDeliveryScheduleEntity =
    {
      calendar_YEAR_ID: 0,
      case_LINE_DEL_SET_Q1_QY: 0, case_LINE_DEL_SET_Q2_QY: 0,
      case_LINE_DEL_SET_Q3_QY: 0, case_LINE_DEL_SET_Q4_QY: 0,
      status: DsamsConstants.ENT_NEW.toString(),
      isFieldModifiable: true, isDeleteAllowed: true,
      isCLDSQ1Modifiable: true,
      isCLDSQ2Modifiable: true,
      isCLDSQ3Modifiable: true,
      isCLDSQ4Modifiable: true,
    }

    let curDeliveryIndex = this.aCurItemSelectedRow;
    if (!!this.caseLineInfoData.caseLineDeliveryItemList[curDeliveryIndex]) {
      //FR29 - default calendar year
      this.setDefaultOfferExpirationDate(curDeliveryIndex);
      aCLDeliverScheduleObject.calendar_YEAR_ID = this.caseLineInfoData.caseLineDeliveryItemList[curDeliveryIndex].aCurrentCalendarYear;
      this.resetCalendarRow(curDeliveryIndex);

      if (this.caseLineInfoData.caseLineDeliveryItemList[curDeliveryIndex].case_LINE_DELIVERY_ITEM_ID &&
        parseInt(this.caseLineInfoData.caseLineDeliveryItemList[curDeliveryIndex].case_LINE_DELIVERY_ITEM_ID) > 0)
        aCLDeliverScheduleObject.case_LINE_DELIVERY_ITEM_ID =
          this.caseLineInfoData.caseLineDeliveryItemList[curDeliveryIndex].case_LINE_DELIVERY_ITEM_ID;
      this.caseLineInfoData.caseLineDeliveryItemList[curDeliveryIndex].caseLineDeliveryScheduleList.push(aCLDeliverScheduleObject);
      this.dataSourceCalendar.data.push(aCLDeliverScheduleObject);
      this.dataSourceCalendar = new MatTableDataSource(this.dataSourceCalendar.data);
      this.dataSourceCalendar._updateChangeSubscription();
      this.aCalendarRowIndex++
      this.caseLineInfoData.isDataChanged = true;
      this.setChangedSaveState();
    }
    else {
      MessageMgr.swalFire({
        icon: 'error',
        html: '<font color="red">An Item must be selected.</font>',
        width: 400,
        focusConfirm: true,
        confirmButtonText: 'OK'
      });
    }
  }

  delOfferReleaseRow(rowElement: any) {
    this.caseLineInfoData.isDataChanged = true;
    this.setChangedSaveState();
    let rowIndex = this.dataSourceOfferRelease.data.indexOf(rowElement);
    if (this.caseLineInfoData.status !== DsamsConstants.ENT_NEW.toString()) {
      if (this.caseLineInfoData.caseLineOfferReleaseList[rowIndex].status !== DsamsConstants.ENT_NEW.toString()) {
        if (LineUtils.theDeletedCLORListArray == null) LineUtils.theDeletedCLORListArray = [];
        this.caseLineInfoData.caseLineOfferReleaseList[rowIndex].status = DsamsConstants.ENT_DELETED.toString();
        LineUtils.theDeletedCLORListArray.push(this.caseLineInfoData.caseLineOfferReleaseList[rowIndex]);
        this.caseUIService.setTheDeletedCLORList(LineUtils.theDeletedCLORListArray);
      }
      //set it to changed so it can be updated
      this.caseLineInfoData.entityStatus = DsamsConstants.ENT_CHANGED.toString();
    }
    this.caseLineInfoData.caseLineOfferReleaseList.splice(
      this.caseLineInfoData.caseLineOfferReleaseList.indexOf(rowElement), 1);
    this.dataSourceOfferRelease.data.splice(this.dataSourceOfferRelease.data.indexOf(rowElement), 1);
    this.dataSourceOfferRelease = new MatTableDataSource(this.dataSourceOfferRelease.data);
  }

  delDeliveryTermRow(rowElement: any) {
    this.caseLineInfoData.isDataChanged = true;
    this.setChangedSaveState();
    let rowIndex = this.dataSourceDeliveryTerm.data.indexOf(rowElement);
    if (this.caseLineInfoData.status !== DsamsConstants.ENT_NEW.toString()) {
      if (this.caseLineInfoData.caseLineDeliveryTermList[rowIndex].status !== DsamsConstants.ENT_NEW.toString()) {
        if (LineUtils.theDeletedCLDTListArray == null) LineUtils.theDeletedCLDTListArray = [];
        this.caseLineInfoData.caseLineDeliveryTermList[rowIndex].status = DsamsConstants.ENT_DELETED.toString();
        LineUtils.theDeletedCLDTListArray.push(this.caseLineInfoData.caseLineDeliveryTermList[rowIndex]);
        this.caseUIService.setTheDeletedCLDTList(LineUtils.theDeletedCLDTListArray);
      }
      //set it to changed so it can be updated
      this.caseLineInfoData.entityStatus = DsamsConstants.ENT_CHANGED.toString();
    }
    this.caseLineInfoData.caseLineDeliveryTermList.splice(
      this.caseLineInfoData.caseLineDeliveryTermList.indexOf(rowElement), 1);

    this.dataSourceDeliveryTerm.data.splice(this.dataSourceDeliveryTerm.data.indexOf(rowElement), 1);
    this.dataSourceDeliveryTerm = new MatTableDataSource(this.dataSourceDeliveryTerm.data);
  }

  delItemRow(rowElement: any) {
    this.caseLineInfoData.isDataChanged = true;
    this.setChangedSaveState();
    let rowIndex = this.dataSourceItem.data.indexOf(rowElement);
    if (this.caseLineInfoData.status !== DsamsConstants.ENT_NEW.toString()) {
      if (this.caseLineInfoData.caseLineDeliveryItemList[rowIndex].status !== DsamsConstants.ENT_NEW.toString()) {
        if (LineUtils.theDeletedCLDIListArray == null) LineUtils.theDeletedCLDIListArray = [];
        this.caseLineInfoData.caseLineDeliveryItemList[rowIndex].status = DsamsConstants.ENT_DELETED.toString();
        LineUtils.theDeletedCLDIListArray.push(this.caseLineInfoData.caseLineDeliveryItemList[rowIndex]);
        //console.log('delete',LineUtils.theDeletedCLDIListArray)
        this.caseUIService.setTheDeletedCLDIList(LineUtils.theDeletedCLDIListArray);
        this.deleteCalendarFromItemList(rowIndex);
      }
      //set it to changed so it can be updated
      this.caseLineInfoData.entityStatus = DsamsConstants.ENT_CHANGED.toString();
    }
    this.caseLineInfoData.caseLineDeliveryItemList.splice(
      this.caseLineInfoData.caseLineDeliveryItemList.indexOf(rowElement), 1);

    this.dataSourceItem.data.splice(this.dataSourceItem.data.indexOf(rowElement), 1);
    this.dataSourceItem = new MatTableDataSource(this.dataSourceItem.data);
    // this.anItemRowIndex--;
    //this.caseLineInfoData.isDeliveryItemValid = this.isMandatoryItemFieldValid();
    //set to calculate quantities of first item in the list
    this.sumOfAllItemQuantities = this.getTotalItemQuantity(0);
    if (this.dataSourceItem.data.length == 0) {
      this.isCalendarBtnDisabled = true;
      this.calendarBtnColor = this.InactiveBtnColor;
    }
    else this.setItemHighlightedRow(0);
  }

  deleteCalendarFromItemList(pItemIndex: any) {
    this.caseLineInfoData.caseLineDeliveryItemList[pItemIndex].
      caseLineDeliveryScheduleList.forEach(element => {
        if (LineUtils.theDeletedCLDSListArray == null) LineUtils.theDeletedCLDSListArray = [];
        element.status = DsamsConstants.ENT_DELETED.toString();
        LineUtils.theDeletedCLDSListArray.push(element);
        this.caseUIService.setTheDeletedCLDSList(LineUtils.theDeletedCLDSListArray);
        this.dataSourceCalendar.data.splice(this.dataSourceCalendar.data.indexOf(element), 1);
      })
    this.caseUIService.setTheDeletedCLDSList(LineUtils.theDeletedCLDSListArray);
    this.caseLineInfoData.caseLineDeliveryItemList[pItemIndex].caseLineDeliveryScheduleList = [];
    this.dataSourceCalendar = new MatTableDataSource(this.dataSourceCalendar.data);
  }

  delCalendarRow(rowElement: any) {
    this.caseLineInfoData.isDataChanged = true;
    this.setChangedSaveState();
    let rowIndex = this.dataSourceCalendar.data.indexOf(rowElement);
    if (this.caseLineInfoData.status !== DsamsConstants.ENT_NEW.toString())
      this.caseLineInfoData.caseLineDeliveryItemList[this.aCurItemSelectedRow].
        caseLineDeliveryScheduleList[rowIndex].status = DsamsConstants.ENT_DELETED.toString();
    this.caseLineInfoData.caseLineDeliveryItemList[this.aCurItemSelectedRow].caseLineDeliveryScheduleList.splice(
      this.caseLineInfoData.caseLineDeliveryItemList[this.aCurItemSelectedRow].
        caseLineDeliveryScheduleList.indexOf(rowElement), 1);
    this.dataSourceCalendar.data.splice(this.dataSourceCalendar.data.indexOf(rowElement), 1);
    this.dataSourceCalendar = new MatTableDataSource(this.dataSourceCalendar.data);
    //Recalculate quantities of first item in the list
    this.sumOfAllItemQuantities = this.getTotalItemQuantity(rowIndex);
    //reset calendar
    if (this.caseLineInfoData.caseLineDeliveryItemList[this.aCurItemSelectedRow].caseLineDeliveryScheduleList.length == 0) {
      this.caseLineInfoData.caseLineDeliveryItemList[this.aCurItemSelectedRow].aCurrentCalendarYear = 0;
    }
  }

  //FR17
  validateDeliveryTermCode(pValue: any) {
    var validatedDeliveryValues: string[] = ['2', '4', '7', '9'];
    let displayMsg: boolean = false;
    let htmlStr: string = '<hr><div align="left">';
    // Only validate if it's a subline or a case line with no sublines.
    if (!validatedDeliveryValues.includes(pValue, 0) &&
      (!CaseUtils.isBlankStr(this.caseLineInfoData.wm_USER_CASE_SUBLINE_TX) || !this.caseLineInfoData.wm_HAS_SUBLINES)
    ) {
      displayMsg = true;
      htmlStr += '<font color="red"> For Security Cooperation Program cases, Delivery Term Codes should be 2,4,7,9.';
    }
    if (displayMsg) {
      MessageMgr.swalFire({
        // title: 'Line Delivery',
        icon: 'warning',
        html: htmlStr,
        width: 400,
        focusConfirm: true,
        confirmButtonText: 'OK'
      })
    }
  }

  //FR18
  onPerformancePeriodRadioBtnClick() {
    if (this.isLineDeliveryDisabled) return true;
    if (this.isPerformancePeriodChecked && !this.isEstimatedServiceChecked) return true;
    this.setChangedSaveState();
    this.isPerformancePeriodChecked = !this.isPerformancePeriodChecked;
    this.isEstimatedServiceChecked = !this.isEstimatedServiceChecked;
    if (this.isPerformancePeriodChecked) {
      if (LineUtils.isThereValueInESFields(true, this.caseLineInfoData)) {
        let htmlStr: string = '<hr><div align="left">';
        if (!!this.caseLineInfoData.wm_USER_CASE_SUBLINE_TX)
          htmlStr += '<font color="red"> Data must be deleted from Estimated Service Dates before proceeding for the subline.';
        else
          htmlStr += '<font color="red">Data must be deleted from Estimated Service Dates before proceeding for line.';
        htmlStr += "";
        MessageMgr.swalFire({
          // title: 'Line Delivery',
          icon: 'error',
          html: htmlStr,
          width: 400,
          focusConfirm: true,
          confirmButtonText: 'OK'
        })
      }
      else {
        this.isESDisabled = true;
        this.isLeadTimeDisabled = true;
        this.esBGColor = this.InactiveBtnColor;
        this.isPPDisabled = false;
        this.ppBGColor = this.ActiveBgColor;
        this.isEstimatedServiceChecked = false;
      }
    }
    else {
      this.isESDisabled = false;
      if (this.isInitialLeadTimeDisabled) this.isLeadTimeDisabled = true;
      else this.isLeadTimeDisabled = false;
      this.esBGColor = this.ActiveBgColor;
      this.isPPDisabled = true;
      this.ppBGColor = this.InactiveBtnColor;
      this.isEstimatedServiceChecked = false
    }
  }

  //callback event check
  onEstimatedServiceRadioBtnClick() {
    if (this.isLineDeliveryDisabled) return true;
    if (this.isEstimatedServiceChecked && !this.isPerformancePeriodChecked) return true;
    this.isEstimatedServiceChecked = !this.isEstimatedServiceChecked;
    this.isPerformancePeriodChecked = !this.isPerformancePeriodChecked;
    if (this.isEstimatedServiceChecked) {
      //FR23
      if (this.isEstimatedServiceFieldsValid()) {
        this.isESDisabled = false;
        if (this.isInitialLeadTimeDisabled) this.isLeadTimeDisabled = true;
        else this.isLeadTimeDisabled = false;
        this.esBGColor = this.ActiveBgColor;
        this.isPPDisabled = true;
        this.ppBGColor = this.InactiveBtnColor;
        this.isPerformancePeriodChecked = false;
      }
    }
    else {
      this.isESDisabled = true;
      this.isLeadTimeDisabled = true;
      this.esBGColor = this.InactiveBtnColor;
      this.isPPDisabled = false;
      this.ppBGColor = this.ActiveBgColor;
      this.isPerformancePeriodChecked = false;
    }

  }
  //FR19 additional - Performance Period From (for the line/subline)
  doesESFieldsHaveValues(): boolean {
    let htmlStr: string = '<hr><div align="left">';
    htmlStr += '<font color="red"> Please ensure the payment schedule overrides are updated if necessary';
    htmlStr += "";

    if (!CaseUtils.isBlankStr(this.caseLineInfoData.case_LINE_PAY_PERIOD_START_QY) ||
      !CaseUtils.isBlankStr(this.caseLineInfoData.case_LINE_PAY_PERIOD_END_QY)) {
      if
        (CaseUtils.isBlankStr(this.caseLineInfoData.case_LINE_PERIOD_START_QY) ||
        CaseUtils.isBlankStr(this.caseLineInfoData.case_LINE_PERIOD_END_QY) ||
        CaseUtils.isBlankStr(this.caseLineInfoData.estimated_DELIVERY_DT) ||
        CaseUtils.isBlankStr(this.caseLineInfoData.estimated_DELIVERY_END_DT) ||
        CaseUtils.isBlankStr(this.caseLineInfoData.case_LINE_AVAILABILITY_LEAD_QY)) {
        MessageMgr.swalFire({
          // title: 'Line Delivery',
          icon: 'error',
          html: htmlStr,
          width: 400,
          focusConfirm: true,
          confirmButtonText: 'OK'
        })
        return false;
      }
    }
    return true;
  }

  isFieldEqualZero(pStrValue: string): boolean {
    if (!CaseUtils.isBlankStr(pStrValue)) {
      if (parseInt(pStrValue) == 0) return true
    }
    return false;
  }

  //FR20 Performance Period To (for the line/subline) 
  // This is a real time validation check. Keep it here for now
  isPerformancePeriodFromValid(): boolean {
    let htmlStr: string = '<hr><div align="left">';
    //Performance Period From must be greater than 0
    if (this.isFieldEqualZero(this.caseLineInfoData.case_LINE_PERIOD_START_QY)) {
      htmlStr = '<font color="red"> 	Performance Period From must be greater than 0.';
      MessageMgr.swalFire({
        // title: 'Line Delivery',
        icon: 'error',
        html: htmlStr,
        width: 400,
        focusConfirm: true,
        confirmButtonText: 'OK'
      })
    }
    return false;
  }

  //FR19 Performance Period From (for the line/subline)
  isPerformancePeriodToValid(): boolean {
    //no need to do further field validation when PP From is null
    // if (CaseUtils.isBlankStr(this.caseLineInfoData.case_LINE_PERIOD_END_QY)) return true;
    let displayMsg: boolean = false;
    let displayMsg1: boolean = false;
    let htmlStr: string = '<hr><div align="left">';
    let htmlStr1: string = '<hr><div align="left">';
    if (!!this.caseLineInfoData.wm_USER_CASE_SUBLINE_TX) {
      htmlStr += '<font color="red"> If entered, the Performance Period for the subline must contain both “From” and “To” portions.';
      htmlStr1 += '<font color="red"> The subline Performance Period start month (From) must not exceed the subline Performance Period end month (To).';
    }
    else {
      htmlStr += '<font color="red"> If entered, the Performance Period for the line must contain both “From” and “To” portions.';
      htmlStr1 += '<font color="red"> The line Performance Period start month (From) must not exceed the line performance period end month (To).';
    }
    htmlStr += "";
    htmlStr1 += "";

    //Performance Period To must be greater than 0
    if (this.isFieldEqualZero(this.caseLineInfoData.case_LINE_PERIOD_END_QY)) {
      htmlStr = '<font color="red"> 	Performance Period To must be greater than 0.';
      displayMsg = true;
    }
    //Performance Period From value must be ≤ the Period To value.
    if (!(CaseUtils.isBlankStr(this.caseLineInfoData.case_LINE_PERIOD_START_QY)) &&
      !(CaseUtils.isBlankStr(this.caseLineInfoData.case_LINE_PERIOD_END_QY))) {
      if ((parseInt(this.caseLineInfoData.case_LINE_PERIOD_START_QY)) > (parseInt(this.caseLineInfoData.case_LINE_PERIOD_END_QY))) {
        displayMsg1 = true;
      }
    }
    if (displayMsg) {
      MessageMgr.swalFire({
        // title: 'Line Delivery',
        icon: 'error',
        html: htmlStr,
        width: 400,
        focusConfirm: true,
        confirmButtonText: 'OK'
      })
      return false;
    }
    else if (displayMsg1) {
      MessageMgr.swalFire({
        // title: 'Line Delivery',
        icon: 'error',
        html: htmlStr1,
        width: 400,
        focusConfirm: true,
        confirmButtonText: 'OK'
      })
      return false;
    }
    return true;
  }

  // //FR21 Payment Schedule Override From
  isPaymentScheduleOverrideFromValid(): boolean {
    //no need to do further field validation when Payment Schedule Override From is null
    let displayMsg: boolean = false;
    let htmlStr: string = '<hr><div align="left">';
    htmlStr += '<font color="red">  Payment Schedule Override From is required. <br>';
    if ((CaseUtils.isBlankStr(this.caseLineInfoData.case_LINE_PAY_PERIOD_START_QY)) &&
      !(CaseUtils.isBlankStr(this.caseLineInfoData.case_LINE_PAY_PERIOD_END_QY))) {
      displayMsg = true;
    }
    // not needed until payment schedule is implemented
    if (displayMsg) {
      MessageMgr.swalFire({
        icon: 'error',
        html: htmlStr,
        width: 400,
        focusConfirm: true,
        confirmButtonText: 'OK'
      })
      return false;
    }
    return true;
  }

  //FR22 Payment Schedule Override To
  isPaymentScheduleOverrideToValid(): boolean {

    //no need to do further field validation when Payment Schedule Override To is null
    // if (CaseUtils.isBlankStr(this.caseLineInfoData.case_LINE_PAY_PERIOD_START_QY)) return true;
    let displayMsg: boolean = false;
    let htmlStr: string = '<hr><div align="left">';
    htmlStr += '<font color="red">  Payment Schedule Override To is required. <br>';
    if ((CaseUtils.isBlankStr(this.caseLineInfoData.case_LINE_PAY_PERIOD_END_QY)) &&
      !(CaseUtils.isBlankStr(this.caseLineInfoData.case_LINE_PAY_PERIOD_START_QY))) {
      displayMsg = true;
    }
    if (displayMsg) {
      MessageMgr.swalFire({
        icon: 'error',
        html: htmlStr,
        width: 400,
        focusConfirm: true,
        confirmButtonText: 'OK'
      })
      return false;
    }
    return true;
  }

  //FR23 Estimated Service Dates radiobutton
  isEstimatedServiceFieldsValid(): boolean {
    // If the Performance Period From and To dates or Payment Schedule Override From and To dates 
    // (spec clarification needed for Availability/Lead-time exist), then display an error message 
    if (LineUtils.isThereValueInPPFields(false, this.caseLineInfoData)) {
      let htmlStr: string = '<hr><div align="left">';
      if (!!this.caseLineInfoData.wm_USER_CASE_SUBLINE_TX)
        htmlStr += '<font color="red"> Data must be deleted from Performance Period before proceeding for subline.';
      else htmlStr += '<font color="red">Data must be deleted from Performance Period before proceeding for line.';
      htmlStr += "";
      MessageMgr.swalFire({
        icon: 'error',
        html: htmlStr,
        width: 400,
        focusConfirm: true,
        confirmButtonText: 'OK'
      })
      return false;
    }
    return true;
  }
  //FR24 Estimated Service Dates From (for the line/subline) 
  isESFromDateValid(): boolean {
    //no need to do further field validation when Estimated Service Dates From is null
    if (this.caseLineInfoData.estimated_DELIVERY_DT == null) return true;
    let displayMsg: boolean = false;
    let displayMsg1: boolean = false;
    let htmlStr: string = '<hr><div align="left">';
    let htmlStr1: string = '<hr><div align="left">';
    htmlStr += '<font color="red"> Estimated Service Dates To is required.';
    htmlStr1 += '<font color="red"> The Estimated Services From date must occur on or before the Estimated Services To date.';
    if (this.caseLineInfoData.estimated_DELIVERY_END_DT == null) displayMsg = true;
    if (this.caseLineInfoData.estimated_DELIVERY_DT > this.caseLineInfoData.estimated_DELIVERY_END_DT) {
      displayMsg1 = true;
    }
    if (displayMsg) {
      MessageMgr.swalFire({
        icon: 'error',
        html: htmlStr,
        width: 400,
        focusConfirm: true,
        confirmButtonText: 'OK'
      })
      return false;
    }
    else if (displayMsg1) {
      MessageMgr.swalFire({
        icon: 'error',
        html: htmlStr1,
        width: 400,
        focusConfirm: true,
        confirmButtonText: 'OK'
      })
      return false;
    }
    // not needed until payment schedule is implemented
    // if (!this.doesESFieldsHaveValues()) return false;
    return true;
  }
  //FR25 Estimated Service Dates To (for the line/subline
  isESToDateValid(): boolean {
    //no need to do further field validation when Estimated Service Dates From is null
    if (this.caseLineInfoData.estimated_DELIVERY_END_DT == null) return true;
    let displayMsg: boolean = false;
    let displayMsg1: boolean = false;
    let htmlStr: string = '<hr><div align="left">';
    let htmlStr1: string = '<hr><div align="left">';
    htmlStr += '<font color="red"> Estimated Service Dates From is required.';
    htmlStr1 += '<font color="red"> The Estimated Services To date must occur on or after the Estimated Services From date.';
    if (this.caseLineInfoData.estimated_DELIVERY_DT == null) displayMsg = true;
    if (this.caseLineInfoData.estimated_DELIVERY_END_DT < this.caseLineInfoData.estimated_DELIVERY_DT) {
      displayMsg1 = true;
    }
    if (displayMsg) {
      MessageMgr.swalFire({
        icon: 'error',
        html: htmlStr,
        width: 400,
        focusConfirm: true,
        confirmButtonText: 'OK'
      })
      return false;
    }
    else if (displayMsg1) {
      MessageMgr.swalFire({
        icon: 'error',
        html: htmlStr1,
        width: 400,
        focusConfirm: true,
        confirmButtonText: 'OK'
      })
      return false;
    }
    // not needed until payment schedule is implemented
    // if (!this.doesESFieldsHaveValues()) return false;
    return true;
  }
  //FR26 Availability/Lead Time (in months) (for the line/subline)
  isLeadTimeValid(): boolean {

    //no need to do any further field validation
    if (this.caseLineInfoData.case_LINE_AVAILABILITY_LEAD_QY == null) return true;
    // not needed until payment schedule is implemented
    // if (parseInt(this.caseLineInfoData.case_LINE_AVAILABILITY_LEAD_QY) > 0) {
    //   if (!this.doesESFieldsHaveValues()) return false;
    // }
    if (this.caseLineInfoData.case_LINE_PERIOD_START_QY ||
      this.caseLineInfoData.case_LINE_PERIOD_END_QY ||
      this.caseLineInfoData.case_LINE_PAY_PERIOD_START_QY ||
      this.caseLineInfoData.case_LINE_PAY_PERIOD_END_QY ||
      this.caseLineInfoData.estimated_DELIVERY_DT ||
      this.caseLineInfoData.estimated_DELIVERY_END_DT) {
      let htmlStr: string = '<hr><div align="left">';
      if (!!this.caseLineInfoData.wm_USER_CASE_SUBLINE_TX)
        htmlStr += '<font color="red">Either Availability/Lead time, Performance Period or Estimated Service Dates can be specified for the line.';
      else htmlStr += '<font color="red"> Either Availability/Lead time, Performance Period or Estimated Service Dates can be specified for the subline.';
      MessageMgr.swalFire({
        icon: 'error',
        html: htmlStr,
        width: 400,
        focusConfirm: true,
        confirmButtonText: 'OK'
      })
      return false;
    }
    return true;
  }

  /* This procedure checks the returned result value from the 
       popover Yes/No dialog window. */
  yesButtonDeliveryTermOnClick(isDeleteConfirmed: any, rowElement: any) {
    if (isDeleteConfirmed)
      this.delDeliveryTermRow(rowElement);
  }
  /* This procedure checks the returned result value from the 
     popover Yes/No dialog window. */
  yesButtonOfferOnClick(isDeleteConfirmed: any, rowElement: any) {
    if (isDeleteConfirmed)
      this.delOfferReleaseRow(rowElement);
  }
  /* This procedure checks the returned result value from the 
       popover Yes/No dialog window. */
  yesButtonItemOnClick(isDeleteConfirmed: any, rowElement: any) {
    if (isDeleteConfirmed)
      this.delItemRow(rowElement);
  }
  /* This procedure checks the returned result value from the 
       popover Yes/No dialog window. */
  yesButtonCalendarOnClick(isDeleteConfirmed: any, rowElement: any) {
    if (isDeleteConfirmed)
      this.delCalendarRow(rowElement);
  }
  //store the modified valued to the case line entity for saving purposes
  onSelectionChange(pColumName: any, pValue: string) {
    if (this.isLineDeliveryDisabled) return;

    //To avoid using NgModel in Mat-Select, use this quick and simple approach to 
    //remap modified values selected on screen
    switch (pColumName) {
      case "shipment_STATUS_ID": {
        this.caseLineInfoData.shipment_STATUS_ID = pValue;
        if (!!this.caseLineInfoData.shipment_STATUS_ID) {
          if (this.caseLineInfoData.change_ACTION_CD.toUpperCase() == LineDeliveryComponent.CHANGE_ACTION_CD_ADDED)
            MessageMgr.swalFire({
              icon: 'warning',
              html: '<font color="red">You have applied Shipment or Completed to an Added Line. Do you want to continue?"</font>',
              width: 400,
              showCancelButton: true,
              cancelButtonText: 'No',
              confirmButtonColor: '#3085d6',
              focusConfirm: true,
              cancelButtonColor: '#d33',
              confirmButtonText: 'Yes',
            }).then((result) => {
              if (!result.value) {
                this.caseLineInfoData.shipment_STATUS_ID = '';
                this.caseLineInfoData.title_NM = '';
              }
            })
        }
        break;
      }
      //per Sonarqube rule
      case "noStatus": break;
      default: break;
    }
    if (this.caseLineInfoData.status !== DsamsConstants.ENT_NEW.toString()) {
      this.caseLineInfoData.status = DsamsConstants.ENT_CHANGED.toString();
      this.caseLineInfoData.entityStatus = DsamsConstants.ENT_CHANGED.toString();
    }
    this.caseLineInfoData.isDataChanged = true;
    this.setChangedSaveState();
  }

  //per sonarqube rule
  checkSubline(pValue: string, pIndex: number) {
    if ((pValue !== "X") &&
      ((!!this.caseLineInfoData.wm_USER_CASE_SUBLINE_TX && this.caseLineInfoData.wm_USER_CASE_SUBLINE_TX !== "") ||
        !this.caseLineInfoData.wm_HAS_SUBLINES)
    ) {
      MessageMgr.displaySinglePopupWarning("E302");
    }
    if (this.caseLineInfoData.status == DsamsConstants.ENT_NEW.toString()) {
      this.caseLineInfoData.caseLineOfferReleaseList[pIndex].status = DsamsConstants.ENT_NEW.toString();
      this.caseLineInfoData.caseLineOfferReleaseList[pIndex].isDeleteAllowed = true;
      this.caseLineInfoData.caseLineOfferReleaseList[pIndex].deleteBgColor = this.ActiveDeleteBtnColor;
    }
    else if (this.caseLineInfoData.caseLineOfferReleaseList[pIndex].status !== DsamsConstants.ENT_NEW.toString() &&
      this.caseLineInfoData.caseLineOfferReleaseList[pIndex].status !== DsamsConstants.ENT_DELETED.toString()) {
      this.caseLineInfoData.caseLineOfferReleaseList[pIndex].isDeleteAllowed = false;
      this.caseLineInfoData.caseLineOfferReleaseList[pIndex].deleteBgColor = this.InactiveBtnColor;
      this.caseLineInfoData.caseLineOfferReleaseList[pIndex].status = DsamsConstants.ENT_CHANGED.toString();
    }
  }

  //per Sonarqube rule
  setTermDelete(pIndex: number) {
    if (this.caseLineInfoData.status == DsamsConstants.ENT_NEW.toString()) {
      this.caseLineInfoData.caseLineDeliveryTermList[pIndex].status = DsamsConstants.ENT_NEW.toString();
      this.caseLineInfoData.caseLineDeliveryTermList[pIndex].isDeleteAllowed = true;
      this.caseLineInfoData.caseLineDeliveryTermList[pIndex].deleteBgColor = this.ActiveDeleteBtnColor;
    }
    else if (this.caseLineInfoData.caseLineDeliveryTermList[pIndex].status !== DsamsConstants.ENT_NEW.toString() &&
      this.caseLineInfoData.caseLineDeliveryTermList[pIndex].status !== DsamsConstants.ENT_DELETED.toString()) {
      this.caseLineInfoData.caseLineDeliveryTermList[pIndex].status = DsamsConstants.ENT_CHANGED.toString();
      this.caseLineInfoData.caseLineDeliveryTermList[pIndex].isDeleteAllowed = false;
      this.caseLineInfoData.caseLineDeliveryTermList[pIndex].deleteBgColor = this.InactiveBtnColor;
    }
  }

  //per Sonarqube rule
  setItemStatus(pIndex: number) {
    if (this.caseLineInfoData.status == DsamsConstants.ENT_NEW.toString())
      this.caseLineInfoData.caseLineDeliveryItemList[pIndex].status = DsamsConstants.ENT_NEW.toString();
    else
      if (this.caseLineInfoData.caseLineDeliveryItemList[pIndex].status !== DsamsConstants.ENT_NEW.toString() &&
        this.caseLineInfoData.caseLineDeliveryItemList[pIndex].status !== DsamsConstants.ENT_DELETED.toString())
        this.caseLineInfoData.caseLineDeliveryItemList[pIndex].status = DsamsConstants.ENT_CHANGED.toString();
  }

  //per Sonarqube rule
  setCalendarStatus(pUpdateCalendarStatus: boolean, pIndex: number) {
    if (this.caseLineInfoData.status !== DsamsConstants.ENT_NEW.toString()) {
      this.caseLineInfoData.status = DsamsConstants.ENT_CHANGED.toString();
      this.caseLineInfoData.entityStatus = DsamsConstants.ENT_CHANGED.toString();
    }
    if (pUpdateCalendarStatus) {
      if (this.caseLineInfoData.status == DsamsConstants.ENT_NEW.toString())
        this.caseLineInfoData.caseLineDeliveryItemList[this.aCurItemSelectedRow].
          caseLineDeliveryScheduleList[pIndex].status = DsamsConstants.ENT_NEW.toString();
      else
        if (this.caseLineInfoData.caseLineDeliveryItemList[this.aCurItemSelectedRow].
          caseLineDeliveryScheduleList[pIndex].status !== DsamsConstants.ENT_NEW.toString() &&
          this.caseLineInfoData.caseLineDeliveryItemList[this.aCurItemSelectedRow].
            caseLineDeliveryScheduleList[pIndex].status !== DsamsConstants.ENT_DELETED.toString())
          this.caseLineInfoData.caseLineDeliveryItemList[this.aCurItemSelectedRow].
            caseLineDeliveryScheduleList[pIndex].status = DsamsConstants.ENT_CHANGED.toString();
    }
  }

  //per Sonarqube rule
  checkOfferForDuplicate(pValue: string, pIndex: number) {
    if (this.isDuplicateORRowFound(pValue)) {
      this.caseLineInfoData.caseLineOfferReleaseList[pIndex].offer_RELEASE_ID = "";
      this.caseLineInfoData.caseLineOfferReleaseList[pIndex].theOfferReleaseId.offer_RELEASE_ID = "";
      this.dataSourceOfferRelease.data[pIndex].offer_RELEASE_ID = "";
    }
    // Check if not X and is subline or case w/o subline.
    else this.checkSubline(pValue, pIndex);
  }

  //per Sonarqube rule
  checkTermForDuplicate(pValue: string, pIndex: number) {
    if (this.isDuplicateDTRowFound(pValue)) {
      this.caseLineInfoData.caseLineDeliveryTermList[pIndex].delivery_TERM_ID = "";
      this.caseLineInfoData.caseLineDeliveryTermList[pIndex].theDeliveryTermId.delivery_TERM_ID = "";
      this.dataSourceDeliveryTerm.data[pIndex].delivery_TERM_ID = "";
    }
    else this.setTermDelete(pIndex);
  }

  //store the modified valued to the case line entity for saving purposes
  onCLSelectionChange(pColumName: any, pValue: string, pIndex: any, pOnClick: boolean) {
    if (this.isLineDeliveryDisabled) return;
    var updateCalendarStatus: boolean = false;
    //To avoid using NgModel in Mat-Select, use this quick and simple approach to 
    //remap modified values selected on screen
    switch (pColumName) {
      case "offer_RELEASE_ID": {
        if (pValue == '' || pValue == null) {
          break;
        }
        else if (!pOnClick) {
          this.caseLineInfoData.caseLineOfferReleaseList[pIndex].offer_RELEASE_ID = pValue;
          this.caseLineInfoData.caseLineOfferReleaseList[pIndex].theOfferReleaseId.offer_RELEASE_ID = pValue;
          this.checkOfferForDuplicate(pValue, pIndex);
        }
        break;
      }
      case "delivery_TERM_ID": {
        if (pValue == '' || pValue == null) {
          break;
        }
        else if (!pOnClick) {
          this.validateDeliveryTermCode(pValue);
          this.caseLineInfoData.caseLineDeliveryTermList[pIndex].delivery_TERM_ID = pValue;
          this.caseLineInfoData.caseLineDeliveryTermList[pIndex].theDeliveryTermId.delivery_TERM_ID = pValue;
          this.checkTermForDuplicate(pValue, pIndex);
        }
        break;
      }
      case "item_CD": {
        if (pValue == '' || pValue == null) {
          break;
        }
        else if (!pOnClick) {
          this.caseLineInfoData.caseLineDeliveryItemList[pIndex].item_CD = pValue;
          this.setItemStatus(pIndex);
        }
        break;
      }
      case "calendar_YEAR_ID": {
        this.caseLineInfoData.caseLineDeliveryItemList[this.aCurItemSelectedRow].
          caseLineDeliveryScheduleList[pIndex].calendar_YEAR_ID = parseInt(pValue);
        updateCalendarStatus = true;
        break;
      }
      case "case_LINE_DEL_SET_Q1_QY": {
        this.caseLineInfoData.caseLineDeliveryItemList[this.aCurItemSelectedRow].
          caseLineDeliveryScheduleList[pIndex].case_LINE_DEL_SET_Q1_QY = parseInt(pValue);
        updateCalendarStatus = true;
        this.sumOfAllItemQuantities = this.getTotalItemQuantity(this.aCurItemSelectedRow);
        break;
      }
      case "case_LINE_DEL_SET_Q2_QY": {
        this.caseLineInfoData.caseLineDeliveryItemList[this.aCurItemSelectedRow].
          caseLineDeliveryScheduleList[pIndex].case_LINE_DEL_SET_Q2_QY = parseInt(pValue);
        updateCalendarStatus = true;
        this.sumOfAllItemQuantities = this.getTotalItemQuantity(this.aCurItemSelectedRow);
        break;
      }
      case "case_LINE_DEL_SET_Q3_QY": {
        this.caseLineInfoData.caseLineDeliveryItemList[this.aCurItemSelectedRow].
          caseLineDeliveryScheduleList[pIndex].case_LINE_DEL_SET_Q3_QY = parseInt(pValue);
        updateCalendarStatus = true;
        this.sumOfAllItemQuantities = this.getTotalItemQuantity(this.aCurItemSelectedRow);
        break;
      }
      case "case_LINE_DEL_SET_Q4_QY": {
        this.caseLineInfoData.caseLineDeliveryItemList[this.aCurItemSelectedRow].
          caseLineDeliveryScheduleList[pIndex].case_LINE_DEL_SET_Q4_QY = parseInt(pValue);
        updateCalendarStatus = true;
        this.sumOfAllItemQuantities = this.getTotalItemQuantity(this.aCurItemSelectedRow);
        break;
      }
    }
    this.setCalendarStatus(updateCalendarStatus, pIndex)
    this.caseLineInfoData.isDataChanged = true;
    this.setChangedSaveState();
  }

  //do this as part of sonarqube cleanup 
  setIsDeleteAllowed(pIndex: number) {
    if (!!this.caseLineInfoData.caseLineDeliveryItemList[pIndex].caseLineDeliveryScheduleList) {
      if (this.caseLineInfoData.caseLineDeliveryItemList[pIndex].caseLineDeliveryScheduleList.length > 0) {
        this.caseLineInfoData.caseLineDeliveryItemList[pIndex].isDeleteAllowed = false;
        this.caseLineInfoData.caseLineDeliveryItemList[pIndex].deleteBgColor = this.InactiveBtnColor;
      }
    }
    else {
      this.caseLineInfoData.caseLineDeliveryItemList[pIndex].deleteBgColor = this.ActiveDeleteBtnColor;
      this.caseLineInfoData.caseLineDeliveryItemList[pIndex].isDeleteAllowed = true;
    }
  }

  setItemHighlightedRow(rowIndex: any) {
    this.aCurItemSelectedRow = rowIndex;
    for (let i = 0; i < this.dataSourceItem.data.length; i++) {
      //set to not higlight row
      this.caseLineInfoData.caseLineDeliveryItemList[i].bgColor = 'white';
      if (i == rowIndex) {
        this.caseLineInfoData.caseLineDeliveryItemList[rowIndex].bgColor = 'lightgrey';
        this.setCalHighlightedRow(rowIndex);
        this.sumOfAllItemQuantities = this.getTotalItemQuantity(rowIndex);

        //set enable or disable delete button
        if (this.caseLineRelatedInfoData.case_VERSION_STATUS_CD.toUpperCase() == 'D') {
          this.caseLineInfoData.caseLineDeliveryItemList[i].isDeleteAllowed = true;
          this.caseLineInfoData.caseLineDeliveryItemList[i].deleteBgColor = this.ActiveDeleteBtnColor;
        }
        else {
          this.setIsDeleteAllowed(i);
        }
      }
    }
  }

  setCalHighlightedRow(rowIndex: any) {
    if (this.caseLineInfoData.caseLineDeliveryItemList[rowIndex] &&
      this.caseLineInfoData.caseLineDeliveryItemList[rowIndex].caseLineDeliveryScheduleList) {
      this.dataSourceCalendar.data = [];
      this.initializeCalendarArray(rowIndex,
        this.caseLineInfoData.caseLineDeliveryItemList[rowIndex].caseLineDeliveryScheduleList, false);
      this.isCalendarBtnDisabled = false;
      this.calendarBtnColor = this.ActiveBtnColor;
    }
    else {
      this.isCalendarBtnDisabled = true;
      this.calendarBtnColor = this.InactiveBtnColor;
      this.dataSourceCalendar.data = [];
    }
    this.dataSourceCalendar._updateChangeSubscription();
  }

  //Perform business check
  isDuplicateORRowFound(pValue: string): boolean {
    if (pValue == '' || pValue == null || pValue == 'N/A') return false;
    var aResult: boolean = false;
    var dupCounter: number = 0;
    let htmlStr: string = '<hr><div align="left">';
    htmlStr += '<font color="red"> Duplicate Offer Release entered; value must be unique.';
    htmlStr += "";
    //loop through the array to find duplicate values
    this.caseLineInfoData.caseLineOfferReleaseList.forEach(searchRow => {
      if (pValue == searchRow.offer_RELEASE_ID) {
        //if found then check counter for more than 1 occurrence
        if (dupCounter > 0) {
          aResult = true;
          MessageMgr.swalFire({
            icon: 'error',
            html: htmlStr,
            width: 400,
            focusConfirm: true,
            confirmButtonText: 'OK'
          })
        }
        dupCounter++;
      }
    })
    return (aResult);
  }

  isDuplicateDTRowFound(pValue: string): boolean {
    if (pValue == '' || pValue == null || pValue == 'N/A') return false;
    var aResult: boolean = false;
    var dupCounter: number = 0;
    let htmlStr: string = '<hr><div align="left">';
    htmlStr += '<font color="red"> Duplicate Delivery Term entered; value must be unique.';
    htmlStr += "";
    //loop through the array to find duplicate values
    this.caseLineInfoData.caseLineDeliveryTermList.forEach(searchRow => {
      if (pValue == searchRow.delivery_TERM_ID) {
        //if found then check counter for more than 1 occurrence
        if (dupCounter > 0) {
          aResult = true;
          MessageMgr.swalFire({
            icon: 'error',
            html: htmlStr,
            width: 400,
            focusConfirm: true,
            confirmButtonText: 'OK'
          })
        }
        dupCounter++;
      }
    })
    return (aResult);
  }

  //FR34
  getTotalItemQuantity(pCurrentIndex): number {
    if (!!this.caseLineInfoData.caseLineDeliveryItemList && this.caseLineInfoData.caseLineDeliveryItemList[pCurrentIndex]) {
      if (this.caseLineInfoData.caseLineDeliveryItemList[pCurrentIndex].caseLineDeliveryScheduleList !== null) {
        this.caseLineInfoData.caseLineDeliveryItemList[pCurrentIndex].sumOfAllItemQuantities = 0;
        //foreach loop will run until it reaches the end of loop
        this.caseLineInfoData.caseLineDeliveryItemList[pCurrentIndex].caseLineDeliveryScheduleList.forEach(element => {
          this.caseLineInfoData.caseLineDeliveryItemList[pCurrentIndex].sumOfAllItemQuantities += element.case_LINE_DEL_SET_Q1_QY +
            element.case_LINE_DEL_SET_Q2_QY + element.case_LINE_DEL_SET_Q3_QY +
            element.case_LINE_DEL_SET_Q4_QY;
        })
      }
      LineUtils.getTotalQuantity(this.caseLineInfoData);
      return (this.caseLineInfoData.caseLineDeliveryItemList[pCurrentIndex].sumOfAllItemQuantities);
    }
    return 0;
  }

  //FR35 - moved to Line Uitlity component
  getTotalQuantity() {
    //must get the sum of all CLDS per item
    if (this.caseLineInfoData.caseLineDeliveryItemList) {
      this.caseLineInfoData.sumOfAllQuantities = 0;
      //foreach loop will run until it reaches the end of loop
      this.caseLineInfoData.caseLineDeliveryItemList.forEach(element => {
        if (!!element.sumOfAllItemQuantities)
          this.caseLineInfoData.sumOfAllQuantities += element.sumOfAllItemQuantities;
      })
    }
  }
  //FR36 
  validateShipmentStatus(): boolean {
    if (this.caseLineInfoData.change_ACTION_CD.toUpperCase() == LineDeliveryComponent.CHANGE_ACTION_CD_ADDED) {
      MessageMgr.swalFire({
        icon: 'warning',
        html: '<font color="red">You have applied Shipment or Completed to an Added Line. Do you want to continue?"</font>',
        width: 400,
        showCancelButton: true,
        cancelButtonText: 'No',
        confirmButtonColor: '#3085d6',
        focusConfirm: true,
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes',
      }).then((result) => {
        if (result.value) {
          // console.log('result is true')
          return true;
        }
      })
    }
    return false;
  }

  //Validation checks
  performValidationFieldCheck(): boolean {
    var displayMsg: boolean = false;
    let msgArray: Array<ErrorParameter> = [];

    //DH - All validation checks will be moved to line utils eventually
    //Line Details tab
    //Mandatory fields from Line Details must be checked first 
    if (!LineUtils.areFieldsValidForLineDetails(this.caseLineInfoData, msgArray))
      displayMsg = true;
    //perform specific fields check
    if (!LineUtils.areSpecificFieldsValidForLineDetails(this.caseLineInfoData, this.caseLineRelatedInfoData, msgArray))
      displayMsg = true;
    //Line Delivery tab
    //perform specific fields check for Line Delivery
    if (!LineUtils.areSpecificFieldsValidForLineDelivery(this.caseLineInfoData, this.caseLineRelatedInfoData, msgArray))
      displayMsg = true;
    //Validate Performance Period values
    if (!LineUtils.arePPFieldsValid(this.caseLineInfoData, msgArray))
      displayMsg = true;

    //Display validation warning/error messages if applicable
    if (displayMsg) {
      this.messageService.displayMessageListTc("Validate Case Line", msgArray).subscribe();
    }

    return !displayMsg
  }

  resetAttributesStatus() {
    this.caseLineInfoData.isDataChanged = false;
    this.caseUIService.theComponentSaveCaseLineState[CaseUIService.SAVE_CASE_LINE_DETAILS_STATE].isDataChanged = false;
    this.caseLineInfoData.isLineNumberChanged = false;
    this.caseLineInfoData.isEntityNew = false;
    this._nporChanged = this._hasNporWarnings;
    this.caseLineInfoData.status = DsamsConstants.ENT_UNCHANGED.toString();
    this.caseLineInfoData.entityStatus = DsamsConstants.ENT_UNCHANGED.toString();
    LineUtils.theDeletedCLDIListArray = [];
    LineUtils.theDeletedCLDTListArray = [];
    LineUtils.theDeletedCLDSListArray = [];
    LineUtils.theDeletedCLORListArray = [];
    LineUtils.theDeletedCLATListArray = [];
    this.caseLineInfoData.wm_SaveCL = false;
    this.caseLineInfoData.wm_SaveCML = false;

    LineUtils.resetCLDIEntityToUnChanged(this.caseLineInfoData);
    LineUtils.resetCLDTEntityToUnChanged(this.caseLineInfoData);
    LineUtils.resetCLOREntityToUnChanged(this.caseLineInfoData);
    this.caseLineInfoData.isLinePurposeDisabled = LineUtils.isLinePurposeDisabled(this.caseLineInfoData);

    this.dataSourceCalendar._updateChangeSubscription();
    this.dataSourceDeliveryTerm._updateChangeSubscription();
    this.dataSourceOfferRelease._updateChangeSubscription();
    this.dataSourceItem._updateChangeSubscription();
  }

  //prepare common data for saving
  prepareCLATEntity() {
    this.caseUIService.getTheDeletedCLATList().subscribe((value) => {
      LineUtils.theDeletedCLATListArray = value;
    });
    LineUtils.prepareCLATEntity(this.caseLineInfoData, LineUtils.theDeletedCLATListArray);
  }

  //For both tabs, prepare proper data format for case line entity for saving
  prepareCaselineEntity() {
    LineUtils.prepareCaselineEntity(this.caseLineInfoData);
    //prepare deleted entities when applicable
    LineUtils.prepareCLOREntity(this.caseLineInfoData, LineUtils.theDeletedCLORListArray);
    LineUtils.prepareCLDTEntity(this.caseLineInfoData, LineUtils.theDeletedCLDTListArray);
    LineUtils.prepareCLDSEntity(this.caseLineInfoData, LineUtils.theDeletedCLDSListArray);
    LineUtils.prepareCLDIEntity(this.caseLineInfoData, LineUtils.theDeletedCLDIListArray);
    this.prepareCLATEntity();
  }

  //prepare case master line entity data for saving
  prepareCaseMasterLineEntity(): ifaceCaseMasterLineEntity {
    var aCaseMasterLine: ifaceCaseMasterLineEntity = {};
    this.caseLineInfoData.wm_CHECK_NPOR = (this._nporChanged && LineUtils.doNporCheck(this.caseLineInfoData));
    aCaseMasterLine = LineUtils.prepareCaseMasterLineEntity(this.caseLineInfoData);
    this.prepareCaselineEntity();
    aCaseMasterLine.caseLineList = [];
    //build up the case line list
    const theCaseLineDetail: ifaceCaseLineData = LineUtils.prepareLineDetailDataForSave(this.caseLineInfoData)
    aCaseMasterLine.caseLineList.push(theCaseLineDetail);
    //console.log('line Delivery=', aCaseMasterLine, theCaseLineDetail)
    return aCaseMasterLine;
  }

  postSaveData() {
    //take care of CLOR entity for now
    this.caseLineInfoData.caseLineOfferReleaseList.forEach((eachRow, index) => {
      eachRow.case_ID = this.caseLineInfoData.case_ID;
      eachRow.working_CASE_ID = this.caseLineInfoData.working_CASE_ID;
      eachRow.working_CASE_VERSION_ID = this.caseLineInfoData.working_CASE_VERSION_ID;
      eachRow.case_MASTER_LINE_ID = this.caseLineInfoData.case_MASTER_LINE_ID;
      if (eachRow.status == DsamsConstants.ENT_NEW.toString()) {
        eachRow.status = DsamsConstants.ENT_UNCHANGED.toString();
      }
      else if (eachRow.status == DsamsConstants.ENT_DELETED.toString()) {
        this.caseLineInfoData.caseLineOfferReleaseList.splice(index, 1);
      }
    })

    //take care of CLDT entity for now
    this.caseLineInfoData.caseLineDeliveryTermList.forEach((eachRow, index) => {
      eachRow.case_ID = this.caseLineInfoData.case_ID;
      eachRow.working_CASE_ID = this.caseLineInfoData.working_CASE_ID;
      eachRow.working_CASE_VERSION_ID = this.caseLineInfoData.working_CASE_VERSION_ID;
      eachRow.case_MASTER_LINE_ID = this.caseLineInfoData.case_MASTER_LINE_ID;
      if (eachRow.status == DsamsConstants.ENT_NEW.toString()) {
        eachRow.status = DsamsConstants.ENT_UNCHANGED.toString();
      }
      else if (eachRow.status == DsamsConstants.ENT_DELETED.toString()) {
        this.caseLineInfoData.caseLineDeliveryTermList.splice(index, 1);
      }
    })

    //take care of CLDI entity for now
    this.caseLineInfoData.caseLineDeliveryItemList.forEach((eachRow, index) => {
      eachRow.case_ID = this.caseLineInfoData.case_ID;
      eachRow.working_CASE_ID = this.caseLineInfoData.working_CASE_ID;
      eachRow.working_CASE_VERSION_ID = this.caseLineInfoData.working_CASE_VERSION_ID;
      eachRow.case_MASTER_LINE_ID = this.caseLineInfoData.case_MASTER_LINE_ID;
      if (eachRow.status == DsamsConstants.ENT_NEW.toString()) {
        eachRow.status = DsamsConstants.ENT_UNCHANGED.toString();
      }
      else if (eachRow.status == DsamsConstants.ENT_DELETED.toString()) {
        this.caseLineInfoData.caseLineDeliveryItemList.splice(index, 1);
      }
    })
  }

  //Saving data to the database server
  performSaveDataOperation() {
    this.caseRestService.saveCaseLineListFromServer(this.prepareCaseMasterLineEntity()).subscribe(
      result => {
        console.log("line delivery result: ", result);
        MessageMgr.displaySuccessWithTimer('Save was successful', 2000);
        let msgArray: Array<ErrorParameter> = null;
        if (!!result.wm_errorMessageArray) {
          msgArray = result.wm_errorMessageArray;
        }
        else {
          msgArray = LineUtils.collectPostSaveMessages(result.wm_POST_SAVE_MESSAGES);
        }

        if (msgArray.length > 0) {
          this.messageService.displayMessageListTc("Case Line Warnings", msgArray).subscribe();
          this._hasNporWarnings = true;
        }
        else {
          this._hasNporWarnings = false;
        }
        this.postSaveData(); //must do this prior to reset all attributes for pricing calculate costs to work properly
        //Clear the array status after a successful Save/Delete
        this.resetAttributesStatus();

        if (this.caseLineInfoData.isPricingDataChanged)
          MessageMgr.displayInfoWithTimer('There are unsaved Pricing changes. Proceed to Pricing tab to save.', 2500);
      },
      err => {
        console.log('Error saving the Case Line data')
        CaseUtils.ReportHTTPError(err, " saving Case Line data");
        MessageMgr.displayErrorWithTimer('Error saving Case Line data', 1500);
      },
    );
  }

  //display message - per sonarqube rule
  saveWindowData() {
    this.caseUIService.milestoneAddService.pipe(take(1)).subscribe((value) => {
      if (value == "PENINK" || value == "CWDREDIT" || value == "CWDPEDIT")
        this.saveMilestone();
      else
        this.performSaveDataOperation();
    })
  }

  //Saving data
  saveButtonOnClick() {
    if (this.performValidationFieldCheck()) {
      if (this.caseLineInfoData.isDataChanged) {
        var saveMessage: string = 'Are you sure you want to save?';
        if (LineUtils.isPSCode(this.caseLineInfoData))
          saveMessage = LineUtils.PSCaseMessage.concat(saveMessage);
        let savePrompt: any =
        {
          text: saveMessage,
          icon: 'question',
          width: 350,
          showCancelButton: true,
          cancelButtonText: 'No',
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: 'Yes',
        };
        MessageMgr.swalFire(savePrompt).then((result) => {
          if (result.value) {
            this.saveWindowData();
          }
        })
      }
      else {
        let nctsPrompt: any = {
          text: 'No change has been made.',
          icon: 'info',
          showConfirmButton: false,
          timer: 1500,
          width: 350
        };
        MessageMgr.swalFire(nctsPrompt);
      }
    }
  }

  saveMilestone() {
    this.caseUIService.milestoneAddService.pipe(take(1)).subscribe((value) => {
      if (value === "PENINK") {
        this.openMilestoneCommentDialog("PENINK");
      } else if (value === "CWDREDIT") {
        this.openMilestoneCommentDialog("CWDREDIT");
      } else if (value === "CWDPEDIT") {
        this.openMilestoneCommentDialog("CWDPEDIT")
      }
    });
  }

  /* Open the Pen & Ink Milestone Comment Dialog */
  openMilestoneCommentDialog(pMilestoneId: string): any {
    const dialogRef = this.dialog.open(MilestoneCommentComponent, {
      width: '50em',
      height: '30em',
      data: {
        caseId: this.caseLineInfoData.working_CASE_ID,
        versionId: this.caseLineInfoData.working_CASE_VERSION_ID,
        milestoneId: pMilestoneId
         // begin DSAMS-5933 09/22 DB
         , activityId: sessionStorage.getItem(LineDeliveryComponent.USER_ACTIVITY_ID),
         userId: sessionStorage.getItem(LineDeliveryComponent.USER_ID)
         // end DSAMS-5933 09/22 DB
      }
    });
    dialogRef.afterClosed().subscribe((data) => {
      if (data === "Ok") {
        this.caseUIService.isMilestoneCommentNull.subscribe((value) => {
          if (!value && this.caseLineInfoData.isDataChanged) {
            this.performSaveDataOperation();
            this.caseUIService.setNotifyToSetDefaultOption(true);
            this.caseUIService.flipToDisabledService.next(DsamsConstants.CASE_LINE_EDITOR);
            const editResponse: IEditResponseType = {
              ID: DsamsConstants.CASE_LINE_EDITOR,
              editToggle: false
            };
            this.caseUIService.caseEditService.next(editResponse);
            this.caseUIService.optionSelectCounter.next(0);
          }
        });
      }
    });
  }

  // Cancel process - FS - Removed on 03/2022 for Card 5204
  // Will work on implementing refresh data
  cancelButtonOnClick() {
    MessageMgr.swalFire({
      text: 'Are you sure you want to cancel?',
      icon: 'question',
      width: 350,
      showCancelButton: true,
      cancelButtonText: 'No',
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes',
    }).then((result) => {
      if (result.value) {
        // this.caseUIService.setCaseLineInfoValues(this.theInitialCaseLineInfoData);
        //populate the reference data
        this.caseLineInfoData.isDataChanged = false;
        this.caseUIService.setIsLineTabDisabled(false);
      }
    })
  }

  //back to previous Case Search Summary page 
  goBackToCaseSearchSummary() {
    this.caseUIService.setbackToCaseSearchSummaryValue(true);
    //Disable Line and Pricing tabs
    this.caseUIService.setIsLineTabDisabled(true);
    this.router.navigateByUrl('/case/search');
  }
  changeEditFields(pEdit: boolean) {
    let curDeliveryIndex = this.aCurItemSelectedRow;
    this.isCLDSQ1Editable = pEdit;
    this.isCLDSQ2Editable = pEdit;
    this.isCLDSQ3Editable = pEdit;
    this.isCLDSQ4Editable = pEdit;
    if (pEdit) {
      if (!!this.caseLineInfoData.offer_EXPIRATION_DT) {
        switch (this.getQuarterOfYear(this.caseLineInfoData.offer_EXPIRATION_DT,
          this.caseLineInfoData.caseLineDeliveryItemList[curDeliveryIndex].aCurrentCalendarYear)) {
          case 1: {
            this.isCLDSQ1Editable = false;
            break;
          }
          case 2: {
            this.isCLDSQ1Editable = false;
            this.isCLDSQ2Editable = false;
            break;
          }
          case 3: {
            this.isCLDSQ1Editable = false;
            this.isCLDSQ2Editable = false;
            this.isCLDSQ3Editable = false;
            break;
          }
        }
      }

    }
    if (this.caseLineInfoData.issue_UNIT_CD === 'XX') {
      this.isCLDSQ1Editable = false;
      this.isCLDSQ2Editable = false;
      this.isCLDSQ3Editable = false;
      this.isCLDSQ4Editable = false;
      this.isAddItemDisabled = true;
      this.addItemBtnColor = this.InactiveBtnColor;
      this.isCalenderYearDisabled = true;
      this.calendarBtnColor = this.InactiveBtnColor;
    }
    if (this.isEditToggleOn && this.caseLineInfoData.issue_UNIT_CD === 'EA'){
      this.isCLDSQ1Editable = true;
      this.isCLDSQ2Editable = true;
      this.isCLDSQ3Editable = true;
      this.isCLDSQ4Editable = true;
      this.isAddItemDisabled = false;
      this.addItemBtnColor = this.ActiveBtnColor;
      this.isCalenderYearDisabled = false;
      this.calendarBtnColor = this.ActiveBtnColor;
     }
  }

  subscribeToPopupMASL() {
    if (this._popupMASLSubscription == null) {
      this._popupMASLSubscription = this.dsamsMethodsService
        .selectedMaslObjectFromPopupValue
        .subscribe(value => {
          if (value !== null){
         this.changeEditFields(this.isEditToggleOn);
          }
        },
          err => {
            CaseUtils.ReporError("Error in dsamsMethodsService.popupMASL");
          }
        );
    }
  }

  //breakout logic per sonarqube rule for Ramesh
  setIntialLeadTimeState() {
    if (this.caseLineInfoData.change_ACTION_CD.toUpperCase() == LineDeliveryComponent.CHANGE_ACTION_CD_ADDED) {
      this.isInitialLeadTimeDisabled = true;
      this.isLeadTimeDisabled = true;
    }
    else {
      this.isInitialLeadTimeDisabled = false;
      this.isLeadTimeDisabled = false;
    }
  }

  subscribeToToggleAction() {
    if (!this._toggleActionSubscription) {
      this._toggleActionSubscription=this.caseUIService.getCaseLineToggleAction().subscribe((value) => {
        if (value === DsamsConstants.SET_ORIG) {
        this.caseLineInfoDataOrig=JSON.parse(JSON.stringify(this.caseLineInfoData));
      }
      if (value === DsamsConstants.TOGGLE_CONTINUE) {
        this.caseLineInfoData=JSON.parse(JSON.stringify(this.caseLineInfoDataOrig));
        this.addOfferBtnColor = this.InactiveBtnColor;
          this.addTermBtnColor = this.InactiveBtnColor;
          this.intializeArrays();
          this.setItemHighlightedRow(0);
          if (this.caseLineInfoData.case_LINE_AVAILABILITY_LEAD_QY) {
            this.setIntialLeadTimeState();
          }
          else {
            this.isInitialLeadTimeDisabled = true;
            this.isLeadTimeDisabled = true;
          }
      }
      });
    }

  }

  setChangedSaveState(){
    this.caseUIService.theComponentSaveCaseLineState[CaseUIService.SAVE_CASE_LINE_DETAILS_STATE].isDataChanged = true;
  }
}