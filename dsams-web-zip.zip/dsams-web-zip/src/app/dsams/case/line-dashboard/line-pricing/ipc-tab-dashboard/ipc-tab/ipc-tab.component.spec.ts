import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IpcTabComponent } from './ipc-tab.component';

describe('IpcTabComponent', () => {
  let component: IpcTabComponent;
  let fixture: ComponentFixture<IpcTabComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IpcTabComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IpcTabComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
