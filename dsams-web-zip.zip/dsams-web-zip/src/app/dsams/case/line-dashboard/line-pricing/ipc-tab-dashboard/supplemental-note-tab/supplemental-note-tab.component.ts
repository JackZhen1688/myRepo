import { formatCurrency } from '@angular/common';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { MatDialog, MatTableDataSource } from '@angular/material';
import { IEditResponseType } from 'src/app/dsams/case/model/edit-response-type';
import { CaseRestfulService } from 'src/app/dsams/case/services/case-restful.service';
import { CaseUIService } from 'src/app/dsams/case/services/case-ui-service';
import { DsamsConstants } from 'src/app/dsams/dsams.constants';
import { supplementalLineNoteDto } from '../model/dto/supplemental-line-note-dto';
import { FieldDisabledMap } from '../../../../model/field-disabled-map';
import { Subscription } from 'rxjs';
import { caseLineComponentDto } from 'src/app/dsams/case/model/dto/case-line-component-dto';
import { CaseUtils } from 'src/app/dsams/case/utils/case-utils';
import { ReferenceDataType } from 'src/app/dsams/case/model/reference-data-type';
import { LinePricingUtils } from '../../../line-pricing-utils';
import { DsamsMethodsService } from 'src/app/dsams/services/dsams-methods.service';
import { TextAreaComponent } from 'src/app/dsams/case/dialogs/text-area/text-area.component';

@Component({
  selector: 'app-supplemental-note-tab',
  templateUrl: './supplemental-note-tab.component.html',
  styleUrls: ['./supplemental-note-tab.component.css']
})
export class SupplementalNoteTabComponent implements OnInit, OnDestroy {

  supplementalColumns =
    [
      'sequenceNumber',
      'itemNumber',
      'itemDescription',
      'quantity',
      'unitOfIssue',
      'sourceOfSupply',
      'availLeadTime',
      'dateShipped',
      'unitOfCost',
      'totalCost',
      'deleted',
      'DeleteRow'
    ];
  supplementalColumnsFooter = ['AddRow'];
  isLoading: boolean = false;
  supplementalNoteDataList: supplementalLineNoteDto[] = [{
    isFieldDisabled: {
      newSLNRow: true,
      supply_SOURCE_NUMBER_ID: true,
      item_NO_LEAD_QY: true,
      datePicker: true,
      item_IDENTIFIER_TX: true,
      list_ITEM_DESCRIPTION_TX: true,
      issue_UNIT_CD: true
    },
    case_LINE_LIST_SEQUENCE_ID: null,
    item_IDENTIFIER_TX: null,
    list_ITEM_DESCRIPTION_TX: null,
    case_LINE_LIST_ATTACHMENT_QY: null,
    issue_UNIT_CD: null,
    supply_SOURCE_NUMBER_ID: null,
    supply_SOURCE_TITLE_NM: null,
    item_NO_LEAD_QY: null,
    supply_LINE_NOTE_SHIPPED_DT: null,
    case_LINE_LIST_UNIT_PRICE_AM: null,
    clla_DELETION_IN: false
  }];
  supplementalNoteDataSource: MatTableDataSource<supplementalLineNoteDto>;
  private _editSubscription: Subscription;
  private _unEditSubscription: Subscription;
  private _dataSubscription: Subscription;
  private _postSaveSubscription: Subscription;
  private postRecalSubscription: Subscription = null;
  private textAreaSubscription: Subscription = null;
  private _textIndex: number = -1;

  private _maxCllaSeqNo: number = 0;
  supp_COMPONENT_UNIT_BASE_PRICE_AM: string = "";
  isPanelEditable: boolean = false;
  _fieldDisabledMap: FieldDisabledMap = {};
  issueUnitList: Array<ReferenceDataType> = [];
  supplySourceList: Array<ReferenceDataType> = [];
  supplementalTabData: caseLineComponentDto;
  savedSupplementalTabData: caseLineComponentDto;
  isSupplementalControlsDisabled: boolean = true;

  constructor(private caseUIService: CaseUIService,
    private caseRestService: CaseRestfulService,
    public dsamsDialogMsgService: DsamsMethodsService,
    public dialog: MatDialog) { }

  ngOnInit() {
    this.supplementalTabData = {
      component_TITLE_NM: '',
    }
    this.populateReferenceLists();
    this.subscribeToDataService();
    this.subscribeToPostRecal();
    this.subscribeToPostSave();
    this.subscribeToEditService();
    this.subscribeToTextAreaDialog();
  }

  ngOnDestroy() {
    if (!!this._editSubscription) {
      this._editSubscription.unsubscribe();
    }
    if (!!this._unEditSubscription) {
      this._unEditSubscription.unsubscribe();
    }
    if (!!this._dataSubscription) {
      this._dataSubscription.unsubscribe();
    }
    if (!!this._postSaveSubscription) {
      this._postSaveSubscription.unsubscribe();
    }
    if (!!this.postRecalSubscription) {
      this.postRecalSubscription.unsubscribe();
    }
  }


  // Subscribe to edit service
  private subscribeToEditService() {
    this._editSubscription = this.caseUIService.caseEditService.subscribe((pEditResult: IEditResponseType) => {
      if (!!pEditResult && pEditResult.ID === DsamsConstants.CASE_LINE_EDITOR) {
        this.isPanelEditable = pEditResult.editToggle;
        //console.log('subscribeToEditService',this.supplementalNoteDataSource)
        this.isSupplementalControlsDisabled = !this.isPanelEditable || this.supplementalTabData.base_PRICE_SOURCE_CD !== 2;
        if (!!this.supplementalNoteDataSource)
          this.setFieldsState();
      }
    });
    this._unEditSubscription = this.caseUIService.caseUnEditService.subscribe((pEditResult: IEditResponseType) => {
      if (!!pEditResult && pEditResult.ID === DsamsConstants.CASE_LINE_EDITOR) {
        this.isPanelEditable = false;
        this.caseUIService.supplementalTabSubscription.next(this.savedSupplementalTabData);
      }
    });
  }

  // Subscribe to data service
  private subscribeToDataService() {
    this._dataSubscription = this.caseUIService.supplementalTabSubscription.subscribe((pSupplementalTabInfo: caseLineComponentDto) => {
      if (!!pSupplementalTabInfo) {
        this.supplementalTabData = pSupplementalTabInfo;
        this.savedSupplementalTabData = JSON.parse(JSON.stringify(this.supplementalTabData));
        if (!this.supplementalTabData.caseLineListAttachmentList) {
          this.supplementalTabData.caseLineListAttachmentList = [];
        }
        for (let i = 0; i < this.supplementalTabData.caseLineListAttachmentList.length; i++) {
          this.recalculateRow(this.supplementalTabData.caseLineListAttachmentList[i]);
          if (this.supplementalTabData.caseLineListAttachmentList[i].case_LINE_LIST_SEQUENCE_ID > this._maxCllaSeqNo) {
            this._maxCllaSeqNo = this.supplementalTabData.caseLineListAttachmentList[i].case_LINE_LIST_SEQUENCE_ID;
          }
          this.supplementalTabData.caseLineListAttachmentList[i].status = DsamsConstants.ENT_UNCHANGED.toString();
        }
        if (this.supplementalTabData.base_PRICE_SOURCE_CD == 2) {
          LinePricingUtils.setCaseLineListAttachmentCost(this.supplementalTabData);    // Sum up the unit base price amounts.        
        }
        if (!CaseUtils.isBlankStr(this.supplementalTabData.component_UNIT_BASE_PRICE_AM)) {
          this.supp_COMPONENT_UNIT_BASE_PRICE_AM = formatCurrency(this.supplementalTabData.component_UNIT_BASE_PRICE_AM, 'en', '$');
        }
        else {
          this.supp_COMPONENT_UNIT_BASE_PRICE_AM = formatCurrency(0, 'en', '$');
        }
        this.sortCaseLineListAttachment(this.supplementalTabData.caseLineListAttachmentList);
        this.supplementalNoteDataList = !this.supplementalTabData.caseLineListAttachmentList ? [] : this.supplementalTabData.caseLineListAttachmentList;
        this.supplementalNoteDataSource = new MatTableDataSource<supplementalLineNoteDto>(this.supplementalTabData.caseLineListAttachmentList);
        this.setFieldsState();
      }
    });
  }

  //jira 4138-Dh
  private subscribeToPostRecal() {
    this.postRecalSubscription = this.caseUIService.pricingPostRecal.subscribe((pClc: caseLineComponentDto) => {
      if (!!pClc && pClc.base_PRICE_SOURCE_CD == 2) {  // Only applies for supplemental line note.
        this.supplementalTabData = pClc;
        if (!this.supplementalTabData.caseLineListAttachmentList) {
          this.supplementalTabData.caseLineListAttachmentList = [];
        }
        for (let i = 0; i < this.supplementalTabData.caseLineListAttachmentList.length; i++) {
          this.recalculateRow(this.supplementalTabData.caseLineListAttachmentList[i]);
          if (this.supplementalTabData.caseLineListAttachmentList[i].case_LINE_LIST_SEQUENCE_ID > this._maxCllaSeqNo) {
            this._maxCllaSeqNo = this.supplementalTabData.caseLineListAttachmentList[i].case_LINE_LIST_SEQUENCE_ID;
          }
          if (this.supplementalTabData.caseLineListAttachmentList[i].status !== DsamsConstants.ENT_NEW.toString())
            this.supplementalTabData.caseLineListAttachmentList[i].status = DsamsConstants.ENT_CHANGED.toString();
        }

        LinePricingUtils.setCaseLineListAttachmentCost(this.supplementalTabData);    // Sum up the unit base price amounts.        
        if (!CaseUtils.isBlankStr(this.supplementalTabData.component_UNIT_BASE_PRICE_AM)) {
          this.supp_COMPONENT_UNIT_BASE_PRICE_AM = formatCurrency(this.supplementalTabData.component_UNIT_BASE_PRICE_AM, 'en', '$');
        }
        else {
          this.supp_COMPONENT_UNIT_BASE_PRICE_AM = formatCurrency(0, 'en', '$');
        }
        this.sortCaseLineListAttachment(this.supplementalTabData.caseLineListAttachmentList);
        this.supplementalNoteDataList = !this.supplementalTabData.caseLineListAttachmentList ? [] : this.supplementalTabData.caseLineListAttachmentList;
        this.supplementalNoteDataSource = new MatTableDataSource<supplementalLineNoteDto>(this.supplementalTabData.caseLineListAttachmentList);
      }
    });
  }

  // Recalculate the row when something changes.
  private recalculateRow(pSuppRow: supplementalLineNoteDto) {
    if ((!CaseUtils.isBlankStr(pSuppRow.case_LINE_LIST_UNIT_PRICE_AM)) &&
      (!CaseUtils.isBlankStr(pSuppRow.case_LINE_LIST_ATTACHMENT_QY))) {
      pSuppRow.total_COST = pSuppRow.case_LINE_LIST_UNIT_PRICE_AM * pSuppRow.case_LINE_LIST_ATTACHMENT_QY;
    }
    else {
      pSuppRow.total_COST = 0;
    }
    pSuppRow.wm_TOTAL_COST = formatCurrency(pSuppRow.total_COST, 'en', '$');
    if (!CaseUtils.isBlankStr(pSuppRow.case_LINE_LIST_UNIT_PRICE_AM)) {
      pSuppRow.wm_case_LINE_LIST_UNIT_PRICE_AM =
        formatCurrency(pSuppRow.case_LINE_LIST_UNIT_PRICE_AM, 'en', '$');
    }
    else {
      pSuppRow.wm_case_LINE_LIST_UNIT_PRICE_AM = formatCurrency(0, 'en', '$');
    }
    this.supp_COMPONENT_UNIT_BASE_PRICE_AM = this.supplementalTabData.wm_component_UNIT_BASE_PRICE_AM;
  }


  //Jira card 2142 - This function returns the sorted result by sequence ID
  sortCaseLineListAttachment(pData: supplementalLineNoteDto[]) {
    pData.sort((object1, object2) => {
      if (object1.case_LINE_LIST_SEQUENCE_ID > object2.case_LINE_LIST_SEQUENCE_ID) {
        return 1;
      }
      if (object1.case_LINE_LIST_SEQUENCE_ID < object2.case_LINE_LIST_SEQUENCE_ID) {
        return -1;
      }
      return 0;
    })
  }

  // Subscribe to post-save.
  private subscribeToPostSave() {
    this._postSaveSubscription = this.caseUIService.pricingPostSave.subscribe((pCaseLineComonent: caseLineComponentDto) => {
      // Refresh the data for the currently selected CLC.
      if (!!pCaseLineComonent) {
        this.caseUIService.supplementalTabSubscription.next(pCaseLineComonent);
      }
    });
  }

  // Subscribe to Text Area Dialog Save
  private subscribeToTextAreaDialog() {
    this.textAreaSubscription = this.dsamsDialogMsgService.textAreaFromIpcDialog.subscribe((textAreaValue: string) => {
      setTimeout(() => {
        if (!!this.supplementalNoteDataSource && !!this.supplementalNoteDataSource.data[this._textIndex]) {
          this.supplementalNoteDataSource.data[this._textIndex].list_ITEM_DESCRIPTION_TX = textAreaValue;
          this.supplementalNoteDataSource._updateChangeSubscription();
          this.setChanged(this._textIndex);
        }
      }, 0);
    });
  }

  // Determine if a field is disabled.
  isFieldDisabled(pElement: any, pFieldName: string): boolean {
    // Is whole panel disabled?
    if (!this.isPanelEditable) {
      return true;
    }
    if (!!pElement && pElement.isDisabled) {
      return true;
    }
    return this._fieldDisabledMap[pFieldName];
  }

  //Jira card 3577-DH-Enable/disable IPC related fields
  setFieldsState() {
    const isWholePanelDisabled: boolean = !this.isPanelEditable || this.supplementalTabData.base_PRICE_SOURCE_CD !== 2;
    this.supplementalNoteDataSource.data.forEach(eachRow => {
      if (!isWholePanelDisabled) {
        eachRow.isFieldDisabled = {
          newSLNRow: true,
          supply_SOURCE_NUMBER_ID: false,
          item_NO_LEAD_QY: false,
          datePicker: false,
          item_IDENTIFIER_TX: false,
          list_ITEM_DESCRIPTION_TX: false,
          issue_UNIT_CD: false
        };
      }
      else {
        eachRow.isFieldDisabled = {
          newSLNRow: true,
          supply_SOURCE_NUMBER_ID: true,
          item_NO_LEAD_QY: true,
          datePicker: true,
          item_IDENTIFIER_TX: true,
          list_ITEM_DESCRIPTION_TX: true,
          issue_UNIT_CD: true
        };
      }
    })
  }

  /* This procedure checks the returned result value from the popover Yes/No dialog window. */
  yesButtonOnClick(isDeleteConfirmed: any, rowElement: any) {
    if (isDeleteConfirmed)
      this.deleteItem(rowElement);
  }

  deleteItem(rowElement: any) {
    let rowIndex = this.supplementalNoteDataList.indexOf(rowElement);
    this.caseUIService.suppTabDeleted.next(this.supplementalNoteDataList[rowIndex]);
    if (this.supplementalNoteDataList[rowIndex].case_LINE_LIST_SEQUENCE_ID == this._maxCllaSeqNo) {
      // If the deleted item is equal to the max sequence, then minus the max sequence.
      this._maxCllaSeqNo--;
    }
    this.supplementalNoteDataList.splice(rowIndex, 1);
    this.supplementalTabData.caseLineListAttachmentList = this.supplementalNoteDataList;
    this.caseUIService.suppTabChanged.next(this.supplementalTabData);
    this.supplementalNoteDataSource = new MatTableDataSource<supplementalLineNoteDto>(this.supplementalNoteDataList);
    this.supplementalNoteDataSource._updateChangeSubscription();
    this.setChanged(-1);  // Mark whole tab changed, not just one row (since the row is now gone).
  }

  addItem() {
    const anItemObject: supplementalLineNoteDto =
    {
      status: DsamsConstants.ENT_NEW.toString(),
      isFieldDisabled: {
        newSLNRow: false,
        supply_SOURCE_NUMBER_ID: false,
        item_NO_LEAD_QY: false,
        datePicker: false,
        item_IDENTIFIER_TX: false,
        list_ITEM_DESCRIPTION_TX: false,
        issue_UNIT_CD: false
      },
      case_LINE_LIST_SEQUENCE_ID: ++this._maxCllaSeqNo,
      item_IDENTIFIER_TX: null,
      list_ITEM_DESCRIPTION_TX: null,
      case_LINE_LIST_ATTACHMENT_QY: null,
      issue_UNIT_CD: null,
      supply_SOURCE_NUMBER_ID: null,
      supply_SOURCE_TITLE_NM: null,
      item_NO_LEAD_QY: null,
      supply_LINE_NOTE_SHIPPED_DT: null,
      case_LINE_LIST_UNIT_PRICE_AM: null,
      clla_DELETION_IN: false,
      total_COST: 0,
      wm_TOTAL_COST: formatCurrency(0, 'en', '$'),
      wm_case_LINE_LIST_UNIT_PRICE_AM: formatCurrency(0, 'en', '$')
    }
    this.supplementalNoteDataList.push(anItemObject);
    this.supplementalNoteDataSource = new MatTableDataSource<supplementalLineNoteDto>(this.supplementalNoteDataList);
    this.setChanged(-1);
  }

  // Change case line list unit price
  onChangeCaseLineListUnitPrice(pValue: string, pIndex: number) {
    this.supplementalTabData.caseLineListAttachmentList[pIndex].case_LINE_LIST_UNIT_PRICE_AM = CaseUtils.unformatCurrency(this.fixupAmount(pValue));
    this.recalculateRow(this.supplementalTabData.caseLineListAttachmentList[pIndex]);
    this.setChanged(pIndex);
  }

  onChangeCASE_LINE_LIST_ATTACHMENT_QY(pValue: string, pIndex: number) {
    this.supplementalTabData.caseLineListAttachmentList[pIndex].case_LINE_LIST_ATTACHMENT_QY = CaseUtils.unformatCurrency(this.fixupAmount(pValue));
    this.recalculateRow(this.supplementalTabData.caseLineListAttachmentList[pIndex]);
    this.setChanged(pIndex);
  }

  // Fixup the number amount.
  fixupAmount(pValue: string): string {
    return CaseUtils.fixupNumber(pValue);
  }

  // Set the status to changed.
  setChanged(pIndex: number) {
    if (pIndex >= 0) {
      if (!this.supplementalNoteDataList[pIndex].status || this.supplementalNoteDataList[pIndex].status === DsamsConstants.ENT_UNCHANGED.toString()) {
        this.supplementalNoteDataList[pIndex].status = DsamsConstants.ENT_CHANGED.toString();
        this.caseUIService.theComponentSaveCaseLineState[CaseUIService.SAVE_CASE_LINE_PRICING_STATE].isDataChanged = true;
      }
    }
    this.supplementalTabData.caseLineListAttachmentList = !this.supplementalNoteDataList ? [] : this.supplementalNoteDataList;
    this.caseUIService.suppTabChanged.next(this.supplementalTabData);
  }

  // Populate Reference Lists
  private populateReferenceLists() {
    // *** Reference: Issue Unit ***
    this.caseRestService
      .getReferenceData(DsamsConstants.REF_ISSUE_UNIT, "", 0, true)
      .subscribe(
        (data: Array<ReferenceDataType>) => {
          this.issueUnitList = data;
        },
        err => {
          CaseUtils.ReportHTTPError(err, "Error fetching reference for " + DsamsConstants.REF_ISSUE_UNIT);
        }
      );
    // *** Reference: Source of Supply ***
    this.caseRestService
      .getReferenceData(DsamsConstants.REF_SUPPLY_SOURCE, "", 0, true)
      .subscribe(
        (data: Array<ReferenceDataType>) => {
          this.supplySourceList = data;
        },
        err => {
          CaseUtils.ReportHTTPError(err, "Error fetching reference for " + DsamsConstants.REF_SUPPLY_SOURCE);
        }
      );
  }

  //Jira card 4217-DH
  calculateBaseUnitPrice() {
    this.supplementalTabData.wm_component_UNIT_BASE_PRICE_AM =
      formatCurrency(this.supplementalTabData.component_UNIT_BASE_PRICE_AM, 'en', '$');
    this.supp_COMPONENT_UNIT_BASE_PRICE_AM = this.supplementalTabData.wm_component_UNIT_BASE_PRICE_AM;
    this.setChanged(-1);
  }

  // Text area popup
  popupTextAreaOpen(pElement: any, pIndex: number): void {
    let diaWidth: string = "50%";
    let diaHeight: string = "60%";
    let passingData: string = pElement.list_ITEM_DESCRIPTION_TX;
    let pTitle: string = "Supplemental Line Note Description";
    this._textIndex = pIndex;
    this.dsamsDialogMsgService.openTextAreaIpcDialog(diaWidth, diaHeight, passingData,
      TextAreaComponent, pIndex.toString(), pTitle, this.supplementalNoteDataSource.data[pIndex].isFieldDisabled['list_ITEM_DESCRIPTION_TX']);
  }
}