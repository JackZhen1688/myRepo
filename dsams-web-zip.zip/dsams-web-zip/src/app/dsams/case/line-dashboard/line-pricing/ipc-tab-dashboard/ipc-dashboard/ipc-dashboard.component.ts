import { Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { CaseLinePK } from 'src/app/dsams/case/model/case-line-pk';
import { CaseUIService } from 'src/app/dsams/case/services/case-ui-service';
import { CaseUtils } from 'src/app/dsams/case/utils/case-utils';

@Component({
  selector: 'app-ipc-dashboard',
  templateUrl: './ipc-dashboard.component.html',
  styleUrls: ['./ipc-dashboard.component.css']
})
export class IpcDashboardComponent implements OnInit {
  theCaseLinePkData: CaseLinePK;
  thePCCLabel: string = '';
  isSupplementalBaseSourcePrice : boolean = true;
  private caseLineIPCSubscription: Subscription = null;

  constructor(private caseUIService: CaseUIService) { }

  ngOnInit() {
    if (!this.caseLineIPCSubscription) {
      this.caseLineIPCSubscription = this.caseUIService.getCaseLinePK().subscribe((data) => {
        this.theCaseLinePkData = data;
        if (CaseUtils.isBlankStr(this.theCaseLinePkData.primary_CATEGORY_CD))
          this.thePCCLabel = 'Primary Category';
        else
          this.thePCCLabel = 'Primary Category: ' + this.theCaseLinePkData.primary_CATEGORY_CD;
      });
    }
  }

}
