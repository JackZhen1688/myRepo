import { Component, OnDestroy, OnInit, Injector } from '@angular/core';
import { CaseUIService } from '../../services/case-ui-service';
import { BehaviorSubject, Subscription } from 'rxjs';
import { ifaceCaseLineData, ifaceGenericRefItem } from '../../model/case-line-model';
import { CaseRestfulService } from '../../services/case-restful.service';
import { CustomerOrganizationRefList } from '../../model/dto/customer-organization';
import { Router } from '@angular/router';
import { MatTableDataSource } from '@angular/material';
import { FieldDisabledMap } from '../../model/field-disabled-map';
import { DsamsConstants } from 'src/app/dsams/dsams.constants';
import { IEditResponseType } from '../../model/edit-response-type';
import { CaseUtils } from '../../utils/case-utils';
import { caseConstants } from '../../case-dashboard/case-dashboard.component';
import { CurrencyPipe, formatCurrency, formatPercent, formatDate } from '@angular/common';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { DsamsMethodsService } from 'src/app/dsams/services/dsams-methods.service';
import { TextAreaComponent } from 'src/app/dsams/case/dialogs/text-area/text-area.component';
import { caseLineComponentDto, caseLineComponentForCivilianPopup, fundDto, priceElementDto } from '../../model/dto/case-line-component-dto';
import { CaseLinePK } from '../../model/case-line-pk';
import { ISelectOptions } from 'src/app/dsams/interfaces/i-select-options';
import { LineUtils } from '../line-utils';
import { CaseLineRelatedInfoType } from '../../model/case-line-related-info-type';
import { CivilianPersonnelComponent } from 'src/app/dsams/case/dialogs/civilian-personnel/civilian-personnel.component';
import { MatDialog } from '@angular/material/dialog';
import Swal from 'sweetalert2';
import { MessageMgr } from '../../validation/message-mgr';
import { PublicationsComponent } from 'src/app/dsams/case/dialogs/publications/publications.component';
import { CaseLineIPCDto } from './ipc-tab-dashboard/model/dto/case-line-ipc-dto';
import { caseLineComponentModel } from '../../model/case-line-component-model';
import { DTCComponent } from 'src/app/dsams/case/dialogs/dtc/dtc.component';
import { supplementalLineNoteDto } from './ipc-tab-dashboard/model/dto/supplemental-line-note-dto';
import { MtdsComponent } from '../../dialogs/mtds/mtds.component';
import { ErrorParameter } from 'src/app/dsams/entities/specialEntities/error-parameter.model';
import { DsamsUserMessageService } from 'src/app/dsams/services/dsams-user-message.service';
import { DialogMessageListComponentTc } from 'src/app/dsams/utilitis/dialogs/dialog-message-list-tc/dialog-message-list-tc.component';
import { MessageType } from 'src/app/dsams/enums/user-message.enum';
import { ReferenceDataType } from '../../model/reference-data-type';
import { CASE_LINE_COMP_DEL_TERM, ICaseLinePricing } from '../../model/dto/icase-line-pricing';
import { mtdsPersonnelModel } from '../../model/mtds-personnel-model';
import { mtdsPersonnelSupportCostsModel } from '../../model/mtds-personnel-support-costs-model';
import { mtdsTravelModel } from '../../model/mtds-travel-model';
import { LinePricingUtils } from '../line-pricing-utils';
import { DateValidator } from '../../validation/date-validator';
import { CaseCommonValidator } from '../../validation/case-common-validator';
import { take } from 'rxjs/operators';
import { MilestoneCommentComponent } from '../../dialogs/milestone-comment/milestone-comment.component';
import { LineDetailsComponent } from '../line/line-details.component';

export interface dropdownArray {
  pCode: string,
  pDesc: string
}

// Stores the value of the Old IPC value as it goes thru calculateCosts.
interface oldIpcStorage {
  clcRow: number,
  ipcRow: number,
  wm_OLD_IPC_NUMBER_ID: string,
  status: string
}

@Component({
  selector: 'app-line-pricing',
  templateUrl: './line-pricing.component.html',
  styleUrls: ['./line-pricing.component.css',
    '../common-CSS.component.css'],
  providers: [CurrencyPipe]
})
export class LinePricingComponent implements OnInit, OnDestroy {

  private static USER_ID: string = "userId";
  private static USER_ACTIVITY_ID : string = "userActivityId";
  _caseUIServiceSubscription: Subscription;
  //caseLineInfoData: ifaceCaseLineData;
  caseLinePricingInfoData: ifaceCaseLineData = {};

  customerOrgList: CustomerOrganizationRefList[];
  customerStructureList: ifaceCaseLineData;
  selectedTab: any;
  emptyString: string = '';
  emptyObject: ifaceGenericRefItem = { value_CD: '', value_TITLE_NM: '', value_TITLE_DESC: '' };
  hideBECtry: boolean = false;
  lineNumber: string = '';
  displayUnderscontruction: boolean = true;
  theExpandIPCPanel: boolean = false;
  caseLinePricingSummary: ICaseLinePricing;
  clcDataList: caseLineComponentDto[] = [];
  delClcDataList: caseLineComponentDto[] = [];
  isLoading: BehaviorSubject<boolean> = new BehaviorSubject(false);
  isPCCPresent: boolean = false;
  theOriginalPricingMethodValue: string;
  theOriginalRecalValue: boolean = false;
  isRecalculateChecked: boolean = true;

  _primaryCategorySubscription: Subscription;
  _priceElementSubscription: Subscription;
  _fundCdSubscription: Subscription;

  theCaselinePK: CaseLinePK;
  primaryCategoryArray: ReferenceDataType[] = [];
  componentPriceElementArray: dropdownArray[] = [];
  componentFundArray: dropdownArray[] = [];
  private _componentPriceElementFundString: string = "";
  private _fundFullList: Array<fundDto> = [];
  private _priceElementFullList: Array<priceElementDto> = [];
  basePriceSourceArray: dropdownArray[] = [];
  fiscalYearArray: dropdownArray[] = [];
  targetPercentRTArray: number[] = [];
  targetCostAMArray: number[] = [];
  targetPercentRT: number;
  targetCostAM: number;
  categoryCode: string[] = [];
  elementCode: string[] = [];
  fundCode: string[] = [];
  basePriceSourceDesc: string;
  caseLineCompDelTermArray: CASE_LINE_COMP_DEL_TERM[] = [];
  caseLineRelatedInfoData: CaseLineRelatedInfoType;
  aCaseUserId: any;
  isSaveButtonDisabled: boolean = true;
  isTlscDisabled: boolean = true;
  private _globalDeletedAttachmentList: Array<supplementalLineNoteDto>;
  private _globalDeletedMtdsPersonnelList: Array<mtdsPersonnelModel>;
  private _globalDeletedMtdsSupportList: Array<mtdsPersonnelSupportCostsModel>;
  private _globalDeletedMtdsTravelList: Array<mtdsTravelModel>;

  /*fetchCaseLineForPricing - return boolean called WM_HasFiscalYearDistribution */
  wm_HasFiscalYearDistribution: boolean = false;

  /* Base Price Source Constants */
  public static get USER_ENTERED(): string { return "User Entered"; }
  public static get SUPPLEMENTAL_LINE_NOTE(): string { return "Supplemental Line Note" }
  public static get PUBLICATION(): string { return "Publication"; }
  public static get CIVILIAN_PERSONNEL(): string { return "Civilian Personnel"; }
  public static get REVERSE_CALCULATION(): string { return "Reverse Calculation"; }
  public static get MTDS(): string { return "MTDS"; }

  //Text Area
  private textAreaSubscription: Subscription = null;

  dataSourcePricingTable = new MatTableDataSource<caseLineComponentDto>();

  lineIndex: number;

  //Description Index
  index: number = 1;

  // Fields for summary pricing data
  price_EFFECTIVE_DT: Date = null;
  price_EFFECTIVE_DT_string: string = '';
  price_EXPIRATION_DT: Date = null;
  price_EXPIRATION_DT_string: string = '';
  case_LINE_ITEM_QY: number = null;
  target_TOTAL_LINE_AM: number = null;
  unit_ABOVE_LINE_COST_AM: number = null;
  total_ABOVE_LINE_COST_AM: number = null;
  unit_BELOW_LINE_COST_AM: number = null;
  total_BELOW_LINE_COST_AM: number = null;
  total_LINE_VALUE_AM: number = null;
  totalInWorkAm: number = null;
  case_LINE_ITEM_QY_string: string = '';
  target_TOTAL_LINE_AM_string: string = '';
  unit_ABOVE_LINE_COST_AM_string: string = '';
  total_ABOVE_LINE_COST_AM_string: string = '';
  total_LINE_VALUE_AM_string: string = '';
  totalInWorkAm_string: string = '';
  military_ARTICLE_SERVICE_CD_string: string = '';
  mtds_NARRATIVE_DESCRIPTION_TX_string: string = '';
  pricing_METHOD_CD_string: string = '';
  wm_USER_CASE_SUBLINE_TX: string = '';

  /**
   * Editability fields
   */
  isPanelEditable: boolean = false;
  private _fieldDisabledMap: FieldDisabledMap = {};
  private editSubscription: Subscription = null;
  private unEditSubscription: Subscription = null;

  // UI Fields
  private _caseLinePricingChangedSubscription: Subscription = null;
  private _ipcTabChangedSubscription: Subscription = null;
  private _ipcTabDeletedSubscription: Subscription = null;
  private _cbTabChangedSubscription: Subscription = null;
  private _suppTabChangedSubscription: Subscription = null;
  private _suppTabDeletedSubscription: Subscription = null;
  private _civPopupSubscription: Subscription = null;
  private _pubPopupSubscription: Subscription = null;
  private _mtdsPopupSubscription: Subscription = null;
  private _milestoneDialogSubscription: Subscription = null;
  private _mielstoneCommentNullSubscription: Subscription = null;
  
  private _expandedClcIndex: number = -1;
  private _dtcDataChangedSubscription: Subscription = null;
  private _popupCivIndex: number = -1;
  private _popupDtcIndex: number = -1;
  private _popupPubIndex: number = -1;
  private _popupMtdsIndex: number = -1;
  private _promptFinancialCheck: boolean = true;
  private _oldIpcStorageArray: oldIpcStorage[] = [];

  private _isResetPricingData: Subscription = null;

  pricingColumnsToDisplay =
    [
      'downArrow',
      'primaryCategory',
      'icon1',
      'componentPriceElement',
      'componentFund',
      'basePriceSource',
      'icon2',
      'baseUnitPrice',
      'baseQuantity',
      'targetPCPercent',
      'targetPCCost',
      'aboveLinePCCost',
      'totalPCValue',
      'description',
      'DeleteRow'
    ];
  pricingColumnsToDisplayFooter = ['AddRow'];

  fcPricingMethod: FormControl;

  pricingForm: FormGroup;

  private readonly PRICING_METHOD_FC: string = "0";
  private readonly PRICING_METHOD_RCATL: string = "1";
  private readonly PRICING_METHOD_RCTV: string = "2";
  private readonly PRICING_METHOD_RCUATL: string = "3";
  private readonly PRICING_METHOD_RCUTV: string = "4";

  validPricingMethods: ISelectOptions[] = [
    { value: this.PRICING_METHOD_FC, viewValue: 'Forward Calculate' },
    { value: this.PRICING_METHOD_RCATL, viewValue: 'Reverse Calculate Above the Line' },
    { value: this.PRICING_METHOD_RCTV, viewValue: 'Reverse Calculate Total Value' },
    { value: this.PRICING_METHOD_RCUATL, viewValue: 'Reverse Calculate Unit Above the Line' },
    { value: this.PRICING_METHOD_RCUTV, viewValue: 'Reverse Calculate Unit Total Value' }
  ];

  // Table for DTC
  dataSourceDTCTable = new MatTableDataSource<CASE_LINE_COMP_DEL_TERM>();
  dtcColumnsToDisplay =
    [
      'primaryCategoryCode',
      'deliveryTermCode',
      'deliveryTitle',
      'DeliveryPercent'
    ];
  // Total Percentage
  totalDTCPercentage: number;

  dtcDrawerIndex: number;

  // For Civilian Personnel Popup
  clcElementForCivilianPersonnel: caseLineComponentDto = null;

  caseUIService: CaseUIService;
  dsamsDialogMsgService: DsamsMethodsService;
  caseRestService: CaseRestfulService;
constructor(
    private popUpDialog: MatDialog,
    private injector : Injector,
    private formBuilder: FormBuilder,
    public dialog: MatDialog,
    private router: Router,
    private currencyPipe: CurrencyPipe,
    private messageService: DsamsUserMessageService) { 
      this.caseUIService = injector.get<CaseUIService>(CaseUIService);
      this.dsamsDialogMsgService = injector.get<DsamsMethodsService>(DsamsMethodsService);
      this.caseRestService = injector.get<CaseRestfulService>(CaseRestfulService);
    }

  ngOnInit() {
    
    
    this.fcPricingMethod = new FormControl('');
    this.isSaveButtonDisabled = true;

    this.constructPricingForm();
    this.subscribeCaseLineInfo();
    //move it  inside subscribeCaseLineInfo
    //this.subscribeToEditServices();
    this.subscribeToChangesFromIpcTab();
    this.subscribeToChangesFromSuppTab();
    this.subscribeToChangesFromPopups();
    this.subscribeToContinueOnEditToggle();
    this.subscribeToSaveOnEditToggle();

    // Subscribe to Options for Pricing
    /* Base Price Source */
    this.basePriceSourceArray.push({ pCode: '1', pDesc: LinePricingComponent.USER_ENTERED });
    this.basePriceSourceArray.push({ pCode: '2', pDesc: LinePricingComponent.SUPPLEMENTAL_LINE_NOTE });
    this.basePriceSourceArray.push({ pCode: '3', pDesc: LinePricingComponent.PUBLICATION });
    this.basePriceSourceArray.push({ pCode: '4', pDesc: LinePricingComponent.CIVILIAN_PERSONNEL });
    this.basePriceSourceArray.push({ pCode: '5', pDesc: LinePricingComponent.REVERSE_CALCULATION });
    this.basePriceSourceArray.push({ pCode: '7', pDesc: LinePricingComponent.MTDS });

    this.subscribeToOptionCaseInReview();
    this.subscribeToOptionCaseInProposed();
    this.subscribeToOptionCasePenInk();
    this.isPanelEditable = false;
    //populate pricing data when refreshed
    this.caseUIService.getNotifyToRefreshPricingData().subscribe(isRefresh => {
      this.theExpandIPCPanel = false;
      this.dataSourcePricingTable = new MatTableDataSource<caseLineComponentDto>([]);
      this.dataSourcePricingTable._updateChangeSubscription();
      if (isRefresh) {
        this.getPricingData();
        this.subscribeToEditServices();
        this.caseUIService.setNotifyToRefreshPricingData(false);
      }
    })
    this._isResetPricingData = this.caseUIService.pricingReset.subscribe(isReSet => {
      if (isReSet) {
          this.wm_USER_CASE_SUBLINE_TX = null;
          this.price_EFFECTIVE_DT = null;
          this.resetPricingDataAfterDelete(false);
      }
    })
  }

  // Subscribe to Save on Edit Toggle
  private saveOnEditToggleSub: Subscription = null;
  subscribeToSaveOnEditToggle() {
    if (!!this.saveOnEditToggleSub) {
      this.saveOnEditToggleSub.unsubscribe();
      this.saveOnEditToggleSub = null;
    }
    this.saveOnEditToggleSub = this.caseUIService.theComponentSaveCaseLineState[CaseUIService.SAVE_CASE_LINE_PRICING_STATE].isSaveConfirmed
      .subscribe(isSaveConfirmed => {
        if (isSaveConfirmed) {
          this._promptFinancialCheck = true;
          this.saveButtonCheckIfOption();
        }
      });
  }
  // Subscribe to Continue on Edit Toggle
  private continueOnEditToggleSub: Subscription = null;
  subscribeToContinueOnEditToggle() {
    if (!!this.continueOnEditToggleSub) {
      this.continueOnEditToggleSub.unsubscribe();
      this.continueOnEditToggleSub = null;
    }
    this.continueOnEditToggleSub = this.caseUIService.theComponentSaveCaseLineState[CaseUIService.SAVE_CASE_LINE_PRICING_STATE].isContinueConfirmed
      .subscribe(isContinueConfirmed => {
        if (isContinueConfirmed) {
          const turnToggleOff: IEditResponseType = { ID: DsamsConstants.CASE_LINE_EDITOR, editToggle: false };
          this.caseUIService.caseEditService.next(turnToggleOff);
          this.getPricingData();
          this.caseLinePricingInfoData.isPricingDataChanged = false;
          this.caseUIService.setIsLineTabDisabled(false);
          this.theExpandIPCPanel = false;
        }
      });
  }
  
  //breakout logic per sonarqube rule
  destroySubs() {
    if (!!this._isResetPricingData) {
      this._isResetPricingData.unsubscribe();
      this._isResetPricingData = null;
    }

    if (!!this._dtcDataChangedSubscription) {
      this._dtcDataChangedSubscription.unsubscribe();
      this._dtcDataChangedSubscription = null;
    }

    if (!!this._milestoneDialogSubscription) {
      this._milestoneDialogSubscription.unsubscribe();
      this._milestoneDialogSubscription = null;
    }

    if (!!this._mielstoneCommentNullSubscription) {
      this._mielstoneCommentNullSubscription.unsubscribe();
      this._mielstoneCommentNullSubscription = null;
    }

    if (!!this.continueOnEditToggleSub) {
      this.continueOnEditToggleSub.unsubscribe();
      this.continueOnEditToggleSub = null;
    }

    if (!!this.saveOnEditToggleSub) {
      this.saveOnEditToggleSub.unsubscribe();
      this.saveOnEditToggleSub = null;
    }
  }

  ngOnDestroy() {
    if (!!this.textAreaSubscription) {
      this.textAreaSubscription.unsubscribe();
      this.textAreaSubscription = null;
    }

    if (!!this._primaryCategorySubscription) {
      this._primaryCategorySubscription.unsubscribe();
      this._primaryCategorySubscription = null;
    }

    if (!!this._priceElementSubscription) {
      this._priceElementSubscription.unsubscribe();
      this._priceElementSubscription = null;
    }

    if (!!this._fundCdSubscription) {
      this._fundCdSubscription.unsubscribe();
      this._fundCdSubscription = null;
    }

    if (!!this._caseLinePricingChangedSubscription) {
      this._caseLinePricingChangedSubscription.unsubscribe();
      this._caseLinePricingChangedSubscription = null;
    }

    if (!!this.editSubscription) {
      this.editSubscription.unsubscribe();
      this.editSubscription = null;
    }

    if (!!this.unEditSubscription) {
      this.unEditSubscription.unsubscribe();
      this.unEditSubscription = null;
    }

    if (!!this._ipcTabChangedSubscription) {
      this._ipcTabChangedSubscription.unsubscribe();
      this._ipcTabChangedSubscription = null;
    }

    if (!!this._ipcTabDeletedSubscription) {
      this._ipcTabDeletedSubscription.unsubscribe();
      this._ipcTabDeletedSubscription = null;
    }

    if (!!this._suppTabChangedSubscription) {
      this._suppTabChangedSubscription.unsubscribe();
      this._suppTabChangedSubscription = null;
    }

    if (!!this._suppTabDeletedSubscription) {
      this._suppTabDeletedSubscription.unsubscribe();
      this._suppTabDeletedSubscription = null;
    }

    if (!!this._cbTabChangedSubscription) {
      this._cbTabChangedSubscription.unsubscribe();
      this._cbTabChangedSubscription = null;
    }

    if (!!this._civPopupSubscription) {
      this._civPopupSubscription.unsubscribe();
      this._civPopupSubscription = null;
    }

    if (!!this._pubPopupSubscription) {
      this._pubPopupSubscription.unsubscribe();
      this._pubPopupSubscription = null;
    }

    if (!!this._mtdsPopupSubscription) {
      this._mtdsPopupSubscription.unsubscribe();
      this._mtdsPopupSubscription = null;
    }
    this.destroySubs();
  }

  getTheUserCaseInfo() {
    this.caseUIService.getCaseLineRelatedInfoValues().subscribe((value) => {
      this.caseLineRelatedInfoData = value;
      // Concatenate the case user ID with case version type code         
      if (!!this.caseLineRelatedInfoData) {
        //exclude version for basic case
        //if (this.caseLineRelatedInfoData.case_VERSION_TYPE_CD == 'B')
        if (this.caseLineRelatedInfoData.case_VERSION_NUMBER_ID == 0) {
          setTimeout(() => {
            this.aCaseUserId = '(' + this.caseLineRelatedInfoData.user_CASE_ID
              + ' ' + this.caseLineRelatedInfoData.case_VERSION_TYPE_CD + ')';
          }, 0);
        }
        else {
          setTimeout(() => {
            this.aCaseUserId = '(' + this.caseLineRelatedInfoData.user_CASE_ID
              + ' ' + this.caseLineRelatedInfoData.case_VERSION_TYPE_CD
              + ' ' + this.caseLineRelatedInfoData.case_VERSION_NUMBER_ID + ')';
          }, 0);
        }
      }
    });
  }

  //DH: Jira 4216 - Reorganize code for readability
  getReferenceData() {
    /* Primary Category */
    this._primaryCategorySubscription = this.caseRestService.getReferenceData(DsamsConstants.REF_PRIMARY_CATEGORY, "", 0, true, false, DsamsConstants.REST_API_NULL, 2).subscribe(
      (data: Array<ReferenceDataType>) => {
        this.primaryCategoryArray = data;
        this.primaryCategoryArray.sort((a, b) => a.key_FIELD.localeCompare(b.key_FIELD));
      },
      err => {
        CaseUtils.ReportHTTPError(err, caseConstants.REFERENCE_ERROR_HEADER_STR + DsamsConstants.REF_PRIMARY_CATEGORY);
      }
    );
    /* Component Price Element */
    this._priceElementSubscription = this.caseRestService.getReferenceData(DsamsConstants.REF_COMPONENT_PRICE_ELEMENT, "", 0, true, false, DsamsConstants.REST_API_NULL, 2).subscribe(
      (refDataList: Array<ReferenceDataType>) => {
        for (let refData of refDataList) {
          this.componentPriceElementArray.push({ pCode: refData.key_FIELD, pDesc: refData.field_2 });
          this._priceElementFullList.push({ price_ELEMENT_CD: refData.key_FIELD, price_ELEMENT_TITLE_NM: refData.field_2 });
        }
      },
      err => {
        CaseUtils.ReportHTTPError(err, caseConstants.REFERENCE_ERROR_HEADER_STR + DsamsConstants.REF_COMPONENT_PRICE_ELEMENT);
      }
    );
    /* Component Fund */
    this._fundCdSubscription = this.caseRestService.getReferenceData(DsamsConstants.REF_FUND, "", 0, true, false, DsamsConstants.REST_API_NULL, 2).subscribe(
      (refDataList: Array<ReferenceDataType>) => {
        for (let refData of refDataList) {
          this.componentFundArray.push({ pCode: refData.key_FIELD, pDesc: refData.field_2 });
          this._fundFullList.push({ fund_CD: refData.key_FIELD, fund_TITLE_NM: refData.field_2 });
        }
      },
      err => {
        CaseUtils.ReportHTTPError(err, caseConstants.REFERENCE_ERROR_HEADER_STR + DsamsConstants.REF_FUND);
      }
    );
    // Get the Price Element Fund info (no need for a subscription variable for rest services).
    this.caseRestService.getReferenceData(DsamsConstants.REF_COMPONENT_PRICE_ELEMENT_FUND, "", 0, true, false, DsamsConstants.REST_API_NULL, 2).subscribe(
      (refDataList: Array<ReferenceDataType>) => {
        for (let refData of refDataList) {
          this._componentPriceElementFundString = this._componentPriceElementFundString + "*" + refData.key_FIELD + "@" + refData.field_1 + "*";
        }
      },
      err => {
        CaseUtils.ReportHTTPError(err, caseConstants.REFERENCE_ERROR_HEADER_STR + DsamsConstants.REF_COMPONENT_PRICE_ELEMENT_FUND);
      }
    );
    /* Fiscal Year from reference */
    this.caseRestService
      .getReferenceData(DsamsConstants.REF_FISCAL_YEAR, "", 0, true)
      .subscribe(
        data => {
          this.fiscalYearArray = data;
        },
        err => {
          CaseUtils.ReportHTTPError(err, "Error fetching reference for " + DsamsConstants.REF_FISCAL_YEAR);
        }
      );
  }

  //DH: Jira 4216 - Get pricing data
 public  getPricingData() {
    this.caseUIService.getCaseRelatedInfoValues().forEach(eachRow => {
      if (!!eachRow && !!eachRow.case_MASTER_LINE_ID) {
        this.isLoading.next(true);
        //console.log('getPricingData', this.caseLinePricingInfoData)
        this.populateCaseLinePricingSummary();
        this.getReferenceData();
        this.theOriginalRecalValue = this.caseLinePricingInfoData.recalculation_IN;
        this.wm_USER_CASE_SUBLINE_TX = this.caseLinePricingInfoData.wm_USER_CASE_SUBLINE_TX;

        // Convert to N/A if $0
        if (this.total_ABOVE_LINE_COST_AM === 0) {
          this.total_ABOVE_LINE_COST_AM_string = 'N/A'
        }
        else {
          this.total_ABOVE_LINE_COST_AM_string = this.currencyPipe.transform(this.total_ABOVE_LINE_COST_AM, 'USD', 'symbol-narrow', '3.0-0', 'en-US');
        }
        // Set the total above line cost amount from case line data call 
        // as it is not set in the pricing summary data call
        this.total_ABOVE_LINE_COST_AM = parseInt(LineUtils.removeDollarSign(this.caseLinePricingInfoData.total_ABOVE_LINE_COST_AM));

        this.dtcDrawerIndex = 999;
        //Description Comment Subscription
        this.textAreaSubscription = this.dsamsDialogMsgService.textAreaFromDialog.subscribe((textAreaValue: string) => {
          setTimeout(() => {
            if (!!this.dataSourcePricingTable.data[this.index]) {
              this.dataSourcePricingTable.data[this.index].component_DESCRIPTION_TX = textAreaValue;
              this.clcDataList[this.index].component_DESCRIPTION_TX = textAreaValue;
              //DH: Commented out as this cause unexpected save behavior 
              //this.onChangeCaseLineComponent(this.index);
            }
          }, 0);
        });

      }
    })
  }

  subscribeCaseLineInfo() {
    const BENEFITING_COUNTRY: string = "BE";
    this._caseUIServiceSubscription = this.caseUIService.getCaseLineInfoValues().subscribe((value) => {
      this.caseLinePricingInfoData = value;

      //Set inital values to avoid display undefined values error
      if (!!this.caseLinePricingInfoData) {
        if (!!this.caseLinePricingInfoData.LINESUBLINESEQVIR)
          this.lineNumber = this.caseLinePricingInfoData.LINESUBLINESEQVIR.substring(0, 3);
        this.case_LINE_ITEM_QY_string = this.caseLinePricingInfoData.case_LINE_ITEM_QY;
      }
      else {
        this.caseLinePricingInfoData = {};
      }

      if ((!!this.caseLinePricingInfoData) &&
        (!!this.caseLinePricingInfoData.case_CUSTOMER_TYPE_CD) &&
        this.caseLinePricingInfoData.case_CUSTOMER_TYPE_CD.toUpperCase() == BENEFITING_COUNTRY) {
        this.hideBECtry = false;
        //FR3
        this.caseLinePricingInfoData.customerStructureList = [];
        this.caseLinePricingInfoData.customerStructureList.push(this.emptyObject);
        this.caseRestService.getCaseLineRefList("CUSTOMER_STRUCTURE").subscribe(custOrg => {
          for (var i = 0; i < custOrg.length; i++) {
            if (this.caseLinePricingInfoData.customerStructureList && custOrg[i]) {
              this.caseLinePricingInfoData.customerStructureList.push(custOrg[i]);
            }
          }
        })
      }
      else {
        this.hideBECtry = true;
      }
    });
  }

  refreshCaseLineInfoData() {
    console.log();
  }

  //back to previous Case Search Summary page 
  goBackToCaseSearchSummary() {
    this.caseUIService.setbackToCaseSearchSummaryValue(true);
    //Disable Line and Pricing tabs
    this.caseUIService.setIsLineTabDisabled(true);
    this.router.navigateByUrl('/case/search');
  }

  onSelectClick(line: string, index: number) {
    this.lineNumber = line;
    this.lineIndex = index;
  }

  /**
   * Get the code based on the option selected for an element in dropdownArray.
   */
  getCodeFromDescription(pDropdownArray: dropdownArray[], pDesc: string): string {
    const theFilteredArray: dropdownArray[] = pDropdownArray.filter(dd => dd.pDesc === pDesc);
    return theFilteredArray.length == 1 ? theFilteredArray[0].pCode : "";
  }


  //Jira card 3577-DH-Enable Pricing Method related fields
  enablePricingMethodRelatedFields(pPricingMethodCd: string) {
    if (pPricingMethodCd === this.PRICING_METHOD_FC) {
      // Set the initialvalues
      this.dataSourcePricingTable.data.forEach(eachRow => {
        eachRow.isFieldDisabled['wm_component_UNIT_BASE_PRICE_AM'] = true;
        eachRow.isFieldDisabled['wm_target_COST_AM'] = false;
        eachRow.isFieldDisabled['case_LINE_COMPONENT_QY'] = false;
        eachRow.isFieldDisabled['wm_target_PERCENT_RT'] = true;
        eachRow.isFieldDisabled['wm_base_PRICE_SOURCE_NM'] = false;
      });
      this.isTlscDisabled = true;
      this.caseLinePricingSummary.target_TOTAL_LINE_AM = 0;
      this.target_TOTAL_LINE_AM_string = "N/A";
    }
    else {
      this.dataSourcePricingTable.data.forEach(eachRow => {
        eachRow.base_PRICE_SOURCE_CD = 5;
        eachRow.wm_base_PRICE_SOURCE_NM = LinePricingComponent.REVERSE_CALCULATION;
        eachRow.isFieldDisabled['wm_component_UNIT_BASE_PRICE_AM'] = true;
        eachRow.isFieldDisabled['wm_target_COST_AM'] = false;
        eachRow.isFieldDisabled['case_LINE_COMPONENT_QY'] = false;
        eachRow.isFieldDisabled['wm_target_PERCENT_RT'] = false;
        eachRow.isFieldDisabled['wm_base_PRICE_SOURCE_NM'] = true;
      });
      let i: number = 0;
      this.clcDataList.forEach(eachRow => {
        eachRow.base_PRICE_SOURCE_CD = 5;
        eachRow.wm_base_PRICE_SOURCE_NM = LinePricingComponent.REVERSE_CALCULATION;
        this.onChangeCaseLineComponent(i++);
      });
      this.isTlscDisabled = false;
      if (!this.target_TOTAL_LINE_AM_string || this.target_TOTAL_LINE_AM_string == "N/A") {
        this.caseLinePricingSummary.target_TOTAL_LINE_AM = 0;
        this.target_TOTAL_LINE_AM_string = this.currencyPipe.transform(this.caseLinePricingSummary.target_TOTAL_LINE_AM, 'USD', 'symbol-narrow', '1.0-0', 'en-US');
      }
    }
  }

  // Enable control fields for all CLC-s
  private enableControlFieldsForAllClcs() {
    if (!!this.dataSourcePricingTable.data) {
      let i: number = 0;
      this.dataSourcePricingTable.data.forEach(eachClc => {
        this.enableControlFields(eachClc.wm_base_PRICE_SOURCE_NM, i++);
      });
    }
  }


  //Jira card 3577-DH-Enable costs related fields
  enableControlFields(pDesc: string, pIndex: number) {
    this.dataSourcePricingTable.data[pIndex].isFieldDisabled = {
      case_LINE_COMPONENT_QY: true,
      wm_target_COST_AM: true,
      wm_component_UNIT_BASE_PRICE_AM: true,
      wm_target_PERCENT_RT: true,
      price_ELEMENT_CD: true,
      fund_CD: true,
      wm_base_PRICE_SOURCE_NM: true
    }

    if (!this.isPanelEditable) {
      return true;
    }

    switch (pDesc) {
      case LinePricingComponent.USER_ENTERED: {
        this.dataSourcePricingTable.data[pIndex].isFieldDisabled['wm_component_UNIT_BASE_PRICE_AM'] = false;
        this.dataSourcePricingTable.data[pIndex].isFieldDisabled['case_LINE_COMPONENT_QY'] = false;
        this.dataSourcePricingTable.data[pIndex].isFieldDisabled['wm_base_PRICE_SOURCE_NM'] = false;
        break;
      }
      case LinePricingComponent.REVERSE_CALCULATION: {
        this.dataSourcePricingTable.data[pIndex].isFieldDisabled['wm_target_COST_AM'] = false;
        this.dataSourcePricingTable.data[pIndex].isFieldDisabled['case_LINE_COMPONENT_QY'] = false;
        this.dataSourcePricingTable.data[pIndex].isFieldDisabled['wm_base_PRICE_SOURCE_NM'] =
          //sonarque cleanup
          //!(this.caseLinePricingSummary.pricing_METHOD_CD == this.PRICING_METHOD_FC);
          (this.caseLinePricingSummary.pricing_METHOD_CD != this.PRICING_METHOD_FC);
        this.dataSourcePricingTable.data[pIndex].isFieldDisabled['wm_target_PERCENT_RT'] = (this.caseLinePricingSummary.pricing_METHOD_CD == this.PRICING_METHOD_FC);
        break;
      }
      case LinePricingComponent.PUBLICATION:
      case LinePricingComponent.MTDS:
      case LinePricingComponent.CIVILIAN_PERSONNEL:
      case LinePricingComponent.SUPPLEMENTAL_LINE_NOTE: {
        this.dataSourcePricingTable.data[pIndex].isFieldDisabled['case_LINE_COMPONENT_QY'] = false;
        this.dataSourcePricingTable.data[pIndex].isFieldDisabled['wm_base_PRICE_SOURCE_NM'] = false;
        break;
      }
    }
    if (this.dataSourcePricingTable.data[pIndex].status == DsamsConstants.ENT_NEW.toString()) {
      this.dataSourcePricingTable.data[pIndex].isFieldDisabled['price_ELEMENT_CD'] = false;
      this.dataSourcePricingTable.data[pIndex].isFieldDisabled['fund_CD'] = false;
    }
    this.dataSourcePricingTable._updateChangeSubscription();
  }

  onChangeCaseLine() {
    if (!!this.caseLinePricingSummary) {
      if (!this.caseLinePricingSummary.status || this.caseLinePricingSummary.status == DsamsConstants.ENT_UNCHANGED) {
        this.caseLinePricingSummary.status = DsamsConstants.ENT_CHANGED;
      }
    }
    //Jira card 4219-DH
    if (this.isRecalculateChecked) this.caseLinePricingInfoData.recalculation_IN = true;
    else this.isRecalculateChecked = true;
    this.caseLinePricingInfoData.isPricingDataChanged = true;
    this.caseUIService.theComponentSaveCaseLineState[CaseUIService.SAVE_CASE_LINE_PRICING_STATE].isDataChanged = true;
  }

  onChangeCaseLineComponent(pIndex: number) {
    if (!!this.clcDataList[pIndex] && (!this.clcDataList[pIndex].status || this.clcDataList[pIndex].status == DsamsConstants.ENT_UNCHANGED.toString())) {
      this.clcDataList[pIndex].status = DsamsConstants.ENT_CHANGED.toString();
      this.isPCCPresent = false; //delete pricing button
    } else {
      if (this.isPanelEditable) this.isPCCPresent = true;
      else this.isPCCPresent = false;
    }
    this.onChangeCaseLine();
  }

  /**
   * Save off the case line pricing info to session storage.
   */
  private saveCaseLineToSession() {
    //DH: commented out as it is no longer needed
    //this.caseLinePricingSummary.caseLineComponentList = this.clcDataList;
    //sessionStorage.setItem(DsamsConstants.SESSION_CASE_LINE_DETAILS_FOR_PRICING, JSON.stringify(this.caseLinePricingSummary));
  }


  isCaseLinePricingChanged(): boolean {
    if (this.caseLinePricingSummary == null || this.caseLinePricingSummary.status == null) return false;
    return (this.caseLinePricingSummary.status != DsamsConstants.ENT_UNCHANGED);
  }

  onChangePricingMethod(pValue: string) {
    this.caseLinePricingSummary.pricing_METHOD_CD = pValue;
    let aPricingMethod = this.validPricingMethods.filter(pricingValue => pricingValue.value == pValue);
    let messageStr = "Changing the Pricing Method will result in resetting all Target PC Costs. Do you want to continue?";
    let confirmMsg: any = {
      text: messageStr,
      icon: 'question',
      width: 700,
      showCancelButton: true,
      cancelButtonText: 'No',
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes'
    };
    MessageMgr.swalFire(confirmMsg).then((result) => {
      if (result.value) {
        this.dataSourcePricingTable.data.forEach((eachRow, index) => {
          eachRow.wm_target_COST_AM = formatCurrency(0, 'en', '$');
          this.clcDataList[index].target_COST_AM = 0;
        })
        if (!!aPricingMethod[0]) {
          this.enablePricingMethodRelatedFields(aPricingMethod[0].value);
        }
        this.recalculateCaseLineTotals();
        this.onChangeCaseLine();
        this.theOriginalPricingMethodValue = pValue;
      }
      else {
        this.pricing_METHOD_CD_string = this.theOriginalPricingMethodValue;
        this.fcPricingMethod.setValue(this.theOriginalPricingMethodValue);
      }
    })
    this.dataSourcePricingTable._updateChangeSubscription();
  }


  onChangeTARGET_TOTAL_LINE_AM(pValue: string) {
    this.caseLinePricingSummary.target_TOTAL_LINE_AM = CaseUtils.unformatCurrency(CaseUtils.fixupNumber(pValue));
    this.target_TOTAL_LINE_AM_string = this.currencyPipe.transform(this.caseLinePricingSummary.target_TOTAL_LINE_AM, 'USD', 'symbol-narrow', '1.0-0', 'en-US');
    this.onChangeCaseLine();
  }


  onFocusTARGET_TOTAL_LINE_AM() {
    if (this.target_TOTAL_LINE_AM_string == "N/A") {
      this.target_TOTAL_LINE_AM_string = " ";
    }
  }

  onChangePrimaryCategory(pPrimaryCategory: string, pIndex: number) {
    const pccCd = pPrimaryCategory.substring(0, pPrimaryCategory.indexOf("*"));
    const mtdsIn = pPrimaryCategory.substring(pPrimaryCategory.indexOf("*") + 1, pPrimaryCategory.indexOf("^"));
    const fundCd = pPrimaryCategory.substring(pPrimaryCategory.indexOf("^") + 1, pPrimaryCategory.indexOf("#"));
    const priceElementCd = pPrimaryCategory.substring(pPrimaryCategory.indexOf("#") + 1);
    let clcData: caseLineComponentDto = this.clcDataList[pIndex];
    this._expandedClcIndex = pIndex;
    clcData.primary_CATEGORY_CD = pccCd;
    clcData.thePrimaryCategoryCd = {
      primary_CATEGORY_CD: (pccCd === "null") ? "" : pccCd,
      mtds_IN: (mtdsIn === "1")
    }
    clcData.fundList = this._fundFullList;
    clcData.priceElementList = this._priceElementFullList;
    clcData.fund_CD = (fundCd === "null") ? "" : fundCd;
    clcData.price_ELEMENT_CD = (priceElementCd === "null") ? "" : priceElementCd;
    clcData.pouplateFundFlag = true;
    clcData.populatePEFlag = true;
    clcData.primaryCategoryChanged = true;
    this.theCaselinePK = {
      case_ID: this.caseLinePricingSummary.case_ID,
      case_MASTER_LINE_ID: this.caseLinePricingSummary.case_MASTER_LINE_ID,
      working_CASE_ID: this.caseLinePricingSummary.working_CASE_ID,
      working_CASE_VERSION_ID: this.caseLinePricingSummary.working_CASE_VERSION_ID,
      case_LINE_COMPONENT_ID: !clcData.case_LINE_COMPONENT_ID ? 0 : clcData.case_LINE_COMPONENT_ID,
      case_USAGE_INDICATOR_CD: this.caseLinePricingInfoData.case_USAGE_INDICATOR_CD,
      primary_CATEGORY_CD: pccCd,
      primaryCategoryChanged: true
    };
    setTimeout(() => {
      this.caseUIService.setCaseLinePK(this.theCaselinePK);
    }, 100);
    console.log('clcData', clcData);
    setTimeout(() => {
      this.repopulateIPCList(clcData);
    }, 10);
    this.onChangeCaseLineComponent(pIndex);
  }

  private populateDatabaseIpcList(pClc: caseLineComponentDto) {
    let theListStr: string = "";
    if (!!pClc.caseLineIpcList) {
      pClc.caseLineIpcList.forEach(eachIpc => { theListStr = theListStr + eachIpc.ipc_NUMBER_ID + "~"; })
    }
    pClc.databaseIpcListStr = theListStr;
  }

  // Repopulate the IPC-s
  private repopulateIPCList(pClc: caseLineComponentDto) {
    this.isLoading.next(true);
    this.caseRestService.getCaseLineIPCDto(this.theCaselinePK.primary_CATEGORY_CD).subscribe((pCaseLineIPCDtoList: CaseLineIPCDto[]) => {
      if (!!pCaseLineIPCDtoList) {
        // Delete existing IPC Rows.
        let currIpcList: CaseLineIPCDto[] = this.clcDataList[this._expandedClcIndex].caseLineIpcList;
        if (!!currIpcList) {
          for (let currIpc of currIpcList) {
            this.deleteIpcLine(currIpc);
          }
        }
        currIpcList = [];
        for (let clIpc of pCaseLineIPCDtoList) {
          // If the IPC was in the database before, make sure the status is set to ENT_CHANGED, not ENT_NEW, 
          // so we don't get a unbique constraint error.
          const theStatus: number = (!!this.clcDataList[this._expandedClcIndex].databaseIpcListStr && this.clcDataList[this._expandedClcIndex].databaseIpcListStr.indexOf(clIpc.ipc_NUMBER_ID) >= 0) ? DsamsConstants.ENT_CHANGED : DsamsConstants.ENT_NEW;
          // Push new recs to the IPC list.
          currIpcList.push(Object.assign(clIpc, {
            case_ID: this.theCaselinePK.case_ID,
            case_MASTER_LINE_ID: this.theCaselinePK.case_MASTER_LINE_ID,
            working_CASE_ID: this.theCaselinePK.working_CASE_ID,
            working_CASE_VERSION_ID: this.theCaselinePK.working_CASE_VERSION_ID,
            case_LINE_COMPONENT_ID: this.theCaselinePK.case_LINE_COMPONENT_ID,
            status: theStatus,
            theIpcNumberId: clIpc.theIpcNumberId
          }));
        }
        this.caseUIService.pricingIpcTabData.next(currIpcList);
        this.clcDataList[this._expandedClcIndex].caseLineIpcList = currIpcList;
        this.caseUIService.pricingIpcTabData.next(this.clcDataList[this._expandedClcIndex].caseLineIpcList);
      }
      console.log('after repopulateIPCList', this.clcDataList[this._expandedClcIndex]);
      this.dataSourcePricingTable.data[this._expandedClcIndex].expandIPCPanel = true;
      this.theExpandIPCPanel = this.dataSourcePricingTable.data[this._expandedClcIndex].expandIPCPanel;
      for (let i = 0; i < this.dataSourcePricingTable.data.length; i++) {
        if (i !== this._expandedClcIndex) this.dataSourcePricingTable.data[i].expandIPCPanel = false;
      }
      this.isLoading.next(false);
    },
      err => {
        this.isLoading.next(false);
        CaseUtils.ReportHTTPError(err, "Error obtaining IPC List for Primary Category.");
      });

  }


  private setPublicationCostAm(pClc: caseLineComponentDto, pIndex: number) {
    if (!pClc.publication_CATEGORY_CD ||
      pClc.publication_CATEGORY_CD == "" ||
      !pClc.publication_PAGE_AM ||
      !this.caseLinePricingSummary.price_EFFECTIVE_DT) {
      pClc.component_UNIT_BASE_PRICE_AM = 0;
      pClc.wm_component_UNIT_BASE_PRICE_AM = formatCurrency(pClc.component_UNIT_BASE_PRICE_AM, 'en', '$');
      this.onChangeCaseLineComponent(pIndex);
    }
    else if (pClc.publication_PAGE_AM <= 0) {
      MessageMgr.swalFire({
        title: "Number of pages must be greater than zero.",
        icon: 'error',
        showCancelButton: false,
        cancelButtonText: 'No',
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'OK'
      });
      pClc.component_UNIT_BASE_PRICE_AM = 0;
      pClc.wm_component_UNIT_BASE_PRICE_AM = formatCurrency(pClc.component_UNIT_BASE_PRICE_AM, 'en', '$');
      this.updateClcLine(pClc, false);
      this.onChangeCaseLineComponent(pIndex);
    }
    else {
      this.caseRestService.calculatePublicationCost(pClc.publication_CATEGORY_CD, pClc.publication_PAGE_AM, this.caseLinePricingSummary.price_EFFECTIVE_DT)
        .subscribe((pPublicationCost: number) => {
          let pubAmt: number = 0;
          if (pPublicationCost == -1) {
            MessageMgr.swalFire({
              text: "The Publication Category/Maximum Pages can not be used because the effective date of the line is before the effective date of the Publication Category/Maximum Pages.",
              icon: 'error',
              width: 500,
              showCancelButton: false,
              confirmButtonColor: '#3085d6',
              confirmButtonText: 'OK'
            });
          }
          else {
            pubAmt = pPublicationCost;
          }
          pClc.component_UNIT_BASE_PRICE_AM = pubAmt;
          pClc.wm_component_UNIT_BASE_PRICE_AM = formatCurrency(pubAmt, 'en', '$');
          this.updateClcLine(pClc, false);
          this.onChangeCaseLineComponent(pIndex);
        });
    }
  }

  // Set MTDS Totals.
  private setMtdsTotals(pClc: caseLineComponentDto) {
    pClc.component_UNIT_BASE_PRICE_AM = (!pClc.caseLineCompMtdsPersonTotalAm || isNaN(pClc.caseLineCompMtdsPersonTotalAm) ? 0 : pClc.caseLineCompMtdsPersonTotalAm) +
      (!pClc.caseLineCompMtdsSupprtTotalAm || isNaN(pClc.caseLineCompMtdsSupprtTotalAm) ? 0 : pClc.caseLineCompMtdsSupprtTotalAm) +
      (!pClc.caseLineCompMtdsTravelTotalAm || isNaN(pClc.caseLineCompMtdsTravelTotalAm) ? 0 : pClc.caseLineCompMtdsTravelTotalAm);
    //
    pClc.wm_component_UNIT_BASE_PRICE_AM = formatCurrency(pClc.component_UNIT_BASE_PRICE_AM, 'en', '$');
  }

  // Changte the field values and editability based on the primary category selected.
  private setPCCAmoundsAndEditability(pClc: caseLineComponentDto, pNewBasePriceSourceCd: number, pBasePriceDesc: string, pIndex: number) {
    this.enableControlFields(pBasePriceDesc, pIndex);
    if (pBasePriceDesc == LinePricingComponent.SUPPLEMENTAL_LINE_NOTE) {
      LinePricingUtils.setCaseLineListAttachmentCost(pClc);
    }
    else if (pBasePriceDesc == LinePricingComponent.PUBLICATION) {
      this.setPublicationCostAm(pClc, pIndex);
    }
    else if (pBasePriceDesc == LinePricingComponent.MTDS) {
      this.setMtdsTotals(pClc);
    }
    else if (pBasePriceDesc == LinePricingComponent.REVERSE_CALCULATION) {
      pClc.component_UNIT_BASE_PRICE_AM = null;
    }
    else {
      pClc.component_UNIT_BASE_PRICE_AM = 0;
    }
    pClc.wm_component_UNIT_BASE_PRICE_AM = formatCurrency(pClc.component_UNIT_BASE_PRICE_AM, 'en', '$');
    pClc.base_PRICE_SOURCE_CD = pNewBasePriceSourceCd;
    this.updateClcLine(pClc, false);
    this.caseUIService.supplementalTabSubscription.next(pClc);  // Notify the Supplemental line tab of the change.
    this.onChangeCaseLineComponent(pIndex);
  }

  // Event handler for changing base price source.
  onChangeBASE_PRICE_SOURCE_CD(pBasePriceDesc: string, pIndex: number) {
    let currClc: caseLineComponentDto = this.clcDataList[pIndex];
    const newBasePriceSourceCd: number = +this.getCodeFromDescription(this.basePriceSourceArray, pBasePriceDesc);
    if (CaseUtils.isBlankStr(currClc.base_PRICE_SOURCE_CD)) {
      // Previous value is blank, no need to prompt user.
      this.setPCCAmoundsAndEditability(currClc, newBasePriceSourceCd, pBasePriceDesc, pIndex);
    }
    else {
      MessageMgr.swalFire(
        {
          text: "Changing the base price source may result in a change to the base unit price. Do you want to continue?",
          icon: 'question',
          width: 500,
          showCancelButton: true,
          cancelButtonText: 'No',
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: 'Yes'
        }).then((promptResult) => {
          if (!!promptResult && promptResult.isConfirmed) {
            this.setPCCAmoundsAndEditability(currClc, newBasePriceSourceCd, pBasePriceDesc, pIndex);
          }
          else {
            this.setWm_BASE_PRICE_SOURCE_NM(currClc);
          }
        });
    }
  }

  onChangeCASE_LINE_COMPONENT_QY(pIndex: number) {
    this.clcDataList[pIndex].case_LINE_COMPONENT_QY = +this.fixupInteger(this.clcDataList[pIndex].case_LINE_COMPONENT_QY.toString());
    this.updateClcLine(this.clcDataList[pIndex], false);
    this.onChangeCaseLineComponent(pIndex);
  }

  onChange_UNIT_BASE_PRICE_AM(pValue: string, pIndex: number) {
    this.clcDataList[pIndex].component_UNIT_BASE_PRICE_AM = CaseUtils.unformatCurrency(pValue);
    this.clcDataList[pIndex].wm_component_UNIT_BASE_PRICE_AM = formatCurrency(this.clcDataList[pIndex].component_UNIT_BASE_PRICE_AM, 'en', '$');
    this.updateClcLine(this.clcDataList[pIndex], false);
    this.onChangeCaseLineComponent(pIndex);
  }

  onChangeTARGET_PERCENT_RT(pValue: string, pIndex: number) {
    this.clcDataList[pIndex].target_PERCENT_RT = +(this.fixupNumber(pValue).replace("%", "")) / 100;
    this.clcDataList[pIndex].wm_target_PERCENT_RT = formatPercent(this.clcDataList[pIndex].target_PERCENT_RT, 'en', '1.2-2');
    this.clcDataList[pIndex].wm_target_PERCENT_RT = this.clcDataList[pIndex].wm_target_PERCENT_RT.substring(0, this.clcDataList[pIndex].wm_target_PERCENT_RT.indexOf("%"));
    this.onChangeCaseLineComponent(pIndex);
  }

  onChangePRICE_EFFECTIVE_DT(pValue: string) {
    if (DateValidator.isItADate(pValue)) {
      this.caseLinePricingSummary.price_EFFECTIVE_DT = <Date>CaseUtils.toDate(pValue);
      this.flagToRecalculate();
    }
    else {
      this.caseLinePricingSummary.price_EFFECTIVE_DT = null;
      this.price_EFFECTIVE_DT = null;
      this.price_EFFECTIVE_DT_string = "";
    }
    this.onChangeCaseLine();
  }

  onChangePRICE_EXPIRATION_DT(pValue: string) {
    if (DateValidator.isItADate(pValue)) {
      this.caseLinePricingSummary.price_EXPIRATION_DT = <Date>CaseUtils.toDate(pValue);
    }
    else {
      this.caseLinePricingSummary.price_EXPIRATION_DT = null;
      this.price_EXPIRATION_DT = null;
      this.price_EXPIRATION_DT_string = "";
    }
    this.flagToRecalculate();
    this.onChangeCaseLine();
  }

  /** 
   * Flag the page to recalculate.
   */
  private flagToRecalculate() {
    this.caseLinePricingInfoData.recalculation_IN = true;
  }

  fixupNumber(pValue: string): string {
    return CaseUtils.fixupNumber(pValue);
  }

  fixupInteger(pValue: string): string {
    return CaseUtils.replaceEverythingExceptDigits(pValue);
  }

  onChangeTARGET_COST_AM(pValue: string, pIndex: number) {
    this.clcDataList[pIndex].target_COST_AM = CaseUtils.unformatCurrency(this.fixupNumber(pValue));
    this.clcDataList[pIndex].wm_target_COST_AM = formatCurrency(this.clcDataList[pIndex].target_COST_AM, 'en', '$');
    this.onChangeCaseLineComponent(pIndex);
  }

  onBlurCASE_LINE_ITEM_QY(pValue: string) {
    this.case_LINE_ITEM_QY = +(CaseUtils.fixupNumber(pValue));
    this.case_LINE_ITEM_QY_string = (!pValue || pValue == "" || pValue == "N/A") ? "N/A" : this.case_LINE_ITEM_QY.toString();
    this.caseLinePricingSummary.case_LINE_ITEM_QY = this.case_LINE_ITEM_QY;
    this.caseLinePricingSummary.case_LINE_ITEM_QY_string = this.case_LINE_ITEM_QY_string;
  }

  onChangeCASE_LINE_ITEM_QY(pValue: string) {
    this.case_LINE_ITEM_QY = +(CaseUtils.fixupNumber(pValue));
    this.caseLinePricingInfoData.case_LINE_ITEM_QY = pValue;
    this.case_LINE_ITEM_QY_string = (!pValue || pValue == "" || pValue == "N/A") ? "N/A" : this.case_LINE_ITEM_QY.toString();
    this.caseLinePricingSummary.case_LINE_ITEM_QY = this.case_LINE_ITEM_QY;
    this.caseLinePricingSummary.case_LINE_ITEM_QY_string = this.case_LINE_ITEM_QY_string;
    this.recalculateCaseLineTotals();
    this.flagToRecalculate();
    this.onChangeCaseLine();
  }

  onChangeMTDS_NARRATIVE_DESCRIPTION_TX(pValue: string) {
    if (!pValue || pValue == "" || pValue == "N/A") {
      this.mtds_NARRATIVE_DESCRIPTION_TX_string = "N/A";
      this.caseLinePricingSummary.mtds_NARRATIVE_DESCRIPTION_TX = "";
    }
    else {
      this.mtds_NARRATIVE_DESCRIPTION_TX_string = pValue;
      this.caseLinePricingSummary.mtds_NARRATIVE_DESCRIPTION_TX = pValue;
    }
    this.onChangeCaseLine();
  }

  onFocusCASE_LINE_ITEM_QY() {
    if (this.case_LINE_ITEM_QY_string == "N/A") {
      this.case_LINE_ITEM_QY_string = "";
    }
  }

  // Delete an IPC Line
  private deleteIpcLine(pIpcToDelete: CaseLineIPCDto) {
    if (!this.clcDataList[this._expandedClcIndex].deletedIpcList) {
      this.clcDataList[this._expandedClcIndex].deletedIpcList = [];
    }
    this.clcDataList[this._expandedClcIndex].deletedIpcList.push(pIpcToDelete);
  }

  // Subscribe to changes from other tabs
  subscribeToChangesFromIpcTab() {
    this._ipcTabChangedSubscription = this.caseUIService.ipcTabChanged.subscribe((pIpcList: Array<CaseLineIPCDto>) => {
      if (!!pIpcList) {
        this.clcDataList[this._expandedClcIndex].caseLineIpcList = pIpcList;
        if (!!this.dataSourcePricingTable.data[this._expandedClcIndex]) {
          this.clcDataList[this._expandedClcIndex].component_UNIT_BASE_PRICE_AM = CaseUtils.unformatCurrency(this.dataSourcePricingTable.data[this._expandedClcIndex].wm_component_UNIT_BASE_PRICE_AM);
        }
        this.updateClcLine(this.clcDataList[this._expandedClcIndex], false);
        this.onChangeCaseLineComponent(this._expandedClcIndex);
      }
    });
    // deleted recs
    this._ipcTabDeletedSubscription = this.caseUIService.ipcTabDeleted.subscribe((pDeletedIpc: CaseLineIPCDto) => {
      if (!!pDeletedIpc) {
        this.deleteIpcLine(pDeletedIpc);
        this.onChangeCaseLineComponent(this._expandedClcIndex);
      }
    });
    // Cost Basis subscription
    this._cbTabChangedSubscription = this.caseUIService.cbTabChanged.subscribe((theClc: caseLineComponentModel) => {
      if (!!theClc) {
        this.clcDataList[this._expandedClcIndex].base_FISCAL_YEAR_ID = theClc.base_FISCAL_YEAR_ID;
        this.clcDataList[this._expandedClcIndex].then_FISCAL_YEAR_ID = theClc.then_FISCAL_YEAR_ID;
        this.clcDataList[this._expandedClcIndex].civilian_FISCAL_YEAR_ID = theClc.civilian_FISCAL_YEAR_ID;
        this.clcDataList[this._expandedClcIndex].inflation_FUND_CD = theClc.inflation_FUND_CD;
        this.clcDataList[this._expandedClcIndex].price_YEAR_CD = theClc.price_YEAR_CD;
        this.clcDataList[this._expandedClcIndex].storage_YEAR_AM = theClc.storage_YEAR_AM;
        this.clcDataList[this._expandedClcIndex].storage_MONTH_AM = theClc.storage_MONTH_AM;
        this.clcDataList[this._expandedClcIndex].storage_DAY_AM = theClc.storage_DAY_AM;
        this.onChangeCaseLineComponent(this._expandedClcIndex);
      }
    });
  }

  // Subscribe to changes from supplemental tab.
  private subscribeToChangesFromSuppTab() {
    this._suppTabChangedSubscription = this.caseUIService.suppTabChanged.subscribe((pClc: caseLineComponentDto) => {
      if (!!pClc) {
        this.clcDataList[this._expandedClcIndex].component_TITLE_NM = pClc.component_TITLE_NM;
        this.clcDataList[this._expandedClcIndex].caseLineListAttachmentList = pClc.caseLineListAttachmentList;
        // Update the supplemental tab info.
        let totalAm: number = 0;
        if (!!this.clcDataList[this._expandedClcIndex].caseLineListAttachmentList) {
          for (let currSln of this.clcDataList[this._expandedClcIndex].caseLineListAttachmentList) {
            totalAm = totalAm + currSln.total_COST;
          }
        }
        pClc.component_UNIT_BASE_PRICE_AM = totalAm;
        pClc.wm_component_UNIT_BASE_PRICE_AM = formatCurrency(pClc.component_UNIT_BASE_PRICE_AM, 'en', '$');
        this.updateClcLine(this.clcDataList[this._expandedClcIndex], false);
        this.onChangeCaseLineComponent(this._expandedClcIndex);
      }
    });
    //
    this._suppTabDeletedSubscription = this.caseUIService.suppTabDeleted.subscribe((pDeletedSuppLine: supplementalLineNoteDto) => {
      if (!!pDeletedSuppLine) {
        if (!this.clcDataList[this._expandedClcIndex].deletedAttachmentList) {
          this.clcDataList[this._expandedClcIndex].deletedAttachmentList = [];
        }
        this.clcDataList[this._expandedClcIndex].deletedAttachmentList.push(pDeletedSuppLine);
        this.updateClcLine(this.clcDataList[this._expandedClcIndex], false);
        this.onChangeCaseLineComponent(this._expandedClcIndex);
      }
    });
  }


  // Subscribe to changes from CLC Popups
  private subscribeToChangesFromPopups() {
    this._civPopupSubscription = this.caseUIService.civilianPersonnelChosen.subscribe((pCivilianPersonnelData: caseLineComponentDto) => {
      this.clcDataList[this._popupCivIndex].civilian_FISCAL_YEAR_ID = pCivilianPersonnelData.civilian_FISCAL_YEAR_ID;
      this.clcDataList[this._popupCivIndex].civilian_PAYROLL_CATEGORY_CD = pCivilianPersonnelData.civilian_PAYROLL_CATEGORY_CD;
      this.clcDataList[this._popupCivIndex].civilian_PAYROLL_COST_AM = pCivilianPersonnelData.civilian_PAYROLL_COST_AM;
      this.clcDataList[this._popupCivIndex].component_UNIT_BASE_PRICE_AM = pCivilianPersonnelData.component_UNIT_BASE_PRICE_AM;
      this.dataSourcePricingTable.data[this._popupCivIndex].civilian_FISCAL_YEAR_ID = pCivilianPersonnelData.civilian_FISCAL_YEAR_ID;
      this.dataSourcePricingTable.data[this._popupCivIndex].civilian_PAYROLL_CATEGORY_CD = pCivilianPersonnelData.civilian_PAYROLL_CATEGORY_CD;
      this.dataSourcePricingTable.data[this._popupCivIndex].civilian_PAYROLL_COST_AM = pCivilianPersonnelData.civilian_PAYROLL_COST_AM;
      this.dataSourcePricingTable.data[this._popupCivIndex].component_UNIT_BASE_PRICE_AM = pCivilianPersonnelData.component_UNIT_BASE_PRICE_AM;
      this.updateClcLine(this.clcDataList[this._popupCivIndex], false);
      this.onChangeCaseLineComponent(this._popupCivIndex);
    });

    this._dtcDataChangedSubscription = this.caseUIService.dtcDataChanged.subscribe((pDtcList: Array<CASE_LINE_COMP_DEL_TERM>) => {
      if (!!pDtcList) {
        this.clcDataList[this._popupDtcIndex].caseLineCompDelTermList = pDtcList;
        this.onChangeCaseLineComponent(this._popupDtcIndex);
      }
    });

    this._pubPopupSubscription = this.caseUIService.publicationInfoChosen.subscribe((pPubValues: any) => {
      if (!!pPubValues) {
        this.clcDataList[this._popupPubIndex].publication_CATEGORY_CD = pPubValues.publication_CATEGORY_CD;
        this.clcDataList[this._popupPubIndex].publication_PAGE_AM = pPubValues.publication_PAGE_AM;
        this.setPublicationCostAm(this.clcDataList[this._popupPubIndex], this._popupPubIndex);
        this.onChangeCaseLineComponent(this._popupPubIndex);
      }
    });

    this._mtdsPopupSubscription = this.caseUIService.mtdsInfoChosen.subscribe((pCaseLineComponentFromMtds: caseLineComponentDto) => {
      if (!!pCaseLineComponentFromMtds) {
        const currClc: caseLineComponentDto = this.clcDataList[this._popupMtdsIndex];
        currClc.caseLineCompMtdsPersonList = pCaseLineComponentFromMtds.caseLineCompMtdsPersonList;
        currClc.caseLineCompMtdsSupprtList = pCaseLineComponentFromMtds.caseLineCompMtdsSupprtList;
        currClc.caseLineCompMtdsTravelList = pCaseLineComponentFromMtds.caseLineCompMtdsTravelList;
        currClc.deletedCaseLineCompMtdsPersonList = pCaseLineComponentFromMtds.deletedCaseLineCompMtdsPersonList;
        currClc.deletedCaseLineCompMtdsSupportList = pCaseLineComponentFromMtds.deletedCaseLineCompMtdsSupportList;
        currClc.deletedCaseLineCompMtdsTravelList = pCaseLineComponentFromMtds.deletedCaseLineCompMtdsTravelList;
        // Append Deleted lists.
        // Don't just copy because otherwise if they come back into the MTDS window, they would lose what they deleted before.
        if (!currClc.deletedCaseLineCompMtdsPersonList) {
          currClc.deletedCaseLineCompMtdsPersonList = [];
        }
        if (!currClc.deletedCaseLineCompMtdsSupportList) {
          currClc.deletedCaseLineCompMtdsSupportList = [];
        }
        if (!currClc.deletedCaseLineCompMtdsTravelList) {
          currClc.deletedCaseLineCompMtdsTravelList = [];
        }
        if (!!pCaseLineComponentFromMtds.deletedCaseLineCompMtdsPersonList) {
          pCaseLineComponentFromMtds.deletedCaseLineCompMtdsPersonList.forEach(eachRow => { currClc.deletedCaseLineCompMtdsPersonList.push(eachRow) });
        }
        if (!!pCaseLineComponentFromMtds.deletedCaseLineCompMtdsSupportList) {
          pCaseLineComponentFromMtds.deletedCaseLineCompMtdsSupportList.forEach(eachRow => { currClc.deletedCaseLineCompMtdsSupportList.push(eachRow) });
        }
        if (!!pCaseLineComponentFromMtds.deletedCaseLineCompMtdsTravelList) {
          pCaseLineComponentFromMtds.deletedCaseLineCompMtdsTravelList.forEach(eachRow => { currClc.deletedCaseLineCompMtdsTravelList.push(eachRow) });
        }
        //
        // Update the base unit price based on the totals of the three MTDS areas.
        //
        currClc.caseLineCompMtdsPersonTotalAm = pCaseLineComponentFromMtds.caseLineCompMtdsPersonTotalAm;
        currClc.caseLineCompMtdsSupprtTotalAm = pCaseLineComponentFromMtds.caseLineCompMtdsSupprtTotalAm;
        currClc.caseLineCompMtdsTravelTotalAm = pCaseLineComponentFromMtds.caseLineCompMtdsTravelTotalAm;
        this.setMtdsTotals(currClc);
        this.updateClcLine(currClc, false);
        this.onChangeCaseLineComponent(this._popupMtdsIndex);
      }
    });
  }

  // Recalculate Case Line Totals 
  private recalculateCaseLineTotals() {
    this.caseLinePricingSummary.total_ABOVE_LINE_COST_AM = this.caseLinePricingSummary.case_LINE_ITEM_QY * this.caseLinePricingSummary.unit_ABOVE_LINE_COST_AM;
    this.caseLinePricingSummary.total_ABOVE_LINE_COST_AM = this.caseLinePricingSummary.unit_ABOVE_LINE_COST_AM * (!this.case_LINE_ITEM_QY ? 1 : this.case_LINE_ITEM_QY);
    this.total_ABOVE_LINE_COST_AM = this.caseLinePricingSummary.total_ABOVE_LINE_COST_AM;
    this.caseLinePricingSummary.total_LINE_VALUE_AM = this.caseLinePricingSummary.total_ABOVE_LINE_COST_AM + (!this.total_BELOW_LINE_COST_AM ? 0 : this.total_BELOW_LINE_COST_AM);
    this.total_LINE_VALUE_AM = this.caseLinePricingSummary.total_LINE_VALUE_AM;
    this.setTotal_ABOVE_LINE_COST_AM();
    this.updateCaseLineTotals();
  }

  // Update the Case Line totals
  private updateCaseLineTotals() {
    this.case_LINE_ITEM_QY = this.caseLinePricingSummary.case_LINE_ITEM_QY;
    if (!this.case_LINE_ITEM_QY_string || this.case_LINE_ITEM_QY_string == "") {
      this.case_LINE_ITEM_QY_string = this.caseLinePricingSummary.case_LINE_ITEM_QY_string;
    }
    // Convert to N/A if $0
    if (this.caseLinePricingSummary.target_TOTAL_LINE_AM === 0) {
      this.target_TOTAL_LINE_AM_string = 'N/A'
    }
    else {
      this.target_TOTAL_LINE_AM_string = this.currencyPipe.transform(this.caseLinePricingSummary.target_TOTAL_LINE_AM, 'USD', 'symbol-narrow', '1.0-0', 'en-US');
    }
    // Convert to N/A if $0
    if (this.caseLinePricingSummary.unit_ABOVE_LINE_COST_AM === 0) {
      this.unit_ABOVE_LINE_COST_AM_string = 'N/A'
    }
    else {
      this.unit_ABOVE_LINE_COST_AM_string = formatCurrency(this.caseLinePricingSummary.unit_ABOVE_LINE_COST_AM, 'en', '$');
    }
    // Convert to N/A if $0
    if (this.caseLinePricingSummary.total_LINE_VALUE_AM === 0) {
      this.total_LINE_VALUE_AM_string = 'N/A'
    }
    else {
      this.total_LINE_VALUE_AM_string = formatCurrency(this.caseLinePricingSummary.total_LINE_VALUE_AM, 'en', '$');
    }
    this.totalInWorkAm_string = formatCurrency(this.caseLinePricingSummary.totalInWorkAm, 'en', '$');
  }

  // Update the totals
  private updateClcTotals() {
    if (!!this.clcDataList) {
      for (let currClc of this.clcDataList) {
        this.updateClcTotal(currClc);
      }
    }
  }


  private setWm_BASE_PRICE_SOURCE_NM(pClc: caseLineComponentDto) {
    switch (pClc.base_PRICE_SOURCE_CD) {
      case 1: pClc.wm_base_PRICE_SOURCE_NM = LinePricingComponent.USER_ENTERED; break;
      case 2: pClc.wm_base_PRICE_SOURCE_NM = LinePricingComponent.SUPPLEMENTAL_LINE_NOTE; break;
      case 3: pClc.wm_base_PRICE_SOURCE_NM = LinePricingComponent.PUBLICATION; break;
      case 4: pClc.wm_base_PRICE_SOURCE_NM = LinePricingComponent.CIVILIAN_PERSONNEL; break;
      case 5: pClc.wm_base_PRICE_SOURCE_NM = LinePricingComponent.REVERSE_CALCULATION; break;
      case 7: pClc.wm_base_PRICE_SOURCE_NM = LinePricingComponent.MTDS; break;
    }
  }


  private updateClcTotal(pClc: caseLineComponentDto) {
    pClc.iconImg = "arrow_drop_down";
    pClc.expandIPCPanel = false;
    this.setWm_BASE_PRICE_SOURCE_NM(pClc);
    pClc.wm_component_UNIT_BASE_PRICE_AM = formatCurrency(pClc.component_UNIT_BASE_PRICE_AM, 'en', '$');
    pClc.wm_target_PERCENT_RT = formatPercent(pClc.target_PERCENT_RT, 'en', '1.2-2');
    pClc.wm_target_PERCENT_RT = pClc.wm_target_PERCENT_RT.substring(0, pClc.wm_target_PERCENT_RT.indexOf("%"));
    pClc.wm_target_COST_AM = formatCurrency(pClc.target_COST_AM, 'en', '$');
    pClc.wm_above_LINE_COST = formatCurrency(pClc.above_LINE_COST, 'en', '$');
    pClc.wm_total_COST = formatCurrency(pClc.total_COST, 'en', '$');
  }


  // Do we have a case_line_item_qty or is it N/A?
  private doWeHaveCaseLineItemQy() {
    return !(!this.case_LINE_ITEM_QY_string || this.case_LINE_ITEM_QY_string == "" || this.case_LINE_ITEM_QY_string == "N/A");
  }


  // Update the case line component totals.
  private updateClcLine(pClc: caseLineComponentDto, pTakeFromDatabase: boolean) {
    let totalUalc: number = 0;
    let totalUblc: number = 0;
    if (!!pClc) {   // If null CLC then there are no CLC-s left.
      LinePricingUtils.setClcTotalAmounts(pClc);
      this.updateClcTotal(pClc);
      for (let currClc of this.clcDataList) {
        totalUalc = totalUalc + currClc.above_LINE_COST;
        totalUblc = totalUblc + currClc.below_LINE_COST;
      }
    }
    if (this.doWeHaveCaseLineItemQy()) {
      this.caseLinePricingSummary.unit_ABOVE_LINE_COST_AM = totalUalc;
      this.unit_ABOVE_LINE_COST_AM = totalUalc;
      this.unit_BELOW_LINE_COST_AM = totalUblc;
      if (!pTakeFromDatabase) {
        this.caseLinePricingSummary.total_ABOVE_LINE_COST_AM = totalUalc * this.case_LINE_ITEM_QY;
      }
      this.total_ABOVE_LINE_COST_AM = this.caseLinePricingSummary.total_ABOVE_LINE_COST_AM;
      this.total_BELOW_LINE_COST_AM = totalUblc * this.case_LINE_ITEM_QY;
    }
    else {
      this.caseLinePricingSummary.unit_ABOVE_LINE_COST_AM = 0;
      this.unit_ABOVE_LINE_COST_AM = 0;
      this.unit_BELOW_LINE_COST_AM = 0;
      if (!pTakeFromDatabase) {
        this.caseLinePricingSummary.total_ABOVE_LINE_COST_AM = totalUalc;
      }
      this.total_ABOVE_LINE_COST_AM = totalUalc;
      this.total_BELOW_LINE_COST_AM = totalUblc;
    }
    this.caseLinePricingSummary.total_LINE_VALUE_AM = this.caseLinePricingSummary.total_ABOVE_LINE_COST_AM + this.total_BELOW_LINE_COST_AM;
    this.total_LINE_VALUE_AM = this.caseLinePricingSummary.total_LINE_VALUE_AM;
    this.setTotal_ABOVE_LINE_COST_AM();
    this.updateCaseLineTotals();
  }

  //breakout logic per sonarqube rule
  setupPreSaveData() {
    //DH: attach the caseLineDeliveryTermList only for now
    this.caseLinePricingSummary.caseLineDeliveryTermList = this.caseLinePricingInfoData.caseLineDeliveryTermList;
    //DH: add the precision cost indicator
    this.caseLinePricingSummary.precision_UNIT_COST_PRICING_IN = true;

    this.caseLinePricingSummary.recalculation_IN = this.caseLinePricingInfoData.recalculation_IN;
    for (let delClc of this.delClcDataList) {
      if (!!delClc.case_LINE_COMPONENT_ID && delClc.case_LINE_COMPONENT_ID > 0) {
        this.caseLinePricingSummary.caseLineComponentList.push(Object.assign(delClc, { status: DsamsConstants.ENT_DELETED }));
      }
    }
  }
  //breakout logic per sonarqube rule
  setupPreSaveIPCData(currClc: caseLineComponentDto) {
    // DTC-s:
    if (!currClc.caseLineCompDelTermList) {
      currClc.caseLineCompDelTermList = [];
    }
    if (!currClc.deletedIpcList) {
      currClc.deletedIpcList = [];
    }
    if (!currClc.caseLineIpcList) {
      currClc.caseLineIpcList = [];
    }
    else {
      for (let currIpc of currClc.caseLineIpcList) {
        currIpc.case_ID = this.caseLinePricingSummary.case_ID;
        currIpc.case_MASTER_LINE_ID = this.caseLinePricingSummary.case_MASTER_LINE_ID;
        currIpc.working_CASE_ID = this.caseLinePricingSummary.working_CASE_ID;
        currIpc.working_CASE_VERSION_ID = this.caseLinePricingSummary.working_CASE_VERSION_ID;
        currIpc.case_LINE_COMPONENT_ID = currClc.case_LINE_COMPONENT_ID;
        if (!!currIpc.wm_CASE_LINE_IPC_PERCENT_RT && currIpc.wm_CASE_LINE_IPC_PERCENT_RT != "") {
          currIpc.case_LINE_IPC_PERCENT_RT = (parseFloat(currIpc.wm_CASE_LINE_IPC_PERCENT_RT)).toString();
        }
        // Set status to 3 if no IPC.
        if (currIpc.ipc_NUMBER_ID == "") {
          currIpc.status = DsamsConstants.ENT_DELETED.toString();
        }
      }
    }
  }

  //breakout logic per sonarqube rule
  setupPreSaveDeletedIPCData(currClc: caseLineComponentDto) {
    // Deleted IPCs
    for (let delIpc of currClc.deletedIpcList) {
      currClc.caseLineIpcList.push(Object.assign(delIpc,
        {
          case_ID: this.caseLinePricingSummary.case_ID,
          case_MASTER_LINE_ID: this.caseLinePricingSummary.case_MASTER_LINE_ID,
          working_CASE_ID: this.caseLinePricingSummary.working_CASE_ID,
          working_CASE_VERSION_ID: this.caseLinePricingSummary.working_CASE_VERSION_ID,
          case_LINE_COMPONENT_ID: currClc.case_LINE_COMPONENT_ID,
          status: DsamsConstants.ENT_DELETED,
          theIpcNumberId: delIpc.theIpcNumberId
        }
      ));
    }
    currClc.deletedIpcList = [];
  }

  //breakout logic per sonarqube rule
  setupPreSaveSupData(currClc: caseLineComponentDto) {
    if (!currClc.deletedAttachmentList) {
      currClc.deletedAttachmentList = [];
    }
    // Current Supps
    if (!currClc.caseLineListAttachmentList) {
      currClc.caseLineListAttachmentList = [];
    }
    else {
      for (let currSupp of currClc.caseLineListAttachmentList) {
        currSupp.case_ID = this.caseLinePricingSummary.case_ID;
        currSupp.case_MASTER_LINE_ID = this.caseLinePricingSummary.case_MASTER_LINE_ID;
        currSupp.working_CASE_ID = this.caseLinePricingSummary.working_CASE_ID;
        currSupp.working_CASE_VERSION_ID = this.caseLinePricingSummary.working_CASE_VERSION_ID;
        currSupp.case_LINE_COMPONENT_ID = currClc.case_LINE_COMPONENT_ID;
      }
    }
  }

  //breakout logic per sonarqube rule
  setupPreSaveDeletedSupData(currClc: caseLineComponentDto) {
    for (let delSupp of currClc.deletedAttachmentList) {
      if (!!delSupp.case_LINE_LIST_ATTACHMENT_ID && delSupp.case_LINE_LIST_ATTACHMENT_ID > 0) {
        const delSupplementalLineNoteDto: supplementalLineNoteDto = Object.assign(delSupp,
          {
            case_ID: this.caseLinePricingSummary.case_ID,
            case_MASTER_LINE_ID: this.caseLinePricingSummary.case_MASTER_LINE_ID,
            working_CASE_ID: this.caseLinePricingSummary.working_CASE_ID,
            working_CASE_VERSION_ID: this.caseLinePricingSummary.working_CASE_VERSION_ID,
            case_LINE_COMPONENT_ID: currClc.case_LINE_COMPONENT_ID,
            status: DsamsConstants.ENT_DELETED
          }
        )
        currClc.caseLineListAttachmentList.push(delSupplementalLineNoteDto);
        if (!this._globalDeletedAttachmentList) {
          this._globalDeletedAttachmentList = [];
        }
        this._globalDeletedAttachmentList.push(delSupplementalLineNoteDto);
      }
    }
  }
  //breakout logic per sonarqube rule
  setupPreSaveDeletedMTDSPersonnelData(currClc: caseLineComponentDto) {
    if (!!currClc.deletedCaseLineCompMtdsPersonList) {
      for (let delMtdsPersonnel of currClc.deletedCaseLineCompMtdsPersonList) {
        if (!!delMtdsPersonnel.case_LINE_MTDS_PERSON_ID && delMtdsPersonnel.case_LINE_MTDS_PERSON_ID > 0) {
          const delMtddPerson: mtdsPersonnelModel = Object.assign(delMtdsPersonnel,
            {
              case_ID: this.caseLinePricingSummary.case_ID,
              case_MASTER_LINE_ID: this.caseLinePricingSummary.case_MASTER_LINE_ID,
              working_CASE_ID: this.caseLinePricingSummary.working_CASE_ID,
              working_CASE_VERSION_ID: this.caseLinePricingSummary.working_CASE_VERSION_ID,
              case_LINE_COMPONENT_ID: currClc.case_LINE_COMPONENT_ID,
              status: DsamsConstants.ENT_DELETED
            });
          currClc.caseLineCompMtdsPersonList.push(delMtddPerson);
          if (!this._globalDeletedMtdsPersonnelList) {
            this._globalDeletedMtdsPersonnelList = [];
          }
          this._globalDeletedMtdsPersonnelList.push(delMtddPerson);
        }
      }
    }
  }
  //breakout logic per sonarqube rule
  setupPreSaveDeletedMTDSSuppportData(currClc: caseLineComponentDto) {
    if (!!currClc.deletedCaseLineCompMtdsSupportList) {
      for (let delMtdsSupport of currClc.deletedCaseLineCompMtdsSupportList) {
        if (!!delMtdsSupport.case_LINE_MTDS_SUPPORT_ID && delMtdsSupport.case_LINE_MTDS_SUPPORT_ID > 0) {
          const delMtdsSupp: mtdsPersonnelModel = Object.assign(delMtdsSupport,
            {
              case_ID: this.caseLinePricingSummary.case_ID,
              case_MASTER_LINE_ID: this.caseLinePricingSummary.case_MASTER_LINE_ID,
              working_CASE_ID: this.caseLinePricingSummary.working_CASE_ID,
              working_CASE_VERSION_ID: this.caseLinePricingSummary.working_CASE_VERSION_ID,
              case_LINE_COMPONENT_ID: currClc.case_LINE_COMPONENT_ID,
              status: DsamsConstants.ENT_DELETED
            });
          currClc.caseLineCompMtdsSupprtList.push(delMtdsSupp);
          if (!this._globalDeletedMtdsSupportList) {
            this._globalDeletedMtdsSupportList = [];
          }
          this._globalDeletedMtdsSupportList.push(delMtdsSupp);
        }
      }
    }
  }
  //breakout logic per sonarqube rule
  setupPreSaveDeletedMTDSTravelData(currClc: caseLineComponentDto) {
    if (!!currClc.deletedCaseLineCompMtdsTravelList) {
      for (let delMtdsTravel of currClc.deletedCaseLineCompMtdsTravelList) {
        if (!!delMtdsTravel.case_LINE_MTDS_TRAVEL_ID && delMtdsTravel.case_LINE_MTDS_TRAVEL_ID > 0) {
          const delMtdsTrvl: mtdsPersonnelModel = Object.assign(delMtdsTravel,
            {
              case_ID: this.caseLinePricingSummary.case_ID,
              case_MASTER_LINE_ID: this.caseLinePricingSummary.case_MASTER_LINE_ID,
              working_CASE_ID: this.caseLinePricingSummary.working_CASE_ID,
              working_CASE_VERSION_ID: this.caseLinePricingSummary.working_CASE_VERSION_ID,
              case_LINE_COMPONENT_ID: currClc.case_LINE_COMPONENT_ID,
              status: DsamsConstants.ENT_DELETED
            });
          currClc.caseLineCompMtdsTravelList.push(delMtdsTrvl);
          if (!this._globalDeletedMtdsTravelList) {
            this._globalDeletedMtdsTravelList = [];
          }
          this._globalDeletedMtdsTravelList.push(delMtdsTrvl);
        }
      }
    }
  }
  // Pre-Save activities.
  private preSave() {
    // If we're coming back from a financial check prompt, no need to run pre-save.
    if (!this._promptFinancialCheck) {
      return;
    }
    this.setupPreSaveData();
    // IPC-s
    // Need to use a for-loop instead of a let loop because otherwise sometimes attributes get lost.
    for (let i = 0; i < this.caseLinePricingSummary.caseLineComponentList.length; i++) {
      let currClc: caseLineComponentDto = this.caseLinePricingSummary.caseLineComponentList[i];
      this.setupPreSaveIPCData(currClc);
      this.setupPreSaveDeletedIPCData(currClc);
      // Supplementals
      this.setupPreSaveSupData(currClc);
      // Deleted Supps  
      this.setupPreSaveDeletedSupData(currClc);
      // Deleted MTDS Personnel
      this.setupPreSaveDeletedMTDSPersonnelData(currClc);
      // Deleted MTDS Suppport
      this.setupPreSaveDeletedMTDSSuppportData(currClc);
      // Deleted MTDS Travel
      this.setupPreSaveDeletedMTDSTravelData(currClc);
    }
  }

  //dsams-5454 - copy the logic from line details
  // begin DSAMS-5983 09/22 DB no longer needed
  // unLock(lockSessionId: number) {
  //   if (lockSessionId > 0) {
  //     this.caseRestService.unLock(lockSessionId, sessionStorage.getItem('serviceDBid'))
  //       .subscribe(
  //         data => {
  //           console.log("### unLock: " + data);
  //           sessionStorage.setItem(LineDetailsComponent.LOCK_SESSION_ID, "0");
  //         },
  //         err => {
  //           console.log("Error occured: unLock()", err)
  //         }
  //       );
  //   }
  // }
  // unlockCaseLineEntity() {
  //   this.unLock(this.getCaseLineLockSessionId());
  // }

  // getCaseLineLockSessionId(): number {
  //   let lockId: string = sessionStorage.getItem(LineDetailsComponent.LOCK_SESSION_ID);
  //   if (lockId == null) {
  //     lockId = "0";
  //     sessionStorage.setItem(LineDetailsComponent.LOCK_SESSION_ID, lockId);
  //   }
  //   return parseInt(lockId);
  // }

  // Post-save activities.
  private postSave() {
    this.caseLinePricingSummary.status = DsamsConstants.ENT_UNCHANGED;
    this.caseLinePricingInfoData.recalculation_IN = false;
    // Reset old expiration dt.
    this.caseLinePricingSummary.old_PRICE_EXPIRATION_DT = !this.caseLinePricingSummary.price_EXPIRATION_DT ? DsamsConstants.DUMMY_DATE : this.caseLinePricingSummary.price_EXPIRATION_DT;
    // Set all statusii to unchanged.
    if (!!this.caseLinePricingSummary.caseLineComponentList) {
      // Filter out the CLC-s that are in the deleted list.
      this.caseLinePricingSummary.caseLineComponentList = this.caseLinePricingSummary.caseLineComponentList.filter(
        elem => {
          if (!!this.delClcDataList) {
            for (let delClc of this.delClcDataList) {
              if (delClc.case_LINE_COMPONENT_ID == elem.case_LINE_COMPONENT_ID) {
                return false;
              }
            }
          }
          return true;
        }
      );
      for (let currClc of this.caseLinePricingSummary.caseLineComponentList) {
        currClc.status = DsamsConstants.ENT_UNCHANGED.toString();
        // CLCDT Recs
        let clcDtArr: Array<CASE_LINE_COMP_DEL_TERM> = currClc.caseLineCompDelTermList;
        if (!!clcDtArr) {
          clcDtArr.forEach(eachCldt => {
            eachCldt.status = DsamsConstants.ENT_UNCHANGED;
            eachCldt.delivery_TERM_RT = eachCldt.delivery_TERM_RT * 100;
          });
        }
        currClc.caseLineCompDelTermList = clcDtArr;

        // Case Line IPC Recs
        let ipcArr: Array<CaseLineIPCDto> = currClc.caseLineIpcList;
        if (!!ipcArr) {
          ipcArr = ipcArr.filter(elem => { return elem.status != DsamsConstants.ENT_DELETED.toString(); });
          for (let currIpc of ipcArr) {
            currIpc.status = DsamsConstants.ENT_UNCHANGED.toString();
            currIpc.wm_OLD_IPC_NUMBER_ID = currIpc.ipc_NUMBER_ID;
          }
        }
        currClc.deletedIpcList = [];
        currClc.caseLineIpcList = ipcArr;

        // Case Line Supplemental Recs
        let suppArr: Array<supplementalLineNoteDto> = currClc.caseLineListAttachmentList;
        if (!!suppArr) {
          suppArr = suppArr.filter(elem => {
            if (!!this._globalDeletedAttachmentList) {
              for (let delSupp of this._globalDeletedAttachmentList) {
                if (delSupp.case_LINE_COMPONENT_ID == elem.case_LINE_COMPONENT_ID &&
                  delSupp.case_LINE_LIST_ATTACHMENT_ID == elem.case_LINE_LIST_ATTACHMENT_ID) {
                  return false;
                }
              }
            }
            return true;
          });
          for (let currSupp of suppArr) {
            currSupp.status = DsamsConstants.ENT_UNCHANGED.toString();
          }
          currClc.caseLineListAttachmentList = suppArr;
        }
        currClc.deletedAttachmentList = [];
        // MTDS Personnel List
        let mtdsPersonArray: Array<mtdsPersonnelModel> = currClc.caseLineCompMtdsPersonList;
        if (!!mtdsPersonArray) {
          mtdsPersonArray = mtdsPersonArray.filter(elem => {
            if (!!this._globalDeletedMtdsPersonnelList) {
              for (let delItem of this._globalDeletedMtdsPersonnelList) {
                if (delItem.case_LINE_COMPONENT_ID == elem.case_LINE_COMPONENT_ID &&
                  delItem.case_LINE_MTDS_PERSON_ID == elem.case_LINE_MTDS_PERSON_ID) {
                  return false;
                }
              }
            }
            return true;
          });
          for (let currItem of mtdsPersonArray) {
            currItem.status = DsamsConstants.ENT_UNCHANGED.toString();
          }
        }
        currClc.deletedCaseLineCompMtdsPersonList = [];
        currClc.caseLineCompMtdsPersonList = mtdsPersonArray;

        // MTDS Support List
        let mtdsSupportArray: Array<mtdsPersonnelSupportCostsModel> = currClc.caseLineCompMtdsSupprtList;
        if (!!mtdsSupportArray) {
          mtdsSupportArray = mtdsSupportArray.filter(elem => {
            if (!!this._globalDeletedMtdsSupportList) {
              for (let delItem of this._globalDeletedMtdsSupportList) {
                if (delItem.case_LINE_COMPONENT_ID == elem.case_LINE_COMPONENT_ID &&
                  delItem.case_LINE_MTDS_SUPPORT_ID == elem.case_LINE_MTDS_SUPPORT_ID) {
                  return false;
                }
              }
            }
            return true;
          });
          for (let currItem of mtdsSupportArray) {
            currItem.status = DsamsConstants.ENT_UNCHANGED.toString();
          }
        }
        currClc.deletedCaseLineCompMtdsSupportList = [];
        currClc.caseLineCompMtdsSupprtList = mtdsSupportArray;

        // MTDS Travel List
        let mtdsTravelArray: Array<mtdsTravelModel> = currClc.caseLineCompMtdsTravelList;
        if (!!mtdsTravelArray) {
          mtdsTravelArray = mtdsTravelArray.filter(elem => {
            if (!!this._globalDeletedMtdsTravelList) {
              for (let delItem of this._globalDeletedMtdsTravelList) {
                if (delItem.case_LINE_COMPONENT_ID == elem.case_LINE_COMPONENT_ID &&
                  delItem.case_LINE_MTDS_TRAVEL_ID == elem.case_LINE_MTDS_TRAVEL_ID) {
                  return false;
                }
              }
            }
            return true;
          });
          for (let currItem of mtdsTravelArray) {
            currItem.status = DsamsConstants.ENT_UNCHANGED.toString();
          }
        }
        this.populateDatabaseIpcList(currClc);
        currClc.deletedCaseLineCompMtdsTravelList = [];
        currClc.caseLineCompMtdsTravelList = mtdsTravelArray;
        currClc.primaryCategoryChanged = false;
      }
    }
    this.clcDataList = this.caseLinePricingSummary.caseLineComponentList;
    this.delClcDataList = [];
    this._globalDeletedAttachmentList = [];
    this._globalDeletedMtdsPersonnelList = [];
    this._globalDeletedMtdsSupportList = [];
    this._globalDeletedMtdsTravelList = [];
    this._globalDeletedAttachmentList = [];
    // CLFD: If this is null, set to an empty array.
    // I verified that it is not null when there are rows.
    if (!this.caseLinePricingSummary.caseLineFiscalDistributionCaseCaseLineList) {
      this.caseLinePricingSummary.caseLineFiscalDistributionCaseCaseLineList = [];
    }
    // Notify other panels that this has been saved.
    if (this._expandedClcIndex >= 0 && !!this.clcDataList) {
      this.caseUIService.pricingPostSave.next(this.clcDataList[this._expandedClcIndex]);
    }
    this.updateCaseLineTotals();
    this.updateClcTotals();
    //******************* testing only
    console.log(this.clcDataList);
    this.dataSourcePricingTable = new MatTableDataSource<caseLineComponentDto>(this.clcDataList);
    if (this._expandedClcIndex >= 0) {
      if (!!this.dataSourcePricingTable.data && !!this.dataSourcePricingTable.data[this._expandedClcIndex]) {
        this.dataSourcePricingTable.data[this._expandedClcIndex].expandIPCPanel = true;
      }
    }
    if (!!this.case_LINE_ITEM_QY_string) {
      this.caseLinePricingSummary.case_LINE_ITEM_QY_string = this.case_LINE_ITEM_QY_string;
    }
    this.resetRelatedCalCostsFields(true);
    this.dataSourcePricingTable._updateChangeSubscription();
    this.caseLinePricingInfoData.isPricingDataChanged = false;
  }

  //breakout logic per sonarqube rule
  postSaveAfterErrorForList() {
    this.caseLinePricingSummary.caseLineComponentList.forEach(eachClc => {
      if (!!eachClc.caseLineIpcList) {
        eachClc.caseLineIpcList = eachClc.caseLineIpcList.filter(elem => elem.status != DsamsConstants.ENT_DELETED.toString());
        eachClc.caseLineIpcList.forEach(eachIpc => {
          if (!!eachIpc.wm_CASE_LINE_IPC_PERCENT_RT && eachIpc.wm_CASE_LINE_IPC_PERCENT_RT != "") {
            eachIpc.case_LINE_IPC_PERCENT_RT = (parseFloat(eachIpc.wm_CASE_LINE_IPC_PERCENT_RT) / 100).toString();
          }
        });
      }
      if (!!eachClc.caseLineListAttachmentList) {
        eachClc.caseLineListAttachmentList = eachClc.caseLineListAttachmentList.filter(elem => elem.status != DsamsConstants.ENT_DELETED.toString());
      }
      if (!!eachClc.caseLineCompMtdsSupprtList) {
        eachClc.caseLineCompMtdsSupprtList = eachClc.caseLineCompMtdsSupprtList.filter(elem => elem.status != DsamsConstants.ENT_DELETED.toString());
      }
      if (!!eachClc.caseLineCompMtdsTravelList) {
        eachClc.caseLineCompMtdsTravelList = eachClc.caseLineCompMtdsTravelList.filter(elem => elem.status != DsamsConstants.ENT_DELETED.toString());
      }
      if (!!eachClc.caseLineCompMtdsPersonList) {
        eachClc.caseLineCompMtdsPersonList = eachClc.caseLineCompMtdsPersonList.filter(elem => elem.status != DsamsConstants.ENT_DELETED.toString());
      }
    });
    this.clcDataList = this.caseLinePricingSummary.caseLineComponentList;
  }

  /**
   * Post-save after an error. Only partially reset fields (unlike in the regular postSave, which does everything).
   */
  private postSaveAfterError() {
    if (!!this.caseLinePricingSummary.caseLineComponentList) {
      // Parse out the recs with status=3 (deleted) so they don't reappear after you re-add following a failed save.
      this.caseLinePricingSummary.caseLineComponentList = this.caseLinePricingSummary.caseLineComponentList.filter(elem => elem.status != DsamsConstants.ENT_DELETED.toString());
      this.postSaveAfterErrorForList();
      this.clcDataList = this.caseLinePricingSummary.caseLineComponentList;
      // Notify other panels to refresh their data.
      if (this._expandedClcIndex >= 0 && !!this.clcDataList && !!this.delClcDataList) {
        if (this.delClcDataList.length > 0)
          this.caseUIService.pricingPostSave.next(this.clcDataList[this._expandedClcIndex]);
      }
    }
    const editResponse: IEditResponseType = {
      ID: DsamsConstants.CASE_LINE_EDITOR,
      editToggle: true
    };
    this.caseUIService.caseEditService.next(editResponse);
    this.isPanelEditable = true;
    this.caseLinePricingInfoData.isPricingDataChanged = true;

    if (this.isPanelEditable) this.setBasePriceSourceState(false);
    else this.setBasePriceSourceState(true);
    this.caseLinePricingInfoData.recalculation_IN = true;
    //reload the PCC list since the list entity has been cleared of deleted entities
    this.dataSourcePricingTable = new MatTableDataSource<caseLineComponentDto>(this.clcDataList);
    this.dataSourcePricingTable._updateChangeSubscription();
    // Notify other panels that this has been saved.
    if (this._expandedClcIndex >= 0 && !!this.clcDataList) {
      this.caseUIService.pricingPostSave.next(this.clcDataList[this._expandedClcIndex]);
    }
  }

  // Toggle the save button.
  private toggleSaveButton(pEnable: boolean) {
    this.isLoading.next(!pEnable);
    this.isSaveButtonDisabled = !pEnable;
  }

  // Check if data is saved.
  private checkDataChanged(): boolean {
    if (!this.caseLinePricingInfoData.isPricingDataChanged) {
      MessageMgr.swalFire({
        text: 'No changes to save.',
        icon: 'info',
        width: 350,
        showCancelButton: false,
        confirmButtonColor: '#3085d6',
        confirmButtonText: 'OK'
      });
      return false;
    }
    return true;
  }
  
  // Save button on-click.
  saveButtonOnClick() {
    if (this.checkDataChanged()) {
      this.toggleSaveButton(false);
      // Validate non-back-end fields.
      this.caseLinePricingSummary.caseLineComponentList = !this.clcDataList ? [] : this.clcDataList;
      this.caseLinePricingSummary.case_LINE_ITEM_QY_string = this.case_LINE_ITEM_QY_string;
      if (this._promptFinancialCheck && !LinePricingUtils.validateCaseLinePricingPreSave(this.caseLinePricingSummary, this.messageService)) {
        this.toggleSaveButton(true);
        this.postSaveAfterError();
        return;
      }
      this.preSave();
      console.log('*** On Pricing save', this.caseLinePricingSummary)
      this.caseRestService
        .saveCaseLinePricingSummary(this.caseLinePricingSummary)
        .subscribe((pCaseLinePricingSummary: ICaseLinePricing) => {
          // If an error, show the list of errors.
          if (pCaseLinePricingSummary.wm_MessageLevel === DsamsConstants.ERROR_TYPE_ERROR) {
            // Popup the error list.
            this.messageService.displayMessageListTc("Case Line Pricing Save Results", pCaseLinePricingSummary.wm_errorMessageArray).subscribe();
            this.toggleSaveButton(true);
            //console.log('before postSaveAfterError',this.clcDataList)
            this.postSaveAfterError();
          }
          else if (pCaseLinePricingSummary.wm_checkFinancialData && this._promptFinancialCheck) {
            // Show financial warning.
            MessageMgr.swalFire(
              {
                text: "Total cost for this line or subline is now less than its authorized, committed, obligated, billed, or disbursed amounts. Do you want to continue?",
                icon: 'question',
                width: 700,
                showCancelButton: true,
                cancelButtonText: 'No',
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes'
              }).then((promptResult) => {
                if (!!promptResult && promptResult.isConfirmed) {
                  this._promptFinancialCheck = false;
                  this.caseLinePricingSummary.wm_noPromptCheckFinancialData = true;
                  this.saveButtonOnClick();
                }
                else {
                  //console.log('before postSaveAfterError1',this.clcDataList)
                  this.postSaveAfterError();
                }
              });
            this.toggleSaveButton(true);
          }
          else {
            if (pCaseLinePricingSummary.wm_MessageLevel === DsamsConstants.ERROR_TYPE_WARNING) {
              // Popup the warning list.
              this.messageService.displayMessageListTc("Case Line Pricing Save Results", pCaseLinePricingSummary.wm_errorMessageArray).subscribe();
              this.toggleSaveButton(true);
            }
            MessageMgr.swalFire({
              text: 'Save complete.',
              icon: 'success',
              width: 350,
              showCancelButton: false,
              confirmButtonColor: '#3085d6',
              confirmButtonText: 'OK'
            });
            this.caseLinePricingSummary = pCaseLinePricingSummary;
            this._promptFinancialCheck = true;
            this.postSave();
            this.caseUIService.theComponentSaveCaseLineState[CaseUIService.SAVE_CASE_LINE_PRICING_STATE].isDataChanged = false;
            // begin DSAMS-5983 09/22 DB
           //this.unlockCaseLineEntity();
            // begin DSAMS-5983 09/22 DB
            this.toggleSaveButton(true);
          }
        },
          err => {
            CaseUtils.ReportHTTPError(err, "Error in save Case Line Pricing.");
            this.toggleSaveButton(true);
            this.postSaveAfterError();
            this.caseLinePricingInfoData.isPricingDataChanged = true;
            //console.log('postSaveAfterError isPricingDataChanged=', this.caseLinePricingInfoData.isPricingDataChanged)
          });
    }
  }


  // Divide the DTC-s by 100 before calc costs.
  private prepareDTCBeforeCostsCalculation() {
    this.caseLinePricingSummary.caseLineComponentList.forEach(eachClc => {
      if (!!eachClc.caseLineCompDelTermList) {
        eachClc.caseLineCompDelTermList.forEach(eachDtc => {
          eachDtc.delivery_TERM_RT = eachDtc.delivery_TERM_RT / 100;
        });
      }
    });
  }

  // Times the DTC-s by 100 after calc costs.
  private refreshDTCAfterCostsCalculation() {
    if (!!this.clcDataList) {
      this.clcDataList.forEach(eachClc => {
        if (!!eachClc.caseLineCompDelTermList) {
          eachClc.caseLineCompDelTermList.forEach(eachDtc => {
            eachDtc.delivery_TERM_RT = eachDtc.delivery_TERM_RT * 100;
          });
        }
      });
    }
  }

  //breakout logic per sonarqube rule
  setIPCStatusCd(eachIPC: CaseLineIPCDto) {
    if (eachIPC.theIpcNumberId == null) {
      eachIPC.theIpcNumberId = {
        ipc_NUMBER_ID: eachIPC.ipc_NUMBER_ID,
        waiver_ALLOWED_IN: false,
        rate_BASED_IN: false
      };
    }
    else {
      if (eachIPC.theCaseLineIpcStatusCd == null) {
        eachIPC.theCaseLineIpcStatusCd = {
          case_LINE_IPC_STATUS_CD: eachIPC.case_LINE_IPC_STATUS_CD,
        }
      }
      else eachIPC.theCaseLineIpcStatusCd.case_LINE_IPC_STATUS_CD = eachIPC.case_LINE_IPC_STATUS_CD;
    }
  }

  //breakout logic per sonarqube rule
  setUpDataForCalculateCosts() {
    this._oldIpcStorageArray = [];
    let clcIndex: number = 0;
    let ipcIndex: number = 0;
    if (!!this.caseLinePricingSummary.caseLineComponentList) {
      this.caseLinePricingSummary.caseLineComponentList.forEach(eachComp => {
        //Required for legacy code: Being accessed by CaseLineIPCPricingPolicyMgr.calcTransportationRate method
        if (eachComp.caseLineCompDelTermList == null) eachComp.caseLineCompDelTermList = [];
        if (eachComp.caseLineIpcList == null) eachComp.caseLineIpcList = [];
        //Required for legacy code: Being checked in validateWaiverCosts
        else eachComp.caseLineIpcList.forEach(eachIPC => {
          this.setIPCStatusCd(eachIPC);
          // Store array of old IPC-s because they get wiped out as it passes thru calculateCost.
          this._oldIpcStorageArray.push({
            clcRow: clcIndex,
            ipcRow: ipcIndex,
            wm_OLD_IPC_NUMBER_ID: eachIPC.wm_OLD_IPC_NUMBER_ID,
            status: eachIPC.status
          });
          ipcIndex++;
        });
        clcIndex++;
      });
      this.prepareDTCBeforeCostsCalculation();
    }
  }

  //Jira card 4138-DH-FR17 Calculate Pricing Costs
  prepareDataForCalculateCosts() {
    //DH: attach the caseLineDeliveryTermList only for now
    this.caseLinePricingSummary.caseLineDeliveryTermList = this.caseLinePricingInfoData.caseLineDeliveryTermList;
    //Do not change these default prerequiste data for Calculate Costs function
    this.caseLinePricingSummary.wm_MessageLevel = '';
    this.caseLinePricingSummary.inventory_VALUE_AM = this.caseLinePricingInfoData.inventory_VALUE_AM
    this.caseLinePricingSummary.change_ACTION_CD = this.caseLinePricingInfoData.change_ACTION_CD;
    this.caseLinePricingSummary.condition_CD = this.caseLinePricingInfoData.condition_CD;
    this.caseLinePricingSummary.line_PURPOSE_CD = this.caseLinePricingInfoData.line_PURPOSE_CD;
    this.caseLinePricingSummary.national_STOCK_NUMBER_ID = this.caseLinePricingInfoData.national_STOCK_NUMBER_ID;
    this.caseLinePricingSummary.other_NATIONAL_STOCK_NUMBER_ID = this.caseLinePricingInfoData.other_NATIONAL_STOCK_NUMBER_ID;
    this.caseLinePricingSummary.supply_SOURCE_NUMBER_ID = this.caseLinePricingInfoData.supply_SOURCE_NUMBER_ID;
    this.caseLinePricingSummary.case_LINE_MARK_FOR_DELETION_IN = this.caseLinePricingInfoData.case_LINE_MARK_FOR_DELETION_IN;
    this.caseLinePricingSummary.acquisition_VALUE_AM = this.caseLinePricingInfoData.acquisition_VALUE_AM;
    this.caseLinePricingSummary.recalculation_IN = this.caseLinePricingInfoData.recalculation_IN;
    this.caseLinePricingSummary.calculateIPCSummaryTotal = true;
    this.caseLinePricingSummary.precision_UNIT_COST_PRICING_IN = true;

    if (!!this.caseLineRelatedInfoData) {
      this.caseLinePricingSummary.theWorkingCaseVersionId = {
        case_VERSION_NUMBER_ID: this.caseLineRelatedInfoData.case_VERSION_NUMBER_ID,
        case_VERSION_STATUS_CD: this.caseLineRelatedInfoData.case_VERSION_STATUS_CD,
        case_VERSION_TYPE_CD: this.caseLineRelatedInfoData.case_VERSION_TYPE_CD,
        case_ID: this.caseLinePricingInfoData.case_ID,
      }
    }
    this.setUpDataForCalculateCosts();
  }

  setTotal_ABOVE_LINE_COST_AM() {
    // Convert to N/A if $0
    if (this.total_ABOVE_LINE_COST_AM === 0) {
      this.total_ABOVE_LINE_COST_AM_string = 'N/A'
    }
    else {
      this.total_ABOVE_LINE_COST_AM_string = formatCurrency(this.caseLinePricingSummary.total_ABOVE_LINE_COST_AM, 'en', '$');
    }
  }

  //refresh cost amounts after calculation
  refreshFieldsAfterCostsCalculation() {
    this.recalculateCaseLineTotals();
    this.clcDataList.forEach(eachClc => {
      this.updateClcLine(eachClc, false);
      if (eachClc.status !== DsamsConstants.ENT_NEW.toString())
        eachClc.status = DsamsConstants.ENT_CHANGED.toString();

      eachClc.isFieldDisabled = {
        wm_target_COST_AM: true,
        wm_component_UNIT_BASE_PRICE_AM: true,
        case_LINE_COMPONENT_QY: true,
        wm_target_PERCENT_RT: true,
        wm_base_PRICE_SOURCE_NM: false,
        fund_CD: false,
        price_ELEMENT_CD: false,
      }
    });
    this.caseLinePricingSummary.status = DsamsConstants.ENT_CHANGED;
    this.onChangeCaseLine();
    let clcIndex: number = 0;
    let ipcIndex: number = 0;
    this.clcDataList.forEach(eachClc => {
      this.caseUIService.pricingPostRecal.next(eachClc);
      // Re-Populate the old_wm_ipc_number_id from the temp table (since it got wiped out in calc costs).
      if (!!eachClc.caseLineIpcList) {
        eachClc.caseLineIpcList.forEach(eachIpc => {
          const oldInfo: oldIpcStorage = this._oldIpcStorageArray.filter(elem => { return elem.clcRow == clcIndex && elem.ipcRow == ipcIndex })[0];
          eachIpc.wm_OLD_IPC_NUMBER_ID = oldInfo.wm_OLD_IPC_NUMBER_ID;
          eachIpc.status = oldInfo.status;
          ipcIndex++;
        });
      }
      clcIndex++;
    });
    this.dataSourcePricingTable = new MatTableDataSource<caseLineComponentDto>(this.clcDataList);
    this.enableControlFieldsForAllClcs();
    this.dataSourcePricingTable._updateChangeSubscription();
  }

  isFYPersonelValid(msgArray: Array<ErrorParameter>, pStatus: boolean): boolean {
    let validStatus: boolean = pStatus;
    this.caseLinePricingSummary.caseLineComponentList.forEach(eachComp => {
      if (!!eachComp.caseLineIpcList) {
        eachComp.caseLineIpcList.forEach(eachIPC => {
          if (!CaseUtils.isBlankStr(eachComp.base_PRICE_SOURCE_CD) &&
            (CaseCommonValidator.isEqual(eachIPC.ipc_NUMBER_ID, "A0420") ||
              CaseCommonValidator.isEqual(eachIPC.ipc_NUMBER_ID, "A0430") ||
              CaseCommonValidator.isEqual(eachComp.base_PRICE_SOURCE_CD.toString(), "4"))) {
            if (CaseUtils.isBlankStr(eachComp.civilian_FISCAL_YEAR_ID)) {
              DialogMessageListComponentTc.addMessageRefToList(msgArray,
                LineUtils.CASE_LINE_CATEGORY, eachComp.primary_CATEGORY_CD + ", " + eachIPC.ipc_NUMBER_ID,
                MessageType.ERROR,
                "Fiscal Year for Personnel Rates is required.");
              validStatus = false;
            }
          }
        })
      }
    })
    return validStatus;
  }

  isTimeInStorageValid(msgArray: Array<ErrorParameter>, pStatus: boolean): boolean {
    let validStatus: boolean = pStatus;
    this.caseLinePricingSummary.caseLineComponentList.forEach(eachComp => {
      if (!!eachComp.caseLineIpcList) {
        eachComp.caseLineIpcList.forEach(eachIPC => {
          if (CaseCommonValidator.isEqual(eachIPC.ipc_NUMBER_ID, "A2110") ||
            CaseCommonValidator.isEqual(eachIPC.ipc_NUMBER_ID, "B0610") &&
            !CaseCommonValidator.isEqual(eachIPC.case_LINE_IPC_STATUS_CD, "NA")) {
            if (CaseUtils.isBlankStr(eachComp.storage_YEAR_AM) &&
              CaseUtils.isBlankStr(eachComp.storage_MONTH_AM) &&
              CaseUtils.isBlankStr(eachComp.storage_DAY_AM)) {
              DialogMessageListComponentTc.addMessageRefToList(msgArray,
                LineUtils.CASE_LINE_CATEGORY, eachComp.primary_CATEGORY_CD + ", " + eachIPC.ipc_NUMBER_ID,
                MessageType.ERROR,
                "At least one storage amount (years, months, or days) is required.");
              validStatus = false;
            }
          }
        })
      }
    })
    validStatus = this.isFYPersonelValid(msgArray, validStatus);
    return validStatus;
  }

  //breakout logic per sonarqube rule
  areAllIPCDataValid(msgArray: Array<ErrorParameter>, eachComp: caseLineComponentDto,
    eachIPC: CaseLineIPCDto, pStatus: boolean): boolean {
    let validStatus: boolean = pStatus;
    if (CaseUtils.isBlankStr(eachComp.price_YEAR_CD)) {
      DialogMessageListComponentTc.addMessageRefToList(msgArray,
        LineUtils.CASE_LINE_CATEGORY, eachComp.primary_CATEGORY_CD + ', ' + eachIPC.ipc_NUMBER_ID,
        MessageType.ERROR,
        "Mandatory field Base Unit Price Year is missing.");
      validStatus = false;
    }
    if (CaseUtils.isBlankStr(eachComp.base_FISCAL_YEAR_ID)) {
      DialogMessageListComponentTc.addMessageRefToList(msgArray,
        LineUtils.CASE_LINE_CATEGORY, eachComp.primary_CATEGORY_CD + ', ' + eachIPC.ipc_NUMBER_ID,
        MessageType.ERROR,
        "Mandatory field Base Fiscal Year is missing.");
      validStatus = false;
    }
    if (CaseUtils.isBlankStr(eachComp.then_FISCAL_YEAR_ID)) {
      DialogMessageListComponentTc.addMessageRefToList(msgArray,
        LineUtils.CASE_LINE_CATEGORY, eachComp.primary_CATEGORY_CD + ', ' + eachIPC.ipc_NUMBER_ID,
        MessageType.ERROR,
        "Mandatory field Then Fiscal Year is missing.");
      validStatus = false;
    }
    if (CaseUtils.isBlankStr(eachComp.inflation_FUND_CD)) {
      DialogMessageListComponentTc.addMessageRefToList(msgArray,
        LineUtils.CASE_LINE_CATEGORY, eachComp.primary_CATEGORY_CD + ', ' + eachIPC.ipc_NUMBER_ID,
        MessageType.ERROR,
        "Mandatory field Fund Code is missing.");
      validStatus = false;
    }
    return validStatus;
  }

  //breakout logic per sonarqube rule
  isIPCCostsBasisValid(msgArray: Array<ErrorParameter>, pStatus: boolean): boolean {
    let validStatus: boolean = pStatus;
    if (!!this.caseLinePricingSummary.caseLineComponentList) {
      console.log('****', this.caseLinePricingSummary.caseLineComponentList)
      this.caseLinePricingSummary.caseLineComponentList.forEach(eachComp => {
        if (!!eachComp.caseLineIpcList) {
          eachComp.caseLineIpcList.forEach(eachIPC => {
            if (CaseCommonValidator.isEqual(eachIPC.ipc_NUMBER_ID, "A0110") &&
              (!CaseCommonValidator.isEqual(eachIPC.case_LINE_IPC_STATUS_CD, "OP") &&
               !CaseCommonValidator.isEqual(eachIPC.case_LINE_IPC_STATUS_CD, "NA") &&
                !CaseCommonValidator.isEqual(eachIPC.case_LINE_IPC_STATUS_CD, "OC"))) {
              validStatus = this.areAllIPCDataValid(msgArray, eachComp, eachIPC, validStatus);
            }
          })
        }
      })
    }
    validStatus = this.isTimeInStorageValid(msgArray, validStatus);
    return validStatus;
  }

  //Validation for Calulate Costs function
  areFieldsValidForCalculation(msgArray: Array<ErrorParameter>): boolean {
    let validStatus: boolean = true;

    if (this.caseLinePricingInfoData.issue_UNIT_CD.toUpperCase() == LineUtils.UNIT_OF_ISSUE_XX &&
      !CaseUtils.isBlankStr(this.caseLinePricingSummary.case_LINE_ITEM_QY) &&
      this.caseLinePricingSummary.case_LINE_ITEM_QY !== 0) {
      DialogMessageListComponentTc.addMessageRefToList(msgArray,
        LineUtils.CASE_LINE_CATEGORY, this.caseLinePricingInfoData.LINESUBLINESEQVIR,
        MessageType.ERROR,
        "Quantity cannot be entered for Unit of Issue XX.");
      validStatus = false;
    }

    if (CaseUtils.isBlankStr(this.caseLinePricingSummary.pricing_METHOD_CD)) {
      DialogMessageListComponentTc.addMessageRefToList(msgArray,
        LineUtils.CASE_LINE_CATEGORY, this.caseLinePricingInfoData.LINESUBLINESEQVIR,
        MessageType.ERROR,
        "Pricing Method is required.");
      validStatus = false;
    }

    if ((!CaseUtils.isBlankStr(this.caseLinePricingInfoData.issue_UNIT_CD)) &&
      (!CaseUtils.isBlankStr(this.caseLinePricingSummary.case_LINE_ITEM_QY))) {
      if (this.caseLinePricingInfoData.issue_UNIT_CD.toUpperCase() == "EA" &&
        this.caseLinePricingSummary.case_LINE_ITEM_QY == 0) {
        DialogMessageListComponentTc.addMessageRefToList(msgArray,
          LineUtils.CASE_LINE_CATEGORY, this.caseLinePricingInfoData.LINESUBLINESEQVIR,
          MessageType.ERROR,
          "Pricing Quantity must be greater than zero (0).");
        validStatus = false;
      }
    }
    validStatus = this.isIPCCostsBasisValid(msgArray, validStatus);
    return validStatus;
  }

  //breakout per Sonarqube rule
  isCalculationResultFailed(pCaseLinePricingSummaryResult: ICaseLinePricing): boolean {
    if (pCaseLinePricingSummaryResult == null) {
      MessageMgr.displayErrorWithTimer('Calculation Costs failed.', 1500);
      this.caseLinePricingInfoData.recalculation_IN = true;
      return true;
    }
    return false;
  }

  //breaout logic per sonaqube rule
  performCalculateCosts(statusArr: Array<string>) {
    this.caseRestService.calculateLinePricingCosts(this.caseLinePricingSummary).subscribe(
      (theCaseLinePricingSummaryResult: ICaseLinePricing) => {
        if (!this.isCalculationResultFailed(theCaseLinePricingSummaryResult)) {
          this.isLoading.next(false);
          if (!!theCaseLinePricingSummaryResult) {
            this.caseLinePricingSummary = theCaseLinePricingSummaryResult;
            // Re-apply any statuses
            for (let i = 0; i < statusArr.length; i++) {
              if (statusArr[i] == DsamsConstants.ENT_NEW.toString()) {
                this.caseLinePricingSummary.caseLineComponentList[i].status = DsamsConstants.ENT_NEW.toString();
              }
            }
            console.log('***after calculateCosts', this.caseLinePricingSummary);
            this.clcDataList = theCaseLinePricingSummaryResult.caseLineComponentList;
            this.refreshFieldsAfterCostsCalculation();
          }
        }
        this.refreshDTCAfterCostsCalculation();
        if (!!theCaseLinePricingSummaryResult && (!!theCaseLinePricingSummaryResult.wm_errorMessageArray) &&
          (theCaseLinePricingSummaryResult.wm_errorMessageArray.length > 0)) {
          if (theCaseLinePricingSummaryResult.wm_MessageLevel === DsamsConstants.ERROR_TYPE_ERROR)
            this.caseLinePricingInfoData.recalculation_IN = true;

          this.messageService.displayMessageListTc("Calculate Costs", theCaseLinePricingSummaryResult.wm_errorMessageArray).subscribe();
        }
        else {
          this.isLoading.next(false);
          MessageMgr.displayInfoWithTimer('Calculate Complete.', 2000);
          this.caseLinePricingInfoData.recalculation_IN = false;
          this.caseLinePricingInfoData.isPricingDataChanged = true;
        }
      },
      err => {
        this.isLoading.next(false);
        console.log('', err);
        MessageMgr.displayErrorWithTimer('Calculation Costs failed.', 1500);
      });
  }

  //Jira card 4138-DH-FR17 Calculate Pricing Costs
  calculateCosts() {
    this.caseLinePricingSummary.caseLineComponentList = this.clcDataList;
    console.log('***before calculateCosts', this.caseLinePricingSummary);

    if (this.caseLinePricingSummary.caseLineComponentList == null) {
      console.log("No PCC line exist");
      return;
    }
    else if (!LinePricingUtils.validateCaseLinePricingPreSave(this.caseLinePricingSummary, this.messageService)) {
      return;
    }

    let msgArray: Array<ErrorParameter> = [];
    if (this.areFieldsValidForCalculation(msgArray)) {
      this.isLoading.next(true);
      this.prepareDataForCalculateCosts();

      // Store the statuses and re-apply them after calc costs.
      let statusArr: Array<string> = [];
      if (!!this.caseLinePricingSummary.caseLineComponentList) {
        this.caseLinePricingSummary.caseLineComponentList.forEach(eachClc => {
          statusArr.push(eachClc.status);
        });
      }
      //Do invoke legacy calculate costs function
      this.performCalculateCosts(statusArr);
    }
    else {
      this.messageService.displayMessageListTc("Validate Case Line", msgArray).subscribe();
    }
  }

  /* This procedure checks the returned result value from the popover Yes/No dialog window. */
  yesButtonOnClick(isDeleteConfirmed: any, rowElement: any) {
    if (isDeleteConfirmed)
      this.deleteItem(rowElement);
  }

  deleteItem(rowElement: any) {
    //DH: Commented out as it may not be the selected current row display index
    //let rowIndex = this.clcDataList.indexOf(rowElement);
    let rowIndex = this.dataSourcePricingTable.data.indexOf(rowElement);

    if (this.clcDataList.length <= 1) {  //Added delete pricing button
      this.isPCCPresent = false;
    }

    if (this.clcDataList[rowIndex].status !== DsamsConstants.ENT_NEW.toString())
      this.delClcDataList.push(this.clcDataList[rowIndex]);

    this.theExpandIPCPanel = false; //delete pricing button  
    this.clcDataList.splice(rowIndex, 1);
    if (this.clcDataList.length == 0) {
      this.updateClcLine(null, false);
    }
    else {
      this.clcDataList.forEach(eachClc => {
        this.updateClcLine(eachClc, false);
      });
    }
    this.dataSourcePricingTable = new MatTableDataSource<caseLineComponentDto>(this.clcDataList);
    this.dataSourcePricingTable._updateChangeSubscription();
    //console.log('deleteItem', this.clcDataList)
  }

  addNewPCC(): void {
    let anItemObject: caseLineComponentDto =
    {
      status: DsamsConstants.ENT_NEW.toString(),
      case_ID: this.caseLinePricingSummary.case_ID,
      case_MASTER_LINE_ID: this.caseLinePricingSummary.case_MASTER_LINE_ID,
      working_CASE_ID: this.caseLinePricingSummary.working_CASE_ID,
      working_CASE_VERSION_ID: this.caseLinePricingSummary.working_CASE_VERSION_ID,
      case_LINE_COMPONENT_ID: null,
      primary_CATEGORY_CD: null,
      price_ELEMENT_CD: null,
      fund_CD: null,
      base_PRICE_SOURCE_CD: null,
      component_UNIT_BASE_PRICE_AM: 0,
      case_LINE_COMPONENT_QY: 1,
      target_COST_AM: 0,
      target_PERCENT_RT: 0,
      above_LINE_COST: 0,
      total_COST: 0,
      component_DESCRIPTION_TX: null,
      iconImg: "arrow_drop_down",
      expandIPCPanel: false,
      base_FISCAL_YEAR_ID: null,
      then_FISCAL_YEAR_ID: null,
      civilian_FISCAL_YEAR_ID: null,
      inflation_FUND_CD: null,
      storage_YEAR_AM: null,
      storage_MONTH_AM: null,
      storage_DAY_AM: null,
      price_YEAR_CD: null,
      fundList: this._fundFullList,
      priceElementList: this._priceElementFullList,
      populatePEFlag: true,
      pouplateFundFlag: true,
      primaryCategoryChanged: false,
      publication_CATEGORY_CD: '',
      publication_PAGE_AM: null,
      databaseIpcListStr: "",
      caseLineCompDelTermList: [],
      isFieldDisabled: {
        wm_target_COST_AM: true,
        wm_component_UNIT_BASE_PRICE_AM: true,
        case_LINE_COMPONENT_QY: true,
        wm_target_PERCENT_RT: true,
        wm_base_PRICE_SOURCE_NM: false,
        fund_CD: false,
        price_ELEMENT_CD: false,
      },
    }
    if (this.fcPricingMethod.value != this.PRICING_METHOD_FC) {
      anItemObject.base_PRICE_SOURCE_CD = 5;
      anItemObject.wm_base_PRICE_SOURCE_NM = LinePricingComponent.REVERSE_CALCULATION;
      anItemObject.isFieldDisabled = {
        wm_target_COST_AM: false,
        wm_component_UNIT_BASE_PRICE_AM: true,
        case_LINE_COMPONENT_QY: false,
        wm_target_PERCENT_RT: false,
        wm_base_PRICE_SOURCE_NM: true,
        fund_CD: false,
        price_ELEMENT_CD: false
      };
    }
    if (!this.clcDataList) {
      this.clcDataList = [];
    }
    this.updateClcTotal(anItemObject);
    this.clcDataList.push(anItemObject);
    this.dataSourcePricingTable = new MatTableDataSource<caseLineComponentDto>(this.clcDataList);
    this.onChangeCaseLine();
    if (this.clcDataList.length >= 1) {
      if (this.isPanelEditable) this.isPCCPresent = true;
      else this.isPCCPresent = false;
    }
    else {
      this.isPCCPresent = false;
    }
    this.theExpandIPCPanel = false;
    this.dataSourcePricingTable.data.forEach(eachRow => {
      eachRow.expandIPCPanel = false;
    });
  }

  setPrimaryCategory(code: string, i: number) {
    this.clcDataList[i].primary_CATEGORY_CD = code;
    this.categoryCode[i] = code;
  }

  setPriceElement(code: string, i: number) {
    this.clcDataList[i].price_ELEMENT_CD = code;
    this.elementCode[i] = code;
  }

  setFund(code: string, i: number) {
    this.clcDataList[i].fund_CD = code;
    this.fundCode[i] = code;
  }

  // Change the fund code list according to what the user selects in the price element.
  populateFundList(pPriceElementCd: string, pIndex: number) {
    this.isRecalculateChecked = false;
    if (this.clcDataList[pIndex].populatePEFlag || !this.clcDataList[pIndex].fund_CD || this.clcDataList[pIndex].fund_CD === "") {
      const filterdPriceElementFundArray: dropdownArray[] = this.componentFundArray.filter(elem => {
        return (!pPriceElementCd || pPriceElementCd === "" || !elem.pCode || elem.pCode === "" || this._componentPriceElementFundString.indexOf("*" + elem.pCode + "@" + pPriceElementCd + "*") >= 0);
      });
      this.clcDataList[pIndex].fundList = [];
      for (let dropdown of filterdPriceElementFundArray) {
        this.clcDataList[pIndex].fundList.push({ fund_CD: dropdown.pCode, fund_TITLE_NM: dropdown.pDesc });
      }
      this.clcDataList[pIndex].fund_CD = "";
      this.dataSourcePricingTable = new MatTableDataSource<caseLineComponentDto>(this.clcDataList);
    }
    if (!pPriceElementCd || pPriceElementCd === "") {
      this.clcDataList[pIndex].priceElementList = this._priceElementFullList;
    }
    this.onChangeCaseLineComponent(pIndex);
    this.clcDataList[pIndex].populatePEFlag = true;
    this.clcDataList[pIndex].pouplateFundFlag = false;
  }

  // Change PE list according to the fund code value.
  populatePriceElementList(pFundCd: string, pIndex: number) {
    this.isRecalculateChecked = false;
    if (this.clcDataList[pIndex].pouplateFundFlag || !this.clcDataList[pIndex].price_ELEMENT_CD || this.clcDataList[pIndex].price_ELEMENT_CD === "") {
      const filterdPriceElementPEArray: dropdownArray[] = this.componentPriceElementArray.filter(elem => {
        return (!pFundCd || pFundCd === "" || !elem.pCode || elem.pCode === "" || this._componentPriceElementFundString.indexOf("*" + pFundCd + "@" + elem.pCode + "*") >= 0);
      });
      this.clcDataList[pIndex].priceElementList = [];
      for (let dropdown of filterdPriceElementPEArray) {
        this.clcDataList[pIndex].priceElementList.push({ price_ELEMENT_CD: dropdown.pCode, price_ELEMENT_TITLE_NM: dropdown.pDesc });
      }
      this.clcDataList[pIndex].price_ELEMENT_CD = "";
      this.dataSourcePricingTable = new MatTableDataSource<caseLineComponentDto>(this.clcDataList);
    }
    if (!pFundCd || pFundCd === "") {
      this.clcDataList[pIndex].fundList = this._fundFullList;
    }
    this.onChangeCaseLineComponent(pIndex);
    this.clcDataList[pIndex].populatePEFlag = false;
    this.clcDataList[pIndex].pouplateFundFlag = true;
  }

  // Text Area Popup
  popupTextAreaOpen(pElement: any, pIndex: number): void {
    let diaWidth: string = "50%";
    let diaHeight: string = "60%";
    let passingData: string = pElement.component_DESCRIPTION_TX;
    let pTitle: string = "IPC Description";
    this.index = pIndex;
    this.dsamsDialogMsgService.openTextAreaDialog2(diaWidth, diaHeight, passingData, TextAreaComponent, pTitle, !this.isPanelEditable);
  }

  /*---------------------------------------------- Edit Toggle --------------------------------------------*/
  // Subscribe to edit service
  private subscribeToEditServices() {
    this.editSubscription = this.caseUIService.caseEditService.subscribe((pEditResult: IEditResponseType) => {
      //console.log('EditServices',this.caseLinePricingInfoData)
      if (!!pEditResult && pEditResult.ID === DsamsConstants.CASE_LINE_EDITOR) {
        this.isPanelEditable = pEditResult.editToggle;
        if (pEditResult.editToggle && this.caseLinePricingInfoData.status!= DsamsConstants.ENT_NEW.toString()) {
          // begin  DSAMS-5867 07/22 DB
          // setTimeout(() => {
          //   this.populateCaseLinePricingSummary();
          // }, 100);
            //end  DSAMS-5867 07/22 DB
}
        if (this.isPanelEditable && !this.theOriginalRecalValue)
          this.caseLinePricingInfoData.recalculation_IN = true;
        else if (!this.isPanelEditable && !this.theOriginalRecalValue)
          this.caseLinePricingInfoData.recalculation_IN = false;

        if (!this.clcDataList || this.clcDataList.length < 1)
          this.isPCCPresent = false; //delete pricing button
        else {
          if (this.isPanelEditable) this.isPCCPresent = true;
          else this.isPCCPresent = false;
          this.resetRelatedCalCostsFields(true);  // postSaveFlag=true, but really true, but we need the behavior.
          this.enableControlFieldsForAllClcs();
        }
      }
    });

    /** UnEdit Subscription */
    this.unEditSubscription = this.caseUIService.caseUnEditService.subscribe((pEditResult: IEditResponseType) => {
      if (!!pEditResult && pEditResult.ID === DsamsConstants.CASE_LINE_EDITOR) {
        this.isLoading.next(true);
        this.isPanelEditable = false;
      }
    });
  }
  

  // Determine if a field is disabled.
  isFieldDisabled(pElement: any, pFieldName: string): boolean {
    // Is whole panel disabled?
    if (!this.isPanelEditable) {
      return true;
    }
    if (!!pElement && pElement.isDisabled) {
      return true;
    }
    return this._fieldDisabledMap[pFieldName];
  }

  //Jira card 3577-DH-Set to enable or disable Base Price Source dropdown
  setBasePriceSourceState(pValue: boolean) {
    if (!!this.dataSourcePricingTable.data) {
      this.dataSourcePricingTable.data.forEach(eachRow => {
        if (!!eachRow.isFieldDisabled) {
          if (this.caseLinePricingSummary.pricing_METHOD_CD !== this.PRICING_METHOD_FC ||
            !this.isPanelEditable)
            eachRow.isFieldDisabled['wm_base_PRICE_SOURCE_NM'] = true;
          else
            eachRow.isFieldDisabled['wm_base_PRICE_SOURCE_NM'] = false;
        }
      });
    }
  }

  //Jira card 3577-DH-reset costs related attributes
  resetRelatedCalCostsFields(postSave: boolean) {
    if (!!this.dataSourcePricingTable.data) {
      this.dataSourcePricingTable.data.forEach(eachRow => {
        if (postSave) {
          this.enableControlFieldsForAllClcs();
        }
        else {
          eachRow.isFieldDisabled = {
            wm_target_COST_AM: true,
            wm_component_UNIT_BASE_PRICE_AM: true,
            case_LINE_COMPONENT_QY: true,
            wm_base_PRICE_SOURCE_NM: true,
            price_ELEMENT_CD: true,
            fund_CD: true,
          };
        }
        if (eachRow.status == DsamsConstants.ENT_NEW.toString()) {
          eachRow.isFieldDisabled = {
            price_ELEMENT_CD: false,
            fund_CD: false,
          }
        }
      })
    }
    if (this.isPanelEditable) this.setBasePriceSourceState(false);
    else this.setBasePriceSourceState(true);
    this.dataSourcePricingTable._updateChangeSubscription();
  }

  // Populate Pricing Summary data
  public populateCaseLinePricingSummary() {
    // begin DSAMS05867 08/22 DB
    this.isLoading.next(true);
  // end DSAMS05867 08/22 DB
    this.caseRestService.getCaseLinePricingSummary(
      this.caseLinePricingInfoData.case_ID,
      this.caseLinePricingInfoData.working_CASE_ID,
      this.caseLinePricingInfoData.working_CASE_VERSION_ID,
      this.caseLinePricingInfoData.case_MASTER_LINE_ID).subscribe(
        data => {
          setTimeout(() => {
            //clear out values
            this.clcDataList = [];
            this.caseLinePricingSummary = data;
            this.caseLinePricingSummary.status = DsamsConstants.ENT_UNCHANGED;
            if (!this.caseLinePricingSummary.case_LINE_ITEM_QY_string) {
              this.caseLinePricingSummary.case_LINE_ITEM_QY_string = "N/A";
            }
            this.case_LINE_ITEM_QY_string = this.caseLinePricingSummary.case_LINE_ITEM_QY_string;
            this.military_ARTICLE_SERVICE_CD_string = this.caseLinePricingSummary.military_ARTICLE_SERVICE_CD;
            this.caseLinePricingSummary.case_USAGE_INDICATOR_CD = this.caseLinePricingInfoData.case_USAGE_INDICATOR_CD;
            if (!this.caseLinePricingSummary.price_EFFECTIVE_DT) {
              this.caseLinePricingSummary.price_EFFECTIVE_DT = new Date(new Date().toDateString());
            }
            this.price_EFFECTIVE_DT = this.caseLinePricingSummary.price_EFFECTIVE_DT;
            this.price_EFFECTIVE_DT_string = formatDate(this.price_EFFECTIVE_DT, 'MM/dd/yyyy', 'en-US');
            this.price_EXPIRATION_DT = this.caseLinePricingSummary.price_EXPIRATION_DT;

            if (this.price_EXPIRATION_DT != null) {
              this.price_EXPIRATION_DT_string = formatDate(this.price_EXPIRATION_DT, 'MM/dd/yyyy', 'en-US');
              this.caseLinePricingSummary.old_PRICE_EXPIRATION_DT = this.price_EXPIRATION_DT;
            }
            else {
              this.price_EXPIRATION_DT_string = '';
              this.caseLinePricingSummary.old_PRICE_EXPIRATION_DT = DsamsConstants.DUMMY_DATE;
            }

            this.updateCaseLineTotals();
            this.mtds_NARRATIVE_DESCRIPTION_TX_string = this.caseLinePricingSummary.mtds_NARRATIVE_DESCRIPTION_TX;
            this.pricing_METHOD_CD_string = this.caseLinePricingSummary.pricing_METHOD_CD;
            this.fcPricingMethod.setValue(this.caseLinePricingSummary.pricing_METHOD_CD);
            this.theOriginalPricingMethodValue = this.caseLinePricingSummary.pricing_METHOD_CD;
            this.isSaveButtonDisabled = false;

            this.wm_HasFiscalYearDistribution = this.caseLinePricingSummary.wm_HasFiscalYearDistribution; //For delete pricing
            if (!this.caseLinePricingSummary.caseLineComponentList) {
              this.clcDataList = [];
            }
            else {
              for (let i = 0; i < this.caseLinePricingSummary.caseLineComponentList.length; i++) {
                this.clcDataList.push(Object.assign(data.caseLineComponentList[i], { populatePEFlag: true, pouplateFundFlag: true, primaryCategoryChanged: false }));
              }
              this.clcDataList.sort((a, b) => (!a.primary_CATEGORY_CD ? "ZZZ" : a.primary_CATEGORY_CD).localeCompare(!b.primary_CATEGORY_CD ? "ZZZ" : b.primary_CATEGORY_CD));
              this.clcDataList.forEach(eachClc => {
                this.updateClcLine(eachClc, true);
                this.populateDatabaseIpcList(eachClc);
                // Times the DTC Lists by 100 so they get passed back to the database correctly.
                if (!!eachClc.caseLineCompDelTermList) {
                  eachClc.caseLineCompDelTermList.forEach(eachDtc => { eachDtc.delivery_TERM_RT = eachDtc.delivery_TERM_RT * 100; });
                }
                // Set the wm_OLD_IPC_NUMBER_ID equal to the current value.
                if (!!eachClc.caseLineIpcList) {
                  eachClc.caseLineIpcList.forEach(eachIpc => { eachIpc.wm_OLD_IPC_NUMBER_ID = eachIpc.ipc_NUMBER_ID; });
                }
              });
            }
            this.dataSourcePricingTable = new MatTableDataSource<caseLineComponentDto>(this.clcDataList);
            this.theCaselinePK = {
              case_ID: this.caseLinePricingSummary.case_ID,
              case_MASTER_LINE_ID: this.caseLinePricingSummary.case_MASTER_LINE_ID,
              working_CASE_ID: this.caseLinePricingSummary.working_CASE_ID,
              working_CASE_VERSION_ID: this.caseLinePricingSummary.working_CASE_VERSION_ID,
              case_USAGE_INDICATOR_CD: this.caseLinePricingInfoData.case_USAGE_INDICATOR_CD,
              primaryCategoryChanged: false
            };
            //
            // If there are no CLC-s, then set the totals fields to 0.
            if (!this.clcDataList || this.clcDataList.length == 0) {
              this.total_ABOVE_LINE_COST_AM = 0;
              this.setTotal_ABOVE_LINE_COST_AM();
            }
            this.caseUIService.setCaseLinePK(this.theCaselinePK);
            this.resetRelatedCalCostsFields(true);  // Not really post-save, but we need post-save-like behavior.
            //
            this.theOriginalRecalValue = this.caseLinePricingInfoData.recalculation_IN;
            this.isTlscDisabled = (this.caseLinePricingSummary.pricing_METHOD_CD === this.PRICING_METHOD_FC);
            this.dataSourcePricingTable._updateChangeSubscription();
            this.isLoading.next(false)
          }, 1000);
        },
        error => {
          CaseUtils.ReportHTTPError(error, "Getting Case Line Pricing Summary Data");
          this.isLoading.next(false);
        }
      );
  }

  //populate case line IPC pks for IPC tab
  setCaseLineIPCPKs(pIndex: number) {
    if (this.dataSourcePricingTable.data[pIndex].expandIPCPanel) {
      this.theCaselinePK.case_LINE_COMPONENT_ID = this.dataSourcePricingTable.data[pIndex].case_LINE_COMPONENT_ID;
      //window mapping attributes
      this.theCaselinePK.primary_CATEGORY_CD = this.dataSourcePricingTable.data[pIndex].primary_CATEGORY_CD;
      this.theCaselinePK.then_FISCAL_YEAR_ID = this.dataSourcePricingTable.data[pIndex].then_FISCAL_YEAR_ID;
      this.theCaselinePK.base_FISCAL_YEAR_ID = this.dataSourcePricingTable.data[pIndex].base_FISCAL_YEAR_ID;
      this.theCaselinePK.civilian_FISCAL_YEAR_ID = this.dataSourcePricingTable.data[pIndex].civilian_FISCAL_YEAR_ID;
      this.theCaselinePK.inflation_FUND_CD = this.dataSourcePricingTable.data[pIndex].inflation_FUND_CD;
      this.theCaselinePK.storage_YEAR_AM = this.dataSourcePricingTable.data[pIndex].storage_YEAR_AM;
      this.theCaselinePK.storage_MONTH_AM = this.dataSourcePricingTable.data[pIndex].storage_MONTH_AM;
      this.theCaselinePK.storage_DAY_AM = this.dataSourcePricingTable.data[pIndex].storage_DAY_AM;
      this.theCaselinePK.price_YEAR_CD = this.dataSourcePricingTable.data[pIndex].price_YEAR_CD;
      this.theCaselinePK.case_LINE_COMPONENT_QY = this.dataSourcePricingTable.data[pIndex].case_LINE_COMPONENT_QY;
      this.theCaselinePK.component_UNIT_BASE_PRICE_AM = this.dataSourcePricingTable.data[pIndex].component_UNIT_BASE_PRICE_AM;
      this.theCaselinePK.primaryCategoryChanged = this.dataSourcePricingTable.data[pIndex].primaryCategoryChanged;
      this.theCaselinePK.case_USAGE_INDICATOR_CD = this.caseLinePricingInfoData.case_USAGE_INDICATOR_CD;
      this.caseUIService.setCaseLinePK(this.theCaselinePK);
      console.log('expanding setIPCPK', this.clcDataList[pIndex], this.theCaselinePK);
      this.caseUIService.supplementalTabSubscription.next(this.clcDataList[pIndex]);
      this.caseUIService.pricingIpcTabData.next(this.clcDataList[pIndex].caseLineIpcList);

      this.dataSourcePricingTable.data[pIndex].primaryCategoryChanged = false;
      this.clcDataList[pIndex].primaryCategoryChanged = false;
    }
    this.theExpandIPCPanel = this.dataSourcePricingTable.data[pIndex].expandIPCPanel;
    for (let i = 0; i < this.dataSourcePricingTable.data.length; i++) {
      if (i !== pIndex) this.dataSourcePricingTable.data[i].expandIPCPanel = false;
    }
    this._expandedClcIndex = pIndex;
  }

  constructPricingForm() {
    this.pricingForm = this.formBuilder.group({
      txtPricingMethod: this.formBuilder.control('')
    });
  }

  // DTC Drawer
  dtcDrawerToggle(pIndex: number, pDrawer: any) {
    const dtcIconElement = document.getElementById("dtcIcon" + pIndex);
    const rect = dtcIconElement.getBoundingClientRect();
    const drawer = document.getElementById("dtcDrawer" + pIndex);
    drawer.style.position = "absolute";
    drawer.style.left = (rect.left - 50) + 'px';
    drawer.style.top = ((rect.bottom / 2) + 15) + 'px';
    this.dtcDrawerIndex = pIndex;
    // Make Rest API Call
    this.caseRestService.getCaseLinePCCDTC(
      this.caseLinePricingSummary.case_ID,
      this.caseLinePricingSummary.working_CASE_ID,
      this.caseLinePricingSummary.working_CASE_VERSION_ID,
      this.caseLinePricingSummary.case_MASTER_LINE_ID,
      this.dataSourcePricingTable.data[pIndex].case_LINE_COMPONENT_ID).subscribe(
        data => {
          this.caseLineCompDelTermArray = data;
          this.dataSourceDTCTable = new MatTableDataSource<CASE_LINE_COMP_DEL_TERM>(this.caseLineCompDelTermArray);

          // Total DTC percentage calculation
          let totalPercent: number = 0;
          for (let i = 0; i < this.caseLineCompDelTermArray.length; i++) {
            totalPercent = totalPercent + this.caseLineCompDelTermArray[i].delivery_TERM_RT;
          }
          this.totalDTCPercentage = totalPercent;
        },
        error => {
          CaseUtils.ReportHTTPError(error, "Getting Case Line PCC DTC Data");
        }
      );

    pDrawer.toggle();
  }

  onDeletePricingClick() {
    let deletePrompt: any =
    {
      text: 'Are you sure? This will delete all pricing data.',
      icon: 'question',
      width: 350,
      showCancelButton: true,
      cancelButtonText: 'No',
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes',
    };
    MessageMgr.swalFire(deletePrompt).then((result) => {
      if (result.value) {
        if (this.wm_HasFiscalYearDistribution) {
          let warningPrompt: any =
          {
            text: 'You have a Price Element/Fund combination with a '
              + 'Prior Year Obligation Value greater than $0. Do you want to continue?',
            icon: 'question',
            width: 350,
            showCancelButton: true,
            cancelButtonText: 'No',
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes',
          };
          MessageMgr.swalFire(warningPrompt).then((data) => {
            if (data.value) {
              this.caseRestService.deleteCaseLinePricing(
                this.theCaselinePK.case_ID,
                this.theCaselinePK.working_CASE_ID,
                this.theCaselinePK.working_CASE_VERSION_ID,
                this.theCaselinePK.case_MASTER_LINE_ID
              ).subscribe(
                value => {
                  Swal.fire({
                    position: 'center',
                    icon: 'success',
                    title: 'Successful',
                    showConfirmButton: false,
                    timer: 2000
                  })
                  //Reset wm_HasFiscalYearDistribution = false. Get ready for next delete
                  this.wm_HasFiscalYearDistribution = false;
                  //Clear the PCC and IPC fields.
                  this.resetPricingDataAfterDelete(true);
                  //Turn off Edit toggle
                  this.caseUIService.flipToDisabledService.next(DsamsConstants.CASE_LINE_EDITOR);
                  const editResponse: IEditResponseType = {
                    ID: DsamsConstants.CASE_LINE_EDITOR,
                    editToggle: false
                  };
                  this.caseUIService.caseEditService.next(editResponse);
                },
                err => {
                  CaseUtils.ReportHTTPError(err, "In Deleting Pricing Data");
                })
            }
          })
        } else {
          this.caseRestService.deleteCaseLinePricing(
            this.theCaselinePK.case_ID,
            this.theCaselinePK.working_CASE_ID,
            this.theCaselinePK.working_CASE_VERSION_ID,
            this.theCaselinePK.case_MASTER_LINE_ID
          ).subscribe(
            value => {
              Swal.fire({
                position: 'center',
                icon: 'success',
                title: 'Successful',
                showConfirmButton: false,
                timer: 2000
              })
              //Reset wm_HasFiscalYearDistribution = false. Get ready for next delete
              this.wm_HasFiscalYearDistribution = false;
              //Clear the PCC and IPC fields.
              this.resetPricingDataAfterDelete(true);
              //Turn off Edit toggle
              this.caseUIService.flipToDisabledService.next(DsamsConstants.CASE_LINE_EDITOR);
              const editResponse: IEditResponseType = {
                ID: DsamsConstants.CASE_LINE_EDITOR,
                editToggle: false
              };
              this.caseUIService.caseEditService.next(editResponse);
            },
            err => {
              CaseUtils.ReportHTTPError(err, "In Deleting Pricing Data");
            })
        }
      }
    })
  }

  resetPricingDataAfterDelete(isCaseLinePricingSummaryDefined: boolean) {
    if (isCaseLinePricingSummaryDefined) {
        this.caseLinePricingSummary.case_ID = null;
        this.caseLinePricingSummary.price_EFFECTIVE_DT = null;
        this.caseLinePricingSummary.price_EXPIRATION_DT = null;
        this.caseLinePricingSummary.case_LINE_ITEM_QY = null;
        this.caseLinePricingSummary.target_TOTAL_LINE_AM = null;
        this.caseLinePricingSummary.unit_ABOVE_LINE_COST_AM = null;
        this.caseLinePricingSummary.total_LINE_VALUE_AM = null;
        this.caseLinePricingSummary.totalInWorkAm = null;
    }
    this.price_EFFECTIVE_DT_string = null;
    this.price_EXPIRATION_DT_string = null;
    this.case_LINE_ITEM_QY_string = null;
    this.target_TOTAL_LINE_AM_string = null;
    this.unit_ABOVE_LINE_COST_AM_string = null;
    this.total_ABOVE_LINE_COST_AM_string = null;
    this.total_LINE_VALUE_AM_string = null;
    this.totalInWorkAm_string = null;
    this.military_ARTICLE_SERVICE_CD_string = null;
    this.mtds_NARRATIVE_DESCRIPTION_TX_string = null;
    this.pricing_METHOD_CD_string = null;
    this.theCaselinePK = null;
    this.caseUIService.setCaseLinePK(this.theCaselinePK);
    this.theExpandIPCPanel = false;
    for (let i = 0; i < this.dataSourcePricingTable.data.length; i++) {
      this.dataSourcePricingTable.data[i].expandIPCPanel = false;
    }
    this.clcDataList = [];
    this.dataSourcePricingTable = new MatTableDataSource(this.clcDataList);
    this.resetRelatedCalCostsFields(false);
    this.dataSourcePricingTable._updateChangeSubscription();
  }

  /* Open the MTDS Dialog COPIED from - Civilian Personnel dialog
   * Author: Jeff Sniffen
   * Date: 7/20/2021
   */
  openMtdsDialog(pClcElement: any, pIndex: number): any {
    this.caseLinePricingSummary.caseLineComponentList = this.clcDataList;
    const dataForPopup: caseLineComponentForCivilianPopup = {
      civilian_FISCAL_YEAR_ID: pClcElement.civilian_FISCAL_YEAR_ID,
      civilian_PAYROLL_COST_AM: pClcElement.civilian_PAYROLL_COST_AM,
      civilian_PAYROLL_CATEGORY_CD: pClcElement.civilian_PAYROLL_CATEGORY_CD
    };
    this.dialog.open(MtdsComponent, {
      width: '80em',
      height: '60em',
      data: {
        caseLineData: this.caseLinePricingInfoData,
        caseVersionData: this.caseLinePricingSummary.theWorkingCaseVersionId,
        caseLinePricingSummaryForPopup: this.caseLinePricingSummary,
        clcElementForCivilianPersonnelForPopup: dataForPopup,
        indexForElement: pIndex,
        clcElementData: pClcElement
      }
    });
    this._popupMtdsIndex = pIndex;
  }

  /* Open the Civilian Personnel Dialog */
  openCivilianPersonnelDialog(pClcElement: any, pIndex: number, pFiscalYearArray: any): any {
    this._popupCivIndex = pIndex;
    this.caseLinePricingSummary.caseLineComponentList = this.clcDataList;
    this.dialog.open(CivilianPersonnelComponent, {
      width: '40em',
      height: '27em',
      data: {
        clcElementForCivilianPersonnelForPopup: pClcElement,
        indexForElement: pIndex,
        fiscalYearArray: pFiscalYearArray
      }
    });
  }


  /* Open the Publication Dialog */
  openPublicationDialog(pPublicationElement: any, pIndex: number): any {
    this._popupPubIndex = pIndex;
    this.caseLinePricingSummary.caseLineComponentList = this.clcDataList;
    this.dialog.open(PublicationsComponent, {
      width: '20em',
      height: '20em',
      data: {
        publicationElementForPublicationsForPopup:
        {
          publication_CATEGORY_CD: !pPublicationElement.publication_CATEGORY_CD ? "" : pPublicationElement.publication_CATEGORY_CD,
          publication_PAGE_AM: !pPublicationElement.publication_PAGE_AM ? 0 : pPublicationElement.publication_PAGE_AM
        },
        indexForElement: pIndex
      }
    });
  }

  /* Open the DTC Dialog */
  openDTCDialog(pDTCElement: any, pIndex: number): any {
    this._popupDtcIndex = pIndex;
    this.caseLinePricingSummary.caseLineComponentList = this.clcDataList;
    this.dialog.open(DTCComponent, {
      width: '35em',
      height: '25em',
      data: {
        caseLinePricingSummaryForPopup: this.caseLinePricingSummary,
        dtcElementForDTCForPopup: pDTCElement,
        caseLineCompDelTermList: this.clcDataList[pIndex].caseLineCompDelTermList,
        indexForElement: pIndex
      }
    });
  }

  // Subscribe to case ui service for option Update Case In Review
  subscribeToOptionCaseInReview() {
    this.caseUIService.optionSelectedUCIR.subscribe((value) => {
       // Set edit slider to on
      if (value) {
    
        const editResponse: IEditResponseType = {
          ID: DsamsConstants.CASE_LINE_EDITOR,
          editToggle: true
        };
        this.caseUIService.caseEditService.next(editResponse);
      }
   
      });
  }
 

  // Subscribe to case ui service for option Update Case In Proposed
  subscribeToOptionCaseInProposed() {
    this.caseUIService.optionSelectedUCIP.subscribe((value) => {
      if (value) {
    
        const editResponse: IEditResponseType = {
          ID: DsamsConstants.CASE_LINE_EDITOR,
          editToggle: true
        };
        this.caseUIService.caseEditService.next(editResponse);
      }
    });
  }

  // Subscribe to case ui service for option Pen and Ink
  subscribeToOptionCasePenInk() {
    this.caseUIService.optionSelectedUCPI.subscribe((value) => {
      if ( value) {
         const editResponse: IEditResponseType = {
          ID: DsamsConstants.CASE_LINE_EDITOR,
          editToggle: true
        };
        this.caseUIService.caseEditService.next(editResponse);
      }
    });
  }

  saveMilestone() {
    this.caseUIService.milestoneAddService.pipe(take(1)).subscribe((value) => {
      if (this.checkDataChanged()) {
        if (value === "PENINK") {
          this.openMilestoneCommentDialog("PENINK");
        } else if (value === "CWDREDIT") {
          this.openMilestoneCommentDialog("CWDREDIT");
        } else if (value === "CWDPEDIT") {
          this.openMilestoneCommentDialog("CWDPEDIT")
        }
      }
    });
  }

  /* Open the Pen & Ink Milestone Comment Dialog */
  openMilestoneCommentDialog(pMilestoneId: string): any {
    const dialogRef = this.dialog.open(MilestoneCommentComponent, {
      width: '50em',
      height: '30em',
      data: {
        caseId: this.caseLinePricingInfoData.working_CASE_ID,
        versionId: this.caseLinePricingInfoData.working_CASE_VERSION_ID,
        milestoneId: pMilestoneId,
       // begin DSAMS-5933 09/22 DB
       activityId: sessionStorage.getItem(LinePricingComponent.USER_ACTIVITY_ID),
       userId: sessionStorage.getItem(LinePricingComponent.USER_ID)
       // end DSAMS-5933 09/22 DB
      }
    });
    if (!this._milestoneDialogSubscription) {
      this._milestoneDialogSubscription = dialogRef.afterClosed().subscribe((data) => {
        if (data === "Ok") {
          if (!this._mielstoneCommentNullSubscription) {
            this._mielstoneCommentNullSubscription = this.caseUIService.isMilestoneCommentNull.subscribe((value) => {
              if (!value) {
                this._promptFinancialCheck = true;
                this.saveButtonOnClick()
                this.caseUIService.setNotifyToSetDefaultOption(true);
                this.caseUIService.flipToDisabledService.next(DsamsConstants.CASE_LINE_EDITOR);
                const editResponse: IEditResponseType = {
                  ID: DsamsConstants.CASE_LINE_EDITOR,
                  editToggle: false
                };
                this.caseUIService.caseEditService.next(editResponse);
                this.caseUIService.optionSelectCounter.next(0);
              }
            });
          }
        }
      });
    }
  }

  saveButtonCheckIfOption() {
    this.caseUIService.milestoneAddService.pipe(take(1)).subscribe((value) => {
      if (value == "PENINK" || value == "CWDREDIT" || value == "CWDPEDIT") {
        this.saveMilestone();
      }
      else {
        this.saveButtonOnClick();
      }
    });
  }

 }