import { CaseLineIPCStatusModel } from "./case-line-ipc-status-model";
import { IndirectPricingComponentModel } from "./indirect-pricing-component-model";

export interface CaseLineIPCModel {
    entityName?: string,
    status?: string,

    case_LINE_IPC_STATUS_CD?: string,
    case_LINE_IPC_REASON_TX?: string,
    case_LINE_IPC_PERCENT_RT?: string,
    case_LINE_COMPONENT_ID?: number,
    case_LINE_IPC_WAIVER_COST_AM?: number,
    case_LINE_IPC_UNIT_COST_AM?: number,
    case_LINE_IPC_TOTAL_COST_AM?: number,
    ipc_NUMBER_ID?: string,
    fund_CD?: string,
    price_ELEMENT_CD?: string,
    theIpcNumberId?: IndirectPricingComponentModel,
    theCaseLineIpcStatusCd?: CaseLineIPCStatusModel,
}