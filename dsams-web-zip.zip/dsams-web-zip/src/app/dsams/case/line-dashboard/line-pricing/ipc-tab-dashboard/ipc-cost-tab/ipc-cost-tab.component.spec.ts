import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IpcCostTabComponent } from './ipc-cost-tab.component';

describe('IpcCostTabComponent', () => {
  let component: IpcCostTabComponent;
  let fixture: ComponentFixture<IpcCostTabComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IpcCostTabComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IpcCostTabComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
