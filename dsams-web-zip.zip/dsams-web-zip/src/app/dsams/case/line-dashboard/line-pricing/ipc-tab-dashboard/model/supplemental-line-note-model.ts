export interface SupplementalLineNoteModel {
    entityName?: string,
    status?: string,

    case_LINE_LIST_SEQUENCE_ID?: number,
    item_IDENTIFIER_TX?: string,
    list_ITEM_DESCRIPTION_TX?: string,
    case_LINE_LIST_ATTACHMENT_QY?: number,
    issue_UNIT_CD?: number,
    supply_SOURCE_NUMBER_ID?: number,
    supply_SOURCE_TITLE_NM?: string,
    item_NO_LEAD_QY?: number,
    supply_LINE_NOTE_SHIPPED_DT?: Date,
    case_LINE_LIST_UNIT_PRICE_AM?: number,
    clla_DELETION_IN?: boolean
}