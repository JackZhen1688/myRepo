import { DefaultPricingComponentModel } from "../default-pricing-component-model";

export interface  DefaultPricingComponentDTO extends DefaultPricingComponentModel{
    ipc_TITLE_NM?: string,
}