import { Component, OnInit, Input } from "@angular/core";
import { FormControl } from "@angular/forms";
import { Observable } from "rxjs";
import { map, startWith } from "rxjs/operators";
import { CustomerOrganizationRefList } from "src/app/dsams/case/model/dto/customer-organization";

/**
 * The Autocomplete Dropdown class is a custom mat-auto-complete Material component 
 * that allows you to wire it up to a reference table. 
 * 
 *  Author: David Huynh 
 *  Date:   06/15/2021
 */
@Component({
  selector: 'app-autocomplete-dropdown',
  templateUrl: './autocomplete-dropdown.component.html',
  styleUrls: ['./autocomplete-dropdown.component.css']
})

export class AutocompleteDropdownComponent implements OnInit {
  @Input() PlaceholderText: string = '';
  @Input() TooltipText: string;
  @Input() TooltipStyle: string = "mat-tooltip-style";
  @Input() FieldID: string;
  @Input() Required: boolean = false;
  @Input() DropdownDataList: string[];
  @Input() testList: CustomerOrganizationRefList[];
  dropdownControl = new FormControl();
  filteredOptions: Observable<string[]>;

  theDropdownDataList: string[] = [];
  testDropdownList: CustomerOrganizationRefList[] = [];
  testfilteredOptions: Observable<CustomerOrganizationRefList[]>;

  ngOnInit() {
    this.theDropdownDataList = this.DropdownDataList;
    this.testDropdownList = this.testList;
    this.testfilteredOptions = this.dropdownControl.valueChanges.pipe(
      startWith(''),
      map(value => this.testfilter(value))
    );
  }

  private _filter(value: string): string[] {
    const filterValue = value.toLowerCase();
    return this.theDropdownDataList.filter(option => option.toLowerCase().indexOf(filterValue) === 0);
  }
  private testfilter(value: string): CustomerOrganizationRefList[] {
    const filterValue = value.toLowerCase();
    return this.testDropdownList.filter(option => option.customer_ORGANIZATION_ID.toLowerCase().indexOf(filterValue) === 0);
  }
}
