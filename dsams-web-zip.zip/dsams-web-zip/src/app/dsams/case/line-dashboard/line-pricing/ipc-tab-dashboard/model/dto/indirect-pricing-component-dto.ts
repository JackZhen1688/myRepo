import { IndirectPricingComponentModel } from "../indirect-pricing-component-model";

export interface  IndirectPricingComponentDto extends IndirectPricingComponentModel{
    isDeleteAllowed?:boolean,
}