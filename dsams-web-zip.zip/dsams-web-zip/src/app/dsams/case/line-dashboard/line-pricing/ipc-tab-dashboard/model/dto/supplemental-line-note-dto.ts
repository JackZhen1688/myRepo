import { FieldDisabledMap } from "src/app/dsams/case/model/field-disabled-map";
import { SupplementalLineNoteModel } from "../supplemental-line-note-model";

export interface supplementalLineNoteDto extends SupplementalLineNoteModel{
    case_ID?: number,
    working_CASE_ID?: number,
    working_CASE_VERSION_ID?: number,
    case_MASTER_LINE_ID?: number,
    case_LINE_COMPONENT_ID?: number,
    case_LINE_LIST_ATTACHMENT_ID?: number,
    total_COST?: number,
    wm_TOTAL_COST?: string,
    wm_case_LINE_LIST_UNIT_PRICE_AM?: string,
    isFieldDisabled:FieldDisabledMap,
}