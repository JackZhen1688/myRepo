import { Component, OnInit, ViewChild } from '@angular/core';
import { CaseUIService } from '../../services/case-ui-service';
import { BehaviorSubject, Subscription } from 'rxjs';
import { ifaceCaseLineData, ifaceCaseMasterLine, ifaceCaseMasterLineEntity, ifaceGenericRefItem } from '../../model/case-line-model';
import { CaseRestfulService } from '../../services/case-restful.service';
import { CustomerOrganizationRefList } from '../../model/dto/customer-organization';
import { LineUtils } from '../line-utils';
import { CaseLineRelatedInfoType } from '../../model/case-line-related-info-type';
import { CaseUtils } from '../../utils/case-utils';
import { FormControl, Validators } from '@angular/forms';
import { DsamsConstants } from 'src/app/dsams/dsams.constants';
import { IEditResponseType } from '../../model/edit-response-type';
import { Router } from '@angular/router';
import { MessageMgr } from '../../validation/message-mgr';
// begin DSAMS-5867 08/22 DB 
import { LineDeliveryComponent } from '../line-delivery/line-delivery.component';
import { LineDetailsComponent } from '../line/line-details.component'
import {LinePricingComponent } from '../line-pricing/line-pricing.component';
import { LineSublineRefComponent } from '../line-reference.component';
import { DsamsRestfulService } from '../../../../dsams/services/dsams-restful.service';
// end DSAMS-5867 08/22 DB
// begin DSAMS-5912 09/22 DB
import { ImessageData } from 'src/app/dsams/interfaces/imessage-data';
import { DsamsUserMessageService } from '../../../services/dsams-user-message.service';
// end DSAMS-5912 09/22 DB
@Component({
  selector: 'app-line-subdashboard',
  templateUrl: './line-subdashboard.component.html',
  styleUrls: ['./line-subdashboard.component.css',
    '../common-CSS.component.css']
})
export class LineSubdashboardComponent implements OnInit {
  private static CASE_LINE_EDITOR_STR: string = DsamsConstants.CASE_LINE_EDITOR;
  private static USER_ID: string = "userId";
  private static USER_ACTIVITY_ID : string = "userActivityId";
  // begin DSAMS-5867 08/22 DB
  private getLineSublineRefData: LineSublineRefComponent;
  @ViewChild(LineDeliveryComponent, { static: false }) ldlvComp: LineDeliveryComponent;
  @ViewChild(LineDetailsComponent, { static: false }) ldtlComp: LineDetailsComponent;
 public  _lprcComp: LinePricingComponent;
 
  // begin DSAMS-5983 09/22 DB
  static LOCK_SESSION_ID = "CaseLineLockSessionId";
  public messageData: ImessageData;
  
// end DSAMS-5983
// end DSAMS-5867 08/22 DB
  _editSubscription: Subscription = null;
  _caseUIServiceSubscription: Subscription;
  caseMasterLineInfoEntity: ifaceCaseMasterLineEntity = {};
  caseMasterLineData: ifaceCaseMasterLine = {};
  caseLineInfoData: ifaceCaseLineData;
  caseLineNumberList: any[] = [];

  caseLineRelatedInfoData: CaseLineRelatedInfoType;
  customerOrgList: CustomerOrganizationRefList[];
  customerStructureList: ifaceCaseLineData;
  selectedTab: any;
  emptyString: string = '';
  emptyObject: ifaceGenericRefItem = { value_CD: '', value_TITLE_NM: '', value_TITLE_DESC: '' };
  hideBECtry: boolean = false;
  lineNumber: string = '';
  sublineNumber: string = '';
  allowChange: boolean = false;
  ActiveBtnColor: any = '#e7eff6';
  ActiveBgColor: any = 'white';
  InactiveBtnColor = 'darkgrey';
  ActiveDeleteBtnColor = 'red'
  deleteBgColor: string = this.InactiveBtnColor;
  refreshBgColor: string = this.InactiveBtnColor;
  ActiveRefreshBtnColor = "0f9e7b";
  isDeleteAllowed = true;
  isRefreshAllowed: boolean = true;
  isLoading: BehaviorSubject<boolean> = new BehaviorSubject(false);
  lineNum = new FormControl('', [Validators.required,
  Validators.maxLength(3),
  Validators.minLength(3),
  Validators.min(1),
  Validators.max(999),
  Validators.pattern(RegExp("^(?!0{3})[0-9][0-9][0-9]", "i"))]);
  sublineNum = new FormControl('', [Validators.required,
  Validators.maxLength(1),
  Validators.minLength(1),
  Validators.pattern(RegExp("^(?!0{1})[a-z|A-Z]", "i"))]);


  maxLines: number = 0;
  count: number = 0;
  isLineHeaderDisabled: boolean = true;
  isSpecificFieldDisabled: boolean = true;
  isSpecificSublineFieldDisabled: boolean = true;
  exists: boolean = false;
  getMaxLinesSubscription: Subscription = new Subscription();
  lineExists: boolean = false;
  sublineExists: boolean = false;
  caseVersionStatusDevelopmentType: string = "D";
  allowSublineChange: boolean;
  allowLineChange: boolean;
  isRefreshButtonVisible: boolean = false;

  constructor(private caseUIService: CaseUIService, private router: Router,
     // begin DSAMS-5983 09/22 DB
    private messageService: DsamsUserMessageService,
     // end DSAMS-5983 09/22 DB
    private dsamsRestService: DsamsRestfulService,
    private caseRestService: CaseRestfulService) { }

  ngOnInit() {

     // begin DSAMS-5983 09/22 DB
    
   
    // end DSAMS-5983 09/22 DB
    //set initial values for Case Line data
    this.initializeCaseLineInfoData();

    this.subscribeCaseLineInfo();

    this._caseUIServiceSubscription = this.caseUIService.getCaseLineRelatedInfoValues().subscribe((value) => {
      this.caseLineRelatedInfoData = value;
      if (!!this.caseLineInfoData && !!this.caseLineRelatedInfoData && !!this.caseLineRelatedInfoData.case_VERSION_TYPE_CD) {
        this.caseLineInfoData.wm_CASE_VERSION_TYPE_CD = this.caseLineRelatedInfoData.case_VERSION_TYPE_CD;
      }
      this.setRefreshVisible();
      if (!!this.caseLineInfoData && !this.caseLineRelatedInfoData) {
        this.caseLineRelatedInfoData = {
          case_CUSTOMER_ORGANIZATION_ID: this.caseLineInfoData.customer_ORGANIZATION_ID,
          case_VERSION_TYPE_CD: this.caseLineInfoData.wm_CASE_VERSION_TYPE_CD,
          security_ASSISTANCE_PROGRAM_CD: this.caseLineInfoData.security_ASSISTANCE_PROGRAM_CD,
          implementing_AGENCY_ID: this.caseLineInfoData.implementing_AGENCY_ID,
          customer_REQUEST_ID: 0
        }
        if (!!this.caseLineRelatedInfoData) {
          this.caseUIService.setCaseLineRelatedInfoValues(this.caseLineRelatedInfoData);
        }
      }
      if (!!this.caseLineInfoData)
        if (!!this.caseLineInfoData.case_ID) this.getDataForNumberList();
    });

    //Set iniital values to avoid display undefined values error
    if (this.caseLineInfoData == null) {
      //set initial values for Case Line data
      this.initializeCaseLineInfoData();
    }
    else {
      this.setSpecificFieldProperty();

      //Jeff - moved this code...
      if (!!this.caseLineInfoData.LINESUBLINESEQVIR) {
        this.lineNumber = this.caseLineInfoData.LINESUBLINESEQVIR.substring(0, 3);
      }
      this.sublineNumber = this.caseLineInfoData.wm_USER_CASE_SUBLINE_TX;
    }

    //subscribe to Edit toggle
    this.subscribeToEditToggle();
    this.setUserActivityId();
  }

  getDataForNumberList() {
    this.caseRestService.getCaseLineListFromServer(this.caseLineInfoData.working_CASE_ID,
      this.caseLineInfoData.working_CASE_VERSION_ID)
      .subscribe(
        data => {
          for (var i = 0; i <= data.caseLineList.length - 1; i++) {
            this.caseLineNumberList.push(data.caseLineList[i]);
          }
          //this.caseUIService.previousLineNumber.next(data.caseLineList.length - 1);
        })
  }

  updateLineNumber(event) { //Line Number
    if (event.target.value == null || parseInt(event.target.value) == 0) {
      this.lineNum.invalid;
    } else {
      for (var t = 0; t <= this.caseLineNumberList.length - 1; t++) {
        if (parseInt(event.target.value) == parseInt(this.caseLineNumberList[t].wm_USER_CASE_LINE_NUMBER_ID)) {
          this.lineExists = true;
          this.lineNum.invalid;
          break;
        }
      }
    }
    if (!this.lineExists && this.lineNum.valid) {
      this.caseLineInfoData.isEntityNew = true;
      this.caseLineInfoData.isDataChanged = true;
      this.caseLineInfoData.isLineNumberChanged = true;
      this.caseLineInfoData.wm_USER_CASE_LINE_NUMBER_ID = event.target.value;
      this.caseLineInfoData.LINESUBLINESEQVIR = event.target.value;
    } else {
      MessageMgr.displaySinglePopupError("E303");
      this.lineExists = false;
      this.lineNum.valid;
    }
  }

  updateSublineNumber(event) { //Subline Number
    if (event.target.value == null || parseInt(event.target.value) == 0) {
      this.sublineNum.invalid;
    } else {
      for (var t = 0; t <= this.caseLineNumberList.length - 1; t++) {
        if (parseInt(event.target.value) == parseInt(this.caseLineNumberList[t].wm_USER_CASE_SUBLINE_TX)) {
          this.sublineExists = true;
          this.sublineNum.invalid;
          break;
        }
      }
    }
    if (!this.sublineExists && this.sublineNum.valid) {
      this.caseLineInfoData.isEntityNew = true;
      this.caseLineInfoData.isDataChanged = true;
      this.caseLineInfoData.isLineNumberChanged = true;
      this.caseLineInfoData.wm_USER_CASE_SUBLINE_TX = event.target.value;
    } else {
      MessageMgr.displaySinglePopupError("E304");
      this.sublineExists = false;
      this.sublineNum.valid;
    }
  }

  //Set enable/Disable to specific fields
  setSpecificFieldProperty() {
    //Tollgle the edit slider
    if (this.caseLineInfoData.status == DsamsConstants.ENT_NEW.toString()) {
      //all fields are enabled in New mode
      this.isSpecificSublineFieldDisabled = false;
      this.isSpecificFieldDisabled = false;
    }
  }

  // Subscribe to edit toggle event
  subscribeToEditToggle() {
    if (!this._editSubscription) {
      this._editSubscription = this.caseUIService
        .caseEditService
        .subscribe((pResponse: IEditResponseType) => {
          if (pResponse && pResponse.ID === LineSubdashboardComponent.CASE_LINE_EDITOR_STR) {
            //  console.log('subdashboard*****',pResponse.ID,pResponse.editToggle)
            this.isLineHeaderDisabled = !pResponse.editToggle;
            if (!CaseUtils.isBlankStr(this.caseLineInfoData.wm_USER_CASE_SUBLINE_TX))
              this.isSpecificSublineFieldDisabled = true;
            else if (!this.isLineHeaderDisabled) this.isSpecificSublineFieldDisabled = false;
          }
          this.setRefreshStatus(this.isLineRefreshAllowed(this.caseLineInfoData));
          if (!this.isLineHeaderDisabled) {
            if (CaseUtils.isBlankStr(this.caseLineInfoData.wm_USER_CASE_SUBLINE_TX)) {
              this.caseUIService.allowLineChange.next(LineUtils.isLineEditable(this.caseLineInfoData));
              this.caseUIService.allowSublineChange.next(false);
              this.caseUIService.allowLineChange.subscribe((value) => {
                this.allowLineChange = value;
              })
            } else {
              this.caseUIService.allowSublineChange.next(LineUtils.isSublineEditable(this.caseLineInfoData));
              this.caseUIService.allowLineChange.next(false);
              this.caseUIService.allowSublineChange.subscribe((value) => {
                this.allowSublineChange = value;
              })
            }
          } else {
            this.caseUIService.allowLineChange.next(false);
            this.caseUIService.allowSublineChange.next(false);
          }
        },
          err => {
            CaseUtils.ReporError("Error in Line List responding to edit toggle");
          }
        );
    }
  }

  
  

  setDeleteStatus(pEnable: boolean) {
    if (pEnable) {
      this.isDeleteAllowed = true;
      this.deleteBgColor = this.ActiveDeleteBtnColor;
    }
    else {
      this.isDeleteAllowed = false;
      this.deleteBgColor = this.InactiveBtnColor;
    }
  }

  /**
   * Set Refresh button enabledness.
   */
  private setRefreshStatus(pEnable: boolean) {
    if (pEnable && !this.isLineHeaderDisabled) {
      this.isRefreshAllowed = true;
      this.refreshBgColor = this.ActiveRefreshBtnColor;
    }
    else {
      this.isRefreshAllowed = false;
      this.refreshBgColor = this.InactiveBtnColor;
    }
  }

  /**
   * Set Refresh button visibility.
   */
  private setRefreshVisible() {
    if (!!this.caseLineInfoData)
      this.isRefreshButtonVisible = (this.caseLineInfoData.wm_CASE_VERSION_TYPE_CD === "A" ||
        this.caseLineInfoData.wm_CASE_VERSION_TYPE_CD === "M") &&
        !(this.caseLineInfoData.wm_CASE_LINE_LOI_IN ||
          this.caseLineInfoData.case_USAGE_INDICATOR_CD === "I");
  }

  /**
 * Determine if a case line refresh is allowed.
 * @param pCaseLineInfoData ifaceCaseLineData
 * @returns true if a refresh is allowed, false if not.
 */
  private isLineRefreshAllowed(pCaseLineInfo: ifaceCaseLineData): boolean {
    if (pCaseLineInfo.wm_CASE_LINE_LOI_IN ||
      pCaseLineInfo.change_ACTION_CD === "U" ||
      pCaseLineInfo.change_ACTION_CD === "A" ||
      pCaseLineInfo.status === DsamsConstants.ENT_NEW.toString()) {
      return false;
    }

    // Disable for line/subline if the opposite is priced.
    if (pCaseLineInfo.wm_PARENT_IS_PRICED || pCaseLineInfo.wm_HAS_SUBLINES_PRICED) {
      return false;
    }

    return true;
  }

  /**
   * Get the Subline textbox class.
   */
  getSublineClass() {
    let cls: string = this.hideBECtry ? "col-sm-2" : "col-sm-1";
    cls += " d-inline";
    return cls;
  }

  /**
   * Determine if we're a subline (for display purposes)
   */
  isSubLine(): boolean {
    return !!this.caseLineInfoData.wm_USER_CASE_SUBLINE_TX && this.caseLineInfoData.wm_USER_CASE_SUBLINE_TX !== "";
  }

  // begin DSAMS-5867 07/22 DB
  refreshCaseLineEvent(pCaseLineInfo: ifaceCaseLineData) {
     this.isLoading.next(true);
      let cmlId: number = pCaseLineInfo.case_MASTER_LINE_ID;
      let caseId: number = pCaseLineInfo.case_ID;
      let csvId: number = pCaseLineInfo.working_CASE_VERSION_ID
      let wCaseId = pCaseLineInfo.working_CASE_ID;
      this.caseRestService.restoreCaseLineData(cmlId, caseId, csvId, wCaseId, 0).subscribe((pUpdatedCaseLine: ifaceCaseLineData) => {
        this.caseLineInfoData = pUpdatedCaseLine;
        this.caseUIService.setCaseLineInfoValues(this.caseLineInfoData);
        this.ldtlComp.getLineDetailsReferenceData();
        this.ldlvComp.getDeliveryReferenceData();
       
        this.ldtlComp.getLineSublineRefData.setResetDynamicRefList(true);
        this.ldlvComp.initializeDeliveryDataFields();
        this._lprcComp.populateCaseLinePricingSummary();
        this.isLoading.next(false);
      },
        err => {
          CaseUtils.ReportHTTPError(err, "Refreshing Case Line from Line Header");
          this.isLoading.next(false);
        });
    
  }
  //end  DSAMS-5867 07/22 DB

  setUserActivityId() {
    let actId : string = sessionStorage.getItem(LineSubdashboardComponent.USER_ACTIVITY_ID);
    if (actId === null  || actId.length < 2) {
    this.dsamsRestService.getUserInfo()
    .subscribe(
      data => { 
        if (data.userProfile.activityId != null) {
            sessionStorage.setItem(LineSubdashboardComponent.USER_ACTIVITY_ID, data.userProfile.activityId);
          } else {
            sessionStorage.Item(LineSubdashboardComponent.USER_ACTIVITY_ID, "");
          }

        })
    }
   
  }


  /*
   * This will perform the refresh (after passing the requisite errors and warnings).
   */
  onRefreshBtnClick(pCaseLineInfo: ifaceCaseLineData) {
    if (pCaseLineInfo.change_ACTION_CD === "D" &&
      (pCaseLineInfo.case_LINE_MARK_FOR_DELETION_IN == '1' || pCaseLineInfo.case_LINE_MARK_FOR_DELETION_IN == 'true')) {
      LineUtils.promptUserToCaseLineRefreshForDeleted().then((resultConfirm) => {
        if (resultConfirm.value == true) {
          // Display applicable errors. 
          // Error if sublines are priced or have all A-sublines.
          if (pCaseLineInfo.wm_HAS_SUBLINES_A || pCaseLineInfo.wm_HAS_SUBLINES_PRICED) {
            MessageMgr.displaySinglePopupError("E306");
            return;
          }

          // Error if parent line is priced.
          if (pCaseLineInfo.wm_PARENT_IS_PRICED) {
            MessageMgr.displaySinglePopupError("E311");
            return;
          }

          // If it's a D-subline, and the parent line is D, then error.
          if (!!pCaseLineInfo.wm_USER_CASE_SUBLINE_TX &&
            pCaseLineInfo.wm_USER_CASE_SUBLINE_TX !== "" &&
            pCaseLineInfo.change_ACTION_CD === "D" &&
            pCaseLineInfo.wm_PARENT_CHANGE_ACTION_CD === "D") {
            MessageMgr.displaySinglePopupError("E309");
            return;
          }

          // If it's a D-subline, and the parent line is priced, then error.
          if (!!pCaseLineInfo.wm_USER_CASE_SUBLINE_TX &&
            pCaseLineInfo.wm_USER_CASE_SUBLINE_TX !== "" &&
            pCaseLineInfo.change_ACTION_CD === "D" &&
            pCaseLineInfo.wm_PARENT_IS_PRICED) {
            MessageMgr.displaySinglePopupError("E310");
            return;
          }

          this.isLoading.next(true);
          this.caseRestService.refreshCaseLine(pCaseLineInfo).subscribe((pUpdatedCaseLine: ifaceCaseLineData) => {
            this.isLoading.next(false);
            MessageMgr.displaySinglePopupInfo("I308");
            // Update the sub-arrays from pUpdatedCaseLine.
            this.caseLineInfoData.caseLineAssistanceTypeList = pUpdatedCaseLine.caseLineAssistanceTypeList;
            this.caseLineInfoData.caseLineOfferReleaseList = pUpdatedCaseLine.caseLineOfferReleaseList;
            this.caseLineInfoData.caseLineDeliveryItemList = pUpdatedCaseLine.caseLineDeliveryItemList;
            this.caseLineInfoData.caseLineDeliveryTermList = pUpdatedCaseLine.caseLineDeliveryTermList;
            this.caseLineInfoData.change_ACTION_TITLE_NM = "Unaffected";
            this.caseLineInfoData.change_ACTION_CD = "U";
            this.caseLineInfoData.case_LINE_MARK_FOR_DELETION_IN = "false"
            this.setRefreshStatus(false);
            this.caseUIService.setResetCaseLineFromRefreshButton(this.caseLineInfoData);
          },
            err => {
              CaseUtils.ReportHTTPError(err, "Refreshing Case Line from Line Header");
              this.isLoading.next(false);
            });
        }
      });
    }
    else {     // Not D
      LineUtils.promptUserToCaseLineRefresh().then((resultConfirm) => {
        if (resultConfirm.value == true) {
          if (pCaseLineInfo.wm_HAS_SUBLINES_A) {
            MessageMgr.displaySinglePopupError("E306");
            return;
          }
          this.isLoading.next(true);
          this.caseRestService.refreshCaseLine(pCaseLineInfo).subscribe((pUpdatedCaseLine: ifaceCaseLineData) => {
            this.isLoading.next(false);
            MessageMgr.displaySinglePopupInfo("I308");
            // Update the sub-arrays from pUpdatedCaseLine.
            this.caseLineInfoData.caseLineAssistanceTypeList = pUpdatedCaseLine.caseLineAssistanceTypeList;
            this.caseLineInfoData.caseLineOfferReleaseList = pUpdatedCaseLine.caseLineOfferReleaseList;
            this.caseLineInfoData.caseLineDeliveryItemList = pUpdatedCaseLine.caseLineDeliveryItemList;
            this.caseLineInfoData.caseLineDeliveryTermList = pUpdatedCaseLine.caseLineDeliveryTermList;
            this.caseLineInfoData.change_ACTION_TITLE_NM = "Unaffected";
            this.caseLineInfoData.change_ACTION_CD = "U";
            this.caseLineInfoData.case_LINE_MARK_FOR_DELETION_IN = 'false';
            this.setRefreshStatus(false);
            this.caseUIService.setResetCaseLineFromRefreshButton(this.caseLineInfoData);
          },
            err => {
              CaseUtils.ReportHTTPError(err, "Refreshing Case Line from Line Header");
              this.isLoading.next(false);
            });
        }
      });
    }
  }


  subscribeCaseLineInfo() {
    const BENEFITING_COUNTRY: string = "BE";
    this._caseUIServiceSubscription = this.caseUIService.getCaseLineInfoValues().subscribe((value) => {
      this.caseLineInfoData = value;
      if (!!this.caseLineInfoData) {
        if (!!this.caseLineInfoData.LINESUBLINESEQVIR) {
          this.lineNumber = this.caseLineInfoData.LINESUBLINESEQVIR.substring(0, 3);
        }
        this.sublineNumber = this.caseLineInfoData.wm_USER_CASE_SUBLINE_TX;
      }

      if ((!!this.caseLineInfoData) &&
        (this.caseLineInfoData.case_CUSTOMER_TYPE_CD) &&
        this.caseLineInfoData.case_CUSTOMER_TYPE_CD.toUpperCase() == BENEFITING_COUNTRY) {
        this.hideBECtry = false;
        //FR3
        this.caseLineInfoData.customerStructureList = [];
        this.caseLineInfoData.customerStructureList.push(this.emptyObject);
        this.caseRestService.getCaseLineRefList("CUSTOMER_STRUCTURE").subscribe(value => {
          for (var i = 0; i < value.length; i++) {
            if (this.caseLineInfoData.customerStructureList && value[i]) {
              this.caseLineInfoData.customerStructureList.push(value[i]);
            }
          }
        })
      }
      else this.hideBECtry = true;

      if (!!this.caseLineInfoData) {
        this.setDeleteStatus(LineUtils.isLineDeleteAllowed(this.caseLineInfoData));
        this.setRefreshStatus(this.isLineRefreshAllowed(this.caseLineInfoData));
      }
    });
    this.refreshCaseLineInfoData();
  }

  refreshCaseLineInfoData() {
    if (!!this.caseLineInfoData) this.caseUIService.setCaseLineInfoValues(this.caseLineInfoData);
    //  console.log('**** refreshCaseLineInfoData==', this.caseLineInfoData)
  }

  //this is for Line tab
  initializeCaseLineInfoData() {
    //since it is an interface, we need to initialize them
    //Set iniital values to avoid display undefined values error
    this.caseLineInfoData = {
      //this is for Header tab
      wm_USER_CASE_LINE_NUMBER_ID: '',
      wm_USER_CASE_SUBLINE_TX: '',
      wm_CASE_VERSION_TYPE_CD: '',
      wm_CASE_LINE_LOI_IN: false,
      wm_CML_SERVICES_COMPLETE_IN: false,
      wm_EXCLUSION_IN: false,
      change_ACTION_TITLE_NM: '',
      customer_ORGANIZATION_ID: '',
      LINESUBLINESEQVIR: '',
    }
  }

  ngOnDestroy() {
    
    //clear the  cache for caseLineInfoData
    this.initializeCaseLineInfoData();
    //clear out the selected case line entity 
    this.caseUIService.setCaseLineInfoValues(this.caseLineInfoData);
    if (this._caseUIServiceSubscription) this._caseUIServiceSubscription.unsubscribe();
    if (this._editSubscription) this._editSubscription.unsubscribe();
  }

  getCustomerOrganizationList() {
    this.customerOrgList = [new CustomerOrganizationRefList];
    this.caseRestService.getCustomerOrganizationList().subscribe(
      data => {
        for (var i = 0; i <= data.length - 1; i++) {
          this.customerOrgList.push(data[i]);
        }
      })
  }

  //FR3
  getCustomerStructureList() {
    this.customerOrgList = [new CustomerOrganizationRefList];
    this.caseRestService.getCustomerOrganizationList().subscribe(
      data => {
        for (var i = 0; i <= data.length - 1; i++) {
          this.customerOrgList.push(data[i]);
        }
      })
  }

  //Subscription to line change
  subscribeToCaseLineNumberUpdate() {
    this._caseUIServiceSubscription = this.caseUIService.caseLineNumberUpdate.subscribe((value) => {
      this.lineNumber = value.toString();
    });
  }

  isDataReadyForDelete(): boolean {
    const CLOSURE_STATUS_FINAL: string = '3';
    const CLOSURE_STATUS_INTERIM: string = '2';
    const CLOSURE_STATUS_SSC: string = '1';
    if (this.caseLineInfoData.wm_CASE_LINE_LOI_IN
      || this.caseLineInfoData.wm_CML_CLOSURE_STATUS_CD == CLOSURE_STATUS_FINAL
      || this.caseLineInfoData.wm_CML_CLOSURE_STATUS_CD == CLOSURE_STATUS_INTERIM
      || this.caseLineInfoData.wm_CML_CLOSURE_STATUS_CD == CLOSURE_STATUS_SSC) {
      return false;
    }
    return true;
  }

  checkCLFinancialData() {
    this.caseRestService.checkCaseLineFinancialData(
      LineUtils.getMappingCaseLineEntityForFinancial(this.caseLineInfoData)).subscribe(
        hasFinData => {
          if (hasFinData) {
            MessageMgr.swalFire({
              text: 'You have a Price Element/Fund combination with a Prior Year Obligation Value greater than $0.  Do you want to continue?',
              icon: 'warning',
              width: 400,
              showCancelButton: true,
              cancelButtonText: 'No',
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              confirmButtonText: 'Yes',
            }).then((result) => {
              if (result.value) {
                //need to set status to delete
                this.caseLineInfoData.change_ACTION_CD = LineUtils.CHANGE_ACTION_DELETED;
                this.caseLineInfoData.change_ACTION_TITLE_NM = 'Deleted';
              }
            })
          }
          else {
            this.caseLineInfoData.change_ACTION_CD = LineUtils.CHANGE_ACTION_DELETED;
            this.caseLineInfoData.change_ACTION_TITLE_NM = 'Deleted';
          }
        },
        err => {
          CaseUtils.ReportHTTPError(err, "checking Case Line financial data from server");
          this.isLoading.next(false);
        }
      );
  }

  //mark delete status for logical delete
  markLogicalDeleteStatus() {
    //now do this to reflect status changes as the user still remains on the same web page
    this.caseLineInfoData.change_ACTION_CD = LineUtils.CHANGE_ACTION_DELETED;
    this.caseLineInfoData.change_ACTION_TITLE_NM = 'Deleted';
    this.caseLineInfoData.case_LINE_MARK_FOR_DELETION_IN = 'true';
  }

  //FR39 and 40
  performSaveDataOperation(pLogicalDelete: boolean): boolean {
    this.isLoading.next(true);
    this.caseRestService.saveCaseLineEntity(LineUtils.prepareCLDataForSave(this.caseLineInfoData)).subscribe(
      result => {
        this.caseUIService.setCaseLineInfoValues(this.caseLineInfoData);
        this.setDeleteStatus(false);
        if (pLogicalDelete) this.markLogicalDeleteStatus();
        this.isLoading.next(false);
      },
      err => {
        CaseUtils.ReportHTTPError(err, "saving Line to the database");
        this.isLoading.next(false);
        return false;
      }
    );
    return true;
  }

  resetEditToggle() {
    // Set Toggle initially to false.
    this.caseUIService.caseEditService.next({
      ID: LineSubdashboardComponent.CASE_LINE_EDITOR_STR,
      editToggle: this.caseUIService.getIsLineDataInEditMode()
    });
    if (!this.caseUIService.getIsLineDataInEditMode())
      this.caseUIService.flipToDisabledService.next(LineSubdashboardComponent.CASE_LINE_EDITOR_STR);

  }

  performDeleteLineOperation() {
    this.caseLineInfoData.case_LINE_MARK_FOR_DELETION_IN = 'true';
    this.caseLineInfoData.entityStatus = DsamsConstants.ENT_DELETED.toString();
    this.caseLineInfoData.status = DsamsConstants.ENT_DELETED.toString();
    if (this.performSaveDataOperation(false)) {
      this.resetEditToggle();
      MessageMgr.displaySuccessWithTimer('Save was successful', 3000);
      setTimeout(() => {
        this.router.navigateByUrl('/case/line-dashboard/0/line');
      }, 1000);
    }
  }

  //this marks line/subline to be for logical delete
  markDeleteAndSaveData() {
    this.caseLineInfoData.entityStatus = DsamsConstants.ENT_DELETED.toString();
    this.caseLineInfoData.status = DsamsConstants.ENT_DELETED.toString();
    if (this.performSaveDataOperation(true)) {
      setTimeout(() => {
        MessageMgr.displaySuccessWithTimer('Save was successful', 3000);
      }, 1000);
    }
  }

  checkPriorYearAmount() {
    this.isLoading.next(true);
    this.caseRestService.checkPriorYearSum(
      LineUtils.getMappingCaseLineEntityPK(this.caseLineInfoData)).subscribe(
        hasGreaterPriorYearAm => {
          if (hasGreaterPriorYearAm) {
            MessageMgr.swalFire({
              text: 'You have a Price Element/Fund combination with a Prior Year Obligation Value greater than $0.  Do you want to continue?',
              icon: 'warning',
              width: 400,
              showCancelButton: true,
              cancelButtonText: 'No',
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              confirmButtonText: 'Yes',
            }).then((result) => {
              if (result.value) {
                //need to set status to delete
                this.markDeleteAndSaveData();
              }
            })
          }
          else {
            //need to set status to delete
            this.markDeleteAndSaveData();
          }
          this.isLoading.next(false);
        },
        err => {
          CaseUtils.ReportHTTPError(err, "checking Case Line Prior Year Amount from server");
          this.isLoading.next(false);
        }
      );
  }

  validatePriorYearAmount() {
    var warningMsg: string;
    if (this.caseLineInfoData.change_ACTION_CD.toUpperCase() == LineUtils.CHANGE_ACTION_CD_CHANGED)
      warningMsg = 'An open Case Line Task exists on the line, do you want to continue with change line?';
    else warningMsg = 'Total cost of line is now less than its authorized, committed, obligated, billed or disbursed amounts.  Do you want to continue?';
    MessageMgr.swalFire({
      text: warningMsg,
      icon: 'warning',
      width: 400,
      showCancelButton: true,
      cancelButtonText: 'No',
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes',
    }).then((result) => {
      if (result.value) {
        //do logical delete
        this.checkPriorYearAmount();
      }
    })
  }

  /* This procedure checks the returned result value from the 
       popover Yes/No dialog window. */
  yesButtonOnClick(isDeleteConfirmed: any) {
    if (isDeleteConfirmed) {
      if (this.caseLineInfoData.change_ACTION_CD == LineUtils.CHANGE_ACTION_CD_ADDED) {
        this.performDeleteLineOperation();
      }
      else {
        if (this.isDataReadyForDelete()) {
          //do logical delete 
          this.checkPriorYearAmount();
        }
        else {
          this.validatePriorYearAmount();
        }
      }
    }
  }

 

 

  
    
 

 
 

  

 
  
  handleError(apiUrl: string, error: any) {
    let errorMsgTitle: string = "";
    let errorMsg: string = "";
    let details: string = "";
    let errorCode: string = "";
    if (error.error == null) {
      errorMsgTitle = error.name;
      errorMsg = error.message;
      errorCode = (typeof error.status !== 'undefined') ? error.status : 0;
      errorMsg = "Status Code " + errorCode + ", " + errorMsg;
      this.messageService.infoMessage (errorMsgTitle, errorMsg);
    } else if (error.error instanceof ErrorEvent) {
      errorMsg = 'An error event occurred: ' + error.error.message;
      errorMsgTitle = "Local Error"
      this.messageService.infoMessage(errorMsgTitle, errorMsg);
      if (!!details) {
        console.log(errorMsg);
      }
    } else {
      this.handleSubError(error);
    }
  }

  handleSubError(error: any) {
    let errorMsgTitle: string;
    let errorMsg: string;
    let details: string;
    if (error.error != null && typeof error.error.lockConflict !== 'undefined' && error.error.lockConflict != null) {
      if (error.error.lockConflict) {
        errorMsgTitle = "Lock Conflict";
        errorMsg = error.error.message;
        this.messageService.infoMessage(errorMsgTitle, errorMsg);
      } else {
        if (error.error.exceptionType !== 'undefined') {
          errorMsg = error.error.exceptionType +
            ' - "' + error.error.message + '"';
          details = errorMsg + "\n" + error.error.stackTrace;
        }
      }
    }
    console.log(errorMsg);
    if (!!details) {
      console.log(errorMsg);
    }
  }
  // end DSAMS-5983 09/22 DB

}
