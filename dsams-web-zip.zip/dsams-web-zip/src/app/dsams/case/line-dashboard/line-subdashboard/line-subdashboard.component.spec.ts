import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LineSubdashboardComponent } from './line-subdashboard.component';

describe('LineSubdashboardComponent', () => {
  let component: LineSubdashboardComponent;
  let fixture: ComponentFixture<LineSubdashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LineSubdashboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LineSubdashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
