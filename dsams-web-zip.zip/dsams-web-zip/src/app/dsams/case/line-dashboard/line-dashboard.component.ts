import { Component, OnInit, Output,ViewChild, EventEmitter } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CaseUIService } from '../services/case-ui-service';
import { CaseLineRelatedInfoType } from '../model/case-line-related-info-type';
import { BehaviorSubject, Subscription } from 'rxjs';
import { MatTabChangeEvent } from '@angular/material';
import { DsamsConstants } from '../../dsams.constants';
import { CaseRelatedInfoType } from '../model/case-related-info-type';
import { IEditResponseType } from '../model/edit-response-type';
import { ifaceCaseLineData } from '../model/case-line-model';
import { DsamsShareService } from './../../services/dsams-share.service';
import { CaseUtils } from '../utils/case-utils';
import { MessageMgr } from '../validation/message-mgr';
import { LinkCaseDataClass } from '../model/link-case-data';
import { CsuCompNameHashTable } from '../../utilitis/csu-component-hashtable';
import { LineSublineRefComponent } from './line-reference.component';
// begin DSAMS05867 08/22 DB
import { LinePricingComponent } from './line-pricing/line-pricing.component';
import { LineSubdashboardComponent } from './line-subdashboard/line-subdashboard.component';
// end DSAMS05867 08/22 DB

import { take } from 'rxjs/operators';

@Component({
  selector: 'app-line-dashboard',
  templateUrl: './line-dashboard.component.html',
  styleUrls: ['./line-dashboard.component.css',
    './common-CSS.component.css']
})

export class LineDashboardComponent implements OnInit {
  @Output() sendBackFromCaseLineLIst = new EventEmitter<boolean>();
 // begin DSAMS05867 08/22 DB
  @ViewChild(LinePricingComponent, { static: false }) lprcComp: LinePricingComponent;
  @ViewChild(LineSubdashboardComponent, { static: false }) lsubComp: LineSubdashboardComponent;
 
// end DSAMS05867 08/22 DB
public static CASE_LINE_LOCK_SESSION_ID = "CaseLineLockSessionId";
  selectedTab: any;
  selectedTabLabel: any = 'Line';
  caseLineRelatedInfoData: CaseLineRelatedInfoType;
  caseRelatedInfoData: CaseRelatedInfoType;
  caseVersionStatusDevelopmentType: string = "D";
  caseLineInfoData: ifaceCaseLineData;
  aCaseUserId: any;
  aUserCaseId: any;
  aCaseId: any;
  aCaseVersionId: any;
  aCaseMasterLineId: any;
  aParentCaseMasterLineId: any;
  aCaseUserStatus: any;
  aCaseVersionNumId: any;
  aCaseVersionTypeCd: any;
  aCaseVersionTypeDesc: any;
  aCaseSublineTx: any = '';
  aCustomerOrgId: any;
  aCaseLineEditorString: string = DsamsConstants.CASE_LINE_EDITOR;
  aCaseLineOptionsMenu: string = "";
  isLineAllowedForEdit: boolean = false;
  isLineTabDisabled: boolean = this.caseUIService.getIsLineTabDisabled();
  readonly PAGE_CASE_LINE: string = DsamsConstants.PAGE_CASE_LINE;

  _caseUIServiceSubscription: Subscription;
  _editSubscription: Subscription;
  _lineInfoValuesSubscription: Subscription;
  private _caseLineOptionsSubscription: Subscription;
  pageTitle: string;
  pageNumber: string;
  //DSAMS-5461 DH 05/02/22
  theCSUId: string;
  isEditRightAccessGranted: boolean = true;

  constructor(private route: ActivatedRoute, private router: Router,
    private caseUIService: CaseUIService,
    private CSUHashTable : CsuCompNameHashTable,
    private getLineSublineRefData: LineSublineRefComponent,
    private dsamsShareService: DsamsShareService) {
    this.selectedTab = this.route.snapshot.params['tabIndex'];
    this.selectedTabLabel = this.route.snapshot.params['tabLabel'];
    //begin DSAMS-5461 DH 05/22
    let aCsuId = this.CSUHashTable.getCSUId(this.route.routeConfig.component.name);
    this.theCSUId = aCsuId ? aCsuId : CsuCompNameHashTable.CSU_CD_WP003;
    //end DSAMS-5461 DH 05/02/22
  }

  ngOnInit() {
    this.getEditAccessRight();
    this.getLinkCaseDataOnInit();
    this.caseUIService.setIsShortcutsMenuHidden(false);
    this.caseUIService.setPageNavigation(DsamsConstants.PAGE_CASE_LINE);
    this.pageTitle = 'Line List';
    this.pageNumber = '(' + this.theCSUId.toUpperCase() + ')';
    this.dsamsShareService.csuname.next(null);
    this.dsamsShareService.csuname.next(this.theCSUId);
     //do this to avoid Null value on init
    this.aCaseVersionNumId = 0;     // This isn't available in caseRelatedInfoData. Hopefully not needed.
    this.aCaseVersionTypeCd = "";   // Same as above.
    this.aCaseVersionTypeDesc = ""; // Same as above.    
    this._caseUIServiceSubscription = this.caseUIService.getCaseLineRelatedInfoValues().subscribe((value) => {
      this.caseLineRelatedInfoData = value;
      // Concatenate the case user ID with case version type code         
      if (!!this.caseLineRelatedInfoData) {
        this.aUserCaseId = this.caseLineRelatedInfoData.user_CASE_ID;
        //exclude version for basic case
        //if (this.caseLineRelatedInfoData.case_VERSION_TYPE_CD == 'B')
        if (this.caseLineRelatedInfoData.case_VERSION_NUMBER_ID == 0) {
          setTimeout(() => {
            this.aCaseUserId = '(' + this.caseLineRelatedInfoData.user_CASE_ID
              + ' ' + this.caseLineRelatedInfoData.case_VERSION_TYPE_CD + ')';
          }, 0);
        }
        else {
          setTimeout(() => {
            this.aCaseUserId = '(' + this.caseLineRelatedInfoData.user_CASE_ID
              + ' ' + this.caseLineRelatedInfoData.case_VERSION_TYPE_CD
              + ' ' + this.caseLineRelatedInfoData.case_VERSION_NUMBER_ID + ')';
          }, 0);
        }
      }
    });
    this._caseUIServiceSubscription = this.caseUIService.getCaseRelatedInfoValues().subscribe((value) => {
      this.caseRelatedInfoData = value;
      if (!!this.caseRelatedInfoData) {
        if (this.caseRelatedInfoData.case_ID != null) {
          this.aCaseId = this.caseRelatedInfoData.case_ID;
        } else {
          this.aCaseId = this.caseRelatedInfoData.working_CASE_ID;
        }
        this.aCaseVersionId = this.caseRelatedInfoData.working_CASE_VERSION_ID;
        this.aCustomerOrgId = this.caseRelatedInfoData.customer_ORGANIZATION_ID;
        this.aCaseMasterLineId = this.caseRelatedInfoData.case_MASTER_LINE_ID;
        this.aCaseSublineTx = this.caseRelatedInfoData.wm_USER_CASE_SUBLINE_TX;
        this.aParentCaseMasterLineId = this.caseRelatedInfoData.wm_PARENT_CASE_MASTER_LINE_ID;
        this.caseUIService.theComponentSaveCaseLineState={};
        this.intializeSaveCaseLineState();      
      }
    });
    this._lineInfoValuesSubscription = this.caseUIService.getCaseLineInfoValues().subscribe((pCaseLine: ifaceCaseLineData) => {
      if (!!pCaseLine) {
        this.caseLineInfoData = pCaseLine; // Added by Jeff Sniffen
        if (!!this.caseRelatedInfoData)
          this.caseRelatedInfoData.case_MASTER_LINE_ID = pCaseLine.case_MASTER_LINE_ID;
        this.aCaseMasterLineId = pCaseLine.case_MASTER_LINE_ID;
        this.aCaseSublineTx = pCaseLine.wm_USER_CASE_SUBLINE_TX;
        this.aParentCaseMasterLineId = pCaseLine.wm_PARENT_CASE_MASTER_LINE_ID;
      } //Jeff - added else, variable was "undefined" throwing exception.
      else {
        this.caseLineInfoData = {
          wm_USER_CASE_SUBLINE_TX: null
        };
      }
    });
    //Subcribe to Edit slider control
    this.subscribeToEditToggle();
   }

  intializeSaveCaseLineState() {
    this.caseUIService.theComponentSaveCaseLineState[CaseUIService.SAVE_CASE_LINE_LIST_STATE] =
    {
      isSaveConfirmed: new BehaviorSubject<boolean>(false), isDataChanged: false,
      isContinueConfirmed: new BehaviorSubject<boolean>(false)
    }
    this.caseUIService.theComponentSaveCaseLineState[CaseUIService.SAVE_CASE_LINE_DETAILS_STATE] =
    {
      isSaveConfirmed: new BehaviorSubject<boolean>(false), isDataChanged: false,
      isContinueConfirmed: new BehaviorSubject<boolean>(false)
    }
    this.caseUIService.theComponentSaveCaseLineState[CaseUIService.SAVE_CASE_LINE_PRICING_STATE] =
    {
      isSaveConfirmed: new BehaviorSubject<boolean>(false), isDataChanged: false,
      isContinueConfirmed: new BehaviorSubject<boolean>(false)
    }
  }

  //begin DSAMS-5461 DH 05/22
  getEditAccessRight(): void {
    this.getLineSublineRefData.getEditAccessRight(this.theCSUId)
      .pipe(take(1))
      .subscribe(result => {
        if (result == 1) this.isEditRightAccessGranted = true;
        else {
          this.isEditRightAccessGranted = false;
          this.caseUIService.setIsOptionsMenuHidden(true);
        }
      });
  }
  //end DSAMS-5461 DH 05/22

  ngOnDestroy() {
    this.dsamsShareService.csuname.next(null);
    if (this._caseUIServiceSubscription) { this._caseUIServiceSubscription.unsubscribe(); }
    if (this._editSubscription) { this._editSubscription.unsubscribe(); }
    if (this._lineInfoValuesSubscription) { this._lineInfoValuesSubscription.unsubscribe(); }
    if (this._caseLineOptionsSubscription) { this._caseLineOptionsSubscription.unsubscribe(); }
  }

  //begin Jira DSAMS-5346 DH 04/22
  getLinkCaseDataOnInit() {
    if (!!this.route.snapshot.queryParamMap.get(LinkCaseDataClass.theLinkCaseData)) {
      this.dsamsShareService.breadcrumbForNewPage.next(LinkCaseDataClass.theLinkCaseData);
      this.getLinkCaseDataForNewPage();
    }
  }
  getLinkCaseDataForNewPage() {
    let linkCaseData = LinkCaseDataClass.getTheLinkCaseData(this.route);
    if (!!linkCaseData) {
      sessionStorage.setItem(DsamsConstants.SESSION_SDB_ID, linkCaseData.serviceDbId);
      this.caseRelatedInfoData = {
        case_ID: linkCaseData.case_ID,
        working_CASE_ID: linkCaseData.case_ID,
        working_CASE_VERSION_ID: linkCaseData.case_VERSION_ID,
        case_VERSION_ID: linkCaseData.case_VERSION_ID.toString(),
        customer_ORGANIZATION_ID: linkCaseData.customer_ORGANIZATION_ID,
        case_MASTER_STATUS_CD: linkCaseData.case_MASTER_STATUS_CD,
        case_USAGE_INDICATOR_CD : linkCaseData.case_USAGE_INDICATOR_CD,
        wm_CASE_VERSION_TYPE_CD: linkCaseData.wm_CASE_VERSION_TYPE_CD,
      }
      this.caseLineRelatedInfoData = {
        case_ID: linkCaseData.case_ID,
        case_VERSION_STATUS_CD: linkCaseData.case_VERSION_STATUS_CD,
        case_VERSION_TYPE_CD: linkCaseData.case_VERSION_TYPE_CD,
        security_ASSISTANCE_PROGRAM_CD: linkCaseData.security_ASSISTANCE_PROGRAM_CD,
        user_CASE_ID: linkCaseData.user_CASE_ID,
        case_VERSION_NUMBER_ID: linkCaseData.case_VERSION_NUMBER_ID,
      }
      //emit updated case/case line info data
      this.caseUIService.setCaseLineRelatedInfoValues(this.caseLineRelatedInfoData);
      this.caseUIService.setCaseRelatedInfoValues(this.caseRelatedInfoData);
    }
  }
  //end Jira DSAMS-5346 DH 04/22

  // begin Jira card DSAMS-5334 04/2022 AKP
  ngAfterViewInit() {
    this.caseUIService.submitBreadcrumbTitleChangeRequest("Line List");
  
  }
  // end Jira card DSAMS-5334 04/2022 AKP

  ngAfterViewChecked() {
    this.lsubComp._lprcComp = this.lprcComp;
  }
  // Subscribe to edit toggle event
  subscribeToEditToggle() {
    if (!this._editSubscription) {
      this._editSubscription = this.caseUIService
        .caseEditService
        .subscribe((pResponse: IEditResponseType) => {
          if (!!pResponse) this.isLineAllowedForEdit = pResponse.editToggle;
        },
          err => {
            CaseUtils.ReporError("in Line List responding to edit toggle");
          }
        );
    }
  }

  onFocusChange(tabChangeEvent: MatTabChangeEvent) {
    if (this.selectedTab == 0 && !this.caseLineInfoData.isDataChanged && !this.caseLineInfoData.isPricingDataChanged) {
      const turnToggleOff: IEditResponseType = { ID: DsamsConstants.CASE_LINE_EDITOR, editToggle: false };
      this.caseUIService.caseEditService.next(turnToggleOff);
    }
    if (this.caseLineInfoData.isDataChanged && this.selectedTab == 1) {
      MessageMgr.swalFire({
        title: 'Info',
        icon: 'info',
        html: '<font color="black">' + 'Before proceeding, please Save or Cancel any changes to the Line.' + '</font>',
        width: 500,
        focusConfirm: true,
        confirmButtonText: 'OK'
      });
      //force the user to stay on the orginal tab
      this.caseUIService.setTheOriginalLineTabIndex(this.selectedTab);
    }
    else if (this.caseLineInfoData.isPricingDataChanged) {
      if (tabChangeEvent.index == 0) {
        MessageMgr.swalFire({
          title: 'Info',
          icon: 'info',
          html: '<font color="black">' + 'Before proceeding, please Save or Cancel any changes to the Pricing.' + '</font>',
          width: 500,
          focusConfirm: true,
          confirmButtonText: 'OK'
        });
        //force the user to stay on the orginal tab
        this.caseUIService.setTheOriginalLineTabIndex(this.selectedTab);
      }
      // else if (this.selectedTab == 2) {
      //   MessageMgr.swalFire({
      //     title: 'Info',
      //     icon: 'info',
      //     html: '<font color="black">' + 'You are proceeding without saving pricing data.' + '</font>',
      //     width: 500,
      //     focusConfirm: true,
      //     confirmButtonText: 'OK'
      //   }).then((result) => {
      //     if (result) {
      //       this.selectedTab = tabChangeEvent.index;
      //       this.caseUIService.setTheOriginalLineTabIndex(tabChangeEvent.index);
      //     }
      //   })
      // }
      
      else this.caseUIService.setTheOriginalLineTabIndex(tabChangeEvent.index);
    }
    else if (this.getCaseLineLockSessionId() > 0){
      const turnToggleOff: IEditResponseType = { ID: DsamsConstants.CASE_LINE_EDITOR, editToggle: false };
      this.caseUIService.caseEditService.next(turnToggleOff);
      this.caseUIService.setTheOriginalLineTabIndex(tabChangeEvent.index);
    }
    else this.caseUIService.setTheOriginalLineTabIndex(tabChangeEvent.index);
  }

  getCaseLineLockSessionId(): number {
    let lockId: string = sessionStorage.getItem(LineDashboardComponent.CASE_LINE_LOCK_SESSION_ID);
    if (lockId == null) {
      lockId = "0";
      sessionStorage.setItem(LineDashboardComponent.CASE_LINE_LOCK_SESSION_ID, lockId);
    }
    return parseInt(lockId);

  }
  onTabChanged(tabChangeEvent: MatTabChangeEvent): void {
    console.log("tab index: " + tabChangeEvent.index);
    if (this.selectedTab == 0 && !this.caseLineInfoData.isDataChanged && !this.caseLineInfoData.isPricingDataChanged)  {
       this.isLineTabDisabled = true;
      this.caseUIService.caseLineUnlockRequest.next(true);
      const turnToggleOff: IEditResponseType = { ID: DsamsConstants.CASE_LINE_EDITOR, editToggle: false };
      this.caseUIService.caseEditService.next(turnToggleOff);
    }
    else this.isLineTabDisabled = false;
    this.caseUIService.getTheOriginalLineTabIndex().forEach(value => { this.selectedTab = value });
    if (this.selectedTab == 0) {
      this.pageTitle = 'Line List';
      let aCsuId = this.CSUHashTable.getCSUId('LineDashboardComponent');
      this.theCSUId = aCsuId ? aCsuId : CsuCompNameHashTable.CSU_CD_WP003;
    } else if (this.selectedTab == 1) {
      this.pageTitle = 'Line';
      let aCsuId = this.CSUHashTable.getCSUId('LineDetailsComponent');
      this.theCSUId = aCsuId ? aCsuId : CsuCompNameHashTable.CSU_CD_WP003A;
    } else if (this.selectedTab == 2) {
      this.pageTitle = 'Line Pricing';
      let aCsuId = this.CSUHashTable.getCSUId('LinePricingComponent');
      this.theCSUId = aCsuId ? aCsuId : CsuCompNameHashTable.CSU_CD_WP003B;
    }
    this.pageNumber = '(' + this.theCSUId.toUpperCase() + ')';
    this.dsamsShareService.csuname.next(null);
    this.dsamsShareService.csuname.next(this.theCSUId);
    this.getEditAccessRight();
  }

  goBackToCaseSearchSummary() {
    this.caseUIService.setbackToCaseSearchSummaryValue(true);
    // this.sendBackFromCaseLineLIst.emit(true);
    //Disable Line and Pricing tabs
    this.caseUIService.setIsLineTabDisabled(true);
    this.router.navigateByUrl('/case/search');
  }

  setTabActive($event) {
    if ($event == 0 &&  this.selectedTab == 0
      && !this.caseLineInfoData.isDataChanged && !this.caseLineInfoData.isPricingDataChanged) {
      const turnToggleOff: IEditResponseType = { ID: DsamsConstants.CASE_LINE_EDITOR, editToggle: false };
      this.caseUIService.caseEditService.next(turnToggleOff);
    }
    this.selectedTab = $event;
  }

  setTabLabelActive($event) {
    this.selectedTabLabel = $event;
  }

}
