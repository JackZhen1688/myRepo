/* This class is used to handle all business logic for 
   the Line Details page.
   Author: Francis Shu 
   Date:   05/04/2020 
*/

import { Component, OnInit, ViewChild, Injector, Output, EventEmitter } from '@angular/core';
import { BehaviorSubject, Subscription } from 'rxjs';
import { MatTableDataSource } from '@angular/material/table';
import { MdePopoverTrigger } from '@material-extended/mde';
import { CaseUIService } from '../../services/case-ui-service';
import { ifaceCaseLineData, ifaceCaseMasterLineEntity, ifaceGenericRefItem, ifaceCaseLineEntity } from '../../model/case-line-model';
import {
  ifaceCaseLineAssistanceTypeEntity, ifaceAssistanceTypeEntity, ifaceCaseLineDeliveryItemEntity,
  ifaceCaseLineDeliveryScheduleEntity, ifaceCaseLineDeliveryTermEntity, ifaceCaseLineOfferReleaseEntity, CaseRelatedInfoType
} from '../../model/case-related-info-type';
import { Router } from '@angular/router';
import { CaseUtils } from '../../utils/case-utils';
import { DsamsConstants } from 'src/app/dsams/dsams.constants';
import { CaseRestfulService } from '../../services/case-restful.service';
import { CaseLineRelatedInfoType } from '../../model/case-line-related-info-type';
import { LineSublineRefComponent } from '../line-reference.component';
import { FormControl, Validators, FormGroup } from '@angular/forms';
import { IEditResponseType } from '../../model/edit-response-type';
import { LineUtils } from '../line-utils';
import { DsamsMethodsService } from './../../../../dsams/services/dsams-methods.service';
import { PopMaslComponent } from '../../../utilitis/popups/pop-masl/pop-masl.component';
import { MessageMgr } from '../../validation/message-mgr';
import { ErrorParameter } from 'src/app/dsams/entities/specialEntities/error-parameter.model';
import { DsamsUserMessageService } from 'src/app/dsams/services/dsams-user-message.service';
import { ICaseVersion } from '../../model/dto/icase-version';
import { take } from 'rxjs/operators';
import { CaseCommonValidator } from '../../validation/case-common-validator';
import { MilestoneCommentComponent } from '../../dialogs/milestone-comment/milestone-comment.component';
import { MatDialog, MatDialogRef, MatDialogState } from '@angular/material';
import { PopNporComponent } from 'src/app/dsams/utilitis/popups/pop-npor/pop-npor.component';
// begin DSAMS-5205 02/2022 DB
import { MatSnackBar } from '@angular/material/snack-bar';
// end DSAMS-5205 02/2022 DB

declare function focusItem(pItem: string): any;

@Component({
  selector: 'app-line-details',
  templateUrl: './line-details.component.html',
  styleUrls: ['./line-details.component.css',
    '../common-CSS.component.css'],
  providers: [
    {
      provide: MatDialogRef,
      useValue: {}
    }
  ]
})
export class LineDetailsComponent implements OnInit {
  @ViewChild(MdePopoverTrigger, { static: true }) trigger: MdePopoverTrigger;
  @Output() sendTabIndex = new EventEmitter<number>();
// begin DSAMS-5867 07/22 DB
  @Output() refreshCaseLine = new EventEmitter<ifaceCaseLineData>()
  refreshCaseLineData() {
    if (!this.caseUIService.getIsLineTabDisabled()) {
      if (!(this.caseLineInfoData.status == DsamsConstants.ENT_NEW.toString())) {
        this.refreshCaseLine.emit(this.caseLineInfoData);
      }
    }
  }
  // end DSAMS-5867 07/22 DB
  private static CASE_LINE_EDITOR_STR: string = DsamsConstants.CASE_LINE_EDITOR;

  private static USER_ID: string = "userId";
  private static USER_ACTIVITY_ID : string = "userActivityId";

  // begin DSAMS-5205 02/2022 DB
  public static LOCK_SESSION_ID = "CaseLineLockSessionId";
  private static KEY_DELIMETER: string = ":";
  // end DSAMS-5205 02/2022 DB

  //Color Attibutes
  ActiveBtnColor: any = '#e7eff6';
  ActiveBgColor: any = 'white';
  InactiveBtnColor = 'darkgrey';
  ActiveDeleteBtnColor = 'red'


  aTypeAssistRowIndex: number = 0;
  emptyString: string = '';
  naString: string = 'N/A';

  isMASLInvalid: boolean = false;
  maslValidation: any[] = [{ isMASLInvalid: false, isMASLrequired: false }]


  private _milestoneSubscription: Subscription = null;
  private _caseUIServiceSubscription1: Subscription = null;
  private _caseUIServiceSubscription2: Subscription = null;
  private _caseUIServiceSubscription3: Subscription = null;
  private _refreshDataSubscription: Subscription = null;
  private _updateNoprSubscription: Subscription = null;
  private _nporListReadySubscription: Subscription = null;
  private _selectNporSubscription: Subscription = null;
  programOfRecordDisp: string = "N/A";
  showNporPopup: boolean = true;   // Show the NPOR popup or dropdown.
  _editSubscription: Subscription;
 
  isRefreshDataNeeded: boolean = false;
  isLoading: BehaviorSubject<boolean> = new BehaviorSubject(false);

  caseLineInfoData: ifaceCaseLineData;
  caseLineInfoDataOrig: ifaceCaseLineData;
  caseLineRelatedInfoData: CaseLineRelatedInfoType;
  aCaseUserId: any;
  // theCaseLineDetail: ifaceCaseLineData;
  theInitialCaseLineInfoData: ifaceCaseLineData;

  aCaseLineAssistanceTypeList: ifaceCaseLineAssistanceTypeEntity[];
  //theDeletedCLATListArray: ifaceCaseLineAssistanceTypeEntity[];
  addAssistanceBtnColor: any = this.InactiveBtnColor;

  //use session storage to cache data for now - cannot clone 2 level deep array 
  static CLAT_CACHE: string = "CLATCache";
  _theCloneCLDIList: ifaceCaseLineDeliveryItemEntity[];
  _theCloneCLDSList: ifaceCaseLineDeliveryScheduleEntity[];
  _theCloneCLDTList: ifaceCaseLineDeliveryTermEntity[];
  _theCloneCLORList: ifaceCaseLineOfferReleaseEntity[];
  _theCloneCLATList: ifaceCaseLineAssistanceTypeEntity[];

  columnsToDisplayTypeAssist = ['TypeofAssistance', 'DeleteRow'];
  dataSourceTypeAssist: any;

  //Use form control for built-in required field validation
  maslFormCtl: FormControl;
  linePurposeFormCtl: FormControl;
  //issueUnitFormCtl: FormControl;

  //Editable fields
  //set field to disable as default values
  isLineManagerDisabled: boolean = true;
  isLineDetailDisabled: boolean = true;
  isSpecificSublineFieldDisabled: boolean = true;
  isPercentStockDisabled: boolean = true;
  isCCAssocFieldsDisabled: boolean = true;
  isNporFieldDisabled: boolean = true;
  isNporEnabledFromDropdown: boolean = false;
  private _nporDropdownExpanded: boolean = false;
  isNewMode: boolean = false;

  // Line Number Change Update
  caseLineNumberUpdate: string;

  // Warning message to display prior to save.
  private _warningMsg: any = null;

  // Form for popup for MASL
  maslForm: FormGroup;

  // Subscription for MASL Popup
  private _popupMASLSubscription: Subscription = null;

  // Subscriptions
  private _isLineManagerDisabledSubscription = null;

  caseVersionData: ICaseVersion;

  lineExists: boolean = false;
  sublineExists: boolean = false;
  caseVersionStatusDevelopmentType: string = "D";
  dialogState: MatDialogState;

  private _databaseNpor: number = 0;
  private _hasNporWarnings: boolean;
  private _noprVisible: boolean;
  readyToEnableNporPopup: boolean;

  // Parameters for repopulate
  repopulateWorking_CASE_ID: number = 0;
  repopulateCase_MASTER_LINE_ID: number = 0;
  repopulateWorking_CASE_VERSION_ID: number = 0;
  repopulateMDE_SMD_CD: string = '';
  repopulateArticle_DESCRIPTION_TX: string = '';

  //DSAMS-5269 DH 03/22 
  public theReferenceLineDataList: ifaceCaseLineData;
  private _resetDynamicRefListSub: Subscription = null;

  caseRestService: CaseRestfulService;
  dsamsMethodsService: DsamsMethodsService;
  messageService: DsamsUserMessageService;
  caseUIService: CaseUIService;
  dsamsDialogMsgService: DsamsMethodsService;
  cancelClicked:boolean=false;
 
  constructor(
    private popUpDialog: MatDialog,
    private injector: Injector,
    private router: Router,
   public getLineSublineRefData: LineSublineRefComponent,
    public dialog: MatDialog,
    // begin DSAMS-5205 02/2022 DB
    private _snackBar: MatSnackBar,
    // begin DSAMS-5205 02/2022 DB

    public dialogRef: MatDialogRef<MilestoneCommentComponent>) {
    this.caseRestService = injector.get<CaseRestfulService>(CaseRestfulService);
    this.dsamsMethodsService = injector.get<DsamsMethodsService>(DsamsMethodsService);
    this.messageService = injector.get<DsamsUserMessageService>(DsamsUserMessageService);
    this.caseUIService = injector.get<CaseUIService>(CaseUIService);
    this.dsamsDialogMsgService = injector.get<DsamsMethodsService>(DsamsMethodsService);
  }


  ngOnInit() {

    // begin DSAMS-5983 09/22 DB
    this.subscribeToCaseLineLockRequest();
    this.subscribeToCaseLineUnlockRequest();
// end DSAMS-5983 09/22 DB
    
    //begin DSAMS-5269 DH 03/22 
    this.subscibeToResetDynamicRefList();
    this.getLineDetailsReferenceData();
    //end DSAMS-5269 DH 03/22
    
 

    this._hasNporWarnings = false;
    this._noprVisible = false;
    this.isNporEnabledFromDropdown = false;
    this.readyToEnableNporPopup = false;
    this.maslFormCtl = new FormControl('', [Validators.required, Validators.pattern(/^[A-z0-9]*$/)]);
    this.linePurposeFormCtl = new FormControl('', [Validators.required]);
    this.dataSourceTypeAssist = new MatTableDataSource(this.aCaseLineAssistanceTypeList);

    if (!this._caseUIServiceSubscription1) {
      this._caseUIServiceSubscription1 = this.caseUIService.getCaseLineRelatedInfoValues().subscribe((value) => {
        this.caseLineRelatedInfoData = value;
     });
    }
    this.subsribeTocaseUIService2();
    // Subscribe to Case UI Service caseLineNumberUpdate
    if (!this._caseUIServiceSubscription3) {
      this._caseUIServiceSubscription3 = this.caseUIService.caseLineNumberUpdate.subscribe((value) => {
        this.caseLineNumberUpdate = value;
      });
    }

    

    
    this.subsribeToRefreshService();
    setTimeout(() => {
      // Update NOPR subscription
      this.subscribeToNOPRService();
    }, 10);

    // Set Case Line Options.
    this.caseUIService.resetOptionFlags(DsamsConstants.PAGE_CASE_LINE);
    // Update Manager 2
     if (!!this.caseLineInfoData) {
      this.caseUIService.setIsMgrEnabled2(CaseUtils.isOptionEnabledForMgr2Shortcut(
        this.caseLineInfoData.wm_CASE_VERSION_STATUS_CD,
        this.caseLineInfoData.wm_CASE_VERSION_TYPE_CD,
        this.caseLineInfoData.case_USAGE_INDICATOR_CD,
        this.caseLineInfoData.case_LINE_MARK_FOR_DELETION_IN,
        this.caseLineInfoData.change_ACTION_CD,
        this.caseLineInfoData.wm_USER_CASE_SUBLINE_TX));
    }
    else this.initializeCaseLineInfo();
    this.caseUIService.setIsStatusCompleteEnabled(true);
    this.caseUIService.setIsOptionsMenuHidden(false);
    this.caseUIService.setPageNavigation(DsamsConstants.PAGE_CASE_LINE);

    this.subscribeToEditToggle();

    setTimeout(() => {
      if (!this.isRefreshDataNeeded) {
        // Set Toggle initially to false
        this.caseUIService.caseEditService.next({
          ID: LineDetailsComponent.CASE_LINE_EDITOR_STR,
          editToggle: this.caseUIService.getIsLineDataInEditMode()
        });
        if (!this.caseUIService.getIsLineDataInEditMode())
          this.caseUIService.flipToDisabledService.next(LineDetailsComponent.CASE_LINE_EDITOR_STR);
      }
    }, 10);
     if (this.caseLineInfoData == null) {
      this.initializeCaseLineInfo();
      LineUtils.theDeletedCLATListArray = [];
      this.maslFormCtl.reset();
      this.linePurposeFormCtl.reset();
    }
    else {
      this.setSpecificFieldProperty();
      if (!CaseUtils.isBlankStr(this.caseLineInfoData.program_OF_RECORD_ID))
        this.setProgramOfRecordDispFromId(this.caseLineInfoData.program_OF_RECORD_ID);
      if (this.caseLineInfoData.caseLineAssistanceTypeList) {
        this._theCloneCLATList = JSON.parse(JSON.stringify(this.caseLineInfoData.caseLineAssistanceTypeList));
        this.initializeCaseLineAssistanceTypeArray(this.caseLineInfoData.caseLineAssistanceTypeList);
      }
    }
    //Cloning an observable object 
    this.theInitialCaseLineInfoData = { ... this.caseLineInfoData };
    // Subscribe to MASL Popup.
    this.subscribeToPopupMASL();
    this.subscribeToLineMgr();

    this.subscribeToSaveOnEditToggle();
    this.subscribeToContinueOnEditToggle();
    
  }

  //begin DSAMS-5269 DH 03/22 
  subscibeToResetDynamicRefList() {
    this._resetDynamicRefListSub = this.getLineSublineRefData.getResetDynamicRefList().subscribe(result => {
      if (result) {
        this.getLineSublineRefData.restoreInitialReferenceDataList();
        if (this.theReferenceLineDataList == null) {
          this.theReferenceLineDataList = {};
          this.theReferenceLineDataList.lineManagerRefList =
            LineSublineRefComponent.theReferenceLineDataList.lineManagerRefList;
          this.theReferenceLineDataList.operatingAgencyRefList =
            LineSublineRefComponent.theReferenceLineDataList.operatingAgencyRefList;
        }
      }
    })
  }
 public getLineDetailsReferenceData() {
    this.theReferenceLineDataList = this.getLineSublineRefData.getReferenceDataForCaseLine();
    if (!!this.theReferenceLineDataList.linePurposeRefList && this.theReferenceLineDataList.linePurposeRefList.length == 0) {
      //should not get in here, but do this condition just in case
      setTimeout(() => {
        this.getLineSublineRefData.populateReferenceDataForCaseLine();
        this.theReferenceLineDataList = this.getLineSublineRefData.getReferenceDataForCaseLine();
      }, 1000);
    }
  }
  //end DSAMS-5269 DH 03/22 

  // begin DSAMS-5176 03/22 DB
  // Updated method FS 3/11/22 for Card 5111
  // WP103a FR104
  isNporDisabled() {
    //DH 05/22: Per Analyst - POR is enabled when adding a new line only. 
    //This is superceded all other check scenarios for new mode.
    if (this.caseLineInfoData.status == DsamsConstants.ENT_NEW.toString() &&
      CaseUtils.isBlankStr(this.caseLineInfoData.wm_USER_CASE_SUBLINE_TX)) {
      return false;
    }

    // Edit toggle is off
    if (this.isLineDetailDisabled) {
      // NPOR Option was selected
      if (this.isNporEnabledFromDropdown) {
        return false;
      }
      else {
        return true;
      }
    }
    // Edit toggle is on
    else {
      if (this._noprVisible && !this.getIsNporFieldDisabled()) {
        return false;
      }
      else {
        return true;
      }
    }
  }
  // end  DSAMS-5176 03/22 DB


  //per Sonarqube rule
  subscribeToNOPRService() {
    if (!this._updateNoprSubscription) {
      this._updateNoprSubscription = this.caseUIService.updateNopr.subscribe(() => {
        this.isNporEnabledFromDropdown = true;
      });
    }

    if (!this._nporListReadySubscription) {
      this._nporListReadySubscription = this.caseUIService.nporListReady.subscribe((pIsReady: boolean) => {
        this.readyToEnableNporPopup = pIsReady;
        if (this.readyToEnableNporPopup) {
          this.setProgramOfRecordDispFromId(this._databaseNpor);
        }
      });
    }
  }

 

  //per Sonarqube rule
  setCaseVersionStatus() {
    if (!CaseUtils.isBlankStr(this.caseLineInfoData.wm_CASE_VERSION_STATUS_CD)) {
      let versionStatus: string = this.caseLineInfoData.wm_CASE_VERSION_STATUS_CD;
      this.caseUIService.setIsCaseInReviewEnabled(CaseUtils.isOptionEnabledForCaseInReviewShortcut(versionStatus));
      this.caseUIService.setIsCaseInProposedEnabled(CaseUtils.isOptionEnabledForCaseInProposedShortcut(versionStatus));
      this.caseUIService.setIsPenInkEnabled(CaseUtils.isOptionEnabledForPenInkShortcut(versionStatus, this.caseLineInfoData.wm_CASE_VERSION_TYPE_CD, this.caseLineInfoData.case_USAGE_INDICATOR_CD));
    }
    else this.caseLineInfoData.wm_CASE_VERSION_STATUS_CD = '';
  }

  //per Sonarqube rule
  subsribeTocaseUIService2() {
    if (!this._caseUIServiceSubscription2) {
      this._caseUIServiceSubscription2 = this.caseUIService.getCaseLineInfoValues().subscribe((value) => {
        this.caseLineInfoData = value;
        this.resetNpor();
        this.isNporFieldDisabled = true;
        this.isNporEnabledFromDropdown = false;
        if (!!this.caseLineInfoData) {
          if (this.caseLineInfoData.caseLineAssistanceTypeList) {
            this.initializeCaseLineAssistanceTypeArray(this.caseLineInfoData.caseLineAssistanceTypeList);
          }
          else {
            this.caseLineInfoData.caseLineAssistanceTypeList = [];
            this.dataSourceTypeAssist.data = [];
            this.dataSourceTypeAssist._updateChangeSubscription();
          }
          this._theCloneCLATList = JSON.parse(JSON.stringify(this.caseLineInfoData.caseLineAssistanceTypeList));
          if (!!this.caseLineInfoData.line_PURPOSE_CD)
            this.caseLineInfoData.previousLPValue = this.caseLineInfoData.line_PURPOSE_CD;
          this.caseLineInfoData.isLinePurposeDisabled = LineUtils.isLinePurposeDisabled(this.caseLineInfoData);

          this.setCaseVersionStatus();
          this.setNoprEnabledness();
          //DH - Jira 1849
          this.setDisableCalculateFMSOMenuOption();
          this.setEnableCalculateFMSOMenuOption();
        }
      });
    }
  }

  //per Sonarqube rule
  subsribeToRefreshService() {
    if (!this._refreshDataSubscription) {
      this._refreshDataSubscription = this.caseUIService.getResetCaseLineFromRefreshButton().subscribe((value) => {
        if (value) {
          this.caseLineInfoData = value;
          this.resetNpor();
          if (this.caseLineInfoData.caseLineAssistanceTypeList) {
            this.initializeCaseLineAssistanceTypeArray(this.caseLineInfoData.caseLineAssistanceTypeList);
          }
          else {
            this.caseLineInfoData.caseLineAssistanceTypeList = [];
            this.dataSourceTypeAssist.data = [];
            this.dataSourceTypeAssist._updateChangeSubscription();
          }
          this._theCloneCLATList = JSON.parse(JSON.stringify(this.caseLineInfoData.caseLineAssistanceTypeList));
          this.setNoprEnabledness();
        }
      });
    }
  }

 

 

 

  

 
  unLock(lockSessionId: number) {
    if (lockSessionId > 0) {
      this.caseRestService.unLock(lockSessionId, sessionStorage.getItem('serviceDBid'))
        .subscribe(
          data => {
            console.log("### unLock: " + data);
            sessionStorage.setItem(LineDetailsComponent.LOCK_SESSION_ID, "0");
            this.refreshCaseLineData();
          },
          err => {
            console.log("Error occured: unLock()", err)
          }
        );
    }
  }
  // // end DSAMS-5205 02/2022 DB

  ngOnDestroy() {
    this.unlockCaseLineEntity();
    if (this.caseLineInfoData.isDataChanged) {
      this.caseUIService.caseEditService.next({
        ID: LineDetailsComponent.CASE_LINE_EDITOR_STR,
        editToggle: false
      });
      this.caseLineInfoData.isDataChanged = false;
     
    }

    //clear the  cache for caseLineInfoData
    this.initializeCaseLineInfo();
    //clear out the selected case line entity 
    this.caseUIService.setCaseLineInfoValues(this.caseLineInfoData);
    if (this._caseUIServiceSubscription1) {
      this._caseUIServiceSubscription1.unsubscribe();
      this._caseUIServiceSubscription1 = null;
    }
    if (this._caseUIServiceSubscription2) {
      this._caseUIServiceSubscription2.unsubscribe();
      this._caseUIServiceSubscription2 = null;
    }
    if (this._caseUIServiceSubscription3) {
      this._caseUIServiceSubscription3.unsubscribe();
      this._caseUIServiceSubscription3 = null;
    }
    if (this._editSubscription) {
      this._editSubscription.unsubscribe();
      this._editSubscription = null;
    }
    if (this._refreshDataSubscription) {
      this._refreshDataSubscription.unsubscribe();
      this._refreshDataSubscription = null;
    }
    if (!!this._popupMASLSubscription) {
      this._popupMASLSubscription.unsubscribe();
      this._popupMASLSubscription = null;
    }
    if (!!this._updateNoprSubscription) {
      this._updateNoprSubscription.unsubscribe();
      this._updateNoprSubscription = null;
    }
    if (!!this._nporListReadySubscription) {
      this._nporListReadySubscription.unsubscribe();
      this._nporListReadySubscription = null;
    }
    if (!!this._selectNporSubscription) {
      this._selectNporSubscription.unsubscribe();
      this._selectNporSubscription = null;
    }

    
    if (!!this._isLineManagerDisabledSubscription) {
      this._isLineManagerDisabledSubscription.unsubscribe();
      this._isLineManagerDisabledSubscription = null;
      this.caseUIService.setFieldLineManagerDisabled(true);
      this.caseUIService.setIsMgrEnabled2(false);
    }

    //Jeff added..
    if (!!this._milestoneSubscription) {
      this._milestoneSubscription.unsubscribe();
      this._milestoneSubscription = null;
    }

    if (!!this._resetDynamicRefListSub) {
      this._resetDynamicRefListSub.unsubscribe();
      this._resetDynamicRefListSub = null;
    }

    if (!!this.continueOnEditToggleSub) {
      this.continueOnEditToggleSub.unsubscribe();
      this.continueOnEditToggleSub = null;
    }
    if (!!this.saveOnEditToggleSub) {
      this.saveOnEditToggleSub.unsubscribe();
      this.saveOnEditToggleSub = null;
    }
  }

  /**
   * Set the NOPR subscription.
   */
  private setNoprEnabledness() {
    // Does not apply to sublines. 
    // Disabled if the case line is marked for deletion (true (1)).
    // Enabled for real and planning cases (i.e., cm.case_usage_indicator_cd = ‘C’ or ‘P’) only.
    // Enable only if the CHANGE_ACTION_CODE = ‘A’, ‘C’, or ‘U’ and CASE_VERSION_STATUS_CD = ‘’A’, ‘I’, ‘O’, ‘P’, ‘W’, or ‘R’.
    // Per feedback, at this time, make option not visible if case is in development.  FS - 3/28/2022.
    this._noprVisible = (this.caseLineInfoData.wm_USER_CASE_SUBLINE_TX !== "" && this.caseLineInfoData.wm_CASE_VERSION_STATUS_CD !== "D");
    const noprDisabled: boolean =
      (!!this.caseLineInfoData.case_LINE_MARK_FOR_DELETION_IN && (this.caseLineInfoData.case_LINE_MARK_FOR_DELETION_IN === "true" || this.caseLineInfoData.case_LINE_MARK_FOR_DELETION_IN == "1")) ||
      !(this.caseLineInfoData.case_USAGE_INDICATOR_CD === "P" ||
        this.caseLineInfoData.case_USAGE_INDICATOR_CD === "C") ||
      // Per feedback, disabled on Development Cases, will make not visible too in this._noprVisible
      !((this.caseLineInfoData.change_ACTION_CD === "A" && this.caseLineInfoData.wm_CASE_VERSION_STATUS_CD !== "D") ||
        (this.caseLineInfoData.change_ACTION_CD === "C" && this.caseLineInfoData.wm_CASE_VERSION_STATUS_CD !== "D") ||
        (this.caseLineInfoData.change_ACTION_CD === "U" && this.caseLineInfoData.wm_CASE_VERSION_STATUS_CD !== "D")) ||
      (this.caseLineInfoData.wm_CASE_VERSION_STATUS_CD === "CL" ||
        this.caseLineInfoData.wm_CASE_VERSION_STATUS_CD === "X");
    this.caseUIService.setIsNoprEnabled({ visible: this._noprVisible, disabled: noprDisabled });
  }

  subscribeToLineMgr() {
    this._isLineManagerDisabledSubscription = this.caseUIService.getFieldLineManagerDisabled().subscribe(value => {
      this.isLineManagerDisabled = value;
    });
  }

  //Set enable/disable to specific fields
  setSpecificFieldProperty() {
    //Tollgle the edit slider
    if (this.caseLineInfoData.status == DsamsConstants.ENT_NEW.toString()) {
      //all fields are enabled in New mode for line
      if (!CaseUtils.isBlankStr(this.caseLineInfoData.wm_USER_CASE_SUBLINE_TX)) {
        //disable fields in edit mode for a subline
        this.isSpecificSublineFieldDisabled = true;
      }
      else {
        this.isSpecificSublineFieldDisabled = false;
      }

      // Also need to make not required if it's disabled.
      this.maslFormCtl = this.isSpecificSublineFieldDisabled ? new FormControl('') :
        new FormControl('', [Validators.required, Validators.pattern(/^[A-z0-9]*$/)]);

      this.isNewMode = true;
      this.isLineDetailDisabled = false;
      this.isPercentStockDisabled = this.isPercentFieldDisabled();
      this.isCCAssocFieldsDisabled = this.isStockFieldsDisabled();
      this.isNporFieldDisabled = this.getIsNporFieldDisabled();
      this.caseUIService.caseEditService.next(
        {
          ID: LineDetailsComponent.CASE_LINE_EDITOR_STR,
          editToggle: true
        }
      );
      this.caseUIService.flipToEnabledService.next(LineDetailsComponent.CASE_LINE_EDITOR_STR);
    }
  }

  onPorSelectionChange(porId: number) {
    this.caseLineInfoData.program_OF_RECORD_ID = porId;
  }

  private setProgramOfRecordDisp(pValue: string) {
    this.programOfRecordDisp = (!pValue || pValue == "") ? "N/A" : pValue;
    this.caseLineInfoData.PORTitle = (!pValue || pValue == "") ? "N/A" : pValue;
  }

  private setProgramOfRecordDispFromId(pValue: number) {
    let dispValue: string = "";
    for (let nporItem of this.theReferenceLineDataList.programOfRecordList) {
      if (nporItem.integer_VALUE_CD == pValue) {
        dispValue = nporItem.value_TITLE_NM;
        break;
      }
    }
    this.setProgramOfRecordDisp(dispValue);
  }

  displayNporOption(id: number, pTitle: string, pDesc: string): string {
    const currPOR = !this.caseLineInfoData.program_OF_RECORD_ID ? 0 : this.caseLineInfoData.program_OF_RECORD_ID;
    return (currPOR == id && !this._nporDropdownExpanded) ? pTitle : pTitle + " - " + pDesc;
  }

  onNporDropdownClick() {
    this._nporDropdownExpanded = true;
  }

  onNporDropdownBlur() {
    this._nporDropdownExpanded = false;
  }

  onNporDropdownFocus() {
    this._nporDropdownExpanded = true;
  }

  private resetNpor() {
    if (!!this.caseLineInfoData)
      this._databaseNpor = !this.caseLineInfoData.program_OF_RECORD_ID ? 0 : this.caseLineInfoData.program_OF_RECORD_ID;
  }

  //return true to disable Percent Stock field if source of supply is not mixed value
  isPercentFieldDisabled(): boolean {
    if (!CaseUtils.isBlankStr(this.caseLineInfoData.supply_SOURCE_NUMBER_ID)) {
      if (!this.isLineDetailDisabled &&
        this.caseLineInfoData.supply_SOURCE_NUMBER_ID == LineUtils.SUPPLY_SOURCE_MIXED) {
        return false;
      }
    }
    return true;
  }

  //return true to disable Stock On Hand fields if case category code = FMSOI
  isStockFieldsDisabled(): boolean {
    if (!CaseUtils.isBlankStr(this.caseLineInfoData.case_CATEGORY_CD)) {
      if (!this.isLineDetailDisabled &&
        this.caseLineInfoData.case_CATEGORY_CD == LineUtils.CASE_CATEGORY_CD_FMSOI) {
        return false;
      }
    }
    return true;
  }

  // Determine if the NPOR field is disabled.
  private getIsNporFieldDisabled(): boolean {
    return !(this.caseLineInfoData.change_ACTION_CD === "A" &&
      this.caseLineInfoData.wm_CASE_VERSION_STATUS_CD === "D" &&
      (this.caseLineInfoData.case_USAGE_INDICATOR_CD === "C" || this.caseLineInfoData.case_USAGE_INDICATOR_CD === "P")
    );
  }

  // Subscribe to edit toggle event
  subscribeToEditToggle() {
    if (!this._editSubscription) {

      this._editSubscription = this.caseUIService
        .caseEditService
        .subscribe((pResponse: IEditResponseType) => {
          if (pResponse && (pResponse.ID === LineDetailsComponent.CASE_LINE_EDITOR_STR || pResponse.ID === DsamsConstants.CASE_LINE_EDITOR || pResponse.ID === DsamsConstants.PAGE_CASE_LINE)) {
            this.isLineDetailDisabled = !pResponse.editToggle;
           
            this.caseUIService.setIsLineDataInEditMode(pResponse.editToggle);
            //DH - Jira 1849
            setTimeout(() => {
              this.setDisableCalculateFMSOMenuOption();
            }, 100);
            setTimeout(() => {
              this.setEnableCalculateFMSOMenuOption();
            }, 100);
            if ((this.isLineDetailDisabled) || (!!this.caseLineInfoData) && !CaseUtils.isBlankStr(this.caseLineInfoData.wm_USER_CASE_SUBLINE_TX))
              this.isSpecificSublineFieldDisabled = true;
            else if (!this.isLineDetailDisabled)
              this.isSpecificSublineFieldDisabled = false;
            LineUtils.getTotalQuantity(this.caseLineInfoData);
            this.isPercentStockDisabled = this.isPercentFieldDisabled();
            this.isCCAssocFieldsDisabled = this.isStockFieldsDisabled();
            this.isNporFieldDisabled = this.getIsNporFieldDisabled();
            this.addAssistanceBtnColor = pResponse.editToggle ? this.ActiveBtnColor : this.InactiveBtnColor;
            this.checkEditAbilityForLineDetail(pResponse.editToggle);
          }
        },
          err => {
            CaseUtils.ReporError("in Line List responding to edit toggle");
          }
        );
    }
  }



  //Enable/Disable input fields
  checkEditAbilityForLineDetail(pEditToggle: boolean) {
    if (pEditToggle) {
      this.addAssistanceBtnColor = this.ActiveBtnColor;
      // begin DSAMS-5205 02/2022 DB
      // if (this.caseLineInfoData.case_MASTER_LINE_ID && !this.caseLineIsLocked) {
      //   this.lockCaseLineEntity();
      // }
      // end DSAMS-5205 02/2022 DB

      if (!this.cancelClicked){
      this.caseLineInfoDataOrig=JSON.parse(JSON.stringify(this.caseLineInfoData));
      this.caseUIService.setCaseLineToggleAction(DsamsConstants.SET_ORIG);      
       } else {
        this.cancelClicked=false;
      }
    }
    else {
     
      if ((!!this.caseLineInfoData) && this.caseLineInfoData.isDataChanged) {
         if (this.caseLineInfoData.isTemporarilySkipSavePrompt) {
          this.caseLineInfoData.isTemporarilySkipSavePrompt = false;
          
 
          return;
        }
      }
    //   else {
    //     // begin DSAMS-5205 02/2022 DB
    //     this.unlockCaseLineEntity();
    //     // end DSAMS-5205 02/2022 DB
    //  }

    }
  }
  
  resetCLATAttribute() {
    if (!!this.dataSourceTypeAssist)
      this.dataSourceTypeAssist.data.forEach(element => {
        element.isFieldDisabled = true;
      });
  }

  //obsolete method as cancel button is eliminated
  _refreshLineDetailData() {
    //Due to limitation of cloning 2 level depth of array lists, so implement as below to circumvent the limitation
    if (this._theCloneCLATList) {
      this.dataSourceTypeAssist.data = [];
      for (let i = 0; i < this._theCloneCLATList.length; i++) {
        this.theInitialCaseLineInfoData.caseLineAssistanceTypeList[i].status = DsamsConstants.ENT_UNCHANGED.toString();
        this.theInitialCaseLineInfoData.caseLineAssistanceTypeList[i].assistance_TYPE_CD = this._theCloneCLATList[i].assistance_TYPE_CD;
        this.theInitialCaseLineInfoData.caseLineAssistanceTypeList[i].isFieldDisabled = true;
        this.dataSourceTypeAssist.data.push(this.theInitialCaseLineInfoData.caseLineAssistanceTypeList[i]);
      }
      this.dataSourceTypeAssist._updateChangeSubscription();
    }
    //Recloning an observable object to keep the latest data
    this.caseUIService.setCaseLineInfoValues(this.theInitialCaseLineInfoData);
    this.resetAttributesStatus();
    this.caseUIService.setNotifyToRefreshLineData(true);
    //Refresh data for Line Delivery tab
    LineUtils.getTotalQuantity(this.caseLineInfoData);
  }

  //Since this is a tab window, need to initialize needed attributes 
  //for this tab as caseLineInfoData inherits an interface class
  initializeCaseLineInfo() {
    //since it is an interface, we need to initialize them
    //Set initial values to avoid display undefined values error
    this.caseLineInfoData = {
      //this is for Header section
      wm_USER_CASE_LINE_NUMBER_ID: '',
      wm_USER_CASE_SUBLINE_TX: '',
      wm_CASE_LINE_LOI_IN: false,
      wm_CML_SERVICES_COMPLETE_IN: false,
      wm_EXCLUSION_IN: false,
      wm_CASE_VERSION_STATUS_CD: '',
      change_ACTION_TITLE_NM: '',
      offer_EXPIRATION_DT: '',
      implementing_AGENCY_ID: '',
      LINESUBLINESEQVIR: '',
      case_CUSTOMER_TYPE_CD: '',
      customer_ORGANIZATION_ID: '',
      //this is for Line Detail tab
      case_LINE_ITEM_QY: '', generic_CD: '', military_ARTICLE_SERVICE_CD: '',
      line_PURPOSE_CD: '', line_PURPOSE_TITLE_NM: '', issue_UNIT_CD: '',
      article_DESCRIPTION_TX: '', major_DEFENSE_EQUIPMENT_CD: '', equipment_TYPE_TITLE_NM: '',
      stock_ON_ORDER_COST_AM: '0', stock_ON_HAND_COST_AM: '0', total_ABOVE_LINE_COST_AM: '',
      unit_ABOVE_LINE_COST_AM: '', part_NUMBER_IN: false, other_PART_NUMBER_IN: false,
      acquisition_VALUE_AM: '0', inventory_VALUE_AM: '0', percent_STOCK_RT: '',
      missile_TECH_CNTRL_REGIME_ID: '', mtcr_TITLE_NM: '', mde_SME_CD: '', parent_MDE_SME_CD: '',
      national_STOCK_NUMBER_ID: '', other_NATIONAL_STOCK_NUMBER_ID: '',
      caseLineAssistanceTypeList: [],
      //this is for delivery tab
      case_LINE_PERIOD_START_QY: '', case_LINE_PERIOD_END_QY: '',
      case_LINE_PAY_PERIOD_START_QY: '', case_LINE_PAY_PERIOD_END_QY: '',
      case_LINE_AVAILABILITY_LEAD_QY: '', case_LINE_SHIPMENT_TX: '',
      estimated_DELIVERY_END_DT: '',
      estimated_DELIVERY_DT: '',
      shipment_STATUS_ID: '',
      title_NM: '',
      sumOfAllQuantities: 0,
      caseLineDeliveryItemList: [], caseLineOfferReleaseList: [], caseLineDeliveryTermList: [],
      //private attributes
      isLinePurposeDisabled: false
    }

    LineUtils.theDeletedCLATListArray = [];
  }

  initializeCaseLineAssistanceTypeArray(pCaseLineAssistanceTypeList: ifaceCaseLineAssistanceTypeEntity[]) {
    this.aTypeAssistRowIndex = pCaseLineAssistanceTypeList.length;
    this.dataSourceTypeAssist.data = [];
    for (let i = 0; i < this.aTypeAssistRowIndex; i++) {
      this.caseLineInfoData.caseLineAssistanceTypeList[i].status = DsamsConstants.ENT_UNCHANGED.toString();
      this.caseLineInfoData.caseLineAssistanceTypeList[i].isFieldDisabled = true;
      this.dataSourceTypeAssist.data.push(this.caseLineInfoData.caseLineAssistanceTypeList[i]);
    }
    this.dataSourceTypeAssist._updateChangeSubscription();
  }

  //Add new row to CLAT table
  addNewTypeAssist() {
    var anAssistanceTypeObject: ifaceAssistanceTypeEntity = { assistance_TYPE_CD: '', assistance_TYPE_TITLE_TX: '' };
    var aCLAssistanceTypeObject: ifaceCaseLineAssistanceTypeEntity =
    {
      assistance_TYPE_CD: '',
      theAssistanceTypeCd: anAssistanceTypeObject,
      isFieldDisabled: false,
      // fcFieldRequired: new FormControl('', [Validators.required]),
    }
    // for new entity
    if (this.caseLineInfoData.caseLineAssistanceTypeList == null) {
      this.caseLineInfoData.caseLineAssistanceTypeList = [];
    }
    aCLAssistanceTypeObject.status = DsamsConstants.ENT_NEW.toString();
    this.caseLineInfoData.caseLineAssistanceTypeList.push(aCLAssistanceTypeObject);
    this.dataSourceTypeAssist.data.push(aCLAssistanceTypeObject);
    this.dataSourceTypeAssist = new MatTableDataSource(this.dataSourceTypeAssist.data);
    this.dataSourceTypeAssist._updateChangeSubscription();
    this.caseLineInfoData.isDataChanged = true;
    this.caseUIService.theComponentSaveCaseLineState[CaseUIService.SAVE_CASE_LINE_DETAILS_STATE].isDataChanged = true;
  }

  //Delete existing row from CLAT table
  delTypeAssistRow(rowElement: any) {
    this.caseLineInfoData.isDataChanged = true;
    this.caseUIService.theComponentSaveCaseLineState[CaseUIService.SAVE_CASE_LINE_DETAILS_STATE].isDataChanged = true;
    let rowIndex = this.dataSourceTypeAssist.data.indexOf(rowElement);
    if (this.caseLineInfoData.status !== DsamsConstants.ENT_NEW.toString()) {
      if (this.caseLineInfoData.caseLineAssistanceTypeList[rowIndex].status !== DsamsConstants.ENT_NEW.toString()) {
        if (LineUtils.theDeletedCLATListArray == null) LineUtils.theDeletedCLATListArray = [];
        this.caseLineInfoData.caseLineAssistanceTypeList[rowIndex].status = DsamsConstants.ENT_DELETED.toString();
        LineUtils.theDeletedCLATListArray.push(this.caseLineInfoData.caseLineAssistanceTypeList[rowIndex]);
        this.caseUIService.setTheDeletedCLATList(LineUtils.theDeletedCLATListArray);
      }
      //set it to changed so it can be updated
      this.caseLineInfoData.entityStatus = DsamsConstants.ENT_CHANGED.toString();
    }
    this.caseLineInfoData.caseLineAssistanceTypeList.splice(
      this.caseLineInfoData.caseLineAssistanceTypeList.indexOf(rowElement), 1);
    this.dataSourceTypeAssist.data.splice(this.dataSourceTypeAssist.data.indexOf(rowElement), 1);
    this.dataSourceTypeAssist = new MatTableDataSource(this.dataSourceTypeAssist.data);
  }

  /* This procedure checks the returned result value from the 
      popover Yes/No dialog window. */
  yesButtonOnClick(isDeleteConfirmed: any, rowElement: any) {
    if (isDeleteConfirmed)
      this.delTypeAssistRow(rowElement);
  }

  //breakout logic per sonarqube rule
  onNSNCheckBoxChange() {
    if (!CaseUtils.isBlankStr(this.caseLineInfoData.national_STOCK_NUMBER_ID)) {
      MessageMgr.swalFire({
        text: 'By clicking on this, any data entered in the associated P/N data entry field will be cleared out.  Do you want to continue?',
        icon: 'warning',
        width: 500,
        showCancelButton: true,
        cancelButtonText: 'No',
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes',
      }).then((result) => {
        if (result.value) {
          this.caseLineInfoData.national_STOCK_NUMBER_ID = '';
        }
        else this.caseLineInfoData.part_NUMBER_IN = !this.caseLineInfoData.part_NUMBER_IN;
      })
    }
  }

  onCheckBoxChange(pOtherNSN: boolean) {
    if (pOtherNSN) {
      this.caseLineInfoData.other_PART_NUMBER_IN = !this.caseLineInfoData.other_PART_NUMBER_IN;
      if (!CaseUtils.isBlankStr(this.caseLineInfoData.other_NATIONAL_STOCK_NUMBER_ID)) {
        MessageMgr.swalFire({
          text: 'By clicking on this, any data entered in the associated Other P/N data entry field will be cleared out.  Do you want to continue?',
          icon: 'warning',
          width: 500,
          showCancelButton: true,
          cancelButtonText: 'No',
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: 'Yes',
        }).then((result) => {
          if (result.value) {
            this.caseLineInfoData.other_NATIONAL_STOCK_NUMBER_ID = '';
          }
          else this.caseLineInfoData.other_PART_NUMBER_IN = !this.caseLineInfoData.other_PART_NUMBER_IN;
        })
      }
    }
    else {
      this.caseLineInfoData.part_NUMBER_IN = !this.caseLineInfoData.part_NUMBER_IN;
      this.onNSNCheckBoxChange();
    }
    this.caseLineInfoData.isDataChanged = true;
    this.caseUIService.theComponentSaveCaseLineState[CaseUIService.SAVE_CASE_LINE_DETAILS_STATE].isDataChanged = true;
  }

  //FR15 - //On input check to ensure Line Purpose code is valid
  isSublineAlowedIn(pLinePurposeCd: string): boolean {
    var status: boolean = false;
    //generic reference column value_IN1 is SUBLINE_ALLOWED_IN
    //generic reference column value_CD is line_PURPOSE_CD
    for (let eachLP of this.theReferenceLineDataList.linePurposeRefList) {
      if (!eachLP.value_IN1 &&
        (this.caseLineInfoData.wm_HAS_SUBLINES || !CaseUtils.isBlankStr(this.caseLineInfoData.wm_USER_CASE_SUBLINE_TX))) {
        if (CaseCommonValidator.isEqual(pLinePurposeCd, eachLP.value_CD)) {
          status = true;
          break;
        }
      }
    }
    if (status) {
      let messageStr = "You have chosen a Line Purpose that is not available for a Line/Subline.";
      let confirmMsg: any = {
        text: messageStr,
        icon: 'warning',
        width: 400,
        focusConfirm: true,
        confirmButtonText: 'OK'
      };
      MessageMgr.swalFire(confirmMsg).then((result) => {
        if (result.value) {
          this.linePurposeFormCtl.setValue(this.caseLineInfoData.previousLPValue);
          this.linePurposeFormCtl.markAsPristine();
          this.caseLineInfoData.line_PURPOSE_CD = this.caseLineInfoData.previousLPValue;
        }
      })
    }
    return status;
  }

  //store the modified valued to the case line entity for saving purposes
  onSelectionChange(pColumName: any, pValue: string) {
    //Do nothing in View mode
    if (this.isLineDetailDisabled && this.isLineManagerDisabled && this.isNporFieldDisabled && !this.isNporEnabledFromDropdown) {
      return; //Added isLineManagerDisabled - if false do the switch.
    }
    //To avoid using NgModel in Mat-Select, use this quick and simple approach to 
    //remap modified values selected on screen
    switch (pColumName) {
      case "line_PURPOSE_CD": {
        if (pValue == '' || pValue == null) {
          this.linePurposeFormCtl.markAsTouched();
        }
        else {
          if (!(this.isSublineAlowedIn(pValue))) {
            if (CaseCommonValidator.isEqual(pValue, LineUtils.LINE_PURPOSE_CE)) {
              let messageStr = "You have chosen a Line Purpose that cannot be changed after the data is saved. Do you to continue?";
              let confirmMsg: any = {
                text: messageStr,
                icon: 'warning',
                showCancelButton: true,
                cancelButtonText: 'No',
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes',
              };
              MessageMgr.swalFire(confirmMsg).then((result) => {
                if (result.value) {
                  this.linePurposeFormCtl.setValue(pValue);
                  this.linePurposeFormCtl.markAsPristine();
                  this.caseLineInfoData.line_PURPOSE_CD = pValue;
                  this.caseLineInfoData.previousLPValue = pValue;
                }
                else {
                  this.linePurposeFormCtl.setValue(this.caseLineInfoData.previousLPValue);
                  this.linePurposeFormCtl.markAsPristine();
                  this.caseLineInfoData.line_PURPOSE_CD = this.caseLineInfoData.previousLPValue;
                }
              })
            }
          }
          else {
            this.linePurposeFormCtl.setValue(pValue);
            this.linePurposeFormCtl.markAsPristine();
            if (this.caseLineInfoData.line_PURPOSE_CD !== pValue)
              this.caseLineInfoData.line_PURPOSE_CD = pValue;
          }
          // Card 5204 - Ensure that selection change is a data change
          this.caseLineInfoData.isDataChanged = true;
        }
        break;
      }
      case "activity_ID": {
        if (this.caseLineInfoData.activity_ID !== pValue)
          this.caseLineInfoData.activity_ID = pValue;
        break;
      }
      case "supply_SOURCE_NUMBER_ID": {
        if (this.caseLineInfoData.supply_SOURCE_NUMBER_ID !== pValue)
          this.caseLineInfoData.supply_SOURCE_NUMBER_ID = pValue;
        this.isPercentStockDisabled = this.isPercentFieldDisabled();
        break;
      }
      case "line_MANAGER_ID": {
        if (this.caseLineInfoData.line_MANAGER_ID !== pValue)
          this.caseLineInfoData.line_MANAGER_ID = pValue;
        this.theReferenceLineDataList.operatingAgencyRefList =
          this.getLineSublineRefData.getOperatingAgencyRefData(this.caseLineInfoData);
        break;
      }
      case "condition_CD": {
        if (this.caseLineInfoData.condition_CD !== pValue)
          this.caseLineInfoData.condition_CD = pValue;
        break;
      }
      case "operating_AGENCY_CD": {
        if (this.caseLineInfoData.operating_AGENCY_CD !== pValue)
          this.caseLineInfoData.operating_AGENCY_CD = pValue;
        this.theReferenceLineDataList.lineManagerRefList =
          this.getLineSublineRefData.getLineManagerRefData(this.caseLineInfoData);
        break;
      }
      case "training_NOTE_CD": {
        if (this.caseLineInfoData.training_NOTE_CD !== pValue)
          this.caseLineInfoData.training_NOTE_CD = pValue;
        break;
      }
      case "supporting_ORGANIZATION_ID": {
        if (this.caseLineInfoData.supporting_ORGANIZATION_ID !== pValue)
          this.caseLineInfoData.supporting_ORGANIZATION_ID = pValue;
        break;
      }
      case "budget_APPROPRIATION_CD": {
        if (this.caseLineInfoData.budget_APPROPRIATION_CD !== pValue)
          this.caseLineInfoData.budget_APPROPRIATION_CD = pValue;
        break;
      }
      case "issue_UNIT_CD": {
        if (this.caseLineInfoData.issue_UNIT_CD !== pValue)
          this.caseLineInfoData.issue_UNIT_CD = pValue;
        break;
      }
      case "program_OF_RECORD_ID": {
        const lValue: string = pValue ? pValue : "0";
        if (!this.caseLineInfoData.program_OF_RECORD_ID) {
          this.caseLineInfoData.program_OF_RECORD_ID = 0;
        }
        if (this.caseLineInfoData.program_OF_RECORD_ID.toString() !== lValue) {
          this.caseLineInfoData.program_OF_RECORD_ID = +lValue;
          this._nporDropdownExpanded = false;
          this.setProgramOfRecordDispFromId(this.caseLineInfoData.program_OF_RECORD_ID);
          this.caseUIService.nporChanged.next(this.caseLineInfoData.program_OF_RECORD_ID !== this._databaseNpor);
        }
        break;
      }
      //default: '';
    }
    if (this.caseLineInfoData.status !== DsamsConstants.ENT_NEW.toString()) {
      this.caseLineInfoData.status = DsamsConstants.ENT_CHANGED.toString();
      this.caseLineInfoData.entityStatus = DsamsConstants.ENT_CHANGED.toString();
    }
    this.caseLineInfoData.isDataChanged = true;
    this.caseUIService.theComponentSaveCaseLineState[CaseUIService.SAVE_CASE_LINE_DETAILS_STATE].isDataChanged = true;
  }

  //begin DSASM-5111 DH 03/22
  setEntityChanged() {
    if (this.caseLineInfoData.status !== DsamsConstants.ENT_NEW.toString()) {
      this.caseLineInfoData.status = DsamsConstants.ENT_CHANGED.toString();
      this.caseLineInfoData.entityStatus = DsamsConstants.ENT_CHANGED.toString();
    }
    this.caseLineInfoData.isDataChanged = true;
    this.caseUIService.theComponentSaveCaseLineState[CaseUIService.SAVE_CASE_LINE_DETAILS_STATE].isDataChanged = true;
  }

  onSelectionPORChange(pValue: ifaceGenericRefItem) {
    if (!this.caseLineInfoData.program_OF_RECORD_ID) {
      this.caseLineInfoData.program_OF_RECORD_ID = 0;
    }
    if (this.caseLineInfoData.program_OF_RECORD_ID !== pValue.integer_VALUE_CD) {
      this.caseLineInfoData.program_OF_RECORD_ID = pValue.integer_VALUE_CD;
      this.caseLineInfoData.PORTitle = pValue.value_TITLE_NM;
      this._nporDropdownExpanded = false;
      this.setEntityChanged();
      this.caseUIService.nporChanged.next(this.caseLineInfoData.program_OF_RECORD_ID !== this._databaseNpor);
    }
  }
  //end DSASM-5111 DH 03/22

  //per sonarqube rule
  setCLAStatus(pIndex: any) {
    if (this.caseLineInfoData.status == DsamsConstants.ENT_NEW.toString())
      this.caseLineInfoData.caseLineAssistanceTypeList[pIndex].status = DsamsConstants.ENT_NEW.toString();
    else {
      if (this.caseLineInfoData.caseLineAssistanceTypeList[pIndex].status !== DsamsConstants.ENT_NEW.toString() &&
        this.caseLineInfoData.caseLineAssistanceTypeList[pIndex].status !== DsamsConstants.ENT_DELETED.toString())
        this.caseLineInfoData.caseLineAssistanceTypeList[pIndex].status = DsamsConstants.ENT_CHANGED.toString();
    }
  }

  //store the modified valued to the case line entity for saving purposes
  onCLSelectionChange(pColumName: any, pValue: string, pIndex: any) {
    //Do nothing in View mode
    if (this.isLineDetailDisabled) return;
    //To avoid using NgModel in Mat-Select, use this quick and simple approach to 
    //remap modified values selected on screen
    switch (pColumName) {
      case "assistance_TYPE_CD": {
        if (pValue == '' || pValue == null || pValue == 'N/A') {
          break;
        }
        else {
          //store the changed values first into the array before checking for duplicate
          this.caseLineInfoData.caseLineAssistanceTypeList[pIndex].assistance_TYPE_CD = pValue;
          this.caseLineInfoData.caseLineAssistanceTypeList[pIndex].theAssistanceTypeCd.assistance_TYPE_CD = pValue;
          if (this.isDuplicateCLATRowFound(pValue)) {
            //clear duplicate value
            this.caseLineInfoData.caseLineAssistanceTypeList[pIndex].assistance_TYPE_CD = "";
            this.caseLineInfoData.caseLineAssistanceTypeList[pIndex].theAssistanceTypeCd.assistance_TYPE_CD = "";
            this.dataSourceTypeAssist.data[pIndex].assistance_TYPE_CD = "";
            break;
          }
          this.setCLAStatus(pIndex);
          break;
        }
      }
    }
    if (this.caseLineInfoData.status !== DsamsConstants.ENT_NEW.toString()) {
      this.caseLineInfoData.status = DsamsConstants.ENT_CHANGED.toString();
      this.caseLineInfoData.entityStatus = DsamsConstants.ENT_CHANGED.toString();
    }
    this.caseLineInfoData.isDataChanged = true;
    this.caseUIService.theComponentSaveCaseLineState[CaseUIService.SAVE_CASE_LINE_DETAILS_STATE].isDataChanged = true;
    this.dataSourceTypeAssist._updateChangeSubscription();
  }

  //back to previous Case Search Summary page 
  goBackToCaseSearchSummary() {
    this.caseUIService.setbackToCaseSearchSummaryValue(true);
    //Disable Line and Pricing tabs
    this.caseUIService.setIsLineTabDisabled(true);
    this.router.navigateByUrl('/case/search');
  }

  //do this for now until validation check is implemented
  prepareCaselineEntity() {
    LineUtils.prepareCaselineEntity(this.caseLineInfoData);
    //prepare deleted entities when applicable
    LineUtils.prepareCLATEntity(this.caseLineInfoData, LineUtils.theDeletedCLATListArray);
    this.prepareCLOREntity();
    this.prepareCLDTEntity();
    this.prepareCLDIEntity();
    this.prepareCLDSEntity();
  }

  //prepare common data for saving
  prepareCLOREntity() {
    this.caseUIService.getTheDeletedCLORList().subscribe((value) => {
      LineUtils.theDeletedCLORListArray = value;
    });
    LineUtils.prepareCLOREntity(this.caseLineInfoData, LineUtils.theDeletedCLORListArray);
  }

  prepareCLDTEntity() {
    this.caseUIService.getTheDeletedCLDTList().subscribe((value) => {
      LineUtils.theDeletedCLDTListArray = value;
    });
    LineUtils.prepareCLDTEntity(this.caseLineInfoData, LineUtils.theDeletedCLDTListArray);
  }

  prepareCLDIEntity() {
    this.caseUIService.getTheDeletedCLDIList().subscribe((value) => {
      LineUtils.theDeletedCLDIListArray = value;
    });
    LineUtils.prepareCLDIEntity(this.caseLineInfoData, LineUtils.theDeletedCLDIListArray)
  }

  prepareCLDSEntity() {
    this.caseUIService.getTheDeletedCLDSList().subscribe((value) => {
      LineUtils.theDeletedCLDSListArray = value;
    });
    LineUtils.prepareCLDSEntity(this.caseLineInfoData, LineUtils.theDeletedCLDSListArray)

  }

  /* This method converts currency to string for calculation */
  removeDollarSign(pVal: string): string {
    // Strip off dollar sign
    if (!!pVal)
      return (pVal.replace(/[^0-9.-]+/g, ""));
    else return (pVal);
  }

  //prepare entity data for legacy Save


  saveButtonOnClick() {
    if (this.performValidationFieldCheck()) {
      if ( this.caseLineInfoData.isDataChanged) {
        var saveMessage: string = 'Are you sure you want to save?';
        if (LineUtils.isPSCode(this.caseLineInfoData))
          saveMessage = LineUtils.PSCaseMessage.concat(saveMessage);
        let savePrompt: any =
        {
          text: saveMessage,
          icon: 'question',
          width: 350,
          showCancelButton: true,
          cancelButtonText: 'No',
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: 'Yes',
        };
        MessageMgr.swalFire(savePrompt).then((result) => {
          if (result.value) {
            this._milestoneSubscription = this.caseUIService.milestoneAddService.pipe(take(1)).subscribe((value) => {
              if (value == "PENINK" || value == "CWDREDIT" || value == "CWDPEDIT")
                this.saveMilestone();
              else
                this.performSaveDataOperation();
              if (!this.isLineManagerDisabled) {
                this.caseUIService.setFieldLineManagerDisabled(true); //See shortcuts UCM2
              }
            })
          }
        })
      }
      else {
        let nctsPrompt: any = {
          text: 'No change has been made.',
          icon: 'info',
          showConfirmButton: false,
          timer: 1500,
          width: 350
        };
        MessageMgr.swalFire(nctsPrompt);
      }
    }
  }

  //Saving data to the database server
  performSaveDataOperation() {
    this.caseRestService.saveCaseLineListFromServer(this.prepareCaseMasterLineEntity()).subscribe(
      result => {
        //Clear the array status after a successful Save/Delete
        MessageMgr.displaySuccessWithTimer('Save was successful', 2000);
        let msgArray: Array<ErrorParameter> = null;
        if (!!result.wm_errorMessageArray) {
          msgArray = result.wm_errorMessageArray;
        }
        else {
          msgArray = LineUtils.collectPostSaveMessages(result.wm_POST_SAVE_MESSAGES);
        }

        if (msgArray.length > 0) {
          this.messageService.displayMessageListTc("Case Line Warnings", msgArray).subscribe(result => { });
          this._hasNporWarnings = true;
        }
        else {
          this._hasNporWarnings = false;
        }
        this.resetAttributesStatus();
        if (this.caseLineInfoData.isPricingDataChanged)
          MessageMgr.displayInfoWithTimer('There are unsaved Pricing changes. Proceed to Pricing tab to save.', 2500);
      },
      err => {
        CaseUtils.ReportHTTPError(err, "saving Case Line data");
        console.log('Error saving the Case Line data')
        MessageMgr.displayErrorWithTimer('Error saving Case Line data', 1500);
        this.refreshCaseLineData();
      },
    );
  }

  // begin DSAMS-5983 09 DB
  private caseLineIsLocked: boolean = false;
 
  

 
 

  setLock(pTableName: string, pInputPara: string) {
    if (this.getCaseLineLockSessionId() == 0) { 
       this.caseRestService.validateLock(pTableName, pInputPara, sessionStorage.getItem('serviceDBid'))
        .subscribe(
          lockMegs => {
            if (lockMegs == null || lockMegs == "") {
              console.log("### Start to setLock")
              this.caseRestService.setLock(false, pTableName, 32, pInputPara, sessionStorage.getItem('serviceDBid'))
                .subscribe(
                  lockSessionId => {
                    console.log("### Lock sessionID: " + lockSessionId);
                    sessionStorage.setItem(LineDetailsComponent.LOCK_SESSION_ID, lockSessionId);
                    // begin DSASM-5867 08/22 DB
                    this.refreshCaseLineData();
                    // end DSASM-5867 08/22 DB
                  },
                  err => {
                    this.caseLineIsLocked = false;
                     this.isLoading.next(false);
                    console.log("Error occured: setLock()", err);
                  });
              //  
            } else {
              this.caseLineIsLocked = false;
               const editResponse: IEditResponseType = {
                ID: DsamsConstants.CASE_LINE_EDITOR,
                editToggle: false
              };
              this.caseUIService.caseEditService.next(editResponse);
              //post M7
              this._snackBar.open("This data is already locked by user " + lockMegs, 'close', {
                duration: 5000,
                panelClass: ['mat-toolbar', 'mat-warn'] // 'mat-accent' or 'mat-warn'
              });
              this.isLoading.next(false);
            }
          });
        }
  }

  lockCaseLineEntity() {
    
    if (this.caseUIService.getIsLineTabDisabled() ||
      (!this.caseLineInfoData.case_MASTER_LINE_ID && !this.caseLineInfoDataOrig.case_MASTER_LINE_ID) ) {
      return;
    }
    this.caseLineIsLocked = true;
    let pkValues: string = this.getCaseLineKeyValues();
    this.setLock("CASE_LINE", pkValues);
  }

  getCaseLineKeyValues(): string {
    let cmle: ifaceCaseMasterLineEntity = LineUtils.prepareLineDetailDataForSave(this.caseLineInfoData);
    let cl: ifaceCaseLineEntity = LineUtils.prepareCLDataForSave(cmle);
    let clKey: string = cl.case_MASTER_LINE_ID + LineDetailsComponent.KEY_DELIMETER +
      cl.case_ID + LineDetailsComponent.KEY_DELIMETER +
      cl.working_CASE_VERSION_ID + LineDetailsComponent.KEY_DELIMETER +
      cl.working_CASE_ID;

    return clKey;
  }

  unlockCaseLineEntity() {
    this.caseLineIsLocked = false;
    this.unLock(this.getCaseLineLockSessionId());
  }
   // unlockCaseLineEntity() {
  //   this.caseLineIsLocked = false;
  //   this.unLock(this.getCaseLineLockSessionId());
  // }

  getCaseLineLockSessionId(): number {
    let lockId: string = sessionStorage.getItem(LineDetailsComponent.LOCK_SESSION_ID);
    if (lockId == null) {
      lockId = "0";
      sessionStorage.setItem(LineDetailsComponent.LOCK_SESSION_ID, lockId);
    }
    return parseInt(lockId);

  }
// end DSAMS-5983 09 DB

  prepareCaseMasterLineEntity(): ifaceCaseMasterLineEntity {
    var aCaseMasterLine: ifaceCaseMasterLineEntity = {};

    // this.caseLineInfoData.program_OF_RECORD_ID = !this.caseLineInfoData.program_OF_RECORD_ID?0:this.caseLineInfoData.program_OF_RECORD_ID;
    // Determine if the NPOR needs to be checked.
    this.caseLineInfoData.wm_CHECK_NPOR = (this._databaseNpor !== this.caseLineInfoData.program_OF_RECORD_ID && LineUtils.doNporCheck(this.caseLineInfoData));

    //prepare data for saving
    aCaseMasterLine = LineUtils.prepareCaseMasterLineEntity(this.caseLineInfoData);
    aCaseMasterLine.caseLineList = [];
    aCaseMasterLine.theICaseLinePricing = { case_ID: 1111 };
    this.prepareCaselineEntity();
    const theCaseLineDetail: ifaceCaseLineData = LineUtils.prepareLineDetailDataForSave(this.caseLineInfoData)
    aCaseMasterLine.caseLineList.push(theCaseLineDetail);
    return aCaseMasterLine;
  }

  //reset all applicable attributes
  resetAttributesStatus() {
   
    this.caseLineInfoData.isDataChanged = false;
    this.caseUIService.theComponentSaveCaseLineState[CaseUIService.SAVE_CASE_LINE_DETAILS_STATE].isDataChanged = false;
    this.caseUIService.setIsLineTabDisabled(false);
    this.caseLineInfoData.isLineNumberChanged = false;
    this.caseLineInfoData.isEntityNew = false;
    this.caseLineInfoData.status = DsamsConstants.ENT_UNCHANGED.toString();
    this.caseLineInfoData.entityStatus = DsamsConstants.ENT_UNCHANGED.toString();
    LineUtils.theDeletedCLATListArray = [];
    LineUtils.theDeletedCLDIListArray = [];
    LineUtils.theDeletedCLDTListArray = [];
    LineUtils.theDeletedCLDSListArray = [];
    LineUtils.theDeletedCLORListArray = [];

    this.caseLineInfoData.wm_SaveCL = false;
    this.caseLineInfoData.wm_SaveCML = false;
    this.resetCLATAttribute();

    LineUtils.resetCLATEntityToUnChanged(this.caseLineInfoData);
    this.caseLineInfoData.isLinePurposeDisabled = LineUtils.isLinePurposeDisabled(this.caseLineInfoData);
    //this.theInitialCaseLineInfoData = { ... this.caseLineInfoData };
    //this.caseUIService.setCaseLineInfoValues(this.theInitialCaseLineInfoData);
    this.dataSourceTypeAssist._updateChangeSubscription();

    //Reset whethere Line No. & Subline No. can be changed, false = no.
    //this.caseUIService.allowLineChange.next(false);
    //this.caseUIService.allowSublineChange.next(false);

    // Reset NPOR changed flag and notify neighboring panel, but only if no NPOR warnings.
    if (!this._hasNporWarnings) {
      this._databaseNpor = this.caseLineInfoData.program_OF_RECORD_ID;
      this.caseUIService.nporChanged.next(false);
      if (this.isLineDetailDisabled) {
        this.isNporFieldDisabled = true;
      }
      this.isNporEnabledFromDropdown = false;
    }
  }

  saveMilestone() {
    this._milestoneSubscription = this.caseUIService.milestoneAddService.pipe(take(1)).subscribe((value) => {
      if (value === "PENINK") {
        this.openMilestoneCommentDialog("PENINK");
      } else if (value === "CWDREDIT") {
        this.openMilestoneCommentDialog("CWDREDIT");
      } else if (value === "CWDPEDIT") {
        this.openMilestoneCommentDialog("CWDPEDIT")
      }
    });
   
  }

  /* Open the Pen & Ink Milestone Comment Dialog */
  openMilestoneCommentDialog(pMilestoneId: string): any {
    let userActivityId: string = sessionStorage.getItem(LineDetailsComponent.USER_ACTIVITY_ID);
    this.dialogRef = this.dialog.open(MilestoneCommentComponent, {
      width: '50em',
      height: '30em',
      data: {
        caseId: this.caseLineInfoData.working_CASE_ID,
        versionId: this.caseLineInfoData.working_CASE_VERSION_ID,
        milestoneId: pMilestoneId
        // begin DSAMS-5933 09/22 DB
        , activityId:userActivityId,
        userId: sessionStorage.getItem(LineDetailsComponent.USER_ID)
        // end DSAMS-5933 09/22 DB
      }
    });
    this.dialogRef.afterClosed().subscribe((data) => {
      if (data === "Ok") {
        this.caseUIService.isMilestoneCommentNull.subscribe((value) => {
          if (!value && this.caseLineInfoData.isDataChanged) {
            this.performSaveDataOperation();
            this.caseUIService.setNotifyToSetDefaultOption(true);
            this.caseUIService.flipToDisabledService.next(DsamsConstants.CASE_LINE_EDITOR);
            const editResponse: IEditResponseType = {
              ID: DsamsConstants.CASE_LINE_EDITOR,
              editToggle: false
            };
            this.caseUIService.caseEditService.next(editResponse);
            this.caseUIService.optionSelectCounter.next(0);
          }
        });
      }
    });
  }

  //Business logic checks
  getMASLErrorString(): string {
    if (this.isLineDetailDisabled || this.isSpecificSublineFieldDisabled) {
      this.maslFormCtl.markAsPristine();
      return;
    }

    if (this.maslFormCtl.value !== null && this.maslFormCtl.value !== '' &&
      this.maslFormCtl.value !== 'N/A' &&
      this.maslFormCtl.hasError('pattern')) {
      return 'Invalid MASL number entered';
    }
    return 'This is a required field';
  }

  markMASLControlField(pMarkedError: boolean) {
    if (pMarkedError) {
      this.maslFormCtl.setErrors({ 'pattern': true });
      this.maslFormCtl.markAsTouched();
      this.getMASLErrorString();
    }
  }

  // Check if the form control is disabled, and if so, get rid of the red border.
  checkMaslFormCtl() {
    if (this.isSpecificSublineFieldDisabled) {
      this.maslFormCtl.markAsUntouched();
    }
  }

  //On input check to ensure MASL number entered is valid
  isMASLNumberValid(): boolean {
    if (!(this.isLineDetailDisabled) &&
      (this.caseLineInfoData.military_ARTICLE_SERVICE_CD !== null ||
        this.caseLineInfoData.military_ARTICLE_SERVICE_CD !== '')) {
      this.caseRestService.getCaseLineMASLData(this.caseLineInfoData.military_ARTICLE_SERVICE_CD).subscribe(
        value => {
          this.caseLineInfoData.military_ARTICLE_SERVICE_CD = value.military_ARTICLE_SERVICE_CD;
          this.caseLineInfoData.generic_CD = value.generic_CD;
          this.caseLineInfoData.article_DESCRIPTION_TX = value.article_DESCRIPTION_TX;
          if (value.major_DEFENSE_EQUIPMENT_CD) {
            if (value.major_DEFENSE_EQUIPMENT_CD.toUpperCase() == 'S')
              this.caseLineInfoData.mde_SME_CD = 'SME';
            else if (value.major_DEFENSE_EQUIPMENT_CD.toUpperCase() == 'Y')
              this.caseLineInfoData.mde_SME_CD = 'MDE';
            else this.caseLineInfoData.mde_SME_CD = 'N/A';
          } else this.caseLineInfoData.mde_SME_CD = 'N/A';
          this.caseLineInfoData.missile_TECH_CNTRL_REGIME_ID = value.missile_TECH_CNTRL_REGIME_ID;
          this.caseLineInfoData.mtcr_TITLE_NM = value.theMissileTechCntrlRegimeId.mtcr_TITLE_NM;
          this.caseLineInfoData.issue_UNIT_CD = value.issue_UNIT_CD;
        },
        error => {
          this.markMASLControlField(true);
          // this.caseLineInfoData.military_ARTICLE_SERVICE_CD = ''
          this.caseLineInfoData.generic_CD = 'N/A';
          this.caseLineInfoData.article_DESCRIPTION_TX = 'N/A';
          this.caseLineInfoData.mde_SME_CD = 'N/A';
          this.caseLineInfoData.missile_TECH_CNTRL_REGIME_ID = 'N/A';
          this.caseLineInfoData.mtcr_TITLE_NM = '';
          this.caseLineInfoData.issue_UNIT_CD = 'N/A'
        }
      );
    }
    this.caseUIService.theComponentSaveCaseLineState[CaseUIService.SAVE_CASE_LINE_DETAILS_STATE].isDataChanged = true;
    return true;
  }

  //On input check to ensure percentage value to not exceed 100%
  isPercentageValid(): boolean {
    let htmlStr: string = '<hr><div align="left">';
    htmlStr += '<font color="red"> Percentage cannot exceed 100%.';
    htmlStr += "";
    if (LineUtils.isPercentageExceeded(this.caseLineInfoData.percent_STOCK_RT)) {
      MessageMgr.swalFire({
        title: 'Line Details',
        icon: 'error',
        html: htmlStr,
        width: 400,
        focusConfirm: true,
        confirmButtonText: 'OK'
      })
      return false;
    }
    return true;
  }

  //on input check to ensure only one line purpose of CE type exists
  isSCMValid(): boolean {
    let htmlStr: string = '<hr><div align="left">';
    htmlStr += '<font color="red"> A Small Case Management Line already exists for this case.';
    htmlStr += "";
    if (CaseCommonValidator.isEqual(this.caseLineInfoData.line_PURPOSE_CD, LineUtils.LINE_PURPOSE_CE) &&
      this.caseLineInfoData.doesCaseLineHaveSCM) {
      MessageMgr.swalFire({
        title: 'Line Details',
        icon: 'error',
        html: htmlStr,
        width: 400,
        focusConfirm: true,
        confirmButtonText: 'OK'
      })
      return false;
    }
    return true;
  }

  //On input check for duplicate in CLAT table
  isDuplicateCLATRowFound(pValue: string): boolean {
    var dupCounter: number = 0;
    let htmlStr: string = '<hr><div align="left">';
    htmlStr += '<font color="red"> Duplicate Type of Assistance entered; value must be unique.';
    htmlStr += "";
    var aResult: boolean = false;
    //loop through the array to find duplicate values
    this.caseLineInfoData.caseLineAssistanceTypeList.forEach(searchRow => {
      if (pValue == searchRow.assistance_TYPE_CD) {
        //if found then check counter for more than 1 occurrence
        if (dupCounter > 0) {
          aResult = true;
          MessageMgr.swalFire({
            title: 'Line Details',
            icon: 'error',
            html: htmlStr,
            width: 400,
            focusConfirm: true,
            confirmButtonText: 'OK'
          })
        }
        dupCounter++;
      }
    })
    return (aResult);
  }

  //FR23 Estimated Service Dates radiobutton
  isEstimatedServiceFieldsValid(): boolean {
    // If the Performance Period From and To dates or Payment Schedule Override From and To dates 
    // (spec clarification needed for Availability/Lead-time exist), then display an error message 
    if (LineUtils.isThereValueInPPFields(false, this.caseLineInfoData)) {
      return false;
    }
    return true;
  }

  //FR19 additional - Performance Period From (for the line/subline)
  doesESFieldsHaveValues(): boolean {
    let htmlStr: string = '<hr><div align="left">';
    htmlStr += '<font color="red"> Please ensure the payment schedule overrides are updated if necessary';
    htmlStr += "";

    if (this.caseLineInfoData.case_LINE_PAY_PERIOD_START_QY !== null ||
      this.caseLineInfoData.case_LINE_PAY_PERIOD_END_QY !== null) {
      if (CaseUtils.isBlankStr(this.caseLineInfoData.case_LINE_PERIOD_START_QY) ||
        CaseUtils.isBlankStr(this.caseLineInfoData.case_LINE_PERIOD_END_QY) ||
        CaseUtils.isBlankStr(this.caseLineInfoData.estimated_DELIVERY_DT) ||
        CaseUtils.isBlankStr(this.caseLineInfoData.estimated_DELIVERY_END_DT) ||
        CaseUtils.isBlankStr(this.caseLineInfoData.case_LINE_AVAILABILITY_LEAD_QY)) {
        MessageMgr.swalFire({
          title: 'Line Delivery',
          icon: 'error',
          html: htmlStr,
          width: 400,
          focusConfirm: true,
          confirmButtonText: 'OK'
        })
        return false;
      }
    }
    return true;
  }

  //validation checks
  performValidationFieldCheck(): boolean {
    var displayMsg: boolean = false;
    let msgArray: Array<ErrorParameter> = [];

    //DH - All validation checks will be moved to line utils eventually
    //Line Detail tab
    //Mandatory fields must be checked first
    if (!LineUtils.areFieldsValidForLineDetails(this.caseLineInfoData, msgArray))
      displayMsg = true;
    //perform specific fields check
    if (!LineUtils.areSpecificFieldsValidForLineDetails(this.caseLineInfoData, this.caseLineRelatedInfoData, msgArray))
      displayMsg = true;

    //Line Delivery tab
    //Mandatory fields check
    //Validate Performance Period values
    if (!LineUtils.arePPFieldsValid(this.caseLineInfoData, msgArray))
      displayMsg = true;
    if (!LineUtils.areFieldsValidForLineDelivery(this.caseLineInfoData, msgArray))
      displayMsg = true;
    //FR27 and FR28
    if (!LineUtils.areSpecificFieldsValidForLineDelivery(this.caseLineInfoData, this.caseLineRelatedInfoData, msgArray))
      displayMsg = true;

    //Display validation warning/error messages if applicable
    if (displayMsg) {
      this.messageService.displayMessageListTc("Validate Case Line", msgArray).subscribe(result => { });
    }

    return !displayMsg
  }

  // MASL Popup
  popupMASL(elementName: string): void {
    let diaWidth: string = "80%";
    let diaHeight: string = "68%";
    let passingData: string = "";

    this.dsamsDialogMsgService.openSearchDialogCase(diaWidth, diaHeight, passingData, PopMaslComponent, this.maslForm, elementName);
  }

  /**
   * NPOR Popup
   */
  popupNpor(): void {
    // Set the value_in according to whether the Npor is selected.

    if (!!this.caseLineInfoData && !!this.caseLineInfoData.programOfRecordList) {
      if (this.caseLineInfoData.programOfRecordList.length > 0) {
        for (let nporItem of this.caseLineInfoData.programOfRecordList) {
          nporItem.value_IN = (!!this.caseLineInfoData.program_OF_RECORD_ID && this.caseLineInfoData.program_OF_RECORD_ID == nporItem.integer_VALUE_CD);
        }
      }
    }

    this.dialog.open(PopNporComponent, {
      width: "55%", data: this.caseLineInfoData.programOfRecordList
    });
    if (!this._selectNporSubscription) {
      this._selectNporSubscription = this.dsamsMethodsService.selectedNporFromPopup.subscribe((pSelectedItem: ifaceGenericRefItem) => {
        this.caseLineInfoData.program_OF_RECORD_ID = !pSelectedItem.integer_VALUE_CD ? null : pSelectedItem.integer_VALUE_CD;
        this.setProgramOfRecordDisp(pSelectedItem.value_TITLE_NM);
        this.caseUIService.nporChanged.next(this.caseLineInfoData.program_OF_RECORD_ID !== this._databaseNpor);
        if (this.caseLineInfoData.status !== DsamsConstants.ENT_NEW.toString()) {
          this.caseLineInfoData.status = DsamsConstants.ENT_CHANGED.toString();
          this.caseLineInfoData.entityStatus = DsamsConstants.ENT_CHANGED.toString();
        }
        this.caseLineInfoData.isDataChanged = true;
        this.caseUIService.theComponentSaveCaseLineState[CaseUIService.SAVE_CASE_LINE_DETAILS_STATE].isDataChanged = true;
      });
    }
  }

  subscribeToPopupMASL() {
    if (this._popupMASLSubscription == null) {
      this._popupMASLSubscription = this.dsamsMethodsService
        .selectedMaslObjectFromPopupValue
        .subscribe(value => {
          this.caseLineInfoData.military_ARTICLE_SERVICE_CD = value.military_ARTICLE_SERVICE_CD;
          this.caseLineInfoData.generic_CD = value.generic_CD;
          this.caseLineInfoData.major_DEFENSE_EQUIPMENT_CD = value.major_DEFENSE_EQUIPMENT_CD;
          // Reset the SME/MDE for selected MASL per Major Def Equip
          LineUtils.getFormattedMDEValue(this.caseLineInfoData);
          this.caseLineInfoData.article_DESCRIPTION_TX = value.official_MASL_DESCRIPTION_TX;
          this.caseLineInfoData.missile_TECH_CNTRL_REGIME_ID = value.missile_TECH_CNTRL_REGIME_ID;
          // May need to pull in MTCR Title, for now using line utils method per missile_TECH_CNTRL_REGIME_ID
          LineUtils.getMTCRTitleValue(this.caseLineInfoData);
          this.caseLineInfoData.issue_UNIT_CD = value.issue_UNIT_CD;
          this.caseLineInfoData.isDataChanged = true;
          this.caseUIService.theComponentSaveCaseLineState[CaseUIService.SAVE_CASE_LINE_DETAILS_STATE].isDataChanged = true;
        },
          err => {
            CaseUtils.ReporError("Error in dsamsMethodsService.popupMASL");
          }
        );
    }
  }

  // Subscribe to Save on Edit Toggle
  private saveOnEditToggleSub: Subscription = null;
  subscribeToSaveOnEditToggle() {
    if (!!this.saveOnEditToggleSub) {
      this.saveOnEditToggleSub.unsubscribe();
      this.saveOnEditToggleSub = null;
    }
    this.saveOnEditToggleSub = this.caseUIService.theComponentSaveCaseLineState[CaseUIService.SAVE_CASE_LINE_DETAILS_STATE].isSaveConfirmed
      .subscribe(isSaveConfirmed => {
        if (isSaveConfirmed) {
          if (this.performValidationFieldCheck()) {
            this.performSaveDataOperation();
            const turnToggleOff: IEditResponseType = { ID: DsamsConstants.CASE_LINE_EDITOR, editToggle: false };
            this.caseUIService.caseEditService.next(turnToggleOff);
          }
          else {
            const turnToggleOn: IEditResponseType = { ID: DsamsConstants.CASE_LINE_EDITOR, editToggle: true };
            this.caseUIService.caseEditService.next(turnToggleOn);
          }
        }
      });
  }

  // Subscribe to Continue on Edit Toggle
  private continueOnEditToggleSub: Subscription = null;
  subscribeToContinueOnEditToggle() {
    if (!!this.continueOnEditToggleSub) {
      this.continueOnEditToggleSub.unsubscribe();
      this.continueOnEditToggleSub = null;
    }
    this.continueOnEditToggleSub = this.caseUIService.theComponentSaveCaseLineState[CaseUIService.SAVE_CASE_LINE_DETAILS_STATE].isContinueConfirmed
      .subscribe(isContinueConfirmed => {
        if (isContinueConfirmed) {
          const turnToggleOff: IEditResponseType = { ID: DsamsConstants.CASE_LINE_EDITOR, editToggle: false };
          this.caseUIService.caseEditService.next(turnToggleOff);
          this.caseLineInfoData.isPricingDataChanged = false;
          this.caseLineInfoData.isDataChanged = false;
         
          if (this.caseLineInfoData.status == DsamsConstants.ENT_NEW.toString()) {
            this.sendTabId();
          }
          else {
           this.unlockCaseLineEntity();
           this.refreshCaseLineData();
           }
        }
      });
  }

  // begin DSAMS-5983 09/22 DB
  subscribeToCaseLineUnlockRequest() {
    this.caseUIService.caseLineUnlockRequest
      .subscribe(value => {
        if (value) {
          this.unlockCaseLineEntity();
         }
      });
  }

  subscribeToCaseLineLockRequest() {
    this.caseUIService.caseLineLockRequest
      .subscribe(value => {
        if (value) {
          this.lockCaseLineEntity();
         }
      });
  }



  // Removed cancelButtonOnClick method
  // no longer needed - FS - Removed on 03/2022 for Card 5204
  // logic moved to refreshLineDetailData method

  //begin DSAMS-1849 DH 03/22
  setEnableCalculateFMSOMenuOption() {
    if (!this.isLineDetailDisabled && !CaseUtils.isBlankStr(this.caseLineInfoData.case_CATEGORY_CD)) {
      if (this.caseLineInfoData.case_CATEGORY_CD == LineUtils.CASE_CATEGORY_CD_FMSOI &&
        (!CaseUtils.isBlankStr(this.caseLineInfoData.total_ABOVE_LINE_COST_AM) &&
          !LineUtils.isValueEqualZero(this.caseLineInfoData.total_ABOVE_LINE_COST_AM)))
        this.caseUIService.setEnableCalculateFMSOOption(true);
    }
    else this.caseUIService.setEnableCalculateFMSOOption(false);
  }

  setDisableCalculateFMSOMenuOption() {
    if (this.isLineDetailDisabled)
      this.caseUIService.setDisableCalculateFMSOOption(true);
    else this.caseUIService.setDisableCalculateFMSOOption(false);
  }
  //end DSAMS-1849 DH 03/22
 
  sendTabId() {
    //send new Line tab index as output
    this.caseUIService.setIsLineTabDisabled(false);
    this.caseUIService.setTheOriginalLineTabIndex(0);
    this.sendTabIndex.emit(0);
  }

  setChangedSaveState(){
    this.caseUIService.theComponentSaveCaseLineState[CaseUIService.SAVE_CASE_LINE_DETAILS_STATE].isDataChanged = true;
  }
  
}
