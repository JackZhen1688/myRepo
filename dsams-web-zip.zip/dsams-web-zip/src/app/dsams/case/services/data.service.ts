import { HttpClient } from '@angular/common/http';
import { Observable, Subject, ReplaySubject, throwError } from 'rxjs';
import { DsamsConstants } from '../../dsams.constants';
import { CaseUtils } from '../utils/case-utils';
import { CaseMasterCI } from '../model/case-master-model';
import { environment } from 'src/environments/environment';
import { ICaseVersion } from '../model/dto/icase-version';
import { ICaseMaster } from '../model/dto/icase-master';
import { ErrorParameter } from '../../entities/specialEntities/error-parameter.model';
import { IUsedUserCase } from '../model/dto/used-user-case';
import { IPerson } from '../model/dto/person';
import { IPersonSearchParamsType } from '../model/search-params/person-search-params-type';
import { ICustomerRequestParamsType } from '../model/search-params/customer-request-params-type';
import { ICustomerRequest } from '../model/dto/customer-request';
import { IEditResultsType } from '../model/edit-results-type';
import { catchError } from 'rxjs/operators';
import { ifaceCaseLineData, ifaceCaseLineEntity } from '../model/case-line-model';
import { IReserveIdentifier } from '../model/ireserve-Identifier';
import { ICaseVersionMilestone } from '../model/dto/case-version-milestone';
import { IWorkflowTaskAssignmentData } from '../model/dto/workflow-task-assignment-data';
import { ICaseLinePricing } from '../model/dto/icase-line-pricing';
import { DateValidator } from '../validation/date-validator';
import { CaseLineIPCDto } from '../line-dashboard/line-pricing/ipc-tab-dashboard/model/dto/case-line-ipc-dto';
import { caseLineComponentDto } from '../model/dto/case-line-component-dto';
import { CivilianPersonnelResultsType } from '../model/dto/civilian-personnel-results-type';
import { ICaseNote } from '../model/dto/case-note';
import { INote } from '../model/note';
import { INoteSearchParams } from '../model/note-search-params';
import { CaseNoteDto } from '../model/dto/case-note-dto';
import { remarksModel } from '../remarks-dashboard/model/case-remarks';
import { remarksDto } from '../remarks-dashboard/model/dto/case-remarks-dto';
import { caseVersionInfoDto } from '../remarks-dashboard/model/dto/case-version-info-dto';
import { attachmentsModel } from '../attachments-dashboard/model/case-attachments';
import { attachmentsDto } from '../attachments-dashboard/model/dto/case-attachments-dto';
import { CongressNotifyAmountDTO } from '../../congressional-notification/case-amount-panel/model/view-case-amount';
import { ICongNotificationParamsType } from '../model/search-params/cong-notification-params-type';
import { ICustomerCn } from 'src/app/dsams/case/model/dto/customer-cn';
import { summaryNotifyDto } from '../../congressional-notification/summary-notify-panel/model/dto/summary-notify-dto';
import { CongressNotifyQuantityDTO } from '../../congressional-notification/case-quantity-panel/model/view-caseline-cn-mde';
import { CongressNotifyOverageDTO } from '../../congressional-notification/case-overage-panel/model/view-case-overage';
import { CongressNotifyAttachmentsDTO } from '../../congressional-notification/cong-attachments-panel/model/cong-attachments';
import { CustomerCnModel } from '../../congressional-notification/summary-notify-panel/model/summary-notify';
import { ModFundingDto } from '../case-dashboard/mod-funding-panel/model/dto/mod-funding-dto';
import { WebComponentDTO } from '../../entities/models/web-component.model';

export class DataService {
  // Are we running in desktop mode?
  //private _isDesktopMode: boolean = false;
  // private _hostURL: string = this._isDesktopMode ? DsamsConstants.devURL : DsamsConstants.hostURL;
  private _hostURL: string = environment.apiUrl.replace("localhost:4200", "localhost:8080");

  private caseLineListEndpoint: string = "/CaseLineList";
  private caseLineListTestEndpoint: string = "/CaseLineList/Test";
  private caseLineEndpoint: string = "/CaseLine";
  private caseLineRefEndpoint: string = "/Reference";
  private canEditSublineEndpoint: string = this.caseLineEndpoint + "/CanEditSubLine";


  private reFetchHostUrl() {
    this._hostURL = environment.apiUrl.replace("localhost:4200", "localhost:8080");
  }

  getMaxLinesValueSubject: ReplaySubject<any> = new ReplaySubject<any>(0);

  // Subject that notifies the case search panel that the data is loading or is ready.
  caseSearchSubject: Subject<any> = new Subject<any>();

  caseSearchReplaySubject: ReplaySubject<any> = new ReplaySubject<any>();

  constructor(private url: string, private http: HttpClient) { }

  /* This is used to set the Host URL path to the proper URL
     string based on the environment the app is being executed.
     This is just a temporary solution to resolve the host URL path
     until a permanent solution is implemented at the project level.
     Author: David Huynh
     Date  : 06/032020
   */
  setDynamicHostURL() {
    this.reFetchHostUrl();
    //Test the URL path to identify the environment
    this.http.get(DsamsConstants.devURL + "/TestDatabase").subscribe(
      value => {
         this._hostURL = DsamsConstants.devURL;
      },
      err => {
         this._hostURL = DsamsConstants.hostURL;
      })
  }

  getServiceDBString(): string {
    this.reFetchHostUrl();
    return "/ServiceDbId/" + CaseUtils.getServiceDatabaseId();
  }

  getCaseQueryString(pCaseId: number, pCaseVersionId: number): string {
    this.reFetchHostUrl();
    const sdb_str: string = this.getServiceDBString();

    if (pCaseVersionId === -1) {
      return sdb_str + "/CaseId/" + +pCaseId;
    }
    return sdb_str + "/CaseId/" + +pCaseId + "/CaseVersionId/" + +pCaseVersionId;
  }

  getCustRequestData(filter: string): Observable<any> {
     this.reFetchHostUrl();
    return this.http.get(this._hostURL + "/getCustomerRequestListByFiller/" + filter);
  }

  getCaseHeaderData(pCaseId: number, pCaseVersionId: number): Observable<any> {
    this.reFetchHostUrl();
    return this.http.get(this._hostURL + "/CaseHeader" + this.getCaseQueryString(pCaseId, pCaseVersionId));
  }

  getCaseHeaderDataNew(pUsedUserCaseId: string, pCaseVersionTypeCd: string): Observable<any> {
    this.reFetchHostUrl();
    const serviceDBId: string = CaseUtils.getServiceDatabaseId();
    return this.http.get(this._hostURL + "/CaseHeaderNew" +
      "/ServiceDbId/" + serviceDBId +
      "/UserCaseId/" + pUsedUserCaseId +
      "/CaseVersionTypeCd/" + pCaseVersionTypeCd);
  }

  getCaseInfoData(pCaseId: number, pCaseVersionId: number): Observable<any> {
    this.reFetchHostUrl();
    return this.http.get(this._hostURL + "/CaseInfo" + this.getCaseQueryString(pCaseId, pCaseVersionId));
  }

  getCaseInfoDataNew(pUserId: number, pCustomerOrganizationId: string): Observable<any> {
    this.reFetchHostUrl();
    return this.http.get(this._hostURL + "/CaseInfoNew/UserId/" + +pUserId + "/CustomerOrganizationId/" + pCustomerOrganizationId);
  }

  getCaseDescription(pCaseId: number, pCaseVersionId: number): Observable<any> {
    this.reFetchHostUrl();
    return this.http.get(this._hostURL + "/CaseDescription" + this.getCaseQueryString(pCaseId, pCaseVersionId));
  }

  getCaseDocumentRequirements(pCaseId: number, pCaseVersionId: number): Observable<any> {
    this.reFetchHostUrl();
    return this.http.get(this._hostURL + "/CaseDocumentRequirements" + this.getCaseQueryString(pCaseId, pCaseVersionId));
  }

  getCaseDocumentRequirementsNew(pUserCaseId: string,
    pCaseVersionTypeCd: string,
    pCaseUsageIndicatorCd: string,
    pCustomerRequestId: number): Observable<any> {
    this.reFetchHostUrl();
    // Throws an error when caseUsageIndicatorCd is blank but I'll fix once I legacyfiy this panel (when this call won't be needed anymore)
    return this.http.get(this._hostURL + "/CaseDocumentRequirementsNew"
      + this.getServiceDBString()
      + "/UserCaseId/" + pUserCaseId
      + "/CaseVersionTypeCd/" + pCaseVersionTypeCd
      + "/CaseUsageIndicatorCd/" + pCaseUsageIndicatorCd
      + "/CustomerRequestId/" + +pCustomerRequestId);
  }

  getCaseSignatory(pCaseId: number, pCaseVersionId: number): Observable<any> {
    this.reFetchHostUrl();
    return this.http.get(this._hostURL + "/CaseSignatory" + this.getCaseQueryString(pCaseId, pCaseVersionId));
  }

  getCaseAssociations(pCaseId: number): Observable<any> {
    this.reFetchHostUrl();
    return this.http.get(this._hostURL + "/CaseAssociation" + this.getCaseQueryString(pCaseId, -1));
  }

  getCaseWaiverData(pCaseId: number, pCaseVersionId: number): Observable<any> {
    this.reFetchHostUrl();
    // return <Observable<any>>this.http.get(this.url+"/data/case-waiver.json");
    return this.http.get(this._hostURL + "/CaseWaiver" + this.getCaseQueryString(pCaseId, pCaseVersionId));
  }

  getCaseSearchResults(pSAProgram: string, pDocType: string, pCaseNumber: string): Observable<any> {
    this.reFetchHostUrl();
    return this.http.get(this._hostURL + "/CaseSearchResults/SAProgram/" +
      pSAProgram + "/DocType/" + pDocType + "/CaseNumber/" + pCaseNumber);
  }

  getUsedUserCase(pCaseDesignatorCd: string, pImplementingAgencyId: string, pCustOrgId: string): Observable<IUsedUserCase> {
    this.reFetchHostUrl();
    const serviceDBId: string = CaseUtils.getServiceDatabaseId();
    return <Observable<IUsedUserCase>>(this.http.get(this._hostURL + "/UsedUserCase" +
      "/ServiceDbId/" + serviceDBId +
      "/CaseDesignatorCd/" + pCaseDesignatorCd +
      "/ImplementingAgencyId/" + pImplementingAgencyId +
      "/CustomerOrganizationId/" + pCustOrgId));
  }

  /* Check UUC (associated cases) */
  checkUsedUserCaseForAssoc(pCaseDesignatorCd: string, pImplementingAgencyId: string, pCustOrgId: string): Observable<number> {
    this.reFetchHostUrl();
    const serviceDBId: string = CaseUtils.getServiceDatabaseId();
    return <Observable<number>>(this.http.get(this._hostURL + "/UsedUserCaseAssoc" +
      "/ServiceDbId/" + serviceDBId +
      "/CaseDesignatorCd/" + pCaseDesignatorCd +
      "/ImplementingAgencyId/" + pImplementingAgencyId +
      "/CustomerOrganizationId/" + pCustOrgId));
  }

  /* Check UUC (related cases) */
  checkUsedUserCaseForRC(pCaseDesignatorCd: string, pUsedUserCase: string): Observable<ICaseMaster> {
    this.reFetchHostUrl();
    const serviceDBId: string = CaseUtils.getServiceDatabaseId();
    const hostUrlString: string = this._hostURL + "/UsedUserCaseRC" +
      "/ServiceDbId/" + serviceDBId +
      "/CaseDesignatorCd/" + pCaseDesignatorCd +
      "/UserCaseId/" + pUsedUserCase;
    return <Observable<ICaseMaster>>(this.http.get(hostUrlString));
  }


  hasBasicCase(pCaseDesignatorCd: string, pImplementingAgencyId: string, pCustOrgId: string): Observable<boolean> {
    this.reFetchHostUrl();
    const serviceDBId: string = CaseUtils.getServiceDatabaseId();
    return <Observable<boolean>>(this.http.get(this._hostURL + "/CheckBasicCase" +
      "/ServiceDbId/" + serviceDBId +
      "/CaseDesignatorCd/" + pCaseDesignatorCd +
      "/ImplementingAgencyId/" + pImplementingAgencyId +
      "/CustomerOrganizationId/" + pCustOrgId));
  }

  // begin Jira Card DSAMS-5426 AKP 05/2022
  isAnotherVersionOfCaseInDevelopmentStatus(pCaseDesignatorCd: string, pImplementingAgencyId: string, pCustOrgId: string): Observable<boolean> {
    this.reFetchHostUrl();
    const serviceDBId: string = CaseUtils.getServiceDatabaseId();
    return <Observable<boolean>>(this.http.get(this._hostURL + "/CheckCaseDevelopmentStatus" +
      "/ServiceDbId/" + serviceDBId +
      "/CaseDesignatorCd/" + pCaseDesignatorCd +
      "/ImplementingAgencyId/" + pImplementingAgencyId +
      "/CustomerOrganizationId/" + pCustOrgId));
  }
  // end Jira Card DSAMS-5426 AKP 05/2022

  //****** CASE Line List and Case Line services ******/

  //checking the case line financial data 
  checkCaseLineFinancialData(pBody: any): Observable<boolean> {
    this.reFetchHostUrl();
    const hostURLStr: string = this._hostURL + this.caseLineEndpoint + "/CheckCLFinData/";
    return <Observable<boolean>>(this.http.post(hostURLStr, pBody));
  }

  //getting prior year sum
  checkPriorYearSum(pBody: any): Observable<boolean> {
    this.reFetchHostUrl();
    const hostURLStr: string = this._hostURL + this.caseLineEndpoint + "/CheckPriorYearAM/";
    return <Observable<boolean>>(this.http.post(hostURLStr, pBody));
  }

  //given a User Case string, getting the user case ID
  getCaseId(pUserCaseId: string): Observable<number> {
    this.reFetchHostUrl();
    const serviceDBString: string = this.getServiceDBString() + "/";
    const queryString: string = this.caseLineEndpoint + serviceDBString + "UserCaseId/" + pUserCaseId;
    return <Observable<number>>(this.http.get(this._hostURL + queryString));
  }

//given a User Case string along with other filter criteria, getting the user case ID
getCaseIdForUserCaseId(pUserCaseId: string, pSecurityAssistanceProgramCd : string,  pCaseUsageIndicatorCd : string, pCaseVersionTypeCd: string): Observable<number> {
  this.reFetchHostUrl();
  const serviceDBString: string = this.getServiceDBString() + "/";
  const queryString: string = this.caseLineEndpoint + serviceDBString + "UserCaseId/" + pUserCaseId           
            + "/securityAssistanceProgramCd/" + pSecurityAssistanceProgramCd
            + "/caseUsageIndicatorCd/" + pCaseUsageIndicatorCd
            + "/CaseVersionTypeCd/" + pCaseVersionTypeCd
  ;
  return <Observable<number>>(this.http.get(this._hostURL + queryString));
}

  //getting the case master line list data from server
  getCaseMasterLineListFromServer(pCaseId: number): Observable<any> {
    this.reFetchHostUrl();
    const serviceDBString: string = this.getServiceDBString() + "/";
    const queryString: string = this.caseLineEndpoint + serviceDBString + "CaseId/" + pCaseId;
    // console.log('this._hostURL===', this._hostURL + queryString)
    return this.http.get(this._hostURL + queryString);
  }

  /* Base Price Source */
  getBasePriceSourceData(pCaseId: number, pWorkingCaseId: number, pWorkingCaseVersionId: number,
    pCaseMasterLineId: number): Observable<any> {
    this.reFetchHostUrl();
    const serviceDBString: string = this.getServiceDBString() + "/";
    const queryString: string = "/BasePriceSource" + serviceDBString +
      "CaseId/" + pCaseId +
      "/WorkingCaseId/" + pWorkingCaseId +
      "/WorkingCaseVersionId/" + pWorkingCaseVersionId +
      "/CaseMasterLineId/" + pCaseMasterLineId;
    return this.http.get(this._hostURL + queryString);
  }

  /* Target Percent RT */
  getTargetPercentRTData(pCaseId: number, pWorkingCaseId: number, pWorkingCaseVersionId: number,
    pCaseMasterLineId: number): Observable<any> {
    this.reFetchHostUrl();
    const serviceDBString: string = this.getServiceDBString() + "/";
    const queryString: string = "/TargetPercentRT" + serviceDBString +
      "CaseId/" + pCaseId +
      "/WorkingCaseId/" + pWorkingCaseId +
      "/WorkingCaseVersionId/" + pWorkingCaseVersionId +
      "/CaseMasterLineId/" + pCaseMasterLineId;
    return this.http.get(this._hostURL + queryString);
  }

  /* Target Cost AM */
  getTargetCostAMData(pCaseId: number, pWorkingCaseId: number, pWorkingCaseVersionId: number,
    pCaseMasterLineId: number): Observable<any> {
    this.reFetchHostUrl();
    const serviceDBString: string = this.getServiceDBString() + "/";
    const queryString: string = "/TargetCostAM" + serviceDBString +
      "CaseId/" + pCaseId +
      "/WorkingCaseId/" + pWorkingCaseId +
      "/WorkingCaseVersionId/" + pWorkingCaseVersionId +
      "/CaseMasterLineId/" + pCaseMasterLineId;
    return this.http.get(this._hostURL + queryString);
  }

  /* Target Cost AM */
  getCaseLineComponentData(pCaseId: number, pWorkingCaseId: number, pWorkingCaseVersionId: number,
    pCaseMasterLineId: number): Observable<any> {
    this.reFetchHostUrl();
    const serviceDBString: string = this.getServiceDBString() + "/";
    const queryString: string = "/CaseLinePricing" + serviceDBString +
      "CaseId/" + pCaseId +
      "/WorkingCaseId/" + pWorkingCaseId +
      "/WorkingCaseVersionId/" + pWorkingCaseVersionId +
      "/CaseMasterLineId/" + pCaseMasterLineId;
    return this.http.get(this._hostURL + queryString);
  }

  /* CASE LINE*/
  getCaseLineData(pCaseId: number, pWorkingCaseId: number, pWorkingCaseVersionId: number,
    pCaseMasterLineId: number): Observable<any> {
    this.reFetchHostUrl();
    const serviceDBString: string = this.getServiceDBString() + "/";
    const queryString: string = "/CaseLinePricingSummary" + serviceDBString +
      "CaseId/" + pCaseId +
      "/WorkingCaseId/" + pWorkingCaseId +
      "/WorkingCaseVersionId/" + pWorkingCaseVersionId +
      "/CaseMasterLineId/" + pCaseMasterLineId;
    return this.http.get(this._hostURL + queryString);
  }

  //posting the case line list data from server using params 
  postCaseLineListWithParamsFromServer(pObjectParams: any): Observable<any> {
    this.reFetchHostUrl();
    const objectParamsData: any = { ...pObjectParams, "service_DB_ID": CaseUtils.getServiceDatabaseId() };
    return this.http.get(this._hostURL + this.caseLineListEndpoint + objectParamsData);
  }

  //getting the case line entity with case line list data from server 
  // - query includes parent case and parent case master line  ID and case version ID
  getCaseLineFromServer(pParentCaseId: number, pParentCMLineId: number, pCaseVersionId: number): Observable<any> {
    this.reFetchHostUrl();
    const serviceDBString: string = this.getServiceDBString();
    const queryString: string = this.caseLineListEndpoint + serviceDBString + "/ParentCaseId/" + pParentCaseId +
      "/ParentCMLId/" + pParentCMLineId + "/CaseVersionId/" + pCaseVersionId;
    return this.http.get(this._hostURL + queryString);
  }

  // Determine if subline can be edited (version with user line number id) 
  getCanSublineBeEdited(pCaseId: number,
    pWorkingCaseVersionId: number,
    pUserCaseLineNumberId: string): Observable<any> {
    this.reFetchHostUrl();
    const serviceDBString: string = this.getServiceDBString();
    const queryString: string = this.canEditSublineEndpoint + serviceDBString +
      "/CaseId/" + pCaseId +
      "/WorkingCaseVersionId/" + pWorkingCaseVersionId +
      "/UserCaseLineNumberId/" + pUserCaseLineNumberId;
    return <Observable<any>>this.http.get(this._hostURL + queryString);
  }


  //getting the case master line entity with and case line list data from server
  // - query includes case and  case master line ID
  getCaseMasterLineFromServer(pCaseId: number, pCaseMasterLIneId: number): Observable<any> {
    this.reFetchHostUrl();
    const serviceDBString: string = this.getServiceDBString() + "/";
    const queryString: string = this.caseLineListEndpoint + + serviceDBString +
      "CaseId/" + pCaseId + "/CaseMasterLineId/" + pCaseMasterLIneId;
    return this.http.get(this._hostURL + queryString);
  }

  //getting the case line list data from server - query includes Working case version ID 
  getCaseLineListFromServer(pCaseId: number, pWorkingCaseId: number): Observable<any> {
    this.reFetchHostUrl();
    const serviceDBString: string = this.getServiceDBString() + "/";
    const queryString: string = this.caseLineListEndpoint + serviceDBString + "CaseId/" + pCaseId +
      "/CaseVersionId/" + pWorkingCaseId;
    // console.log('this._hostURL===', this._hostURL)
    return this.http.get(this._hostURL + queryString);
  }

  getCaseLineListFromServerForNotes(pCaseId: number, pCaseVersionId: number): Observable<any> {
    this.reFetchHostUrl();
    const serviceDBString: string = this.getServiceDBString() + "/";
    const queryString: string = this.caseLineListEndpoint + "/CaseNote" + serviceDBString + "CaseId/" + pCaseId + "/CaseVersionId/" + pCaseVersionId;
    return this.http.get(this._hostURL + queryString);
  }


  //For testing purpose only - getting the case line list data from server - query includes Working case version ID 
  getTestCaseLineListFromServer(pCaseId: number, pWorkingCaseId: number): Observable<any> {
    this.reFetchHostUrl();
    const serviceDBString: string = this.getServiceDBString() + "/";
    const queryString: string = this.caseLineListTestEndpoint + serviceDBString + "CaseId/" + pCaseId +
      "/CaseVersionId/" + pWorkingCaseId;
    // console.log('this._hostURL===', this._hostURL)
    return this.http.get(this._hostURL + queryString);
  }

  //getting the case line list data from server - query includes Working case version ID 
  getSubsetCaseLineList(pCaseId: number, pWorkingCaseId: number): Observable<any> {
    this.reFetchHostUrl();
    const serviceDBString: string = this.getServiceDBString() + "/";
    const queryString: string = this.caseLineListEndpoint + "/Subset" + serviceDBString + "CaseId/" + pCaseId +
      "/CaseVersionId/" + pWorkingCaseId;
    console.log('this._hostURL===', this._hostURL + queryString)
    return this.http.get(this._hostURL + queryString);
  }

  //delete the case line data from server
  deleteCaseLineFromServer(pCaseId: number, pCaseMasterLIneId: number,
    pWorkingCaseId: number, pWorkingCaseVersionId: number): Observable<any> {
    this.reFetchHostUrl();
    const serviceDBString: string = this.getServiceDBString() + "/";
    const queryString: string = this.caseLineListEndpoint + serviceDBString +
      "CaseId/" + pCaseId + "/CaseMasterLineId/" + pCaseMasterLIneId +
      "/WorkingCaseId/" + pWorkingCaseId + "/WorkingCaseVersionId/" + pWorkingCaseVersionId;
    return this.http.delete(this._hostURL + queryString);
  }

  //delete the case line list data from server using body param
  deleteCaseLineListFromServer(pBody: any): Observable<any> {
    this.reFetchHostUrl();
    return this.http.delete(this._hostURL + this.caseLineListEndpoint, pBody);
  }

  //delete and save the case line data using body param
  saveCaseLineListFromServer(pBody: any): Observable<any> {
    this.reFetchHostUrl();
    return this.http.post(this._hostURL + this.caseLineListEndpoint, pBody);
  }

  //saving the case line data to database using body param
  saveCaseLineEntity(pBody: any): Observable<any> {
    const hostURLStr: string = this._hostURL + this.caseLineEndpoint + "/SaveCaseLineEntity/";
    return this.http.post(hostURLStr, pBody);
  }

  // Save the Case Detail entity
  saveCaseDetail(pCaseVersion: ICaseVersion): Observable<ICaseVersion> {
    this.reFetchHostUrl();
    const serviceDBId: string = CaseUtils.getServiceDatabaseId();
    let restAPIUri: string = this._hostURL + "/CaseDetail";
    restAPIUri += "/ServiceDbId/" + serviceDBId;
    return this.http.post(restAPIUri, pCaseVersion);
  }

  // Save Case Version Milestone
  saveCaseVersionMilestone(pCaseVersionMIlestone: ICaseVersionMilestone): Observable<ICaseVersionMilestone> {
    this.reFetchHostUrl();
    const serviceDBId: string = CaseUtils.getServiceDatabaseId();
    let restAPIUri: string = this._hostURL + "/CaseVersionMilestone";
    restAPIUri += "/ServiceDbId/" + serviceDBId;
    return <Observable<ICaseVersionMilestone>>this.http.post(restAPIUri, pCaseVersionMIlestone);
  }

  // Validate Case
  validateCase(pCaseId: number, pCaseVersionId: number): Observable<Array<ErrorParameter>> {
    this.reFetchHostUrl();
    const serviceDBId: string = CaseUtils.getServiceDatabaseId();
    let restAPIUri: string = this._hostURL + "/CaseValidate/ServiceDbId/" + serviceDBId + "/CaseId/" + pCaseId + "/CaseVersionId/" + pCaseVersionId;
    return <Observable<Array<ErrorParameter>>>(this.http.get(restAPIUri));
  }

  // get reference data for case line list
  getCaseLineRefList(pTableName: string): Observable<any> {
    this.reFetchHostUrl();
    return this.http.get(this._hostURL + this.caseLineRefEndpoint + "/RefTable/" + pTableName);
  }

  // get reference data for line tab
  getLineReferenceList(): Observable<any> {
    this.reFetchHostUrl();
    //return <Observable<ifaceCaseLineData>> this.http.get(this._hostURL + this.caseLineRefEndpoint);
    return <Observable<ifaceCaseLineData>> this.http.get(this.url+"/data/referencelist.json");
  }

  // get reference MASL data for case line 
  getCaseLineMASLData(pColumnValue: string): Observable<any> {
    this.reFetchHostUrl();
    return this.http.get(this._hostURL + this.caseLineRefEndpoint + "/RefColumn/" + pColumnValue);
  }

  // get customer organization list from reference database as default
  getCustomerOrganizationList(pServiceDbId: any = 'C'): Observable<any> {
    this.reFetchHostUrl();
    return this.http.get(this._hostURL + "/getCustomerOrganizationListByServiceId/" + pServiceDbId);
  }

  // ***** Case Version services *****/
  updateSBLInd(pCaseVersion: ICaseVersion): Observable<ICaseVersion> {
    return this.saveCaseDetail(pCaseVersion);
  }

  //Update Congressional Notification Amounts
  updateCongNotifAmounts(pCaseLine: ifaceCaseLineEntity): Observable<ifaceCaseLineEntity> {
    this.reFetchHostUrl();
    const hostURLStr: string = this._hostURL + this.caseLineEndpoint + "/CongNotif/";
    pCaseLine.service_DB_ID = CaseUtils.getServiceDatabaseId();
    return this.http.post(hostURLStr, pCaseLine);
  }

  // *********************** Reserve Identifier *************************
  getReserveIdentifier(pReserveCountry, pPseudoCountry, pReserveIa,
    pReserveDesignator, pOriginalCountry): Observable<IReserveIdentifier> {
    this.reFetchHostUrl();
    const serviceDBId: string = CaseUtils.getServiceDatabaseId();
    let restAPIUri: string = this._hostURL + "/CaseReserveIdentifier";
    restAPIUri += "/ServiceDbId/" + serviceDBId;
    restAPIUri += "/ReserveCountry/" + pReserveCountry;
    restAPIUri += "/PseudoCountry/" + pPseudoCountry;
    restAPIUri += "/ReserveIa/" + pReserveIa;
    restAPIUri += "/ReserveDesignator/" + pReserveDesignator;
    restAPIUri += "/OriginalCountry/" + pOriginalCountry;
    console.log(restAPIUri);
    return <Observable<IReserveIdentifier>>(this.http.get(restAPIUri));
  }

  //  ********************** Case Detail Legacy *************************

  getCaseDetailLegacy(pCaseId: number, pCaseVersionId: number): Observable<ICaseVersion> {
    this.reFetchHostUrl();
    const serviceDBId: string = CaseUtils.getServiceDatabaseId();
    let restAPIUri: string = this._hostURL + "/CaseDetail";
    restAPIUri += "/ServiceDbId/" + serviceDBId;
    restAPIUri += "/CaseId/" + +pCaseId;
    restAPIUri += "/CaseVersionId/" + +pCaseVersionId;
    return <Observable<ICaseVersion>>(this.http.get(restAPIUri));
  }

  getCaseAmendModLegacy(pCaseId: number, pCaseVersionId: number,
    pCaseVersionTypeCd: string, pCaseVersionNumberId: number): Observable<ICaseVersion> {
    this.reFetchHostUrl();
    const serviceDBId: string = CaseUtils.getServiceDatabaseId();
    let restAPIUri: string = this._hostURL + "/CaseAmendMod";
    restAPIUri += "/ServiceDbId/" + serviceDBId;
    restAPIUri += "/CaseId/" + +pCaseId;
    restAPIUri += "/CaseVersionId/" + +pCaseVersionId;
    restAPIUri += "/CaseVersionTypeCd/" + pCaseVersionTypeCd;
    restAPIUri += "/CaseVersionNumberId/" + +pCaseVersionNumberId;
    return <Observable<ICaseVersion>>(this.http.get(restAPIUri)).pipe(
      catchError(this.handleAmendModError));
  }

  handleAmendModError(error: Response) {
    if (error.status === 204) {
      return throwError(error);
    }
  }

  // begin Jira card DSAMS-5233 03/2022 AKP
  caseAmendModRefresh(pCaseId: number, pCaseVersionId: number,
    pRefreshCd: string): Observable<Array<ErrorParameter>> {
      this.reFetchHostUrl();
      const serviceDBId: string = CaseUtils.getServiceDatabaseId();
      let restAPIUri: string = this._hostURL + "/CaseAmendModRefresh";
      restAPIUri += "/ServiceDbId/" + serviceDBId;
      restAPIUri += "/CaseId/" + pCaseId;
      restAPIUri += "/CaseVersionId/" + pCaseVersionId;    
      restAPIUri += "/RefreshCd/" + pRefreshCd;
      return <Observable<Array<ErrorParameter>>>(this.http.get(restAPIUri));
  }
  // end Jira card DSAMS-5233 03/2022 AKP

  // ******************* Check case editability *************************

  getCaseEditability(pCaseId: number, pCaseVersionId: number): Observable<IEditResultsType> {
    this.reFetchHostUrl();
    const serviceDBId: string = CaseUtils.getServiceDatabaseId();
    let restAPIUri: string = this._hostURL + "/CaseVersionEdit";
    restAPIUri += "/ServiceDbId/" + serviceDBId;
    restAPIUri += "/CaseId/" + +pCaseId;
    restAPIUri += "/CaseVersionId/" + +pCaseVersionId;
    return <Observable<IEditResultsType>>(this.http.get(restAPIUri));
  }

  // ********************** Check Case Line Editability ************************

  getCaseLineEditability(pCaseId: number,
    pWorkingCaseId: number,
    pWorkingCaseVersionId: number,
    pCaseMasterLineId: number,
    pParentCaseMasterLineId: number,
    pCaseSubLineTx: string): Observable<IEditResultsType> {
    this.reFetchHostUrl();
    const serviceDBId: string = CaseUtils.getServiceDatabaseId();
    let restAPIUri: string = this._hostURL + "/CaseLine/CanEditCaseLine";
    restAPIUri += "/ServiceDbId/" + serviceDBId;
    restAPIUri += "/CaseId/" + pCaseId;
    restAPIUri += "/WorkingCaseId/" + pWorkingCaseId;
    restAPIUri += "/WorkingCaseVersionId/" + pWorkingCaseVersionId;
    restAPIUri += "/CaseMasterLineId/" + pCaseMasterLineId;
    restAPIUri += "/ParentCMLId/" + pParentCaseMasterLineId;
    restAPIUri += "/CaseSubLineTx/" + ((pCaseSubLineTx === "") ? DsamsConstants.REST_API_NULL : pCaseSubLineTx);
     return <Observable<IEditResultsType>>(this.http.get(restAPIUri));
  }

  //  ********************** Case Related Case ***************************

  getRelatedCaseMaster(pCaseId: number): Observable<ICaseMaster> {
    this.reFetchHostUrl();
    const serviceDBId: string = CaseUtils.getServiceDatabaseId();
    let restAPIUri: string = this._hostURL + "/CaseRelatedCase";
    restAPIUri += "/ServiceDbId/" + serviceDBId;
    restAPIUri += "/CaseId/" + +pCaseId;
    return <Observable<ICaseMaster>>(this.http.get(restAPIUri));
  }

  // ************************* Refresh Case Line ***************************

  refreshCaseLine(pCaseLine: ifaceCaseLineData): Observable<ifaceCaseLineData> {
    this.reFetchHostUrl();
    const hostURLStr: string = this._hostURL + this.caseLineEndpoint + "/Refresh/";
    pCaseLine.service_DB_ID = CaseUtils.getServiceDatabaseId();
    return <Observable<ifaceCaseLineData>>(this.http.post(hostURLStr, pCaseLine));
  }

   // DSAMS-5867 begin 07/22 DB
   restoreCaseLineData(pCaseMasterLineId: number, pCaseId: number, pWorkingCaseVersionId: number, pWorkingCaseId: number, pLockSessionId: number): Observable<any> {
    this.reFetchHostUrl();
    const queryString: string = "/GetCaseLineData/" + CaseUtils.getServiceDatabaseId() + "/" + pCaseMasterLineId + "/" + pCaseId + "/" + pWorkingCaseVersionId + "/" + pWorkingCaseId + "/" + pLockSessionId;
    return this.http.get(this._hostURL + queryString);
  }
// DSAMS-5867 end 07/22 DB

  //  ******************* Case Detail Legacy - Create Case *****************

  getCaseDetailLegacyNew(pSearchFormData: any): Observable<ICaseVersion> {
    this.reFetchHostUrl();
    const searchFormData: any = { ...pSearchFormData, "serviceDbId": CaseUtils.getServiceDatabaseId() };
    return <Observable<ICaseVersion>>(this.http.post(this._hostURL + "/CaseDetailNew", searchFormData));
  }

  // ************************** Case Detail - Check Congressional Notification ***************************

  checkCongNotifCd(pCustOrgId: string, pCaseId: number, pCaseVersionId: number, pCongNotifCd: string): Observable<any> {
    this.reFetchHostUrl();
    const serviceDBId: string = CaseUtils.getServiceDatabaseId();
    let restAPIUri: string = this._hostURL + "/CaseCheckCVN";
    restAPIUri += "/ServiceDbId/" + serviceDBId;
    restAPIUri += "/CustomerOrganizationId/" + pCustOrgId;
    restAPIUri += "/CaseId/" + +pCaseId;
    restAPIUri += "/CaseVersionId/" + +pCaseVersionId;
    restAPIUri += "/CongNotifNumber/" + pCongNotifCd;
    return <Observable<any>>(this.http.get(restAPIUri));
  }


  //  ********************** User Info *************************

  getCaseUserInfo(): Observable<any> {
    this.reFetchHostUrl();
    //return this.http.get(this._hostURL + "/getUserInfo");
    return this.http.get(this.url+"/data/userinfo.json");
  }

  //  ********************** Reference Data *************************

  /**
   * Get Reference Data from database.
   */
  getReferenceData(pRefType: string,
    pDefaultValue: string,
    pSortFieldNum: number,
    pAllowNull: boolean,
    pShowInactive: boolean = false,
    pExtraInfo: string = DsamsConstants.REST_API_NULL,
    pRuleSet: number = 1): Observable<any> {
    this.reFetchHostUrl();
    let dfltValue: string = pDefaultValue === "" ? DsamsConstants.REST_API_NULL : pDefaultValue;
    let restAPIUri: string = this._hostURL + "/ReferenceList";
    const serviceDBId: string = CaseUtils.getServiceDatabaseId();

    let extraInfo: string = pExtraInfo;
    if (extraInfo == null || extraInfo === "") {
      extraInfo = DsamsConstants.REST_API_NULL;
    }

    restAPIUri += "/ListType/" + pRefType;
    restAPIUri += "/ServiceDB/" + serviceDBId;
    restAPIUri += "/RuleSet/" + +pRuleSet;
    restAPIUri += "/CurrentValue/" + dfltValue;
    restAPIUri += "/SortFieldNum/" + +pSortFieldNum;
    restAPIUri += "/AllowNull/" + pAllowNull;
    restAPIUri += "/ShowInactive/" + String(pShowInactive);
    restAPIUri += "/ExtraInfo/" + extraInfo;
    //http://localhost:8080/dsams-service/ReferenceList/ListType/CustomerOrganization/ServiceDB/A/RuleSet/1/CurrentValue/null/SortFieldNum/0/AllowNull/true/ShowInactive/false/ExtraInfo/null
    //return this.http.get(restAPIUri);
    return this.http.get(this.url+"/data/customer_organization.json");
  }

  getAllCaseDetailsRefData(pRefType: string[],
    pDefaultValue: string[],
    pSortFieldNum: number[],
    pAllowNull: boolean[],
    pShowInactive: boolean[],
    pExtraInfo: string [],
    pRuleSet: number[]): Observable<Array<any>> {
  
    this.reFetchHostUrl();
    let restAPIUri: string = this._hostURL + "/AllCaseDetailsRefList";
    const serviceDBId: string = CaseUtils.getServiceDatabaseId();

    restAPIUri += "/ListType/" + pRefType;
    restAPIUri += "/ServiceDB/" + serviceDBId;
    restAPIUri += "/RuleSet/" +  pRuleSet;
    restAPIUri += "/CurrentValue/" + pDefaultValue;
    restAPIUri += "/SortFieldNum/" + pSortFieldNum;
    restAPIUri += "/AllowNull/" + pAllowNull;
    restAPIUri += "/ShowInactive/" + String(pShowInactive);
    restAPIUri += "/ExtraInfo/" + pExtraInfo;
    //return <Observable<Array<any>>>this.http.get(restAPIUri);
     return  <Observable<Array<any>>>this.http.get(this.url+"/data/case-details.json");
  }

  /**
   * POST Case Search to the database.
   * 
   * @param pSearchFormData  Search Params in JSON format.
   */
  postCaseSearch(pSearchFormData: any): Observable<any> {
    this.reFetchHostUrl();
    const searchFormData: any = { ...pSearchFormData, "service_DB_ID": CaseUtils.getServiceDatabaseId() };
    //return this.http.post(this._hostURL + "/CaseSearch", searchFormData);
    return this.http.get(this.url+"/data/case-search-results.json");
  }

  /**
   * POST Person Search search criteria.
   */
  postPersonSearch(pSearchFormData: IPersonSearchParamsType): Observable<Array<IPerson>> {
    this.reFetchHostUrl();
    const searchFormData: any = { ...pSearchFormData, "service_DB_ID": CaseUtils.getServiceDatabaseId() };
    return <Observable<Array<IPerson>>>(this.http.post(this._hostURL + "/PersonSearch", searchFormData));
  }

  /**
   * POST Customer Request Search search criteria.
   */
  postCustomerRequestSearch(pSearchFormData: ICustomerRequestParamsType): Observable<Array<ICustomerRequest>> {
    this.reFetchHostUrl();
    const searchFormData: any = { ...pSearchFormData, "service_DB_ID": CaseUtils.getServiceDatabaseId() };
    return <Observable<Array<ICustomerRequest>>>(this.http.post(this._hostURL + "/CustomerRequestSearch", searchFormData));
  }

  /**
   * POST Congressional Notification Search search criteria.
   */
  postCongNotificationRequestSearch(pSearchFormData: ICongNotificationParamsType): Observable<Array<ICustomerCn>> {
    this.reFetchHostUrl();
    const searchFormData: any = { ...pSearchFormData, "service_DB_ID": CaseUtils.getServiceDatabaseId() };
    return <Observable<Array<ICustomerCn>>>(this.http.post(this._hostURL + "/CongNotificationSearch", searchFormData));
  }

  /**
   * POST Case Insert (right now just case info panel)
   */
  postCaseInsert(pCaseInfo: CaseMasterCI): Observable<any> {
    this.reFetchHostUrl();
    const serviceDBId: string = CaseUtils.getServiceDatabaseId();
    let restAPIUri: string = this._hostURL + "/CaseInfo";
    restAPIUri += "/ServiceDbId/" + serviceDBId;
    return this.http.post(restAPIUri, pCaseInfo);
  }

  /**
   * GET Activity By Filter
   */
  getActivityByFilter(filter: string): Observable<any> {
    return this.http.get(this._hostURL + "/getActivityListByFilter/" + filter);
  }

  /**
   * GET Masl By Filter
   */
  getMaslByFilter(filter: string): Observable<any> {
    return this.http.get(this._hostURL + "/getMASLListByFilter/" + filter);
  }

  /**
   * GET Congressional Notification By Filter
   */
  getCnByFilter(filter: string): Observable<any> {
    return this.http.get(this._hostURL + "/getCNListByFilter/" + filter);
  }

  // Get pending tasks.
  getPendingTasks(pUserId: number): Observable<Array<IWorkflowTaskAssignmentData>> {
    this.reFetchHostUrl();
    const serviceDBId: string = CaseUtils.getServiceDatabaseId();
    let restAPIUri: string = this._hostURL + "/PendingTasks";
    restAPIUri += "/ServiceDbId/" + serviceDBId;
    restAPIUri += "/UserId/" + pUserId;
    //return <Observable<Array<IWorkflowTaskAssignmentData>>>(this.http.get(restAPIUri));
    return <Observable<Array<IWorkflowTaskAssignmentData>>>(this.http.get(this.url+"/data/tasklist.json"));
  }

  //  ********************** Rollup Sublines ***************************
  rollupSublines(pCaseId: string, pCaseMasterLineId: string, pWorkingCaseId: string, pWorkingCaseVersionId: string, pQuantity: number): Observable<Array<ErrorParameter>> {
    this.reFetchHostUrl();
    const serviceDBId: string = CaseUtils.getServiceDatabaseId();
    let restAPIUri: string = this._hostURL + this.caseLineEndpoint + "/RollupSublines";
    restAPIUri += "/ServiceDbId/" + serviceDBId;
    restAPIUri += "/CaseId/" + pCaseId;
    restAPIUri += "/CaseMasterLineId/" + pCaseMasterLineId;
    restAPIUri += "/WorkingCaseId/" + pWorkingCaseId;
    restAPIUri += "/WorkingCaseVersionId/" + pWorkingCaseVersionId;
    restAPIUri += "/Quantity/" + pQuantity;
     return <Observable<Array<ErrorParameter>>>(this.http.get(restAPIUri));
  }

  /******** Cutomer Request panels and reference data *********/
  getCustomerRequest(pCustomerRequestId: number,
    pCustomerOrganizationId: string): Observable<any> {
    this.reFetchHostUrl();
    const serviceDBId: string = CaseUtils.getServiceDatabaseId();
    return this.http.get(this._hostURL + "/CustomerRequest" +
      "/ServiceDbId/" + serviceDBId +
      "/CustomerRequestId/" + +pCustomerRequestId +
      "/CustomerOrganizationId/" + pCustomerOrganizationId);
  }

  //retrieve customer request record
  private customerRequestEndpoint: string = "/CustomerRequest";
  getCustomerRequestDto(pCustomerRequestId: number): Observable<any> {
    this.reFetchHostUrl();
    const serviceDBString: string = this.getServiceDBString();
    const queryString: string = this.customerRequestEndpoint + serviceDBString
      + "/CustomerRequestId/" + pCustomerRequestId;
    return this.http.get(this._hostURL + queryString);
  }

  //delete customer request record
  private deleteCREndpoint: string = "/DeleteCRRecord";
  deleteCustomerRequestRecord(pCustomerRequestId: number): Observable<any> {
    const serviceDBString: string = this.getServiceDBString();
    const queryString: string = this.deleteCREndpoint + serviceDBString
      + "/CustomerRequestId/" + pCustomerRequestId;
    return this.http.delete(this._hostURL + queryString);
  }

  private customerRequestNewEndpoint: string = "/CustomerRequestNew";
  getCustomerRequestNewDto(): Observable<any> {
    this.reFetchHostUrl();
    const serviceDBString: string = this.getServiceDBString();
    const queryString: string = this.customerRequestNewEndpoint + serviceDBString
    return this.http.get(this._hostURL + queryString);
  }

  private customerRequestSaveEndpoint: string = "/CustomerRequestSave";
  saveCustomerRequestRecord(pBody: any): Observable<any> {
    //hard code locksession ID for now
    const curlockSessionID: number = 1;
    this.reFetchHostUrl();
    const serviceDBString: string = this.getServiceDBString();
    const hostURLStr: string = this._hostURL + this.customerRequestSaveEndpoint +
      serviceDBString;
    return this.http.post(hostURLStr, pBody);
  }

  //Case Line Indirect Pricing Components
  private clIPCEndpoint: string = "/CaseLinePricing/CaseLineIPC";
  getCaseLineIPCDto(pPrimaryCategoryCd: string): Observable<CaseLineIPCDto[]> {
    this.reFetchHostUrl();
    const serviceDBString: string = this.getServiceDBString();
    const queryString: string = this.clIPCEndpoint + serviceDBString + "/PrimaryCategory/" + ((pPrimaryCategoryCd === "") ? DsamsConstants.REST_API_NULL : pPrimaryCategoryCd)
    return <Observable<CaseLineIPCDto[]>>this.http.get(this._hostURL + queryString);
  }

  //Case Line IPC 
  private clIPCNewEndpoint: string = "/CaseLinePricing/CLIPCReference/";
  getCLIPCRefData(pPrimaryCategoryCd: string): Observable<any> {
    this.reFetchHostUrl();
    const serviceDBString: string = "ServiceDbId/C";
    const queryString: string = this.clIPCNewEndpoint + serviceDBString +
      "/PrimaryCategory/" + pPrimaryCategoryCd;
    return this.http.get(this._hostURL + queryString);
  }

  //Case Line IPC Cost Basis
  private clIPCCostRefEndpoint: string = "/CaseLinePricing/CLIPCCostReference";
  getCLIPCCostRefData(): Observable<any> {
    this.reFetchHostUrl();
    const serviceDBString: string = this.getServiceDBString();
    const queryString: string = this.clIPCCostRefEndpoint + serviceDBString
    return this.http.get(this._hostURL + queryString);
  }

  // Case line Pricing Summary Data Call
  private pricingSummaryEndpoint: string = "/CaseLinePricingSummary";
  getCaseLinePricingSummary(pCaseId: number, pWorkingCaseId: number,
    pWorkingCaseVersionId: number, pCaseMasterLIneId: number): Observable<any> {
    //DH: commented out session var as Pricing tab structure of loading data has been reworked.
    // Fetch from the session var if it already has a value.
    // const caseLineInfoFromSession:ICaseLinePricing = JSON.parse(sessionStorage.getItem(DsamsConstants.SESSION_CASE_LINE_DETAILS_FOR_PRICING));
    // if (!!caseLineInfoFromSession) {
    //   return of(caseLineInfoFromSession);
    // }
    // else {
    this.reFetchHostUrl();
    const serviceDBString: string = this.getServiceDBString();
    const queryString: string = this.pricingSummaryEndpoint + serviceDBString +
      "/CaseId/" + pCaseId +
      "/WorkingCaseId/" + pWorkingCaseId +
      "/WorkingCaseVersionId/" + pWorkingCaseVersionId +
      "/CaseMasterLineId/" + pCaseMasterLIneId;
    return this.http.get(this._hostURL + queryString);
    // }
  }

  // Save Case Line Pricing
  // Same URI but it's a PUT (insert if it doesn't exist, update if it does).
  saveCaseLinePricingSummary(pCaseLinePricingSummary: ICaseLinePricing): Observable<ICaseLinePricing> {
    this.reFetchHostUrl();
    const serviceDBString: string = this.getServiceDBString();
    const queryString: string = this.pricingSummaryEndpoint + serviceDBString;
    return <Observable<ICaseLinePricing>>(this.http.put(this._hostURL + queryString, pCaseLinePricingSummary));
  }

  // Case line PCC DTC Data Call
  private pricingPCCDTCEndpoint: string = "/CaseLine/CaseLineComponentDeliveryTerm";
  getCaseLinePCCDTC(pCaseId: number, pWorkingCaseId: number,
    pWorkingCaseVersionId: number, pCaseMasterLIneId: number,
    pCaseLineComponentId: number): Observable<any> {
    this.reFetchHostUrl();
    const serviceDBString: string = this.getServiceDBString();
    const queryString: string = this.pricingPCCDTCEndpoint + serviceDBString +
      "/CaseId/" + pCaseId +
      "/WorkingCaseId/" + pWorkingCaseId +
      "/WorkingCaseVersionId/" + pWorkingCaseVersionId +
      "/CaseMasterLineId/" + pCaseMasterLIneId +
      "/CaseLineComponentId/" + (!pCaseLineComponentId ? 0 : pCaseLineComponentId);
    return this.http.get(this._hostURL + queryString);
  }

  // Delete Pricing Data Call
  private deletePricingEndpoint: string = "/CaseLinePricingSummary";
  deleteCaseLinePricing(pCaseId: number, pWorkingCaseId: number,
    pWorkingCaseVersionId: number, pCaseMasterLIneId: number): Observable<any> {
    this.reFetchHostUrl();
    const serviceDBString: string = this.getServiceDBString();
    const queryString: string = this.deletePricingEndpoint + serviceDBString +
      "/CaseId/" + pCaseId +
      "/WorkingCaseId/" + pWorkingCaseId +
      "/WorkingCaseVersionId/" + pWorkingCaseVersionId +
      "/CaseMasterLineId/" + pCaseMasterLIneId;
    return this.http.delete(this._hostURL + queryString);
  }

  //Card 4138 - FR17 Case Line Pricing - Calculate Costs 
  private clpCalEndpoint: string = "/CaseLinePricing/CalculateCosts";
  calculateLinePricingCosts(pCaseLinePricingSummary: ICaseLinePricing): Observable<ICaseLinePricing> {
    this.reFetchHostUrl();
    const serviceDBString: string = this.getServiceDBString();
    const hostURLStr: string = this._hostURL + this.clpCalEndpoint +
      serviceDBString;
    return <Observable<ICaseLinePricing>>this.http.patch(hostURLStr, pCaseLinePricingSummary);
  }

  // Get the publication cost.
  calculatePublicationCost(pPubCategoryCd: string, pNumPages: number, pEffectiveDt: Date): Observable<number> {
    this.reFetchHostUrl();
    const serviceDBString: string = this.getServiceDBString();
    const hostURLStr: string = this._hostURL + "/CaseLine/PublicationCost" +
      serviceDBString +
      "/PublicationCategoryCd/" + pPubCategoryCd +
      "/NumPages/" + pNumPages +
      "/EffectiveDt/" + DateValidator.dateToString2(pEffectiveDt);
    return <Observable<number>>this.http.get(hostURLStr);
  }

  // Get the personnel base rate.
  getPersonnelBaseRate(pCaseLineComponent: caseLineComponentDto): Observable<CivilianPersonnelResultsType> {
    this.reFetchHostUrl();
    const serviceDBString: string = this.getServiceDBString();
    const hostURLStr: string = this._hostURL + "/CaseLine/PersonnelBasePrice" + serviceDBString;
    return <Observable<CivilianPersonnelResultsType>>this.http.post(hostURLStr, pCaseLineComponent);
  }

  //DH - Jira 2946 - populate line/subline dropdown list
  private CaseLineSublineEndpoint: string = "/CaseNoteListLineSubline";
  getLineSublineDto(pCaseId: number): Observable<any> {
    const serviceDBString: string = this.getServiceDBString() + "/";
    const queryString: string = this.CaseLineSublineEndpoint + serviceDBString +
      "CaseId/" + pCaseId;
    return this.http.get(this._hostURL + queryString);
  }

  //DH - Jira 2946 - populate line/subline dropdown list using case id and case version ID params
  getLineSublineListForCVDto(pCaseId: number, pCaseVersionId: number): Observable<any> {
    const serviceDBString: string = this.getServiceDBString() + "/";
    const queryString: string = this.CaseLineSublineEndpoint + serviceDBString +
      "CaseId/" + pCaseId + "/CaseVersionId/" + pCaseVersionId;
    return this.http.get(this._hostURL + queryString);
  }

  //DH - Jira 2924 - retrieve case note list records
  private caseNoteListEndpoint: string = "/CaseNoteList";
  getCaseNoteListDto(pCaseId: number, pCaseVersionId: number): Observable<any> {
    const serviceDBString: string = this.getServiceDBString() + "/";
    const queryString: string = this.caseNoteListEndpoint + serviceDBString +
      "CaseId/" + pCaseId + "/CaseVersionId/" + pCaseVersionId;
    return this.http.get(this._hostURL + queryString);
  }

  //DH - Jira 4405 - replacing expired note version with latest version
  private CaseNoteReplaceEndpoint: string = "/CaseNoteReplace";
  getLatestCaseNoteVersionDto(pCaseNoteData: ICaseNote): Observable<ICaseNote> {
    this.reFetchHostUrl();
    const hostURLStr: string = this._hostURL + this.CaseNoteReplaceEndpoint + this.getServiceDBString();
    return <Observable<ICaseNote>>this.http.patch(hostURLStr, pCaseNoteData);
  }

  //DH - Jira 2934 - check duplicate user note version
  private CaseNoteDupCheckEndpoint: string = "/CaseNoteDupCheck";
  checkCaseNoteDupVersion(pCaseNoteData: ICaseNote): Observable<boolean> {
    this.reFetchHostUrl();
    const hostURLStr: string = this._hostURL + this.CaseNoteDupCheckEndpoint + this.getServiceDBString();
    return <Observable<boolean>>this.http.patch(hostURLStr, pCaseNoteData);
  }

  //DH - Jira 2960 - save case remark records
  private CaseRemarkListSaveEndpoint: string = "/CaseRemarkListSave";
  saveCaseRemarkList(pCaseRemarkListData: remarksModel[]): Observable<any> {
    this.reFetchHostUrl();
    const hostURLStr: string = this._hostURL + this.CaseRemarkListSaveEndpoint + this.getServiceDBString();
    return <Observable<any>>this.http.put(hostURLStr, pCaseRemarkListData);
  }

  //CI - Jira 2953 - save case attachment records
  private CaseAttachmentListSaveEndpoint: string = "/CaseAttachmentListSave";
  saveCaseAttachmentList(pCaseAttachmentListData: attachmentsModel[]): Observable<any> {
    this.reFetchHostUrl();
    const hostURLStr: string = this._hostURL + this.CaseAttachmentListSaveEndpoint + this.getServiceDBString();
    return <Observable<any>>this.http.put(hostURLStr, pCaseAttachmentListData);

  }

  //CI - Jira 2953 - save case attachment txt records
  private CaseAttachmentListTXTSaveEndpoint: string = "/CaseAttachmentListTXTSave";
  saveCaseAttachmentListTXT(pCaseAttachmentListTXTData: attachmentsModel[]): Observable<any> {
    this.reFetchHostUrl();
    const hostURLStr: string = this._hostURL + this.CaseAttachmentListTXTSaveEndpoint + this.getServiceDBString();
    return <Observable<any>>this.http.put(hostURLStr, pCaseAttachmentListTXTData);
  }

  //CI - Jira 2953 - save case attachment line records
  private CaseAttachmentListLineSaveEndpoint: string = "/CaseAttachmentListLineSave";
  saveCaseAttachmentListLine(pCaseAttachmentListLineData: attachmentsModel[]): Observable<any> {
    this.reFetchHostUrl();
    const hostURLStr: string = this._hostURL + this.CaseAttachmentListLineSaveEndpoint + this.getServiceDBString();
    return <Observable<any>>this.http.put(hostURLStr, pCaseAttachmentListLineData);
  }

  // Fetch Case Note from database.
  public getCaseNote(pCaseId: number,
    pCaseVersionId: number,
    pNoteId: number,
    pNoteVersionId: number,
    pCaseNoteId: number,
    pLock: boolean): Observable<ICaseNote> {
    this.reFetchHostUrl();
    const queryString: string = "/CaseNote" + this.getServiceDBString() +
      "/CaseId/" + pCaseId +
      "/CaseVersionId/" + pCaseVersionId +
      "/NoteId/" + pNoteId +
      "/NoteVersionId/" + pNoteVersionId +
      "/CaseNoteId/" + pCaseNoteId +
      "/Lock/" + pLock;
    return <Observable<ICaseNote>>this.http.get(this._hostURL + queryString);
  }

  //Card in Jira is 4555 - Replace Existing Version
  private CaseNoteListReplaceEndpoint: string = "/CaseNoteListReplace";
  getLatestCaseNoteListVersionDto(pCaseNoteData: CaseNoteDto[]): Observable<CaseNoteDto> {
    this.reFetchHostUrl();
    const hostURLStr: string = this._hostURL + this.CaseNoteListReplaceEndpoint + this.getServiceDBString();
    return <Observable<CaseNoteDto>>this.http.patch(hostURLStr, pCaseNoteData);
  }

  /**
   * Card in Jira is 2926 - Assign Reference Note
   * Author: Jeff Sniffen
   * Date: 11/8/2021
   */
  private CaseNoteAssignReferrenceNotesEndpoint: string = "/ApplicableReferenceNotes";
  getCaseNoteApplicableReferenceNotes(pCaseId: number, pCaseVersionId: string): Observable<CaseNoteDto[]> {
    this.reFetchHostUrl();
    const hostURLStr: string = this._hostURL + this.CaseNoteAssignReferrenceNotesEndpoint
      + this.getServiceDBString() + "/CaseId/" + pCaseId + "/CaseVersionId/" + pCaseVersionId;
    return <Observable<CaseNoteDto[]>>this.http.get(hostURLStr);
  }

  /**
   * Card 2961 - Remarks
   * Author Jeff Sniffen
   * Date: 11/10/2021 
   */
  private CaseRemarksData: string = "/Remark";
  getCaseRemarksData(pCaseId: number): Observable<remarksDto[]> {
    this.reFetchHostUrl();
    const hostURLStr: string = this._hostURL + this.CaseRemarksData
      + this.getServiceDBString() + "/CaseId/" + pCaseId;
    return <Observable<remarksDto[]>>this.http.get(hostURLStr);
  }

  /**
   * Card 2961 - Remarks Version Data
   * Author: Jeff Sniffen
   * Date: 11/15/2021
   */
  private CaseVersionInfoData: string = "/CaseVersion";
  getCaseVersionInfoData(pCaseId: number): Observable<caseVersionInfoDto[]> {
    this.reFetchHostUrl();
    const hostURLStr: string = this._hostURL + this.CaseVersionInfoData
      + this.getServiceDBString() + "/CaseId/" + pCaseId;
    return <Observable<caseVersionInfoDto[]>>this.http.get(hostURLStr);
  }

  // Fetch a Note
  public getNote(pNoteId: number, pNoteVersionId: number): Observable<INote> {
    this.reFetchHostUrl();
    const queryString: string = "/Note" + this.getServiceDBString() +
      "/NoteId/" + pNoteId +
      "/NoteVersionId/" + pNoteVersionId;
    return <Observable<INote>>this.http.get(this._hostURL + queryString);
  }

  // Get Note List
  public getNoteList(pUserNoteId: string,
    pNoteVersionId: string,
    pNoteTitle: string,
    pActivityId: string,
    pNoteTypeCd: string,
    pNoteExpirationDt: string): Observable<INote[]> {
    const noteSearchParams: INoteSearchParams = {
      user_NOTE_ID: pUserNoteId,
      note_VERSION_ID: pNoteVersionId,
      official_NOTE_TITLE_TX: pNoteTitle,
      activity_ID: pActivityId,
      note_TYPE_CD: pNoteTypeCd,
      note_EXPIRATION_DT: pNoteExpirationDt
    };
    this.reFetchHostUrl();
    const queryString: string = this._hostURL + "/NoteList" + this.getServiceDBString();
    return <Observable<INote[]>>this.http.post(queryString, noteSearchParams);
  }

  // Check Case Note Editability
  public getCaseNoteEditability(pCaseNoteData: ICaseNote): Observable<IEditResultsType> {
    this.reFetchHostUrl();
    const hostURLStr: string = this._hostURL + "/CaseNoteEdit" + this.getServiceDBString();
    return <Observable<IEditResultsType>>this.http.patch(hostURLStr, pCaseNoteData);
  }

  // Save Case Note
  public saveCaseNote(pCaseNoteData: ICaseNote): Observable<ICaseNote> {
    this.reFetchHostUrl();
    const queryString: string = "/CaseNote" + this.getServiceDBString();
    return <Observable<ICaseNote>>(this.http.put(this._hostURL + queryString, pCaseNoteData));
  }

  // Save Case Note List
  public saveCaseNoteList(pCaseNoteDtoList: CaseNoteDto[]): Observable<boolean> {
    this.reFetchHostUrl();
    const queryString: string = "/CaseNoteList" + this.getServiceDBString();
    return <Observable<boolean>>(this.http.put(this._hostURL + queryString, pCaseNoteDtoList));
  }


  // Refresh Case Note 
  public refreshCaseNoteForDetail(pCaseId: number, pUserNoteNumberId: number): Observable<ICaseNote> {
    this.reFetchHostUrl();
    const queryString: string = "/CaseNoteRefresh" + this.getServiceDBString() +
      "/CaseId/" + pCaseId +
      "/UserNoteNumberId/" + pUserNoteNumberId;
    return <Observable<ICaseNote>>this.http.get(this._hostURL + queryString);
  }

  // Refresh Case Note (for list)
  public refreshCaseNoteForList(pCaseId: number, pUserNoteNumberId: number): Observable<CaseNoteDto> {
    this.reFetchHostUrl();
    const queryString: string = "/CaseNoteRefreshForList" + this.getServiceDBString() +
      "/CaseId/" + pCaseId +
      "/UserNoteNumberId/" + pUserNoteNumberId;
    return <Observable<CaseNoteDto>>this.http.get(this._hostURL + queryString);
  }

  // Lock Case Note List 
  public lockCaseNoteList(pCaseId: number, pCaseVersionId: number): Observable<number> {
    this.reFetchHostUrl();
    const queryString: string = "/CaseNoteListLock" + this.getServiceDBString() + "/CaseId/" + pCaseId + "/CaseVersionId/" + pCaseVersionId;
    return <Observable<number>>this.http.get(this._hostURL + queryString);
  }

  // Lock Case Remark List 
  public lockCaseRemarkList(pCaseId: number): Observable<number> {
    this.reFetchHostUrl();
    const queryString: string = "/CaseRemarkListLock" + this.getServiceDBString() + "/CaseId/" + pCaseId;
    return <Observable<number>>this.http.get(this._hostURL + queryString);
  }

  /**
   * Attachments
   * Author Francis Shu
   * Date: 12/07/2021
   */
  private CaseAttachmentData: string = "/Attachment";
  getCaseAttachmentsData(pCaseId: number, pVersionId: number): Observable<attachmentsDto[]> {
    this.reFetchHostUrl();
    const hostURLStr: string = this._hostURL + this.CaseAttachmentData
      + this.getServiceDBString() + "/CaseId/" + pCaseId + "/CaseVersionId/" + pVersionId;
    return <Observable<attachmentsDto[]>>this.http.get(hostURLStr);
  }

  private SummaryNotifyData: string = "/Summary";
  getSummaryNotifyData(pCongNotifyCode: string): Observable<summaryNotifyDto[]> {
    this.reFetchHostUrl();
    const hostURLStr: string = this._hostURL + this.SummaryNotifyData
      + this.getServiceDBString() + "/CongNotificationNumberCode/" + pCongNotifyCode;
    return <Observable<summaryNotifyDto[]>>this.http.get(hostURLStr);
  }

  private CongAttachmentsData: string = "/CustomerAttachment";
  getCongAttachmentsData(pNotificationNbrCode: string): Observable<CongressNotifyAttachmentsDTO[]> {
    this.reFetchHostUrl();
    const hostURLStr: string = this._hostURL + this.CongAttachmentsData + "/CongNotificationNumberCode/" + pNotificationNbrCode;
    return <Observable<CongressNotifyAttachmentsDTO[]>>this.http.get(hostURLStr);
  }

  private getPdf: string = "/CNAttachment";
  getCongAttachmentPdf(pCNID: string, pAttachmentId: string): any {
    this.reFetchHostUrl();
    const hostURLStr: string = this._hostURL + this.getPdf + "/CustomerCNID/" + pCNID 
    + "/AttachmentID/" + pAttachmentId;
    const options = { responseType: 'blob' as 'json'  };
    return this.http.get<any>(hostURLStr, options);
      
  }
 
  // Lock Case Attachment List 
  public lockCaseAttachmentList(pCaseId: number, pCaseVersionId: number): Observable<number> {
    this.reFetchHostUrl();
    const queryString: string = "/CaseAttachmentListLock" + this.getServiceDBString() + "/CaseId/" + pCaseId + "/CaseVersionId/" + pCaseVersionId;
    return <Observable<number>>this.http.get(this._hostURL + queryString);
  }

  //DH - Jira 4936 - get Congressional Notify Case Amount records
  private CNCaseAmountEndpoint: string = "/Amount";
  getCongressionalNotifyCaseAmountList(pCNCode: string): Observable<CongressNotifyAmountDTO[]> {
    this.reFetchHostUrl();
    const queryString: string = this.CNCaseAmountEndpoint + "/CongNotNumCd/" + pCNCode;
    return <Observable<CongressNotifyAmountDTO[]>>this.http.get(this._hostURL + queryString);
  }

  //DH - Jira 3204 - get Congressional Notify Case Quantity records
  private CNCaseQuantitytEndpoint: string = "/Quantity/CountryCd/";
  getCongressionalNotifyCaseQuantityList(pCNCode: string, pCountry: string): Observable<CongressNotifyQuantityDTO[]> {
    this.reFetchHostUrl();
    const queryString: string = this.CNCaseQuantitytEndpoint + pCountry + "/CongNotNumCd/" + pCNCode;
    return <Observable<CongressNotifyQuantityDTO[]>>this.http.get(this._hostURL + queryString);
  }

  //FS - Jira 3208 - get Congressional Notify Case Overage records
  private CNCaseOverageEndpoint: string = "/Overages";
  getCongressionalNotifyCaseOverageList(pCNCode: string): Observable<CongressNotifyOverageDTO[]> {
    this.reFetchHostUrl();
    const queryString: string = this.CNCaseOverageEndpoint + "/CongNotNumCd/" + pCNCode;
    return <Observable<CongressNotifyAmountDTO[]>>this.http.get(this._hostURL + queryString);
  }

  //DH - Jira 5056 - save congressional notification records
  private CongressionalNotificationSaveEndpoint: string = "/CongressionalNotificationSave";
  saveCongressionalNotification(pCongressionalNotificationData: CustomerCnModel[]): Observable<any> {
    this.reFetchHostUrl();
    const hostURLStr: string = this._hostURL + this.CongressionalNotificationSaveEndpoint + this.getServiceDBString();
    return <Observable<any>>this.http.put(hostURLStr, pCongressionalNotificationData);
  }

  //DH - Jira 5020 - save congressional notification PDF records
  private CongressionalPDFSaveEndpoint: string = "/CongressNotifPDFAttachment";
  saveCongressionalPDFNotification(pCongressionalNotificationPDFData: FormData): Observable<any> {
    this.reFetchHostUrl();
    const hostURLStr: string = this._hostURL + this.CongressionalPDFSaveEndpoint;
    return <Observable<any>>this.http.post(hostURLStr, pCongressionalNotificationPDFData);
  }

  //DH - Jira 1849 - Calculate FMSO Costs 
  private CalFMSOEndpoint: string = "/CaseLine/CalculateFMSO";
  calculateFMSOAmounts(pCaseLineData: ifaceCaseLineData): Observable<ifaceCaseLineData> {
    this.reFetchHostUrl();
    const serviceDBString: string = this.getServiceDBString();
    const hostURLStr: string = this._hostURL + this.CalFMSOEndpoint + serviceDBString;
    return <Observable<ifaceCaseLineData>>this.http.patch(hostURLStr, pCaseLineData);
  }

  //DH - Jira 5282 - Create new case version document
  private NewCaseVersionEndpoint: string = "/newCaseVersion/document/";
  createNewCaseVersionDoc(pCaseVersionData: ICaseVersion): Observable<ICaseVersion> {
    this.reFetchHostUrl();
    const hostURLStr: string = this._hostURL + this.NewCaseVersionEndpoint +
      CaseUtils.getServiceDatabaseId() + '/' + pCaseVersionData.case_ID + '/' + pCaseVersionData.customer_REQUEST_ID +
      '/' + pCaseVersionData.case_VERSION_TYPE_CD;
    return <Observable<ICaseVersion>>this.http.get(hostURLStr);
  }
  
   // begin DSAMS-5205 Locking support 02/2022 DB
   setLock(pIsVirtual:boolean, pTableName:string, pOperation:number, pInputPara:string, serviceId:string): Observable<any> {
    return this.http.get(this._hostURL+"/setLock/"+pIsVirtual+"/"+pTableName+"/"+pOperation+"/"+pInputPara+"/"+serviceId);
  }

  unLock(lockSessionId:number, serviceId:string): Observable<any> {
    return this.http.get(this._hostURL+"/closeSession/"+lockSessionId+"/"+serviceId);
  }

  validateLock(pTableName:string, pInputPara:string, serviceId:string): Observable<any> {
    return this.http.get(this._hostURL+"/validateSessionMegs/"+pTableName+"/"+pInputPara+"/"+serviceId, { responseType: 'text'});
  }
  // end DSAMS-5205 Locking support 
 //Card 5231 
 
  validateOverRiddenIPC(pCaseId: number, pCaseVersionId: number): Observable<Array<ErrorParameter>> {
    this.reFetchHostUrl();
    const serviceDBId: string = CaseUtils.getServiceDatabaseId();
    let restAPIUri: string = this._hostURL + "/validateOverRiddenIPC/ServiceDbId/" + serviceDBId + "/CaseId/" + pCaseId + "/CaseVersionId/" + pCaseVersionId;
    console.log("................  ", restAPIUri , " ........................................");
    return <Observable<Array<ErrorParameter>>>(this.http.get(restAPIUri));
  }

  private CaseModFundingData: string = "/getCaseDetailModFunding";
  getCaseModFundingData(pCaseId: number, pVersionId: number): Observable<ModFundingDto[]> {
    this.reFetchHostUrl();
    const hostURLStr: string = this._hostURL + this.CaseModFundingData
      + "/" + CaseUtils.getServiceDatabaseId()+"/" + pCaseId + "/" + pVersionId;
    return <Observable<ModFundingDto[]>>this.http.get(hostURLStr);
  }

  getNextCaseDesignator(pCaseDesignatorCd: string, pCountry: string, pCaseUsage: string, pIaCd: string): Observable<any>{
    this.reFetchHostUrl();
    const hostURLStr: string = this._hostURL + "/nextCaseDesignator/" + CaseUtils.getServiceDatabaseId() + "/" + pCaseDesignatorCd + "/" + pCountry + "/" + pCaseUsage + "/" + pIaCd;
    return <Observable<string>>this.http.get(hostURLStr);
  }

  //DSAMS-5462 DH 05/22
  private UserFloWAccessEndpoint: string = "/UserWorkflowAccess";
  checkUserWorkFlowAccess(pCaseId: number, 
     pCaseVersionId: number,
     pCaseLineId: number,
     pLevel: string,
     pLockSessionId: number): Observable<boolean> {
      this.reFetchHostUrl();
      const queryString: string = this.UserFloWAccessEndpoint
       + "/" + CaseUtils.getServiceDatabaseId() 
       + "/" + pCaseId 
       + "/" + pCaseVersionId 
       + "/" + pCaseLineId 
       + "/" + pLevel 
       + "/" + pLockSessionId;
     return <Observable<boolean>>this.http.get(this._hostURL + queryString);  
   }
 
  //DSAMS-5462 DH 07/22
  private checkCaseWritingEndPoint: string = "/CVWritingAccess";
  checkForCVWritingStatus(pCaseId: number, 
     pCaseVersionId: number): Observable<boolean> {
      this.reFetchHostUrl();
      const queryString: string = this.checkCaseWritingEndPoint
       + "/" + CaseUtils.getServiceDatabaseId() 
       + "/" + pCaseId 
       + "/" + pCaseVersionId;
       console.log(this.http.get(this._hostURL + queryString))
     return <Observable<boolean>>this.http.get(this._hostURL + queryString);  
   }

  //DSAMS-5462 DH 05/22
  private WebCompEndpoint: string = "/getWebComponent";
  getWebComponent(): Observable<WebComponentDTO[]> {
     this.reFetchHostUrl();
     const hostURLStr: string = this._hostURL + this.WebCompEndpoint;
     //return <Observable<WebComponentDTO[]>>(this.http.get(hostURLStr));
     return <Observable<WebComponentDTO[]>>(this.http.get(this.url+"/data/webcomps.json"));
  }

  //DSAMS-5690 ZW 07/2022
  getCaseAmendModNumberChange(pCaseId: number, pCaseVersionId: number, pVersionTypeCd: string, pVersionNumId: number): Observable<any> {
    this.reFetchHostUrl();
    const queryString: string = "/" + CaseUtils.getServiceDatabaseId() 
                              + "/" + pCaseId + "/" + pCaseVersionId
                              + "/" + pVersionTypeCd + "/" + pVersionNumId;

    return this.http.get(this._hostURL + "/getCaseAmendModNumberChange" + queryString, { responseType: 'text'});

  }

  //For Case Milestones
  getOptionGroups(filter: string): Observable<any> 
  {
    //return this.http.get(this._hostURL+"/getOptionGroups/"+filter);
    return this.http.get(this.url+"/data/groupoptions.json");
  }

  getCaseMilestones(filter: string): Observable<any> 
  {
    //return this.http.get(this._hostURL+"/getCaseMilestones/"+filter);
    return this.http.get(this.url+"/data/milestonelist.json");
  }

  getZeroValueEDAGrant(filter: string): Observable<any> 
  {
    //return this.http.get(this._hostURL+"/getZeroValueEDAGrant/"+filter);
    return this.http.get(this.url+"/data/access.json");
  }

  getRecentAOD(filter: string): Observable<any> 
  {
    //return this.http.get(this._hostURL+"/getRecentAOD/"+filter);
    return this.http.get(this.url+"/data/empty.json");
  }

  postCaseMilestones(formData: any): Observable<any>{
    return this.http.post(this._hostURL+"/saveCaseMilestones", formData);
  } 

  getMilestonePrerequiste(filter: string): Observable<any> 
  {
    return this.http.get(this._hostURL+"/getMilestonePrerequiste/"+filter);
  }

  getCommRequiredIn(filter: string): Observable<any> 
  {
    return this.http.get(this._hostURL+"/getCommRequiredIn/"+filter);
  }

  private caseValidateEndpoint: string = "/caseValidateForStatusChange";
  caseValidateForStatusChange(pBody: ICaseVersion): Observable<ICaseVersion> {
    //hard code locksession ID for now
    const curlockSessionID: string = "/LockSessionId/0";
    this.reFetchHostUrl();
    const serviceDBString: string = this.getServiceDBString();
    const hostURLStr: string = this._hostURL + this.caseValidateEndpoint +
      serviceDBString + curlockSessionID;
      console.log('hosturlstr=',hostURLStr)
    return  <Observable<ICaseVersion>>this.http.post(hostURLStr, pBody);
  }

  // begin jiracard DSAMS-5848 08/2022 AKP
  postValidateWebComponent(validateWebComponentInputData: any, ): Observable<any>{
    let tempHostURL = this._hostURL+"/webComponent/validateWebComponent" + "/" + CaseUtils.getServiceDatabaseId();
    console.log("tempHostURL==" + tempHostURL);
    //return this.http.post(this._hostURL+"/webComponent/validateWebComponent" + "/" + CaseUtils.getServiceDatabaseId(), validateWebComponentInputData);
    return this.http.get(this.url+"/data/validatewebcomp.json");
  } 
  // end jiracard DSAMS-5848 08/2022 AKP

  //DSAMS-5851 ZW 09/2022
  validateSelectedOption(pCsuCd: string, pCaseId: string, pCaseVersionId: string): Observable<any> {
    this.reFetchHostUrl();
    const queryString: string = "/" + CaseUtils.getServiceDatabaseId() 
              + "/" + pCsuCd + "/" + pCaseId + "/" + pCaseVersionId;

    return this.http.get(this._hostURL + "/validateSelectedOption" + queryString);
  }

  //begin DSAMS-5961 DH 10/22
  private checkIfPendingTasksEndpoint: string = "/checkIfPendingTasksforCancel";
  checkIfPendingTasksforCancel(pCaseVersionId: string,pSAP: string): Observable<boolean> {
    this.reFetchHostUrl();
    const queryString: string = "/" + CaseUtils.getServiceDatabaseId() 
              + "/" +  pCaseVersionId + "/" + pSAP;
    return <Observable<boolean>> this.http.get(this._hostURL + this.checkIfPendingTasksEndpoint + queryString);
  }

  private checkForRelatedCVEndpoint: string = "/checkForRelatedCaseVersion";
  checkForRelatedCaseVersion(pCaseId: string,pCaseVersionId: string): Observable<boolean> {
    this.reFetchHostUrl();
    const queryString: string = "/" + CaseUtils.getServiceDatabaseId() 
              + "/" +  pCaseId + "/" + pCaseVersionId;
    return <Observable<boolean>> this.http.get(this._hostURL + this.checkForRelatedCVEndpoint + queryString);
  }

  private xRefreshSaveStatusChangeEndpoint: string = "/ExecuteSaveStatusChange";
  executeRefreshSaveStatusChange(pCaseVersionBody: ICaseVersion, pLockSessionId: string): Observable<boolean> {
    this.reFetchHostUrl();
    const serviceDBString: string = this.getServiceDBString();
    const hostURLStr: string = this._hostURL + this.xRefreshSaveStatusChangeEndpoint +
      serviceDBString +  "/LockSessionId/" + pLockSessionId;
      console.log('hosturlstr=',hostURLStr)
    return  <Observable<boolean>>this.http.post(hostURLStr, pCaseVersionBody);
  }

  private deleteMilestoneStatusEndpoint: string = "/DeleteMilestone";
  deleteMilestoneStatusChange(pCaseVersionBody: ICaseVersion, pLockSessionId: string): Observable<boolean> {
    this.reFetchHostUrl();
    const serviceDBString: string = this.getServiceDBString();
    const hostURLStr: string = this._hostURL + this.deleteMilestoneStatusEndpoint + serviceDBString;
      console.log('hosturlstr=',hostURLStr)
    return  <Observable<boolean>>this.http.post(hostURLStr, pCaseVersionBody);
  }

  checkIfCaseVersionMilestoneExists(pCaseId: string,pCaseVersionId: string,
    pMilestoneId: string,pIgnoreRestatement: boolean,pWithDateTypeCd: string): Observable<boolean> {
    this.reFetchHostUrl();
    const queryString: string = "/" + CaseUtils.getServiceDatabaseId() 
              + "/" +  pCaseId +"/" + pCaseVersionId + "/" + pMilestoneId +"/" + pIgnoreRestatement +"/"+ pWithDateTypeCd;

    return <Observable<boolean>> this.http.get(this._hostURL + "/checkIfCaseVersionMilestoneExists" + queryString);
  }
  //end DSAMS-5961 DH 10/22

    // begin DSAMS-5912 09/22 DB
    getDbId(): string {
      return sessionStorage.getItem('serviceDBid');
    }
    getDbIdSlash(): string {
      return this.getDbId() + "/";
    }
  
    getSlashDbIdSlash(): string {
      return"/" + this.getDbId() + "/";
    }
  
    getSlashDbId(): string {
      return"/" + this.getDbId();
    }
    openLegacyLockSession(): Observable<any>{
      this.reFetchHostUrl();
     let  apiUrl: string = this._hostURL + "/legacy/openLockSession/" + this.getDbId();
      return this.http.get(apiUrl ); 
   } 
    closeLegacyLockSession(lockSessionId: string): Observable<any>{ 
      this.reFetchHostUrl();
      let apiUrl: string = this._hostURL + "/legacy/closeDbLockSession/" + this.getDbIdSlash() + lockSessionId;
      return this.http.get(apiUrl ) ; 
    }
  
    setCaseVersionListLock(tableName: string, caseVersionId: string, caseId: string, lockSessionId: string): Observable<any> {
      this.reFetchHostUrl();
      let apiUrl: string = this._hostURL + "/legacy/caseVersion/listLock/" + this.getDbIdSlash() + tableName + "/" + caseVersionId + "/" + caseId + "/" +
        lockSessionId;
      return this.http.get(apiUrl);
    }
    
    // end DSAMS-5912 09/22 DB
}