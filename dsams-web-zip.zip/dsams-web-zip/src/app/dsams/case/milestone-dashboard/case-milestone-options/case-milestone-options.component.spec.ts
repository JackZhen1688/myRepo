import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CaseMilestoneOptionsComponent } from './case-milestone-options.component';

describe('CaseMilestoneOptionsComponent', () => {
  let component: CaseMilestoneOptionsComponent;
  let fixture: ComponentFixture<CaseMilestoneOptionsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CaseMilestoneOptionsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CaseMilestoneOptionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
