import { formatDate } from '@angular/common';
import { Component, Inject, Injector, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormGroup } from '@angular/forms';
import { MatDialog, MatDialogConfig, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { BehaviorSubject } from 'rxjs';
import { take } from 'rxjs/operators';
import { DsamsConstants } from 'src/app/dsams/dsams.constants';
import { MessageBtnClicked, MessageBtnConfig } from 'src/app/dsams/enums/user-message.enum';
import { ImessageData } from 'src/app/dsams/interfaces/imessage-data';
import { DsamsMethodsService } from 'src/app/dsams/services/dsams-methods.service';
import { DsamsRestfulService } from 'src/app/dsams/services/dsams-restful.service';
import { DsamsUserMessageService } from 'src/app/dsams/services/dsams-user-message.service';
import { PopCommonMilestoneComponent } from 'src/app/dsams/utilitis/popups/pop-common-milestone/pop-common-milestone.component';
import { CVMRejectionReason } from '../../../model/cvm-rejection-reason-model';
import { ICaseMilestoneRevision } from '../../../model/dto/case-milestone-revision';
import { ICaseVersionMilestone } from '../../../model/dto/case-version-milestone';
import { ICaseVersion } from '../../../model/dto/icase-version';
import { CaseRestfulService } from '../../../services/case-restful.service';
import { CaseUtils } from '../../../utils/case-utils';
import { MessageMgr } from '../../../validation/message-mgr';
import { MilestoneConstants } from '../../constants/milestone.constants';
import { ShareMethodsService } from '../../services/share-methods.service';
import { CaseMilestoneOptionsComponent } from '../case-milestone-options.component';


@Component({
  selector: 'app-control-milestone',
  templateUrl: './control-milestone.component.html',
  styleUrls: ['./control-milestone.component.css']
})
export class ControlMilestoneComponent implements OnInit {

  public msOptionForm: FormGroup;
  isSaveDisabled: boolean = false;
  caseId: number;
  caseVersionId: number;
  isEditable: boolean = false;
  paramCaseId: string;
  mData: string[];
  dData: string[];
  mTitle: string;
  statusLabel: string;
  userCaseId: string;
  typeWithNum: string;
  dateLabel: string = 'Actual Date';
  dateDisabled: boolean = false;
  commentsLable: string = 'Comments'
  isCommentsFieldsRequired = false; 
  addDisabled: boolean = false;

  caseVersionDS: ICaseVersion;
  dateTypeCd: string = 'A';
  revisionList: ICaseMilestoneRevision[] = [];
  caseVersionMSList: ICaseVersionMilestone[] = [];
  showSpinner: BehaviorSubject<boolean> = new BehaviorSubject(false);
  private messageService: DsamsUserMessageService;
  cancelClicked: boolean = false;
  messageData: ImessageData;
  private dsamsRestService: DsamsRestfulService;
  private shareMethodsService: ShareMethodsService;

  personUserId: string;
  personUserName: string;
  personActivityId: string;
  durationInSeconds: number = 5;


  constructor(public dialogRef: MatDialogRef<CaseMilestoneOptionsComponent>,
    private dialog: MatDialog,
    private caseRestService: CaseRestfulService,
    private dsamsMethodsService: DsamsMethodsService,
    private injector: Injector,
    @Inject(MAT_DIALOG_DATA) public data: {
      passingCaseID: string,
      passingCaseVerId: string,
      passingUsage: string,
      passingMilestoneId: string
    },
    private formBuilder: FormBuilder) {
    this.messageService = injector.get<DsamsUserMessageService>(DsamsUserMessageService);
    this.dsamsRestService = injector.get<DsamsRestfulService>(DsamsRestfulService);
    this.shareMethodsService = injector.get<ShareMethodsService>(ShareMethodsService);
    this.msOptionForm = formBuilder.group({
      'msOption': formBuilder.array([]),
    });
    console.log("construct option");
  }

  ngOnInit() {
    console.log('new Date().toString=', new Date().toString());
    this.caseId = Number(this.data.passingCaseID);
    this.caseVersionId = Number(this.data.passingCaseVerId);
    this.mData = (MilestoneConstants.getMilestoneData(this.data.passingMilestoneId)).split('|');
    this.mTitle = this.mData[0];
    console.log('MDATA=',this.mData)
    if (this.mData[1] == 'N') {
      this.statusLabel = this.mData[2];
    } else {
      this.statusLabel = 'Saving this milestone will cause the case status to change to';
    }
    if (this.data.passingUsage.substring(0, 5).toUpperCase() == 'STATE') {
      this.dateLabel = 'Planned Date';
      this.dateTypeCd = 'P';
    }
    if (this.data.passingUsage.substring(0, 5).toUpperCase() == 'OTHER') {
      this.dateDisabled = true;
    }
    if (this.mData[4] == '1') {
      this.commentsLable = 'Comments*'
      this.isCommentsFieldsRequired = true;
    }
    else this.isCommentsFieldsRequired = false;

    if (this.mData[3] == '1') {
      this.addDisabled = false;
    }
    this.addMsOption();
    this.getUserInfo();
    this.getCaseVersionData();
   
  }

  onSave() {
    console.log('on save');

  }

  onCancel(): void {
    console.log('on cancel');
    this.cancelClicked = true;
    this.dialogRef.close({ data: false });
  }

  addMsOption() {
    const data = this.formBuilder.group({
      'txtMilestoneId': [this.data.passingMilestoneId],
      'txtMilestoneName': [this.mTitle],
      'txtActualDate_A': [new Date()],
      'txtComments': [''],
      'commReasons': this.formBuilder.array([])
    });
    this.msOption.push(data);
  }

  get msOption() {
    return this.msOptionForm.get('msOption') as FormArray
  }

  onSubmit() {
    if (!this.cancelClicked) {
      this.startSave();
    }
  }

  addCommReason(pIndex: number, pCommReason?: any) {
    const comReason = this.formBuilder.group({
      'txtCode': [pCommReason ? pCommReason.REJECT_REASON_ID : ''],
      'txtReason': [pCommReason ? pCommReason.REJECT_TITLE_NM : ''],
      'txtComments': [pCommReason ? pCommReason.CDEF_COMMENT_TX : ''],
      'reject_REASON_ID': [pCommReason ? pCommReason.REJECT_REASON_ID : ''],
      'cdef_COMMENT_TX': [pCommReason ? pCommReason.CDEF_COMMENT_TX : ''],
      'new_REASON':['insert'],
    });
    (<FormArray>(<FormGroup>(<FormArray>this.msOption)
      .controls[pIndex]).controls['commReasons']).push(comReason);
  }

  delCommReason(pMsIndex: number, pIndex: number) {
    (<FormArray>(<FormGroup>(<FormArray>this.msOption)
      .controls[pMsIndex]).controls['commReasons']).removeAt(pIndex);
  }

  commonMilestonePopup(index: number) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = "1170px";
    dialogConfig.height = "610px";
    dialogConfig.data = { passingMilestoneId: this.data.passingMilestoneId };
    const dialogRef = this.dialog.open(PopCommonMilestoneComponent, dialogConfig);
    dialogRef.afterClosed().subscribe(result => {
      if (result.length != 0) {
        (<FormArray>(<FormGroup>this.msOption.controls[0]).controls['commReasons']).controls[index].get("txtCode").setValue(result.milestone_REJECT_REASON_ID);
        (<FormArray>(<FormGroup>this.msOption.controls[0]).controls['commReasons']).controls[index].get("txtReason").setValue(result.reject_TITLE_NM);
        (<FormArray>(<FormGroup>this.msOption.controls[0]).controls['commReasons']).controls[index].get("reject_REASON_ID").setValue(result.reject_REASON_ID);
        console.log("*****result=" + JSON.stringify(result),'***Current CVM=', this.msOption.controls[0]);
      }
    });
  }

  continueSaveChangeStatus(){
    this.caseVersionDS.desiredStatusTitle = this.dData[1];
    this.caseVersionDS.desiredStatusSequenceNmbr = Number(this.dData[2]);
    this.caseVersionDS.currentStatusSequenceNmbr = Number(this.dData[3]);
    this.caseVersionDS.refreshCd = 9;
    this.caseVersionDS.congressional_NOTIFICATION_IN = true;
    this.caseVersionDS.validateCase = true;
    this.caseVersionDS.caseVersionMilestoneList = this.caseVersionMSList;
    this.caseVersionDS.theCaseId.user_CASE_ID = CaseUtils.unformatUserCaseId(this.userCaseId);
    this.setTheMilestones();
    console.log('CV data to be saved=', this.caseVersionDS);
    if (this.validateComments(this.caseVersionDS.caseVersionMilestoneList[0])) {
      if (this.mData[1] == 'N') {
        if (this.shareMethodsService.validateFormValues(this.buildNewFormValue())) {
          this.nonLegacySave(this.buildNewFormValue());
        }
      } else {
        if (CaseUtils.isBlankStr(this.caseVersionDS.desiredStatusCd)){
          MessageMgr.displayErrorMessage("New status cannot be determined. Identify this document to your DSAMS POC");
          this.dialogRef.close({ data: false });
        }
        else this.performLegacySave();
      }
    }
  }

  //DH 10/22 - check for related case version of desired code = Implemented
  checkForRelatedCaseExist(){
    if (this.doesRelatedCaseVersionExist && this.caseVersionDS.desiredStatusCd.toUpperCase() === 'I'){
      this.messageData = this.messageService.yesNoMsgData();
      this.messageData.title = 'Confirmation Message';
      this.messageData.message = 'There are cases related with concurrent funding. Do you still want to proceed?'
      this.messageData.msgBtnConfig = MessageBtnConfig.YesNo;
      this.messageService.showMessage(this.messageData)
        .subscribe(result => {
          if (this.messageData.btnClicked == MessageBtnClicked.YesClicked) {
            console.log('yes confirmed');
            this.continueSaveChangeStatus();
          } else {
            console.log('no confirmed');
          }
        });
    }
    else {
      this.continueSaveChangeStatus();
    }
  }

  getDesiredStatusForLabel(){
    const param: any = {
      sapCd: this.caseVersionDS.theCaseId.security_ASSISTANCE_PROGRAM_CD,
      cuiCd: this.caseVersionDS.theCaseId.case_USAGE_INDICATOR_CD,
      cvTypeCd: this.caseVersionDS.case_VERSION_TYPE_CD,
      dsaApprovalIn: this.caseVersionDS.dsa_APPROVAL_IN,
      sdApprovalIn: this.caseVersionDS.state_DEPARTMENT_APPROVAL_IN,
      cStatusCd: this.caseVersionDS.case_VERSION_STATUS_CD,
      cmStatusCd: this.caseVersionDS.theCaseId.case_MASTER_STATUS_CD
    }
    let parsedOutDesiredStatus = (MilestoneConstants.getDesiredStatus(this.data.passingMilestoneId, param)).split('|');
    console.log('parsedOutDesiredStatus=', parsedOutDesiredStatus[1]);
    if (!CaseUtils.isBlankStr(parsedOutDesiredStatus[1]))
        this.statusLabel += " " + parsedOutDesiredStatus[1];
  }

  startSave() {
    if (this.caseVersionDS.theCaseId.security_ASSISTANCE_PROGRAM_CD === 'FMS' &&
      (this.caseVersionDS.case_VERSION_TYPE_CD === 'A' || this.caseVersionDS.case_VERSION_TYPE_CD === 'M') &&
      this.caseVersionDS.case_VERSION_STATUS_CD === 'C') {
      this.messageData = this.messageService.yesNoMsgData();
      this.messageData.title = 'Confirmation Message';
      this.messageData.message = 'Another document was implemented after this %1 was initialized. Data must be refreshed before status can be changed. Do you want to continue?'
      this.messageData.msgBtnConfig = MessageBtnConfig.YesNo;
      this.messageService.showMessage(this.messageData)
        .subscribe(result => {
          if (this.messageData.btnClicked == MessageBtnClicked.YesClicked) {
            console.log('yes clicked')
          } else {
            console.log('No Clicked')
          }
        });
    }

    const aRevisionObject: ICaseMilestoneRevision = {
      entityName: 'ICaseMilestoneRevision',
      status: 1,
      case_VERSION_MILESTONE_DT: new Date(),
      theActivityId: null,
      theDateTypeCd: null,
      theUserId: null,
      activity_ID: this.personActivityId,
      case_ID: this.caseId,
      case_MILESTONE_ID: null,
      case_MILESTONE_REVISION_ID: null,
      case_VERSION_ID: this.caseVersionId,
      date_TYPE_CD: this.dateTypeCd,
      user_ID: Number(this.personUserId)
    }
    this.revisionList.push(aRevisionObject);
    const aCaseVersionMSObject: ICaseVersionMilestone = {
      entityName: 'caseVersionMilestone',
      status: 0,
      case_ID: this.caseId,
      case_MILESTONE_COMMENT_TX: this.msOption.controls[0].get("txtComments").value,
      cASE_MILESTONE_ID: null,
      case_VERSION_ID: this.caseVersionId,
      customer_REQUEST_ID: null,
      milestone_ID: this.data.passingMilestoneId,
      milestone_OVERRIDE_IN: false,
      caseMilestoneRevisionList: this.revisionList,
     }
    let commReasonsSize = this.msOption.controls[0].get('commReasons').value
    console.log('**preparelegacySave',this.msOption.controls[0].get('commReasons').value,commReasonsSize.length)
    if (this.msOption.controls[0].get('commReasons').value !== null &&
      commReasonsSize.length > 0) {
      aCaseVersionMSObject.cvmRejectionReasonList = [{
        entityName: "CVM_REJECTION_REASON",
        status: 1,
        case_ID: this.caseId,
        cASE_MILESTONE_ID: null,
        case_VERSION_ID: this.caseVersionId,
        reject_REASON_ID:
          (<FormArray>(<FormGroup>this.msOption.controls[0]).controls['commReasons']).controls[0].get("reject_REASON_ID").value,
      }]
    }
    this.caseVersionMSList = [];
    this.caseVersionMSList.push(aCaseVersionMSObject);
    const param: any = {
      sapCd: this.caseVersionDS.theCaseId.security_ASSISTANCE_PROGRAM_CD,
      cuiCd: this.caseVersionDS.theCaseId.case_USAGE_INDICATOR_CD,
      cvTypeCd: this.caseVersionDS.case_VERSION_TYPE_CD,
      dsaApprovalIn: this.caseVersionDS.dsa_APPROVAL_IN,
      sdApprovalIn: this.caseVersionDS.state_DEPARTMENT_APPROVAL_IN,
      cStatusCd: this.caseVersionDS.case_VERSION_STATUS_CD,
      cmStatusCd: this.caseVersionDS.theCaseId.case_MASTER_STATUS_CD
    }
    console.log('desriedstatus=', MilestoneConstants.getDesiredStatus(this.data.passingMilestoneId, param));
    console.log('param values =', param);
    this.dData = (MilestoneConstants.getDesiredStatus(this.data.passingMilestoneId, param)).split('|');
    this.caseVersionDS.desiredStatusCd = this.dData[0];    
    this.checkForRelatedCaseExist();
  }

  getCaseMilestones(filter: string) {
    this.caseRestService.getCaseMilestones(filter)
      .subscribe(
        milestoneData => {
          if (milestoneData) {
            console.log('milestoneData=', milestoneData);
          }
        },
        err => {
          console.log("Error occured: getCaseMilestones()" + err.message);
          this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, JSON.stringify(err.message))
        }
      );
  }

  getMilestonesRecord(){ 
    const filter = this.data.passingMilestoneId+"%" + "@NULL%"+ "@%"+ "@%"+"#" + CaseUtils.getServiceDatabaseId();
    this.dsamsRestService.getMilestones(encodeURIComponent(filter))
    .subscribe(            
      data => {console.log('Milestone data =',data)
    })
  }
 
  getCaseVersionData() {
    this.caseRestService
      .getCaseDetailLegacy(this.caseId, this.caseVersionId).pipe(take(1))
      .subscribe(
        data => {
          if (data) {
            this.caseVersionDS = data;
            this.userCaseId = this.caseVersionDS.theCaseId.user_CASE_ID;
            if (this.caseVersionDS.case_VERSION_NUMBER_ID == 0) {
              this.typeWithNum = this.caseVersionDS.case_VERSION_TYPE_CD;
            } else {
              this.typeWithNum = this.caseVersionDS.case_VERSION_TYPE_CD + this.caseVersionDS.case_VERSION_NUMBER_ID.toString();
            }
            console.log('this.caseversionds=', this.caseVersionDS);
            this.isTherePendingTaskForCancel();
            this.checkForRelatedCaseVersion();
            this.getDesiredStatusForLabel();
          }
        },
        err => {
          CaseUtils.ReportHTTPError(err, "Loading Case Version Data");
        }
      );
  }

  nonLegacySave(formValue:any) {
    /**  let formValue: any = this.buildNewFormValue();*/
    console.log('nonlegacy save formvalue=', formValue);
    this.caseRestService.postCaseMilestones(formValue)
      .subscribe(
        saveFlag => {
          if (saveFlag) {
             MessageMgr.displaySuccess("Success.");
             this.dialogRef.close({ data: true });
           } else {
             this.handleExceptionError('<font color="red">Control  Milestone Save Failure.</font>');
          }
        },
        err => {
          console.log("Error occured: saveCaseMilestones()" + err.message);
          this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, JSON.stringify(err.message));
          this.dialogRef.close({ data: false });
        }
      );
  }

  buildNewFormValue() {
    let newFormValue = {};
    let serviceId: string = CaseUtils.getServiceDatabaseId();
    let actualDate: string = null;
    let plannedDate: string = null;
    let userIdA: string = "";
    let userNameA: string = "";
    let activityIdA: string = "";
    let userIdP: string = "";
    let userNameP: string = "";
    let activityIdP: string = "";
    if (this.dateLabel == 'Actual Date') {
      actualDate = formatDate(new Date(), 'yyyy-MM-dd', 'en');
      userIdA = this.personUserId;
      userNameA = this.personUserName;
      activityIdA = this.personActivityId;
    } else {
      plannedDate = formatDate(new Date(), 'yyyy-MM-dd', 'en');
      userIdP = this.personUserId;
      userNameP = this.personUserName;
      activityIdP = this.personActivityId;
    }
    newFormValue["serviceId"] = serviceId;
    newFormValue["caseId"] = this.caseId;
    newFormValue["caseVerId"] = this.caseVersionId;
    newFormValue["delMilIds"] = "";
    newFormValue["delRejIds"] = "";
    newFormValue["milestones"] = [
      {
        "new_MILESTONE": "insert",
        "case_MILESTONE_ID": "",
        "milestone_ID": this.data.passingMilestoneId,
        "milestone_TITLE_NM": this.mTitle,
        "milestone_CATEGORY_CD": "",
        "case_VERSION_MILESTONE_DT_A": actualDate,
        "case_VERSION_MILESTONE_DT_P": plannedDate,
        "case_VERSION_MILESTONE_DT_R": null,
        "milestone_OVERRIDE_IN": false,
        "create_DT": "",
        "user_ID_A": userIdA,
        "person_NM_A": userNameA,
        "activity_ID_A": activityIdA,
        "user_ID_P": userIdP,
        "activity_ID_P": activityIdP,
        "person_NM_P": userNameP,
        "user_ID_R": "",
        "activity_ID_R": "",
        "person_NM_R": "",
        "milestone_DESCRIPTION_TX": this.msOption.controls[0].get("txtComments").value,
        "commReasons": this.msOption.controls[0].get("commReasons").value,
      }
    ]
    console.log('****build new formvalue=',newFormValue);
    return newFormValue;
  }

  //DH 10/22 - Proceed to save message
  isSaveConfirmedOnWarningMessages(){
    this.messageData = this.messageService.yesNoMsgData();
    this.messageData.title = 'Confirmation Message';
    this.messageData.message = 'Do you want to continue with changing the case status?'
    this.messageData.msgBtnConfig = MessageBtnConfig.YesNo;
    this.messageService.showMessage(this.messageData)
      .subscribe(result => {
        if (this.messageData.btnClicked == MessageBtnClicked.YesClicked) {
          this.showSpinner.next(true);
          console.log('yes to continue on saving case status');
          this.continueChangeStatusOnWarningSave();
         } else {
          console.log('no save occurs');
          //hardcode the lock session ID for now
          this.caseRestService.deleteMilestoneStatusChange(this.caseVersionDS, '0').subscribe();
        }
      });
  }
  
  //proceed to save data without case validation enforced
  continueChangeStatusOnWarningSave(){
    this.caseVersionDS.desiredStatusTitle = this.dData[1];
    this.caseVersionDS.desiredStatusSequenceNmbr = Number(this.dData[2]);
    this.caseVersionDS.currentStatusSequenceNmbr = Number(this.dData[3]);
    this.caseVersionDS.refreshCd = 9;
    this.caseVersionDS.validateCase = false;
    this.caseVersionDS.caseVersionMilestoneList = this.caseVersionMSList;
    this.caseVersionDS.theCaseId.user_CASE_ID = CaseUtils.unformatUserCaseId(this.userCaseId);
    this.setTheMilestones();
    //hardcode the lock session ID for now
    this.caseRestService.executeRefreshSaveStatusChange(this.caseVersionDS, '0').subscribe(result => {
      this.showSpinner.next(false);
      if (result) {
        MessageMgr.displaySuccessWithTimer('Save was successful', 2000);
        this.dialogRef.close({ data: true });
      }
    },
      err => {
        this.showSpinner.next(false);
        CaseUtils.ReportHTTPError(err, "Save Case Milestone Status");
        this.dialogRef.close({ data: false });
        return false;
      });
  }
   //closing WP004a window per spec when there is a generic error
  handleExceptionError(pHTMLString: string){
    MessageMgr.swalFire({
      icon: 'error',
      html: pHTMLString,
      width: 400,
      focusConfirm: true,
      confirmButtonText: 'OK'
    }).then((result) => {
      if (result.isConfirmed) {
        this.dialogRef.close({ data: false });
      }
    });
  }

  performLegacySave() {
    this.showSpinner.next(true);
    this.prepareDataForSave();
    this.caseRestService.caseValidateForStatusChange(this.caseVersionDS).subscribe(
      result => {
        this.showSpinner.next(false);
        if (!!result && result.wp004aSaveResult ==  DsamsConstants.STATUS_CHANGE_SUCCESSFUL) {
          MessageMgr.displaySuccessWithTimer('Save was successful', 2000);
          this.dialogRef.close({ data: true });
        }
        else if (!!result && result.wp004aSaveResult == DsamsConstants.STATUS_CHANGE_FAIL && result.theErrorMessageList == null) {
          this.handleExceptionError( '<font color="red">System Failure.</font>');
        } 
        else if (!!result && (result.wp004aSaveResult == DsamsConstants.STATUS_CHANGE_FAIL ||
          result.wp004aSaveResult == DsamsConstants.STATUS_CHANGE_OVERRIDE ||
          result.wp004aSaveResult == DsamsConstants.STATUS_CHANGE_WARNING)) {
          let title: string = "Control Milestone Save Validation";
          this.messageService.displayMessageListTc(title, result.theErrorMessageList).pipe(take(1)).subscribe(() => {
            if (result.wp004aSaveResult == DsamsConstants.STATUS_CHANGE_WARNING) {
               this.isSaveConfirmedOnWarningMessages();
            }
            if (result.wp004aSaveResult == DsamsConstants.STATUS_CHANGE_FAIL) {
              this.dialogRef.close({ data: false });
            }
          });
        }
      },
      err => {
        this.showSpinner.next(false);
        CaseUtils.ReportHTTPError(err, "Validate Case Milestone Status");
        this.dialogRef.close({ data: false });
        return false;
      }
    );
  }

  //begin DSAMS-5861 DH 10/22 - Validation checks
  validateComments(pCVEntity: ICaseVersionMilestone): boolean {
    if (CaseUtils.isBlankStr(pCVEntity.case_MILESTONE_COMMENT_TX) && this.isCommentsFieldsRequired) {
      MessageMgr.displayErrorMessage("Comments is required.");
      return false;
    }
    else {
      return this.validateRejectReasonList(pCVEntity.cvmRejectionReasonList);
    }
  }

  validateRejectReasonList(pCVRList: CVMRejectionReason[]): boolean {
    if (!!pCVRList){
      for (let eachCVR of pCVRList) {
        if (CaseUtils.isBlankStr(eachCVR.reject_REASON_ID)) {
          MessageMgr.displayErrorMessage("Common Reasons row initiated using the ADD button has empty field. It must be either deleted or completed. Save operation failed.");
          return false;
        }
      }
    }
    return true;
  }
  //end DSAMS-5861 DH 10/22

  setNullValue(): void {
    this.caseVersionDS.customer_REQUEST_ID = this.getNullValue(this.caseVersionDS.customer_REQUEST_ID);
    this.caseVersionDS.case_VERSION_NUMBER_ID = this.getNullValue(this.caseVersionDS.case_VERSION_NUMBER_ID);
    this.caseVersionDS.customer_ADDRESS_ID = this.getNullValue(this.caseVersionDS.customer_ADDRESS_ID);
    this.caseVersionDS.manpower_TRAVEL_DATA_CD = this.getNullValue(this.caseVersionDS.manpower_TRAVEL_DATA_CD);
    this.caseVersionDS.mildep_USER_ID = this.getNullValue(this.caseVersionDS.mildep_USER_ID);
    this.caseVersionDS.offer_LOA_QY = this.getNullValue(this.caseVersionDS.offer_LOA_QY);
    this.caseVersionDS.previous_CASE_ID = this.getNullValue(this.caseVersionDS.previous_CASE_ID);
    this.caseVersionDS.previous_CASE_VERSION_ID = this.getNullValue(this.caseVersionDS.previous_CASE_VERSION_ID);
    this.caseVersionDS.workflow_ASSIGN_NUMBER_ID = this.getNullValue(this.caseVersionDS.workflow_ASSIGN_NUMBER_ID);
    this.caseVersionDS.xs_CASE_VERSION_ID = this.getNullValue(this.caseVersionDS.xs_CASE_VERSION_ID);
    this.caseVersionDS.theCustomerRequestId.customer_REQUEST_ID = this.getNullValue(this.caseVersionDS.theCustomerRequestId.customer_REQUEST_ID);
    this.caseVersionDS.theCustomerRequestId.eda_QOI_ID = this.getNullValue(this.caseVersionDS.theCustomerRequestId.eda_QOI_ID);
    this.caseVersionDS.theCustomerRequestId.lora_LOR_ID = this.getNullValue(this.caseVersionDS.theCustomerRequestId.lora_LOR_ID);
    this.caseVersionDS.theCustomerRequestId.medical_COUNTERMEASURES_CD = this.getNullValue(this.caseVersionDS.theCustomerRequestId.medical_COUNTERMEASURES_CD);
    this.caseVersionDS.theCaseId.casePersonnelRoleList.forEach(eachrow => eachrow.status = 0);
  }

  getNullValue(pValue: any): any {
    if (pValue == 0) {
      return null;
    } else if (pValue > 0) {
      return pValue;
    } else {
      return pValue;
    }

  }

  setTheMilestones(): void {
    let msList: string[];
    switch (this.data.passingMilestoneId) {
      case DsamsConstants.MILESTONE_MILDEP_CANCEL: {
        msList = this.getMSListMilcan();
         if (msList.length !== 0) {
          this.caseVersionDS.theMilestones = msList;
        } else {
          this.caseVersionDS.theMilestones = [DsamsConstants.MILESTONE_MILDEP_CANCEL];
        }
        break;
      }
      case DsamsConstants.MILESTONE_MILDEP_APPROVAL: {
        msList = this.getMsListMildepApproval();
        this.caseVersionDS.theMilestones = msList;
        break;
      }
      case DsamsConstants.MILESTONE_MILDEP_SIGNATURE: {
        msList = this.getMsListMildepSignature();
        this.caseVersionDS.theMilestones = msList;
        break;
      }
      case DsamsConstants.MILESTONE_CASE_APPROVAL: {
        msList = this.getMsListCaseApproval();
        this.caseVersionDS.theMilestones = msList;
        break;
      }
      case DsamsConstants.MILESTONE_DSCA_REJECT: {
        msList = this.getMsListDscaReject();
        this.caseVersionDS.theMilestones = msList;
        break;
      }
      case DsamsConstants.MILESTONE_DSCA_RETURN: {
        msList = this.getMsListDscaReturn();
        this.caseVersionDS.theMilestones = msList;
        break;
      }
      case DsamsConstants.MILESTONE_STATE_DEPT_APPROVAL: {
        msList = this.getMsListStateApproval();
        this.caseVersionDS.theMilestones = msList;
        break;
      }
      case DsamsConstants.MILESTONE_STATE_DEPT_DISAPPROVAL: {
        msList = this.getMsListStateDisApproval();
        this.caseVersionDS.theMilestones = msList;
        break;
      }
      case DsamsConstants.MILESTONE_STATE_RETURN: {
        msList = this.getMsListStateReturn();
        this.caseVersionDS.theMilestones = msList;
        break;
      }
      default: {
        msList = this.getDefaultMsList();
        this.caseVersionDS.theMilestones = msList;    
      }
    }
  }

  prepareDataForSave() {

    this.setNullValue();
  }

  getUserInfo() {
    this.dsamsRestService.getUserInfo()
      .subscribe(
        data => {
          console.log('userdata=', data);
          this.personUserId = data.userProfile.userId;
          this.personUserName = data.userProfile.firstNm + " " + data.userProfile.lastNm;
          this.personActivityId = data.userProfile.activityId;
        },
        err => {
          console.log("Error occured: getUserInfo()" + err.message);
          this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, JSON.stringify(err.message))
        }
      );
  }

  getMSListMilcan(): string[] {
    let retMSList: string[] = [];
    if (!this.proceedNext()) {
      return retMSList;
    }
    retMSList[0] = MilestoneConstants.MILESTONE_MILDEP_CANCEL;
    let secondMilestoneCreated: boolean = false;
    let thirdMilestoneCreated: boolean = false;

      if (this.isPendingTaskForCancel) {
        secondMilestoneCreated = true;
        if (this.caseVersionDS.theCaseId.security_ASSISTANCE_PROGRAM_CD === MilestoneConstants.SA_PROGRAM_FMS) {
          retMSList[1] = MilestoneConstants.MILESTONE_CASE_RETURNED;
        }
        else if (this.caseVersionDS.theCaseId.security_ASSISTANCE_PROGRAM_CD === MilestoneConstants.SA_PROGRAM_LEASE) {
          retMSList[1] = MilestoneConstants.MILESTONE_LEASE_RETURNED;
        }
      }     

    if (this.caseVersionDS.congress_TRANSMIT_ID !== null && this.caseVersionDS.congressional_NOTIFICATION_IN) {
      if (secondMilestoneCreated) {
        retMSList[2] = MilestoneConstants.MILESTONE_CANCEL_CONGESS;
        thirdMilestoneCreated = true;
      }
      else {
        retMSList[1] = MilestoneConstants.MILESTONE_CANCEL_CONGESS;
        secondMilestoneCreated = true;
      }
    }

    if (this.checkTermOfSaleMNZ()) {
      if (thirdMilestoneCreated) {
        retMSList[3] = MilestoneConstants.MILESTONE_CANCRFIN;
      }
      else if (secondMilestoneCreated) {
        retMSList[2] = MilestoneConstants.MILESTONE_CANCRFIN;
      }
      else {
        retMSList[1] = MilestoneConstants.MILESTONE_CANCRFIN;
      }
    }

    return retMSList;
  }

  getMsListMildepApproval(): string[] {
    let retMSList: string[] = [];
    retMSList[0] = DsamsConstants.MILESTONE_MILDEP_APPROVAL;
    return retMSList;
  }

  getDefaultMsList(): string[] {
    let retMSList: string[] = [];
    if (!CaseUtils.isBlankStr(this.caseVersionDS.caseVersionMilestoneList[0].milestone_ID)) 
       retMSList[0] = this.caseVersionDS.caseVersionMilestoneList[0].milestone_ID;
    return retMSList;
  }

  getMsListMildepSignature(): string[] {
    let retMSList: string[] = [];
    if ((this.caseVersionDS.dsa_APPROVAL_IN)
      && (this.caseVersionDS.state_DEPARTMENT_APPROVAL_IN)
      && (this.caseVersionDS.theCaseId.security_ASSISTANCE_PROGRAM_CD === MilestoneConstants.SA_PROGRAM_LEASE)
      && (this.caseVersionDS.theCaseId.case_USAGE_INDICATOR_CD === MilestoneConstants.CASE_USAGE_REAL)
      && (this.caseVersionDS.case_VERSION_TYPE_CD === MilestoneConstants.CASE_VERSION_TYPE_AMENDMENT
        || this.caseVersionDS.case_VERSION_TYPE_CD === MilestoneConstants.CASE_VERSION_TYPE_BASIC_CASE)) {
      this.caseVersionDS.desiredStatusCd = 'P';
      this.caseVersionDS.desiredStatusTitle = 'Proposed';
      this.caseVersionDS.desiredStatusSequenceNmbr = 20;
      this.caseVersionDS.currentStatusSequenceNmbr = Number(MilestoneConstants.getSeqNumber(this.caseVersionDS.case_VERSION_STATUS_CD));
      retMSList[0] = DsamsConstants.MILESTONE_MILDEP_SIGNATURE;
      retMSList[1] = DsamsConstants.MILESTONE_DSCA_APPROVAL_REQUIRED;
    }
    if ((this.caseVersionDS.theCaseId.security_ASSISTANCE_PROGRAM_CD === MilestoneConstants.SA_PROGRAM_FMS)
      && (this.caseVersionDS.theCaseId.case_USAGE_INDICATOR_CD === MilestoneConstants.CASE_USAGE_PLANNING)
      && (this.caseVersionDS.case_VERSION_TYPE_CD === MilestoneConstants.CASE_VERSION_TYPE_BASIC_CASE)) {
      this.caseVersionDS.desiredStatusCd = 'O';
      this.caseVersionDS.desiredStatusTitle = 'Offered';
      this.caseVersionDS.desiredStatusSequenceNmbr = 30;
      this.caseVersionDS.currentStatusSequenceNmbr = Number(MilestoneConstants.getSeqNumber(this.caseVersionDS.case_VERSION_STATUS_CD));
      retMSList[0] = DsamsConstants.MILESTONE_MILDEP_SIGNATURE;
      retMSList[1] = DsamsConstants.MILESTONE_OFFERED;
    }
    return retMSList;
  }

  getMsListCaseApproval(): string[] {
    let retMSList: string[] = [];
    if ((this.caseVersionDS.dsa_APPROVAL_IN)
      && (!this.caseVersionDS.state_DEPARTMENT_APPROVAL_IN)
      && (this.caseVersionDS.theCaseId.security_ASSISTANCE_PROGRAM_CD === MilestoneConstants.SA_PROGRAM_FMS)
      && (this.caseVersionDS.theCaseId.case_USAGE_INDICATOR_CD === MilestoneConstants.CASE_USAGE_REAL
        || this.caseVersionDS.theCaseId.case_USAGE_INDICATOR_CD === MilestoneConstants.CASE_USAGE_LOI)
      && (this.caseVersionDS.case_VERSION_TYPE_CD === MilestoneConstants.CASE_VERSION_TYPE_AMENDMENT
        || this.caseVersionDS.case_VERSION_TYPE_CD === MilestoneConstants.CASE_VERSION_TYPE_BASIC_CASE)) {
      this.caseVersionDS.desiredStatusCd = 'O';
      this.caseVersionDS.desiredStatusTitle = 'Offered';
      this.caseVersionDS.desiredStatusSequenceNmbr = 30;
      this.caseVersionDS.currentStatusSequenceNmbr = Number(MilestoneConstants.getSeqNumber(this.caseVersionDS.case_VERSION_STATUS_CD));
      retMSList[0] = DsamsConstants.MILESTONE_CASE_APPROVAL;
      retMSList[1] = DsamsConstants.MILESTONE_DSAA_COUNTERSIGNATURE;
      retMSList[2] = DsamsConstants.MILESTONE_OFFERED;
    }
    if ((this.caseVersionDS.dsa_APPROVAL_IN)
      && (this.caseVersionDS.state_DEPARTMENT_APPROVAL_IN)
      && (this.caseVersionDS.theCaseId.security_ASSISTANCE_PROGRAM_CD === MilestoneConstants.SA_PROGRAM_FMS)
      && (this.caseVersionDS.theCaseId.case_USAGE_INDICATOR_CD === MilestoneConstants.CASE_USAGE_REAL
        || this.caseVersionDS.theCaseId.case_USAGE_INDICATOR_CD === MilestoneConstants.CASE_USAGE_LOI)
      && (this.caseVersionDS.case_VERSION_TYPE_CD === MilestoneConstants.CASE_VERSION_TYPE_AMENDMENT
        || this.caseVersionDS.case_VERSION_TYPE_CD === MilestoneConstants.CASE_VERSION_TYPE_BASIC_CASE
        || this.caseVersionDS.case_VERSION_TYPE_CD === MilestoneConstants.CASE_VERSION_TYPE_MODIFICATION)) {
      this.caseVersionDS.desiredStatusCd = 'P';
      this.caseVersionDS.desiredStatusTitle = 'Proposed';
      this.caseVersionDS.desiredStatusSequenceNmbr = 20;
      this.caseVersionDS.currentStatusSequenceNmbr = Number(MilestoneConstants.getSeqNumber(this.caseVersionDS.case_VERSION_STATUS_CD));
      retMSList[0] = DsamsConstants.MILESTONE_CASE_APPROVAL;
      retMSList[1] = DsamsConstants.MILESTONE_STATE_LIST;
    }
    if ((this.caseVersionDS.dsa_APPROVAL_IN)
      && (!this.caseVersionDS.state_DEPARTMENT_APPROVAL_IN)
      && (this.caseVersionDS.theCaseId.security_ASSISTANCE_PROGRAM_CD === MilestoneConstants.SA_PROGRAM_FMS)
      && (this.caseVersionDS.theCaseId.case_USAGE_INDICATOR_CD === MilestoneConstants.CASE_USAGE_REAL)
      && (this.caseVersionDS.case_VERSION_TYPE_CD === MilestoneConstants.CASE_VERSION_TYPE_MODIFICATION)) {
      this.caseVersionDS.desiredStatusCd = 'I';
      this.caseVersionDS.desiredStatusTitle = 'Implemented';
      this.caseVersionDS.desiredStatusSequenceNmbr = 50;
      this.caseVersionDS.currentStatusSequenceNmbr = Number(MilestoneConstants.getSeqNumber(this.caseVersionDS.case_VERSION_STATUS_CD));
      retMSList[0] = DsamsConstants.MILESTONE_CASE_APPROVAL;
      retMSList[1] = DsamsConstants.MILESTONE_DSAA_COUNTERSIGNATURE;
      retMSList[2] = DsamsConstants.MILESTONE_OFFERED;
      // if (TheClientMgr_proxy.getInstance().qq_getTheMilestoneMgr().checkIfCaseVersionMilestoneExists(this.getTheCaseVersion().getCASE_ID().getValue(), this.getTheCaseVersion().getCASE_VERSION_ID().getValue(), mil.dsca.dsams.constants.Constants.MILESTONE_STATE_LIST, false, "P", (DSAMSInteger)null, (DSAMSDate)null, false, false)) {
      if (this.checkIfCaseVersionMilestoneExists()) {
        retMSList[3] = DsamsConstants.MILESTONE_STATE_LIST;
      }
    }
    return retMSList;
  }

  getMsListDscaReject(): string[] {
    let retMSList: string[] = [];
    if ((this.caseVersionDS.dsa_APPROVAL_IN)
      && (this.caseVersionDS.theCaseId.security_ASSISTANCE_PROGRAM_CD === MilestoneConstants.SA_PROGRAM_LEASE)
      && (this.caseVersionDS.theCaseId.case_USAGE_INDICATOR_CD === MilestoneConstants.CASE_USAGE_REAL)
      && (this.caseVersionDS.case_VERSION_TYPE_CD === MilestoneConstants.CASE_VERSION_TYPE_AMENDMENT
        || this.caseVersionDS.case_VERSION_TYPE_CD === MilestoneConstants.CASE_VERSION_TYPE_BASIC_CASE)) {
      retMSList[0] = DsamsConstants.MILESTONE_DSCA_REJECT;
      // Only if a planned state list milestone exsists create the 2 additional milestone
      // if (TheClientMgr_proxy.getInstance().qq_getTheMilestoneMgr().checkIfCaseVersionMilestoneExists(this.getTheCaseVersion().getCASE_ID().getValue(), this.getTheCaseVersion().getCASE_VERSION_ID().getValue(), mil.dsca.dsams.constants.Constants.MILESTONE_STATE_LIST, false, "P", (DSAMSInteger)null, (DSAMSDate)null, false, false)) {
      if (this.checkIfCaseVersionMilestoneExists()) {
        retMSList[1] = DsamsConstants.MILESTONE_STATE_LIST;
        retMSList[2] = DsamsConstants.MILESTONE_STATE_DEPT_DISAPPROVAL;
      }
    }
    return retMSList;
  }

  getMsListDscaReturn(): string[] {
    let retMSList: string[] = [];
    if ((this.caseVersionDS.theCaseId.security_ASSISTANCE_PROGRAM_CD === MilestoneConstants.SA_PROGRAM_LEASE)
      && (this.caseVersionDS.theCaseId.case_USAGE_INDICATOR_CD === MilestoneConstants.CASE_USAGE_REAL)
      && (this.caseVersionDS.case_VERSION_TYPE_CD === MilestoneConstants.CASE_VERSION_TYPE_AMENDMENT
        || this.caseVersionDS.case_VERSION_TYPE_CD === MilestoneConstants.CASE_VERSION_TYPE_BASIC_CASE)) {
      retMSList[0] = DsamsConstants.MILESTONE_DSCA_RETURN;
      // Only if a planned state list milestone exsists create the 2 additional milestone
      // if (TheClientMgr_proxy.getInstance().qq_getTheMilestoneMgr().checkIfCaseVersionMilestoneExists(this.getTheCaseVersion().getCASE_ID().getValue(), this.getTheCaseVersion().getCASE_VERSION_ID().getValue(), mil.dsca.dsams.constants.Constants.MILESTONE_STATE_LIST, false, "P", (DSAMSInteger)null, (DSAMSDate)null, false, false)) {
      if (this.checkIfCaseVersionMilestoneExists()) {
        retMSList[1] = DsamsConstants.MILESTONE_STATE_LIST;
        retMSList[2] = DsamsConstants.MILESTONE_STATE_DEPT_DISAPPROVAL;
      }
    }
    return retMSList;
  }

  getMsListStateApproval(): string[] {
    let retMSList: string[] = [];
    if ((this.caseVersionDS.dsa_APPROVAL_IN)
      && (this.caseVersionDS.state_DEPARTMENT_APPROVAL_IN)
      && (this.caseVersionDS.theCaseId.security_ASSISTANCE_PROGRAM_CD === MilestoneConstants.SA_PROGRAM_FMS)
      && (this.caseVersionDS.theCaseId.case_USAGE_INDICATOR_CD === MilestoneConstants.CASE_USAGE_REAL
        || this.caseVersionDS.theCaseId.case_USAGE_INDICATOR_CD === MilestoneConstants.CASE_USAGE_LOI)
      && (this.caseVersionDS.case_VERSION_TYPE_CD === MilestoneConstants.CASE_VERSION_TYPE_AMENDMENT
        || this.caseVersionDS.case_VERSION_TYPE_CD === MilestoneConstants.CASE_VERSION_TYPE_BASIC_CASE)) {
      this.caseVersionDS.desiredStatusCd = 'O';
      this.caseVersionDS.desiredStatusTitle = 'Offered';
      this.caseVersionDS.desiredStatusSequenceNmbr = 30;
      this.caseVersionDS.currentStatusSequenceNmbr = Number(MilestoneConstants.getSeqNumber(this.caseVersionDS.case_VERSION_STATUS_CD));
      retMSList[0] = DsamsConstants.MILESTONE_DSAA_COUNTERSIGNATURE;
      retMSList[1] = DsamsConstants.MILESTONE_STATE_DEPT_APPROVAL;
      retMSList[2] = DsamsConstants.MILESTONE_STATE_LIST;
      retMSList[3] = DsamsConstants.MILESTONE_OFFERED;
    }
    if ((this.caseVersionDS.dsa_APPROVAL_IN)
      && (this.caseVersionDS.state_DEPARTMENT_APPROVAL_IN)
      && (this.caseVersionDS.theCaseId.security_ASSISTANCE_PROGRAM_CD === MilestoneConstants.SA_PROGRAM_FMS)
      && (this.caseVersionDS.theCaseId.case_USAGE_INDICATOR_CD === MilestoneConstants.CASE_USAGE_REAL)
      && (this.caseVersionDS.case_VERSION_TYPE_CD === MilestoneConstants.CASE_VERSION_TYPE_MODIFICATION)) {
      this.caseVersionDS.desiredStatusCd = 'I';
      this.caseVersionDS.desiredStatusTitle = 'Implemented';
      this.caseVersionDS.desiredStatusSequenceNmbr = 50;
      this.caseVersionDS.currentStatusSequenceNmbr = Number(MilestoneConstants.getSeqNumber(this.caseVersionDS.case_VERSION_STATUS_CD));
      retMSList[0] = DsamsConstants.MILESTONE_DSAA_COUNTERSIGNATURE;
      retMSList[1] = DsamsConstants.MILESTONE_STATE_DEPT_APPROVAL;
      retMSList[2] = DsamsConstants.MILESTONE_STATE_LIST;
      retMSList[3] = DsamsConstants.MILESTONE_OFFERED;
    }
    return retMSList;
  }

  getMsListStateDisApproval(): string[] {
    let retMSList: string[] = [];
    if ((this.caseVersionDS.theCaseId.security_ASSISTANCE_PROGRAM_CD === MilestoneConstants.SA_PROGRAM_FMS
      || this.caseVersionDS.theCaseId.case_USAGE_INDICATOR_CD === MilestoneConstants.CASE_USAGE_LOI)
      && (this.caseVersionDS.theCaseId.case_USAGE_INDICATOR_CD === MilestoneConstants.CASE_USAGE_REAL)
      && (this.caseVersionDS.case_VERSION_TYPE_CD === MilestoneConstants.CASE_VERSION_TYPE_AMENDMENT
        || this.caseVersionDS.case_VERSION_TYPE_CD === MilestoneConstants.CASE_VERSION_TYPE_BASIC_CASE
        || this.caseVersionDS.case_VERSION_TYPE_CD === MilestoneConstants.CASE_VERSION_TYPE_MODIFICATION)) {
      retMSList[0] = DsamsConstants.MILESTONE_STATE_DEPT_DISAPPROVAL;
      retMSList[1] = DsamsConstants.MILESTONE_STATE_LIST;
      retMSList[2] = "Do Nothing so create actual date";
    }
    return retMSList;
  }

  getMsListStateReturn(): string[] {
    let retMSList: string[] = [];
    if ((this.caseVersionDS.theCaseId.security_ASSISTANCE_PROGRAM_CD === MilestoneConstants.SA_PROGRAM_FMS
      || this.caseVersionDS.theCaseId.case_USAGE_INDICATOR_CD === MilestoneConstants.CASE_USAGE_LOI)
      && (this.caseVersionDS.theCaseId.case_USAGE_INDICATOR_CD === MilestoneConstants.CASE_USAGE_REAL)
      && (this.caseVersionDS.case_VERSION_TYPE_CD === MilestoneConstants.CASE_VERSION_TYPE_AMENDMENT
        || this.caseVersionDS.case_VERSION_TYPE_CD === MilestoneConstants.CASE_VERSION_TYPE_BASIC_CASE
        || this.caseVersionDS.case_VERSION_TYPE_CD === MilestoneConstants.CASE_VERSION_TYPE_MODIFICATION)) {
      retMSList[0] = DsamsConstants.MILESTONE_STATE_DEPT_DISAPPROVAL;
      retMSList[1] = DsamsConstants.MILESTONE_STATE_LIST;
      retMSList[2] = "Do Nothing so create actual date";
      retMSList[3] = DsamsConstants.MILESTONE_STATE_RETURN;
    }
    return retMSList;
  }

  checkTermOfSaleMNZ(): boolean {
    let aCounter = 0;
    if (this.caseVersionDS.caseSaleTermList.length == 0) {
      return false;
    }
    for (let ii = 0; ii < this.caseVersionDS.caseSaleTermList.length; ii++) {
      if (this.caseVersionDS.caseSaleTermList[ii].sale_TERM_ID == MilestoneConstants.SALE_TERM_FMS_MAP ||
        this.caseVersionDS.caseSaleTermList[ii].sale_TERM_ID == MilestoneConstants.SALE_TERM_FMS_CREDIT_NONREPAYABLE ||
        this.caseVersionDS.caseSaleTermList[ii].sale_TERM_ID == MilestoneConstants.SALE_TERM_FMS_CREDIT) {
        return true;
      }
    }
    return false;
  }

  // needs backend legacy call
  checkIfPendingTasksforCancel(): boolean {
    let retdata: boolean = false;
    this.caseRestService.checkIfPendingTasksforCancel(this.caseVersionId.toString(), this.caseVersionDS.theCaseId.security_ASSISTANCE_PROGRAM_CD)
      .subscribe(
        tdata => {
          if (tdata) {
            retdata = tdata;
          }
        },
        err => {
          CaseUtils.ReportHTTPError(err, "Getting checkIfPendingTasksforCancel");
        }
      );
    return retdata;
  }

  //begin DSAMS-5961 DH 10/03: added this pending task workflow check
  isPendingTaskForCancel: boolean = false;
  isTherePendingTaskForCancel(){
    this.caseRestService.checkIfPendingTasksforCancel(this.caseVersionId.toString(), this.caseVersionDS.theCaseId.security_ASSISTANCE_PROGRAM_CD)
    .subscribe(result => {
      this.isPendingTaskForCancel = result;
    });
  }

  //DH 10/03: added this check For Related Case Version 
  doesRelatedCaseVersionExist: boolean = false;
  checkForRelatedCaseVersion(){
    this.caseRestService.checkForRelatedCaseVersion(this.caseId.toString(),this.caseVersionId.toString())
    .subscribe(
      result => {
        console.log('Related Case Version Exists=',result)
        this.doesRelatedCaseVersionExist = result;
        });
  }
  //end DSAMS-5961 DH 10/03

  proceedNext(): boolean {
    let firstIf: boolean = false;
    let secondIf: boolean = false;
    let thirdIf: boolean = false

    if (this.caseVersionDS.theCaseId.security_ASSISTANCE_PROGRAM_CD === MilestoneConstants.SA_PROGRAM_FMS
      || this.caseVersionDS.theCaseId.security_ASSISTANCE_PROGRAM_CD === MilestoneConstants.SA_PROGRAM_GRANT
      || this.caseVersionDS.theCaseId.security_ASSISTANCE_PROGRAM_CD === MilestoneConstants.SA_PROGRAM_LEASE) {
      firstIf = true;
    }

    if (this.caseVersionDS.theCaseId.case_USAGE_INDICATOR_CD === MilestoneConstants.CASE_USAGE_REAL
      || this.caseVersionDS.theCaseId.case_USAGE_INDICATOR_CD === MilestoneConstants.CASE_USAGE_LOI
      || this.caseVersionDS.theCaseId.case_USAGE_INDICATOR_CD === MilestoneConstants.CASE_USAGE_PLANNING
      || this.caseVersionDS.theCaseId.case_USAGE_INDICATOR_CD === MilestoneConstants.CASE_USAGE_MODEL) {
      secondIf = true;
    }

    if (this.caseVersionDS.case_VERSION_TYPE_CD === MilestoneConstants.CASE_VERSION_TYPE_AMENDMENT
      || this.caseVersionDS.case_VERSION_TYPE_CD === MilestoneConstants.CASE_VERSION_TYPE_BASIC_CASE
      || this.caseVersionDS.case_VERSION_TYPE_CD === MilestoneConstants.CASE_VERSION_TYPE_REVISION
      || this.caseVersionDS.case_VERSION_TYPE_CD === MilestoneConstants.CASE_VERSION_TYPE_MODIFICATION) {
      thirdIf = true;
    }
    if (firstIf && secondIf && thirdIf) {
      return true;
    } else {
      return false;
    }
  }

  checkIfCaseVersionMilestoneExists(): boolean {
    let retdata: boolean = false;
    this.caseRestService.checkIfCaseVersionMilestoneExists(this.caseId.toString(), this.caseVersionId.toString(), MilestoneConstants.MILESTONE_STATE_LIST, false, 'P')
      .subscribe(
        cdata => {
          if (cdata) {
            retdata = cdata;
          }
        },
        err => {
          CaseUtils.ReportHTTPError(err, "Getting checkIfCaseVersionMilestoneExists");
        }
      );
    return retdata;
  }

}



