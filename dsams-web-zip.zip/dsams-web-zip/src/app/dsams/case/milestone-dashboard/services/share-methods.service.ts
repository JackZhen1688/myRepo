import { Injectable } from '@angular/core';
import { formatDate } from '@angular/common';
import { MatSnackBar } from '@angular/material/snack-bar';
import { DsamsConstants } from './../../../dsams.constants';
import { DsamsMethodsService } from './../../../services/dsams-methods.service';
import { CaseRestfulService } from './../../services/case-restful.service';

@Injectable({
  providedIn: 'root'
})
export class ShareMethodsService {

  durationInSeconds = 5;

  emptyMilestoneFlage: boolean;
  invalidActPlanDate  = new Map();
  invalidRevPlannDate = new Map();
  invalidPrerequistes = new Map();
  invalidFormValues   = new Map();
  prereWithActualDate = new Map();


  constructor(private _snackBar: MatSnackBar,
              private caseRestService: CaseRestfulService,
              private dsamsMethodsService: DsamsMethodsService) { 

  }

  saveMilestone(formValue: any) {
    if (this.validateFormValues(formValue))
        this.saveCaseMilestones(formValue);
  }

  saveCaseMilestones(formValue: any) {
    this.caseRestService.postCaseMilestones(formValue)
    .subscribe(
      saveFlag => {
        if (saveFlag) {
            this._snackBar.open("Case milestone data has been saved successfully!", 'close',  {
              duration: this.durationInSeconds * 1000,
              panelClass: ['mat-toolbar', 'mat-primary']  
            });
        } else {
            this._snackBar.open("Case milestone data saved failure!", 'close',  {
              duration: this.durationInSeconds * 1000,
              panelClass: ['mat-toolbar', 'mat-warn']     
            });
       }
       this.refreshPage();
      },
      err => {
        console.log("Error occured: saveCaseMilestones()"+err.message);
        this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, JSON.stringify(err.message))
      }
    );    
  }

  refreshPage() {
    this.invalidActPlanDate.clear();
    this.invalidRevPlannDate.clear();
    this.invalidPrerequistes.clear();
    this.prereWithActualDate.clear();
    this.invalidFormValues.clear();
  }

  validateFormValues(formValue: any) {
    this.checkFormValues(formValue);
    if (this.emptyMilestoneFlage) {
        this.dsamsMethodsService.openMegsDialog(DsamsConstants.diaWidth, "The milestone Id & milestone name are missing.");
        return false;
    } else {
        if (this.invalidActPlanDate.size > 0 || this.invalidRevPlannDate.size > 0) {
            let invalidDates = new Map([...this.invalidActPlanDate.entries(), ...this.invalidRevPlannDate.entries()]);
            this.dsamsMethodsService.openMegsListDialog(DsamsConstants.diaLsWidth, invalidDates);
            return false;
        } else {
            if (this.invalidActPlanDate.size > 0 || this.invalidRevPlannDate.size > 0) {
                let invalidDates = new Map([...this.invalidActPlanDate.entries(), ...this.invalidRevPlannDate.entries()]);
                this.dsamsMethodsService.openMegsListDialog(DsamsConstants.diaLsWidth, invalidDates);
                return false;
            } else {
                let invalidPrereqMessages =  new Map([...this.invalidPrerequistesMegs(formValue).entries(), ...this.prereWithActualDateMegs(formValue).entries()]);
                if (invalidPrereqMessages.size > 0) {
                    this.dsamsMethodsService.openMegsListDialog(DsamsConstants.diaLsWidth, invalidPrereqMessages);
                    return false;
                }
            }
        }
    }
    return true;
  }

  invalidPrerequistesMegs(formValue:any) {
    let invalidPrerequistesNew  = new Map(); 
    if (this.invalidPrerequistes.size > 0) {
        let jsonFormValue = JSON.parse(JSON.stringify(formValue));
        jsonFormValue.milestones.forEach(milestone => {
          if (milestone.new_MILESTONE === 'insert' || milestone.new_MILESTONE === 'update') {
            for (let data of this.invalidPrerequistes.values()) {
                 invalidPrerequistesNew = this.addPrerequistesMegs(milestone, data, invalidPrerequistesNew);
            }
          }
        });
    }
    return invalidPrerequistesNew;
  }

  addPrerequistesMegs(milestone:any, data:any, invalidPrerequistesTmp:any) 
  {
    if (milestone.milestone_ID === data.milestone_ID) {
        if (milestone.case_VERSION_MILESTONE_DT_A != null) 
            invalidPrerequistesTmp.set(data.milestone_ID, "The "+data.prerequisite_MILESTONE_ID+" milestone with an actual date must occur prior to "+data.milestone_ID+".");
    }
    return invalidPrerequistesTmp;
  }

  prereWithActualDateMegs(formValue:any) {
    let prereWithActualDateNew  = new Map(); 
    if (this.prereWithActualDate.size > 0) {
        let jsonFormValue = JSON.parse(JSON.stringify(formValue));
        jsonFormValue.milestones.forEach(milestone => {
          if (milestone.new_MILESTONE === 'insert' || milestone.new_MILESTONE === 'update') {
            for (let data of this.prereWithActualDate.values()) {
                 prereWithActualDateNew = this.addPrereActualDateMegs(milestone, data, prereWithActualDateNew);
            }  
          }
        });
    }
    return prereWithActualDateNew;
  }

  addPrereActualDateMegs(milestone:any, data:any, prereWithActualDateTmp:any) 
  {
    if (milestone.case_VERSION_MILESTONE_DT_A != null) {
        let prereqDate = formatDate(new Date(data.actualDATE).valueOf(), 'yyyy-MM-dd', 'en');
        let actualDate = formatDate(new Date(milestone.case_VERSION_MILESTONE_DT_A).valueOf(), 'yyyy-MM-dd', 'en');
        console.log(data.milestone_ID+"==>pre"+prereqDate+"==act"+actualDate)
        if (prereqDate > actualDate)
            prereWithActualDateTmp.set(data.milestone_ID, "The "+data.prerequisite_MILESTONE_ID+" milestone with an actual date must occur prior to "+data.milestone_ID+".");
    }
    return prereWithActualDateTmp;
  }

  checkFormValues(formValue) 
  {
    var minVerMilestoneDate = formatDate('1899-01-01', 'yyyy-MM-dd', 'en');
    var maxVerMilestoneDate = formatDate('2999-12-31', 'yyyy-MM-dd', 'en');
    let jsonFormValue = JSON.parse(JSON.stringify(formValue));
    jsonFormValue.milestones.forEach(milestone => {
      if (milestone.new_MILESTONE === 'insert' && milestone.milestone_ID ==='') {
          this.emptyMilestoneFlage = true;
      } else {
          this.checkActualandPlannedDate(milestone, minVerMilestoneDate, maxVerMilestoneDate);  
          this.checkRevisedPlannedDate(milestone, minVerMilestoneDate, maxVerMilestoneDate);
      }
    });
  }

  checkActualandPlannedDate(milestone:any, minVerDate:any, maxVerDate:any) 
  {
    let invalidMessages:string = '';
    if (!milestone.case_VERSION_MILESTONE_DT_A && !milestone.case_VERSION_MILESTONE_DT_P) {
         invalidMessages = " mandatory fields Actual Date and/or Planned Date are missing.";
    } else {
         if (this.checkActualDate(milestone, minVerDate, maxVerDate) !='')
             invalidMessages = invalidMessages +"&"+ this.checkActualDate(milestone, minVerDate, maxVerDate);
 
         if (this.checkPlannedDate(milestone, minVerDate, maxVerDate) !='')
             invalidMessages = invalidMessages +"&"+ this.checkPlannedDate(milestone, minVerDate, maxVerDate);
    }
    if (invalidMessages !='')
        this.invalidActPlanDate.set(milestone.milestone_ID, "The "+milestone.milestone_ID+" milestone "+invalidMessages.substring(1));
  }

  checkActualDate(milestone:any, minVerDate:any, maxVerDate:any) 
  {
    let invalidMessages:string = '';
    const currentDate = formatDate(new Date(), 'yyyy-MM-dd', 'en');
    if (milestone.case_VERSION_MILESTONE_DT_A !=null) {
        if (formatDate(new Date(milestone.case_VERSION_MILESTONE_DT_A).valueOf(), 'yyyy-MM-dd', 'en') < minVerDate ||
            formatDate(new Date(milestone.case_VERSION_MILESTONE_DT_A).valueOf(), 'yyyy-MM-dd', 'en') > maxVerDate) 
        {   
            invalidMessages = " Actual date invalid. ";
        } else {
            if (currentDate < formatDate(new Date(milestone.case_VERSION_MILESTONE_DT_A).valueOf(), 'yyyy-MM-dd', 'en')) {
                invalidMessages = " Actual date cannot be greater than the current date. ";
            } 
        }
    }
    return invalidMessages;
  }

  checkPlannedDate(milestone:any, minVerDate:any, maxVerDate:any) 
  {
    let invalidMessages:string = '';
    if (milestone.case_VERSION_MILESTONE_DT_P !=null) { 
        if (formatDate(new Date(milestone.case_VERSION_MILESTONE_DT_P).valueOf(), 'yyyy-MM-dd', 'en') < minVerDate ||
            formatDate(new Date(milestone.case_VERSION_MILESTONE_DT_P).valueOf(), 'yyyy-MM-dd', 'en') > maxVerDate) 
        {
            invalidMessages = " Planned date invalid. ";
        }
    }
    return invalidMessages;
  }

  checkRevisedPlannedDate(milestone:any, minVerDate:any, maxVerDate:any) 
  {
    let invalidMessages:string = '';
    if (milestone.case_VERSION_MILESTONE_DT_R !=null) {
        if (formatDate(new Date(milestone.case_VERSION_MILESTONE_DT_R).valueOf(), 'yyyy-MM-dd', 'en') < minVerDate ||
            formatDate(new Date(milestone.case_VERSION_MILESTONE_DT_R).valueOf(), 'yyyy-MM-dd', 'en') > maxVerDate) 
        {
            invalidMessages = " Revised planned date invalid. ";
        } else {
            let custReceiptDt = formatDate(new Date(milestone.customer_REQUEST_RECEIPT_DT).valueOf(), 'yyyy-MM-dd', 'en');
            let revplannedDt  = formatDate(new Date(milestone.case_VERSION_MILESTONE_DT_R).valueOf(), 'yyyy-MM-dd', 'en') ;
            console.log("txtCustReceiptDt=="+custReceiptDt)
            if (revplannedDt < custReceiptDt) {
                invalidMessages = invalidMessages +"&"+ " The Revised Planned date cannot be less than the Customer request receipt date: "+custReceiptDt+". ";
            } 
        }
    }
    if (invalidMessages !='')
        this.invalidRevPlannDate.set(milestone.milestone_ID, "The "+milestone.milestone_ID+" milestone "+invalidMessages.substring(1));
  }



}
