import { TestBed } from '@angular/core/testing';

import { ShareMethodsService } from './share-methods.service';

describe('ShareMethodsService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ShareMethodsService = TestBed.get(ShareMethodsService);
    expect(service).toBeTruthy();
  });
});
