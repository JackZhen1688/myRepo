/* FR7 From Confluence */
export class MilestoneConstants {
    public static getMilestoneData(pId: string): string {
        let retData: string;
        retData = this.getMData1(pId);
        if (retData === '') {
            retData = this.getMData2(pId);
        }
        if (retData === '') {
            retData = this.getMData3(pId);
        }
        return retData;
    }
    public static getMData1(pData: string): string {
        switch (pData) {
            case 'BYPASCONNO': {
                return 'Bypass Cong. Notif. Process' + '|' + 'N' + '|' + 'Saving this milestone will bypass Congressional Notification validations.'
                    + '|' + '0' + '|' + '0';
            }
            case 'FOUOAPPROV': {
                return 'FOUO Approved' + '|' + 'N' + '|' + 'Saving this milestone will approve case For Official Use Only.'
                    + '|' + '0' + '|' + '0';
            }
            case 'DISAPFOUO': {
                return 'FOUO Disapproved' + '|' + 'N' + '|' + 'Saving this milestone will disapprove case For Official Use Only.'
                    + '|' + '0' + '|' + '0';
            }
            case 'DSTANOT': {
                return 'Statutory Notification to DSCA' + '|' + 'N' + '|' + 'Saving this will create the Statutory Notification Submitted by MILDEP to DSCA.'
                    + '|' + '0' + '|' + '0';
            }
            case 'SSTANOT': {
                return 'Statutory Notif to State Dept' + '|' + 'N' + '|' + 'Saving this will create DSCA to State Stat Congressional Notification milestone.'
                    + '|' + '0' + '|' + '0';
            }
            case 'SSTANOTAP': {
                return 'Statutory Approval from State' + '|' + 'N' + '|' + 'Saving this will create the Stat Congressional Notification State Approval milestone.'
                    + '|' + '0' + '|' + '0';
            }
            case 'SSTANOTRJ': {
                return 'Statutory Rejection from State' + '|' + 'N' + '|' + 'Saving this will create the Stat Congressional Notification State Disapproval milestone.'
                    + '|' + '0' + '|' + '0';
            }
            case 'DFCORCAN': {
                return 'DFAS Coordination Cancellation' + '|' + 'N' + '|' + 'Saving this will milestone will denote DFAS coordination.'
                    + '|' + '0' + '|' + '0';
            }
            case 'DCSGN': {
                return 'DSCA Countersignature' + '|' + 'Y' + '|' + ''
                    + '|' + '0' + '|' + '0';
            }
            case 'DHOLD': {
                return 'DSCA Hold Placed' + '|' + 'N' + '|' + 'Saving this milestone will put the document on hold.'
                    + '|' + '0' + '|' + '1';
            }
            case 'DHOLDREM': {
                return 'DSCA Hold Removed' + '|' + 'N' + '|' + 'Saving this milestone will eliminate the hold from the document.'
                    + '|' + '0' + '|' + '1';
            }
            case 'DSCAEMRGY': {
                return 'DSCA Emergy Imp Authority' + '|' + 'N' + '|' + 'Saving this milestone will authorize emergency implementation of the document.'
                    + '|' + '0' + '|' + '0';
            }
            case 'DREACT': {
                return 'DSCA Reactivation Authority' + '|' + 'N' + '|' + 'Saving this milestone will authorize reactivation of the document.'
                    + '|' + '0' + '|' + '0';
            }
            case 'DCSGNRJ': {
                return 'DSCA Rejection' + '|' + 'Y' + '|' + ''
                    + '|' + '0' + '|' + '1';
            }
            case 'DDOCRTN': {
                return 'DSCA Document Return' + '|' + 'Y' + '|' + ''
                    + '|' + '0' + '|' + '1';
            }
            default: {
                return '';
            }
        }
    }
    public static getMData2(pData2: string): string {
        switch (pData2) {
            case 'MILCAN': {
                return 'MilDep Cancellation' + '|' + 'Y' + '|' + ''
                    + '|' + '0' + '|' + '0';
            }
            case 'CLOSE': {
                return 'Case Closure' + '|' + 'Y' + '|' + ''
                    + '|' + '0' + '|' + '0';
            }
            case 'DOCMNTSENT': {
                return 'Document Sent from IA' + '|' + 'N' + '|' + 'Saving this milestone will create the Document to Customer milestone.'
                    + '|' + '0' + '|' + '0';
            }
            case 'MILIMP': {
                return 'MilDep Implementation' + '|' + 'Y' + '|' + ''
                    + '|' + '0' + '|' + '0';
            }
            case 'HOLD': {
                return 'Hold Placed' + '|' + 'N' + '|' + 'Saving this milestone will put the document on hold.'
                    + '|' + '0' + '|' + '1';
            }
            case 'HOLDREM': {
                return 'Hold Removed' + '|' + 'N' + '|' + 'Saving this milestone will eliminate the hold from the document.'
                    + '|' + '0' + '|' + '1';
            }
            case 'MILAP': {
                return 'MilDep Approval' + '|' + 'N/Y*' + '|' + ''
                    + '|' + '0' + '|' + '0';
            }
            case 'OFFERACC': {
                return 'Offer Accepted by Customer' + '|' + 'Y' + '|' + ''
                    + '|' + '0' + '|' + '0';
            }
            case 'MILREACT': {
                return 'MilDep Reactivation' + '|' + 'Y' + '|' + ''
                    + '|' + '0' + '|' + '0';
            }
            case 'REMSUSPEND': {
                return 'Remove Suspend' + '|' + 'N' + '|' + 'Saving this milestone will eliminate the suspension from the document.'
                    + '|' + '0' + '|' + '1';
            }
            case 'REOPEN': {
                return 'Reopening a Closed Case' + '|' + 'Y' + '|' + ''
                    + '|' + '0' + '|' + '1';
            }
            case 'RESTATE': {
                return 'Update Offer/Restatement' + '|' + 'Y' + '|' + ''
                    + '|' + '0' + '|' + '0';
            }
            case 'MILSGN': {
                return 'MilDep Signature' + '|' + 'N/Y*' + '|' + 'Saving this milestone on FMS cases will post the MILDEP Signature.'
                    + '|' + '0' + '|' + '0';
            }
            case 'SLOADCOMP': {
                return 'Standard LOAD Complete' + '|' + 'N' + '|' + 'Saving this milestone will create the Standard Load Complete milestone.'
                    + '|' + '0' + '|' + '0';
            }
            case 'SLOADSTART': {
                return 'Standard LOAD Start' + '|' + 'N' + '|' + 'Saving this milestone will create the Standard Load Start milestone.'
                    + '|' + '0' + '|' + '0';
            }
            case 'SUSPEND': {
                return 'Suspend' + '|' + 'N' + '|' + 'Saving this milestone will suspend the document.'
                    + '|' + '0' + '|' + '1';
            }
            case 'IPODOCRTN': {
                return 'IPO Document Return' + '|' + 'N' + '|' + 'Saving this milestone will specify the reason(s) for returning the document to the MILDEP.'
                    + '|' + '1' + '|' + '0';
            }
            case 'CDEF': {
                return 'Case Dev Extenuating Factors' + '|' + 'N' + '|' + 'Saving this milestone will specify the extenuating factors for the document.'
                    + '|' + '1' + '|' + '1';
            }
            case 'STAP': {
                return 'State Department Approval' + '|' + 'Y' + '|' + ''
                    + '|' + '0' + '|' + '0';
            }
            case 'STDAP': {
                return 'State Department Disapproval' + '|' + 'Y' + '|' + ''
                    + '|' + '0' + '|' + '0';
            }
            case 'STLST': {
                return 'State Department List' + '|' + 'N' + '|' + 'Saving this milestone will create the State List milestone.'
                    + '|' + '0' + '|' + '0';
            }
            case 'SDOCRTN': {
                return "Doc Ret'd to W Status (State)" + '|' + 'Y' + '|' + ''
                    + '|' + '0' + '|' + '0';
            }
            case 'SHOLD': {
                return 'State Dept Case Prep Hold' + '|' + 'N' + '|' + 'Saving this milestone will put the document on hold.'
                    + '|' + '0' + '|' + '1';
            }
            case 'SHOLDREM': {
                return 'State Dept Hold Removed' + '|' + 'N' + '|' + 'Saving this milestone will eliminate the hold from the document.'
                    + '|' + '0' + '|' + '1';
            }
            case 'SE-SUP': {
                return '' + '|' + 'N' + '|' + 'Saving this milestone will prevent all actions except billing.'
                    + '|' + '0' + '|' + '0';
            }

            default: {
                return '';
            }
        }
    }
    public static getMData3(pData3: string): string {
        switch (pData3) {
            case 'SE-SUPREM': {
                return '' + '|' + 'N' + '|' + 'Saving this milestone will allow all processes.'
                    + '|' + '0' + '|' + '0';
            }
            case 'WDOCRTN': {
                return 'Document Returned to W Status' + '|' + 'Y' + '|' + ''
                    + '|' + '1' + '|' + '1';
            }
            case 'WRITECOMP': {
                return 'CWD Writing Completed' + '|' + 'Y' + '|' + ''
                    + '|' + '0' + '|' + '0';
            }
            case 'FUTCORREQW': {
                return 'Future Correction Required - W' + '|' + 'N' + '|' + 'Saving this milestone will specify the corrections required on a future document.'
                    + '|' + '1' + '|' + '1';
            }
            case 'CWDDOCRTN': {
                return 'Document Returned to D Status' + '|' + 'Y' + '|' + ''
                    + '|' + '1' + '|' + '1';
            }
            case 'CWDAPPRV': {
                return 'CWD Approval' + '|' + 'Y' + '|' + ''
                    + '|' + '0' + '|' + '0';
            }
            case 'FUTCORREQR': {
                return 'Future Correction Required - R' + '|' + 'N' + '|' + 'Saving this milestone will specify the corrections required on a future document.'
                    + '|' + '1' + '|' + '1';
            }
            case 'EDAAUTH': {
                return '' + '|' + 'N' + '|' + 'Saving this milestone will create the EDA Authorization Process Start milestone.'
                    + '|' + '0' + '|' + '0';
            }
            case 'EDASTATE': {
                return '' + '|' + 'N' + '|' + 'Saving this milestone will create the EDA Department of State Coordination milestone.'
                    + '|' + '0' + '|' + '0';
            }
            case 'EDACOMRCE': {
                return '' + '|' + 'N' + '|' + 'Saving this milestone will create the EDA Department of Commerce Coordination milestone.'
                    + '|' + '0' + '|' + '0';
            }
            case 'EDAOSDPOL': {
                return '' + '|' + 'N' + '|' + 'Saving this milestone will create the EDA OSD Policy Coordination milestone.'
                    + '|' + '0' + '|' + '0';
            }
            case 'EDACNPREP': {
                return '' + '|' + 'N' + '|' + 'Saving this milestone will create the EDA Congressional Notification Prepared milestone.'
                    + '|' + '0' + '|' + '0';
            }
            case 'EDACNSTRT': {
                return '' + '|' + 'N' + '|' + 'Saving this milestone will create the EDA Congressional Notification Start milestone.'
                    + '|' + '0' + '|' + '0';
            }
            case 'EDAAUTHMSG': {
                return '' + '|' + 'N' + '|' + 'Saving this milestone will create the EDA Congressional Notification End/Authorization Message Released milestone.'
                    + '|' + '0' + '|' + '0';
            }
            case 'PAYAUTH': {
                return 'PaymentAuth for NonDepUndertak' + '|' + 'N' + '|' + 'Saving this milestone will  authorize the addition of a payment schedule to a case version for a nondependable undertaking country.'
                    + '|' + '0' + '|' + '1';
            }
            case 'CSTANOT': {
                return 'Statutory Notif. to Congress' + '|' + 'N' + '|' + 'Saving this will create the Statutory Notification Submitted by DSCA to Congress.'
                    + '|' + '0' + '|' + '0';
            }
            case 'LORACTION': {
                return 'LOR Actionable' + '|' + 'N' + '|' + 'Saving this milestone records the date that the LOR meets the actionable criteria as defined in SAMM.'
                    + '|' + '0' + '|' + '0';
            }
            case 'CPOHOLD': {
                return 'DSCA CPO Hold Placed' + '|' + 'N' + '|' + 'Saving this milestone will put the document on hold.'
                    + '|' + '0' + '|' + '1';
            }
            case 'CPOHOLDREM': {
                return 'DSCA CPO Hold Removed' + '|' + 'N' + '|' + 'Saving this milestone will eliminate the hold from the document.'
                    + '|' + '0' + '|' + '1';
            }
            case 'DSCACNOVRD': {
                return 'DSCA CN OVERRIDE' + '|' + 'N' + '|' + 'Saving this milestone will allow a status change when the case violates CN amount and quantity restrictions.'
                    + '|' + '0' + '|' + '1';
            }
            case 'BPCWAIT': {
                return 'BPC Wait' + '|' + 'N' + '|' + 'Saving this milestone will end the LOA processing clock for BPC cases.'
                    + '|' + '0' + '|' + '0';
            }
            default: {
                return '';
            }
        }
    }

    public static getDesiredStatus(pMilestoneId: string, pVersion: any): string {
        let retData: string;
        retData = this.getDData1(pMilestoneId, pVersion);
        return retData;
    }

    public static getDData1(pMData1: string, pVersionData1: any) {
        let cStatusCd: string = pVersionData1.cStatusCd;
        let sapCd: string = pVersionData1.sapCd;
        let cuiCd: string = pVersionData1.cuiCd;
        let cvTypeCd: string = pVersionData1.cvTypeCd;
        let dsaApprovalIn: string = pVersionData1.dsaApprovalIn;
        let sdApprovalIn: string = pVersionData1.sdApprovalIn;
        switch (pMData1) {
            case 'MILAP': {
                return this.getS1(sapCd, cuiCd, cvTypeCd, cStatusCd);
            }
            case 'WRITECOMP': {
                return this.getS2(sapCd, cuiCd, cvTypeCd, cStatusCd);
            }
            case 'MILSGN': {
                return this.getS3(sapCd, cuiCd, cvTypeCd, cStatusCd);
            }
            case 'CWDAPPRV': {
                return this.getS5(sapCd, cuiCd, cvTypeCd, dsaApprovalIn, sdApprovalIn, cStatusCd);
            }
            case 'WDOCRTN':
            case 'STDAP': {
                return this.getS6(sapCd, cuiCd, cvTypeCd, cStatusCd);
            }
            case 'CWDDOCRTN': {
                return this.getS7(sapCd, cuiCd, cvTypeCd, cStatusCd);
            }
            case 'MILCAN': {
                return this.getS8(sapCd, cuiCd, cvTypeCd, cStatusCd);
            }
            case 'MILIMP': {
                return this.getS9(sapCd, cuiCd, cvTypeCd, cStatusCd);
            }
            case 'MILREACT': {
                return this.getS10(sapCd, cuiCd, cvTypeCd, cStatusCd);
            }
            case 'DCSGN': {
                return this.getS11(sapCd, cuiCd, cvTypeCd, dsaApprovalIn, sdApprovalIn, cStatusCd);
            }
            case 'STAP': {
                return this.getS12(sapCd, cuiCd, cvTypeCd, dsaApprovalIn, sdApprovalIn, cStatusCd);
            }
            case 'DCSGN': {
                return this.getS13(sapCd, cuiCd, cvTypeCd, cStatusCd);
            }
            case 'DCSGNRJ': {
                return this.getS14(sapCd, cuiCd, cvTypeCd, cStatusCd);
            }
            case 'SDOCRTN': {
                return this.getS16(sapCd, cuiCd, cvTypeCd, cStatusCd);
            }
            case 'OFFERACC': {
                return this.getS17(sapCd, cuiCd, cvTypeCd, cStatusCd)
            }
            case 'REOPEN': {
                return this.getS18(sapCd, cuiCd, cvTypeCd, cStatusCd)
            }
            default: {
                return '';
            }

        }
    }

    public static getSeqNumber(pStatus: string): string {
        switch (pStatus) {
            case 'D': {
                return '10';
            }
            case 'W': {
                return '14';
            }
            case 'R': {
                return '17';
            }
            case 'P': {
                return '20';
            }
            case 'O': {
                return '30';
            }
            case 'A': {
                return '40';
            }
            case 'I': {
                return '50';
            }
            case 'CL': {
                return '60';
            }
            case 'X': {
                return '0';
            }
            default: {
                return '';
            }
        }
    }
    public static getS1(sapCd: string, cuiCd: string, cvTypeCd: string, cStatusCd: string): string {
        let retData: string = '';
        if (sapCd === 'FMS' && (cuiCd === 'C' || cuiCd === 'I') && (cvTypeCd === 'A' || cvTypeCd === 'B' || cvTypeCd === 'M')) {
            return 'W' + '|' + 'Write' + '|' + this.getSeqNumber('W') + '|' + this.getSeqNumber(cStatusCd);
        }
        return retData;
    }
    public static getS2(sapCd: string, cuiCd: string, cvTypeCd: string, cStatusCd: string): string {
        let retData: string = '';
        if (sapCd === 'FMS' && (cuiCd === 'C' || cuiCd === 'I') && (cvTypeCd === 'A' || cvTypeCd === 'B' || cvTypeCd === 'M')) {
            return 'R' + '|' + 'Review ' + '|' + this.getSeqNumber('R') + '|' + this.getSeqNumber(cStatusCd);
        }
        return retData;
    }
    public static getS3(sapCd: string, cuiCd: string, cvTypeCd: string, cStatusCd: string): string {
        let retData: string = '';
        if (sapCd === 'LEASE' &&(cuiCd === 'P' || cuiCd === 'C')) {
            return 'P' + '|' + 'Proposed' + '|' + this.getSeqNumber('P') + '|' + this.getSeqNumber(cStatusCd);
        }
        else this.getS4(sapCd, cuiCd, cvTypeCd, cStatusCd);
        return retData;
    }
    public static getS4(sapCd: string, cuiCd: string, cvTypeCd: string, cStatusCd: string): string {
        let retData: string = '';
        if (sapCd === 'FMS' && (cuiCd === 'P' || cuiCd === 'C') && cvTypeCd === 'B') {
            return 'O' + '|' + 'Offered' + '|' + this.getSeqNumber('O') + '|' + this.getSeqNumber(cStatusCd);
        }
        return retData;
    }
    public static getS5(sapCd: string, cuiCd: string, cvTypeCd: string, dsaApprovalIn: string, sdApprovalIn: string, cStatusCd: string): string {
        let retValue: string = '';
        if (sapCd === 'FMS' && (cuiCd === 'C' || cuiCd === 'I') && (cvTypeCd === 'A' || cvTypeCd === 'B') &&
            dsaApprovalIn  && !sdApprovalIn) {
            retValue = 'O' + '|' + 'Offered' + '|' + this.getSeqNumber('O') + '|' + this.getSeqNumber(cStatusCd);
        }
        else if (sapCd === 'FMS' && (cuiCd === 'C' || cuiCd === 'I') && (cvTypeCd === 'A' || cvTypeCd === 'B' || cvTypeCd === 'M') &&
            dsaApprovalIn && sdApprovalIn) {
            retValue = 'P' + '|' + 'Proposed' + '|' + this.getSeqNumber('P') + '|' + this.getSeqNumber(cStatusCd);
        }
        else if (sapCd === 'FMS' && cuiCd === 'C' && cvTypeCd === 'M' && dsaApprovalIn && sdApprovalIn ) {
            retValue = 'I' + '|' + 'Implemented' + '|' + this.getSeqNumber('I') + '|' + this.getSeqNumber(cStatusCd);
        }
        return retValue;
    }
    public static getS6(sapCd: string, cuiCd: string, cvTypeCd: string, cStatusCd: string): string {
        console.log('');//sonarqube trick for now
        let retData: string = '';
        if (sapCd === 'FMS' && (cuiCd === 'C' || cuiCd === 'I') && (cvTypeCd === 'A' || cvTypeCd === 'B' || cvTypeCd === 'M')) {
            return 'W' + '|' + 'Write' + '|' + this.getSeqNumber('W') + '|' + this.getSeqNumber(cStatusCd);
        }
        return retData;
    }
    public static getS7(sapCd: string, cuiCd: string, cvTypeCd: string, cStatusCd: string): string {
        let retData: string = '';
        if (sapCd === 'FMS' && (cuiCd === 'C' || cuiCd === 'I') && (cvTypeCd === 'A' || cvTypeCd === 'B' || cvTypeCd === 'M')) {
            return 'D' + '|' + 'Development' + '|' + this.getSeqNumber('D') + '|' + this.getSeqNumber(cStatusCd);
        }
        return retData;
    }
    public static getS8(sapCd: string, cuiCd: string, cvTypeCd: string, cStatusCd: string): string {
        let retData: string = '';
        if (sapCd === 'FMS' && (cuiCd === 'C' || cuiCd === 'I') && 
           (cvTypeCd === 'A' || cvTypeCd === 'B' || cvTypeCd === 'M' || cvTypeCd === 'R')) {
            return 'X' + '|' + 'Cancelled' + '|' + this.getSeqNumber('X') + '|' + this.getSeqNumber(cStatusCd);
        }
        return retData;
    }
    public static getS9(sapCd: string, cuiCd: string, cvTypeCd: string, cStatusCd: string): string {
        let retData: string = '';
        if (sapCd === 'FMS' && (cuiCd === 'C' || cuiCd === 'I') && (cvTypeCd === 'A' || cvTypeCd === 'B' || cvTypeCd === 'M')) {
            return 'I' + '|' + 'Implemented' + '|' + this.getSeqNumber('I') + '|' + this.getSeqNumber(cStatusCd);
        }
        return retData;
    }
    public static getS10(sapCd: string, cuiCd: string, cvTypeCd: string, cStatusCd: string): string {
        let retData: string = '';
        if (sapCd === 'FMS' && (cuiCd === 'C' || cuiCd === 'I' || cuiCd === 'P') &&
            (cvTypeCd === 'A' || cvTypeCd === 'B' || cvTypeCd === 'M' || cvTypeCd === 'R')) {
            return 'D' + '|' + 'Development' + '|' + this.getSeqNumber('D') + '|' + this.getSeqNumber(cStatusCd);
        }
        return retData;
    }
    public static getS11(sapCd: string, cuiCd: string, cvTypeCd: string, dsaApprovalIn: string, sdApprovalIn: string, cStatusCd: string): string {
        let retData: string = '';
        if (sapCd === 'FMS' && cuiCd === 'C' && cvTypeCd === 'A' && dsaApprovalIn && sdApprovalIn) {
            return 'O' + '|' + 'Offered' + '|' + this.getSeqNumber('O') + '|' + this.getSeqNumber(cStatusCd);
        }
        return retData;
    }
    public static getS12(sapCd: string, cuiCd: string, cvTypeCd: string, dsaApprovalIn: string, sdApprovalIn: string, cStatusCd: string): string {
        let retData: string = '';
        if (sapCd === 'FMS' && cuiCd === 'C' && cvTypeCd === 'M' && dsaApprovalIn && sdApprovalIn ) {
            return 'I' + '|' + 'Implemented' + '|' + this.getSeqNumber('I') + '|' + this.getSeqNumber(cStatusCd);
        }
        return retData;
    }
    public static getS13(sapCd: string, cuiCd: string, cvTypeCd: string, cStatusCd: string): string {
        let retData: string = '';
        if (sapCd === 'LEASE' && cuiCd === 'C' && (cvTypeCd === 'A' || cvTypeCd === 'B')) {
            return 'O' + '|' + 'Offered' + '|' + this.getSeqNumber('O') + '|' + this.getSeqNumber(cStatusCd);
        }
        return retData;
    }
    public static getS14(sapCd: string, cuiCd: string, cvTypeCd: string, cStatusCd: string): string {
        let retData: string = '';
        if (sapCd === 'LEASE' && cuiCd === 'C' && (cvTypeCd === 'A' || cvTypeCd === 'B')) {
            return 'D' + '|' + 'Development' + '|' + this.getSeqNumber('D') + '|' + this.getSeqNumber(cStatusCd);
        }
        return retData;
    }
    public static getS16(sapCd: string, cuiCd: string, cvTypeCd: string, cStatusCd: string): string {
        let retData: string = '';
        if (sapCd === 'FMS' && cuiCd === 'C' && (cvTypeCd === 'A' || cvTypeCd === 'B' || cvTypeCd === 'M')) {
            return 'W' + '|' + 'Write' + '|' + this.getSeqNumber('W') + '|' + this.getSeqNumber(cStatusCd);
        }
        return retData;
    }
    public static getS17(sapCd: string, cuiCd: string, cvTypeCd: string, cStatusCd: string): string {
        let retData: string = '';
        if (sapCd === 'FMS' && cuiCd === 'C' &&(cvTypeCd === 'A' || cvTypeCd === 'B' || cvTypeCd === 'M')) {
            return 'A' + '|' + 'Accepted' + '|' + this.getSeqNumber('A') + '|' + this.getSeqNumber(cStatusCd);
        }
        return retData;
    }
    public static getS18(sapCd: string, cuiCd: string, cvTypeCd: string, cStatusCd: string): string {
        let retData: string = '';
        if ((sapCd === 'FMS' || sapCd === 'LEASE') && (cuiCd === 'C' || cuiCd === 'I') && (cvTypeCd === 'A' || cvTypeCd === 'B')) {
            return 'I' + '|' + 'Implemented ' + '|' + this.getSeqNumber('I') + '|' + this.getSeqNumber(cStatusCd);
        }
        return retData;
    }
    public static get SA_PROGRAM_FMS(): string {return "FMS"; }
    public static get SA_PROGRAM_GRANT(): string {return "GRANT"; }
    public static get SA_PROGRAM_LEASE(): string {return "LEASE"; }
    public static get CASE_USAGE_REAL(): string {return "C"; }
    public static get CASE_USAGE_LOI(): string {return "I"; }
    public static get CASE_USAGE_PLANNING(): string {return "P"; }
    public static get CASE_USAGE_MODEL(): string {return "M"; }
    public static get CASE_VERSION_TYPE_AMENDMENT(): string {return "A"; }
    public static get CASE_VERSION_TYPE_BASIC_CASE(): string {return "B"; }
    public static get CASE_VERSION_TYPE_REVISION(): string {return "R"; }
    public static get CASE_VERSION_TYPE_MODIFICATION(): string {return "M"; }
    public static get SALE_TERM_FMS_MAP(): string {return "M"; }
    public static get SALE_TERM_FMS_CREDIT_NONREPAYABLE(): string {return "N"; }
    public static get SALE_TERM_FMS_CREDIT(): string {return "Z"; }
    
    public static get MILESTONE_MILDEP_CANCEL(): string {return "MILCAN"; }
    public static get MILESTONE_CASE_RETURNED(): string {return "CASERETD"; }
    public static get MILESTONE_LEASE_RETURNED(): string {return "LEASERETD"; }
    public static get MILESTONE_CANCEL_CONGESS(): string {return "CANCONGTRN"; }
    public static get MILESTONE_CANCRFIN(): string {return "CANCRFIN"; }
    public static get MILESTONE_STATE_LIST(): string {return "STLST"; }
    
}
