import { ChangeDetectorRef, Component, OnInit, Injector } from '@angular/core';
import { MatTableDataSource } from '@angular/material';
import { DsamsConstants } from '../../../dsams.constants';
import { CaseUIService } from '../../services/case-ui-service';
import { BehaviorSubject, Subscription } from 'rxjs';
import { IEditResponseType } from '../../model/edit-response-type';
import { CaseUtils } from '../../utils/case-utils';
import { DatePipe, formatDate } from '@angular/common';
import { FormBuilder, FormControl } from '@angular/forms';
import { FieldDisabledMap } from '../../model/field-disabled-map';
import { TextAreaComponent } from '../../dialogs/text-area/text-area.component';
import { DsamsMethodsService } from 'src/app/dsams/services/dsams-methods.service';
import { remarksDto } from '../model/dto/case-remarks-dto';
import { CaseRestfulService } from '../../services/case-restful.service';
import { prepareCaseRemarkDataForSave } from '../model/case-remarks';
import { MessageMgr } from '../../validation/message-mgr';
import { CaseRelatedInfoType } from '../../model/case-related-info-type';
import { LineUtils } from '../../line-dashboard/line-utils';
import { CaseCommonValidator } from '../../validation/case-common-validator';
import { CaseVersion } from '../../model/dto/case-version';
import { newremarksDto } from '../model/dto/new-case-remarks-dto';
import { IPerson } from '../../model/dto/person';
import { IPersonSearchParamsType } from '../../model/search-params/person-search-params-type';
import { ErrorParameter } from 'src/app/dsams/entities/specialEntities/error-parameter.model';
import { DialogMessageListComponentTc } from 'src/app/dsams/utilitis/dialogs/dialog-message-list-tc/dialog-message-list-tc.component';
import { MessageType } from 'src/app/dsams/enums/user-message.enum';
import { DsamsUserMessageService } from 'src/app/dsams/services/dsams-user-message.service';
import { caseVersionInfoDto } from '../model/dto/case-version-info-dto';
import { DsamsRestfulService } from 'src/app/dsams/services/dsams-restful.service';
import { DsamsShareService } from '../../../services/dsams-share.service';

const removeDuplicates = (array, key) => {
  return array.reduce((arr, item) => {
    const removed = arr.filter(i => i[key] !== item[key]);
    return [...removed, item];
  }, []);
};


@Component({
  selector: 'app-case-remarks-panel',
  templateUrl: './case-remarks-panel.component.html',
  styleUrls: ['./case-remarks-panel.component.css'],
  providers: [DatePipe]
})
export class CaseRemarksPanelComponent implements OnInit {

  date = this.fb.control(new Date());
  dates = this.fb.array([
    this.fb.control(new Date())
  ]);
  isDeleteDisabled: boolean[] = [];
  isVersionDisabled: boolean[] = [];

  /**
   * Editability fields
   */
  isPanelEditable: boolean = false;
  private _fieldDisabledMap: FieldDisabledMap = {};
  private _newfieldDisabledMap: FieldDisabledMap;
  private editSubscription: Subscription = null;
  private newCRSubscription: Subscription = null;
  private revertEditSubscription: Subscription = null;
  private saveCompleteSubscription: Subscription = null;

  /* Remarks Table */
  dataSourceRemarkTable = new MatTableDataSource<remarksDto>();
  dataSourceRemarkListData: remarksDto[] = [];

  remarksColumnsToDisplayItems = ['RemarksDate', 'RemarksTitle', 'ActivityRemarks', 'AuthorRemarks', 'VersionType', 'RemarksText', 'DeleteRow'];
  remarksColumnsToDisplayFooter = ['AddRow'];
  isLoading: BehaviorSubject<boolean> = new BehaviorSubject(false);
  theCustomerTypeCode: string;

  selectedCaseVersion: caseVersionInfoDto[] = [{}];
  mySelectArray: newremarksDto[] = [{}];

  caseVersionListData: caseVersionInfoDto[] = [{}];  

  private caseUIServiceSubscription: Subscription = null;
  private _caseUIServiceSubscription1: Subscription = null;
  private _caseVersionInfoSubscription: Subscription = null;
  private _caseRemarksDataSubscription: Subscription = null;
  private _personDataSubscription: Subscription = null;

  aPersonData: IPerson[] = [];
  personForm: IPersonSearchParamsType = {
    personLastNm: sessionStorage.getItem('lastNm'),
    personFirstNm: sessionStorage.getItem('firstNm'),
    personNicknameNm: sessionStorage.getItem('loginId'),
    activityId: '',
    userId: sessionStorage.getItem('userId'),
    ruleSet: null,
    maxRecords: 1
  };
  caseRelatedInfoData: CaseRelatedInfoType = { case_CUSTOMER_TYPE_CD: '' };
  remarksPanelData: remarksDto[] = [];
  caseVersionData: CaseVersion;
  todaysDate: Date;
  formattedDate: string;
  emptyString: string = '';
  selected: any[] = [];
  index: number;
  private _textIndex: number;

  dsamsShareService: DsamsShareService;
  dsamsRestfulService: DsamsRestfulService;
  messageService: DsamsUserMessageService;
  constructor(private injector : Injector,
    private caseUIService: CaseUIService,
    private fb: FormBuilder,
    private caseRestService: CaseRestfulService,
    public dsamsDialogMsgService: DsamsMethodsService,
    private datepipe: DatePipe,
    private cDRef: ChangeDetectorRef) { 
      this.dsamsShareService = injector.get<DsamsShareService>(DsamsShareService);
      this.dsamsRestfulService = injector.get<DsamsRestfulService>(DsamsRestfulService);
      this.messageService = injector.get<DsamsUserMessageService>(DsamsUserMessageService);
      this.dsamsShareService.csuname.next('WP011');
    }

  //Text Area
  private textAreaSubscription: Subscription = null;

  ngOnInit() {
    this.theCustomerTypeCode = '';
    this.subscribeToEditService();

    this.todaysDate = new Date();
    this.formattedDate = formatDate(this.todaysDate, "MM/dd/yyyy", "en-US");

    this.formattedDate = formatDate(this.todaysDate, "MM/dd/yyyy", "en-US");
    this._fieldDisabledMap = {
      'selected[i]': true,
      'RemarkAdd': true,
    };
    this._newfieldDisabledMap = {
      'case_REMARK_TITLE_NM': true,
      'case_REMARK_TX': true,
      'RemarkDelete': true,
    };

    if (!this._caseUIServiceSubscription1) {
      if (!!this.caseRelatedInfoData) {
        this.isLoading.next(true);
        this._caseUIServiceSubscription1 = this.caseUIService.getCaseRelatedInfoValues().subscribe((value) => {
          this.caseRelatedInfoData = value;
        },
          err => {
            CaseUtils.ReportHTTPError(err, "Getting Case Related Info Data");
            this.isLoading.next(false);
          });
        this.isLoading.next(false);
      }
    }

    if (!this._personDataSubscription) {
      this.isLoading.next(true);
      this._personDataSubscription = this.caseRestService.postPersonSearch(this.personForm).subscribe((value) => {
        this.aPersonData = value;
      })
    }

    if (!this._caseVersionInfoSubscription) {
      if (!!this.caseRelatedInfoData) {
        this._caseVersionInfoSubscription =
          this.caseRestService.getCaseVersionInfoData(this.caseRelatedInfoData.case_ID).subscribe((data) => {
            this.caseVersionListData = data;            
            for (let d = this.caseVersionListData.length - 1; d >= 0; d--){
              if (this.caseVersionListData[d].case_VERSION_TYPE_CD == 'D'){
                this.caseVersionListData.splice(d, 1);
              }
            }
            this.caseVersionListData.sort((a, b) => Number((a.case_VERSION_TYPE_CD + '&nbsp;' + a.case_VERSION_NUMBER_ID)
            .localeCompare((b.case_VERSION_TYPE_CD + '&nbsp;' + b.case_VERSION_NUMBER_ID))));
          },
            err => {
              CaseUtils.ReportHTTPError(err, "Getting Version Info");
              this.isLoading.next(false);
            });
      }
    }

    this.populateRemarkTable();
    this.subscribeToTextAreaDialog();
    this.subscribeToTextAreaDialogTitle();
    this.isLoading.next(false);
    this.clobberLockSession();
  }

  ngOnDestroy() {
    this.dsamsShareService.csuname.next(null);
    if (!!this.caseUIServiceSubscription) {
      this.caseUIServiceSubscription.unsubscribe();
    }
    if (!!this.editSubscription) {
      this.editSubscription.unsubscribe();
    }
    if (!!this.newCRSubscription) {
      this.newCRSubscription.unsubscribe();
    }
    if (!!this.revertEditSubscription) {
      this.revertEditSubscription.unsubscribe();
    }
    if (!!this.saveCompleteSubscription) {
      this.saveCompleteSubscription.unsubscribe();
    }
    if (!!this._caseVersionInfoSubscription) {
      this._caseVersionInfoSubscription.unsubscribe();
    }
    if (!!this._caseRemarksDataSubscription) {
      this._caseRemarksDataSubscription.unsubscribe();
    }
    if (!!this._personDataSubscription) {
      this._personDataSubscription.unsubscribe();
    }
    this.clobberLockSession();
  }

  

  populateRemarkTable() {
    this.isLoading.next(true);
    if (!this._caseRemarksDataSubscription) {
      if (!!this.caseRelatedInfoData) {
        this._caseRemarksDataSubscription = 
            this.caseRestService.getCaseRemarksData(this.caseRelatedInfoData.case_ID)
              .subscribe((values) => {
          if (values !== null) {
            this.dataSourceRemarkListData = values;
            this.remarksPanelData = values;
            this.theCustomerTypeCode = this.caseRelatedInfoData.case_CUSTOMER_TYPE_CD;
            for (let i = 0; i < this.dataSourceRemarkListData.length; i++) {
              this.dates.insert(this.dates.length - 1,
              new FormControl(this.dataSourceRemarkListData[i].case_REMARK_DT));
              this.isDeleteDisabled[i] = true;
              this.isVersionDisabled[i] = false;
              for (let n = this.caseVersionListData.length-1; n>=0; n--) {
                this.selectedCaseVersion[i] = {case_ID: null, case_VERSION_ID: null, case_VERSION_NUMBER_ID: null, case_VERSION_TYPE_CD: null};
                if ((this.dataSourceRemarkListData[i].remark_CASE_ID === this.caseVersionListData[n].case_ID
                  && this.dataSourceRemarkListData[i].remark_CASE_VERSION_ID === this.caseVersionListData[n].case_VERSION_ID)) {
                  this.dataSourceRemarkListData[i].case_VERSION_TYPE_CD = this.caseVersionListData[n].case_VERSION_TYPE_CD;
                  this.dataSourceRemarkListData[i].case_VERSION_NUMBER_ID = this.caseVersionListData[n].case_VERSION_NUMBER_ID;
                  this.selectedCaseVersion[i].case_ID = this.caseVersionListData[n].case_ID;
                  this.selectedCaseVersion[i].case_VERSION_ID = this.caseVersionListData[n].case_VERSION_ID;
                  this.selectedCaseVersion[i].case_VERSION_NUMBER_ID = this.caseVersionListData[n].case_VERSION_NUMBER_ID;
                  this.selectedCaseVersion[i].case_VERSION_TYPE_CD = this.caseVersionListData[n].case_VERSION_TYPE_CD; 
                }
              }
              this.dataSourceRemarkListData[i].status = DsamsConstants.ENT_UNCHANGED.toString();
            } 
            //console.log("this.dataSourceRemarkListData", this.dataSourceRemarkListData);   
            // Set Breadcrumb
            
            this.dataSourceRemarkTable = new MatTableDataSource(this.dataSourceRemarkListData);
            this.dataSourceRemarkTable._updateChangeSubscription();
            this.isLoading.next(false);
          }          
        },
          err => {
            CaseUtils.ReportHTTPError(err, "Getting Remarks");
            this.isLoading.next(false);
          });
      }
    }
  }  

  change(i: number, param: string) {
      let paramSplit = param.split(':');
      this.remarksPanelData[i].remark_CASE_ID = Number(paramSplit[0]);
      this.remarksPanelData[i].remark_CASE_VERSION_ID = Number(paramSplit[1]);
      if (this.remarksPanelData[i].status !== DsamsConstants.ENT_NEW.toString()) {
        this.remarksPanelData[i].status = DsamsConstants.ENT_CHANGED.toString();
      }
      console.log(this.remarksPanelData[i].remark_CASE_ID, this.remarksPanelData[i].remark_CASE_VERSION_ID);
  }

  /* This procedure checks the returned result value from the popover Yes/No dialog window. */
  yesButtonOnClick(isDeleteConfirmed: any, rowElement: any) {
    if (isDeleteConfirmed)
      this.deleteItem(rowElement);
  }

  /* Delete a row from the Remark Grid */
  deleteItem(rowElement: any) {
    let rowIndex = this.remarksPanelData.indexOf(rowElement);
    this.remarksPanelData.splice(rowIndex, 1);
    this.dates.removeAt(rowIndex);
    this.dataSourceRemarkTable = new MatTableDataSource(this.remarksPanelData);
    this.dataSourceRemarkTable._updateChangeSubscription();
  }

  /* Add Button in the Remark Grid */
  addItem(): void {
    const anItemObject: newremarksDto =
    {
      status: DsamsConstants.ENT_NEW.toString(),
      isDataChanged: false,
      case_REMARK_ID: null,
      case_ID: this.caseRelatedInfoData.case_ID,
      remark_CASE_ID: null,
      remark_CASE_VERSION_ID: null,
      case_REMARK_TX: "",
      case_REMARK_DT: this.datepipe.transform(this.todaysDate, 'MM/dd/yyyy', 'en-US'),
      activity_ID: this.aPersonData[0].activity_ID,
      author_USER_ID: sessionStorage.getItem('userId'),
      person_LAST_NM: sessionStorage.getItem('lastNm'),
      case_REMARK_TITLE_NM: null,
      case_VERSION_TYPE_CD: null,
      case_VERSION_NUMBER_ID: null,
      case_Version_Status_CD: null,
      caseCustomerTypeCD: this.theCustomerTypeCode,
      isNewElement: true
    };
    // if the list is intially empty
    if (this.remarksPanelData == null) {
      this.remarksPanelData = [];
    }

    this.isDeleteDisabled[this.remarksPanelData.length + 1] = false;
    this.isVersionDisabled[this.remarksPanelData.length + 1] = false;
    //add new object to the entity list
    this.dates.insert(this.dates.length - 1, new FormControl(anItemObject.case_REMARK_DT));
    this.remarksPanelData.push(anItemObject);
    this.dataSourceRemarkTable = new MatTableDataSource(this.remarksPanelData);
    //refresh the table
    this.dataSourceRemarkTable._updateChangeSubscription();
    /* Added to fix edit toggle off - Author: JS */
    const editResp: IEditResponseType = { ID: DsamsConstants.REMARKS_EDITOR, editToggle: true };
    this.caseUIService.hasEditBeenMadeService.next(editResp);
  }

     // Clobber the existing session IDs.
     private clobberLockSession() {
      const sessionIdForRemarkLock: string = sessionStorage.getItem(DsamsConstants.SESSION_CASE_REMARK_LOCK_ID);
      if (!!sessionIdForRemarkLock && (+sessionIdForRemarkLock) > 0) {
        this.dsamsRestfulService.closeLegacyLockSession(sessionIdForRemarkLock).subscribe((pResult: any) => {
          sessionStorage.setItem(DsamsConstants.SESSION_CASE_REMARK_LOCK_ID, "0");
        },
          err => {
            CaseUtils.ReportHTTPError(err, "Removing Remark Lock from Note List");
          });
      }
    }
  
  /*---------------------------------------------- Edit Toggle --------------------------------------------*/
  // Subscribe to edit service
  private subscribeToEditService() {
    this.editSubscription = this.caseUIService.caseEditService.subscribe((pEditResult: IEditResponseType) => {
      if (!!pEditResult && pEditResult.ID === DsamsConstants.REMARKS_EDITOR) {
        this.isPanelEditable = pEditResult.editToggle;
        if (pEditResult.editToggle) {
           this.caseRestService.lockCaseRemarkList(this.caseRelatedInfoData.case_ID).
            subscribe((pLockSessionId: number) => {
              sessionStorage.setItem(DsamsConstants.SESSION_CASE_REMARK_LOCK_ID, pLockSessionId.toString());
             },
             err => {
              const turnToggleOff:IEditResponseType = {ID: DsamsConstants.REMARKS_EDITOR, editToggle: false};
              CaseUtils.ReportHTTPError(err, "locking case remark list");
              this.caseUIService.caseEditService.next(turnToggleOff);
              this.caseUIService.caseEditServiceRegSub.next(turnToggleOff);
              this.caseUIService.revertEditService.next(turnToggleOff);
              this.caseUIService.hasEditBeenMadeService.next(turnToggleOff);

            });
          
        } else {
        console.log("inside else on subscribetoEdit");
          this.clobberLockSession();
          if (this.hasDataBeenChanged()) {
            console.log("edit change beforee refresh");
          this.refreshData();
          }
        }

      }
    });
  }

  private makeSureEditToggleIsOff() {
    this.caseUIService.flipToDisabledService.next(DsamsConstants.REMARKS_EDITOR);
    // this._editToggleState = false;
  }

  // Determine if a field is disabled.
  isFieldDisabled(pElement: any, pFieldName: string): boolean {
    //this._fieldDisabledMap = {}; //Jeff 11/4/21
    // Modified 11/15/2021 Cliff Inks
    // Is whole panel disabled?
    if (!this.isPanelEditable) {
      return true;
    } else {
      if (pFieldName === 'deleteRemark') {
        if (pElement === true) {
          return pElement;
        } else {
          return false; 
        }
      }
      if (pFieldName === 'versionType') {
        if (pElement === true) {
          return pElement;
        } else {
          return false;
        }
      }
      if (pFieldName === 'case_REMARK_TX') {
        if (pElement === true) {
          return pElement;
        } else {
          return false;
        }
      }
      if (pFieldName === 'case_REMARK_TITLE_NM') {
        if (pElement === true) {
          return pElement;
        } else {
          return false;
        }
      }
    }
    if (!!pElement && pElement.isDisabled) {
      return true;
    }
    if (!!pElement && pElement.isNewElement && this._newfieldDisabledMap[pFieldName]) {
      return false;
    }
    return !this._fieldDisabledMap[pFieldName];
  }

  /**
  * Set the field changed so that the edit toggle is notified.
  */
  setChanged(index: number) {
    const editResp: IEditResponseType = { ID: DsamsConstants.REMARKS_EDITOR, editToggle: true };
    this.caseUIService.hasEditBeenMadeService.next(editResp);
    this.remarksPanelData[index].isDataChanged = true;
  }

  //Remarks Title
  // Text area popup
  popupTextAreaOpenTitle(pElement: any, pIndex: number): void {
    let diaWidth: string = "50%";
    let diaHeight: string = "60%";
    let passingData: string = pElement.case_REMARK_TITLE_NM;
    let pTitle: string = "Remark Title";
    this._textIndex = pIndex;
    this.dsamsDialogMsgService.openTextAreaIpc2Dialog(diaWidth, diaHeight, passingData,
      TextAreaComponent, pIndex.toString(), pTitle, this.isFieldDisabled(this.isDeleteDisabled[pIndex], 'case_REMARK_TITLE_NM'));
      // !this.isPanelEditable);
  }

  // Subscribe to Text Area Dialog
  private subscribeToTextAreaDialogTitle() {
    this.textAreaSubscription = this.dsamsDialogMsgService.textAreaFromIpc2Dialog.subscribe((textAreaValue: string) => {
      setTimeout(() => {
        if (!!this.dataSourceRemarkTable.data[this._textIndex]) {
          this.dataSourceRemarkTable.data[this._textIndex].case_REMARK_TITLE_NM = textAreaValue;
          this.dataSourceRemarkTable._updateChangeSubscription();
          this.setChanged(this._textIndex);
        }
      }, 0);
    });
  }

  // Remark Popup
  // Text area popup
  popupTextAreaOpen(pElement: any, pIndex: number): void {
    let diaWidth: string = "50%";
    let diaHeight: string = "60%";
    let passingData: string = pElement.case_REMARK_TX;
    let pTitle: string = "Remark Description";
    this._textIndex = pIndex;
    this.dsamsDialogMsgService.openTextAreaIpcDialog(diaWidth, diaHeight, passingData,
      TextAreaComponent, pIndex.toString(), pTitle, this.isFieldDisabled(this.isDeleteDisabled[pIndex], 'case_REMARK_TX'));
      // !this.isPanelEditable);
  }

  // Subscribe to Text Area Dialog
  private subscribeToTextAreaDialog() {
    this.textAreaSubscription = this.dsamsDialogMsgService.textAreaFromIpcDialog.subscribe((textAreaValue: string) => {
      setTimeout(() => {
        if (!!this.dataSourceRemarkTable.data[this._textIndex]) {
          this.dataSourceRemarkTable.data[this._textIndex].case_REMARK_TX = textAreaValue;
          this.dataSourceRemarkTable._updateChangeSubscription();
          this.setChanged(this._textIndex);
        }
      }, 0);
    });
  }

  /**
  * Determine if the save button is enabled.
  * (currently only depends on if the edit slider is toggled)
  */
  isSaveEnabled() {
    return this.isPanelEditable;
  }

  isCancelEnabled() {
    return this.isPanelEditable;
  }

  /** 
    * Do save Case Remark data
    * @Author: David Huynh
    * @Date: 11/12/2021
    * @Jira Card: 2960 
    */
  performSaveOperation() {
    console.log('remarksPanelData object to be saved=', this.remarksPanelData);
    this.isLoading.next(true);
    let saveCRList = new prepareCaseRemarkDataForSave(this.remarksPanelData);
    if (this.areFieldsValidForSave()) {
      this.caseRestService.saveCaseRemarkList(saveCRList.theCREntityList).subscribe(
        result => {
          this.postSaveData();
          this.isLoading.next(false);
          setTimeout(() => {
            MessageMgr.displaySuccessWithTimer('Save was successful', 2000);
          }, 1200);
        },
        err => {
          this.isLoading.next(false);
          CaseUtils.ReportHTTPError(err, "saving case remark to the database");
        })
      this.isLoading.next(false);
      this.postSaveData();
    }
  }

  //check whether data has been changed
  hasDataBeenChanged(): boolean {
    for (let i = 0; i < this.remarksPanelData.length; i++) {
      if (!!this.remarksPanelData[i].status && this.remarksPanelData[i].status !== DsamsConstants.ENT_UNCHANGED.toString())
        return true;
    }
    return false;
  }

  //make sure madatory fields have values
  areFieldsValidForSave(): boolean {
    var displayMsg: boolean = false;
    let msgArray: Array<ErrorParameter> = [];

    this.remarksPanelData.forEach((eachRow, index) => {
      if (CaseUtils.isBlankStr(eachRow.case_REMARK_TITLE_NM)) {
        DialogMessageListComponentTc.addMessageRefToList(msgArray,
          'Remarks', 'Row ' + index.toString(), MessageType.ERROR,
          "Remark Title is required.");
        displayMsg = true;
      }
      if (CaseUtils.isBlankStr(eachRow.case_REMARK_TX)) {
        DialogMessageListComponentTc.addMessageRefToList(msgArray,
          'Remarks', 'Row ' + index.toString(), MessageType.ERROR,
          "Remark Text is required.");
        displayMsg = true;
      }
    })
    //Display validation warning/error messages if applicable
    if (displayMsg) {
      this.isLoading.next(false);
      this.messageService.displayMessageListTc("Validate Remarks", msgArray).subscribe();
    }
    return !displayMsg;
  }

  /** 
   * Save Case Remark function includes validation
   * @Author: David Huynh
   * @Date: 11/05/2021
   * @Jira Card: 2960
   */
  onClickSaveCaseRemarkData() {
    if (this.hasDataBeenChanged()) {
      if (CaseCommonValidator.isEqual(this.theCustomerTypeCode, LineUtils.CUSTOMER_TYPE_PS)) {
        MessageMgr.swalFire({
          text: 'This is a 36(b) Congressional Notification document!!! Please ensure that no references are made to classified information!!! Do you want to continue with Save?',
          icon: 'question',
          width: 550,
          showCancelButton: true,
          cancelButtonText: 'No',
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: 'Yes',
        }).then((result) => {
          if (result.isConfirmed)
            this.performSaveOperation();
        })
      }
      else this.performSaveOperation();
    }
    else {
      let nctsPrompt: any = {
        text: 'No change has been made.',
        icon: 'info',
        showConfirmButton: false,
        timer: 1500,
        width: 350
      };
      MessageMgr.swalFire(nctsPrompt);
    }
  }

  /** 
   * Post save data method to reset applicable attributes
   * @Author: David Huynh
   * @Date: 11/05/2021
   * @Jira Card: 2960
  */
  postSaveData() {
    this.remarksPanelData.forEach((eachRow, index) => {
      eachRow.status = DsamsConstants.ENT_UNCHANGED.toString();
      eachRow.isDataChanged = false;
      this.isDeleteDisabled[index] = true;
    })
    /* Added to fix edit toggle off - Author: JS */
    const editResp: IEditResponseType = { ID: DsamsConstants.REMARKS_EDITOR, editToggle: false };
    this.caseUIService.hasEditBeenMadeService.next(editResp);
  }

refreshData(){
  this._caseRemarksDataSubscription = 
      this.caseRestService.getCaseRemarksData(this.caseRelatedInfoData.case_ID)
        .subscribe((data) => {
    if (data !== null) {
      this.dataSourceRemarkListData = data;
      this.remarksPanelData = data;
      this.theCustomerTypeCode = this.caseRelatedInfoData.case_CUSTOMER_TYPE_CD;
      for (let i = 0; i < this.dataSourceRemarkListData.length; i++) {
        this.dates.insert(this.dates.length - 1,
        new FormControl(this.dataSourceRemarkListData[i].case_REMARK_DT));
        this.isDeleteDisabled[i] = true;
        this.isVersionDisabled[i] = false;
        for (let n = this.caseVersionListData.length-1; n>=0; n--) {
          this.selectedCaseVersion[i] = {case_ID: null, case_VERSION_ID: null, case_VERSION_NUMBER_ID: null, case_VERSION_TYPE_CD: null};
          if ((this.dataSourceRemarkListData[i].remark_CASE_ID === this.caseVersionListData[n].case_ID
            && this.dataSourceRemarkListData[i].remark_CASE_VERSION_ID === this.caseVersionListData[n].case_VERSION_ID)) {
            this.dataSourceRemarkListData[i].case_VERSION_TYPE_CD = this.caseVersionListData[n].case_VERSION_TYPE_CD;
            this.dataSourceRemarkListData[i].case_VERSION_NUMBER_ID = this.caseVersionListData[n].case_VERSION_NUMBER_ID;
            this.selectedCaseVersion[i].case_ID = this.caseVersionListData[n].case_ID;
            this.selectedCaseVersion[i].case_VERSION_ID = this.caseVersionListData[n].case_VERSION_ID;
            this.selectedCaseVersion[i].case_VERSION_NUMBER_ID = this.caseVersionListData[n].case_VERSION_NUMBER_ID;
            this.selectedCaseVersion[i].case_VERSION_TYPE_CD = this.caseVersionListData[n].case_VERSION_TYPE_CD; 
          }
        }
        this.dataSourceRemarkListData[i].status = DsamsConstants.ENT_UNCHANGED.toString();
      } 

        //console.log("this.dataSourceRemarkListData", this.dataSourceRemarkListData);   
      this.dataSourceRemarkTable = new MatTableDataSource(this.dataSourceRemarkListData);
      this.dataSourceRemarkTable._updateChangeSubscription();
      this.isLoading.next(false);
    }          
  },
    err => {
      CaseUtils.ReportHTTPError(err, "Getting Remarks");
      this.isLoading.next(false);
    });

  }

 
}
