import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CaseRemarksPanelComponent } from './case-remarks-panel.component';

describe('CaseRemarksPanelComponent', () => {
  let component: CaseRemarksPanelComponent;
  let fixture: ComponentFixture<CaseRemarksPanelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CaseRemarksPanelComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CaseRemarksPanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
