import {caseVersionInfoModel} from '../case-version-info'

export interface caseVersionInfoDto extends caseVersionInfoModel {

}