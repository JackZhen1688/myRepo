
import { formatDate } from "@angular/common";
import { DsamsConstants } from "src/app/dsams/dsams.constants";
import { remarksDto } from "./dto/case-remarks-dto";

export interface remarksModel {

    entityName?: string;
    status?: string;
    isDataChanged?: boolean;

    case_REMARK_ID?: number,
    case_ID?: number,
    case_VERSION_ID?: number,
    remark_CASE_VERSION_ID?: number,
    remark_CASE_ID?: number,
    case_REMARK_TITLE_NM?: string,
    case_REMARK_TX?: string,
    author_USER_ID?: string,
    case_REMARK_DT?: string,
    lockSessionId?: string,
    create_USER_ID?: string,
    case_Version_Status_CD?: string,
    case_VERSION_TYPE_CD?: string,
    case_VERSION_NUMBER_ID?: string,
    activity_ID?: string,
    person_LAST_NM?: string
}

/** 
  * Prepare Case Remark list data for save
  * @Author: David Huynh
  * @Date: 11/05/2021
  * @Jira Card: 2960
*/
export class prepareCaseRemarkDataForSave {
    theCREntityList: remarksModel[] = [];
    aCREntity: remarksModel = {};
    constructor(pCRList: remarksDto[]) {
        this.theCREntityList = [];
        this.aCREntity = {};
        pCRList.forEach(eachCRDto => {
            if (!!eachCRDto.status && eachCRDto.status !== DsamsConstants.ENT_UNCHANGED.toString()) {
                this.aCREntity = {
                    case_ID: eachCRDto.case_ID,
                    case_REMARK_ID: eachCRDto.case_REMARK_ID ? eachCRDto.case_REMARK_ID : null,
                    remark_CASE_VERSION_ID: eachCRDto.remark_CASE_VERSION_ID ? eachCRDto.remark_CASE_VERSION_ID : null,
                    remark_CASE_ID: eachCRDto.remark_CASE_ID ? eachCRDto.remark_CASE_ID : null,
                    case_REMARK_TITLE_NM: eachCRDto.case_REMARK_TITLE_NM,
                    case_REMARK_TX: eachCRDto.case_REMARK_TX,
                    author_USER_ID: eachCRDto.author_USER_ID,
                    case_REMARK_DT: eachCRDto.case_REMARK_DT ?
                        formatDate(eachCRDto.case_REMARK_DT, "yyyy-MM-dd", "en-US") : null,
                    lockSessionId: this.getCaseRemarkLockSessionId(),
                    status: eachCRDto.status,
                };
                this.theCREntityList.push(this.aCREntity);
            }
        })
    }

    getCaseRemarkLockSessionId(): string {
        let lockId = sessionStorage.getItem(DsamsConstants.SESSION_CASE_REMARK_LOCK_ID);
        if (lockId == null || lockId.length == 0) {
            lockId = '0';
        }
        return lockId;
    }
}