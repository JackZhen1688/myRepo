export interface caseVersionInfoModel {
    case_ID?: number,
    case_VERSION_ID?: number,
    case_VERSION_TYPE_CD?: string,
    case_VERSION_NUMBER_ID?: string
}