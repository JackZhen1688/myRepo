import { remarksModel } from "../case-remarks";

export interface remarksDto extends remarksModel{
    caseCustomerTypeCD?: string,
}
