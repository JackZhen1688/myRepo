import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-menubar-case',
  templateUrl: './menubar-case.component.html',
  styleUrls: ['./menubar-case.component.css']
})
export class MenubarCaseComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
