export interface IOptions {
    id: string;
    label: string;
    disabled: boolean;
    checkMark?: boolean;
  }
  
  export interface ISuboptions {
    id: string;
    label: string;
  }
  
  export interface IShortcuts {
    id: string;
    label: string;
    isDisabled:boolean;
  }

  export interface IOptionConfig {
    visible: boolean;
    disabled: boolean;
  }
  