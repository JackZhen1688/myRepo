import { SaveResultsType } from './save-results-type';
import { DsamsConstants } from '../../dsams.constants';
import { PanelExpansionProperties } from '../model/panel-expansion-properties';
import { CaseCommonValidator } from './case-common-validator';
import { FormControl } from '@angular/forms';
import { NamedFormControl } from './named-form-control';
import { DateValidator } from './date-validator';

export class CaseInfoValidator {

public static validateCaseInfoPanel(pCaseInfo:any, 
                                    pPanelExpansionProperties:PanelExpansionProperties,
                                    pFormControlList:FormControl[],
                                    pCaseCategoryDisabled:boolean):SaveResultsType 
{
    let validateResults:SaveResultsType = new SaveResultsType();
    const isBenefittingCountry:boolean = (pCaseInfo["customer_TYPE_CD"] === "BE");
    const isBenefittingCountryAndHasBPC:boolean = isBenefittingCountry && pCaseInfo["building_PARTNER_CAPACITY_IN"];
    validateResults.currentPanel = DsamsConstants.CASE_PANEL_INFO;

    // Nickname (required for benefitting countries)
    if (isBenefittingCountry && 
        CaseCommonValidator.isBlank(pCaseInfo["case_NICKNAME_NM"])) 
    {
        validateResults.addMessageWithParams("E002", ["Nickname", "Benefitting Countries"]);
    }

    // Document Initiator
    if (CaseCommonValidator.isBlank(pCaseInfo["case_INITIATOR_ACTIVITY_ID"])) {
        validateResults.addMessageWithParams("E001", ["Document Initiator"]);
    }    

    let validateAODCategoryCombo:boolean = true;
    // AOD Group
    if (CaseCommonValidator.isBlank(pCaseInfo["aod_GROUP_CD"]))
    {
        validateAODCategoryCombo = false;
        validateResults.addMessageWithParams("E001", ["AOD Group"]);
    }

    // Case Categry
    if (!pCaseCategoryDisabled && CaseCommonValidator.isBlank(pCaseInfo["case_CATEGORY_CD"]))
    {
        validateAODCategoryCombo = false;
        validateResults.addMessageWithParams("E001", ["Case Category"]);
    }

    // AOD/Categry Combo
    let aodCCErrorMsg: string = "";
    if (validateAODCategoryCombo) {
        if (
            (pCaseInfo["aod_GROUP_CD"] === "A" && pCaseInfo["case_CATEGORY_CD"] === "DO") ||
            ((pCaseInfo["aod_GROUP_CD"] === "B" || pCaseInfo["aod_GROUP_CD"] === "C") && pCaseInfo["case_CATEGORY_CD"] !== "DO")
           )
        {
        aodCCErrorMsg = "E007";
        }

        if (aodCCErrorMsg !== "") {
            validateResults.addMessage(aodCCErrorMsg);
        }
    }
   
    // AOD Date and Offer Expiration Dates
    let namedFormControl:NamedFormControl = null;
    let validationError:string;
    for (let formControl of pFormControlList) {
        namedFormControl = <NamedFormControl>formControl;
        if (!(namedFormControl.name === "OED Date" && pCaseInfo['offer_EXPIRATION_DT'] === pCaseInfo['old_OFFER_EXPIRATION_DT'])) { 
            validationError = DateValidator.DateErrorMessage(namedFormControl) ;
            if (validationError !== DsamsConstants.NO_ERROR) {
                validateResults.addMessageWithParams("E100", [namedFormControl.name, validationError]);
            }
        }
    }

    // *****************************************
    // Customer Service Grid
    // *****************************************
    let refInfo:string;
    let gridRow:number = 1;
    let errCode:string;
    let dupValue:boolean;    
    let numPA:number = 0;

    if (pCaseInfo["caseMasterServiceTypeList"]) {
        let mstList:any = pCaseInfo["caseMasterServiceTypeList"].slice();
        CaseCommonValidator.addUniqueId(mstList);
        for (let mst of mstList) {
            refInfo = "Row " + +gridRow++;            
            if (CaseCommonValidator.isBlank(mst["customer_SERVICE_TYPE_ID"])) {
                validateResults.addMessageWithParams("E001", ["Service Name"], refInfo);
            }

            dupValue = false;
            // Check for dups
            for (let mst2 of mstList) { 
                if (mst[DsamsConstants.UNIQUE_ID_FIELD] !== mst2[DsamsConstants.UNIQUE_ID_FIELD] &&
                    CaseCommonValidator.isEqual(mst["customer_SERVICE_TYPE_ID"], mst2["customer_SERVICE_TYPE_ID"])) 
                {
                    dupValue = true;
                }
            }
            if (dupValue) {
                validateResults.addMessage("E009", refInfo);
            }

            if (!!mst["procuringAgencyIn"] && mst["procuringAgencyIn"]) {
                numPA++;
            }
        }
    }
    // Validate one Procuring Agency checkbox checked.
    if (gridRow > 1 && numPA != 1) {
        validateResults.addMessage("E008");
    }

    // *****************************************
    // Case Manager/Role Grid
    // *****************************************

    gridRow = 1;
    if (pCaseInfo["casePersonnelRoleList"]) {
        let mgrRoleList:any = pCaseInfo["casePersonnelRoleList"].slice();
        CaseCommonValidator.addUniqueId(mgrRoleList);
        for (let mgrRole of mgrRoleList) {
            refInfo = "Row " + +gridRow++;
            if (CaseCommonValidator.isBlankNumber(mgrRole["user_ID"], "user_ID")) {
                if (!(CaseCommonValidator.isBlank(mgrRole["management_ROLE_ID"]))) {
                    if (mgrRole["management_ROLE_ID"] === "CASEMGR") {
                        validateResults.addMessageWithParams("E001", ["Manager for Case Manager Role"], refInfo);
                    }
                    else if (mgrRole["management_ROLE_ID"] === "FINMGR") {
                        validateResults.addMessageWithParams("E001", ["Manager for Financial Role"], refInfo);                    
                    }    
                    else {
                        validateResults.addMessageWithParams("E001", ["Manager"], refInfo);
                    }
                }
                else {
                    validateResults.addMessageWithParams("E001", ["Manager"], refInfo);
                }
            }
            if (CaseCommonValidator.isBlank(mgrRole["management_ROLE_ID"])) {
                validateResults.addMessageWithParams("E001", ["Role"], refInfo);
            }
        }
    }

    // *****************************************
    // Term of Sale grid
    // *****************************************
    
    if (!pCaseInfo["caseSaleTermList"] || pCaseInfo["caseSaleTermList"].length == 0) {       
        validateResults.addMessage("E035");
    }
    else {
        gridRow = 1;
        let cstList:any = pCaseInfo["caseSaleTermList"].slice();

        // Add a unique ID to the array.
        CaseCommonValidator.addUniqueId(cstList);

        let selTermId:string = "";
        for (let saleTerm of cstList) {
            refInfo = "Row " + +gridRow++;
            selTermId = "";
            if (CaseCommonValidator.isBlank(saleTerm["sale_TERM_ID"])) {
                validateResults.addMessageWithParams("E001", ["Sale Term"], refInfo);
            }
            else {
                selTermId = saleTerm["sale_TERM_ID"];
            }

            if (isBenefittingCountry) {
                if (CaseCommonValidator.isBlankNumber(saleTerm["fiscal_YEAR_ID"], "fiscal_YEAR_ID")) {
                    validateResults.addMessage("E010", refInfo);
                }
            }

            if (isBenefittingCountryAndHasBPC) {
                if (CaseCommonValidator.isBlank(saleTerm["public_LAW_ID"])) {
                    validateResults.addMessage("W003", refInfo);
                }
            }

            // Loop within the loop to look for duplicates.
            // Combination of FY, Authroity, and TOS must be unique.
            errCode = "";
            for (let saleTerm2 of cstList) {
                if (saleTerm[DsamsConstants.UNIQUE_ID_FIELD] !== saleTerm2[DsamsConstants.UNIQUE_ID_FIELD] &&
                    CaseCommonValidator.isEqual(saleTerm["sale_TERM_ID"], saleTerm2["sale_TERM_ID"]) &&
                    CaseCommonValidator.isEqual(saleTerm["public_LAW_ID"], saleTerm2["public_LAW_ID"]) &&
                    CaseCommonValidator.isEqual(saleTerm["fiscal_YEAR_ID"], saleTerm2["fiscal_YEAR_ID"]))
                {                        
                    errCode = (CaseCommonValidator.isBlankNumber(saleTerm["fiscal_YEAR_ID"], "fiscal_YEAR_ID") &&  
                               (saleTerm["sale_TERM_ID"] === "Q" || saleTerm["sale_TERM_ID"] === "F"))
                            ?"E006":"E005";
                } 
            }
            if (errCode !== "") {
                validateResults.addMessage(errCode, refInfo);
            }

            // Term of Sale Amount
            if (selTermId === "F" || selTermId === "Z"  || selTermId === "M" || selTermId === "N" || selTermId === "P" || selTermId === "Y" || selTermId === "Q") {
                if (CaseCommonValidator.isBlankNumber(saleTerm["case_SALE_TERM_AM"], "case_SALE_TERM_AM")) {
                    validateResults.addMessageWithParams("E001", ["Sale Term Amount"], refInfo);
                }    
            }
        }
    }

    return validateResults;
}

}