import { PanelExpansionProperties } from '../model/panel-expansion-properties';
import { SaveResultsType } from './save-results-type';
import { DsamsConstants } from '../../dsams.constants';
import { CaseCommonValidator } from './case-common-validator';

export class CaseAssociationsValidator {
    public static validateAssociationsPanel(pRelatedCaseData:any,
                                            pAssociatedCaseData:any,
                                            pPanelExpansionProperties:PanelExpansionProperties):SaveResultsType 
    {
        let validateResults:SaveResultsType = new SaveResultsType();
        validateResults.currentPanel = DsamsConstants.CASE_PANEL_ASSOCIATIONS;
        const FIELD_USER_CASE_ID:string = "user_CASE_ID";
        const FIELD_CUST_ORG:string = "customer_ORGANIZATION_ID";
        const FIELD_IA:string = "implementing_AGENCY_ID";
        const FIELD_CASE_DESIGNATOR:string = "case_DESIGNATOR_CD";
        const FIELD_RATIONALE_TX:string = "associated_CASE_RATIONALE_TX";        

        // If no assocations and no waivers, success!
        if ((!pRelatedCaseData || pRelatedCaseData.length == 0) && 
            (!pAssociatedCaseData || pAssociatedCaseData.length == 0)) 
        {
            return validateResults; 
        }

        // Check associations
        // Mandatory fields.
        let refInfo:string = "";
        let gridRow:number = 1;
        for (let currAC of pAssociatedCaseData) {
            refInfo = "Row " + +gridRow;
            // Check required fields.
            if (CaseCommonValidator.isBlank(currAC[FIELD_USER_CASE_ID])) { 
                validateResults.addMessageWithParams("E001", ["Associated User Case ID"], refInfo);
            }            
            if (CaseCommonValidator.isBlank(currAC[FIELD_RATIONALE_TX])) {                
                validateResults.addMessageWithParams("E001", ["Associated Case Rationale"], refInfo);
            }             
            // Check other functionality.
            if (!(CaseCommonValidator.isBlank(currAC[FIELD_USER_CASE_ID])) && currAC[FIELD_USER_CASE_ID].length < 6) {
                validateResults.addMessage("E023", refInfo);
            }
            else {
                currAC[FIELD_CUST_ORG] = currAC[FIELD_USER_CASE_ID].substr(0, 2);
                currAC[FIELD_IA] = currAC[FIELD_USER_CASE_ID].substr(2, 1);
                currAC[FIELD_CASE_DESIGNATOR] = currAC[FIELD_USER_CASE_ID].substr(3, 5);
                if (currAC[FIELD_IA] === pPanelExpansionProperties.caseRequestParams.implementingAgencyId) {
                    validateResults.addMessage("E024", refInfo);
                }
                // Check if cust org is a pseudo-country
                if (currAC[FIELD_CUST_ORG] === "X1" ||
                    currAC[FIELD_CUST_ORG] === "X2" ||
                    currAC[FIELD_CUST_ORG] === "X3" ||
                    currAC[FIELD_CUST_ORG] === "X4" ||
                    currAC[FIELD_CUST_ORG] === "X5" ||
                    currAC[FIELD_CUST_ORG] === "X6" ||
                    currAC[FIELD_CUST_ORG] === "X7" ||
                    currAC[FIELD_CUST_ORG] === "X8" ||
                    currAC[FIELD_CUST_ORG] === "X9" ||
                    currAC[FIELD_CUST_ORG] === "XX" ||
                    currAC[FIELD_CUST_ORG] === "XY" ||
                    currAC[FIELD_CUST_ORG] === "YY")
                {
                    validateResults.addMessage("E025", refInfo);
                }
            }
            gridRow++;
        }
        return validateResults;
    }

}