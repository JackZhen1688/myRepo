import { SaveResultsType } from './save-results-type';
import { PanelExpansionProperties } from '../model/panel-expansion-properties';
import { DsamsConstants } from '../../dsams.constants';

/**
 * Validator class for Case Description panel.
 * 
 * @author CBanta
 */
export class CaseDescriptionValidator {
    public static validateDescriptionPanel(pDescriptionData:any, 
                                           pPanelExpansionProperties:PanelExpansionProperties,                                           
                                           pErrorMessageList:string[]):SaveResultsType 
    {
        let validateResults:SaveResultsType = new SaveResultsType();
        validateResults.currentPanel = DsamsConstants.CASE_PANEL_DESCRIPTIONS;
        for (let errMsg of pErrorMessageList) {
          if (errMsg !== DsamsConstants.NO_ERROR && errMsg !== "EUNK") {
            validateResults.addMessage(errMsg);
          }
        }
        return validateResults;
    }
}