import { MessageType } from './message-type';

/**
 * This interface contains the details about a message, such as the type (warning , error, info), 
 * what panel it's on, if there's reference info associated with it.
 * This is used for displaying to the user.
 * 
 * @author CBanta
 */
export interface MessageDetail {
    message: MessageType,
    reference: string,
    panel: string,
    params: string[]
}