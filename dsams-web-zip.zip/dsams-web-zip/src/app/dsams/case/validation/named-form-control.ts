import { FormControl, ValidatorFn, AbstractControlOptions, AsyncValidatorFn } from '@angular/forms';

/**
 * This is like a FormControl, but it allows you to specify a name so 
 * that you can find out what form fields have issues come validation/save time.
 * 
 * Author: CBanta
 */
export class NamedFormControl extends FormControl {
    private _name:string = "";

    public get name():string {
        return this._name;
    }

    constructor(pName:string, formState?: any, validatorOrOpts?: ValidatorFn | ValidatorFn[] | AbstractControlOptions, asyncValidator?: AsyncValidatorFn | AsyncValidatorFn[]) {        
        super(formState, validatorOrOpts, asyncValidator);
        this._name = pName;
    }
}