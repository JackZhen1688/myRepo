import { SaveResultsType } from './save-results-type';
import { PanelExpansionProperties } from '../model/panel-expansion-properties';
import { DsamsConstants } from '../../dsams.constants';

/**
 * Validator class for Case Customer Request panel.
 * 
 * @author CBanta
 */
export class CaseDocumentRequirementsValidator {
    public static validateDocumentRequirementsPanel(pDocumentRequirementsData:any, 
                                                   pPanelExpansionProperties:PanelExpansionProperties,
                                                   pErrorMessageList:string[]):SaveResultsType 
    {
        let validateResults:SaveResultsType = new SaveResultsType();
        validateResults.currentPanel = DsamsConstants.CASE_PANEL_DOCUMENT_REQUIREMENTS;

        // Validate MTDS
        if (pDocumentRequirementsData["manpower_TRAVEL_DATA_CD"] == null || 
            pDocumentRequirementsData["manpower_TRAVEL_DATA_CD"] === 0) 
        {
            validateResults.addMessage("E019");
        }
        
        // Check MTDS Priced
        if (pDocumentRequirementsData["mtds_PRICED"] && pDocumentRequirementsData['manpower_TRAVEL_DATA_CD'] !== 1) {
            validateResults.addMessage("E063");
        }

        return validateResults;
    }
}