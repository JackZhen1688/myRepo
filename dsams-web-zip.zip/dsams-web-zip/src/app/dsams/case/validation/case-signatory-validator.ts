import { SaveResultsType } from './save-results-type';
import { PanelExpansionProperties } from '../model/panel-expansion-properties';
import { DsamsConstants } from '../../dsams.constants';
import { CaseCommonValidator } from './case-common-validator';

/**
 * Validator class for Case Signatories panel.
 * 
 * @author CBanta
 */
export class CaseSignatoryValidator {
    public static validateSignatoriesPanel(pSignatoriesData:any, 
                                           pPanelExpansionProperties:PanelExpansionProperties,
                                           pErrorMessageList:string[]):SaveResultsType 
    {
        let validateResults:SaveResultsType = new SaveResultsType();
        validateResults.currentPanel = DsamsConstants.CASE_PANEL_SIGNATORIES;

        // Check that signatory name and activity are present.
        if (CaseCommonValidator.isBlank(pSignatoriesData["activity_ID"])) {
          validateResults.addMessageWithParams("E001", ["MILDEP Signatory Activity"]);
        }
        if (CaseCommonValidator.isBlank(pSignatoriesData["mildep_PERSON_NM"])) {
          validateResults.addMessageWithParams("E001", ["MILDEP Signatory Name"]);
        }        

        let refInfo:string = "";
        let gridRow:number = 1;
        if (pSignatoriesData["caseDistributionList"]) {
          for (let cdlItem of pSignatoriesData["caseDistributionList"]) {
            refInfo = "Row " + +gridRow++;  
            let numThingsEntered:number = 0;  
            // console.log("act=" + cdlItem["activity_ID"] + " uid=" + cdlItem["user_ID"] + " tx=" + cdlItem["case_DISTRIBUTION_LIST_TX"]);
            if (!(CaseCommonValidator.isBlank(cdlItem["activity_ID"]))) {
              numThingsEntered++;
            }
            if (!(CaseCommonValidator.isBlank(cdlItem["user_ID"])) && cdlItem["user_ID"] !== 0) {
              numThingsEntered++;
            }
            if (!(CaseCommonValidator.isBlank(cdlItem["case_DISTRIBUTION_LIST_TX"]))) {
              numThingsEntered++;
            }            
            if (numThingsEntered != 1) {
              validateResults.addMessage("E050", refInfo); 
            }
          }        
        }

        return validateResults;
    }
}