import { AbstractControl } from '@angular/forms';
import { DsamsConstants } from '../../dsams.constants';
import { NamedFormControl } from './named-form-control';
import { CaseUtils } from '../utils/case-utils';

/**
 * This class contains validations to make sure the user enters valid dates on the UI.
 * 
 * @author CBanta
 */

export class DateValidator {

/**
 * Verifies if the date is greater that or equal to Sysdate.
 * Returns null if valid, otherwise it returns the key-string map indicating an error.
 * @param control FormControl of the date field on the UI.
 */    
public static validateDateGESysdate(control: AbstractControl|string|Date): {[key: string]: any} | null  
{
    let enteredDate:Date = null;
    if (control instanceof AbstractControl) {
        if (control.value == null || control.value === "") {
            return null;
        }        
        enteredDate = new Date(control.value);
    }
    else if (control instanceof Date) {
        if (control == null) {
            return null;
        }        
        enteredDate = control;
    }
    else {  // string
        if (control === "") {
            return null;
        }        
        enteredDate = new Date(control);
    }
    
    // Check date GE Sysdate.
    const todaysDate:Date = new Date();
    const enteredDateFmt:string = CaseUtils.formatDateForComparison(enteredDate);
    const todysDateFmt:string = CaseUtils.formatDateForComparison(todaysDate);

    if (enteredDateFmt < todysDateFmt) {
        return { 'DateNotGESysdate': true };
    }
    return null;
}


/**
 * Converts a date object to a string in the proper format.
 * @param pDate Date to convert to a string in MM/DD/YYYY format.
 */
public static dateToString(pDate:Date):string {
    if (!pDate) {
        return "";
    }
    const realDate:Date = CaseUtils.numberToDate(pDate);   // In case value coming is is really a number disguised as a date.
    let day: string = realDate.getDate().toString();
    day = +day < 10 ? '0' + day : day;
    let month: string = (realDate.getMonth() + 1).toString();
    month = +month < 10 ? '0' + month : month;
    let year = realDate.getFullYear();
    return `${month}/${day}/${year}`;
}

/**
 * Converts a date object to a string in YYYY-MM-DD format.
 * @param pDate Date to convert to a string in YYYY-MM-DD format.
 */
 public static dateToString2(pDate:Date):string {
    if (!pDate) {
        return "";
    }
    const realDate:Date = CaseUtils.numberToDate(pDate);   // In case value coming is is really a number disguised as a date.
    let day: string = realDate.getDate().toString();
    day = +day < 10 ? '0' + day : day;
    let month: string = (realDate.getMonth() + 1).toString();
    month = +month < 10 ? '0' + month : month;
    let year = realDate.getFullYear();
    return `${year}-${month}-${day}`;
}

/**
 * Check if a date is valid from the 
 */
public static isItADate(pDateStr:string):boolean {
    // If blank, then it's a date.
    if (pDateStr === "") {
        return true;
    }    
    const testDate:Date = new Date(pDateStr);    
    if (!testDate||isNaN(testDate.getDate())) {
        return false;
    }
    return true;
}


/**
 * This is a placeholder method to make sure the user enters a valid date on the UI.
 * It is needed here although it is validated automatically on the UI.
 * @param control Control UI field in the template.
 */
public static validateRegularDate(control: AbstractControl): {[key: string]: any} | null  
{
    // Date is validated automatically within the control.
    // No need to do anything else.
    return null;
}

/**
 * This obtains the error message for use on the UI's validator for a date field.
 * @param pFormControl NamedFormControl (like a FormControl but with a name) of the UI element.
 */
public static DateErrorMessage(pFormControl: NamedFormControl): string {
    if (pFormControl.hasError('DateNotGESysdate')) {
       return 'Date cannot be less than today\'s date.';
    }
    else if (pFormControl.hasError('matDatepickerParse')) {
        return "Date is invalid.";
    }
    else if (pFormControl.hasError('required')) {
        return "Field is required.";
    }
    else  {
       return DsamsConstants.NO_ERROR;
    }
  }    
}