import { PanelExpansionProperties } from '../model/panel-expansion-properties';
import { SaveResultsType } from './save-results-type';
import { DsamsConstants } from '../../dsams.constants';
import { CaseCommonValidator } from './case-common-validator';
import { DateValidator } from './date-validator';

/**
 * Validator class for Case Waivers panel.
 * 
 * @author CBanta
 */
export class CaseWaiversValidator {
    public static validateCustomerRequestPanel(pCaseVersionWaiverData:Array<any>, 
                                               pPanelExpansionProperties:PanelExpansionProperties):SaveResultsType 
    {
        let validateResults:SaveResultsType = new SaveResultsType();
        validateResults.currentPanel = DsamsConstants.CASE_PANEL_WAIVERS;
        if (!pCaseVersionWaiverData || pCaseVersionWaiverData.length == 0) {
            return validateResults;  // Returns blank validation if no rows.
        }        
        let refInfo:string = "";
        let gridRow:number = 1;
        for (let currCVW of pCaseVersionWaiverData) {
            refInfo = "Row " + +gridRow;
            // Waiver Type is required.
            if (CaseCommonValidator.isBlank(currCVW["waiver_TYPE_ID"])) {                
                validateResults.addMessageWithParams("E001", ["Waiver Type"], refInfo);
            }
            // IPC required-ness
            if (CaseCommonValidator.isBlank(currCVW["ipc_NUMBER_ID"]) && <boolean>(currCVW["br_IPC_REQUIRED"])) {
                validateResults.addMessage("E020", refInfo);
            }

            // Check percent rate
            let pctRateStr:number = currCVW["case_WAIVER_PERCENT_RT_shadow"];
            let pctRate:number = +pctRateStr;
            if (pctRate < 0 || pctRate > 100) {
                validateResults.addMessageWithParams("E032", ["Percent Rate", "0", "100"], refInfo);
            }
            
            // Check dates
            let isNew:boolean = currCVW["isNew"];
            let dateChanged:boolean = isNew || 
                    (DateValidator.dateToString(currCVW["case_VERSION_WAIVER_EFFECT_DT"]) !== DateValidator.dateToString(currCVW["case_VERSION_WAIVER_EFFECT_DT_orig"])) ||
                    (DateValidator.dateToString(currCVW["case_VERSION_WAIVER_EXPIRAT_DT"]) !== DateValidator.dateToString(currCVW["case_VERSION_WAIVER_EXPIRAT_DT_orig"]));

            // Check date valid-ness.
            let effDateStr:string = currCVW["case_VERSION_WAIVER_EFFECT_DT"];
            let effDateValid: boolean = false;
            let expDateStr:string = currCVW["case_VERSION_WAIVER_EXPIRAT_DT"];
            let expDateValid: boolean = false;

            // Check effective date present and validity.
            if (dateChanged && CaseCommonValidator.isBlank(effDateStr) && currCVW["waiver_TYPE_ID"] !== "1") {
                validateResults.addMessageWithParams("E001", ["Waiver Effective Date"], refInfo);
            }
            else if (!DateValidator.isItADate(effDateStr)) {
                 validateResults.addMessageWithParams("E030", ["Waiver Effective"], refInfo);
            }
            else {
                effDateValid = true;
            }

            // Check expiration date validity.
            if (!DateValidator.isItADate(currCVW["case_VERSION_WAIVER_EXPIRAT_DT_shadow"])) {
                validateResults.addMessageWithParams("E030", ["Waiver Expiration"], refInfo);
            }
            else {
                expDateValid = true;
            }

            // Check expiration date.
            if (!(CaseCommonValidator.isBlank(expDateStr)) && expDateValid) {
                let expDt: Date = new Date(expDateStr);
                if (dateChanged && !!DateValidator.validateDateGESysdate(expDt)) {
                    validateResults.addMessage("E021", refInfo);
                }
                if (dateChanged && effDateValid && !(CaseCommonValidator.isBlank(effDateStr))) {
                    let effDt: Date = new Date(effDateStr);
                    if (effDt > expDt) {
                        validateResults.addMessage("E022", refInfo);
                    }
                }
            }

            gridRow++;
        }
        return validateResults;
    }
}