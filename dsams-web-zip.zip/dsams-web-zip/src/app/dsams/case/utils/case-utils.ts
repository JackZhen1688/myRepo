
import { HttpErrorResponse } from '@angular/common/http';
import { throwError } from 'rxjs';
import { ReferenceDataType } from '../model/reference-data-type';
import { FieldDisabledMap } from '../model/field-disabled-map';
import { DsamsConstants } from '../../dsams.constants';
import { formatCurrency } from '@angular/common';
import { FormGroup } from '@angular/forms';
import { MessageMgr } from '../validation/message-mgr';
import { ICaseVersion } from '../model/dto/icase-version';
import { CaseRequestParamsType } from '../model/search-params/case-request-params-type';
import { ICaseVersionMilestone } from '../model/dto/case-version-milestone';
import { ICaseMilestoneRevision } from '../model/dto/case-milestone-revision';

export class CaseUtils {
    public static theRefCustomerOrganizationList: Array<ReferenceDataType> = [];
    public static theRefCaseUsageIndList : Array<ReferenceDataType> = [];
    
    static readonly CaseMasterStatusPendingType = "P";
    static readonly CaseMasterStatusOpenType = "N";
    static readonly CaseMasterStatusClosedType = "C";
    static readonly CaseMasterStatusCancelledType = "X";
    static readonly CaseVersionBasicType = "B";
    static readonly CaseVersionModType = "M";
    static readonly CaseVersionRevisionType = "R";
    static readonly CaseVersionAmendmentType = "A";
    static readonly CaseVersionStatusOfferedType = 'O';
    static readonly CaseVersionStatusDevelopmentType = "D";
    static readonly CaseVersionStatusAcceptedType = "A";
    static readonly CaseVersionStatusImplementedType = "I";
    static readonly CaseVersionStatusProposedType = "P";
    static readonly CaseVersionStatusReviewType = "R";
    static readonly CaseVersionStatusWritingType = "W";
    static readonly CaseVersionStatusCaseClosedType = "CL";
    static readonly CaseVersionStatusCaseCancelledType = "X";
    static readonly CaseVersionUpdateImplementedCaseType = "I";
    static readonly CaseVersionPlanningType = "P";
    static readonly CaseVersionLoiType = "L";
    static readonly CaseVersionModelType = "M";

    static filterLength: any;
    static showChangeCountryOption: boolean;
    static isS1DescriptionUpdatable: boolean;


    /**
     * Takes a string (obtained from a generic object) and converts it to a date.
     * @param pDateStr String you want to convert to a date field.
     */
    public static toDate(pDateStr: string): string | Date {
        if (pDateStr !== null) {
            return new Date(pDateStr);
        }
        return pDateStr;
    }

    /**
     * This function will convert a date (in milliseconds) to a date that can be dispaled on the UI.
     * @param pDateNum Number of milliseconds. Needs to also be or-Date to avoid compilation errors.
     * @returns Date object 
     */
    public static numberToDate(pDateNum: number | Date): Date {
        if (typeof pDateNum === 'number') {
            if (pDateNum == 0) {
                return null;
            }
            return new Date(new Date(pDateNum).toUTCString());
        }
        return pDateNum;  // If type is Date
    }

        /**
     * Determine if a date is greater than or equal to sysdate.
     * return false if null.
     */
    public static isLTSysdate(pDateStr: string):boolean {
    if (!pDateStr || pDateStr == "") {
        return false;
    }
    const theDateStr:string = CaseUtils.formatDateForComparison(<Date>(CaseUtils.toDate(pDateStr)));
    const sysdateStr:string = CaseUtils.formatDateForComparison(new Date());
    return theDateStr < sysdateStr;
}

    /**
     * Convert a string to boolean 
     * @param pValue String we are looking to convert to a boolean.
     * @returns true if value is "true", otherwise false.
     */
    public static strToBoolean(pValue: string): boolean {
        return (pValue === "true");
    }

     /**
     * Convert a string to boolean 
     * @param pValue String we are looking to convert to a boolean (as a 1 or 0).
     * @returns true if value is "1", otherwise false.
     */
     public static strToBoolean2(pValue: string): boolean {
        return (!!pValue && pValue === "1");
     }
    

    /**
     * Get a business rule map value for a given key.
     * @param pMapObj Map object (somethingData.businessRuleMap)
     * @param pKey Key for the object we want to retrieve.
     * @param pDefaultValue Default value to return if there object map is not there.
     * @returns string, number, or boolean value at the specified key. 
     */
    public static getBusinessRuleMapValue(pMapObj: Object,
        pKey: string,
        pDefaultValue: string | number | boolean): string | number | boolean {
        // First conver the object to a map.
        let tsMap = new Map();

        // If the map key is not found, return the default object.
        if (!pMapObj || !(Object.keys(pMapObj))) {
            return pDefaultValue;
        }

        Object.keys(pMapObj).forEach(key => {
            tsMap.set(key, pMapObj[key]);
        });

        const mapVal: string = tsMap.get(pKey);
        // If not found
        if (!mapVal) {
            return "";
        }
        // Numeric
        if (!(Number.isNaN)) {
            return Number(mapVal);
        }
        else if (mapVal === "true" || mapVal === "false") {
            // boolean
            return (mapVal === "true");
        }
        return mapVal;
    }

    /**
     * Determine if a string is numeric. 
     * Blank or null means not numeric.
     * @param pValue Value we want to see if is a number. 
     */
    public static isNumeric(pValue: string): boolean {
        return ((pValue != null) && (pValue !== '') && !isNaN(Number(pValue)));
    }

    /**
     * Converts a field of generic type into an array.
     * Used when we know something is a generic object is an array.
     * @param pField Generic field we want to convert to an array.
     */
    public static toArray(pField: any): any[] {
        if (pField !== null) {
            return <Array<any>>pField;
        }
        return <Array<any>>[];   // Empty array if null.
    }

    /**
     * Report an error by logging it or showing it to the user.
     * @param pMessage Error message.
     */
    public static ReporError(pMessage: string): void {
        console.log(pMessage);
    }

    /**
     * Report an HTTP (REST API) error by logging it or showing it to the user.
     * @param pMessage Error message.
     */
     public static ReportHTTPError(pError: any, pMessage: string): void {
        let displayMsg: string = "HTTP Error in " + pMessage + ": ";
        if (pError instanceof HttpErrorResponse) {
            displayMsg += pError.message;
            MessageMgr.displayError(pMessage, pError);
        }
        else {
            displayMsg += "Unknown";
        }
        throwError(displayMsg);
    }

    // Fetch the ReferenceDataType value from an array based on the key value selected.
    /**
     * Find the ReferenceDataType object corresponding to the row in the array with KEY_VALUE=pKeyValue.
     * @param pRefDataTypeList Reference Data Type array
     * @param pKeyValue Key value we want to select on.
     * @Returns The ReferenceDataType object corresponding to the row in the array with KEY_VALUE=pKeyValue. Null if not found.
     */
    public static fetchRefereneDataTypeByValue(pRefDataTypeList: Array<ReferenceDataType>, pKeyValue: string): ReferenceDataType {
        let refDataType: ReferenceDataType = null;

        const numericCompare: boolean = CaseUtils.isNumeric(pKeyValue);
        let compareNum: number;
        if (numericCompare) {
            compareNum = Number(pKeyValue);
        }

        for (var currRDT of pRefDataTypeList) {
            if (numericCompare) {
                const listNumericCompare: boolean = CaseUtils.isNumeric(currRDT.key_FIELD);
                if (listNumericCompare && Number(currRDT.key_FIELD) == compareNum) {
                    refDataType = currRDT;
                }
            }
            else if (currRDT.key_FIELD === pKeyValue) {
                refDataType = currRDT;
            }
        }
        return refDataType;
    }

    /**
     * Fixup a ReferenceDataType array by converting null values into blank strings.
     * @param pRefDataTypeList ReferenceDataType array we need to fixup.
     * @retunrs The array all fixed up.
     */
    public static fixupReferenceDataList(pRefDataTypeList: Array<ReferenceDataType>): Array<ReferenceDataType> {
        let newRDT = pRefDataTypeList;
        for (var currRDT of newRDT) {
            if (currRDT.field_1 === null) {
                currRDT.field_1 = "";
            }
            if (currRDT.field_2 === null) {
                currRDT.field_2 = "";
            }
            if (currRDT.field_3 === null) {
                currRDT.field_3 = "";
            }
            if (currRDT.field_4 === null) {
                currRDT.field_4 = "";
            }
            if (currRDT.field_5 === null) {
                currRDT.field_5 = "";
            }
        }
        return newRDT;
    }

    /**
     * Print today's date on the screen with the proper date format.
     * @returns String representing today's date in format you can show on the UI.
     */
    public static todaysDateForDisplay(): string {
        const todaysDate: Date = new Date();
        const todaysDateFormatted: string = ('0' + (+todaysDate.getMonth() + 1)).slice(-2) +
            '/' + ('0' + +todaysDate.getDate()).slice(-2) +
            '/' + +todaysDate.getFullYear();
        return todaysDateFormatted;
    }

    /**
     * Format a date for comparison purposes (YYYY-MM-DD format).
     * @param pDate Date we want to format as a string for comparison purposes.
     * @returns String representing today's date in format you want to use for comparison purposes.
     */
    public static formatDateForComparison(pDate: Date): string {
        return +pDate.getFullYear() + "-" +
            ('0' + (+pDate.getMonth() + 1)).slice(-2) + "-" +
            ('0' + +pDate.getDate()).slice(-2);
    }

    /**
     * Format a date for Legacy data calls (DD-MMM-YYYY format).
     * @param pDate Date we want to format.
     * @returns String representing date format for Legacy data calls.
     */
     public static formatDateForLegacy(pDate: Date): string {
        let monthNames =["JAN","FEB","MAR","APR",
                        "MAY","JUN","JUL","AUG",
                        "SEP", "OCT","NOV","DEC"];
        
        let day = String(pDate.getDate()).padStart(2, '0');
        let monthIndex = pDate.getMonth();
        let monthName = monthNames[monthIndex];
        let year = pDate.getFullYear();
    
        return (day + '-' + monthName + '-' + year)
    }

    /**
     * Determine if a field on the UI will be disabled based on the field disabled map.
     * The FieldDisabledMap is populated on the UI based on business logic.
     * @param pFieldMap FieldDsiabledMap object containing a map of fields and panels, and whether eor not they're disabled.
     * @param pPanelName Panel Name (corresponding to what's in the FieldDsiabledMap)
     * @param pFieldName Field ID/Name (corresponding to what's in the FieldDsiabledMap).
     * @returns true if the field is to be disabled on the UI, false if not.
     */
    public static isFieldDisabled(pFieldMap: FieldDisabledMap, pPanelName: string, pFieldName: string): boolean {
        // If all case panels are disabled, then the field is disabled.
        if (!!(pFieldMap[DsamsConstants.CASE_PANEL_ALL]) && pFieldMap[DsamsConstants.CASE_PANEL_ALL]) {
            return true;
        }
        // Check panel-wide (case-info panel)
        if (pPanelName === DsamsConstants.CASE_PANEL_INFO) {
            if (!!(pFieldMap[DsamsConstants.CASE_PANEL_INFO]) && pFieldMap[DsamsConstants.CASE_PANEL_INFO]) {
                return true;
            }
        }

        // Check panel-wide (customer-request panel)
        if (pPanelName === DsamsConstants.CASE_PANEL_CUSTOMER_REQUEST) {
            if (!!(pFieldMap[DsamsConstants.CASE_PANEL_CUSTOMER_REQUEST]) && pFieldMap[DsamsConstants.CASE_PANEL_CUSTOMER_REQUEST]) {
                return true;
            }
        }

        // Check panel-wide (document-requirements panel)
        if (pPanelName === DsamsConstants.CASE_PANEL_DOCUMENT_REQUIREMENTS) {
            if (!!(pFieldMap[DsamsConstants.CASE_PANEL_DOCUMENT_REQUIREMENTS]) && pFieldMap[DsamsConstants.CASE_PANEL_DOCUMENT_REQUIREMENTS]) {
                return true;
            }
        }

        // Check panel-wide (descriptions panel)
        if (pPanelName === DsamsConstants.CASE_PANEL_DESCRIPTIONS) {
            if (!!(pFieldMap[DsamsConstants.CASE_PANEL_DESCRIPTIONS]) && pFieldMap[DsamsConstants.CASE_PANEL_DESCRIPTIONS]) {
                return true;
            }
        }

        // Check panel-wide (signatories panel)
        if (pPanelName === DsamsConstants.CASE_PANEL_SIGNATORIES) {
            if (!!(pFieldMap[DsamsConstants.CASE_PANEL_SIGNATORIES]) && pFieldMap[DsamsConstants.CASE_PANEL_SIGNATORIES]) {
                return true;
            }
        }

        // Check panel-wide (associations panel)
        if (pPanelName === DsamsConstants.CASE_PANEL_ASSOCIATIONS) {
            if (!!(pFieldMap[DsamsConstants.CASE_PANEL_ASSOCIATIONS]) && pFieldMap[DsamsConstants.CASE_PANEL_ASSOCIATIONS]) {
                return true;
            }
        }

        // Check panel-wide (waivers panel)
        if (pPanelName === DsamsConstants.CASE_PANEL_WAIVERS) {
            if (!!(pFieldMap[DsamsConstants.CASE_PANEL_WAIVERS]) && pFieldMap[DsamsConstants.CASE_PANEL_WAIVERS]) {
                return true;
            }
        }

        // If no panel-wide or global field disabling, check the disabling at the field level.
        if (!!(pFieldMap[pFieldName])) {
            return pFieldMap[pFieldName];
        }

        // Not disabled or not in the FieldDisabledMap, so return false (not disabled).
        return false;
    }

    /* This function is used to format the string amount to US currency string representation
    Author: David Huynh
    Date: 09/22/20 
   */
    public static getUSCurrency(pValue: string): string {
        if (!!pValue && pValue !== 'N/A') return formatCurrency(parseFloat(pValue), 'en', '$')
        return ("$0.00")
    }

    /**
    * These functions unformat currency so that it can be sent over the wire as a number (no $ or commas)
    */
    public static unformatCurrency(pValue: string | number): number {
        if (CaseUtils.isBlankStr(pValue)) {
            return 0;
        }
        return +(pValue.toString().split(",").join("").split("$").join(""));
    }
    
    /**
     * Replace everything except digits.
     */
    public static replaceEverythingExceptDigits(pNumber:string):string {
        return pNumber.replace(/\D+/g, '');
    }

    /**
     * Format a number by removing subsequent decimal places.
     */
     public static fixupNumber(pNumber:string):string {
         let numStr:string = pNumber.replace('.', '%FD%')       // replace first occurrence of decimal point (placeholder)
                                    .replace(/\./g, '')         // now replace all but first occurrence (refer to above)
                                    .replace(/%FD%(0+)?$/, '')  // remove placeholder if not necessary at end of string
                                    .replace('%FD%', '.');      // otherwise, replace placeholder with period
        // If there are minus signs, move them to the first position.
        if (numStr.indexOf("-") >= 0) {
            numStr = "-" + numStr.replace(/-/g, "");
        }
        return numStr;
    }

    /* This function is used to convert N/A string to 
       empty string representation if applicable.
       Author: David Huynh
       Date: 09/09/20 
    */
    public static convertNAStrToBlank(attr: any): string {
        //a simple string conversion to deal with N/A value
        if ((attr as string) !== null && (attr as string) !== undefined)
            if ((attr as string) == 'N/A')
                return '';
        return attr;
    }

    /* This function is used to convert NULL string to 
       'N/A' string representation.
       Author: David Huynh
       Date: 05/15/20 
    */
    public static convertNullStrToNA(attr: any): string {
        //a simple string conversion to deal with null value
        if ((attr as string) == null || (attr as string) == undefined)
            return 'N/A'
        return (attr ? attr as string : 'N/A');
    }

    /* This function is used to convert NULL string to 
       '0' string representation.
       Author: David Huynh
       Date: 05/22/20 
   */
    public static convertNullStrToZero(attr: any): string {
        //a simple string conversion to deal with null value
        if ((attr as string) == null ||
            (attr as string) == undefined ||
            (attr as string) == 'N/A')
            return '0'
        return (attr ? attr as string : '0');
    }

    /* This function is used to convert a string to mask 
       the user case ID string.
       Author: David Huynh
       Date: 05/15/20 
    */
    public static formatUserCaseId(attr: any): string {
        const str: string = (attr as string);
        if (str.indexOf("-") >= 0) {
            return str;
        }
        //a simple string conversion to format string
        // to DSAMS user case id string
        return str.substring(0, 2) + '-' + str.substring(2, 3) + '-' + str.substring(3);
    }

    /* This function is used to convert a string to mask 
       the user case ID string.
       Author: CBanta
       Date: 01/11/21
    */
    public static formatUserCaseIdForChangeCountry(uCaseid: string, custOrgId: string): string {
        return custOrgId + uCaseid.substring(2, 8);
    }

    /**
     * Unformat the user case Id by removing the dashes.
     */
    public static unformatUserCaseId(attr: any): string {
        const str: string = (attr as string);
        return str.replace(/-/g, "");
    }

    /**
     * Repopulate the CaseRequestParamsType from the iCaseVersion.
     * This is necessary if the caseRequestParams only consists of a caseId and caseVersionId,
     * such as if it's a link that's clicked.
     */
    public static populateCaseRequestParamsType(pCaseRequestParams: CaseRequestParamsType, pCaseVersion: ICaseVersion) {
        if (pCaseRequestParams.caseId > 0) {
            pCaseRequestParams.customerOrganizationId = pCaseVersion.theCaseId.customer_ORGANIZATION_ID;
            pCaseRequestParams.caseVersionTypeCd = pCaseVersion.case_VERSION_TYPE_CD;
            pCaseRequestParams.securityAssistanceProgramCd = pCaseVersion.theCaseId.security_ASSISTANCE_PROGRAM_CD;
            pCaseRequestParams.implementingAgencyId = pCaseVersion.theCaseId.implementing_AGENCY_ID;
            pCaseRequestParams.customerRequestId = pCaseVersion.customer_REQUEST_ID;
        }
    }

    /** 
      This function will parse the ID from an ID and description combo.
     */
    public static parseOutID(pValue: string): string {
        if (pValue === "") {
            return "";
        }
        const dashPos: number = pValue.indexOf("-");
        if (dashPos < 0) {
            return pValue;
        }
        return pValue.substr(0, dashPos - 1).trim();
    }

    /* This function is used to prefix zero to the user  
       case line ID string. 
       Author: David Huynh
       Date: 08/15/20 
    */
    public static formatLineNumber(lineNumber: any): string {
        if (lineNumber.toString().length == 1)
            return ("00" + lineNumber.toString());
        else if (lineNumber.toString().length == 2)
            return ("0" + lineNumber.toString());
        return lineNumber.toString();
    }

    /*
    * Get the current service DB ID selected by the user.
    * If no such database was selected (aka no choice offered)
    * then return "null"
    */
    public static getServiceDatabaseId(): string {
        const sdb_id: string = sessionStorage.getItem(DsamsConstants.SESSION_SDB_ID);
        if (sdb_id == null || sdb_id === "") {
            return "null";
        }
        else {
            return sdb_id;
        }
    }

    /** 
     * Set a null value to "" (for use with dropdowns)
     */
    public static nullFix(pStr: string): string {
        return !pStr ? "" : pStr;
    }

    /**
     * Determine if a user entry is blank.
     */
    public static isBlankStr(pAttr: any): boolean {
        const attrStr: string = CaseUtils.nullFix(CaseUtils.convertNAStrToBlank(pAttr)).toString().trim();
        return (attrStr === "");
    }

    /**
    * Get a FormGroup value
    */
    public static getFormGroupValue(pFormGroup: FormGroup, pFieldName: string): string {
        return (pFormGroup.get(pFieldName).value === '' || pFormGroup.get(pFieldName).value == null) ? "" : pFormGroup.get(pFieldName).value;
    }

    /* These utility functions are being used to determine the Case Master Status type.
       Author: David Huynh
       Date: 11/25/20 
    */
    public static isOpenCaseStatus(pVal: string): boolean {
        return (pVal == this.CaseMasterStatusOpenType);
    }
    public static isClosedCaseStatus(pVal: string): boolean {
        return (pVal == this.CaseMasterStatusClosedType);
    }
    public static isCancelledCaseStatus(pVal: string): boolean {
        return (pVal == this.CaseMasterStatusCancelledType);
    }
    public static isPendingCaseStatus(pVal: string): boolean {
        return (pVal == this.CaseMasterStatusPendingType);
    }

    /* These utility functions are being used to determine the Case Version type.
       Author: David Huynh
       Date: 11/25/20 
    */
    public static isBasicCaseVersion(pVal: string): boolean {
        return (pVal == this.CaseVersionBasicType);
    }
    public static isAmendCaseVersion(pVal: string): boolean {
        return (pVal == this.CaseVersionAmendmentType);
    }
    public static isModCaseVersion(pVal: string): boolean {
        return (pVal == this.CaseVersionModType);
    }
    public static isRevisionCaseVersion(pVal: string): boolean {
        return (pVal == this.CaseVersionRevisionType);
    }
    public static isWritingCaseVersion(pVal: string): boolean {
        return (pVal == this.CaseVersionStatusWritingType);
    }
    public static isReviewCaseVersion(pVal: string): boolean {
        return (pVal == this.CaseVersionStatusReviewType);
    }
    public static isBasicOrModOrAmendCase(pVal: string): boolean {
        if (this.isBasicCaseVersion(pVal) || this.isAmendCaseVersion(pVal) ||
            this.isModCaseVersion(pVal) || this.isRevisionCaseVersion(pVal) ) {
            return true;
        }
        return false;
    }

    /* These utility functions are being used to determine the Case Version Status type.
       Author: David Huynh
       Date: 11/25/20 
    */
    public static isOfferedCaseVersionStatus(pVal: string): boolean {
        return (pVal == this.CaseVersionStatusOfferedType);
    }
    public static isDevCaseVersionStatus(pVal: string): boolean {
        return (pVal == this.CaseVersionStatusDevelopmentType);
    }
    public static isReviewCaseVersionStatus(pVal: string): boolean {
        return (pVal == this.CaseVersionStatusReviewType);
    }
    public static isImpCaseVersionStatus(pVal: string): boolean {
        return (pVal == this.CaseVersionStatusImplementedType);
    }
    public static isClosedCaseVersionStatus(pVal: string): boolean {
        return (pVal == this.CaseVersionStatusCaseClosedType);
    }
    public static isCancelledCaseVersionStatus(pVal: string): boolean {
        return (pVal == this.CaseVersionStatusCaseCancelledType);
    }
    public static isWritingCaseVersionStatus(pVal: string): boolean {
        return (pVal == this.CaseVersionStatusWritingType);
    }
    public static isAcceptedCaseVersionStatus(pVal: string): boolean {
        return (pVal == this.CaseVersionStatusAcceptedType);
    }

    public static isOptionEnabledForPenInkShortcut(pVersionStatus: string, pVersionType?: string,
        pCaseUsageCode?: string): boolean {
        if (pVersionType == "I" ||
            pVersionType == this.CaseVersionPlanningType ||
            pVersionType == this.CaseVersionModelType ||
            pVersionStatus !== this.CaseVersionStatusOfferedType ||
            pCaseUsageCode == "I") {
            return false;
        }
        return true;
    }

    public static isOptionEnabledForUpdImplCaseShortcut(pCaseVersionType: string): boolean {
        if (pCaseVersionType == this.CaseVersionUpdateImplementedCaseType) { //Had to hard code this one.
            return true;
        }
        return false;
    }

    public static isOptionEnabledForCountryShortcut(pVersionStatus: string, pCaseVersionType: string,
        pCaseVersionData: ICaseVersion): boolean {
        if (pVersionStatus == this.CaseVersionStatusDevelopmentType &&
            pCaseVersionType == this.CaseVersionBasicType &&
            pCaseVersionData.theCaseId.case_USAGE_INDICATOR_CD.toUpperCase() !== 'M') {
            if (!!pCaseVersionData.caseVersionMilestoneList && pCaseVersionData.caseVersionMilestoneList.length !== 0) {
                this.filterLength = pCaseVersionData.
                    caseVersionMilestoneList.filter((s1) => s1.milestone_ID === 'S1SENT');
                if (this.filterLength.length > 0) {
                    return false;
                } else {
                    return true;
                }
            }
        }
        if (pVersionStatus == this.CaseVersionStatusDevelopmentType &&
            pCaseVersionType == this.CaseVersionBasicType &&
            pCaseVersionData.theCaseId.case_USAGE_INDICATOR_CD.toUpperCase() === 'M') {
            return false;
        }
    }

    public static isOptionEnabledForCongressionalNotificationShortcut(pVersionStatus: string): boolean {
        if (pVersionStatus == this.CaseVersionStatusDevelopmentType) {
            return true;
        }
        return false;
    }

    // is the option Update Manager enabled.
    // If it passes this then option is true and line manager
    // can be edited.
    public static isOptionEnabledForMgr2Shortcut(
        pVersionStatus: string, 
        pCaseVersionType: string, 
        pCaseUsageCode: string,
        pCaseMarkForDeletionIn: string,
        pChangeActionCode: string,
        pCaseSublineTx: string): boolean {
        if (pCaseVersionType === this.CaseVersionUpdateImplementedCaseType &&
            pCaseUsageCode !== "I" && 
            pCaseMarkForDeletionIn !== "1" &&
            pChangeActionCode !== "D" &&
            pCaseSublineTx === null){
            return true;
        } else {
            return false;
        }
    }

    public static isOptionEnabledForMgrShortcut(pVersionStatus: string, pCaseVersionType: string): boolean {
        if (pVersionStatus !== this.CaseVersionStatusDevelopmentType) {
            if (pCaseVersionType === this.CaseVersionBasicType) {
                if (pVersionStatus === this.CaseVersionStatusImplementedType) {
                    return true;
                }
            }
            if (pVersionStatus === this.CaseVersionAmendmentType || pVersionStatus === this.CaseVersionModType) {
                return true;
            }
            return true;
        }
        return false;
    }

    public static isOptionEnabledForCaseInReviewShortcut(pVersionStatus: string): boolean {
        if (pVersionStatus == this.CaseVersionStatusReviewType) {
            return true;
        }
        return false;
    }
    public static isOptionEnabledForCaseInProposedShortcut(pVersionStatus: string): boolean {
        if (pVersionStatus == this.CaseVersionStatusProposedType) {
            return true;
        }
        return false;
    }
    public static isOptionEnabledForDscaShortcut(pVersionStatus: string): boolean {
        if (pVersionStatus == this.CaseVersionStatusProposedType) {
            return true;
        }
        return false;
    }
    public static isOptionEnabledForMildepShortcut(pVersionStatus: string, pCaseVersionType: string): boolean {
        // Fixed Option - Card 5184
        if ((pVersionStatus == this.CaseVersionStatusOfferedType ||
            pVersionStatus == this.CaseVersionStatusImplementedType ||
            pVersionStatus == this.CaseVersionStatusAcceptedType || 
            pCaseVersionType == this.CaseVersionUpdateImplementedCaseType) && 
            pCaseVersionType != this.CaseVersionModelType) {
            return true;
        }
        return false;
    }
    public static isOptionEnabledForS1DescriptionShortcut(pVersionStatus: string,
        pCaseVersionData: ICaseVersion): boolean {
        if (pVersionStatus == this.CaseVersionStatusDevelopmentType ||
            pVersionStatus == this.CaseVersionStatusWritingType) {
            if (pCaseVersionData.theCaseId.fouo_APPROVAL_IN !== true) {
                return true;
            }
        }
        return false;
    }
    public static isOptionEnabledForSpecialBillingAgreementShortcut(pVersionStatus: string): boolean {
        if (pVersionStatus == this.CaseVersionStatusDevelopmentType ||
            pVersionStatus == this.CaseVersionStatusWritingType ||
            pVersionStatus == this.CaseVersionStatusReviewType) {
            return true;
        }
        return false;
    }
    public static isOptionEnabledForCustomerInformationShortcut(pVersionStatus: string, pCaseVersionType: string): boolean {
        // Fixed Option - Card 5184
        if (pVersionStatus == this.CaseVersionStatusDevelopmentType ||
            pVersionStatus == this.CaseVersionStatusOfferedType ||
            pVersionStatus == this.CaseVersionStatusReviewType ||
            pVersionStatus == this.CaseVersionStatusProposedType ||
            pVersionStatus == this.CaseVersionStatusImplementedType ||
            pVersionStatus == this.CaseVersionStatusAcceptedType ||
            pCaseVersionType == this.CaseVersionUpdateImplementedCaseType) {
            return true;
        }
        return false;
    }
    public static isOptionEnabledForAmendModShortcut(pVersionStatus: string, pCaseVersionType: string): boolean {
        if (pVersionStatus == this.CaseVersionStatusDevelopmentType &&
            (pCaseVersionType == this.CaseVersionModType || pCaseVersionType == this.CaseVersionAmendmentType)) {
            return true;
        }
        return false;
    }
    public static isOptionEnabledForRequisitionForcastIndicatorShortcut(pVersionStatus: string, pCaseVersionType: string): boolean {
        // Fixed Option - Card 5184 - Option for Change Customer Req. Allowed Indicator
        if (pVersionStatus == this.CaseVersionStatusWritingType ||
            pVersionStatus == this.CaseVersionStatusReviewType ||
            pVersionStatus == this.CaseVersionStatusOfferedType ||
            pVersionStatus == this.CaseVersionStatusProposedType ||
            pVersionStatus == this.CaseVersionStatusAcceptedType ||
            pVersionStatus == this.CaseVersionStatusImplementedType ||
            pCaseVersionType == this.CaseVersionUpdateImplementedCaseType) {
            return true;
        }
        return false;
    }
    public static isOptionEnabledForReserveCaseIdentifierShortcut(pCaseVersionData: ICaseVersion, pCaseVersionType: string): boolean {
        // Fixed Option - Card 5184 - Option if in development and is a pseudo case
        if (pCaseVersionData.case_VERSION_STATUS_CD == this.CaseVersionStatusDevelopmentType && 
            pCaseVersionData.theCaseId.theCustomerOrganizationId.customer_TYPE_CD == 'PS') {
            return true;
        }
        return false;
    }

    /* This function evaluates passing paramters and returns true when any condition is met 
      per WP001-FR87.
      Author: David Huynh
      Date: 11/25/20 
      @pCaseVersionType: is the case version type code
      @pVersionStatus:  is the case version status code
      @pCaseMasterStatus: is the case master status code
    */
    public static isOptionEnabledForDocInitShortcut(pCaseVersionType: string,
        pVersionStatus: string, pCaseMasterStatus: string): boolean {
        switch (pCaseVersionType) {
            case this.CaseVersionBasicType: {
                if ((this.isDevCaseVersionStatus(pVersionStatus) && this.isPendingCaseStatus(pCaseMasterStatus)) ||
                    (this.isWritingCaseVersionStatus(pVersionStatus) && this.isPendingCaseStatus(pCaseMasterStatus))) return true;
                break;
            }
            case this.CaseVersionModType:
            case this.CaseVersionAmendmentType: {
                if ((this.isDevCaseVersionStatus(pVersionStatus) && this.isOpenCaseStatus(pCaseMasterStatus)) ||
                    (this.isWritingCaseVersionStatus(pVersionStatus) && this.isOpenCaseStatus(pCaseMasterStatus)) ||
                    (this.isClosedCaseVersionStatus(pVersionStatus) && this.isOpenCaseStatus(pCaseMasterStatus)))
                    return true;
                break;
            }
            default: return false;
        }
        return false;
    }
    /* 
    This function determines the enabledness of the validate case option.
    Author: Cbanta
    Date: 02/08/21
    @pVersionStatus:  is the case version status code
    @pCaseMasterStatus: is the case master status code    
    */
    public static isOptionEnabledForValidateCaseShortcut(pVersionStatus: string, pCaseMasterStatus: string) {
        return !(this.isClosedCaseVersionStatus(pVersionStatus) ||
            this.isCancelledCaseVersionStatus(pVersionStatus) ||
            this.isClosedCaseStatus(pCaseMasterStatus) ||
            this.isCancelledCaseStatus(pCaseMasterStatus));
    }

    /**
     * This function will add a case version milestone to a list of CVM-s.
     */
    public static addCaseVersionMilestone (pCaseId: number,
                                           pCaseVersionId: number,
                                           pCustomerRequestId: number,
                                           pMilestoneId: string,
                                           pMilestoneTx: string,
                                           pActivityId: string,
                                           pUserId: number): ICaseVersionMilestone
    {
        const piCMR: ICaseMilestoneRevision = {
            entityName: "CASE_MILESTONE_REVISION",
            status: DsamsConstants.ENT_NEW,
            case_VERSION_MILESTONE_DT: new Date(),
            theActivityId: null,
            theDateTypeCd: null,
            theUserId: null,
            activity_ID: pActivityId,
            case_ID: pCaseId,
            case_MILESTONE_ID: 0,
            case_MILESTONE_REVISION_ID: 0,
            case_VERSION_ID: pCaseVersionId,
            date_TYPE_CD: "A",
            user_ID: pUserId
          };
          const piCVM: ICaseVersionMilestone = {
            entityName: "CASE_VERSION_MILESTONE",
            status: DsamsConstants.ENT_NEW,
            case_ID: pCaseId,
            case_MILESTONE_COMMENT_TX: pMilestoneTx,
            cASE_MILESTONE_ID: 0,
            case_VERSION_ID: pCaseVersionId,
            customer_REQUEST_ID: pCustomerRequestId,
            milestone_ID: pMilestoneId,
            milestone_OVERRIDE_IN: false,
            caseMilestoneRevisionList: []            
          };
        piCVM.caseMilestoneRevisionList.push(piCMR);
        return piCVM;
    }

    /**
     * Perform a deep clone of an object.
     */
     public static deepCopy(pObj:any):any {
        return JSON.parse(JSON.stringify(pObj)); 
     }
}