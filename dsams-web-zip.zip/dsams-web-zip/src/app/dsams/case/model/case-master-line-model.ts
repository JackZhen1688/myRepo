import { CaseMasterModel } from "./case-master-model";

//Case Master Line entity
export interface CaseMasterLineModel {
    case_ID?:number,
    case_MASTER_LINE_ID?: number,
    theCaseId?:CaseMasterModel,
    customer_ORGANIZATION_ID?:string,
    user_CASE_SUBLINE_TX?: string,
    user_CASE_LINE_NUMBER_ID?: string
}