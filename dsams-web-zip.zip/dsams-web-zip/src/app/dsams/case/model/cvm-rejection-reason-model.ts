
export interface CVMRejectionReason {
    entityName?: string,
    status?: number,
    aCTUAL_DAYS_FOR_CDEF_QY?: number,
    case_ID?: number,
    cASE_MILESTONE_ID?: number,
    case_VERSION_ID?: number,
    cDEF_COMMENT_TX ?: string,
    pROPOSED_DAYS_FOR_CDEF_QY?: number,
    reject_REASON_ID?: number,
}