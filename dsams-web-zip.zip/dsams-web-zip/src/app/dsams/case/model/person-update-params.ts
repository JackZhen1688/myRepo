export interface IPersonUpdateParams {
    user_ID:number,
    csu_CD:string,
    service_DB_ID:string,
    update_PRC:string,
    email_ADDRESS_TX?:string    
}