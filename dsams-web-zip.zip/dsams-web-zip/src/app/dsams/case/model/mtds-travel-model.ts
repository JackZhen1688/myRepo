export interface mtdsTravelModel {
    entityName?: string;
    status?: string,

    mtds_TRAVEL_PURPOSE_TX?: string,
    fiscal_YEAR_ID?: string,
    mtds_TRAVEL_SITE_TX?: string,
    mtds_TRAVEL_NUMBER_QY?: number,
    mtds_TRAVEL_DURATION_QY?: number,
    mtds_TRAVEL_DURATION_UNIT_CD?: number,
    mtds_TRAVEL_NUMBER_PERSON_QY?: number,
    mtds_TRAVEL_TOTAL_COST_AM?: number,
    mtds_TRAVEL_TOTAL_COST_AM_String?: string,
    mtds_MANPOWER_MATRIX_CD?: string,
    mtds_MANPOWER_MATRIX_CD_USER_FORMAT?: string,
    case_LINE_MTDS_TRAVEL_ID?: number,
    case_ID?: number,
    case_MASTER_LINE_ID?: number,
    working_CASE_ID?: number,
    working_CASE_VERSION_ID?: number,
    case_LINE_COMPONENT_ID?: number      
}