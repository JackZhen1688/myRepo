/**
 * This contains the data for reference data values.
 * The contents of each of the fields is determined on a reference-table basis
 * according to the logic in the middle-tier.
 * 
 * @author CBanta
 */

export interface ReferenceDataType {
    key_FIELD: string;
    field_1: string;
    field_2: string;
    field_3: string;
    field_4: string;
    field_5: string;
    inactive_IN: boolean;
}