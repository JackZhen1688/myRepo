export interface CasePanelStatusType {
    panelName:string,
    status:number,
    caseId:number,
    caseVersionId:number
}