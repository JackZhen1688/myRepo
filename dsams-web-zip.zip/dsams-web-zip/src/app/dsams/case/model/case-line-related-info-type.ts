export interface CaseLineRelatedInfoType {
    case_ID?: number,
    user_CASE_ID?: string,
    case_VERSION_NUMBER_ID?: number,
    case_VERSION_STATUS_CD?: string,
    case_VERSION_TYPE_CD?: string,
    case_CUSTOMER_ORGANIZATION_ID?: string,
    implementing_AGENCY_ID?:string,
    case_VERSION_ID?: number,
    wm_OFFER_EXPIRATION_DT?:string,
    security_ASSISTANCE_PROGRAM_CD?:string,
    customer_REQUEST_ID?:number
}