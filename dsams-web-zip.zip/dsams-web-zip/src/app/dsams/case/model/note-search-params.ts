export interface INoteSearchParams {
	user_NOTE_ID: string,
	note_VERSION_ID: string,
	official_NOTE_TITLE_TX: string,
	activity_ID: string,
	note_TYPE_CD: string,
	note_EXPIRATION_DT: string
}