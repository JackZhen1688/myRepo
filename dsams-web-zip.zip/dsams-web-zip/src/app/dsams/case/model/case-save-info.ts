export interface CaseSaveInfo {
    case_ID: number,
    case_VERSION_ID: number,
    isNewMode: boolean,
    isNewCaseMaster: boolean,
    isEditable: boolean
}