export interface mtdsPersonnelSupportCostsModel {
    entityName?: string;
    status?: string,

    mtds_SUPPORT_TYPE_TX?: string,
    mtds_SUPPORT_TOTAL_COST_AM?: number,
    mtds_SUPPORT_TOTAL_COST_AM_String?: string,
    mtds_SUPPORT_MATRIX_CD?: string,
    mtds_SUPPORT_MATRIX_CD_USER_FORMAT?: string,
    mtds_SUPPRT_ORGAN_TX?: string,
    case_LINE_MTDS_SUPPORT_ID?: number,
    case_ID?: number,
    case_MASTER_LINE_ID?: number,
    working_CASE_ID?: number,
    working_CASE_VERSION_ID?: number,
    case_LINE_COMPONENT_ID?: number    
}