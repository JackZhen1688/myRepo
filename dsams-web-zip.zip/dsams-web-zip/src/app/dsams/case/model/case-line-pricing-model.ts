export interface caseLinePricingModel {
    entityName?: string;
    status?: string,

    primary_CATEGORY_CD?: string,
    PRIMARY_CATEGORY_TITLE_NM?: string,
    PRICE_ELEMENT_CD?: string,
    PRICE_ELEMENT_TITLE_NM?: string,
    FUND_CD?: string,
    BASE_PRICE_SOURCE_CD?: number,
    COMPONENT_UNIT_BASE_PRICE_AM?: number,
    CASE_LINE_COMPONENT_QY?: number,
    TARGET_PERCENT_RT?: number,
    TARGET_COST_AM?: number,    
    ABOVE_THE_LINE_PC_COST?: string,
    COMPONENT_DESCRIPTION_TX?: string,
    TOTAL_PC_VALUE?: string
}