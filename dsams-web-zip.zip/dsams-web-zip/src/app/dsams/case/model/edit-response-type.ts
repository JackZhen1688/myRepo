export interface IEditResponseType {
    ID: string,
    editToggle: boolean
}