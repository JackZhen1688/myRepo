export interface ICaseVersionStatus {
    entityName: string,
    status: number,    
    case_VERSION_STATUS_CD: string,
    inactive_IN: boolean,
    sequence_NUMBER_ID: number,
    version_STATUS_DESCRIPTION_TX: string,
    version_STATUS_TITLE_NM: string
}