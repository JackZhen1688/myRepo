import { CVMRejectionReason } from '../cvm-rejection-reason-model';
import { ICaseMilestoneRevision } from './case-milestone-revision';

export interface ICaseVersionMilestone {
    entityName: string,
    status: number,
    case_ID: number,
    case_MILESTONE_COMMENT_TX: string,
    cASE_MILESTONE_ID: number,
    case_VERSION_ID: number,
    customer_REQUEST_ID: number,
    milestone_ID: string,
    milestone_OVERRIDE_IN: boolean,
    caseMilestoneRevisionList: Array<ICaseMilestoneRevision>,
    cvmRejectionReasonList?: CVMRejectionReason[],
}