import { INoteParameter } from "./note-parameter";

export interface ICaseNoteParameter {
    entityName?: string,
    status?: number,    
    case_ID?: number,
    case_NOTE_ID?: number,
    case_NOTE_PARAMETER_ID?: number,
    case_NOTE_PARAMETER_TX?: string,
    case_VERSION_ID?: number,
    note_ID?: number,
    note_VERSION_ID?: number,
    prompting_NOTE_ID?: number,
    prompting_NOTE_PARAMETER_ID?: number,
    prompting_NOTE_VERSION_ID?: number,
    thePromptingNoteParameterId?: INoteParameter,    
}