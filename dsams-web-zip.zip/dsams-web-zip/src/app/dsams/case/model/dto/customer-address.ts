import { IAddressType } from './address-type';
import { IServiceDatabase } from './service-database';
import { ICustomerOrganization } from './icustomer-organization';

export interface ICustomerAddress {
    theAddressTypeCd: IAddressType,
    theCustomerOrganizationId: ICustomerOrganization,
	theServiceDbId: IServiceDatabase,
    address_LINE_1_TX: string,
    address_LINE_2_TX: string,
    address_LINE_3_TX: string,
    address_LINE_4_TX: string,
    address_LINE_5_TX: string,
    address_TYPE_CD: string,
    customer_ADDRESS_ID: number,
    customer_ORGANIZATION_ID: string,
    default_ADDRESS_IN: boolean,
    inactive_IN: boolean,
    service_DB_ID: string
}