export interface IWorkflowTaskAssignmentData {
    task_ID: string,
    workflow_TASK_ID: number, 
    workflow_ASSIGN_NUMBER_ID: number, 
    workflow_ASSIGNMENT_STATUS_CD: string,
    recipient_USER_ID: number,
    workflow_TASK_ASSIGN_DT: Date,
    workflow_TASK_DUE_DT: Date,
    case_ID: number,
    case_VERSION_ID: number,
    user_CASE_ID: string,
    case_VERSION_TYPE_DISP: string
}