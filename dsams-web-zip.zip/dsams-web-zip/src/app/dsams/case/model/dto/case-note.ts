import { INote } from "../note";
import { ICaseLineNote } from "./case-line-note";
import { ICaseNoteParameter } from "./case-note-parameter";
import { IChangeAction } from "./icase-line-pricing";
import { ICaseVersion } from "./icase-version";
import { CaseMasterLineModel } from "../case-master-line-model";
import { CaseMaster } from "./case-master";

export interface ICaseNote {
    entityName?: string,
    status?: number,    
    case_ID?: number,
    case_NOTE_ID?: number,
    case_VERSION_ID?: number,
    change_ACTION_CD?: string,
    ipc_CATEGORY_CD?: string,
    note_ID?: number,
    note_VERSION_ID?: number,
    user_NOTE_NUMBER_ID?: number,
    assignment_IN?: boolean,
    caseLineNoteRelatedNoteIdList?: ICaseLineNote[],
    caseNoteParameterList?: ICaseNoteParameter[],
    theChangeActionCd?: IChangeAction,
    theNoteId?: INote,
    theCaseVersionId?: ICaseVersion,
    theCaseMasterLineId?: CaseMasterLineModel,
    theCaseId?: CaseMaster,
    lockSessionId?: number,
    wm_CASE_WRITING_IN?: boolean
}