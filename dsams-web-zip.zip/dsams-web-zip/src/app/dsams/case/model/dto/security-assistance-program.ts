export interface ISecurityAssistanceProgram {
    entityName: string,
    status: number,
    inactive_IN: boolean,    
    program_ADVANCE_PERIOD_QY: number,
    program_DESCRIPTION_TX: string,
    program_EXEMPT_PERIOD_QY: number,
    program_NONEXEMPT_PERIOD_QY: number,
    program_TITLE_NM: string,
    security_ASSISTANCE_PROGRAM_CD: string
}