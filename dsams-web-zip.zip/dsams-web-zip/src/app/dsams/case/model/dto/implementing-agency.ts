export interface IImplementingAgency {
    entityName: string,
    status: number,
    acas_ELIGIBLE_IN: boolean,
    implementing_AGENCY_ID: string,
    implementing_AGENCY_TITLE_NM: string,
    implementing_AGENCY_TX: string,
    inactive_IN: boolean,
    military_BRANCH_AIR_FORCE_IN: boolean,
    military_BRANCH_ARMY_IN: boolean,
    military_BRANCH_NAVY_IN: boolean,
    parent_IMPLEMENTING_AGENCY_ID: string,
    service_DB_ID: string
}