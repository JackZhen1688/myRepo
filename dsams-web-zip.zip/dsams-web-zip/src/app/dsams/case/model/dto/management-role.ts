export interface IManagementRole {
    entityName: string,
    status: number,
    case_ROLE_DISPLAY_IN: boolean,
    inactive_IN: boolean,
    management_ROLE_DESCRIPTION_TX: string,
    management_ROLE_ID: string,
    management_ROLE_TITLE_NM: string,
    management_ROLE_TYPE_ID: string,
    service_DB_ID: string
}