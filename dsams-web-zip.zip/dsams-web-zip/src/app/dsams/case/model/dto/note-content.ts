export interface INoteContent {
    entityName?: string,
    status?: number,    
    note_ID?: number,
    note_TX?: string,
    note_VERSION_ID?: number
}