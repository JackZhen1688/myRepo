export interface IUsedUserCase {
    entityName?: string,
    status?: number,    
    case_DESIGNATOR_CD: string,
    customer_ORGANIZATION_ID: string,
    implementing_AGENCY_ID: string,
    pseudo_IN: boolean
}