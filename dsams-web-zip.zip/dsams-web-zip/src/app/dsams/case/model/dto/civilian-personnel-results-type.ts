export interface CivilianPersonnelResultsType {
    component_UNIT_BASE_PRICE_AM: number,
    errorMsg: string
}