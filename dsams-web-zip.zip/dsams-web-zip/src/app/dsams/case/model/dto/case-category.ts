import { ISecurityAssistanceProgram } from './security-assistance-program';

export interface ICaseCategory {
    entityName: string,
    status: number,
    theSecurityAssistanceProgramCd: ISecurityAssistanceProgram,
    case_CATEGORY_CD: string,
    case_CATEGORY_DESCRIPTION_TX: string,
    case_CATEGORY_TITLE_NM: string,
    inactive_IN: boolean,
    security_ASSISTANCE_PROGRAM_CD: string
}