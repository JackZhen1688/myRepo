export interface IDsamsBulletin {
    user_ID: number,
    message_ID: number,
    message_START_DT: Date,
    message_END_DT: Date,
    message_PDF_LINK_ID: string,
    message_STATUS_ID: string,
    message_TITLE_NM: string,
    message_TX: string,
    service_DB_ID: string,
    has_PDF_FILE: boolean
}