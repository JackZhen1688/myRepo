import { CaseLineIPCDto } from "../../line-dashboard/line-pricing/ipc-tab-dashboard/model/dto/case-line-ipc-dto";
import { supplementalLineNoteDto } from "../../line-dashboard/line-pricing/ipc-tab-dashboard/model/dto/supplemental-line-note-dto";
import { caseLineComponentModel } from "../case-line-component-model";
import { FieldDisabledMap } from "../field-disabled-map";
import { mtdsPersonnelModel } from "../mtds-personnel-model";
import { mtdsPersonnelSupportCostsModel } from "../mtds-personnel-support-costs-model";
import { mtdsTravelModel } from "../mtds-travel-model";
import { CASE_LINE_COMP_DEL_TERM } from "./icase-line-pricing";

export interface caseLineComponentDto extends caseLineComponentModel {
    //no window mappping attributes needed
    wm_status?: string;
    isDisabled?: boolean;   // Is row enabled?
    iconImg?: "arrow_drop_down";
    expandIPCPanel?: boolean;
    isFieldDisabled?: FieldDisabledMap; //is specific field enabled?

    case_LINE_COMPONENT_ID?: number,
    primary_CATEGORY_CD?: string,
    price_ELEMENT_CD?: string,
    fund_CD?: string,
    base_PRICE_SOURCE_CD?: number,
    component_UNIT_BASE_PRICE_AM?: number,
    case_LINE_COMPONENT_QY?: number,
    target_PERCENT_RT?: number,
    target_COST_AM?: number,
    component_DESCRIPTION_TX?: string, 
    component_TITLE_NM?: string,
    above_LINE_COST?: number,
    total_COST?: number,

    wm_component_UNIT_BASE_PRICE_AM?: string,
    wm_target_PERCENT_RT?: string,
    wm_target_COST_AM?: string,
    wm_above_LINE_COST?: string,
    wm_total_COST?: string,
    wm_base_PRICE_SOURCE_NM?: string,

    then_FISCAL_YEAR_ID?: string,
    base_FISCAL_YEAR_ID?: string,
    inflation_FUND_CD?: string,
    civilian_FISCAL_YEAR_ID?: string,
    civilian_PAYROLL_COST_AM?: number,
    civilian_PAYROLL_CATEGORY_CD?: number,
    storage_YEAR_AM?: number,
    storage_MONTH_AM?: number,
    storage_DAY_AM?: number,
    price_YEAR_CD?: number,
    thePrimaryCategoryCd?:primaryCategoryDto,
    caseLineIpcList?: Array<CaseLineIPCDto>,
    deletedIpcList?: Array<CaseLineIPCDto>,    
    databaseIpcListStr?: string,
    caseLineListAttachmentList?: Array<supplementalLineNoteDto>,
    deletedAttachmentList?: Array<supplementalLineNoteDto>,
    caseLineCompDelTermList?: Array<CASE_LINE_COMP_DEL_TERM>,
    fundList?: Array<fundDto>,
    priceElementList?: Array<priceElementDto>,
    populatePEFlag?: boolean,
    pouplateFundFlag?: boolean,
    caseLineCompMtdsPersonList?: Array<mtdsPersonnelModel>,
    caseLineCompMtdsSupprtList?: Array<mtdsPersonnelSupportCostsModel>,
    caseLineCompMtdsTravelList?: Array<mtdsTravelModel>,
    deletedCaseLineCompMtdsPersonList?: Array<mtdsPersonnelModel>,
    deletedCaseLineCompMtdsSupportList?: Array<mtdsPersonnelSupportCostsModel>,
    deletedCaseLineCompMtdsTravelList?: Array<mtdsTravelModel>,
    caseLineCompMtdsPersonTotalAm?: number,
    caseLineCompMtdsSupprtTotalAm?: number,
    caseLineCompMtdsTravelTotalAm?: number,
    primaryCategoryChanged?: boolean
}


// For civilian personnel popup
export interface caseLineComponentForCivilianPopup {
    civilian_FISCAL_YEAR_ID: string,
    civilian_PAYROLL_COST_AM: number,
    civilian_PAYROLL_CATEGORY_CD: number
}

// For Primary categry
export interface primaryCategoryDto {
    primary_CATEGORY_CD?:string,
    mtds_IN?:boolean
}


export interface fundDto {
    fund_CD?: string,    
    fund_TITLE_NM?: string
}

export interface priceElementDto {
    price_ELEMENT_CD?: string,
    price_ELEMENT_TITLE_NM?: string
}