import { ICaseMaster } from './icase-master';

export interface IRelatedCase {
    entityName: string,
    status: number,    
    case_ID: number,
    theRelatedCaseId?: ICaseMaster,
    profile_USED_MAJOR_ITEM_QY?: number,
    related_CASE_ID: number,
    related_CASE_RATIONALE_TX: string,
    related_CASE_TYPE_CD?:string
}