export interface INoteParameter {
    entityName?: string,
    status?: number,    
    note_FILL_IN_NM?: string,
    note_FILL_IN_PROMPT_TX?: string,
    note_ID?: number,
    note_PARAMETER_ID?: number,
    note_VERSION_ID?: number
}