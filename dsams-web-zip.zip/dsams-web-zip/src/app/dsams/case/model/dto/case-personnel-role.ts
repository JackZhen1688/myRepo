import { IManagementRole } from './management-role';
import { IPerson } from './person';

export interface ICasePersonnelRole {
    entityName: string,
    status: number,
    theManagementRoleId?: IManagementRole,
    theUserId?: IPerson,
    case_ID: number,
    management_ROLE_ID: string,
    user_ID: number
}