export class CustomerOrganizationRefList {
    customer_ORGANIZATION_ID:string = '';
    customer_NICKNAME_NM?:string = '';
    customer_TYPE_CD?:string = '';
	inactive_ID?:string = '';
    bypass_CONG_NOTIFICATION_IN?:string='';
    building_PARTNER_CAPACITY_IN?:string='';
    wm_RESTRICTION_EXPIRATION_DT?:string='';
    wm_RESTRICTION_EFFECTIVE_DT?:string='';
}