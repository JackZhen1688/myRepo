import { ErrorParameter } from "src/app/dsams/entities/specialEntities/error-parameter.model";
import { CaseMasterLineModel } from "../case-master-line-model";
import { ifaceCaseLineDeliveryTermEntity } from "../case-related-info-type";
import { CaseVersionModel } from "../case-version-model";
import { caseLineComponentDto } from "./case-line-component-dto";
import { ICaseLineFiscalDistribution } from "./case-line-fiscal-distribution-dto";

export interface ICaseLinePricing {
    status?: number,
    case_ID?: number,
    working_CASE_ID?: number,
    working_CASE_VERSION_ID?: number,
    case_MASTER_LINE_ID?: number,
    military_ARTICLE_SERVICE_CD?: string,
    case_LINE_ITEM_QY?: number,
    price_EFFECTIVE_DT?: Date,
    price_EXPIRATION_DT?: Date,
    old_PRICE_EXPIRATION_DT?: Date,
    target_TOTAL_LINE_AM?: number,
    unit_ABOVE_LINE_COST_AM?: number,
    mtds_NARRATIVE_DESCRIPTION_TX?: string,
    total_LINE_VALUE_AM?: number,   // Maps to Total Line/Subline Value
    totalInWorkAm?: number,      // Maps to Total Case Value
    pricing_METHOD_CD?: string,
    wm_HasFiscalYearDistribution?: boolean,
    caseLineComponentList?: Array<caseLineComponentDto>,
    case_LINE_ITEM_QY_string?: string,
    wm_errorMessageArray?: Array<ErrorParameter>,
    wm_MessageLevel?: string,
    wm_checkFinancialData?: boolean,
    wm_noPromptCheckFinancialData?: boolean,
    //Calculate Costs Attributes
    change_ACTION_CD?: string,
    line_PURPOSE_CD?: string,
    other_NATIONAL_STOCK_NUMBER_ID?: string,
    national_STOCK_NUMBER_ID?: string,
    supply_SOURCE_NUMBER_ID?: string,
    case_LINE_MARK_FOR_DELETION_IN?: string,
    condition_CD?: string,
    inventory_VALUE_AM?: string;
    acquisition_VALUE_AM?: string;
    total_ABOVE_LINE_COST_AM?: number;
    recalculation_IN?: boolean;
    calculateIPCSummaryTotal?: boolean;
    issue_UNIT_CD?: string,
    precision_UNIT_COST_PRICING_IN?:boolean;
    theWorkingCaseVersionId?: CaseVersionModel,
    theCaseMasterLineId?: CaseMasterLineModel,
    theParentCaseMasterLineId?: CaseMasterLineModel,
    //window mapping attributes
    //theCaseLine?:ifaceCaseLineData,
    case_USAGE_INDICATOR_CD?: string,
    caseLineFiscalDistributionCaseCaseLineList?: Array<ICaseLineFiscalDistribution>,
    caseLineDeliveryTermList?: Array<ifaceCaseLineDeliveryTermEntity>,
    theChangeActionCd?: IChangeAction
  }
  
  export interface IChangeAction {
    change_ACTION_CD?: string,
    cHANGE_ACTION_DESCRIPTION_TX?: string,
    change_ACTION_TITLE_NM?: string
    iNACTIVE_IN?: boolean
  }

  export interface caseLineDeliveryTermDto {
    case_MASTER_LINE_ID: number,
    case_ID: number,
    working_CASE_ID: number,
    working_CASE_VERSION_ID: number,
    delivery_TERM_ID: string,
    sequence_CD: number,
    theDeliveryTermId: deliveryTermDto
  }

  export interface deliveryTermDto {
    delivery_TERM_ID: string,
    delivery_TERM_TITLE_NM: string
  }

  export interface CASE_LINE_COMP_DEL_TERM {
    status: number,
    delivery_TERM_ID: string,
    case_LINE_COMPONENT_ID: number,
    case_MASTER_LINE_ID: number,
    case_ID: number,
    working_CASE_ID: number,
    working_CASE_VERSION_ID: number,
    delivery_TERM_RT: number,
    wm_PRIMARY_CATEGORY_CD: string, // On case_line_component
    wm_DELIVERY_TERM_TITLE_NM: string,
    wm_USER_CASE_ID: string
  }