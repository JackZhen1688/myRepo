export interface ICustomerRequestStatus {
    entityName: string,
    status: number,    
    customer_REQUEST_STATUS_CD: string,
    inactive_IN: boolean,
    request_STATUS_DESCRIPTION_TX: string,
    request_STATUS_TITLE_NM: string
}