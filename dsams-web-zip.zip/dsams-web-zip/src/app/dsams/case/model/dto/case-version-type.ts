export interface ICaseVersionType {
    entityName: string,
    status: number,  
    case_VERSION_TYPE_CD: string,
    case_VERSION_TYPE_NM: string,
    case_VERSION_TYPE_TX: string,
    inactive_IN: boolean
}