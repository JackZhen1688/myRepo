import { ifaceCaseLineEntity } from "../case-line-model";
import { ICaseNote } from "./case-note";

export interface ICaseLineNote {
    entityName?: string,
    status?: number,    
    case_ID?: number,
    case_MASTER_LINE_ID?: number,
    related_CASE_ID?: number,
    related_CASE_NOTE_ID?: number,
    related_CASE_VERSION_ID?: number,
    related_NOTE_ID?: number,
    related_NOTE_VERSION_ID?: number,
    working_CASE_ID?: number,
    working_CASE_VERSION_ID?: number,
    theCaseLine?: ifaceCaseLineEntity,
    theRelatedCaseNoteId?: ICaseNote
}