import { mtdsPersonnelSupportCostsModel } from "../mtds-personnel-support-costs-model";

export interface mtdsPersonnelSupportCostsDto extends mtdsPersonnelSupportCostsModel {
    wm_status?: string;
    isDisabled?: boolean;   // Is row enabled?

    wm_MTDS_SUPPORT_TOTAL_COST_AM?: string;
    tempStatus?: boolean;
}