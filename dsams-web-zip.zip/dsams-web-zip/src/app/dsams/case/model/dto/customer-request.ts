import { ICustomerRequestStatus } from './customer-request-status';
import { ICustomerOrganization } from './icustomer-organization';
import { ISecurityClassification } from './security-classification';

export interface ICustomerRequest {
    entityName: string,
    status: number,
    theCustomerRequestStatusCd: ICustomerRequestStatus,
    theCustomerOrganizationId: ICustomerOrganization,
    theSecurityCd: ISecurityClassification,
    customer_REQUEST_DT: Date,
    customer_REQUEST_RECEIPT_DT: Date,
    customer_REQUEST_STATUS_DT: Date,
    activity_ID: string,
    customer_ORGANIZATION_ID: string,
    customer_REQUEST_ACTION_TX: string,
    customer_REQUEST_END_ITEM_TX: string,
    customer_REQUEST_FUNDING_TX: string,
    customer_REQUEST_ID: number,
    customer_REQUEST_REFERENCE_TX: string,
    customer_REQUEST_REQUIRE_TX: string,
    customer_REQUEST_STATUS_CD: string,
    customer_REQUEST_TRANSPORT_TX: string,
    eda_QOI_ID: number,
    lora_LOR_ID: number,
    medical_COUNTERMEASURES_CD: number,
    moa_DESCRIPTION_TX: string,
    request_CONGRESSIONAL_IN: boolean,
    request_CONTACT_PERSON_NM: string,
    request_SOLE_SOURCE_TX: string,
    request_STATUS_COMMENT_TX: string,
    request_TYPE_CD: string,
    security_CD: string,
    statutory_NOTIFICATION_IN: boolean  
}