import { IFiscalYear } from './fiscal-year';
import { IPublicLaw } from './public-law';
import { ISaleTerm } from './sale-term';

export interface ICaseSaleTerm {
    entityName: string,
    status: number,
    theFiscalYearId?: IFiscalYear,
    thePublicLawId?: IPublicLaw,
    theSaleTermId?: ISaleTerm,
    case_ID: number,
    case_SALE_TERM_AM: number,
    case_SALE_TERM_SEQ_CD: number,
    case_VERSION_ID: number,
    fiscal_YEAR_ID: string,
    public_LAW_ID: string,
    sale_TERM_ID: string,
    businessRuleMap?: Map<string, string> 
}