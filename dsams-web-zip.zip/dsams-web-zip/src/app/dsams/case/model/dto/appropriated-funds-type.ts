export interface IAppropriatedFundsType {
    entityName: string,
    status: number,    
    appr_FUNDS_DESCRIPTION_TX: string,
    appr_FUNDS_TITLE_NM: string,
    appropriated_FUNDS_CD: string,
    customer_ORGANIZATION_ID: string,
    fiscal_YEAR_ID: string,
    inactive_IN: boolean,
    service_DB_ID: string
}