export interface ICaseLineFiscalDistribution {
    cASE_ID?: number,
	cASE_MASTER_LINE_ID?: number,
	wORKING_CASE_ID?: number,
	wORKING_CASE_VERSION_ID?: number,   	
    bUDGET_YEAR_AM?: number,
    pRIOR_YEAR_AM?: number,
    rEMAINING_PROGRAM_AM?: number, 
    dELETION_IN?: boolean,
    fUND_CD?: string,
    pRICE_ELEMENT_CD?:string
}