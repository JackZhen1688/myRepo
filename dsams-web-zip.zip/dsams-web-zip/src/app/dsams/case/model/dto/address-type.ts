export interface IAddressType {
    address_TYPE_CD: string,
    address_TYPE_DESCRIPTION_TX: string,
    address_TYPE_TITLE_NM: string,
    inactive_IN: boolean
}