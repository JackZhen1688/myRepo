import { CaseRequestParamsType } from './search-params/case-request-params-type';

/**
 * This class contains the information needed for the panels that are expanded so they can act on 
 * what the user entered in the new/search panels.
 * 
 * @author: CBanta
 */

export interface PanelExpansionProperties {
    panelName: string;
    isNewMode: boolean;
    isResetPanels: boolean;
    caseHeaderData: any,
    caseRequestParams: CaseRequestParamsType;
}