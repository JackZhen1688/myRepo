export interface IShortcutOptions {
    id: string;
    shortcutLabel: string;
    group:string;
  }