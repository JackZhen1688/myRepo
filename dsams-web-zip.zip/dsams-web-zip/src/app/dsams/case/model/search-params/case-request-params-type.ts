/**
 * This class stores the information entered by the user in the new/search panel so it 
 * can be used by the panel that gets expanded.
 * 
 * @author CBanta
 */

export interface CaseRequestParamsType {
    caseId: number,
    caseVersionId: number,
    customerOrganizationId?: string,
    caseVersionTypeCd?: string,
    securityAssistanceProgramCd?: string,
    implementingAgencyId?: string,
    customerRequestId?: number,
    isEditable?: boolean;
}