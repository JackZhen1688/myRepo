/**
 * This contains the parameters for the case search that gets submitted to the middle-tier via HTTP.
 * 
 * @author CBanta
 */
export interface CaseQueryParamsType {
    searchByUserCaseId: boolean,
    searchByCasePopup: boolean,
    security_ASSISTANCE_PROGRAM_CD1: string,
    user_CASE_ID: string,
    security_ASSISTANCE_PROGRAM_CD2: string,
    case_USAGE_INDICATOR_CD1: string,
    case_USAGE_INDICATOR_CD2: string,
    customer_ORGANIZATION_ID: string,
    implementing_AGENCY_ID: string,
    case_DESIGNATOR: string,
    case_MASTER_STATUS_CD: string,
    case_VERSION_STATUS_CD: string,
    case_VERSION_TYPE_CD: string,
    case_VERSION_NUMBER_ID: string,
    activity_ID: string,
    case_NICKNAME_NM: string,
    case_MANAGER_ID: number,
    case_MANAGER_USERNAME: string,
    user_ID: number,
    resultFormatParams: {
        showAllRows: boolean,
        minRow: number,
        maxRow: number,
        sortColumns: string[]
    }
}