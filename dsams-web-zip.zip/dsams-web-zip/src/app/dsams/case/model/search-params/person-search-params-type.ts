export interface IPersonSearchParamsType {
    personLastNm: string,
    personFirstNm: string,
    personNicknameNm: string,
    activityId: string,
    userId: string,
    ruleSet: number,
    maxRecords: number
}