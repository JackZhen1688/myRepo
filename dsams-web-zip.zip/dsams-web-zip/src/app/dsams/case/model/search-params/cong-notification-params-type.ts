export interface ICongNotificationParamsType {
    customerOrganizationId: string,
    congNotificationNumberCode: string,
    ruleSet: number,
    maxRecords: number
}