export interface ICustomerRequestParamsType {
    customerRequestId: string,
    customerOrganizationId: string,
    customerRequestReferenceTx: string,
    customerRequestDt: Date,
    activityId: string,
    ruleSet: number,
    maxRecords: number
}