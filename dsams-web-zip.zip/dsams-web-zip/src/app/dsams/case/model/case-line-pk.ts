export class CaseLinePK {
    case_ID: number = 0;
    case_MASTER_LINE_ID: number = 0;
    working_CASE_ID: number = 0;
    working_CASE_VERSION_ID: number = 0;

    //Foreign Keys
    case_LINE_COMPONENT_ID?: number = 0;
 
    //Window mapping attributes
    primary_CATEGORY_CD?: string='';
    then_FISCAL_YEAR_ID?: string = '';
    base_FISCAL_YEAR_ID?: string = '';
    civilian_FISCAL_YEAR_ID?: string = '';
    inflation_FUND_CD?: string = '';
    storage_YEAR_AM?: number = 0;
    storage_MONTH_AM?: number = 0;
    storage_DAY_AM?: number = 0;
    price_YEAR_CD?: number = 0;
    case_LINE_COMPONENT_QY?: number = 0;
    component_UNIT_BASE_PRICE_AM?: number = 0;
    case_USAGE_INDICATOR_CD?:string='';
    primaryCategoryChanged?: boolean = false;
}