//Case Version entity
export interface CaseVersionModel {
    case_ID:number,
    case_VERSION_NUMBER_ID: number,
    case_VERSION_TYPE_CD?: string,
    case_VERSION_STATUS_CD?: string,
}