import { INoteContent } from "./dto/note-content";
import { INoteParameter } from "./dto/note-parameter";
import { INoteType } from "./dto/note-type";

export interface INote {
    entityName?: string,
    status?: number,    
    note_ID?: number,
    note_VERSION_ID?: number,
    user_NOTE_ID?: string,
    note_DESCRIPTION_TX?: string,
    official_NOTE_TITLE_TX?: string,
    note_INPUT_RESPONSIBILITY_CD?: string,
    note_TYPE_CD?: string,
    activity_ID?: string,
    note_EXPIRATION_DT?: string,
    fillin_IN?: boolean,
    wm_NOTE_EXPIRATION_DT_STR?: string,
    theNoteTypeCd?: INoteType,
    noteContentList?: INoteContent[],
    noteParameterList?: INoteParameter[]
}