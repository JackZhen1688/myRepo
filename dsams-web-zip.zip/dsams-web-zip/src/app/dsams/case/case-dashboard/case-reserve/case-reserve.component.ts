import { Component, Inject } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ReferenceDataType } from '../../model/reference-data-type';
import swal from 'sweetalert2';
import { CaseRestfulService } from '../../services/case-restful.service';

@Component({
    selector: 'app-case-reserve',
    templateUrl: './case-reserve.component.html',
    styleUrls: ['./case-reserve.component.css']
})

export class CaseReserveComponent {

    nameFormControl: FormControl = new FormControl();
    countryCodesData: Array<ReferenceDataType> = [];
    selected: string;
    countryList: Array<ReferenceDataType> = [];
    countryListSorted: Array<ReferenceDataType> = [];


    constructor(private _dialogRef: MatDialogRef<CaseReserveComponent>,
        @Inject(MAT_DIALOG_DATA) public data: {
            countryCodes: Array<ReferenceDataType>,
            countryCode: string,
            implAgencyId: string,
            caseDesignator: string
        },
        private caseRestService: CaseRestfulService) { }

    ngOnInit() {

        //Take out null elements from the array.
        for (let i = 0; i < this.data.countryCodes.length; i++) {
            if (this.data.countryCodes[i].field_2 == "") {
                this.data.countryCodes.splice(0, 1);
            }
        }

        this.countryList = this.sortCountriesList();

        //Select the first element in the array, as selected
        this.selected = this.countryList[0].field_2;
    }


    //Sort Options
    sortCountriesList(): ReferenceDataType[] {
        return this.data.countryCodes.sort(function (a, b) {
            return a.field_2.localeCompare(b.field_2);
        });
    }

    onOkClick(event: Event): void {
        this.caseRestService.getReserveIdentifier(
            this.selected.substr(0, 2), this.data.countryCode, this.data.implAgencyId,
            this.data.caseDesignator, this.selected.substr(0, 2)).subscribe((result) => {
                if (result)
                  console.log("post executed");
            });
        this.savedDialog();
    }

    onNoclick(): void {
        this._dialogRef.close();
    }

    savedDialog() {
        swal.fire({
            title: this.selected + " Reserve Case Identifier is Valid",
            icon: 'success',
            showCancelButton: false,
            cancelButtonText: 'No',
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'OK'
        });
    }
}