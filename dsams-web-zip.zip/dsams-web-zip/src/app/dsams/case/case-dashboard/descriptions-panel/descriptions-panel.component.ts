import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs';
import { CaseUIService } from '../../services/case-ui-service';
import { DsamsConstants } from 'src/app/dsams/dsams.constants';
import { PanelExpansionProperties } from '../../model/panel-expansion-properties';
import { CaseUtils } from '../../utils/case-utils';
import { FieldDisabledMap } from '../../model/field-disabled-map';
import { SaveResultsType } from '../../validation/save-results-type';
import { CaseDescriptionValidator } from '../../validation/case-description-validator';
import { ICaseMaster } from '../../model/dto/icase-master';
import { ICaseVersion } from '../../model/dto/icase-version';
import { MessageMgr } from '../../validation/message-mgr';
import { IEditResponseType } from '../../model/edit-response-type';
import { CaseSaveInfo } from '../../model/case-save-info';

@Component({
  selector: 'app-descriptions-panel',
  templateUrl: './descriptions-panel.component.html',
  styleUrls: ['../common-CSS.component.css',
    './descriptions-panel.component.css',
    '../case-dashboard.component.css']
})
export class DescriptionsPanelComponent implements OnInit, OnDestroy {
  public caseDescriptionData: any = {};
  private _caseUIServiceSubscription: Subscription;
  private _reloadData: boolean = true;
  private _pnlExpansionProperties: PanelExpansionProperties;
  private fieldDisabledMap: FieldDisabledMap = {};
  private _saveSubscription: Subscription = null;
  private _dataSubscription: Subscription;
  private _sizbacSubsciprtion: Subscription = null;
  private _S1DescriptionMessageCd: string = DsamsConstants.NO_ERROR;
  private _StateDescriptionMessageCd: string = DsamsConstants.NO_ERROR;
  private _editSubscription: Subscription = null;
  private _saveCompleteSubscription: Subscription = null;
  private _newModeInfoSubscription: Subscription = null;
  private _panelCollapedSubscription: Subscription = null;
  private _casePanelStatusQuerySubscription: Subscription = null;
  isS1DescriptionRequired: boolean = false;
  isS1DescriptionInvisible: boolean = false;
  isAMDescriptionInvisible: boolean = false;
  isCaseDescriptionRequired: boolean = false;
  isCaseDescriptionInvisible: boolean = false;
  caseVersionData: ICaseVersion;
  loaLabel: string;
  isStateDescriptionRequired: boolean = false;
  isStateDescriptionInvisible: boolean = false;
  isCaseVersionDescriptionEmpty: boolean = false;
  private _isGotInfoFromCIPanel: boolean = false;
  private _currentToggle:boolean = false;
  private _alreadyToggledOn: boolean = false;
  private _skipSavePanel:boolean = false;

  constructor(private caseUIService: CaseUIService) { }

  ngOnInit() {
    // Only fetch data when the panel is opened.
    this._caseUIServiceSubscription = this.caseUIService.panelExpanded.subscribe(
      {
        next: (pnlExpansionProperties: PanelExpansionProperties) => {
          if (pnlExpansionProperties.panelName === DsamsConstants.CASE_PANEL_DESCRIPTIONS ||
            pnlExpansionProperties.panelName === DsamsConstants.CASE_PANEL_ALL) {
            this._pnlExpansionProperties = pnlExpansionProperties;
            this.subscribeToValidateOrSaveRequest();
            this.subscribeToDataService();
            // this.subscribeToSizbacService();
            this.subscribeToEdit();
            // Subscribe to case ui service for optionSelectedUCDU Option for DSCA Update
            this.subscribeToUCDUOption();
            if (this._pnlExpansionProperties.isNewMode) {
              this._currentToggle = true;
              this.enableOrDisableEverything(this._currentToggle);
            }
            this.subscribeToSaveComplete();
            this.subscribeToNewModeInfo();
            this.subscribeToPanelCollapsed();
            this.subscribeToCasePanelStatusQuery();
            this._skipSavePanel = false;               
          }
        }
      });
  }


  // Make sure panel expansion subscription is cleaned up.
  ngOnDestroy() {
    this._caseUIServiceSubscription.unsubscribe();
    if (this._saveSubscription) {
      this._saveSubscription.unsubscribe();
      this._saveSubscription = null;
    }
    if (this._dataSubscription) {
      this._dataSubscription.unsubscribe();
    }
    if (this._sizbacSubsciprtion) {
      this._sizbacSubsciprtion.unsubscribe();
      this._sizbacSubsciprtion = null;
    }
    if (!!this._editSubscription) {
      this._editSubscription.unsubscribe();
      this._editSubscription = null;
    }
    if (!!this._saveCompleteSubscription) {
      this._saveCompleteSubscription.unsubscribe();
      this._saveCompleteSubscription = null;
    }
    if (!!this._newModeInfoSubscription) {
      this._newModeInfoSubscription.unsubscribe();
      this._newModeInfoSubscription = null;
    }
    if (!!this._panelCollapedSubscription) {
      this._panelCollapedSubscription.unsubscribe();
      this._panelCollapedSubscription = null;
    }       
    if (!!this._casePanelStatusQuerySubscription) {
      this._casePanelStatusQuerySubscription.unsubscribe();
      this._casePanelStatusQuerySubscription = null;
    }       
  }


  // Subscribe to panel collapsing
  subscribeToPanelCollapsed() {
    if (!this._panelCollapedSubscription) {
      this._panelCollapedSubscription = this.caseUIService.panelCollapsed.subscribe((panelName: string) => {
        if (panelName === DsamsConstants.CASE_PANEL_DESCRIPTIONS || panelName === DsamsConstants.CASE_PANEL_ALL) 
        {
           this._skipSavePanel = true;
        }
      });
    }
  }

  // Subscribe to Case Panel Status
  subscribeToCasePanelStatusQuery() {
    if (!this._casePanelStatusQuerySubscription) {
      this._casePanelStatusQuerySubscription = this.caseUIService.getPanelCaseVersionStatusQuerySubscription().subscribe(() => {
        this.caseUIService.panelCaseVersionStatusResponseSubscriptionNext(DsamsConstants.CASE_PANEL_DESCRIPTIONS,
                                                                          this.caseDescriptionData[DsamsConstants.PROP_CASE_VERSION_STATUS],
                                                                          this._pnlExpansionProperties.caseRequestParams.caseId,
                                                                          this._pnlExpansionProperties.caseRequestParams.caseVersionId);
      });
    }
  }    


  fieldDisabled(pFieldName: string): boolean {
    // Special Case for S1 Description Field (DSAMS-1597)
    if (pFieldName === "system_1200_DESCRIPTION_TX" && !(this.fieldDisabledMap["system_1200_DESCRIPTION_TX"]) && this.caseUIService.optionSelectedUCCS.getValue()) {
      // Do nothing
    }
    // Special Case for DSCA Update (DSAMS-1587)
    else if (pFieldName === "acas_CASE_DESCRIPTION_TX" && !(this.fieldDisabledMap["acas_CASE_DESCRIPTION_TX"]) && this.caseUIService.optionSelectedUCDU.getValue()) {
      // Do nothing
    }
    else if (pFieldName === "acas_CASE_DESCRIPTION_TX" && !(this.fieldDisabledMap["acas_CASE_DESCRIPTION_TX"]) && this.caseUIService.optionSelectedUCMP.getValue()) {
      // Do nothing
    }
    else if (pFieldName === "case_VERSION_DESCRIPTION_TX" && !(this.fieldDisabledMap["case_VERSION_DESCRIPTION_TX"]) && this.caseUIService.optionSelectedUCMP.getValue()) {
      // Do nothing
    }
    else {
      return CaseUtils.isFieldDisabled(this.fieldDisabledMap, DsamsConstants.CASE_PANEL_DESCRIPTIONS, pFieldName);
    }
  }

  getCaseDescriptionData(): any {
    return this.caseDescriptionData;
  }


  // Flag the field as changed so we can update the record upon save.
  setChangedCV() {
    this.caseDescriptionData[DsamsConstants.PROP_CASE_VERSION_STATUS] = this._pnlExpansionProperties.isNewMode?DsamsConstants.ENT_NEW:DsamsConstants.ENT_CHANGED;
    if (this.caseDescriptionData[DsamsConstants.PROP_CASE_VERSION_STATUS] == DsamsConstants.ENT_UNCHANGED) {
      this.caseUIService.theComponentSaveState[CaseUIService.SAVE_CASE_DETAILS_STATE].isDataChanged = false;
    }
    else
      this.caseUIService.theComponentSaveState[CaseUIService.SAVE_CASE_DETAILS_STATE].isDataChanged = true;   
  }

  setChangedCM() {
    this.caseDescriptionData[DsamsConstants.PROP_CASE_MASTER_STATUS] = this._pnlExpansionProperties.isNewMode?DsamsConstants.ENT_NEW:DsamsConstants.ENT_CHANGED;
    this.setChangedCV();   
  }

  // Subscribe to edit toggle event
  subscribeToEdit() {
    if (!this._editSubscription) {
      this._editSubscription = this.caseUIService
        .caseEditService
        .subscribe((pResponse: IEditResponseType) => {
          if (pResponse && (pResponse.ID === DsamsConstants.CASE_VERSION_EDITOR || pResponse.ID === DsamsConstants.PAGE_CASE_DETAIL)) {
            this.enableOrDisableEverything(pResponse.editToggle);
            this._currentToggle = pResponse.editToggle;
            if (this._currentToggle) {
              this._alreadyToggledOn = true;
            }            
          }
        },
          err => {
            CaseUtils.ReporError("Error in descriptions panel responding to edit toggle");
          }
        );
    }
  }

  // Subscribe to case ui service for optionSelectedUCDU Option for DSCA Update
  subscribeToUCDUOption() {
    // for DSCA update option
    this.caseUIService.optionSelectedUCDU.subscribe((value) => {
      // Set State Description to enable
      if (value) {
        this.fieldDisabledMap["acas_CASE_DESCRIPTION_TX"] = false;
      }
    });
  }
  
 // Subscribe to case ui service for optionSelectedUCMP Update Manager
 subscribeToUCMPOption() {
  this.caseUIService.optionSelectedUCMP.subscribe((value) => {
    // Set fields to
    if (value) {
      this.fieldDisabledMap["acas_CASE_DESCRIPTION_TX"] = false;
      this.fieldDisabledMap["case_VERSION_DESCRIPTION_TX"] = false;
    }
  });
}

  isImpCaseVersionStatus(): boolean {
    return CaseUtils.isImpCaseVersionStatus(this.caseVersionData.case_VERSION_TYPE_CD.toUpperCase());
  }

  // Enable or Disable everything on the panel.
  enableOrDisableEverything(pEnable: boolean) {
    let l_isEnabled: boolean = this._pnlExpansionProperties.isNewMode ? true : pEnable;
    this.fieldDisabledMap[DsamsConstants.CASE_PANEL_DESCRIPTIONS] = !l_isEnabled;
    if (l_isEnabled) {
      this.initializePanelFields();
    }
  }

  initializePanelFields() {
    this.fieldDisabledMap["system_1200_DESCRIPTION_TX"] = <boolean>CaseUtils.getBusinessRuleMapValue(this.caseVersionData.businessRuleMap, "S1_DESCRIPTION_DISABLED", false);

    //State Description Disability
    this.fieldDisabledMap['acas_CASE_DESCRIPTION_TX'] = <boolean>CaseUtils.getBusinessRuleMapValue(this.caseVersionData.businessRuleMap, "STATE_DESCRIPTION_DISABLED", false);

    // Determine This LOA Description Disability
    this.fieldDisabledMap['case_DESCRIPTION_TX'] = <boolean>CaseUtils.getBusinessRuleMapValue(this.caseVersionData.businessRuleMap, "CASE_DESCRIPTION_DISABLED", false);

    // For DSAMS-1590 (Update Implemented Case)
    if (this.isImpCaseVersionStatus() && this.caseUIService.milestoneAddService.getValue() === "UPDTCASE") {
      // Disable S1 Description
      this.fieldDisabledMap["system_1200_DESCRIPTION_TX"] = true;
      // Enable State Desc
      this.fieldDisabledMap["acas_CASE_DESCRIPTION_TX"] = false;
      // if Case Desc is empty, make invisible and Enable LOA Desc
      if (this.isCaseVersionDescriptionEmpty) {
        this.isAMDescriptionInvisible = true;
        this.fieldDisabledMap['case_DESCRIPTION_TX'] = false;
      }
      // otherwise disable the field
      else {
        this.fieldDisabledMap['case_DESCRIPTION_TX'] = true;
      }
    }

    // Push out a dummy record so the field gets enabled/disabled properly.
    let plList: Array<string> = [];
    if (this.fieldDisabledMap["system_1200_DESCRIPTION_TX"] ||
      this.fieldDisabledMap["acas_CASE_DESCRIPTION_TX"] ||
      this.fieldDisabledMap["case_DESCRIPTION_TX"]) {
      plList.push(DsamsConstants.PL_SIZBAC);
    }
    this.caseUIService.sizbacService.next(plList);
  }
  

  getFieldStyleProperty(pElementName: string, isAppearanceNotStyle: boolean): string | object {
    const ERROR_APPEARANCE: string = DsamsConstants.ERROR_APPEARANCE;
    const REGULAR_APPEARANCE: string = DsamsConstants.REGULAR_APPEARANCE;
    const ERROR_STYLE_1 = { "border": "3px solid red" };
    let isError: boolean = false;
    let styleStr: object = {};
    if (pElementName === "system_1200_DESCRIPTION_TX") {
      isError = this.hasS1DescrpitionError();
      styleStr = ERROR_STYLE_1;
    }
    if (pElementName === "acas_CASE_DESCRIPTION_TX") {
      isError = this.hasStateDescriptionError();
      styleStr = ERROR_STYLE_1;
    }
    if (isAppearanceNotStyle) {
      return isError ? ERROR_APPEARANCE : REGULAR_APPEARANCE;
    }
    else {
      return isError ? styleStr : {};
    }
  }


  hasS1DescrpitionError(): boolean {
    return (!(this.fieldDisabled('system_1200_DESCRIPTION_TX')) && this._S1DescriptionMessageCd !== DsamsConstants.NO_ERROR);
  }


  showS1DescrpitionErrorMessage() {
    if (this.hasS1DescrpitionError()) {
      return MessageMgr.getMesssage(this._S1DescriptionMessageCd).messageText;
    }
    else {
      return DsamsConstants.NO_ERROR;
    }
  }

  hasStateDescriptionError(): boolean {
    return (!(this.fieldDisabled('acas_CASE_DESCRIPTION_TX')) && this._StateDescriptionMessageCd !== DsamsConstants.NO_ERROR);
  }


  showStateDescriptionErrorMessage() {
    if (this.hasStateDescriptionError()) {
      return MessageMgr.getMesssage(this._StateDescriptionMessageCd).messageText;
    }
    else {
      return DsamsConstants.NO_ERROR;
    }
  }

  fetchIsDescriptionRequired() {
    if (!(this.isS1DescriptionInvisible) && !(this.fieldDisabledMap["system_1200_DESCRIPTION_TX"])) {
      this.isS1DescriptionRequired = true;
    } else {
      this.isS1DescriptionRequired = false;
    }
  }

  validateS1Description(pFieldValue: string) {
    this._S1DescriptionMessageCd = DsamsConstants.NO_ERROR;

    // No validating if the field is diabled or invisible.
    if (this.isS1DescriptionInvisible == null) {
      this.isS1DescriptionInvisible = false;
    }
    if (this.isS1DescriptionInvisible || this.fieldDisabledMap["system_1200_DESCRIPTION_TX"]) {
      return;
    }

    let newValue: string = pFieldValue;

    // Change to uppercase.
    newValue = newValue.toUpperCase();

    // Replace asterisks with *
    while (newValue.includes("*")) {
      newValue = newValue.toUpperCase().replace("*", " ");
    }

    // First char cannot be a space.
    while (newValue.substring(0, 1) === " ") {
      newValue = newValue.substring(1);
    }

    // Max length 40
    if (newValue.length > 40) {
      newValue = newValue.substring(0, 40);
    }

    // Reformat the value according to the value above.
    (<HTMLInputElement>document.getElementById("txtSYSTEM_1200_DESCRIPTION_TX")).value = newValue;
    this.caseDescriptionData['system_1200_DESCRIPTION_TX'] = newValue;

    // Now validate the new value.  
    if (this.isS1DescriptionRequired && newValue === "") {
      this._S1DescriptionMessageCd = "E040";
    }
    else if (newValue.length < 16) {
      this._S1DescriptionMessageCd = "E041";
    }
  }

  validateStateDescription(pFieldValue: string) {
    this._StateDescriptionMessageCd = DsamsConstants.NO_ERROR;

    // No validating if the field is diabled or invisible.
    if (this.isStateDescriptionInvisible == null) {
      this.isStateDescriptionInvisible = false;
    }
    if (this.isStateDescriptionInvisible || this.fieldDisabledMap["acas_CASE_DESCRIPTION_TX"]) {
      return;
    }

    let newValue: string = pFieldValue;

    // Now validate the new value.  
    if (this.isStateDescriptionRequired && newValue === "") {
      this._StateDescriptionMessageCd = "E042";
    }
  }


  // ******************************* Fetch from database **********************************

  subscribeToDataService() {
    if (this._reloadData) {
      this._dataSubscription = this.caseUIService.caseDetailData.subscribe(
        {
          next: (caseDetailData: ICaseVersion) => {
            if (caseDetailData) {
              this.caseVersionData = caseDetailData;
              CaseUtils.populateCaseRequestParamsType(this._pnlExpansionProperties.caseRequestParams, this.caseVersionData);
              this.caseDescriptionData['case_DESCRIPTION_TX'] = this.caseVersionData.theCaseId.case_DESCRIPTION_TX;
              this.caseDescriptionData['system_1200_DESCRIPTION_TX'] = this.caseVersionData.system_1200_DESCRIPTION_TX;
              this.caseDescriptionData['case_VERSION_DESCRIPTION_TX'] = this.caseVersionData.case_VERSION_DESCRIPTION_TX;
              this.caseDescriptionData['acas_CASE_DESCRIPTION_TX'] = this.caseVersionData.acas_CASE_DESCRIPTION_TX;
              this.loaLabel = <string>CaseUtils.getBusinessRuleMapValue(this.caseVersionData.businessRuleMap, "LOA_LABEL", "");

              //State Department Description Required
              this.isStateDescriptionRequired = <boolean>CaseUtils.getBusinessRuleMapValue(this.caseVersionData.businessRuleMap, "STATE_DESCRIPTION_REQUIRED", false);
              //State Department Description Invisible
              this.isStateDescriptionInvisible = <boolean>CaseUtils.getBusinessRuleMapValue(this.caseVersionData.businessRuleMap, "STATE_DESCRIPTION_INVISIBLE", false);

              // Determine S1 Description Visibility
              this.isS1DescriptionInvisible = <boolean>CaseUtils.getBusinessRuleMapValue(this.caseVersionData.businessRuleMap, "S1_DESCRIPTION_INVISIBLE", false);
              this.isAMDescriptionInvisible = <boolean>CaseUtils.getBusinessRuleMapValue(this.caseVersionData.businessRuleMap, "CASE_VERSION_DESCRIPTION_INVISIBLE", false);
              this.isCaseVersionDescriptionEmpty = <boolean>this.caseDescriptionData['case_VERSION_DESCRIPTION_TX'] === null;
              this.enableOrDisableEverything(this._currentToggle);
              // S1 Description is required if it's enabled and visible.
              const defaultStatus:number = this._pnlExpansionProperties.isNewMode?DsamsConstants.ENT_NEW:DsamsConstants.ENT_UNCHANGED; 
              this.caseDescriptionData[DsamsConstants.PROP_CASE_MASTER_STATUS] = defaultStatus;
              this.caseDescriptionData[DsamsConstants.PROP_CASE_VERSION_STATUS] = defaultStatus;   
              this._pnlExpansionProperties.caseRequestParams.caseId = this.caseVersionData.case_ID;     
              this._pnlExpansionProperties.caseRequestParams.caseVersionId = this.caseVersionData.case_VERSION_ID;  
              this.fetchIsDescriptionRequired();
            }
          }
        }
      );
      this._reloadData = false;
    }
  }

  /**
  * Subscribe to the Sizbac service from the case info panel.
  */
  subscribeToSizbacService() {
    if (!this._sizbacSubsciprtion) {
      this._sizbacSubsciprtion = this.caseUIService
        .sizbacService
        .subscribe((publicLawList: Array<string>) => {
          let hasSizbac: boolean = false;
          if (publicLawList) {
            for (let publicLaw of publicLawList) {
              if (publicLaw === DsamsConstants.PL_SIZBAC) {
                hasSizbac = true;
              }
            }
          }
          this.fieldDisabledMap["system_1200_DESCRIPTION_TX"] = hasSizbac || this.caseVersionData.theCaseId.fouo_APPROVAL_IN;
          if ((hasSizbac || this.caseVersionData.theCaseId.fouo_APPROVAL_IN) && !(this.isS1DescriptionInvisible)) {
            this.caseDescriptionData['system_1200_DESCRIPTION_TX'] = "";
          }
          this.fetchIsDescriptionRequired();
        },
          err => {
            CaseUtils.ReporError("Error in caseUIService.sizbacService in descriptions panel");
          }
        );
    }
  }

  // **************************** Validate/Save ********************************

  // Subcsribe to validate or save request.
  subscribeToValidateOrSaveRequest() {
    if (this._saveSubscription == null) {
      this._saveSubscription = this.caseUIService.saveRequest.subscribe((pSkipValidation:boolean) => {
        if (!this._skipSavePanel) {
          let svResults: SaveResultsType = this.savePanel(pSkipValidation);
          this.caseUIService.saveReturnRequest.next(svResults);
        }
      });
    }
  }


  // Do a validate/save request to the middle tier.
  savePanel(pSkipValidation:boolean): SaveResultsType {
    let valResults: SaveResultsType = new SaveResultsType();
    valResults.currentPanel = DsamsConstants.CASE_PANEL_DESCRIPTIONS; 
    if (!pSkipValidation) {
      let s1Desc: string = this.caseDescriptionData['system_1200_DESCRIPTION_TX'];
      let stateDesc: string = this.caseDescriptionData['acas_CASE_DESCRIPTION_TX'];
      if (s1Desc == null) {
        s1Desc = "";
      }
      if (stateDesc == null) {
        stateDesc = "";
      }
      this.fetchIsDescriptionRequired();
      this.validateS1Description(s1Desc);
      this.validateStateDescription(stateDesc);
      valResults = CaseDescriptionValidator.validateDescriptionPanel (this.caseDescriptionData,
                                                                      this._pnlExpansionProperties,
                                                                      [this._S1DescriptionMessageCd, this._StateDescriptionMessageCd]);
    }
    let svResults: SaveResultsType = new SaveResultsType();
    svResults.currentPanel = valResults.currentPanel;
    svResults.messageList = valResults.messageList;

    if (svResults.isValidationSuccessful()) {
      let cmEntity:ICaseMaster = {status:this.caseDescriptionData[DsamsConstants.PROP_CASE_MASTER_STATUS]};
      let cvEntity:ICaseVersion = {status:this.caseDescriptionData[DsamsConstants.PROP_CASE_VERSION_STATUS]};
      cmEntity.case_DESCRIPTION_TX = this.caseDescriptionData["case_DESCRIPTION_TX"];
      cvEntity.system_1200_DESCRIPTION_TX = this.caseDescriptionData["system_1200_DESCRIPTION_TX"];
      cvEntity.acas_CASE_DESCRIPTION_TX = this.caseDescriptionData["acas_CASE_DESCRIPTION_TX"];
      cvEntity.case_VERSION_DESCRIPTION_TX = this.caseDescriptionData["case_VERSION_DESCRIPTION_TX"];
      cvEntity.theCaseId = cmEntity;
      svResults.caseVersionPanelData = cvEntity;
      this._isGotInfoFromCIPanel = false;
    }
    return svResults;
  }

    // Post-save activities
  subscribeToSaveComplete() {
    if (!this._saveCompleteSubscription) {
      this._saveCompleteSubscription = this.caseUIService.saveCaseVersionComplete.subscribe((pReturnCaseVersion: ICaseVersion) => {
         if (!!pReturnCaseVersion) {
          this.caseUIService.theComponentSaveState[CaseUIService.SAVE_CASE_DETAILS_STATE].isDataChanged = false;
          this.caseUIService.theComponentSaveState[CaseUIService.SAVE_CASE_DETAILS_STATE].isSaveConfirmed.next(false);      
          if (this._isGotInfoFromCIPanel) {
            this._isGotInfoFromCIPanel = false;
          }             
          this.caseDescriptionData[DsamsConstants.PROP_CASE_VERSION_STATUS] = DsamsConstants.ENT_UNCHANGED;
          this.caseDescriptionData[DsamsConstants.PROP_CASE_MASTER_STATUS] = DsamsConstants.ENT_UNCHANGED;
          this._pnlExpansionProperties.caseRequestParams.caseId = pReturnCaseVersion.case_ID;
          this._pnlExpansionProperties.caseRequestParams.caseVersionId = pReturnCaseVersion.case_VERSION_ID;
          this._pnlExpansionProperties.isNewMode = false;
          this.enableOrDisableEverything(this._currentToggle);
         }
      });
    }
  }

  // Subscribe to new mode info coming from CI panel.
  subscribeToNewModeInfo() {
    if (!this._newModeInfoSubscription) {
      this._newModeInfoSubscription = this.caseUIService.newModeInfo.subscribe((pCSI: CaseSaveInfo) => {
        if (!!pCSI) {
          this.caseDescriptionData[DsamsConstants.PROP_CASE_VERSION_STATUS] = pCSI.isNewMode?DsamsConstants.ENT_NEW:DsamsConstants.ENT_UNCHANGED;
          this.caseDescriptionData[DsamsConstants.PROP_CASE_MASTER_STATUS] = pCSI.isNewCaseMaster?DsamsConstants.ENT_NEW:DsamsConstants.ENT_UNCHANGED;
          this._pnlExpansionProperties.caseRequestParams.caseId = pCSI.case_ID;
          this._pnlExpansionProperties.caseRequestParams.caseVersionId = pCSI.case_VERSION_ID;
          this._pnlExpansionProperties.isNewMode = pCSI.isNewMode;
          if (!this._alreadyToggledOn) {     
            this._currentToggle = pCSI.isEditable;
            this.enableOrDisableEverything(this._currentToggle); 
          }
          this._isGotInfoFromCIPanel = false;
        }
      });
    }    
  }
}