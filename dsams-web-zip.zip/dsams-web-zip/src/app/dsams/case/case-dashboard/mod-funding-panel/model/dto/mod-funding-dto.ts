import { ModFundingModel } from "../mod-funding-model";

export interface ModFundingDto {

     provideOrReceive ?:string,
     implementedCaseValue ?: string,
     adjustedCaseValue ?: string,
     relatedCaseVersionData ?: ModFundingModel[]
}
