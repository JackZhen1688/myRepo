/* 
  Author: Francis Shu 
  Date:   03/05/2020 
*/

import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { Subscription } from 'rxjs';
import { MatTableDataSource } from '@angular/material/table';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { CaseRestfulService } from '../../services/case-restful.service';
import { CaseUIService } from '../../services/case-ui-service';
import { DsamsConstants } from 'src/app/dsams/dsams.constants';
import { ReferenceDataType } from '../../model/reference-data-type';
import { CaseUtils } from '../../utils/case-utils';
import { PanelExpansionProperties } from '../../model/panel-expansion-properties';
import { MdePopoverTrigger } from '@material-extended/mde';
import { FormBuilder, FormGroup } from '@angular/forms';
import { DsamsMethodsService } from '../../../../dsams/services/dsams-methods.service';
import { PopCaseAssociationComponent } from '../../../utilitis/popups/pop-case-association/pop-case-association.component';
import { FieldDisabledMap } from '../../model/field-disabled-map';
import { ICaseVersion } from '../../model/dto/icase-version';
import { IRelatedCase } from '../../model/dto/related-case';
import { ICaseMaster } from '../../model/dto/icase-master';
import { IAssociatedCase } from '../../model/dto/associated-case';
import { DateValidator } from '../../validation/date-validator';
import { SaveResultsType } from '../../validation/save-results-type';
import { CaseAssociationsValidator } from '../../validation/case-associations-validator';
import { IEditResponseType } from '../../model/edit-response-type';
import { CaseSaveInfo } from '../../model/case-save-info';

declare function focusItem(pItem: string): any;

export class assoRelCaseConstants {
  static readonly iconImageArrowUp = "arrow_drop_up";
  static readonly iconImageArrowDown = "arrow_drop_down";
}

export class assoAssociationConstants {
  static readonly iconAssoImageArrowUp = "arrow_drop_up";
  static readonly iconAssoImageArrowDown = "arrow_drop_down";
}

export interface theAssoRelCaseArray {
  iconImg: string; Case: string;
  DocType: string;
  SAProgram: string; LastDocument: string;
  Status: string; StatusDate: string;
  TotalCashValue: string;
}

export interface theAssoAssociationArray {
  iconAssoImg: string; Case: string;
}

const theAssoRelCaseData: theAssoRelCaseArray[] = []

const theAssoAssociationData: theAssoAssociationArray[] = []

@Component({
  selector: 'app-associations-panel',
  templateUrl: './associations-panel.component.html',
  styleUrls: ['./associations-panel.component.css',
    '../common-CSS.component.css'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0', minHeight: '0', display: 'none' })),
      state('expanded', style({ height: '*' })),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})

export class AssociationsPanelComponent implements OnInit, OnDestroy {
  private caseAssociationData: any = {};
  private _caseUIServiceSubscription: Subscription;
  private _reloadData: boolean = true;
  private _reloadReferenceData: boolean = true;
  private _pnlExpansionProperties: PanelExpansionProperties;
  private fieldDisabledMap: FieldDisabledMap = {};
  private _dataSubscription: Subscription;
  private _relatedCaseAddSubscription: Subscription = null;
  private _saveSubscription: Subscription = null;
  private _saveCompleteSubscription: Subscription = null;
  private _editSubscription: Subscription = null;
  private _dataReturnedFlag: boolean = false;
  private _newModeInfoSubscription: Subscription = null;
  private _panelCollapedSubscription: Subscription = null;
  private _casePanelStatusQuerySubscription: Subscription = null;
  private _isGotInfoFromCIPanel: boolean = false;
  private _currentToggle: boolean = false;
  private _dataServiceRun: boolean = false;
  private _alreadyToggledOn: boolean = false;
  private _skipSavePanel: boolean = false;
  private _somethingChanged: boolean = false;

  @ViewChild(MdePopoverTrigger, { static: true }) trigger: MdePopoverTrigger;

  dataSourceAssociations: MatTableDataSource<any>;
  aAssociationlArray = [];
  aAssoAssociationTest = new MatTableDataSource(this.aAssociationlArray);

  columnsToDisplayAssociations = ['DocType', 'Case', 'SAProgram', 'LastDocument', 'Status', 'StatusDate', 'TotalCashValue', 'DeleteRow'];
  aAssociationRowIndex: number = 0;
  expandedElement: null;
  displaySubcolumns = ['rationale'];
  iconImage: any = assoRelCaseConstants.iconImageArrowDown;
  theSourceAssoRelCaseData = theAssoRelCaseData;

  dataSourceAssoAssociations = new MatTableDataSource();
  aAssoAssociationlArray = [];

  columnsToDisplayAssoAssociations = ['UserCaseId', 'DeleteRow'];
  aAssoAssociationRowIndex: number = 0;
  expandedAssoElement: null;
  displayAssoSubcolumns = ['justification'];
  iconAssoImage: any = assoRelCaseConstants.iconImageArrowDown;
  theSourceAssoAssociationData = theAssoAssociationData;
  refCaseUsageIndicatorList: Array<ReferenceDataType> = [];
  private _caseVersionData: ICaseVersion;
  caseAssociationForm: FormGroup;
  FIELD_REQUIRED_MSG: string = DsamsConstants.FIELD_REQUIRED_MSG;

  constructor(private caseRestService: CaseRestfulService,
    private caseUIService: CaseUIService,
    private formBuilder: FormBuilder,
    public dsamsMethodsService: DsamsMethodsService) { }

  ngOnInit() {
    // Only fetch data when the panel is opened.
    this._caseUIServiceSubscription = this.caseUIService.panelExpanded.subscribe(
      {
        next: (pnlExpansionProperties: PanelExpansionProperties) => {
          if (pnlExpansionProperties.panelName === DsamsConstants.CASE_PANEL_ASSOCIATIONS ||
            pnlExpansionProperties.panelName === DsamsConstants.CASE_PANEL_ALL) {
            this._pnlExpansionProperties = pnlExpansionProperties;
            if (this._pnlExpansionProperties.isResetPanels) {
              this._reloadData = true;
              this._reloadReferenceData = true;
            }
            sessionStorage.setItem('caseAssoPopupValue', '');
            this._dataReturnedFlag = false;
            this.fetchReferenceData();
            this.subscribeToDataService();
            this.subscribeToRelatedCaseAdd();
            this.subscribeToValidateOrSaveRequest();
            this.subscribeToEdit();
            if (this._pnlExpansionProperties.isNewMode) {
              this._currentToggle = true;
              this.enableOrDisableEverything(this._currentToggle);
            }
            this.subscribeToSaveComplete();
            this.subscribeToNewModeInfo();
            this.subscribeToPanelCollapsed();
            this.subscribeToCasePanelStatusQuery();
            this._skipSavePanel = false;
          }
        }
      });
    this.constructCaseAssociationForm();
  }


  // Subscribe to panel collapsing
  subscribeToPanelCollapsed() {
    if (!this._panelCollapedSubscription) {
      this._panelCollapedSubscription = this.caseUIService.panelCollapsed.subscribe((panelName: string) => {
        if (panelName === DsamsConstants.CASE_PANEL_ASSOCIATIONS || panelName === DsamsConstants.CASE_PANEL_ALL) {
          this._skipSavePanel = true;
        }
      });
    }
  }


  // Subscribe to request for panel status.
  subscribeToCasePanelStatusQuery() {
    if (!this._casePanelStatusQuerySubscription) {
      this._casePanelStatusQuerySubscription = this.caseUIService.getPanelCaseVersionStatusQuerySubscription().subscribe(() => {
        let currStatus: number = this._somethingChanged ? DsamsConstants.ENT_CHANGED : DsamsConstants.ENT_UNCHANGED;
        currStatus = this._pnlExpansionProperties.isNewMode ? DsamsConstants.ENT_NEW : currStatus;
        this.caseUIService.panelCaseVersionStatusResponseSubscriptionNext(DsamsConstants.CASE_PANEL_ASSOCIATIONS,
          currStatus,
          this._pnlExpansionProperties.caseRequestParams.caseId,
          this._pnlExpansionProperties.caseRequestParams.caseVersionId);
      });
    }
  }


  constructCaseAssociationForm() {
    this.caseAssociationForm = this.formBuilder.group({
      'txtSuffix': this.formBuilder.control(''),
    });
  }

  // Popup Window
  popupCaseAssociation(elementName: string): void {
    let diaWidth: string = "70%";
    let diaHeight: string = "70%";
    let passingData: string = "";

    // Pass in elementName - Associated or Related
    this.dsamsMethodsService.openSearchDialogCase(diaWidth, diaHeight, passingData, PopCaseAssociationComponent, this.caseAssociationForm, elementName);
  }


  // Make sure panel expansion subscription is cleaned up.
  ngOnDestroy() {
    this._caseUIServiceSubscription.unsubscribe();
    if (this._dataSubscription) {
      this._dataSubscription.unsubscribe();
      this._dataSubscription = null;
    }
    if (this._relatedCaseAddSubscription) {
      this._relatedCaseAddSubscription.unsubscribe();
      this._relatedCaseAddSubscription = null;
    }
    if (this._saveSubscription) {
      this._saveSubscription.unsubscribe();
      this._saveSubscription = null;
    }
    if (!!this._editSubscription) {
      this._editSubscription.unsubscribe();
      this._editSubscription = null;
    }
    if (!!this._saveCompleteSubscription) {
      this._saveCompleteSubscription.unsubscribe();
      this._saveCompleteSubscription = null;
    }
    if (!!this._newModeInfoSubscription) {
      this._newModeInfoSubscription.unsubscribe()
      this._newModeInfoSubscription = null;
    }
    if (!!this._panelCollapedSubscription) {
      this._panelCollapedSubscription.unsubscribe();
      this._panelCollapedSubscription = null;
    }
    if (!!this._casePanelStatusQuerySubscription) {
      this._casePanelStatusQuerySubscription.unsubscribe();
      this._casePanelStatusQuerySubscription = null;
    }
  }

  // Flag the record as changed.
  setChangedRC(pElement: any, pIndex: number) {
    if (pElement.status == DsamsConstants.ENT_UNCHANGED) {
      pElement.status = DsamsConstants.ENT_CHANGED;
      this.caseUIService.theComponentSaveState[CaseUIService.SAVE_CASE_DETAILS_STATE].isDataChanged = true;
    }
    const idx: number = pIndex == -1 ? this.caseAssociationData["caseRelatedCaseList"].indexOf(pElement) : pIndex;
    this.caseAssociationData["caseRelatedCaseList"][idx].status = pElement.status;
    this._somethingChanged = true;
  }

  setChangedAC(pElement: any) {
    if (pElement.status == DsamsConstants.ENT_UNCHANGED) {
      pElement.status = DsamsConstants.ENT_CHANGED;
      this.caseUIService.theComponentSaveState[CaseUIService.SAVE_CASE_DETAILS_STATE].isDataChanged = true;
    }
    const idx: number = this.dataSourceAssoAssociations.data.indexOf(pElement);
    this.caseAssociationData["caseAssociatedCaseList"][idx].status = pElement.status;
    this._somethingChanged = true;
  }


  getFieldStyleProperty(pElement: any, pElementName: string, isAppearanceNotStyle: boolean): string | object {
    const ERROR_APPEARANCE: string = DsamsConstants.ERROR_APPEARANCE;
    const REGULAR_APPEARANCE: string = DsamsConstants.REGULAR_APPEARANCE;
    const ERROR_STYLE_1 = { "border": "2px solid red", "padding-top": "5%", "padding-bottom": "5%", "border-radius": "4px", "vertical-align": "top", "margin-top": "-20px" };
    const ERROR_STYLE_2 = { "border": "2px solid red", "border-radius": "8px" };
    let isError: boolean = false;
    let styleStr: object = {};
    if (pElementName === "user_CASE_ID") {
      isError = (
        pElement.userCaseIdRequired ||
        pElement.userCaseIdTooShort ||
        pElement.userCaseIdIAInvalid ||
        pElement.userCaseIdPseudo ||
        pElement.userCaseIdNotFound);
      styleStr = ERROR_STYLE_1;
    }
    else if (pElementName === "associated_CASE_RATIONALE_TX") {
      isError = pElement.acRationaleInvalid;
      styleStr = ERROR_STYLE_2;
    }
    if (isAppearanceNotStyle) {
      return isError ? ERROR_APPEARANCE : REGULAR_APPEARANCE;
    }
    else {
      return isError ? styleStr : {};
    }
  }


  /* Check Used User Case ID for Associated Cases */
  checkUserCaseIdAC(pElement: any) {
    pElement.userCaseIdMessage = "";
    if (!pElement.userCaseIdChanged) {
      pElement.userCaseIdChanged = true;
    }
    pElement.userCaseIdRequired = (pElement.user_CASE_ID === "");
    pElement.userCaseIdTooShort = (pElement.user_CASE_ID !== "" && pElement.user_CASE_ID.length < 6);
    pElement.userCaseIdIAInvalid = (pElement.user_CASE_ID.substr(2, 1) === this._pnlExpansionProperties.caseRequestParams.implementingAgencyId);
    if (pElement.userCaseIdRequired || pElement.userCaseIdTooShort || pElement.userCaseIdIAInvalid) {
      this.setACUserMessagesForDisplay(pElement);
      this.setMessagesAndSavability();
    }
    else {
      // Call database and return.
      const custOrgId = pElement.user_CASE_ID.substr(0, 2);
      const implAgencyId = pElement.user_CASE_ID.substr(2, 1);
      const caseDesignatorCd = pElement.user_CASE_ID.substr(3, 5);
      this.caseUIService.canSave.next(false);  // DIsabled while we make database call.
      this.caseRestService.checkUsedUserCaseForAssoc(caseDesignatorCd, implAgencyId, custOrgId)
        .subscribe((errMsg: number) => {
          pElement.userCaseIdPseudo = (errMsg == 1);
          pElement.userCaseIdNotFound = (errMsg == 2);
          this.setACUserMessagesForDisplay(pElement);
          this.setMessagesAndSavability();
        },
          err => {
            CaseUtils.ReportHTTPError(err, "Error checking user case ID for assoc case");
            this.setACUserMessagesForDisplay(pElement);
            this.setMessagesAndSavability();
          }
        );
    }
  }


  /* Check Used User Case ID for Related Cases */
  checkUserCaseIdRC(pElement: any) {
    this.caseUIService.canSave.next(false);
    pElement.userCaseIdRequired = false;
    pElement.userCaseIdTooShort = false;
    pElement.userCaseIdIAInvalid = false;
    const currIndex = this.dataSourceAssociations.data.indexOf(pElement);
    let hasIssue: boolean = false;
    if (pElement.case_USAGE_INDICATOR_CD === "" || pElement.user_CASE_ID === "") {
      pElement.userCaseIdRequired = true;
      hasIssue = true;
    }
    else if (pElement.user_CASE_ID.length < 6) {
      pElement.userCaseIdTooShort = true;
      hasIssue = true;
    }
    if (hasIssue) {
      this.setChangedRC(pElement, currIndex);
      this.setMessagesAndSavability();
      return;
    }
    const oldRelatedCaseId: number = pElement.old_RELATED_CASE_ID;
    const oldRelatedCaseTx: string = pElement.old_RELATED_CASE_RATIONALE_TX
    this.caseRestService
      .checkUsedUserCaseForRC(pElement.case_USAGE_INDICATOR_CD, pElement.user_CASE_ID)
      .subscribe((pCaseMaster: ICaseMaster) => {
        const cmFound: boolean = !!pCaseMaster;
        const caseVersion: ICaseVersion = cmFound ? pCaseMaster.caseVersionList[0] : null;
        const updItem = {
          rowNum: currIndex,
          status: pElement.status,
          case_ID: this._pnlExpansionProperties.caseRequestParams.caseId,
          iconImg: assoRelCaseConstants.iconImageArrowDown,
          user_CASE_ID: pElement.user_CASE_ID,
          case_VERSION_TYPE_CD: cmFound ? caseVersion.case_VERSION_TYPE_CD : "",
          case_VERSION_TYPE_NM: cmFound ? caseVersion.theCaseVersionTypeCd.case_VERSION_TYPE_NM : "",
          case_USAGE_INDICATOR_CD: pElement.case_USAGE_INDICATOR_CD,
          case_USAGE_TITLE_NM: "",
          related_CASE_RATIONALE_TX: "",
          security_ASSISTANCE_PROGRAM_CD: cmFound ? pCaseMaster.security_ASSISTANCE_PROGRAM_CD : "",
          case_VERSION_STATUS_DT: cmFound ? DateValidator.dateToString(CaseUtils.numberToDate(caseVersion.case_VERSION_STATUS_DT)) : "",
          case_VERSION_STATUS_CD: cmFound ? caseVersion.case_VERSION_STATUS_CD : "",
          version_STATUS_TITLE_NM: cmFound ? caseVersion.theCaseVersionStatusCd.version_STATUS_TITLE_NM : "",
          case_VERSION_NUMBER_ID: cmFound ? caseVersion.case_VERSION_NUMBER_ID : "",
          total_CASE_VALUE_AM: cmFound ? CaseUtils.getBusinessRuleMapValue(pCaseMaster.businessRuleMap, "TOTAL_CASE_VERSION_DERIVED_VALUE", "0") : 0,
          related_CASE_ID: cmFound ? pCaseMaster.case_ID : 0,
          old_RELATED_CASE_ID: oldRelatedCaseId,
          old_RELATED_CASE_RATIONALE_TX: oldRelatedCaseTx,
          case_DESCRIPTION_TX: cmFound ? pCaseMaster.case_DESCRIPTION_TX : "",
          userCaseIdRequired: false,
          userCaseIdTooShort: false,
          userCaseIdIAInvalid: false,
          userCaseIdNotFound: !cmFound
        };
        (<Array<any>>this.caseAssociationData["caseRelatedCaseList"])[currIndex] = updItem;
        this.dataSourceAssociations = new MatTableDataSource(this.caseAssociationData["caseRelatedCaseList"]);
        this.dataSourceAssociations._updateChangeSubscription();
        this.setChangedRC(pElement, currIndex);
        this.setMessagesAndSavability();
      },
        err => {
          CaseUtils.ReportHTTPError(err, "Error checking user case ID for related case");
          this.setMessagesAndSavability();
        }
      );
  }


  checkACRationale(pElement: any) {
    if (!pElement.acRationaleChanged) {
      pElement.acRationaleChanged = true;
    }
    pElement.acRationaleInvalid = (pElement.associated_CASE_RATIONALE_TX === "");
    this.setACUserMessagesForDisplay(pElement);
    this.setMessagesAndSavability();
  }


  setACUserMessagesForDisplay(pElement: any) {
    // user case ID
    let userCaseIdError: string = null;
    userCaseIdError = pElement.userCaseIdRequired ? this.FIELD_REQUIRED_MSG : null;
    if (!userCaseIdError) {
      userCaseIdError = pElement.userCaseIdTooShort ? "Must be 6 chars long." : null;
    }
    if (!userCaseIdError) {
      userCaseIdError = pElement.userCaseIdIAInvalid ? "The case's implementing agency ID cannot equal the associated case's implementing agency ID." : null;
    }
    if (!userCaseIdError) {
      userCaseIdError = pElement.userCaseIdPseudo ? "Associated Case Customer Organization cannot be a pseudo-country." : null;
    }
    if (!userCaseIdError) {
      userCaseIdError = pElement.userCaseIdNotFound ? "Associated Case does not exist." : null;
    }
    pElement.userCaseIdMessage = !userCaseIdError ? "" : userCaseIdError;
    // Rationale message
    let acRationaleMessage: string = null;
    acRationaleMessage = pElement.acRationaleInvalid ? this.FIELD_REQUIRED_MSG : null;
    pElement.acRationaleMessage = !acRationaleMessage ? "" : acRationaleMessage;
  }


  setRCUserMessageForDisplay(pElement: any) {
    let userCaseIdError: string = null;
    userCaseIdError = pElement.userCaseIdRequired ? this.FIELD_REQUIRED_MSG : null;
    if (!userCaseIdError) {
      userCaseIdError = pElement.userCaseIdTooShort ? "Must be 6 chars long." : null;
    }
    if (!userCaseIdError) {
      userCaseIdError = pElement.userCaseIdNotFound ? "Related Case does not exist." : null;
    }
    pElement.userCaseIdMessage = !userCaseIdError ? "" : userCaseIdError;
  }


  private setMessagesAndSavability() {
    let hasError: boolean = false;
    // Check related cases.
    for (let i = 0; i < this.caseAssociationData["caseRelatedCaseList"].length; i++) {
      let rcRow = this.caseAssociationData["caseRelatedCaseList"][i];
      this.setRCUserMessageForDisplay(rcRow);
      if (rcRow.status != DsamsConstants.ENT_UNCHANGED && rcRow.userCaseIdMessage !== DsamsConstants.NO_ERROR) {
        hasError = true;
        break;
      }
    }
    // Check associated cases.
    if (!hasError) {
      for (let i = 0; i < this.caseAssociationData["caseAssociatedCaseList"].length; i++) {
        let assocRow = this.caseAssociationData["caseAssociatedCaseList"][i];
        this.setACUserMessagesForDisplay(assocRow);
        if (assocRow.status != DsamsConstants.ENT_UNCHANGED && assocRow.userCaseIdMessage !== DsamsConstants.NO_ERROR) {
          hasError = true;
          break;
        }
      }
    }
    this.caseUIService.canSave.next(!hasError);
  }


  isRelatedCaseListPopulated(): boolean {
    return !!(this.caseAssociationData["caseRelatedCaseList"]) || this._pnlExpansionProperties.isNewMode;
  }


  isAssociatedCaseListPopulated(): boolean {
    return !!(this.caseAssociationData["caseAssociatedCaseList"]) || this._pnlExpansionProperties.isNewMode;
  }


  initializeAssociationArray() {
    let tmpArray: Array<any> = [];
    let currRC: ICaseMaster = null;
    let currRC_MRV: ICaseVersion = null;
    this.caseAssociationData["caseRelatedCaseDeletedList"] = [];
    this.aAssociationRowIndex = !this._caseVersionData.theCaseId.relatedCaseCaseIdList ? 0 : this._caseVersionData.theCaseId.relatedCaseCaseIdList.length;
    for (var i = 0; i < this.aAssociationRowIndex; i++) {
      currRC = this._caseVersionData.theCaseId.relatedCaseCaseIdList[i].theRelatedCaseId;
      currRC_MRV = currRC.caseVersionList[0];
      tmpArray[i] = {
        rowNum: i,
        status: DsamsConstants.ENT_UNCHANGED,
        case_ID: this._pnlExpansionProperties.caseRequestParams.caseId,
        old_CASE_ID: this._pnlExpansionProperties.caseRequestParams.caseId,
        iconImg: assoRelCaseConstants.iconImageArrowDown,
        user_CASE_ID: CaseUtils.formatUserCaseId(currRC.user_CASE_ID),
        case_VERSION_TYPE_CD: currRC_MRV.case_VERSION_TYPE_CD,
        case_VERSION_TYPE_NM: currRC_MRV.theCaseVersionTypeCd.case_VERSION_TYPE_NM,
        case_USAGE_INDICATOR_CD: currRC.case_USAGE_INDICATOR_CD,
        case_USAGE_TITLE_NM: currRC.theCaseUsageIndicatorCd.case_USAGE_TITLE_NM,
        related_CASE_RATIONALE_TX: this._caseVersionData.theCaseId.relatedCaseCaseIdList[i].related_CASE_RATIONALE_TX,
        old_RELATED_CASE_RATIONALE_TX: this._caseVersionData.theCaseId.relatedCaseCaseIdList[i].related_CASE_RATIONALE_TX,
        security_ASSISTANCE_PROGRAM_CD: currRC.security_ASSISTANCE_PROGRAM_CD,
        case_VERSION_STATUS_DT: DateValidator.dateToString(CaseUtils.numberToDate(currRC_MRV.case_VERSION_STATUS_DT)),
        case_VERSION_STATUS_CD: currRC_MRV.case_VERSION_STATUS_CD,
        version_STATUS_TITLE_NM: currRC_MRV.theCaseVersionStatusCd.version_STATUS_TITLE_NM,
        case_VERSION_NUMBER_ID: currRC_MRV.case_VERSION_NUMBER_ID <= 0 ? "" : currRC_MRV.case_VERSION_NUMBER_ID,
        total_CASE_VALUE_AM: CaseUtils.getBusinessRuleMapValue(currRC.businessRuleMap, "TOTAL_CASE_VERSION_DERIVED_VALUE", "0"),
        related_CASE_ID: currRC.case_ID,   // This is the related case's case_id.
        old_RELATED_CASE_ID: currRC.case_ID,
        case_DESCRIPTION_TX: currRC.case_DESCRIPTION_TX,
        userCaseIdRequired: false,
        userCaseIdTooShort: false,
        userCaseIdIAInvalid: false
      }
    }
    this.caseAssociationData["caseRelatedCaseList"] = tmpArray;
    this.dataSourceAssociations = new MatTableDataSource(this.caseAssociationData["caseRelatedCaseList"]);
    this.dataSourceAssociations._updateChangeSubscription();
  }


  addNewRelatedCaseItem() {
    this.aAssociationRowIndex = this.aAssociationRowIndex + 1;

    if (!(this.caseAssociationData["caseRelatedCaseList"])) {
      this.caseAssociationData["caseRelatedCaseList"] = [];
    }

    const caseAssoPopupValues: string = sessionStorage.getItem('caseAssoPopupValue');
    const caseAssoPopupArray: Array<string> = !caseAssoPopupValues ? [] : caseAssoPopupValues.split(',');

    let newItem: any = null;

    // Do for each item in array
    for (let i = 0; i < caseAssoPopupArray.length; i++) {
      if (!!caseAssoPopupArray[i] && caseAssoPopupArray[i] !== "") {
        this.caseRestService
          .getRelatedCaseMaster(+caseAssoPopupArray[i])
          .subscribe(
            (data: ICaseMaster) => {
              const caseVersion: ICaseVersion = data.caseVersionList[0];
              newItem = {
                rowNum: this.aAssociationRowIndex++,
                status: DsamsConstants.ENT_NEW,
                case_ID: this._pnlExpansionProperties.caseRequestParams.caseId,
                iconImg: assoRelCaseConstants.iconImageArrowDown,
                user_CASE_ID: CaseUtils.formatUserCaseId(data.user_CASE_ID),
                case_VERSION_TYPE_CD: caseVersion.case_VERSION_TYPE_CD,
                case_VERSION_TYPE_NM: caseVersion.theCaseVersionTypeCd.case_VERSION_TYPE_NM,
                case_USAGE_INDICATOR_CD: data.case_USAGE_INDICATOR_CD,
                case_USAGE_TITLE_NM: "",
                related_CASE_RATIONALE_TX: "",
                security_ASSISTANCE_PROGRAM_CD: data.security_ASSISTANCE_PROGRAM_CD,
                case_VERSION_STATUS_DT: DateValidator.dateToString(CaseUtils.numberToDate(caseVersion.case_VERSION_STATUS_DT)),
                case_VERSION_STATUS_CD: caseVersion.case_VERSION_STATUS_CD,
                version_STATUS_TITLE_NM: caseVersion.theCaseVersionStatusCd.version_STATUS_TITLE_NM,
                case_VERSION_NUMBER_ID: caseVersion.case_VERSION_NUMBER_ID,
                total_CASE_VALUE_AM: CaseUtils.getBusinessRuleMapValue(data.businessRuleMap, "TOTAL_CASE_VERSION_DERIVED_VALUE", "0"),
                related_CASE_ID: data.case_ID,
                case_DESCRIPTION_TX: data.case_DESCRIPTION_TX,
                userCaseIdRequired: false,
                userCaseIdTooShort: false,
                userCaseIdIAInvalid: false
              };
              (<Array<any>>this.caseAssociationData["caseRelatedCaseList"]).push(newItem);
              if (this.caseAssociationData["caseRelatedCaseList"].length > this.dataSourceAssociations.data.length) {
                this.dataSourceAssociations.data.push(newItem);
              }
              this.dataSourceAssociations._updateChangeSubscription();
            },
            err => {
              CaseUtils.ReportHTTPError(err, "Error fetching related case info from popup.");
            }
          );
      }
    }
    focusItem("case_USAGE_INDICATOR_CD" + +this.aAssociationRowIndex);
    this._somethingChanged = true;
    this.caseUIService.theComponentSaveState[CaseUIService.SAVE_CASE_DETAILS_STATE].isDataChanged = true;
  }

  /**
   * Add an associated case item.
   */
  addACItem(): void {
    this.aAssoAssociationRowIndex++;
    if (!(this.caseAssociationData["caseAssociatedCaseList"])) {
      this.caseAssociationData["caseAssociatedCaseList"] = [];
    }
    let tmpElement: any = {
      rowNum: this.aAssoAssociationRowIndex,
      status: DsamsConstants.ENT_NEW,
      iconAssoImg: assoAssociationConstants.iconAssoImageArrowDown,
      case_ID: this._pnlExpansionProperties.caseRequestParams.caseId,
      customer_ORGANIZATION_ID: "",
      implementing_AGENCY_ID: "",
      case_DESIGNATOR_CD: "",
      associated_CASE_RATIONALE_TX: "",
      user_CASE_ID: "",
      old_USER_CASE_ID: "",
      userCaseIdRequired: false,
      userCaseIdTooShort: false,
      userCaseIdIAInvalid: false,
      userCaseIdPseudo: false,
      userCaseIdNotFound: false,
      userCaseIdMessage: "",
      userCaseIdChanged: false,
      acRationaleInvalid: false,
      acRationaleMessage: "",
      acRationaleChanged: false
    };
    (<Array<any>>this.caseAssociationData["caseAssociatedCaseList"]).push(tmpElement);
    focusItem("txtUSER_CASE_ID" + +this.aAssoAssociationRowIndex);
    this.dataSourceAssoAssociations._updateChangeSubscription();
    this._somethingChanged = true;
    this.caseUIService.theComponentSaveState[CaseUIService.SAVE_CASE_DETAILS_STATE].isDataChanged = true;
    this.setMessagesAndSavability();
  }

  /**
   * Initialize Associated Case Array
   */
  initializeAssoAssociationArray() {
    this.caseAssociationData["caseAssociatedCaseList"] = [];
    this.caseAssociationData["caseAssociatedCaseDeletedList"] = [];
    let tmpArray: Array<any> = [];
    let currAC: IAssociatedCase = null;
    this.aAssoAssociationRowIndex = !(this._caseVersionData.theCaseId.associatedCaseList) ? 0 : this._caseVersionData.theCaseId.associatedCaseList.length;
    for (var i = 0; i < this.aAssoAssociationRowIndex; i++) {
      currAC = Object.assign(this._caseVersionData.theCaseId.associatedCaseList[i]);
      tmpArray[i] = {
        rowNum: i,
        status: DsamsConstants.ENT_UNCHANGED,
        iconAssoImg: assoAssociationConstants.iconAssoImageArrowDown,
        case_ID: this._pnlExpansionProperties.caseRequestParams.caseId,
        customer_ORGANIZATION_ID: currAC.customer_ORGANIZATION_ID,
        implementing_AGENCY_ID: currAC.implementing_AGENCY_ID,
        case_DESIGNATOR_CD: currAC.case_DESIGNATOR_CD,
        user_CASE_ID: CaseUtils.formatUserCaseId(currAC.customer_ORGANIZATION_ID + currAC.implementing_AGENCY_ID + currAC.case_DESIGNATOR_CD),
        old_USER_CASE_ID: CaseUtils.formatUserCaseId(currAC.customer_ORGANIZATION_ID + currAC.implementing_AGENCY_ID + currAC.case_DESIGNATOR_CD),
        customer_ORGANIZATION_ID_ORIG: currAC.customer_ORGANIZATION_ID,
        implementing_AGENCY_ID_ORIG: currAC.implementing_AGENCY_ID,
        case_DESIGNATOR_CD_ORIG: currAC.case_DESIGNATOR_CD,
        associated_CASE_RATIONALE_TX: currAC.associated_CASE_RATIONALE_TX,
        userCaseIdRequired: false,
        userCaseIdTooShort: false,
        userCaseIdIAInvalid: false,
        userCaseIdPseudo: false,
        userCaseIdNotFound: false,
        userCaseIdMessage: "",
        userCaseIdChanged: false,
        acRationaleInvalid: false,
        acRationaleMessage: "",
        acRationaleChanged: false
      }
    }
    this.caseAssociationData["caseAssociatedCaseList"] = tmpArray;
    this.dataSourceAssoAssociations = new MatTableDataSource(this.caseAssociationData["caseAssociatedCaseList"]);
  }

  yesButtonWaiverOnClick(isDeleteConfirmed: any, rowElement: any) {
    if (isDeleteConfirmed) {
      this.delRCItem(rowElement);
    }
  }

  delRCItem(rowElement: any) {
    (<Array<any>>this.caseAssociationData["caseRelatedCaseDeletedList"]).push(rowElement);
    (<Array<any>>this.caseAssociationData["caseRelatedCaseList"]).splice(this.dataSourceAssociations.data.indexOf(rowElement), 1);
    this.dataSourceAssociations = new MatTableDataSource(this.caseAssociationData["caseRelatedCaseList"]);
    this._somethingChanged = true;
    this.caseUIService.theComponentSaveState[CaseUIService.SAVE_CASE_DETAILS_STATE].isDataChanged = true;
    this.setMessagesAndSavability();
  }

  yesButtonAssoOnClick(isDeleteConfirmed: any, rowElement: any) {
    if (isDeleteConfirmed) {
      this.delAssoItem(rowElement);
    }
  }

  delAssoItem(rowElement: any) {
    (<Array<any>>this.caseAssociationData["caseAssociatedCaseDeletedList"]).push(rowElement);
    (<Array<any>>this.caseAssociationData["caseAssociatedCaseList"]).splice(this.dataSourceAssoAssociations.data.indexOf(rowElement), 1);
    this.dataSourceAssoAssociations = new MatTableDataSource(this.caseAssociationData["caseAssociatedCaseList"]);
    this._somethingChanged = true;
    this.caseUIService.theComponentSaveState[CaseUIService.SAVE_CASE_DETAILS_STATE].isDataChanged = true;
    this.setMessagesAndSavability();
  }

  getIconImage(object: theAssoAssociationArray) {
    return (object.iconAssoImg);
  }

  changeIconImages(rowElement: any) {
    let rowN: number = this.dataSourceAssociations.data.indexOf(rowElement);
    var str: string = ((this.dataSourceAssociations.data[rowN] as theAssoRelCaseArray).iconImg);

    if (str === assoRelCaseConstants.iconImageArrowDown) {
      (this.dataSourceAssociations.data[rowN] as theAssoRelCaseArray).iconImg = assoRelCaseConstants.iconImageArrowUp;
    }
    else {
      (this.dataSourceAssociations.data[rowN] as theAssoRelCaseArray).iconImg = assoRelCaseConstants.iconImageArrowDown;
    }
    this.expandedElement === rowElement ? this.expandedElement = null : this.expandedElement = rowElement;
  }


  // Determine if a field is disabled.
  fieldDisabled(pFieldName: string): boolean {
    return CaseUtils.isFieldDisabled(this.fieldDisabledMap, DsamsConstants.CASE_PANEL_ASSOCIATIONS, pFieldName);
  }


  // Subscribe to edit toggle event
  subscribeToEdit() {
    if (!this._editSubscription) {
      this._editSubscription = this.caseUIService
        .caseEditService
        .subscribe((pResponse: IEditResponseType) => {
          if (pResponse && (pResponse.ID === DsamsConstants.CASE_VERSION_EDITOR || pResponse.ID === DsamsConstants.PAGE_CASE_DETAIL)) {
            this.enableOrDisableEverything(pResponse.editToggle);
            this._currentToggle = pResponse.editToggle;
            if (this._currentToggle) {
              this._alreadyToggledOn = true;
            }
          }
        },
          err => {
            CaseUtils.ReporError("Error in customer-request responding to edit toggle");
          }
        );
    }
  }


  // Enable or Disable everything on the panel.
  enableOrDisableEverything(pEnable: boolean) {
    let l_isEnabled: boolean = this._pnlExpansionProperties.isNewMode ? true : pEnable;
    this.fieldDisabledMap[DsamsConstants.CASE_PANEL_ASSOCIATIONS] = !l_isEnabled;
    this.fieldDisabledMap["acList_ASSOCIATED_CASE_RATIONALE_TX"] = !l_isEnabled;
    this.fieldDisabledMap["acList_RELATED_CASE_RATIONALE_TX"] = !l_isEnabled;
    this.fieldDisabledMap["associate_USER_CASE_ID"] = !l_isEnabled;
    this.fieldDisabledMap["security_ASSISTANCE_PROGRAM_CD"] = !l_isEnabled;
    this.fieldDisabledMap["case_VERSION_TYPE_NM"] = !l_isEnabled;
    this.fieldDisabledMap["associatedCaseAdd"] = !l_isEnabled;
    this.fieldDisabledMap["relatedCaseList"] = !l_isEnabled;
    if (pEnable) {
      this.initializePanelFields();
    }
  }


  // Set the field enabledness and disabledness upon panel load.
  initializePanelFields() {
    let isFieldDisabled = ((this._pnlExpansionProperties.caseRequestParams.caseVersionTypeCd !== "B") &&
      (this._pnlExpansionProperties.caseRequestParams.caseVersionTypeCd !== "A") &&
      (this._pnlExpansionProperties.caseRequestParams.caseVersionTypeCd !== "M"));
    this.fieldDisabledMap["acList_ASSOCIATED_CASE_RATIONALE_TX"] = isFieldDisabled;
    this.fieldDisabledMap["acList_RELATED_CASE_RATIONALE_TX"] = isFieldDisabled;
    this.fieldDisabledMap["associate_USER_CASE_ID"] = isFieldDisabled;
    this.fieldDisabledMap["security_ASSISTANCE_PROGRAM_CD"] = isFieldDisabled;
    this.fieldDisabledMap["case_VERSION_TYPE_NM"] = isFieldDisabled;
    this.fieldDisabledMap["relatedCaseList"] = isFieldDisabled;

    let isAddDelButtonDisabled = this._pnlExpansionProperties.caseRequestParams.caseVersionTypeCd !== "B";
    this.fieldDisabledMap["associatedCaseAdd"] = isAddDelButtonDisabled;
  }

  changeAssoIconImages(rowElement: any) {
    let rowN: number = this.dataSourceAssoAssociations.data.indexOf(rowElement);
    let str: string = ((this.dataSourceAssoAssociations.data[rowN] as theAssoAssociationArray).iconAssoImg);

    if (str === assoAssociationConstants.iconAssoImageArrowDown) {
      (this.dataSourceAssoAssociations.data[rowN] as theAssoAssociationArray).iconAssoImg = assoAssociationConstants.iconAssoImageArrowUp;
    }
    else {
      (this.dataSourceAssoAssociations.data[rowN] as theAssoAssociationArray).iconAssoImg = assoAssociationConstants.iconAssoImageArrowDown;
    }

    this.expandedAssoElement === rowElement ? this.expandedAssoElement = null : this.expandedAssoElement = rowElement;
  }

  fetchReferenceData() {
    if (this._reloadReferenceData) {
      //DSAMS-5754 07/22 DH - use static ref data
      if (CaseUtils.theRefCaseUsageIndList == null || CaseUtils.theRefCaseUsageIndList.length == 0) {
        // *** Reference: Case Usage Indicator ***
        this.caseRestService
          .getReferenceData(DsamsConstants.REF_CASE_USAGE_INDICATOR, "C", 0, false)
          .subscribe(
            data => {
              this.refCaseUsageIndicatorList = data;
            },
            err => {
              CaseUtils.ReportHTTPError(err, "Error fetching reference for " + DsamsConstants.REF_CASE_USAGE_INDICATOR);
            }
          );
      }
      else this.refCaseUsageIndicatorList = CaseUtils.theRefCaseUsageIndList;
      this._reloadReferenceData = false;
    }
  }


  subscribeToDataService() {
    if (this._reloadData && !this._dataSubscription) {
      this._dataSubscription = this.caseUIService.caseDetailData.subscribe(
        {
          next: (caseDetailData: ICaseVersion) => {
            if (caseDetailData) {
              this._dataServiceRun = true;
              this._caseVersionData = caseDetailData;
              CaseUtils.populateCaseRequestParamsType(this._pnlExpansionProperties.caseRequestParams, this._caseVersionData);
              this._pnlExpansionProperties.caseRequestParams.caseId = this._caseVersionData.case_ID;
              this._pnlExpansionProperties.caseRequestParams.caseVersionId = this._caseVersionData.case_VERSION_ID;
              this.enableOrDisableEverything(this._currentToggle);
              this.initializeAssociationArray();
              this.initializeAssoAssociationArray();
            }
          }
        }
      );
      this._reloadData = false;
    }
  }

  // Subscribe to DSAMS method service to see if should add a related case row
  subscribeToRelatedCaseAdd() {
    if (!this._relatedCaseAddSubscription) {
      this._relatedCaseAddSubscription = this.dsamsMethodsService.relatedCaseAdd.subscribe(value => {
        if (value) this.addNewRelatedCaseItem();
      },
        err => {
          CaseUtils.ReporError("Error in dsamsMethodsService.relatedCaseAdd");
        }
      );
    }
  }

  // ************************** Validate/Save *****************************

  // Subcsribe to validate or save request.
  subscribeToValidateOrSaveRequest() {
    if (this._saveSubscription == null) {
      this._saveSubscription = this.caseUIService.saveRequest.subscribe((pSkipValidation: boolean) => {
        if (!this._skipSavePanel) {
          let svResults: SaveResultsType = this.savePanel(pSkipValidation);
          this.caseUIService.saveReturnRequest.next(svResults);
        }
      });
    }
  }

  // Do a validate/save request to the middle tier.
  savePanel(pSkipValidation: boolean): SaveResultsType {
    let valResults: SaveResultsType = new SaveResultsType();
    valResults.currentPanel = DsamsConstants.CASE_PANEL_ASSOCIATIONS;
    if (!pSkipValidation) {
      valResults = CaseAssociationsValidator.validateAssociationsPanel
        (this.caseAssociationData["caseRelatedCaseList"],
          this.caseAssociationData["caseAssociatedCaseList"],
          this._pnlExpansionProperties);
    }
    let svResults: SaveResultsType = new SaveResultsType();
    svResults.currentPanel = valResults.currentPanel;
    svResults.messageList = valResults.messageList;
    //
    if (svResults.isValidationSuccessful()) {
      const currCaseId: number = this._pnlExpansionProperties.caseRequestParams.caseId;
      let cvEntity: ICaseVersion = { status: DsamsConstants.ENT_UNCHANGED };
      let cmEntity: ICaseMaster = { status: DsamsConstants.ENT_UNCHANGED };
      //
      // Related Cases (changed and new)
      // 
      let rcArray: Array<IRelatedCase> = [];
      let rcFormArray: Array<any> = this.caseAssociationData["caseRelatedCaseList"];
      let somethingChanged: boolean = false;
      const rcTypeCd: string = "RC";
      if (!!rcFormArray) {
        for (let i = 0; i < rcFormArray.length; i++) {
          let rcEntity: IRelatedCase;
          const rcIdChanged: boolean = (rcFormArray[i]["related_CASE_ID"] !== rcFormArray[i]["old_RELATED_CASE_ID"]);
          const txChanged: boolean = (rcFormArray[i]["old_RELATED_CASE_RATIONALE_TX"] !== rcFormArray[i]["related_CASE_RATIONALE_TX"]);
          if (!rcIdChanged && txChanged && rcFormArray[i]["status"] == DsamsConstants.ENT_UNCHANGED) {
            rcFormArray[i]["status"] = DsamsConstants.ENT_CHANGED;
          }
          if (rcFormArray[i]["status"] != DsamsConstants.ENT_NEW) {
            const theStatus: number = rcFormArray[i]["status"] == DsamsConstants.ENT_UNCHANGED ? DsamsConstants.ENT_UNCHANGED : (rcIdChanged ? DsamsConstants.ENT_DELETED : DsamsConstants.ENT_CHANGED);
            if (theStatus != DsamsConstants.ENT_UNCHANGED) {
              somethingChanged = true;
            }
            rcEntity =
            {
              entityName: "RELATED_CASE",
              status: theStatus,
              case_ID: rcFormArray[i]["case_ID"],
              related_CASE_ID: theStatus == DsamsConstants.ENT_DELETED ? rcFormArray[i]["old_RELATED_CASE_ID"] : rcFormArray[i]["related_CASE_ID"],
              related_CASE_TYPE_CD: rcTypeCd,
              related_CASE_RATIONALE_TX: rcFormArray[i]["related_CASE_RATIONALE_TX"]
            };
            rcArray.push(rcEntity);
            if (rcIdChanged) {
              rcEntity =
              {
                entityName: "RELATED_CASE",
                status: DsamsConstants.ENT_NEW,
                case_ID: rcFormArray[i]["case_ID"],
                related_CASE_ID: rcFormArray[i]["related_CASE_ID"],
                related_CASE_TYPE_CD: rcTypeCd,
                related_CASE_RATIONALE_TX: rcFormArray[i]["related_CASE_RATIONALE_TX"]
              };
              rcArray.push(rcEntity);
            }
          }
          else {
            somethingChanged = true;
            rcEntity =
            {
              entityName: "RELATED_CASE",
              status: DsamsConstants.ENT_NEW,
              case_ID: currCaseId,
              related_CASE_ID: rcFormArray[i]["related_CASE_ID"],
              related_CASE_TYPE_CD: rcTypeCd,
              related_CASE_RATIONALE_TX: rcFormArray[i]["related_CASE_RATIONALE_TX"]
            };
            rcArray.push(rcEntity);
          }
        }
      }
      //
      // Related Cases (deleted)
      //     
      rcFormArray = this.caseAssociationData["caseRelatedCaseDeletedList"];
      if (!!rcFormArray) {
        for (let i = 0; i < rcFormArray.length; i++) {
          somethingChanged = true;
          let rcEntity: IRelatedCase =
          {
            entityName: "RELATED_CASE",
            status: DsamsConstants.ENT_DELETED,
            case_ID: currCaseId,
            related_CASE_ID: rcFormArray[i]["related_CASE_ID"],
            related_CASE_TYPE_CD: rcTypeCd,
            related_CASE_RATIONALE_TX: rcFormArray[i]["related_CASE_RATIONALE_TX"]
          };
          rcArray.push(rcEntity);
        }
      }
      cmEntity.relatedCaseCaseIdList = rcArray;
      //
      // Associated Cases (changed and new)
      //
      let acArray: Array<IAssociatedCase> = [];
      let acFormArray: Array<IAssociatedCase> = this.caseAssociationData["caseAssociatedCaseList"];
      if (!!acFormArray) {
        for (let i = 0; i < acFormArray.length; i++) {
          const uCaseId: string = CaseUtils.unformatUserCaseId(acFormArray[i]["user_CASE_ID"]);
          const acChanged: boolean = (CaseUtils.unformatUserCaseId(acFormArray[i]["user_CASE_ID"]) !== CaseUtils.unformatUserCaseId(acFormArray[i]["old_USER_CASE_ID"]));
          if (acChanged && acFormArray[i]["status"] == DsamsConstants.ENT_CHANGED) {
            // Do a new and delete.
            somethingChanged = true;
            const oldUcaseId: string = CaseUtils.unformatUserCaseId(acFormArray[i]["old_USER_CASE_ID"]);
            let acEntity: IAssociatedCase =
            {
              entityName: "ASSOCIATED_CASE",
              status: DsamsConstants.ENT_DELETED,
              case_ID: currCaseId,
              associated_CASE_RATIONALE_TX: acFormArray[i]["associated_CASE_RATIONALE_TX"],
              customer_ORGANIZATION_ID: oldUcaseId.substr(0, 2),
              implementing_AGENCY_ID: oldUcaseId.substr(2, 1),
              case_DESIGNATOR_CD: oldUcaseId.substr(3, 3)
            };
            acArray.push(acEntity);
            acEntity =
            {
              entityName: "ASSOCIATED_CASE",
              status: DsamsConstants.ENT_NEW,
              case_ID: currCaseId,
              associated_CASE_RATIONALE_TX: acFormArray[i]["associated_CASE_RATIONALE_TX"],
              customer_ORGANIZATION_ID: uCaseId.substr(0, 2),
              implementing_AGENCY_ID: uCaseId.substr(2, 1),
              case_DESIGNATOR_CD: uCaseId.substr(3, 3)
            };
            acArray.push(acEntity);
          }
          else {
            // Regular insert or update.
            somethingChanged = true;
            let acEntity: IAssociatedCase =
            {
              entityName: "ASSOCIATED_CASE",
              status: acFormArray[i]["status"],
              case_ID: currCaseId,
              associated_CASE_RATIONALE_TX: acFormArray[i]["associated_CASE_RATIONALE_TX"],
              customer_ORGANIZATION_ID: uCaseId.substr(0, 2),
              implementing_AGENCY_ID: uCaseId.substr(2, 1),
              case_DESIGNATOR_CD: uCaseId.substr(3, 3)
            };
            acArray.push(acEntity);
          }
        }
      }
      //
      // Associated Cases (deleted)
      //
      acFormArray = this.caseAssociationData["caseAssociatedCaseDeletedList"];
      if (!!acFormArray) {
        for (let i = 0; i < acFormArray.length; i++) {
          const uCaseId: string = CaseUtils.unformatUserCaseId(acFormArray[i]["user_CASE_ID"]);
          somethingChanged = true;
          let acEntity: IAssociatedCase =
          {
            entityName: "ASSOCIATED_CASE",
            status: DsamsConstants.ENT_DELETED,
            case_ID: currCaseId,
            associated_CASE_RATIONALE_TX: acFormArray[i]["associated_CASE_RATIONALE_TX"],
            customer_ORGANIZATION_ID: uCaseId.substr(0, 2),
            implementing_AGENCY_ID: uCaseId.substr(2, 1),
            case_DESIGNATOR_CD: uCaseId.substr(3, 3)
          };
          acArray.push(acEntity);
        }
      }
      cmEntity.associatedCaseList = acArray;
      if (somethingChanged) {
        const theStatus = this._pnlExpansionProperties.isNewMode ? DsamsConstants.ENT_NEW : DsamsConstants.ENT_CHANGED;
        cmEntity.status = theStatus;
        cvEntity.status = theStatus;
      }
      cvEntity.theCaseId = cmEntity;
      svResults.caseVersionPanelData = cvEntity;
      this._isGotInfoFromCIPanel = false;
      this._dataServiceRun = false;
    }
    return svResults;
  }

  /**
   * Subscribe to save complete subscription.
   */
  subscribeToSaveComplete() {
    if (!this._saveCompleteSubscription) {
      this._saveCompleteSubscription = this.caseUIService.saveCaseVersionComplete.subscribe((pReturnCaseVersion: ICaseVersion) => {
        if (!!pReturnCaseVersion) {
          this.caseUIService.theComponentSaveState[CaseUIService.SAVE_CASE_DETAILS_STATE].isDataChanged = false;
          this.caseUIService.theComponentSaveState[CaseUIService.SAVE_CASE_DETAILS_STATE].isSaveConfirmed.next(false);

          if (this._isGotInfoFromCIPanel) {
            this._isGotInfoFromCIPanel = false;
          }
          // Do not run past here if the data service has already loaded.
          if (this._dataServiceRun) {
            this._dataServiceRun = false;
            return;
          }

          this.caseAssociationData["caseRelatedCaseDeletedList"] = [];
          let oldRCList: Array<any> = this.caseAssociationData["caseRelatedCaseList"];
          this.caseAssociationData["caseRelatedCaseList"] = !pReturnCaseVersion.theCaseId.relatedCaseCaseIdList ? [] : pReturnCaseVersion.theCaseId.relatedCaseCaseIdList.filter(elem => elem.status != DsamsConstants.ENT_DELETED);

          let tmpArray: Array<any> = [];
          if (!!this.caseAssociationData["caseRelatedCaseList"]) {
            this.aAssociationRowIndex = this.caseAssociationData["caseRelatedCaseList"].length;
            tmpArray = [];
            for (let i = 0; i < this.aAssociationRowIndex; i++) {
              tmpArray[i] = Object.assign(this.caseAssociationData["caseRelatedCaseList"][i],
                {
                  rowNum: (i + 1),
                  status: DsamsConstants.ENT_UNCHANGED,
                  iconImg: assoRelCaseConstants.iconImageArrowDown,
                  old_CASE_ID: this.caseAssociationData["caseRelatedCaseList"][i].case_ID,
                  old_RELATED_CASE_ID: this.caseAssociationData["caseRelatedCaseList"][i].related_CASE_ID,
                  old_RELATED_CASE_RATIONALE_TX: this.caseAssociationData["caseRelatedCaseList"][i].related_CASE_RATIONALE_TX,
                  user_CASE_ID: oldRCList[i].user_CASE_ID,
                  case_VERSION_TYPE_CD: oldRCList[i].case_VERSION_TYPE_CD,
                  case_VERSION_TYPE_NM: oldRCList[i].case_VERSION_TYPE_NM,
                  case_USAGE_INDICATOR_CD: oldRCList[i].case_USAGE_INDICATOR_CD,
                  case_USAGE_TITLE_NM: oldRCList[i].case_USAGE_TITLE_NM,
                  security_ASSISTANCE_PROGRAM_CD: oldRCList[i].security_ASSISTANCE_PROGRAM_CD,
                  case_VERSION_STATUS_DT: oldRCList[i].case_VERSION_STATUS_DT,
                  case_VERSION_STATUS_CD: oldRCList[i].case_VERSION_STATUS_CD,
                  version_STATUS_TITLE_NM: oldRCList[i].version_STATUS_TITLE_NM,
                  case_VERSION_NUMBER_ID: oldRCList[i].case_VERSION_NUMBER_ID,
                  total_CASE_VALUE_AM: oldRCList[i].total_CASE_VALUE_AM,
                  userCaseIdRequired: false,
                  userCaseIdTooShort: false,
                  userCaseIdIAInvalid: false
                });
            }
          }
          else {
            this.aAssociationRowIndex = 0;
          }
          this.caseAssociationData["caseRelatedCaseList"] = tmpArray;
          this.dataSourceAssociations.data = this.caseAssociationData["caseRelatedCaseList"];
          this.caseAssociationData["caseAssociatedCaseDeletedList"] = [];
          this.caseAssociationData["caseAssociatedCaseList"] = !pReturnCaseVersion.theCaseId.associatedCaseList ? [] : pReturnCaseVersion.theCaseId.associatedCaseList.filter(elem => elem.status != DsamsConstants.ENT_DELETED);
          let tmpArray2: Array<any> = [];
          if (!!this.caseAssociationData["caseAssociatedCaseList"]) {
            this.aAssoAssociationRowIndex = this.caseAssociationData["caseAssociatedCaseList"].length;
            for (let i = 0; i < this.aAssoAssociationRowIndex; i++) {
              const uCaseId: string = this.caseAssociationData["caseAssociatedCaseList"][i].customer_ORGANIZATION_ID + "-" +
                this.caseAssociationData["caseAssociatedCaseList"][i].implementing_AGENCY_ID + "-" +
                this.caseAssociationData["caseAssociatedCaseList"][i].case_DESIGNATOR_CD
              tmpArray2[i] = Object.assign(this.caseAssociationData["caseAssociatedCaseList"][i],
                {
                  rowNum: (i + 1),
                  status: DsamsConstants.ENT_UNCHANGED,
                  user_CASE_ID: uCaseId,
                  old_USER_CASE_ID: uCaseId,
                  iconAssoImg: assoAssociationConstants.iconAssoImageArrowDown
                });
            }
          }
          else {
            this.aAssoAssociationRowIndex = 0;
          }
          this.caseAssociationData["caseAssociatedCaseList"] = tmpArray2;
          this.dataSourceAssoAssociations.data = this.caseAssociationData["caseAssociatedCaseList"];
          this._pnlExpansionProperties.caseRequestParams.caseId = pReturnCaseVersion.case_ID;
          this._pnlExpansionProperties.caseRequestParams.caseVersionId = pReturnCaseVersion.case_VERSION_ID;
          this._pnlExpansionProperties.isNewMode = false;
          this._somethingChanged = false;
          this.enableOrDisableEverything(this._currentToggle);
        }
      });
      this._dataReturnedFlag = true;
    }
  }

  // Subscribe to new mode info coming from CI panel.
  subscribeToNewModeInfo() {
    if (!this._newModeInfoSubscription) {
      this._newModeInfoSubscription = this.caseUIService.newModeInfo.subscribe((pCSI: CaseSaveInfo) => {
        if (!!pCSI) {
          this._pnlExpansionProperties.caseRequestParams.caseId = pCSI.case_ID;
          this._pnlExpansionProperties.caseRequestParams.caseVersionId = pCSI.case_VERSION_ID;
          this._pnlExpansionProperties.isNewMode = pCSI.isNewMode;
          if (!this._alreadyToggledOn) {
            this._currentToggle = pCSI.isEditable;
            this.enableOrDisableEverything(this._currentToggle);
          }
          this._isGotInfoFromCIPanel = false;
        }
      });
    }
  }
}