import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CaseButtonsComponent } from './case-buttons.component';

describe('CaseButtonsComponent', () => {
  let component: CaseButtonsComponent;
  let fixture: ComponentFixture<CaseButtonsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CaseButtonsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CaseButtonsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
