import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SignatoriesPanelComponent } from './signatories-panel.component';

describe('SignatoriesPanelComponent', () => {
  let component: SignatoriesPanelComponent;
  let fixture: ComponentFixture<SignatoriesPanelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SignatoriesPanelComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SignatoriesPanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
