/* 
  Author: David Huynh 
  Date:   01/28/2020 
*/

import { Component, OnInit, ViewChild, OnDestroy, ComponentFactoryResolver } from '@angular/core';
import { MatTableDataSource, MatTable } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { Subscription } from 'rxjs';
import { CaseRestfulService } from '../../services/case-restful.service';
import { CaseUIService } from '../../services/case-ui-service';
import { DsamsConstants } from 'src/app/dsams/dsams.constants';
import { ReferenceDataType } from '../../model/reference-data-type';
import { CaseUtils } from '../../utils/case-utils';
import { PanelExpansionProperties } from '../../model/panel-expansion-properties';
import { MdePopoverTrigger } from '@material-extended/mde';
import { FieldDisabledMap } from '../../model/field-disabled-map';
import { SaveResultsType } from '../../validation/save-results-type';
import { CaseSignatoryValidator } from '../../validation/case-signatory-validator';
import { ICaseVersion } from '../../model/dto/icase-version';
import { ICaseDistributionList } from '../../model/dto/case-distribution-list';
import { FormGroup } from '@angular/forms';
import { DsamsShareService } from '../../../services/dsams-share.service';
import { PopCaseActivityComponent } from '../../../utilitis/popups/pop-case-activity/pop-case-activity.component';
import { DsamsMethodsService } from './../../../../dsams/services/dsams-methods.service';
import { PopPersonComponent } from 'src/app/dsams/utilitis/popups/pop-person/pop-person.component';
import { IPerson } from '../../model/dto/person';
import { IEditResponseType } from '../../model/edit-response-type';
import { MessageMgr } from '../../validation/message-mgr';
import { IActivity } from '../../model/dto/activity';
import { CaseSaveInfo } from '../../model/case-save-info';


declare function focusItem(pItem: string): any;

@Component({
  selector: 'app-signatories-panel',
  templateUrl: './signatories-panel.component.html',
  styleUrls: ['./signatories-panel.component.css',
    '../common-CSS.component.css']
})


export class SignatoriesPanelComponent implements OnInit, OnDestroy {
  public caseSignatoryData: any = {};
  private _caseUIServiceSubscription: Subscription;
  private _reloadReferenceData: boolean = true;
  private _pnlExpansionProperties: PanelExpansionProperties;
  private fieldDisabledMap: FieldDisabledMap = {};
  private _saveSubscription: Subscription = null;
  private _dataSubscription: Subscription = null;
  private _popupActivitySubscription: Subscription = null;
  private _popupPersonSubscription: Subscription = null;
  private _popupPersonMILNameSubscription: Subscription = null;
  private _editSubscription: Subscription = null;
  private _popupActivityDistSubscription: Subscription = null;
  private _saveCompleteSubscription: Subscription = null;
  private _newModeInfoSubscription: Subscription = null;
  private _panelCollapedSubscription: Subscription = null;
  private _casePanelStatusQuerySubscription: Subscription = null;
  private _isGotInfoFromCIPanel: boolean = false;
  private _currentToggle: boolean = false;
  private _globalPersonRowElement: any = null;   // Stores the element of the person while popup is open.  
  private _globalActivityRowElement: any = null;   // Stores the element of the activity while popup is open.  
  private _mildepSignatoryErrorCd: string = DsamsConstants.NO_ERROR;
  private _mildepSignatoryPopulatedFromPopup: boolean = false;
  private _distroSignatoryPopulatedFromPopup: boolean = false;
  private _numDistrosWithErrors:number = 0;
  private _alreadyToggledOn: boolean = false;
  private _skipSavePanel:boolean = false;
  caseVersionData: ICaseVersion;

  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;
  @ViewChild(MatTable, { static: true }) table: MatTable<any>;
  @ViewChild(MdePopoverTrigger, { static: true }) trigger: MdePopoverTrigger;

  countryMailingAddress: string = '';

  //  Distribution array and table declaration
  columnsToDisplayDistribution = ['ActivityId', 'PersonName', 'DisbText', 'Attachments', 'DeleteRow'];

  dataSourceDistribution = new MatTableDataSource();

  // Form for new popup for activity
  caseActivityForm: FormGroup;

  aDisbRowIndex: number = 0;
  refActivityList: Array<ReferenceDataType> = [];
  refMildepSignatoryList: Array<ReferenceDataType> = [];
  refCustomerOrganizationAddressList: Array<ReferenceDataType> = [];
  popupStatus:number=0;

  // ********** Main Body ***********
  constructor(private caseRestService: CaseRestfulService,
    public dsamsDialogMsgService: DsamsMethodsService,
    private caseUIService: CaseUIService,
    private dataSharingService: DsamsShareService,
    private dsamsMethodsService: DsamsMethodsService) { }

  ngOnInit() {

    // Only fetch data when the panel is opened.
    this._caseUIServiceSubscription = this.caseUIService.panelExpanded.subscribe(
      {
        next: (pnlExpansionProperties: PanelExpansionProperties) => {
          if (pnlExpansionProperties.panelName === DsamsConstants.CASE_PANEL_SIGNATORIES ||
            pnlExpansionProperties.panelName === DsamsConstants.CASE_PANEL_ALL) {
              this._pnlExpansionProperties = pnlExpansionProperties;
            if (this._pnlExpansionProperties.isResetPanels) {
              this._reloadReferenceData = true;
            }              
            this.fetchReferenceData();
            this.subscribeToDataService();
            this.subscribeToValidateOrSaveRequest();

            // Reset flags.
            this._mildepSignatoryPopulatedFromPopup = false;
            this._distroSignatoryPopulatedFromPopup = false;

            if (this._pnlExpansionProperties.isNewMode) {
              this._currentToggle = true;
              this.enableOrDisableEverything(this._currentToggle);
            }
            this.subscribeToSaveComplete();
            this.subscribeToNewModeInfo();
            this.subscribeToPanelCollapsed();
            this.subscribeToCasePanelStatusQuery();
            this._skipSavePanel = false;               
          }
        }
      });

    // Subscribe to Activity Popup.
    this.subscribeToPopupActivity();

    // Subscribe to Dist Activity Popup.
    this.subscribeToPopupActivityDistList();

    // Subscribe to case ui service for signatory name
    // for change customer information option
    this.caseUIService.getFieldSignatoryNameDisabled().subscribe((value) => {
      // Set field disabled to value
      if (this.caseUIService.optionSelectedUCCI.getValue()) {
        this.fieldDisabledMap["mildep_USER_ID"] = value;
      }
    });
  }

  // Make sure panel expansion subscription is cleaned up.
  ngOnDestroy() {
    this._caseUIServiceSubscription.unsubscribe();
    if (this._saveSubscription != null) {
      this._saveSubscription.unsubscribe();
      this._saveSubscription = null;
    }
    if (!!this._dataSubscription) {
      this._dataSubscription.unsubscribe();
      this._dataSubscription = null;
    }
    if (!!this._popupPersonSubscription) {
      this._popupPersonSubscription.unsubscribe();
      this._popupPersonSubscription = null;
    }
    if (!!this._popupPersonMILNameSubscription) {
      this._popupPersonMILNameSubscription.unsubscribe();
      this._popupPersonMILNameSubscription.unsubscribe();
    }
    if (!!this._popupActivitySubscription) {
      this._popupActivitySubscription.unsubscribe();
      this._popupActivitySubscription = null;
    }
    if (!!this._editSubscription) {
      this._editSubscription.unsubscribe();
      this._editSubscription = null;
    }
    if (!!this._popupActivityDistSubscription) {
      this._popupActivityDistSubscription.unsubscribe();
      this._popupActivityDistSubscription = null;
    }
    if (!!this._saveCompleteSubscription) {
      this._saveCompleteSubscription.unsubscribe();
      this._saveCompleteSubscription = null;
    }
    if (!!this._newModeInfoSubscription) {
      this._newModeInfoSubscription.unsubscribe();
      this._newModeInfoSubscription = null;
    } 
    if (!!this._panelCollapedSubscription) {
      this._panelCollapedSubscription.unsubscribe();
      this._panelCollapedSubscription = null;
    }
    if (!!this._casePanelStatusQuerySubscription) {
      this._casePanelStatusQuerySubscription.unsubscribe();
      this._casePanelStatusQuerySubscription = null;
    }       
  }

  ngAfterViewInit() {
    this.dataSourceDistribution.paginator = this.paginator;
    this.dataSourceDistribution.sort = this.sort;
  }


  // Subscribe to panel collapsing
  subscribeToPanelCollapsed() {
    if (!this._panelCollapedSubscription) {
      this._panelCollapedSubscription = this.caseUIService.panelCollapsed.subscribe((panelName: string) => {
        if (panelName === DsamsConstants.CASE_PANEL_SIGNATORIES || panelName === DsamsConstants.CASE_PANEL_ALL) 
        {
           this._skipSavePanel = true;
        }
      });
    }
  }

  // Subscribe to request for panel status.
  subscribeToCasePanelStatusQuery() {
    if (!this._casePanelStatusQuerySubscription) {
      this._casePanelStatusQuerySubscription = this.caseUIService.getPanelCaseVersionStatusQuerySubscription().subscribe(() => {
        this.caseUIService.panelCaseVersionStatusResponseSubscriptionNext(DsamsConstants.CASE_PANEL_SIGNATORIES,
                                                                          this.caseSignatoryData[DsamsConstants.PROP_CASE_VERSION_STATUS],
                                                                          this._pnlExpansionProperties.caseRequestParams.caseId,
                                                                          this._pnlExpansionProperties.caseRequestParams.caseVersionId);
      });
    }
  }      
    

  // Determine if a field is disabled or not.
  fieldDisabled(pFieldName: string): boolean {
    // Special Case for Mil Dep Signatories Field when user selects change customer information option (DSAMS-1585)
    if (pFieldName === "mildep_USER_ID" && !(this.fieldDisabledMap["mildep_USER_ID"])
      && (this.caseUIService.optionSelectedUCCI.getValue() ||
        //DSAMS-1587 when user selects update MILDep option
        this.caseUIService.optionSelectedUCMS.getValue())) {
      // Do nothing
    }
    // Special Case for Mil Dep Signatories Fields when user selects update MILDep option (DSAMS-1587)
    else if (pFieldName == "activity_ID" && !(this.fieldDisabledMap["activity_ID"])
      && this.caseUIService.optionSelectedUCMS.getValue()) {
      // Do nothing
    }
    else {
      return CaseUtils.isFieldDisabled(this.fieldDisabledMap, DsamsConstants.CASE_PANEL_SIGNATORIES, pFieldName);
    }
  }

  // Flag the field as changed so we can update the record upon save.
  setChangedCV() {
    this.caseSignatoryData[DsamsConstants.PROP_CASE_VERSION_STATUS] = (!!this._pnlExpansionProperties && this._pnlExpansionProperties.isNewMode)?DsamsConstants.ENT_NEW:DsamsConstants.ENT_CHANGED;
    if (this.caseSignatoryData[DsamsConstants.PROP_CASE_VERSION_STATUS] == DsamsConstants.ENT_UNCHANGED) {
      this.caseUIService.theComponentSaveState[CaseUIService.SAVE_CASE_DETAILS_STATE].isDataChanged = false;
    }
    else
      this.caseUIService.theComponentSaveState[CaseUIService.SAVE_CASE_DETAILS_STATE].isDataChanged = true;    
   }

  setChangedPopup() {
    this.popupStatus= (!!this._pnlExpansionProperties && this._pnlExpansionProperties.isNewMode)?DsamsConstants.ENT_NEW:DsamsConstants.ENT_CHANGED;
    if (this.caseSignatoryData[DsamsConstants.PROP_CASE_VERSION_STATUS] == DsamsConstants.ENT_UNCHANGED) {
      this.caseUIService.theComponentSaveState[CaseUIService.SAVE_CASE_DETAILS_STATE].isDataChanged = false;
    }
    else
      this.caseUIService.theComponentSaveState[CaseUIService.SAVE_CASE_DETAILS_STATE].isDataChanged = true;     
  }

  // Flag change for case distribution list.
  setChangedCDL(pElement:any) {
    if (pElement.status == DsamsConstants.ENT_UNCHANGED) {
      pElement.status = DsamsConstants.ENT_CHANGED;
    }
    this.setChangedCV();
  }


  hasMildepSignatoryError():boolean {    
    return (!(this.fieldDisabled('activity_ID')) && this._mildepSignatoryErrorCd !== DsamsConstants.NO_ERROR);
  }

  showMildepSignatoryErrorMessage() {
    if (this.hasMildepSignatoryError()) {
      if (this._mildepSignatoryErrorCd === "E001") {
        return "Field is required.";
      }
      return MessageMgr.getMesssage(this._mildepSignatoryErrorCd).messageText;
    }
    else {
      return DsamsConstants.NO_ERROR;
    }
  }

  getFieldStyleProperty(pElement:any, pElementName:string, isAppearanceNotStyle:boolean):string|object {
    const ERROR_APPEARANCE:string = DsamsConstants.ERROR_APPEARANCE;
    const REGULAR_APPEARANCE:string = DsamsConstants.REGULAR_APPEARANCE;
    const ERROR_STYLE_1 = {"border":"2px solid red", "padding-top":"3px", "padding-bottom":"5px", "border-radius":"4px", "vertical-align":"top", "margin-top":"-20px"};
    let isError:boolean = false;    
    let styleStr:object = {};
    if (pElementName === "activity_ID") {
      isError = this.hasMildepSignatoryError();
      styleStr = ERROR_STYLE_1;
    }
    else if (pElementName === "refActivityList_ACTIVITY_ID") {
      isError = this.hasDistroActivityError(pElement);
      styleStr = ERROR_STYLE_1;
    }
    if (isAppearanceNotStyle) {
      return isError?ERROR_APPEARANCE:REGULAR_APPEARANCE;
    }
    else {
      return isError?styleStr:{};
    }    
  }  

  hasDistroActivityError(pElement:any):boolean {
    return pElement.errorMsg !==  DsamsConstants.NO_ERROR;
  }

  showDistroActivityErrorMessage(pElement:any):string {
    if (this.hasDistroActivityError(pElement)) {
      return MessageMgr.getMesssage(pElement.errorMsg).messageText;
    }
    else {
      return DsamsConstants.NO_ERROR;
    }
  }

  // Validate Distribution List Activity
  validateDistroActivity(pElement:any, pRowNum: number) {
    const activityElem = <HTMLInputElement>document.getElementById('ddlACTIVITY_ID_S' + +pRowNum);
    if (this._distroSignatoryPopulatedFromPopup == true || !activityElem || activityElem.value === "") {
      this.caseUIService.canSave.next(true); 
      pElement.errorMsg = DsamsConstants.NO_ERROR;  
      return;     
    }
    this.caseUIService.canSave.next(false);
    const activityId: string = CaseUtils.parseOutID(activityElem.value).toUpperCase(); 
    // Call the database to make sure it's valid.    
    let filter:string = activityId + "@@@#" + sessionStorage.getItem(DsamsConstants.SESSION_SDB_ID);   
    filter = encodeURIComponent(filter);
    let isValid:boolean = false;
    this.caseRestService
        .getActivityByFilter(filter)
        .subscribe(data => {
                     let fetchedActivity:IActivity = null;
                      if (!!data) {
                        // Loop thru the fetched activities until we find one of the same length as what the user entered.
                        for (let i = 0; i < data.length; i++) {
                          if (CaseUtils.parseOutID(data[i].activity_ID).length === activityId.length) {
                            fetchedActivity = data[i];
                          }
                        }
                      }
                      if (!!fetchedActivity) {
                        pElement.activity_ID = fetchedActivity.activity_ID + " - " + fetchedActivity.activity_NM;
                        if (pElement.errorMsg !== DsamsConstants.NO_ERROR) {
                          this._numDistrosWithErrors--;
                          pElement.errorMsg = DsamsConstants.NO_ERROR;
                        }
                        this.setChangedCDL(pElement);
                        this.caseUIService.canSave.next(true);                        
                      }
                      else {
                        if (pElement.errorMsg === DsamsConstants.NO_ERROR) {
                          this._numDistrosWithErrors++;
                        }
                        pElement.errorMsg = "E051";
                        pElement.activity_ID = activityId;
                      }
                    },
        err => {
          CaseUtils.ReportHTTPError(err, "Validating Activity ID on Distro List");
          this.caseUIService.canSave.next(true);
        }
      );      
  }

  // Validate the signatory activity .
  validateActivity() {
    if (this._mildepSignatoryPopulatedFromPopup == true) {
      this._mildepSignatoryErrorCd = DsamsConstants.NO_ERROR;
      this.caseUIService.canSave.next(true); 
      return;
    }

    if (!this.caseSignatoryData['activity_ID'] || this.caseSignatoryData['activity_ID'] === "") {
      this._mildepSignatoryErrorCd = "E001";
      return;
    }

    const activityId:string = CaseUtils.parseOutID(this.caseSignatoryData['activity_ID']).toUpperCase();
    this.caseUIService.canSave.next(false);
    // Call the database to make sure it's valid.    
    let filter:string = activityId + "@@@#" + sessionStorage.getItem(DsamsConstants.SESSION_SDB_ID);    
    filter = encodeURIComponent(filter);
    let isValid:boolean = false;
    this.caseRestService
        .getActivityByFilter(filter)
        .subscribe(data => {
                      let fetchedActivity:IActivity = null;
                      if (!!data) {
                        // Loop thru the fetched activities until we find one of the same length as what the user entered.
                        for (let i = 0; i < data.length; i++) {
                          if (CaseUtils.parseOutID(data[i].activity_ID).length === activityId.length) {
                            fetchedActivity = data[i];
                          }
                        }
                      }
                      if (!!fetchedActivity) {
                        this.caseSignatoryData['activity_ID'] = fetchedActivity.activity_ID + " - " + fetchedActivity.activity_NM;
                        this._mildepSignatoryErrorCd = DsamsConstants.NO_ERROR;
                        this.setChangedCV();                     
                        this.caseUIService.canSave.next(true);   
                      }
                      else {
                        this._mildepSignatoryErrorCd = "E051";
                        this.caseSignatoryData['activity_ID'] = activityId;
                      }
                    },
        err => {
          CaseUtils.ReportHTTPError(err, "Validating Activity ID");
          this.caseUIService.canSave.next(true);
        }
      );    
  }


  // What the Cust Org Address shows in the dropdown.
  showCustOrgAddressInDropdown(pAddrType: string, pField_1: string, pField_2: string): string {
    return (pAddrType == null ? " " : pAddrType + ": ") +
      (pField_1 == null ? " " : pField_1 + " ") +
      (pField_2 == null ? " " : pField_2);
  }


  setCountryMailingAddress(selectedValue: string) {
    // Loop thru the customer-address values until the one we selected is picked.
    let idx: number = 0;
    let selectedIndex: number = 0;
    for (var currAddr of this.refCustomerOrganizationAddressList) {
      if (currAddr["customer_ADDRESS_ID"] === selectedValue) {
        selectedIndex = idx;
      }
      idx++;
    }
    // Use that selected address to populate the country mailing address txtbox.
    let selectedAddr = this.refCustomerOrganizationAddressList[selectedIndex];
    this.countryMailingAddress = (selectedAddr["address_LINE_1_TX"] == null ? " " : selectedAddr["address_LINE_1_TX"]) + "\n" +
      (selectedAddr["address_LINE_2_TX"] == null ? " " : selectedAddr["address_LINE_2_TX"]) + "\n" +
      (selectedAddr["address_LINE_3_TX"] == null ? " " : selectedAddr["address_LINE_3_TX"]) + "\n" +
      (selectedAddr["address_LINE_4_TX"] == null ? " " : selectedAddr["address_LINE_4_TX"]) + "\n" +
      (selectedAddr["address_LINE_5_TX"] == null ? " " : selectedAddr["address_LINE_5_TX"]);
  }

  // Make sure the array is populated.
  isDistributionListPopulated(): boolean {
    return !!(this.caseSignatoryData["caseDistributionList"]) || this._pnlExpansionProperties.isNewMode;
  }

  //*************  Distribution table
  initializeDistributionArray() {
    let currCaseSignatoryList: Array<any> = <Array<any>>(this.caseSignatoryData["caseDistributionList"]);
    let currCaseSignatoryItem: any;
    this.aDisbRowIndex = currCaseSignatoryList.length;
    this.caseSignatoryData["caseMasterServiceTypeDeletedList"] = [];
    for (let i = 0; i < this.aDisbRowIndex; i++) {
      currCaseSignatoryItem = Object.assign({ rowNum: (i + 1), errorMsg: DsamsConstants.NO_ERROR },
        { status: DsamsConstants.ENT_UNCHANGED },
        { personNm: (!currCaseSignatoryList[i].theUserId) ? "" : CaseUtils.getBusinessRuleMapValue(currCaseSignatoryList[i].theUserId.businessRuleMap, "PERSON_DISPLAY_NM_LONG", "") },
        currCaseSignatoryList[i]);
        currCaseSignatoryItem.activity_ID = (!currCaseSignatoryItem.theActivityId || !currCaseSignatoryItem.theActivityId.activity_ID) ? "" : currCaseSignatoryItem.theActivityId.activity_ID + " - " + currCaseSignatoryItem.theActivityId.activity_NM;
      currCaseSignatoryList[i] = currCaseSignatoryItem;
    }
    this.dataSourceDistribution = new MatTableDataSource(currCaseSignatoryList);
  }

  addNewDistributionRow() {
    this.aDisbRowIndex++;

    if (!(this.caseSignatoryData["caseDistributionList"])) {
      this.caseSignatoryData["caseDistributionList"] = [];
    }

    (<Array<any>>this.caseSignatoryData["caseDistributionList"]).push(
      {
        rowNum: this.aDisbRowIndex,
        errorMsg: DsamsConstants.NO_ERROR,
        status: DsamsConstants.ENT_NEW,
        case_DISTRIBUTION_ATTACH_IN: false,
        case_DISTRIBUTION_LIST_ID: 0,
        case_DISTRIBUTION_LIST_TX: "",
        case_ID: this._pnlExpansionProperties.caseRequestParams.caseId,
        case_VERSION_ID: this._pnlExpansionProperties.caseRequestParams.caseVersionId,
        activity_ID: "",
        user_ID: 0,
        person_FIRST_NM: null,
        person_LAST_NM: null
      }
    );
    this.dataSourceDistribution = new MatTableDataSource(this.caseSignatoryData["caseDistributionList"]);
    this.dataSourceDistribution._updateChangeSubscription();
    this.setChangedCV();
    focusItem("ddlACTIVITY_ID_S" + +this.aDisbRowIndex);
  }

  /* This procedure checks the returned result value from the 
     popover Yes/No dialog window. */
  yesButtonOnClick(isDeleteConfirmed: any, rowElement: any) {
    if (isDeleteConfirmed) {
      this.delDistributionRow(rowElement);      
    }
  }

  delDistributionRow(rowElement: any) {
    if (!(this.caseSignatoryData["caseDistributionDeletedList"])) {
      this.caseSignatoryData["caseDistributionDeletedList"] = [];
    }
    (<Array<any>>this.caseSignatoryData["caseDistributionDeletedList"]).push(rowElement);  

    // If we're deleting the last row with errors then toggle the save button to save-able.
    if (rowElement.errorMsg !== DsamsConstants.NO_ERROR) {
      this._numDistrosWithErrors--;
      if (this._numDistrosWithErrors == 0) {
        this.caseUIService.canSave.next(true);   
      }
    }
    (<Array<any>>this.caseSignatoryData["caseDistributionList"]).splice(this.dataSourceDistribution.data.indexOf(rowElement), 1);  
    this.dataSourceDistribution = new MatTableDataSource(this.caseSignatoryData["caseDistributionList"]);
    this.dataSourceDistribution.paginator = this.paginator;
    this.dataSourceDistribution.sort = this.sort;
    this.dataSourceDistribution._updateChangeSubscription();
    this.setChangedCV();
  }


  // Subscribe to edit toggle event
  subscribeToEdit() {
    if (!this._editSubscription) {
      this._editSubscription = this.caseUIService
        .caseEditService
        .subscribe((pResponse: IEditResponseType) => {
            if (
                (pResponse && (pResponse.ID === DsamsConstants.CASE_VERSION_EDITOR || pResponse.ID === DsamsConstants.PAGE_CASE_DETAIL) && this.isBasicOrModOrAmendCase()) || 
                (this.isImpCaseVersionStatus() && this.caseUIService.milestoneAddService.getValue() === "UPDTCASE")
              ) 
            {
              this.enableOrDisableEverything(pResponse.editToggle);
              this._currentToggle = pResponse.editToggle; 
              if (this._currentToggle) {
                this._alreadyToggledOn = true;
              }
            }
          },
          err => {
            CaseUtils.ReporError("Error in signaories panel responding to edit toggle");
          }
        );
    }
  }

  isBasicOrModOrAmendCase(): boolean {
    return CaseUtils.isBasicOrModOrAmendCase(this.caseVersionData.case_VERSION_TYPE_CD.toUpperCase());
  }

  isImpCaseVersionStatus(): boolean {
    return CaseUtils.isImpCaseVersionStatus(this.caseVersionData.case_VERSION_TYPE_CD.toUpperCase());
  }

  // Enable or Disable everything on the panel.
  enableOrDisableEverything(pEnable: boolean) {
    let l_isEnabled: boolean = this._pnlExpansionProperties.isNewMode ? true : pEnable;
    this.fieldDisabledMap[DsamsConstants.CASE_PANEL_SIGNATORIES] = !l_isEnabled;
    if (l_isEnabled) {
      this.initializePanelFields();
    }
  }


  // Set the enabledness of the field on this panel according to business rules.
  initializePanelFields() {
    // No extra business logic here right now.
  }

  // ********************************** REST API Calls ***************************************

  fetchReferenceData() {
    if (this._reloadReferenceData) {
      // *** Reference: Activity ***
      this.caseRestService
        .getReferenceData(DsamsConstants.REF_ACTIVITY, "", 0, true, false, "", 3)
        .subscribe(
          data => {
            this.refActivityList = data;
          },
          err => {
            CaseUtils.ReportHTTPError(err, "Error fetching reference for " + DsamsConstants.REF_ACTIVITY);
          }
        );

      // ** MILDEP Signatory **
      const extraInfo: string = this._pnlExpansionProperties.caseRequestParams.caseId.toString() + ":" + this._pnlExpansionProperties.caseRequestParams.caseVersionId.toString();
      this.caseRestService
        .getReferenceData(DsamsConstants.REF_MILDEP_SIGNATORY, "", 0, true, true, extraInfo)
        .subscribe(
          data => {
            this.refMildepSignatoryList = data;
          },
          err => {
            CaseUtils.ReportHTTPError(err, "Error fetching reference for " + DsamsConstants.REF_MILDEP_SIGNATORY);
          }
        );

      this._reloadReferenceData = false;
    }
  }

  /**
   * Subscribe to validate or save.
   */
  // Add the subscription for this panel for getting the data from the dashboard.
  subscribeToDataService() {
    if (!this._dataSubscription) {
      this._dataSubscription = this.caseUIService.caseDetailData.subscribe(
        {
          next: (caseDetailData: ICaseVersion) => {
            if (caseDetailData) {
              this.caseVersionData = caseDetailData;              
              CaseUtils.populateCaseRequestParamsType(this._pnlExpansionProperties.caseRequestParams, this.caseVersionData);              
              this.caseSignatoryData['congressional_NOTIFICATION_IN'] = this.caseVersionData.congressional_NOTIFICATION_IN;
              if (!!this.caseVersionData.signatory_ACTIVITY_ID ) {
                this.caseSignatoryData['activity_ID'] = this.caseVersionData.signatory_ACTIVITY_ID + " - " + this.caseVersionData.theSignatoryActivityId.activity_NM;
              }
              else {
                this.caseSignatoryData['activity_ID'] = "";
              }
              // Need to get MILDEP Person Full Name from the database (icase-version.ts)
              // Currently the only value for MILDEP is user id
              // if mildep_USER_ID is zero do empty space
              this.caseSignatoryData['mildep_USER_ID'] = this.caseVersionData.mildep_USER_ID;
              if (this.caseVersionData.mildep_USER_ID === 0) {
                this.caseSignatoryData['mildep_PERSON_NM'] = '';
              }
              else {
                this.caseSignatoryData['mildep_PERSON_NM'] = CaseUtils.getBusinessRuleMapValue(this.caseVersionData.theMildepUserId.businessRuleMap, "PERSON_DISPLAY_NM_LONG", "");
              }
              this.caseSignatoryData['customer_SIGNATORY_NM'] = this.caseVersionData.customer_SIGNATORY_NM;
              this.caseSignatoryData['customer_ADDRESS_ID'] = this.caseVersionData.customer_ADDRESS_ID;
              // Customer Address Dropdown
              if (!!this.caseVersionData.theCaseId.theCustomerOrganizationId) {
                if (!!this.caseVersionData.theCaseId.theCustomerOrganizationId.customerAddressList) {
                  this.caseSignatoryData["customerAddressList"] = this.caseVersionData.theCaseId.theCustomerOrganizationId.customerAddressList;
                  // Loop thru the addresses and set the address_type_title_nm.
                  for (let i = 0; i < this.caseVersionData.theCaseId.theCustomerOrganizationId.customerAddressList.length; i++) {
                    if (this.caseVersionData.theCaseId.theCustomerOrganizationId.customerAddressList[i].theAddressTypeCd != null) {
                      this.caseSignatoryData["customerAddressList"][i]['address_TYPE_TITLE_NM'] = this.caseVersionData.theCaseId.theCustomerOrganizationId.customerAddressList[i].theAddressTypeCd.address_TYPE_TITLE_NM;
                    }
                  }
                }
              }
              if (this.caseSignatoryData["customerAddressList"]) {
                this.refCustomerOrganizationAddressList = this.caseSignatoryData["customerAddressList"];
                this.setCountryMailingAddress(this.caseSignatoryData["customer_ADDRESS_ID"]);
              }
              this.caseSignatoryData['caseDistributionList'] = this.caseVersionData.caseDistributionListList;
              const defaultStatus:number = this._pnlExpansionProperties.isNewMode?DsamsConstants.ENT_NEW:DsamsConstants.ENT_UNCHANGED; 
              this.caseSignatoryData[DsamsConstants.PROP_CASE_MASTER_STATUS] = defaultStatus;
              this.caseSignatoryData[DsamsConstants.PROP_CASE_VERSION_STATUS] = defaultStatus;                 
              this.enableOrDisableEverything(this._currentToggle);
              this.initializeDistributionArray();              
              // Subscribe to edit
              this.subscribeToEdit();
              this._isGotInfoFromCIPanel = false;
            }
          }
        }
      );
    }
  }

  // ************************** Validate/Save *****************************

  // Subcsribe to validate or save request.
  subscribeToValidateOrSaveRequest() {
    if (this._saveSubscription == null) {
      this._saveSubscription = this.caseUIService.saveRequest.subscribe((pSkipValidation:boolean) => {
        if (this.popupStatus !== 0){
          this.caseSignatoryData[DsamsConstants.PROP_CASE_VERSION_STATUS]=this.popupStatus;
         }
        if (!this._skipSavePanel) {
          let svResults: SaveResultsType = this.savePanel(pSkipValidation);
          this.caseUIService.saveReturnRequest.next(svResults);
        }
      });
    }
  }

  // Do a validate/save request to the middle tier.
  savePanel(pSkipValidation:boolean): SaveResultsType {
    let valResults: SaveResultsType = new SaveResultsType();
    valResults.currentPanel = DsamsConstants.CASE_PANEL_SIGNATORIES;
    if (!pSkipValidation) {
      valResults = CaseSignatoryValidator.validateSignatoriesPanel
                                              (this.caseSignatoryData,
                                               this._pnlExpansionProperties, []);
    }
    let svResults: SaveResultsType = new SaveResultsType();
    svResults.currentPanel = valResults.currentPanel;
    svResults.messageList = valResults.messageList;

  if (svResults.isValidationSuccessful()) {
    const currCaseId:number = this._pnlExpansionProperties.caseRequestParams.caseId;
    const currCaseVersionId: number = this._pnlExpansionProperties.caseRequestParams.caseVersionId;     
    let cvEntity:ICaseVersion = {status:this.caseSignatoryData[DsamsConstants.PROP_CASE_VERSION_STATUS]};
    cvEntity.signatory_ACTIVITY_ID = CaseUtils.parseOutID(this.caseSignatoryData['activity_ID'])
    cvEntity.mildep_USER_ID = this.caseSignatoryData['mildep_USER_ID'];
    cvEntity.customer_ADDRESS_ID = this.caseSignatoryData['customer_ADDRESS_ID'];
    cvEntity.customer_SIGNATORY_NM = this.caseSignatoryData['customer_SIGNATORY_NM'];
    //
    // Case Distribution List (new and changed)
    //
    let cdlArray: Array<ICaseDistributionList> = [];
    let cdlFormArray: Array<ICaseDistributionList> = this.caseSignatoryData["caseDistributionList"];
    if (!!cdlFormArray) {
      for (let i = 0; i < cdlFormArray.length; i++) {
        let cdlEntity:ICaseDistributionList = 
          {              
            entityName: "CASE_DISTRIBUTION_LIST",
            status: cdlFormArray[i]["status"],
            activity_ID: CaseUtils.parseOutID(cdlFormArray[i]["activity_ID"]),
            case_DISTRIBUTION_ATTACH_IN: cdlFormArray[i]["case_DISTRIBUTION_ATTACH_IN"],
            case_DISTRIBUTION_LIST_ID: cdlFormArray[i]["case_DISTRIBUTION_LIST_ID"],
            case_DISTRIBUTION_LIST_TX: cdlFormArray[i]["case_DISTRIBUTION_LIST_TX"],
            case_ID: currCaseId,
            case_VERSION_ID: currCaseVersionId,
            user_ID: cdlFormArray[i]["user_ID"]
          };     
        cdlArray.push(cdlEntity);
      }
    }
    //
    // Case Distribution List (deleted)
    // 
    cdlFormArray = this.caseSignatoryData["caseDistributionDeletedList"];
    if (!!cdlFormArray) {
      for (let i = 0; i < cdlFormArray.length; i++) {
        let cdlEntity:ICaseDistributionList = 
          {              
            entityName: "CASE_DISTRIBUTION_LIST",
            status: DsamsConstants.ENT_DELETED,
            activity_ID: CaseUtils.parseOutID(cdlFormArray[i]["activity_ID"]),
            case_DISTRIBUTION_ATTACH_IN: cdlFormArray[i]["case_DISTRIBUTION_ATTACH_IN"],
            case_DISTRIBUTION_LIST_ID: cdlFormArray[i]["case_DISTRIBUTION_LIST_ID"],
            case_DISTRIBUTION_LIST_TX: cdlFormArray[i]["case_DISTRIBUTION_LIST_TX"],
            case_ID: currCaseId,
            case_VERSION_ID: currCaseVersionId,
            user_ID: cdlFormArray[i]["user_ID"]
          };     
        cdlArray.push(cdlEntity);
      }
    }
    cvEntity.caseDistributionListList = cdlArray;
    svResults.caseVersionPanelData = cvEntity;
    this._isGotInfoFromCIPanel = false;    
   }
    return svResults;
  }


  subscribeToSaveComplete() {
    if (!this._saveCompleteSubscription) {
      this._saveCompleteSubscription = this.caseUIService.saveCaseVersionComplete.subscribe((pReturnCaseVersion:ICaseVersion) => {          
        if (!!pReturnCaseVersion) {
          this.caseUIService.theComponentSaveState[CaseUIService.SAVE_CASE_DETAILS_STATE].isDataChanged = false;
          this.caseUIService.theComponentSaveState[CaseUIService.SAVE_CASE_DETAILS_STATE].isSaveConfirmed.next(false);      
          if (this._isGotInfoFromCIPanel) {
            this._isGotInfoFromCIPanel = false;
          }             
          const unch:number = DsamsConstants.ENT_UNCHANGED;          
          this.caseSignatoryData[DsamsConstants.PROP_CASE_VERSION_STATUS] = unch;
          this.caseSignatoryData[DsamsConstants.PROP_CASE_MASTER_STATUS] = unch;
          this.caseSignatoryData["caseDistributionDeletedList"] = [];
          this.caseSignatoryData["caseDistributionList"] = !pReturnCaseVersion.caseDistributionListList?[]:pReturnCaseVersion.caseDistributionListList.filter(elem => elem.status != DsamsConstants.ENT_DELETED);
          if (!!this.caseSignatoryData["caseDistributionList"]) {
            this.aDisbRowIndex = this.caseSignatoryData["caseDistributionList"].length;
            for (let i = 0; i < this.aDisbRowIndex; i++) {
                this.caseSignatoryData["caseDistributionList"][i] = Object.assign (this.caseSignatoryData["caseDistributionList"][i],
                                                                                    { rowNum: (i + 1), 
                                                                                      status: unch
                                                                                    });
            }
          }
          else {
            this.aDisbRowIndex = 0;
          }
          this._pnlExpansionProperties.isNewMode = false;
          this.popupStatus=0;
          this._pnlExpansionProperties.caseRequestParams.caseId = pReturnCaseVersion.case_ID;
          this._pnlExpansionProperties.caseRequestParams.caseVersionId = pReturnCaseVersion.case_VERSION_ID;        
          this.enableOrDisableEverything(this._currentToggle);        
        }
      });
    }
  }

  // Subscribe to new mode info coming from CI panel.
  subscribeToNewModeInfo() {
    if (!this._newModeInfoSubscription) {
      this._newModeInfoSubscription = this.caseUIService.newModeInfo.subscribe((pCSI: CaseSaveInfo) => {   
        this.caseSignatoryData[DsamsConstants.PROP_CASE_VERSION_STATUS] = pCSI.isNewMode?DsamsConstants.ENT_NEW:DsamsConstants.ENT_UNCHANGED;
        this.caseSignatoryData[DsamsConstants.PROP_CASE_MASTER_STATUS] = pCSI.isNewCaseMaster?DsamsConstants.ENT_NEW:DsamsConstants.ENT_UNCHANGED;
        this._pnlExpansionProperties.caseRequestParams.caseId = pCSI.case_ID;
        this._pnlExpansionProperties.caseRequestParams.caseVersionId = pCSI.case_VERSION_ID;
        this._pnlExpansionProperties.isNewMode = pCSI.isNewMode;
        if (!this._alreadyToggledOn) {          
          this._currentToggle = pCSI.isEditable;
          this.enableOrDisableEverything(this._currentToggle); 
        }             
        this._isGotInfoFromCIPanel = false;
      });
    }    
  }

  mildepActivityKeyPress() {
    this._mildepSignatoryPopulatedFromPopup = false;
    this.setChangedCV();
  }

  distroActivityKeyPress(pElement:any) {
    this._distroSignatoryPopulatedFromPopup = false;
    this.setChangedCDL(pElement);
  }

  // Activity Popup
  popupCaseActivity(elementName: string): void {
    let diaWidth: string = "60%";
    let diaHeight: string = "68%";
    let passingData: string = "";

    this.dsamsDialogMsgService.openSearchDialogCase(diaWidth, diaHeight, passingData, PopCaseActivityComponent, this.caseActivityForm, elementName);
  }


  // Subscribe to the DSAMS service for activity textfield for popup selection.
  subscribeToPopupActivity() {
    if (this._popupActivitySubscription == null) {
      this._popupActivitySubscription = this.dsamsMethodsService
          .selectedActivityFromPopupValue
          .subscribe(value => {
            if (!!value){
              this.caseSignatoryData['activity_ID'] = value;              
              this._mildepSignatoryPopulatedFromPopup = true;
              this._mildepSignatoryErrorCd = DsamsConstants.NO_ERROR;
              console.log('inside subscribeToPopupActivity')
              this.setChangedCV();
              this.setChangedPopup();
              this.caseUIService.canSave.next(true);   
            }
        },
          err => {
            CaseUtils.ReporError("Error in dsamsMethodsService.popupActivity");
          }
        );
    }
  }

  // Person Popup
  popupPerson(pElement: any) {
    let tmpFormGroup: FormGroup;
    let pType: string = "3";
    let pTitle: string = DsamsConstants.PERSON_SEARCH_CDL;
    this._globalPersonRowElement = pElement;
    this.dsamsDialogMsgService.openSearchDialogCase(DsamsConstants.PERSON_POPUP_WIDTH,
      DsamsConstants.PERSON_POPUP_HEIGHT,
      pType,
      PopPersonComponent,
      tmpFormGroup,
      pTitle);
    this.subscribeToPopupPerson();
  }


  // Subscribe to the DSAMS service for person textfield for popup selection.
  subscribeToPopupPerson() {
    if (this._popupPersonSubscription == null) {
      this._popupPersonSubscription = this.dsamsDialogMsgService
        .selectedPersonFromPopupValue
        .subscribe((selectedVal: IPerson) => {
          if (!!selectedVal && sessionStorage.getItem(DsamsConstants.SESSION_CASE_POPUP) === DsamsConstants.PERSON_SEARCH_CDL && !!this._globalPersonRowElement) {
            this._globalPersonRowElement.user_ID = selectedVal.user_ID;
            this._globalPersonRowElement.personNm = CaseUtils.getBusinessRuleMapValue(selectedVal.businessRuleMap, "PERSON_DISPLAY_NM_LONG", "");
            this.setChangedCDL(this._globalPersonRowElement);
          }
          this._globalPersonRowElement = null;
        },
          err => {
            CaseUtils.ReporError("Error in dsamsMethodsService.popupPerson in signatories");
            this._globalPersonRowElement = null;
          }
        );
    }
  }

  // Do backspace or delete on person.
  doBackspaceMR(pElement: any) {
    if (!this.fieldDisabled('refActivityList_USER_ID')) {
      pElement.user_ID = 0;
      pElement.personNm = "";
      this.setChangedCDL(pElement);
    }
  }

  // Person Popup for MILDEP Signatory Name - DSAMS-1447
  popupPersonForMILName() {
    let tmpFormGroup: FormGroup;
    let pType: string = "0";
    let pTitle: string = DsamsConstants.PERSON_SEARCH_MILDEP;
    this.dsamsDialogMsgService.openSearchDialogCase(DsamsConstants.PERSON_POPUP_WIDTH,
      DsamsConstants.PERSON_POPUP_HEIGHT,
      pType,
      PopPersonComponent,
      tmpFormGroup,
      pTitle);
    this.subscribeToPopupPersonForMILName();
  }

  // Subscribe to the DSAMS service for person textfield for popup selection for MILDEP Signatory Name - DSAMS-1447
  subscribeToPopupPersonForMILName() {
    if (this._popupPersonMILNameSubscription == null) {
      this._popupPersonMILNameSubscription = this.dsamsDialogMsgService
        .selectedPersonFromPopupValue
        .subscribe((selectedVal: IPerson) => {
          if (!!selectedVal && sessionStorage.getItem(DsamsConstants.SESSION_CASE_POPUP) === DsamsConstants.PERSON_SEARCH_MILDEP) {
            this.caseSignatoryData['mildep_USER_ID'] = selectedVal.user_ID;
            this.caseSignatoryData['mildep_PERSON_NM'] = CaseUtils.getBusinessRuleMapValue(selectedVal.businessRuleMap, "PERSON_DISPLAY_NM_LONG", "");
            this.setChangedCV();
            this.setChangedPopup();
            this.caseUIService.canSave.next(true);
          }
        },
          err => {
            CaseUtils.ReporError("Error in dsamsMethodsService.popupPersonMILName");
          }
        );
    }
  }

  // Activity Popup for Distributed List
  popupCaseActivityDistList(pElement: any): void {
    let diaWidth: string = "60%";
    let diaHeight: string = "68%";
    let passingData: string = "Distribution_Activity";
    let pTitle: string = "Activity Search";

    this._globalActivityRowElement = pElement;

    this.dsamsDialogMsgService.openSearchDialogCase(diaWidth, diaHeight, passingData, PopCaseActivityComponent, this.caseActivityForm, pTitle);
  }

  // Subscribe to the DSAMS service for activity textfield for popup selection.
  subscribeToPopupActivityDistList() {
    if (this._popupActivityDistSubscription == null) {
      this._popupActivityDistSubscription = this.dsamsMethodsService
        .selectedActivityDistFromPopupValue
        .subscribe(value => {
          // Need to update the distribution list row - activity text field.
          if (!!value && !!this._globalActivityRowElement) {
            this._globalActivityRowElement.activity_ID = value;
            if (this._globalActivityRowElement.errorMsg !== DsamsConstants.NO_ERROR) {
              this._numDistrosWithErrors--;
              this._globalActivityRowElement.errorMsg = DsamsConstants.NO_ERROR;
            }
            this._distroSignatoryPopulatedFromPopup = true;
            this.caseUIService.canSave.next(true);                  
          }
          this._globalActivityRowElement = null;
        },
          err => {
            CaseUtils.ReporError("Error in dsamsMethodsService.popupActivity");
            this._globalActivityRowElement = null;
          }
        );
    }
  }
}