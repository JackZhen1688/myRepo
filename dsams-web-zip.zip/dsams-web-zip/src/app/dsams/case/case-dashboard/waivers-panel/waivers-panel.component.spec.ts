import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WaiversPanelComponent } from './waivers-panel.component';

describe('WaiversPanelComponent', () => {
  let component: WaiversPanelComponent;
  let fixture: ComponentFixture<WaiversPanelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WaiversPanelComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WaiversPanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
