import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { CaseRestfulService } from '../../services/case-restful.service';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Subscription, BehaviorSubject } from 'rxjs';
import { CaseUtils } from '../../utils/case-utils';
import { ErrorParameter } from '../../../entities/specialEntities/error-parameter.model';
import { CaseUIService } from '../../services/case-ui-service';
import { MessageMgr } from '../../validation/message-mgr';
import { DsamsConstants } from './../../../dsams.constants';
import { DialogMessageYesnoComponent } from './../../../utilitis/dialogs/dialog-message-yesno/dialog-message-yesno.component';
import { DsamsUserMessageService } from '../../../services/dsams-user-message.service';


@Component({
  selector: 'app-case-amendmod-refresh',
  templateUrl: './case-amendmod-refresh.component.html',
  styleUrls: ['./case-amendmod-refresh.component.css']
})
export class CaseAmendModRefreshComponent implements OnInit {

  amendModRefreshForm: FormGroup;

  // Subsriptions
  _amendModRefreshSubscription: Subscription;
  showSpinner: BehaviorSubject<boolean> = new BehaviorSubject(false);

  refreshCd : string;
  REFRESH_ALL_DATA : string = '1';
  REFRESH_UNAFFECTED_DATA : string = '2';

  m1Msg: string = "The Refresh All function will copy all lines/sublines from the Current Implemented (I) version to " +
                  "this version and will overlay all changes made on those lines. Do you want to continue?";
  m2Msg: string = "The Refresh Unaffected function will update the lines/sublines on this version that have an Unaffected status code with data from the " +
                  "Current Implemented (I) version. It will not change data on the lines/sublines with a status code other than Unaffected. " +
                  "The Refresh Added Function will copy the lines/sublines that were added on the last implemented version onto this version and " +
                  "set their status to Unaffected. Do you want to continue?";

  constructor(
      private formBuilder: FormBuilder,
      private caseRestService: CaseRestfulService,
      public dialogRef: MatDialogRef<CaseAmendModRefreshComponent>,
      @Inject(MAT_DIALOG_DATA) public data: { caseId: number, versionId: number},
      public dialog: MatDialog,
      protected messageService: DsamsUserMessageService,
      private caseUIService: CaseUIService ) { }

  ngOnInit() {
    
    this.amendModRefreshForm = this.formBuilder.group({
      rbnSelection: this.formBuilder.control('REFRESH_UNAFFECTED')
    });
  }


  ngOnDestroy(){
    if (this._amendModRefreshSubscription){
      this._amendModRefreshSubscription.unsubscribe();
    }
  }

  XcloseDialog(): void {
    console.log("**XcloseDialog clicked");
    this.dialogRef.close();
  } 

  cancelDialog(): void {
    console.log("**Cancel Button clicked");
    this.dialogRef.close();
  }

  closePopup(): void {
    console.log("**Closing popup");
    this.dialogRef.close();
  }

  saveDialog(): void {
    console.log("**Save Button clicked");
    let messageNbr : string;
     
    if (this.amendModRefreshForm.get('rbnSelection').value == 'REFRESH_ALL') {
      console.log("** REFRESH_ALL selected - so pass value==1");
      this.refreshCd = this.REFRESH_ALL_DATA;
      messageNbr = this.m1Msg;   
    }
    else {
      console.log("** REFRESH_UNAFFECTED selected - so pass value==2");
      this.refreshCd = this.REFRESH_UNAFFECTED_DATA;
      messageNbr = this.m2Msg; 
    }

    this.showConfirmationMessageDialog(messageNbr);
       
  }
 
  showConfirmationMessageDialog(messageNbr:string){
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width= DsamsConstants.diaWidth;
    dialogConfig.data = {message: messageNbr, indecator: null};

    const dialogRef = this.dialog.open(DialogMessageYesnoComponent, dialogConfig);
    dialogRef.afterClosed().subscribe(result => {
      if (result == 1) {
        console.log("**YES clicked");
        
        //call Legacy to refresh Amend/Mod and use data passed from case detail (openAmendModRefreshDialog() in case-shortcut.component.ts)
        this.caseAmendModRefresh( this.data.caseId, this.data.versionId, this.refreshCd);
      } 
      else {
        console.log("**NO clicked");
        this.closePopup();
      }     
    });
  }

  caseAmendModRefresh(caseId: number, caseVersionId: number, refreshCd: string){  
    console.log("**params Value== pCaseId: " +caseId + " pCaseVersionId: " + caseVersionId + " pRefreshCd: " + refreshCd )
    this.showSpinner.next(true);

    this._amendModRefreshSubscription = this.caseRestService
      .caseAmendModRefresh(caseId,caseVersionId, refreshCd)
      .subscribe((pMessageList: Array<ErrorParameter>) => {        
        this.showSpinner.next(false);
        if (pMessageList.length == 0) {          
          
          this.closePopup();          
          
          MessageMgr.swalFire({
            text: 'Data was updated successfully',
            icon: 'success',
            showConfirmButton: false,
            timer: 2000,
            width: 300
          });
    
        }
        else {
          this.messageService.displayMessageListTc('Refresh Amend-Modification Errors/Warnings', pMessageList).subscribe();
          this.closePopup();
          this.showSpinner.next(false);
        }
      },
      err => {
        // Show other errors including 'Data is locked' error
        CaseUtils.ReportHTTPError(err, "Refresh Amend/Mod");
        this.showSpinner.next(false);
      }
    );
  }

}
