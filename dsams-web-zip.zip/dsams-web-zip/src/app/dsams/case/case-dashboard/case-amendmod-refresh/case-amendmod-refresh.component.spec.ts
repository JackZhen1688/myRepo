import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CaseAmendModRefreshComponent } from './case-amendmod-refresh.component';

describe('CaseAmendmodRefreshComponent', () => {
  let component: CaseAmendModRefreshComponent;
  let fixture: ComponentFixture<CaseAmendModRefreshComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CaseAmendModRefreshComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CaseAmendModRefreshComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
