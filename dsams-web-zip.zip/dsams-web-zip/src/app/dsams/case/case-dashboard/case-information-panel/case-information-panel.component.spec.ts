import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CaseInformationPanelComponent } from './case-information-panel.component';

describe('CaseInformationPanelComponent', () => {
  let component: CaseInformationPanelComponent;
  let fixture: ComponentFixture<CaseInformationPanelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CaseInformationPanelComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CaseInformationPanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
