import { SweetAlertResult } from "sweetalert2";
import { MessageMgr } from "../validation/message-mgr";

/**
 * Utility Class for Case Note
 * Author: CBanta
 * Date: 10/2021
 * 
 */
export class NoteUtils {
    // Change the note status according to what the new and previous values are.
    // Code reverse engineered from dsams-core.CaseNoteWin.setNoteStatus.
    public static changeCaseNoteStatus(pCurrentStatus:string, pNextStatus:string):string {
        if (pCurrentStatus == "A") {
            return "A";
        }
        else if (pCurrentStatus == "C") {
            return (pNextStatus == "R" || pNextStatus == "U" || pNextStatus == "D")?pNextStatus:pCurrentStatus;
        }
        else if (pCurrentStatus == "R") {
            return (pNextStatus == "C" || pNextStatus == "U" || pNextStatus == "D")?pNextStatus:pCurrentStatus;
        }
        else if (pCurrentStatus == "D") {
            return (pNextStatus == "C" || pNextStatus == "U" || pNextStatus == "R")?pNextStatus:pCurrentStatus;
        }
        else if (pCurrentStatus == "U") {
            return (pNextStatus == "C" || pNextStatus == "D" || pNextStatus == "R")?pNextStatus:pCurrentStatus;
        }
        else {
            return pNextStatus;
        }
    }

    /* 
    * Show confirm or lose changes.
    */
    public static showConfirmLoseChanges(pMessage:string): Promise<SweetAlertResult<unknown>> {
        return MessageMgr.swalFire(
          {
            title: pMessage,
            icon: 'warning',
            showCancelButton: true,
            cancelButtonText: 'No',
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#3085d6',
            confirmButtonText: 'Yes',
            html: MessageMgr.getMesssage("E036").messageText
          });
      }    
}