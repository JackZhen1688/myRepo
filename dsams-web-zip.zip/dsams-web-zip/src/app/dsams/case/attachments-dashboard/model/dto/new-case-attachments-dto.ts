import { attachmentsModel } from "../case-attachments";
import { attachmentsDto } from "./case-attachments-dto";

export interface newattachmentsDto extends attachmentsDto {
    isNewElement?: Boolean;
}
