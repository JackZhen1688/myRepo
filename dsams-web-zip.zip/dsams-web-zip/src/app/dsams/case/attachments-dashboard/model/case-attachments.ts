
import { formatDate } from "@angular/common";
import { ICaseVersion } from "src/app/dsams/case/model/dto/icase-version";
import { CaseMasterLineModel } from "src/app/dsams/case/model/case-master-line-model";
import { CaseMaster } from "src/app/dsams/case/model/dto/case-master";

import { DsamsConstants } from "src/app/dsams/dsams.constants";
import { attachmentsDto } from "./dto/case-attachments-dto";
import { attachmentsLineModel} from "src/app/dsams/case/attachments-dashboard/model/case-attachments-line"

export interface attachmentsModel {
    entityName?: string;
    status?: string;
    isDataChanged?: boolean;

    case_ID?: number,
    case_VERSION_ID?: string,

    iconImg?: string,
    case_ATTACHMENT_ID?: number,

    case_ATTACHMENT_NUMBER_ID?: number,
    change_ACTION_CD?: string,
    case_ATTACHMENT_TYPE_CD?: string,
    case_ATTACHMENT_OFFICIAL_TITLE?: string,
    case_ATTACHMENT_TX?: string,
    case_ATTACHMENT_PAGE_QY?: number,
    attachment_LAST_UPDATED_DT?: string,

    case_ATTACHMENT_NM?:string,
    lockSessionId?: string,
    theCaseVersionId?: ICaseVersion,
    theCaseMasterLineId?: CaseMasterLineModel,
    theCaseId?: CaseMaster,

    caseLineAttachmentRelatedAttachmentIdList?: attachmentsLineModel[]
}


/** 
  * Prepare Case Attachment list data for save
  * @Author: Cliff Inks
  * @Date: 12/21/2021
  * @Jira Card: 2953
*/
export class prepareCaseAttachmentDataForSave {
    theCAEntityList: attachmentsModel[] = [];
    aCAEntity: attachmentsModel = {};
    constructor(pCAList: attachmentsDto[]) {
        this.theCAEntityList = [];
        this.aCAEntity = {};
        pCAList.forEach(eachCRDto => {
            if (!!eachCRDto.status && eachCRDto.status !== DsamsConstants.ENT_UNCHANGED.toString()) {
                this.aCAEntity = {
                    case_ID: eachCRDto.case_ID,
                    case_VERSION_ID: eachCRDto.case_VERSION_ID,
                    case_ATTACHMENT_ID: eachCRDto.case_ATTACHMENT_ID,
                    case_ATTACHMENT_TYPE_CD: eachCRDto.case_ATTACHMENT_TYPE_CD,
                    case_ATTACHMENT_NM: eachCRDto.case_ATTACHMENT_NM,
                    case_ATTACHMENT_TX: eachCRDto.case_ATTACHMENT_TX,
                    case_ATTACHMENT_PAGE_QY: eachCRDto.case_ATTACHMENT_PAGE_QY ? eachCRDto.case_ATTACHMENT_PAGE_QY : null,
                    change_ACTION_CD:eachCRDto.change_ACTION_CD,
                    case_ATTACHMENT_NUMBER_ID:eachCRDto.case_ATTACHMENT_NUMBER_ID,
                    attachment_LAST_UPDATED_DT: eachCRDto.attachment_LAST_UPDATED_DT ?
                          formatDate(eachCRDto.attachment_LAST_UPDATED_DT, "yyyy-MM-dd", "en-US") : null,
                    lockSessionId: this.getCaseAttachmentLockSessionId(),
                    status: eachCRDto.status
                };
                 this.theCAEntityList.push(this.aCAEntity);
            }

        })
    }

    getCaseAttachmentLockSessionId(): string {
        let lockId = sessionStorage.getItem(DsamsConstants.SESSION_CASE_ATTACHMENT_LOCK_ID);
        if (lockId == null || lockId.length == 0) {
            lockId = '0';
        }
        return lockId;
    }
}

export class prepareCaseAttachmentTXTDataForSave {
    theCATXTEntityList: attachmentsModel[] = [];
    aCATXTEntity: attachmentsModel = {};
    constructor(pCATXTList: attachmentsDto[]) {
        this.theCATXTEntityList = [];
        this.aCATXTEntity = {};
        pCATXTList.forEach(eachCATXTDto => {
            if (!!eachCATXTDto.status && eachCATXTDto.status !== DsamsConstants.ENT_UNCHANGED.toString()) {
                this.aCATXTEntity = {
                    case_ID: eachCATXTDto.case_ID,
                    case_VERSION_ID: eachCATXTDto.case_VERSION_ID,
                    case_ATTACHMENT_ID: eachCATXTDto.case_ATTACHMENT_ID,
                    case_ATTACHMENT_TX: eachCATXTDto.case_ATTACHMENT_TX,
                    lockSessionId: this.getCaseAttachmentLockSessionId(),
                    status: eachCATXTDto.status
                };
                 this.theCATXTEntityList.push(this.aCATXTEntity);
            }

        })

    }

    getCaseAttachmentLockSessionId(): string {
        let lockId = sessionStorage.getItem(DsamsConstants.SESSION_CASE_ATTACHMENT_LOCK_ID);
        if (lockId == null || lockId.length == 0) {
            lockId = '0';
        }
        return lockId;
    }
  
}

export class prepareCaseAttachmentLineDataForSave {
    theCALINEEntityList: attachmentsLineModel[] = [];
    aCALINEEntity: attachmentsLineModel = {};
    constructor(pCALINEList: attachmentsDto[]) {
        this.theCALINEEntityList = [];
        this.aCALINEEntity = {};

        pCALINEList.forEach(eachCALINEDto => {
                for (let i = 0; i < eachCALINEDto.caseLineAttachmentRelatedAttachmentIdList.length; i++) {
                  if (eachCALINEDto.caseLineAttachmentRelatedAttachmentIdList[i].status != DsamsConstants.ENT_UNCHANGED.toString()) {
                    this.aCALINEEntity = {
                        case_ID: eachCALINEDto.case_ID,
                        related_CASE_ID: eachCALINEDto.case_ID,
                        working_CASE_ID: eachCALINEDto.case_ID,
                        related_CASE_VERSION_ID: eachCALINEDto.case_VERSION_ID,
                        working_CASE_VERSION_ID:eachCALINEDto.case_VERSION_ID,
                        related_CASE_ATTACHMENT_ID: eachCALINEDto.case_ATTACHMENT_ID,
                        lockSessionId: this.getCaseAttachmentLockSessionId(),   
                        case_MASTER_LINE_ID: eachCALINEDto.caseLineAttachmentRelatedAttachmentIdList[i].theCaseLine.case_MASTER_LINE_ID,
                        CASE_LINE_DATA: eachCALINEDto.caseLineAttachmentRelatedAttachmentIdList[i].theCaseLine,
                        status: eachCALINEDto.caseLineAttachmentRelatedAttachmentIdList[i].status,
                        change_ACTION_CD:eachCALINEDto.caseLineAttachmentRelatedAttachmentIdList[i].change_ACTION_CD
                    };
                    this.theCALINEEntityList.push(this.aCALINEEntity);

               }
        }
   
           })
   
       }

    getCaseAttachmentLockSessionId(): string {
        let lockId = sessionStorage.getItem(DsamsConstants.SESSION_CASE_ATTACHMENT_LOCK_ID);
        if (lockId == null || lockId.length == 0) {
            lockId = '0';
        }
        return lockId;
    }
}