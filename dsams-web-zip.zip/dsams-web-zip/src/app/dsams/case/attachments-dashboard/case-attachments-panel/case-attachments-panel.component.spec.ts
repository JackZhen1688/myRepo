import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CaseAttachmentsPanelComponent } from './case-attachments-panel.component';

describe('CaseAttachmentsPanelComponent', () => {
  let component: CaseAttachmentsPanelComponent;
  let fixture: ComponentFixture<CaseAttachmentsPanelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CaseAttachmentsPanelComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CaseAttachmentsPanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
