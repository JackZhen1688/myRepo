import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { NotFoundComponent } from './not-found/not-found.component';
import { NotAuthorizedComponent } from './not-authorized/not-authorized.component';
import { HomeComponent } from './home/home.component';
import { SignOutComponent } from './sign-out/sign-out.component';
import { MenubarComponent } from './dsams/billing/menubar/menubar.component';
import { BillingDashboardComponent } from './dsams/billing/billing-dashboard/billing-dashboard.component';
import { AutonewReimbursementCycleComponent } from './dsams/billing/run-new-cycle/autonew-reimbursement-cycle/autonew-reimbursement-cycle.component';
import { AutonewReimburseCycleComponent } from './dsams/billing/run-new-cycle/autonew-reimburse-cycle/autonew-reimburse-cycle.component';
import { GfebsSuffixCycleComponent } from './dsams/billing/run-new-cycle/gfebs-suffix-cycle/gfebs-suffix-cycle.component';
import { GfebsTlaCycleComponent } from './dsams/billing/run-new-cycle/gfebs-tla-cycle/gfebs-tla-cycle.component';
import { MangeAutomaticReimbursementCycleComponent } from './dsams/billing/run-new-cycle/manage-automatic-reimbursement-cycle/manage-automatic-reimbursement-cycle.component';
import { MangeManualReimbursementCycleComponent } from './dsams/billing/run-new-cycle/manage-manual-reimbursement-cycle/manage-manual-reimbursement-cycle.component';
import { FinancialHistoryComponent } from './dsams/billing/financial-history/financial-history.component';
import { ManualObligationDisbursementsComponent } from './dsams/billing/manual-obligation-disbursements/manual-obligation-disbursements.component';
import { MenubarCaseComponent } from './dsams/case/menubar-case/menubar-case.component';
import { UpdateComponent } from './dsams/case/update/update.component';
import { ViewComponent } from './dsams/case/view/view.component';
import { ModificationComponent } from './dsams/case/initialize/modification/modification.component';
import { RevisionComponent } from './dsams/case/initialize/revision/revision.component';
import { ProcessOneComponent } from './dsams/case/initialize/basic/process-one/process-one.component';
import { ProcessTwoComponent } from './dsams/case/initialize/basic/process-two/process-two.component';
import { ProcessThreeComponent } from './dsams/case/initialize/basic/process-three/process-three.component';
import { ProcessFourComponent } from './dsams/case/initialize/basic/process-four/process-four.component';
import { CaseDashboardComponent } from './dsams/case/case-dashboard/case-dashboard.component';
import { NotificationComponent } from './dsams/utilitis/notifications/notification/notification.component';
import { LineDetailsComponent } from './dsams/case/line-dashboard/line/line-details.component';
import { LineDashboardComponent } from './dsams/case/line-dashboard//line-dashboard.component';
import { FundingHomeComponent } from './dsams/funding/funding-home/funding-home.component';
import { ManageOpenFundingCycleComponent } from './dsams/funding/manage-open-funding-cycle/manage-open-funding-cycle.component';
import { GenerateTrainingFundingCycleComponent } from './dsams/funding/generate-training-funding-cycle/generate-training-funding-cycle.component';
import { RequestImmediateFundingComponent } from './dsams/funding/request-immediate-funding/request-immediate-funding.component';
import { FundingDocumentContactsComponent } from './dsams/funding/funding-document-contacts/funding-document-contacts.component';
import { ManageOfflineItoAuthorizationsComponent } from './dsams/funding/manage-offline-ito-authorizations/manage-offline-ito-authorizations.component';
import { ApproveBidCTransactionsComponent } from './dsams/funding/approve-bid-c-transactions/approve-bid-c-transactions.component';
import { AirforceDocumentCertificationComponent } from './dsams/funding/airforce-document-certification/airforce-document-certification.component';
import { DocumentAcceptanceComponent } from './dsams/funding/document-acceptance/document-acceptance.component';
import { ArmyDocumentCertificationComponent } from './dsams/funding/army-document-certification/army-document-certification.component';
import { AirforceFinancialPipelineComponent } from './dsams/funding/airforce-financial-pipeline/airforce-financial-pipeline.component';
import { ArmyFinancialPipelineComponent } from './dsams/funding/army-financial-pipeline/army-financial-pipeline.component';
import { NavyFinancialPipelineComponent } from './dsams/funding/navy-financial-pipeline/navy-financial-pipeline.component';
import { CustomerNumberStartingRangesComponent } from './dsams/funding/customer-number-starting-ranges/customer-number-starting-ranges.component';
import { ReleaseTransactionsComponent } from './dsams/billing/release-transactions/release-transactions.component';
import { ReleaseDtimComponent } from './dsams/billing/release-dtim/release-dtim.component';
import { DsamsDeactivateService } from './dsams/services/dsams-deactivate.service';
import { UpdateFillnobillComponent } from './dsams/billing/update-fillnobill/update-fillnobill.component';
import { NotificationFundingComponent } from './dsams/utilitis/notifications/notification-funding/notification-funding.component';
import { ChartComponent } from './dsams/utilitis/charts/chart/chart.component';
import { TestComponent } from './dsams/test/test.component';
import { PopupTestComponent } from './dsams/popup-test/popup-test.component';
import { CanDeactivateGuard } from './dsams/blockers/can-deactivate-guard/can-deactivate-guard.component';
import { CusRequestDashboardComponent } from './dsams/customer-request/cus-request-dashboard/cus-request-dashboard.component';
import { CongNotificationDashboardComponent } from './dsams/congressional-notification/cong-notification-dashboard/cong-notification-dashboard.component';
import { ManageGafsPsrDetailsComponent } from './dsams/funding/manage-gafs-psr-details/manage-gafs-psr-details.component';
import { NoteListComponent } from './dsams/case/note-dashboard/note-list/note-list.component';
import { NoteDashboardComponent } from './dsams/case/note-dashboard/note-dashboard.component';
import { NoteDetailsComponent } from './dsams/case/note-dashboard/note/note-details.component';
import { UnderConstructionComponent } from './dsams/utilitis/under-construction/under-construction.component';
import { RemarksDashboardComponent } from './dsams/case/remarks-dashboard/remarks-dashboard.component';
import { AttachmentsDashboardComponent } from './dsams/case/attachments-dashboard/attachments-dashboard.component';
import { MilestoneDashboardComponent } from './dsams/case/milestone-dashboard/milestone-dashboard.component';
import { ITOAuthorizations } from './dsams/funding/ito-authorizations/ito-authorizations.component';
import { FindReportComponent } from './dsams/reports/find-report/find-report.component';
import { DeamsTransactionApprovalComponent } from './dsams/funding/deams-transaction-approval/deams-transaction-approval.component';
import { ReleaseBIDsToGAFSComponent } from './dsams/funding/release-bids-to-gafs/release-bids-to-gafs.component';
import { PersonComponent } from './dsams/reference/person/person.component';


const rSep: string = " > ";		// Breadcrumb menu-item separator

const routes: Routes = [
	{ path: '', component: HomeComponent, data: { breadcrumb: '' } },
	{ path: 'reload', component: HomeComponent, data: { breadcrumb: '' } },
	{ path: 'underConstruction/:wp', component: UnderConstructionComponent, data: { breadcrumb: 'Under Construction' } },
	{
		path: 'reports', component: FindReportComponent, data: { breadcrumb: 'Reports' },
		children: [
			{ path: 'findreport', component: FindReportComponent, data: { breadcrumb: '' } },
		]
	},
	{
		path: 'case', component: MenubarCaseComponent, data: { breadcrumb: 'Case' },
		children: [
			{ path: '', component: CaseDashboardComponent, data: { breadcrumb: '' } },
			{ path: 'initialize/basic/process-one', component: ProcessOneComponent, data: { breadcrumb: 'FMS' + rSep + 'Initialize' + rSep + 'Basic' } },
			{ path: 'initialize/basic/process-two', component: ProcessTwoComponent, data: { breadcrumb: 'FMS' + rSep + 'Initialize' + rSep + 'Amendment' } },
			{ path: 'initialize/basic/process-three', component: ProcessThreeComponent, data: { breadcrumb: 'FMS' + rSep + 'Initialize' + rSep + 'Modification' } },
			{ path: 'initialize/basic/process-four', component: ProcessFourComponent, data: { breadcrumb: 'FMS' + rSep + 'Initialize' + rSep + 'Reivsion' } },
			{ path: 'initialize/modification', component: ModificationComponent, data: { breadcrumb: 'FMS' + rSep + 'Initialize' + rSep + 'Modification' } },
			{ path: 'initialize/revision', component: RevisionComponent, data: { breadcrumb: 'FMS' + rSep + 'Initialize' + rSep + 'Reivsion' } },
			{ path: 'update', component: UpdateComponent, data: { breadcrumb: 'FMS' + rSep + 'Update' } },
			{ path: 'view', component: ViewComponent, data: { breadcrumb: 'FMS' + rSep + 'View Case Detail' } },
			{ path: 'search', component: CaseDashboardComponent, data: { breadcrumb: 'Case Search Summary' } },
			{ path: 'line-dashboard/:tabIndex/:tabLabel', component: LineDashboardComponent, data: { breadcrumb: 'Case Line' } },
			{ path: 'line-details', component: LineDetailsComponent, data: { breadcrumb: 'Case Line' } },
			{ path: 'milestone-dashboard', component: MilestoneDashboardComponent, data: { breadcrumb: 'Milestone' } },
			{ path: 'note-dashboard', component: NoteDashboardComponent, data: { breadcrumb: 'Note' } },
			{ path: 'note-dashboard/note-list', component: NoteListComponent, data: { breadcrumb: 'Note List' } },
			{ path: 'note-details', component: NoteDetailsComponent, data: { breadcrumb: 'Case Note' } },
			{ path: 'remarks-dashboard', component: RemarksDashboardComponent, data: { breadcrumb: 'Remarks' } },
			{ path: 'attachments-dashboard', component: AttachmentsDashboardComponent, data: { breadcrumb: 'Attachments' } },
			{ path: '**', component: CaseDashboardComponent }
		]
	},
	{
		path: 'customer-request/:csu', component: CusRequestDashboardComponent, data: { breadcrumb: 'Customer Request' },
		children: [
			{ path: '', component: CusRequestDashboardComponent, data: { breadcrumb: '' } },
			{ path: '**', component: CusRequestDashboardComponent }
		]
	},
	{
		path: 'reference', component: MenubarComponent, data: { breadcrumb: 'Reference' },
		children: [
			{ path: 'cong-notification/:csu', component: CongNotificationDashboardComponent, data: { breadcrumb: 'Congressional Notification' } },
			{ path: 'person/:csu', component: PersonComponent, data: { breadcrumb: 'Person' } },
		]
	},
	{
		path: 'billing', component: MenubarComponent,
		children: [
			{ path: '', component: BillingDashboardComponent, data: { breadcrumb: 'Dashboard' } },
			{ path: 'automatic', component: AutonewReimbursementCycleComponent, data: { breadcrumb: 'New Automatic Reimbursemente' } },
			{ path: 'automnewreimburse/:csu', component: AutonewReimburseCycleComponent, data: { breadcrumb: 'New Automatic Reimbursement' } },
			{ path: 'mangeautomatic/:cycleid/:csu', component: MangeAutomaticReimbursementCycleComponent, data: { breadcrumb: 'Manage Automatic Reimbursement' } },
			{ path: 'runnewcycle/mangemanual/:cycleid/:csu', component: MangeManualReimbursementCycleComponent, data: { breadcrumb: 'Manage Manual Reimbursement' }, canDeactivate: [CanDeactivateGuard] },
			{ path: 'mangemanual/:cycleid/:csu', component: MangeManualReimbursementCycleComponent, data: { breadcrumb: 'Manage Manual Reimbursement' }, canDeactivate: [CanDeactivateGuard] },
			{ path: 'ManualObligationDisbursements/:cycleid/:csu', component: ManualObligationDisbursementsComponent, data: { breadcrumb: 'Manual Obligation Disbursements' } },
			{ path: 'gfebssuffix/:cycleid/:csu', component: GfebsSuffixCycleComponent, data: { breadcrumb: 'Manage Suffix Posting' }, canDeactivate: [CanDeactivateGuard] },
			{ path: 'gfebstla/:cycleid/:csu', component: GfebsTlaCycleComponent, data: { breadcrumb: 'Manage TLA Posting' }, canDeactivate: [CanDeactivateGuard] },
			{ path: 'financialhistory/:csu', component: FinancialHistoryComponent, data: { breadcrumb: 'Financial History' } },
			{ path: 'releasetrans/:csu', component: ReleaseTransactionsComponent, canDeactivate: [DsamsDeactivateService], data: { breadcrumb: 'Release Transactions after Billing' } },
			{ path: 'releasedtim/:csu', component: ReleaseDtimComponent, canDeactivate: [DsamsDeactivateService], data: { breadcrumb: 'Release DTIM Transactions' } },
			{ path: 'updatefillnobill/:csu', component: UpdateFillnobillComponent, canDeactivate: [DsamsDeactivateService], data: { breadcrumb: 'Update Fill No Bill' } },

		]
	},
	{
		path: 'funding', component: MenubarComponent,
		children: [
			{ path: '', component: FundingHomeComponent, data: { breadcrumb: 'Dashboard' } },
			{ path: 'fundingDocContacts/:csu', component: FundingDocumentContactsComponent, data: { breadcrumb: 'Funding Document Contacts' } },
			{ path: 'fundingNotification', component: NotificationFundingComponent, data: { breadcrumb: 'Funding Notification' } },
			{ path: 'manageGafsPsrDetails/:csu', component: ManageGafsPsrDetailsComponent, data: { breadcrumb: 'Manage GAFS PSR Details' }},
			{ path: 'generateTrainingFundingCycle/:fundingParameterSetId/:csu', component: GenerateTrainingFundingCycleComponent, data: { breadcrumb: 'Generate Funding Cycle' } },
			{ path: 'requestImmediateFunding/:csu', component: RequestImmediateFundingComponent, data: { breadcrumb: 'Request Immediate Funding' } },
			{ path: 'manageOfflineItoAuthorizations/:csu', component: ManageOfflineItoAuthorizationsComponent, data: { breadcrumb: 'Manage Offline ITO Authorizations' } },
			{ path: 'approveBidCTransactions/:csu', component: ApproveBidCTransactionsComponent, data: { breadcrumb: 'Approve BID C Transactions' } },
			{ path: 'customerNumberStartingRanges/:csu', component: CustomerNumberStartingRangesComponent, data: { breadcrumb: 'Customer Number Starting Ranges' } },
			{ path: 'manageopenfundingcycle/:cycleid/:csu', component: ManageOpenFundingCycleComponent, data: { breadcrumb: 'Manage Open Funding' } },
			{ path: 'airforceFinancialPipeline/:csu', component: AirforceFinancialPipelineComponent, data: { breadcrumb: 'Air Force Financial Pipeline' } },
			{ path: 'armyFinancialPipeline/:csu', component: ArmyFinancialPipelineComponent, data: { breadcrumb: 'Army Financial Pipeline' } },
			{ path: 'navyFinancialPipeline/:csu', component: NavyFinancialPipelineComponent, data: { breadcrumb: 'Navy Financial Pipeline' } },
			{ path: 'airforceDocumentCertification/:csu', component: AirforceDocumentCertificationComponent, data: { breadcrumb: 'Air Force Document Certification' } },
			{ path: 'documentAcceptance/:csu', component: DocumentAcceptanceComponent, data: { breadcrumb: 'Funding Document Acceptance' } },
			{ path: 'armyDocumentCertification/:csu', component: ArmyDocumentCertificationComponent, data: { breadcrumb: 'Army Document Certification' } },
			{ path: 'app-ito-authorizations/:csu', component: ITOAuthorizations, data: { breadcrumb: 'ITO Authorizations' } },
			{ path: 'deamsTransApproval/:csu/:group', component: DeamsTransactionApprovalComponent, data: { breadcrumb: 'Deams Transaction Approval' } },
			{ path: 'release-bids-to-gafs/:csu', component: ReleaseBIDsToGAFSComponent, data: { breadcrumb: 'Release BIDs to GAFS' } },
			
		]
	},
	{ path: 'test', component: TestComponent, data: { breadcrumb: 'Test' } },
	{ path: 'popupTest', component: PopupTestComponent, data: { breadcrumb: 'PopupTest' } },
	{ path: 'loginfailed', component: NotAuthorizedComponent, data: { breadcrumb: 'Login Failed' } },
	{ path: 'notification', component: NotificationComponent, data: { breadcrumb: 'Notification' } },
	{ path: 'chart', component: ChartComponent, data: { breadcrumb: 'Chart' } },
	{ path: 'signout', component: SignOutComponent, data: { breadcrumb: 'Sign out' } },
	{ path: '**', component: NotFoundComponent },
];

@NgModule({
	imports: [RouterModule.forRoot(routes)],
	exports: [RouterModule]
})
export class AppRoutingModule { }
